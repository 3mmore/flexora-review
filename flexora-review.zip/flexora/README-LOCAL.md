# Run FLEXORA locally on Windows

`setup.ps1` was not present in the supplied project and cannot be included. Use the commands below from **Git Bash** in the extracted `flexora` directory. They are a manual alternative, not a claim that `setup.ps1` was tested. These instructions are for a private development machine, not production.

## Prerequisites

Install Docker Desktop with Compose v2, Git for Windows (Git Bash and `openssl`), and Node.js **22 LTS, version 22.12 or newer**, with npm. Start Docker Desktop. Check `docker compose version`, `node -v`, and `openssl version`.

## Configure and start

1. Copy `.env.example` to `.env`; copy the three other `.env.example` files beside the api, web and license server to `.env` if running those apps on your host. Never share these files. Set `NODE_ENV=development` in the root `.env`. Fill the placeholders and all required Compose variables using fresh, distinct values. Set `DOMAIN=localhost`. Set `DIRECT_URL` to the migration-owner database URL using Docker host `db`; set `DATABASE_URL` to the `flexora_app` runtime role using host `db`. Both URLs must name the same database; URL-encode special characters in passwords. The dev override sets `NEXT_PUBLIC_API_URL` to an empty string so the browser uses the same-origin `/api` proxy; it does not bake a loopback URL into the web image.
2. From Git Bash, run `bash scripts/local-tls-bootstrap.sh`. It creates a self-signed certificate for `localhost` at `certbot/conf/live/domain/`. Your browser will warn: accept the warning only for this local site. Do not ship the generated certificate or key.
3. Start the database and Redis on loopback only:

   ```bash
   docker compose -f docker-compose.yml -f docker-compose.dev.yml up -d db redis
   ```

4. Build and run migrations with the **owner** connection using the one-shot service:

   ```bash
   docker compose -f docker-compose.yml -f docker-compose.dev.yml up --build migrate
   ```

   There are **68 project migrations**. Before starting the API, set the migration-created `flexora_app` role's password to the one you chose for the runtime `DATABASE_URL`. Open `psql` in the database container and use its interactive `\password flexora_app` command; do not put a password in a command argument or shell history. See `docs/DATABASE_SETUP.md` for role setup.
5. Start the stack:

   ```bash
   docker compose -f docker-compose.yml -f docker-compose.dev.yml up --build
   ```

   Check `https://localhost/api/health/live` and `https://localhost/`. The explicit dev override is never loaded automatically; do not use it on a shared machine. It binds database and Redis ports to `127.0.0.1` only. For a host-run API, use host `127.0.0.1` and the loopback ports in `apps/api/.env`; do not put the migration-owner URL in the API container.

## Optional development variables

`PLATFORM_OWNER_PHONE`, `WHATSAPP_PHONE_ID`, and `WHATSAPP_TOKEN` may be empty: alerts are recorded as `NO_CHANNEL` and cannot be delivered until configured. `JWT_PLATFORM_SECRET` may be empty in development: the server uses an ephemeral secret, so console sessions do not survive restart. Set it in production. The API must never receive `DATABASE_ADMIN_URL`.

## First platform administrator and TOTP

After installing host dependencies with `npm install`, run `npm --workspace @flexora/api run prisma:generate`. A root `npm ci` can leave the Prisma client uninitialized until this explicit step. Configure `apps/api/.env` for the loopback database and run:

```bash
npm run bootstrap:admin -- --confirm --email you@example.com --name "Owner"
```

The CLI prompts for the password without echo; do not pass a password as an argument. It refuses if any platform administrator already exists. The optional demo seed can create one, so bootstrap **before** running that seed. Sign in at `https://localhost/platform/login`, scan the enrolment QR code or enter the displayed setup key in a desktop TOTP app, and submit the six-digit code. Save the recovery codes shown once, tick the acknowledgement, then continue. Sensitive actions require a fresh code.

See `docs/ADMIN_CONSOLE.md`, `docs/DEPLOYMENT.md`, `docs/DATABASE_SETUP.md`, and `docs/DOCKERFILES.md`. Compose uses `apps/api/Dockerfile` and `apps/web/Dockerfile`; the root Dockerfiles serve the separate build-and-push scripts.

## Existing installation: preserve the database

Use the same `.env` and `COMPOSE_PROJECT_NAME=flexora` when replacing the source
files. Before upgrading, take a PostgreSQL `pg_dump` backup and verify that it can
be restored to a separate database. Keep the backup private: it contains sensitive
account data. Never run `docker compose down -v` or delete the database volume.
Run `scripts/verify-upgrade.ps1` before and after and compare its outputs; it is
read-only and prints operational gym names and dates, so keep the output private.
It uses the `flexora` Compose project and the credentials already inside the db
container. Run migrations with the owner connection as in step 4 above, then
restart the services. This script reports counts and audit validity, not a full
row-by-row comparison or a replacement for a backup. Stop if the audit chain is
invalid; do not repair it automatically.

The supplied `setup.ps1` and `tunnel.ps1` were not available for review and are
not included. Copy your existing versions yourself. In particular, review your
setup script before running it to confirm that it never deletes a database volume;
that cannot be verified here. The dev override alone sets `ADMIN_HOSTS` to
`localhost,127.0.0.1,api` and `TRUST_PROXY_HOPS=0` for web and API, so local Next
rewrites work without trusting forwarded host headers. Do not use that override
in production or expose the local services publicly.

Bootstrap accepts `--password-env NAME`; provide the variable only in the process
running the CLI and clear it afterwards. Do not put its value in a command line,
logs, or this file. Bootstrap creates only the first admin and refuses if the seed
already created one. If you can sign in as that admin, change its password through
the authenticated change-password flow; if TOTP is lost, the documented
`--reset-totp --confirm --email ... --reason ...` recovery resets TOTP only and
requires a new enrollment. It does not reset the password. See
`docs/SECRET_ROTATION.md` and `docs/ADMIN_CONSOLE.md`; do not delete the admin or
rerun the demo seed to force bootstrap.
