#!/usr/bin/env bash
# =============================================================================
# PHASE P1 — scripts/check-db-compat.sh
#
# Answers one question with evidence instead of assertion: which PostgreSQL
# owner profiles can actually run this product's migration chain AND serve
# traffic afterwards?
#
# For every profile, on a FRESH database:
#   A. apps/api/prisma/preflight-db-compat.ts — must PASS for a supported
#      profile, and must REFUSE (exit 1) for an unsupported one; when it
#      refuses, the database must still be completely empty. That is what
#      "fail EARLY" means: no half-created schema to clean up.
#   B. `prisma migrate deploy` — the raw chain, run even after a refusal, so the
#      matrix shows where an unsupported profile actually dies and that the
#      refusal was not theoretical.
#   C1/C2 migrations applied, tables created
#   C3   the runtime role really is NOSUPERUSER NOBYPASSRLS
#   C4   FORCE ROW LEVEL SECURITY is on for the tenant tables
#   C5   the SECURITY DEFINER pre-auth functions return rows under FORCE RLS
#        when called by the runtime role — this is exactly what login needs
#   C6   a real boot: owner login (201), GET /api/members (200),
#        POST /api/members (201) against that database
#
# Profiles. The brief names three; four supplementary variants are run too,
# because the three as specified cannot separate "may not create the runtime
# role" from "cannot read through SECURITY DEFINER", and because PostgreSQL 16+
# changed what CREATEROLE implies for ALTER ROLE on an existing role. A
# deployment guide that cannot tell those apart is useless. Every row is
# labelled, and each carries the outcome it is EXPECTED to produce so that an
# unsupported profile failing is recorded as evidence, not as a script failure.
#   1  superuser                     SUPERUSER                              (brief)
#   2  bypassrls                     NOSUPERUSER BYPASSRLS                  (brief)
#   3  nobypassrls                   NOSUPERUSER NOBYPASSRLS                (brief)
#   2b bypassrls+createrole          NOSUPERUSER BYPASSRLS CREATEROLE  (supplementary)
#   2c bypassrls+createrole+admin    … + ADMIN OPTION on flexora_app   (supplementary)
#   3b nobypassrls+createrole        NOSUPERUSER NOBYPASSRLS CREATEROLE(supplementary)
#   3c nobypassrls+createrole+admin  … + ADMIN OPTION on flexora_app   (supplementary)
#
# PHASE Q1 adds a D series after the profiles: the same preflight, run against a
# database whose chain is ALREADY APPLIED. A preflight that refuses every
# redeploy on a managed (non-superuser) database bricks routine deployments, so
# D1-D5b prove it decides from the PENDING migration set:
#   D0   the admin bootstraps the chain (what a managed provider does)
#   D1   non-superuser owner, ZERO pending            -> must PASS
#   D2   same owner, ONE new ordinary migration       -> must PASS
#   D2b  …and `prisma migrate deploy` really runs      -> must apply it
#   D3   same owner, 202607050001 GENUINELY pending   -> must still REFUSE EARLY
#   D4   superuser on that same database              -> must PASS (control)
#   D5   owner satisfying NEITHER R1 nor R2, zero pending -> must PASS
#   D5b  …and that same owner on an EMPTY database     -> must REFUSE EARLY
# The D series works on a COPY of apps/api/prisma under $COMPAT_WORK/dschema, so
# no fixture migration is ever written into the delivered tree.
#
# SECURITY: this script generates credentials and reuses existing ones. It never
# prints a password, a licence key, or a connection string containing
# credentials — every URL it logs goes through mask(). Role passwords are sent to
# psql on stdin, never on a command line (so they cannot appear in `ps`).
# Fixtures are 0600 inside a 0700 directory that is deleted at the end unless
# --keep is given.
#
# Usage:   scripts/check-db-compat.sh [--keep] [--skip-api] [--profiles 1,2,3]
#
# Environment:
#   DATABASE_ADMIN_URL  URL used to create roles/databases; must be SUPERUSER.
#                       Default: DIRECT_URL (else DATABASE_URL) from apps/api/.env.
#   LICENSE_SERVER_URL  licence server for the C6 boots. Default: start the
#                       repository's own license-server on 127.0.0.1:3333 with a
#                       throwaway licence, and stop it afterwards.
#   API_PORT_BASE       first port for C6 boots (default 4300).
#   COMPAT_WORK         fixture/log directory (default /var/tmp/flexora-db-compat).
# =============================================================================
set -uo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
API="$ROOT/apps/api"

KEEP=0; SKIP_API=0; ONLY=""
while [ $# -gt 0 ]; do
  case "$1" in
    --keep)     KEEP=1 ;;
    --skip-api) SKIP_API=1 ;;
    --profiles) shift; ONLY="${1:-}" ;;
    -h|--help)  sed -n '2,52p' "${BASH_SOURCE[0]}"; exit 0 ;;
    *) echo "unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

WORK="${COMPAT_WORK:-/var/tmp/flexora-db-compat}"
PORT_BASE="${API_PORT_BASE:-4300}"
PGHOST="${PGHOST:-localhost}"; PGPORT="${PGPORT:-5432}"

mkdir -p "$WORK/pw" && chmod 700 "$WORK" "$WORK/pw"
: > "$WORK/run.log"; : > "$WORK/matrix.tsv"

mask() { printf '%s' "${1:-}" | sed -E 's#(://)[^@/]*@#\1***:***@#g'; }
say()  { printf '%s\n' "$*" | tee -a "$WORK/run.log"; }
hr()   { say "──────────────────────────────────────────────────────────────────────"; }
record() { printf '%s\t%s\t%s\t%s\n' "$1" "$2" "$3" "$4" >> "$WORK/matrix.tsv"; }
# swap the database name in a postgres URL (never printed with credentials)
swapdb() { python3 -c 'import sys,re;print(re.sub(r"/[^/?]+(\?|$)","/"+sys.argv[2]+r"\1",sys.argv[1],count=1))' "$1" "$2"; }
# Prisma URLs carry ?schema=public; psql rejects that query parameter outright
# ("invalid URI query parameter: schema"), so every psql call goes through this.
stripq() { printf '%s' "${1%%\?*}"; }

# ---------------------------------------------------------------------------
# 0. tools + the admin connection
# ---------------------------------------------------------------------------
for t in psql openssl node npx curl python3; do
  command -v "$t" >/dev/null 2>&1 || { say "FATAL: $t is required but not installed"; exit 2; }
done
[ -d "$API/prisma/migrations" ] || { say "FATAL: $API/prisma/migrations not found — run from the repository"; exit 2; }
[ -f "$API/dist/src/main.js" ] && HAVE_DIST=1 || HAVE_DIST=0

env_url() { [ -f "$API/.env" ] && sed -nE "s|^$1=([^#]*)\$|\1|p" "$API/.env" | head -1; }
ADMIN_URL="${DATABASE_ADMIN_URL:-$(env_url DIRECT_URL)}"; ADMIN_URL="${ADMIN_URL:-$(env_url DATABASE_URL)}"
[ -n "$ADMIN_URL" ] || { say "FATAL: no DATABASE_ADMIN_URL and none derivable from apps/api/.env"; exit 2; }
say "admin connection: $(mask "$ADMIN_URL")"

psql_admin() { psql "$(stripq "$ADMIN_URL")" -v ON_ERROR_STOP=1 -q -tA "$@"; }
psql_admin >/dev/null 2>&1 -c 'select 1' || {
  say "FATAL: the admin URL cannot connect. Nothing was created."
  psql "$(stripq "$ADMIN_URL")" -q -tA -c 'select 1' 2>&1 | sed -E 's#://[^@/]*@#://***:***@#g' | head -3 | sed 's/^/       /' | tee -a "$WORK/run.log"
  exit 2
}
if [ "$(psql_admin -c 'select rolsuper from pg_roles where rolname = current_user')" != "t" ]; then
  say "FATAL: the admin role is not a SUPERUSER, so it cannot create the profile roles this"
  say "       matrix needs. Set DATABASE_ADMIN_URL to one that can. Nothing was created."
  exit 2
fi

RUNTIME_URL_TEMPLATE="${DATABASE_RUNTIME_URL:-$(env_url DATABASE_URL)}"
[ -n "$RUNTIME_URL_TEMPLATE" ] || { say "FATAL: apps/api/.env has no DATABASE_URL for the runtime role"; exit 2; }
RUNTIME_USER="$(python3 -c 'import sys,re;m=re.match(r"^[a-z]+://([^:/@]+)",sys.argv[1]);print(m.group(1) if m else "")' "$RUNTIME_URL_TEMPLATE")"
say "runtime role reused from apps/api/.env (credential never printed): ${RUNTIME_USER:-<unknown>}"

MIGRATIONS_TOTAL="$(find "$API/prisma/migrations" -mindepth 1 -maxdepth 1 -type d | wc -l | tr -d ' ')"
say "migration directories in the chain: $MIGRATIONS_TOTAL   built api dist: $([ "$HAVE_DIST" = 1 ] && echo yes || echo NO)"

# ---------------------------------------------------------------------------
# 1. throwaway licence server (so C6 is not killed by the global licence check)
# ---------------------------------------------------------------------------
LIC_PID=""; LICENSE_URL="${LICENSE_SERVER_URL:-}"
if [ -z "$LICENSE_URL" ] && [ "$SKIP_API" = 0 ]; then
  hr; say "starting the repository's own license-server with a throwaway licence"
  openssl rand -hex 32 > "$WORK/pw/license-hmac"; chmod 600 "$WORK/pw/license-hmac"
  export LICENSE_HMAC_SECRET; LICENSE_HMAC_SECRET="$(cat "$WORK/pw/license-hmac")"
  export LICENSES_FILE_PATH="$WORK/licenses.json"; echo '[]' > "$LICENSES_FILE_PATH"; chmod 600 "$LICENSES_FILE_PATH"
  ( cd "$ROOT/license-server" && npx ts-node generate-license.ts "DB Compat Gym" "2027-01-01" > "$WORK/license-gen.log" 2>&1 )
  python3 - "$LICENSES_FILE_PATH" "$WORK/pw/license-key" <<'PY'
import json, sys
lic = json.load(open(sys.argv[1]))[-1]
open(sys.argv[2], "w").write(lic["key"])
PY
  chmod 600 "$WORK/pw/license-key"
  say "  throwaway licence written (key length $(wc -c < "$WORK/pw/license-key" | tr -d ' '); value not printed)"
  ( cd "$ROOT/license-server" && PORT=3333 npx ts-node server.ts > "$WORK/license-server.log" 2>&1 ) &
  LIC_PID=$!
  for _ in $(seq 1 60); do
    [ "$(curl -s -o /dev/null -w '%{http_code}' -m 2 -X POST http://127.0.0.1:3333/v1/verify 2>/dev/null)" != "000" ] && break
    kill -0 "$LIC_PID" 2>/dev/null || break
    sleep 1
  done
  LICENSE_URL="http://127.0.0.1:3333"
  say "  license-server pid=$LIC_PID url=$LICENSE_URL probe=$(curl -s -o /dev/null -w '%{http_code}' -m 3 -X POST "$LICENSE_URL/v1/verify" 2>/dev/null) (400 expected: empty body)"
fi

# ---------------------------------------------------------------------------
# 2. profiles
# ---------------------------------------------------------------------------
PROFILE_IDS=(1 2 3 2b 2c 3b 3c)
# EXPECT  = is this profile supposed to be usable end to end?
# PREP    = fixture step run as admin before the chain (grants ADMIN OPTION on the
#           pre-existing runtime role, which is what PostgreSQL 16+ requires for a
#           non-superuser to ALTER ROLE it).
# EXPB    = does the raw chain apply for this profile? Used so that an EXPECTED
#           failure is recorded as evidence (PASS of that row) and only an
#           UNEXPECTED result is recorded as FAIL.
P_NAME_1="superuser";                     P_ATTRS_1="SUPERUSER";                                    P_EXPECT_1="supported";     P_PREP_1="none";         P_EXPB_1="applies"
P_NAME_2="bypassrls";                     P_ATTRS_2="NOSUPERUSER BYPASSRLS";                         P_EXPECT_2="refused-early"; P_PREP_2="none";         P_EXPB_2="fails"
P_NAME_3="nobypassrls";                   P_ATTRS_3="NOSUPERUSER NOBYPASSRLS";                       P_EXPECT_3="refused-early"; P_PREP_3="none";         P_EXPB_3="fails"
P_NAME_2b="bypassrls+createrole";         P_ATTRS_2b="NOSUPERUSER BYPASSRLS CREATEROLE";             P_EXPECT_2b="refused-early";P_PREP_2b="none";        P_EXPB_2b="fails"
P_NAME_2c="bypassrls+createrole+admin";   P_ATTRS_2c="NOSUPERUSER BYPASSRLS CREATEROLE";             P_EXPECT_2c="refused-early";P_PREP_2c="admin-option";P_EXPB_2c="fails"
P_NAME_3b="nobypassrls+createrole";       P_ATTRS_3b="NOSUPERUSER NOBYPASSRLS CREATEROLE";           P_EXPECT_3b="refused-early";P_PREP_3b="none";        P_EXPB_3b="fails"
P_NAME_3c="nobypassrls+createrole+admin"; P_ATTRS_3c="NOSUPERUSER NOBYPASSRLS CREATEROLE";           P_EXPECT_3c="refused-early";P_PREP_3c="admin-option";P_EXPB_3c="fails"
val() { eval "printf '%s' \"\${P_${1}_${2}}\""; }
selected() { [ -z "$ONLY" ] && return 0; case ",$ONLY," in *",$1,"*) return 0 ;; *) return 1 ;; esac; }

run_profile() {
  local id="$1" idx="$2"
  local name; name="$(val NAME "$id")"
  local attrs; attrs="$(val ATTRS "$id")"
  local expect; expect="$(val EXPECT "$id")"
  local prep; prep="$(val PREP "$id")"
  local expb; expb="$(val EXPB "$id")"
  local safe="${id//[^a-zA-Z0-9]/_}"
  local role="flexora_c_${safe}" db="flexora_c_${safe}"
  local dir="$WORK/$id"; mkdir -p "$dir"
  local port=$((PORT_BASE + idx))
  local redis_db=$((idx))          # 1..7; never 0, which the main instance uses

  hr; say "PROFILE $id — $name   ($attrs)   expected: $expect   chain-expected: $expb   prep: $prep"
  say "  role=$role db=$db api-port=$port redis-db=$redis_db"

  # ---- fresh role + database (password goes to psql on stdin, not argv) ------
  psql_admin >/dev/null 2>&1 -c "DROP DATABASE IF EXISTS $db"
  psql_admin >/dev/null 2>&1 -c "DROP ROLE IF EXISTS $role"
  openssl rand -hex 24 > "$WORK/pw/$role"; chmod 600 "$WORK/pw/$role"
  local pw; pw="$(cat "$WORK/pw/$role")"
  if ! psql_admin > "$dir/role.log" 2>&1 <<SQL
CREATE ROLE $role LOGIN $attrs PASSWORD '$pw' CONNECTION LIMIT -1;
SQL
  then
    say "  FATAL could not create the profile role:"; sed 's/^/      /' "$dir/role.log" | tee -a "$WORK/run.log"
    record "$id/$name" "role creation (fixture step)" "FAIL" "$(head -1 "$dir/role.log" | cut -c1-90)"; return
  fi
  if ! psql_admin > "$dir/db.log" 2>&1 -c "CREATE DATABASE $db OWNER $role"; then
    say "  FATAL could not create the database:"; sed 's/^/      /' "$dir/db.log" | tee -a "$WORK/run.log"
    record "$id/$name" "database creation (fixture step)" "FAIL" "$(head -1 "$dir/db.log" | cut -c1-90)"; return
  fi
  # Fixture prep: on an existing cluster the runtime role already exists, and
  # PostgreSQL 16+ only lets a non-superuser ALTER ROLE it with ADMIN OPTION.
  if [ "$prep" = admin-option ]; then
    if psql_admin > "$dir/prep.log" 2>&1 -c "GRANT $RUNTIME_USER TO $role WITH ADMIN OPTION"; then
      say "  prep: GRANT $RUNTIME_USER TO $role WITH ADMIN OPTION — ok"
    else
      say "  prep FAILED:"; sed 's/^/      /' "$dir/prep.log" | tee -a "$WORK/run.log"
      record "$id/$name" "prep: admin option on runtime role" "FAIL" "$(head -1 "$dir/prep.log" | cut -c1-90)"; return
    fi
  fi
  local owner_url="postgresql://${role}:${pw}@${PGHOST}:${PGPORT}/${db}?schema=public"
  local admin_db_url; admin_db_url="$(stripq "$(swapdb "$ADMIN_URL" "$db")")"
  say "  created: $(mask "$owner_url")"

  # ---- A. the preflight ------------------------------------------------------
  ( cd "$API" && env -u NODE_OPTIONS NODE_ENV=development DIRECT_URL="$owner_url" DATABASE_URL="$owner_url" \
      npx ts-node prisma/preflight-db-compat.ts > "$dir/preflight.log" 2>&1 )
  local pre=$?
  local tbl_after mig_after
  tbl_after="$(psql "$admin_db_url" -tAc "select count(*) from information_schema.tables where table_schema='public'" 2>/dev/null || echo '?')"
  mig_after="$(psql "$admin_db_url" -tAc "select to_regclass('public._prisma_migrations') is null" 2>/dev/null || echo '?')"
  local rre; rre="$(grep -ao 'runtime_role_exists=[a-z]*' "$dir/preflight.log" | head -1)"
  # Derive this profile's expectations from the MEASURED cluster state instead of
  # trusting the static table. A non-superuser owner can only run the role
  # migration when the runtime role does not exist yet: PostgreSQL lets a
  # CREATEROLE role CREATE ROLE ... NOSUPERUSER ..., but refuses any non-superuser
  # ALTER ROLE ... NOSUPERUSER ... even with ADMIN OPTION on that role (measured on
  # PostgreSQL 17; see the PHASE P1 evidence). So "supported" is a property of the
  # (owner attributes, runtime-role-exists) pair, not of the owner alone.
  local fresh=0 has_cr=0 is_super=0 has_bypass=0 fresh_word=true
  [ "${rre#runtime_role_exists=}" = false ] && fresh=1
  [ "$fresh" = 1 ] && fresh_word=false
  case " $attrs " in *" CREATEROLE "*) has_cr=1 ;; esac
  case " $attrs " in *" SUPERUSER "*)  is_super=1 ;; esac
  case " $attrs " in *" BYPASSRLS "*)  has_bypass=1 ;; esac
  if [ "$is_super" = 1 ]; then
    expb="applies"; expect="supported"
  elif [ "$fresh" = 1 ] && [ "$has_cr" = 1 ]; then
    expb="applies"
    if [ "$has_bypass" = 1 ]; then expect="supported"; else expect="refused-early"; fi
  else
    expb="fails"; expect="refused-early"
  fi
  say "  derived from cluster state: runtime_role_exists=$fresh_word -> preflight=$expect chain=$expb"
  say "  A preflight exit=$pre   tables-after=$tbl_after   _prisma_migrations-absent=$mig_after   ${rre:-runtime_role_exists=?}"
  grep -aE 'db-compat preflight|FATAL|R1 |R2 |Supported owner' "$dir/preflight.log" | head -5 | sed 's/^/      /' | tee -a "$WORK/run.log"
  if [ "$expect" = supported ]; then
    if [ "$pre" = 0 ]; then record "$id/$name" "A preflight accepts" "PASS" "exit=0"
    else record "$id/$name" "A preflight accepts" "FAIL" "exit=$pre (expected 0)"; fi
  else
    if [ "$pre" != 0 ] && [ "$tbl_after" = 0 ] && [ "$mig_after" = t ]; then
      record "$id/$name" "A preflight refuses EARLY" "PASS" "exit=$pre; 0 tables; no _prisma_migrations"
    else
      record "$id/$name" "A preflight refuses EARLY" "FAIL" "exit=$pre tables=$tbl_after migrations_absent=$mig_after"
    fi
  fi

  # ---- B. the raw chain (evidence, run regardless of A) ----------------------
  local t0 t1 secs
  t0=$(date +%s)
  ( cd "$API" && env -u NODE_OPTIONS NODE_ENV=development DIRECT_URL="$owner_url" DATABASE_URL="$owner_url" \
      npx prisma migrate deploy > "$dir/migrate.log" 2>&1 )
  local mig=$?
  t1=$(date +%s); secs=$((t1 - t0))
  local applied failed tables
  applied="$(psql "$admin_db_url" -tAc "select count(*) from _prisma_migrations where finished_at is not null" 2>/dev/null || echo 0)"
  failed="$(psql "$admin_db_url" -tAc "select count(*) from _prisma_migrations where finished_at is null" 2>/dev/null || echo 0)"
  tables="$(psql "$admin_db_url" -tAc "select count(*) from information_schema.tables where table_schema='public'" 2>/dev/null || echo 0)"
  say "  B migrate deploy exit=$mig in ${secs}s   applied=$applied/$MIGRATIONS_TOTAL failed_rows=$failed tables=$tables"
  if [ "$mig" != 0 ]; then
    grep -aE 'Error|ERROR|permission denied|42501|following migration|failed' "$dir/migrate.log" | head -5 | sed 's/^/      /' | tee -a "$WORK/run.log"
  fi
  local chain_applied=0
  { [ "$mig" = 0 ] && [ "$applied" = "$MIGRATIONS_TOTAL" ]; } && chain_applied=1
  if [ "$expb" = applies ]; then
    if [ "$chain_applied" = 1 ]; then
      record "$id/$name" "B chain applies ($MIGRATIONS_TOTAL migrations)" "PASS" "${secs}s; $tables tables"
    else
      record "$id/$name" "B chain applies ($MIGRATIONS_TOTAL migrations)" "FAIL" "expected to apply: exit=$mig applied=$applied/$MIGRATIONS_TOTAL ${secs}s"
    fi
  else
    if [ "$chain_applied" = 0 ]; then
      record "$id/$name" "B chain fails as expected" "PASS" "exit=$mig applied=$applied/$MIGRATIONS_TOTAL ${secs}s — unsupported profile"
    else
      record "$id/$name" "B chain fails as expected" "FAIL" "chain UNEXPECTEDLY applied $applied/$MIGRATIONS_TOTAL — this expectation is stale, re-check the profile"
    fi
  fi
  if [ "$chain_applied" != 1 ]; then
    record "$id/$name" "C3–C6" "NOT RUN" "chain did not complete for this profile"
    return
  fi

  # ---- C3 runtime role attributes -------------------------------------------
  local attrs_row
  attrs_row="$(psql "$(stripq "$owner_url")" -tAc "select 'super='||rolsuper||' bypass='||rolbypassrls||' createrole='||rolcreaterole from pg_roles where rolname='$RUNTIME_USER'" 2>/dev/null)"
  say "  C3 runtime role $RUNTIME_USER: ${attrs_row:-<unreadable>}"
  case "$attrs_row" in
    super=f*bypass=f*) record "$id/$name" "C3 runtime role NOSUPERUSER NOBYPASSRLS" "PASS" "$attrs_row" ;;
    *)                 record "$id/$name" "C3 runtime role NOSUPERUSER NOBYPASSRLS" "FAIL" "${attrs_row:-unreadable}" ;;
  esac

  # ---- C4 FORCE RLS ----------------------------------------------------------
  local rls forced
  rls="$(psql "$(stripq "$owner_url")" -tAc "select count(*) from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relrowsecurity" 2>/dev/null)"
  forced="$(psql "$(stripq "$owner_url")" -tAc "select count(*) from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relrowsecurity and c.relforcerowsecurity" 2>/dev/null)"
  say "  C4 row-security tables=$rls  force-row-security=$forced"
  if [ "${forced:-0}" -ge 70 ] 2>/dev/null; then
    record "$id/$name" "C4 FORCE ROW LEVEL SECURITY on tenant tables" "PASS" "forced=$forced rls=$rls"
  else
    record "$id/$name" "C4 FORCE ROW LEVEL SECURITY on tenant tables" "FAIL" "forced=$forced rls=$rls"
  fi

  # ---- seed as admin (fixture step, not a capability under test) -------------
  local seed_pw="Compat$(openssl rand -hex 8)Z!9"
  ( cd "$API" && env -u NODE_OPTIONS NODE_ENV=development DATABASE_URL="$admin_db_url" DIRECT_URL="$admin_db_url" \
      SUPER_ADMIN_PASSWORD="$seed_pw" npx ts-node prisma/seed.ts > "$dir/seed.log" 2>&1 )
  local seed=$?
  say "  seed as admin into $db: exit=$seed"
  tail -2 "$dir/seed.log" | sed 's/^/      /' | tee -a "$WORK/run.log"
  if [ "$seed" != 0 ]; then
    record "$id/$name" "C5/C6" "BLOCKED" "seed failed exit=$seed (see $id/seed.log)"; return
  fi

  # ---- C5 SECURITY DEFINER pre-auth under FORCE RLS, as the runtime role -----
  local runtime_url; runtime_url="$(swapdb "$RUNTIME_URL_TEMPLATE" "$db")"
  local c5a c5b
  c5a="$(psql "$(stripq "$runtime_url")" -tAc "select count(*) from preauth_find_users_by_email('owner@demo.flexora.app')" 2>"$dir/c5.err")"
  c5b="$(psql "$(stripq "$runtime_url")" -tAc "select count(*) from preauth_find_user_by_id((select id from preauth_find_users_by_email('owner@demo.flexora.app') limit 1))" 2>>"$dir/c5.err")"
  say "  C5 as $RUNTIME_USER: preauth_find_users_by_email=${c5a:-ERR} preauth_find_user_by_id=${c5b:-ERR}"
  [ -s "$dir/c5.err" ] && head -2 "$dir/c5.err" | sed 's/^/      /' | tee -a "$WORK/run.log"
  local c5_ok=0
  { [ "${c5a:-0}" -ge 1 ] 2>/dev/null && [ "${c5b:-0}" -ge 1 ] 2>/dev/null; } && c5_ok=1
  if [ "$expect" = supported ]; then
    if [ "$c5_ok" = 1 ]; then
      record "$id/$name" "C5 SECURITY DEFINER preauth rows under FORCE RLS" "PASS" "by_email=$c5a by_id=$c5b"
    else
      record "$id/$name" "C5 SECURITY DEFINER preauth rows under FORCE RLS" "FAIL" "by_email=${c5a:-ERR} by_id=${c5b:-ERR} — login impossible on a supported profile"
    fi
  else
    if [ "$c5_ok" = 1 ]; then
      record "$id/$name" "C5 preauth returns NO rows (expected for this owner)" "FAIL" "by_email=$c5a — rows came back unexpectedly; R2 may not be required after all"
    else
      record "$id/$name" "C5 preauth returns NO rows (expected for this owner)" "PASS" "by_email=${c5a:-ERR} by_id=${c5b:-ERR} — confirms R2 (BYPASSRLS) is required"
    fi
  fi

  # ---- C6 real boot ---------------------------------------------------------
  if [ "$SKIP_API" = 1 ]; then record "$id/$name" "C6 live API" "SKIPPED" "--skip-api"; return; fi
  if [ "$HAVE_DIST" != 1 ]; then record "$id/$name" "C6 live API" "BLOCKED" "apps/api/dist missing — build first"; return; fi
  if [ "$c5_ok" != 1 ]; then
    if [ "$expect" = supported ]; then
      record "$id/$name" "C6 live API" "FAIL" "C5 failed: no pre-auth rows, so no login is possible"
    else
      record "$id/$name" "C6 live API (expected blocked)" "PASS" "not attempted — no pre-auth rows means login cannot work for this owner profile"
    fi
    return
  fi
  ( cd "$API" && env -u NODE_OPTIONS NODE_ENV=development PRISMA_QUERY_LOG=off \
      DATABASE_URL="$runtime_url" DIRECT_URL="$runtime_url" \
      REDIS_URL="redis://127.0.0.1:6379/$redis_db" API_PORT="$port" \
      LICENSE_SERVER_URL="$LICENSE_URL" FLEXORA_LICENSE_KEY="$(cat "$WORK/pw/license-key" 2>/dev/null)" \
      node dist/src/main.js > "$dir/api.log" 2>&1 ) &
  local api_pid=$! up=000
  for _ in $(seq 1 45); do
    up="$(curl -s -o /dev/null -w '%{http_code}' -m 3 "http://127.0.0.1:$port/api/health/live" 2>/dev/null)"
    [ "$up" = 200 ] && break
    kill -0 "$api_pid" 2>/dev/null || break
    sleep 1
  done
  say "  C6 api :$port /api/health/live -> $up (pid $api_pid)"
  if [ "$up" != 200 ]; then
    grep -aiE 'FATAL|licen|shutdown|error' "$dir/api.log" | head -4 | sed 's/^/      /' | tee -a "$WORK/run.log"
    kill "$api_pid" 2>/dev/null
    record "$id/$name" "C6 live API" "FAIL" "health=$up (see $id/api.log)"; return
  fi

  local jar="$dir/cookies.txt" base="http://127.0.0.1:$port" login list create csrf plan mobile
  # body written to a 0600 file: keeps the seed password out of curl's argv
  # (visible in `ps`) and out of the shell quoting entirely.
  node -e 'const fs=require("fs");fs.writeFileSync(process.argv[1],JSON.stringify({email:process.argv[2],password:process.argv[3]}))' "$dir/login-body.json" "owner@demo.flexora.app" "$seed_pw"
  chmod 600 "$dir/login-body.json"
  login="$(curl -s -o "$dir/login.json" -w '%{http_code}' -m 20 -c "$jar" -H 'Content-Type: application/json' --data-binary "@$dir/login-body.json" "$base/api/auth/login" 2>/dev/null)"
  rm -f "$dir/login-body.json"
  say "     POST /api/auth/login -> $login"
  [ "$login" != 201 ] && head -c 200 "$dir/login.json" 2>/dev/null | sed 's/^/      /' | tee -a "$WORK/run.log" && say ""
  curl -s -o /dev/null -m 15 -b "$jar" -c "$jar" "$base/api/members?limit=1" >/dev/null 2>&1
  csrf="$(awk '/_csrf/ {for(i=1;i<=NF;i++) if($i ~ /_csrf/) print $i}' "$jar" 2>/dev/null | head -1 | sed -E 's/^_csrf//')"
  list="$(curl -s -o "$dir/members.json" -w '%{http_code}' -m 25 -b "$jar" "$base/api/members?limit=1" 2>/dev/null)"
  say "     GET  /api/members -> $list"
  curl -s -o "$dir/plans.json" -m 25 -b "$jar" "$base/api/plans?limit=1" >/dev/null 2>&1
  plan="$(node -e 'const fs=require("fs");try{const j=JSON.parse(fs.readFileSync(process.argv[1],"utf8"));const a=Array.isArray(j)?j:(j.data||j.items||j.plans||[]);console.log((a[0]&&a[0].id)||"")}catch(e){console.log("")}' "$dir/plans.json" 2>/dev/null)"
  # 11 digits with a valid Egyptian mobile prefix — the API validates the format,
  # so a random 9xxxxxxxx number only proves the test was wrong, not the product.
  local pfx_idx=$((RANDOM % 3))
  local tail8=$(( (RANDOM * 32768 + RANDOM) % 100000000 ))
  mobile="$(printf '01%d%08d' "$pfx_idx" "$tail8")"
  # payload written by node: no nested shell quoting, no escaping bugs
  node -e 'const fs=require("fs");fs.writeFileSync(process.argv[1],JSON.stringify({name:"Compat Probe Member",mobile:process.argv[2],planId:process.argv[3]}))' "$dir/create-body.json" "$mobile" "$plan"
  if [ -n "$csrf" ]; then
    create="$(curl -s -o "$dir/create.json" -w '%{http_code}' -m 30 -b "$jar" -H 'Content-Type: application/json' -H "X-CSRF-Token: $csrf" --data-binary "@$dir/create-body.json" "$base/api/members" 2>/dev/null)"
  else
    create="$(curl -s -o "$dir/create.json" -w '%{http_code}' -m 30 -b "$jar" -H 'Content-Type: application/json' --data-binary "@$dir/create-body.json" "$base/api/members" 2>/dev/null)"
  fi
  local plan_state=NO csrf_state=NO
  [ -n "$plan" ] && plan_state=yes
  [ -n "$csrf" ] && csrf_state=yes
  say "     POST /api/members -> $create   (planId present: $plan_state, csrf token present: $csrf_state)"
  if [ "$create" != 201 ]; then head -c 300 "$dir/create.json" 2>/dev/null | sed 's/^/      /' | tee -a "$WORK/run.log"; say ""; fi

  if [ "$login" = 201 ] && [ "$list" = 200 ] && [ "$create" = 201 ]; then
    if [ "$expect" = supported ]; then
      record "$id/$name" "C6 login 201 + GET members 200 + POST member 201" "PASS" "$login/$list/$create"
    else
      record "$id/$name" "C6 login 201 + GET members 200 + POST member 201" "FAIL" "$login/$list/$create on a profile expected to be unusable — re-check"
    fi
  else
    if [ "$expect" = supported ]; then
      record "$id/$name" "C6 login 201 + GET members 200 + POST member 201" "FAIL" "login=$login list=$list create=$create"
    else
      record "$id/$name" "C6 refused as expected" "PASS" "login=$login list=$list create=$create"
    fi
  fi
  kill "$api_pid" 2>/dev/null; wait "$api_pid" 2>/dev/null
}

# ---------------------------------------------------------------------------
# 3. run
# ---------------------------------------------------------------------------
hr; say "PHASE P1 — database owner compatibility matrix"
say "repo: $ROOT   work: $WORK   migrations in chain: $MIGRATIONS_TOTAL"
i=0
for id in "${PROFILE_IDS[@]}"; do
  i=$((i + 1))
  selected "$id" || continue
  run_profile "$id" "$i"
done

# ---------------------------------------------------------------------------
# 3b. PHASE Q1 — the D series: a preflight that blocks routine redeploys is a
#     defect, not a safeguard. On a managed database the owner is a
#     non-superuser and `flexora_app` already exists, so R1 can never be
#     satisfied again after the first deploy — yet nothing privileged is left to
#     run. These rows prove the preflight now decides from the PENDING set.
#
#     Everything here runs against a COPY of apps/api/prisma under $WORK/dschema,
#     so the delivered tree is never modified: no dummy migration is ever written
#     into apps/api/prisma/migrations, and an interrupted run cannot leave the
#     repository dirty.
# ---------------------------------------------------------------------------
DROOT="$WORK/dschema"
D_ROLE="flexora_c_d2b"
D_DB="flexora_c_d2b"
D_WEAK_ROLE="flexora_c_dweak"
D_WEAK_DB="flexora_c_dweak"
D_PART_DB="flexora_c_dpart"

prepare_dschema() {
  rm -rf "$DROOT"
  mkdir -p "$DROOT/src/config"
  cp -a "$API/prisma" "$DROOT/prisma"
  cp "$API/tsconfig.json" "$DROOT/tsconfig.json" 2>/dev/null || true
  # The real preflight imports '../src/config/load-env' for its dotenv side
  # effect. Here every variable it needs is passed explicitly on the command
  # line, so an empty stub is both sufficient and safer (it cannot pick up a
  # stray .env and quietly change which database is inspected).
  : > "$DROOT/src/config/load-env.ts"
  ln -sfn "$ROOT/node_modules" "$DROOT/node_modules"
}

# preflight as a given owner URL; echoes the exit code, log goes to $2
d_preflight() {
  local owner_url="$1" log="$2"
  ( cd "$DROOT" && env -u NODE_OPTIONS NODE_ENV=development \
      DIRECT_URL="$owner_url" DATABASE_URL="$owner_url" \
      npx ts-node prisma/preflight-db-compat.ts > "$log" 2>&1 )
  echo $?
}

# After an ADMIN applies a chain into a database owned by a profile role, that
# role still cannot read `_prisma_migrations` (the table is owned by the admin).
# This is the same fixture grant o0-rebuild-env.sh applies for flexora_app, and it
# models the real managed-provider split: a privileged bootstrap role applied the
# schema once, the non-superuser owner role runs every later deploy. It is a
# FIXTURE step, not a capability under test, and it is logged as one.
d_grant() {
  local db="$1" role="$2" ok=1
  # NOTE: psql gives a conninfo string passed as its first non-option argument
  # PRECEDENCE over -d, so `psql_admin -d "$db"` would silently have run against
  # the admin URL's own database. The per-database admin URL is built instead
  # (credentials still masked everywhere this script prints).
  local db_admin_url; db_admin_url="$(stripq "$(swapdb "$ADMIN_URL" "$db")")"
  psql "$db_admin_url" -v ON_ERROR_STOP=1 -q -tA >/dev/null 2>"$WORK/grant-$db.err" -c \
    "GRANT USAGE ON SCHEMA public TO $role; GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA public TO $role; GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA public TO $role; GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO $role;" || ok=0
  if [ "$ok" = 1 ]; then
    say "  fixture grant: $role can read/write the schema of $db (admin applied it)"
  else
    say "  fixture grant FAILED for $role on $db:"
    head -2 "$WORK/grant-$db.err" | sed 's/^/      /' | tee -a "$WORK/run.log"
  fi
}

d_preflight_before() {
  local owner_url="$1" log="$2"
  ( cd "$DROOT" && env -u NODE_OPTIONS NODE_ENV=development \
      DIRECT_URL="$owner_url" DATABASE_URL="$owner_url" \
      npx ts-node prisma/preflight-before.ts > "$log" 2>&1 )
  echo $?
}

d_migrate() {
  local url="$1" log="$2" schema="${3:-prisma/schema.prisma}"
  ( cd "$DROOT" && env -u NODE_OPTIONS NODE_ENV=development \
      DIRECT_URL="$url" DATABASE_URL="$url" \
      npx prisma migrate deploy --schema "$schema" > "$log" 2>&1 )
  echo $?
}

run_dseries() {
  hr; say "D SERIES — PHASE Q1: the preflight must not block redeploys"
  [ -d "$API/prisma/migrations" ] || { say "  FATAL: no migrations directory"; return; }

  # ---- fixture roles/databases (admin step, not a capability under test) -----
  local dpw dwpw downer dweak dadmin dpart_admin
  # bash evaluates every word of a single `local a=… b=$a …` command before the
  # declarations exist, which under `set -u` reads as an unbound variable — so
  # each fixture role is described by parallel arrays and assigned one at a time.
  local fx_roles=("$D_ROLE" "$D_WEAK_ROLE")
  local fx_dbs=("$D_DB" "$D_WEAK_DB")
  local fx_attrs=("NOSUPERUSER BYPASSRLS CREATEROLE" "NOSUPERUSER NOBYPASSRLS NOCREATEROLE")
  local k fr fd fa lpw
  for k in 0 1; do
    fr="${fx_roles[$k]}"; fd="${fx_dbs[$k]}"; fa="${fx_attrs[$k]}"
    psql_admin >/dev/null 2>&1 -c "DROP DATABASE IF EXISTS $fd"
    psql_admin >/dev/null 2>&1 -c "DROP ROLE IF EXISTS $fr"
    openssl rand -hex 24 > "$WORK/pw/$fr"; chmod 600 "$WORK/pw/$fr"
    lpw="$(cat "$WORK/pw/$fr")"
    if ! psql_admin > "$WORK/$fr.role.log" 2>&1 <<SQL
CREATE ROLE $fr LOGIN $fa PASSWORD '$lpw' CONNECTION LIMIT -1;
SQL
    then
      say "  FATAL could not create $fr:"
      sed 's/^/      /' "$WORK/$fr.role.log" | tee -a "$WORK/run.log"
      record "D/$fr" "fixture: create role" "FAIL" "$(head -1 "$WORK/$fr.role.log" | cut -c1-90)"
      return
    fi
    if ! psql_admin > "$WORK/$fr.db.log" 2>&1 -c "CREATE DATABASE $fd OWNER $fr"; then
      say "  FATAL could not create $fd"
      record "D/$fr" "fixture: create database" "FAIL" "see $fr.db.log"
      return
    fi
    say "  fixture: role $fr ($fa) owns database $fd"
  done
  psql_admin >/dev/null 2>&1 -c "DROP DATABASE IF EXISTS $D_PART_DB"
  psql_admin > "$WORK/dpart.db.log" 2>&1 -c "CREATE DATABASE $D_PART_DB OWNER $D_ROLE" \
    || { say "  FATAL could not create $D_PART_DB"; record "D/partial" "fixture: create database" "FAIL" "see dpart.db.log"; return; }

  dpw="$(cat "$WORK/pw/$D_ROLE")"; dwpw="$(cat "$WORK/pw/$D_WEAK_ROLE")"
  downer="postgresql://${D_ROLE}:${dpw}@${PGHOST}:${PGPORT}/${D_DB}?schema=public"
  dweak="postgresql://${D_WEAK_ROLE}:${dwpw}@${PGHOST}:${PGPORT}/${D_WEAK_DB}?schema=public"
  dadmin="$(swapdb "$ADMIN_URL" "$D_DB")"
  dpart_admin="$(swapdb "$ADMIN_URL" "$D_PART_DB")"
  dpart_owner="postgresql://${D_ROLE}:${dpw}@${PGHOST}:${PGPORT}/${D_PART_DB}?schema=public"
  say "  runtime role \"$RUNTIME_USER\" exists on this cluster: $(psql_admin -tAc "select count(*)>0 from pg_roles where rolname='$RUNTIME_USER'")"

  # ---- D0: the managed-provider bootstrap — the chain is applied by the ADMIN
  prepare_dschema
  local m0; m0="$(d_migrate "$dadmin" "$WORK/d0-migrate.log")"
  local applied0; applied0="$(psql "$(stripq "$dadmin")" -tAc "select count(*) from _prisma_migrations where finished_at is not null" 2>/dev/null || echo 0)"
  local tables0; tables0="$(psql "$(stripq "$dadmin")" -tAc "select count(*) from information_schema.tables where table_schema='public'" 2>/dev/null || echo 0)"
  say "  D0 admin applied the chain into $D_DB: exit=$m0 applied=$applied0/$MIGRATIONS_TOTAL tables=$tables0"
  if [ "$applied0" != "$MIGRATIONS_TOTAL" ]; then
    record "D0 admin bootstrap" "chain applied by the admin role" "FAIL" "exit=$m0 applied=$applied0/$MIGRATIONS_TOTAL"
    grep -aE 'Error|ERROR|permission denied' "$WORK/d0-migrate.log" | head -3 | sed 's/^/      /' | tee -a "$WORK/run.log"
    return
  fi
  record "D0 admin bootstrap" "chain applied by the admin role ($MIGRATIONS_TOTAL migrations)" "PASS" "$tables0 tables"
  d_grant "$D_DB" "$D_ROLE"

  # ---- D1: the redeploy that PHASE P1 broke ---------------------------------
  local pre1; pre1="$(d_preflight "$downer" "$WORK/d1-preflight.log")"
  local pend1; pend1="$(grep -ao 'pending=[0-9]*' "$WORK/d1-preflight.log" | tail -1)"
  say "  D1 preflight as $D_ROLE (non-superuser, runtime role exists) on the FULLY APPLIED db:"
  say "     exit=$pre1  ${pend1:-pending=?}  R1: $(grep -ao 'R1(CREATE/ALTER ROLE)=[^;]*' "$WORK/d1-preflight.log" | tail -1)"
  grep -aE 'db-compat preflight|FATAL' "$WORK/d1-preflight.log" | head -6 | sed 's/^/      /' | tee -a "$WORK/run.log"
  if [ "$pre1" = 0 ] && [ "$pend1" = "pending=0" ]; then
    record "D1/2b redeploy" "preflight PASSES with zero pending migrations" "PASS" "exit=0; $pend1; tables=$tables0"
  else
    record "D1/2b redeploy" "preflight PASSES with zero pending migrations" "FAIL" "exit=$pre1 ${pend1:-?} — redeploy blocked"
  fi

  # ---- D1-before: the same database, the same owner, the PREVIOUS preflight ---
  # Optional and driven from outside the delivered tree: point
  # Q1_BEFORE_PREFLIGHT at a copy of an earlier preflight-db-compat.ts and this
  # row runs it against exactly the fixtures D1 used, so BEFORE and AFTER are
  # directly comparable instead of being two separate stories.
  if [ -n "${Q1_BEFORE_PREFLIGHT:-}" ] && [ -f "${Q1_BEFORE_PREFLIGHT:-}" ]; then
    cp "$Q1_BEFORE_PREFLIGHT" "$DROOT/prisma/preflight-before.ts"
    local preb; preb="$(d_preflight_before "$downer" "$WORK/d1-before-preflight.log")"
    say "  D1-before previous preflight on the SAME fully applied db as the SAME owner: exit=$preb"
    grep -aE 'BEFORE|FATAL|R1 ' "$WORK/d1-before-preflight.log" | head -4 | sed 's/^/      /' | tee -a "$WORK/run.log"
    if [ "$preb" != 0 ]; then
      record "D1-before/Phase P1 preflight" "the previous preflight REFUSED this redeploy (BEFORE)" "PASS" "exit=$preb — the defect PHASE Q1 removes"
    else
      record "D1-before/Phase P1 preflight" "the previous preflight REFUSED this redeploy (BEFORE)" "FAIL" "exit=0 — the BEFORE evidence did not reproduce; check Q1_BEFORE_PREFLIGHT"
    fi
  else
    record "D1-before/Phase P1 preflight" "the previous preflight REFUSED this redeploy (BEFORE)" "NOT RUN" "set Q1_BEFORE_PREFLIGHT=<path to an earlier preflight-db-compat.ts>"
  fi

  # ---- D2: a redeploy that carries ONE new, ordinary migration --------------
  local dummy="99999999999999_q1_dummy_redeploy_probe"
  mkdir -p "$DROOT/prisma/migrations/$dummy"
  cat > "$DROOT/prisma/migrations/$dummy/migration.sql" <<'SQL'
-- PHASE Q1 fixture: an ordinary migration of the kind a redeploy really carries.
-- It creates no role and no SECURITY DEFINER function, so it demands nothing
-- privileged from the owner. This file exists ONLY inside the throwaway copy of
-- the schema under $COMPAT_WORK — never in apps/api/prisma/migrations.
CREATE TABLE IF NOT EXISTS "Q1DummyProbe" (
  id TEXT PRIMARY KEY,
  created_at TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP
);
SQL
  local total2=$((MIGRATIONS_TOTAL + 1))
  local pre2; pre2="$(d_preflight "$downer" "$WORK/d2-preflight.log")"
  local pend2; pend2="$(grep -ao 'pending=[0-9]*' "$WORK/d2-preflight.log" | tail -1)"
  say "  D2 preflight as $D_ROLE with ONE new ordinary migration pending:"
  say "     exit=$pre2  ${pend2:-pending=?}  R1: $(grep -ao 'R1(CREATE/ALTER ROLE)=[^;]*' "$WORK/d2-preflight.log" | tail -1)"
  grep -aE 'PASS|FATAL|R1\(|R2\(' "$WORK/d2-preflight.log" | head -4 | sed 's/^/      /' | tee -a "$WORK/run.log"
  if [ "$pre2" = 0 ] && [ "$pend2" = "pending=1" ]; then
    record "D2/2b + new migration" "preflight PASSES with one ordinary migration pending" "PASS" "exit=0; $pend2; R1 not needed"
  else
    record "D2/2b + new migration" "preflight PASSES with one ordinary migration pending" "FAIL" "exit=$pre2 ${pend2:-?}"
  fi

  # ---- D2b: and the deploy itself really runs as that owner -----------------
  local m2; m2="$(d_migrate "$downer" "$WORK/d2b-migrate.log")"
  local applied2; applied2="$(psql "$(stripq "$dadmin")" -tAc "select count(*) from _prisma_migrations where finished_at is not null" 2>/dev/null || echo 0)"
  local dummy_row; dummy_row="$(psql "$(stripq "$dadmin")" -tAc "select count(*) from _prisma_migrations where migration_name='$dummy'" 2>/dev/null || echo 0)"
  say "  D2b migrate deploy as $D_ROLE: exit=$m2 applied=$applied2/$total2 dummy-recorded=$dummy_row"
  [ "$m2" != 0 ] && grep -aE 'Error|ERROR|permission denied' "$WORK/d2b-migrate.log" | head -3 | sed 's/^/      /' | tee -a "$WORK/run.log"
  if [ "$m2" = 0 ] && [ "$applied2" = "$total2" ] && [ "$dummy_row" = 1 ]; then
    record "D2b/2b applies it" "migrate deploy succeeds as the non-superuser owner" "PASS" "exit=0; applied=$applied2/$total2"
  else
    record "D2b/2b applies it" "migrate deploy succeeds as the non-superuser owner" "FAIL" "exit=$m2 applied=$applied2/$total2 dummy=$dummy_row"
  fi

  # ---- D3: the role migration GENUINELY pending, same owner -----------------
  # Build it honestly: apply the first 32 migrations as the admin from a copy of
  # the chain that stops before 202607050001, then restore the full chain so the
  # privileged migrations are pending for real (recorded nowhere in
  # _prisma_migrations).
  prepare_dschema
  local kept=0 removed=0 d
  for d in "$DROOT"/prisma/migrations/*/; do
    local n; n="$(basename "$d")"
    if [[ "$n" > "$ROLE_MIGRATION_NAME" || "$n" == "$ROLE_MIGRATION_NAME" ]]; then
      rm -rf "$d"; removed=$((removed + 1))
    else kept=$((kept + 1)); fi
  done
  say "  D3 fixture: chain truncated to the $kept migrations before $ROLE_MIGRATION_NAME ($removed held back)"
  local m3; m3="$(d_migrate "$dpart_admin" "$WORK/d3-migrate.log")"
  local applied3; applied3="$(psql "$(stripq "$dpart_admin")" -tAc "select count(*) from _prisma_migrations where finished_at is not null" 2>/dev/null || echo 0)"
  local tables3; tables3="$(psql "$(stripq "$dpart_admin")" -tAc "select count(*) from information_schema.tables where table_schema='public'" 2>/dev/null || echo 0)"
  say "  D3 admin applied the truncated chain: exit=$m3 applied=$applied3 tables=$tables3"
  if [ "$applied3" != "$kept" ]; then
    record "D3 fixture" "partial chain applied by the admin" "FAIL" "exit=$m3 applied=$applied3 expected=$kept"
    return
  fi
  d_grant "$D_PART_DB" "$D_ROLE"
  # restore the FULL chain into the same throwaway copy -> 202607050001 is now
  # genuinely pending
  rm -rf "$DROOT/prisma/migrations"
  cp -a "$API/prisma/migrations" "$DROOT/prisma/migrations"
  local pre3; pre3="$(d_preflight "$dpart_owner" "$WORK/d3-preflight.log")"
  local pend3; pend3="$(grep -ao 'pending=[0-9]*' "$WORK/d3-preflight.log" | tail -1)"
  local named3; named3="$(grep -ac "$ROLE_MIGRATION_NAME" "$WORK/d3-preflight.log")"
  local applied3b tables3b
  applied3b="$(psql "$(stripq "$dpart_admin")" -tAc "select count(*) from _prisma_migrations where finished_at is not null" 2>/dev/null || echo 0)"
  tables3b="$(psql "$(stripq "$dpart_admin")" -tAc "select count(*) from information_schema.tables where table_schema='public'" 2>/dev/null || echo 0)"
  say "  D3 preflight as $D_ROLE with $ROLE_MIGRATION_NAME genuinely pending:"
  say "     exit=$pre3  ${pend3:-pending=?}  names-the-migration=$([ "${named3:-0}" -ge 1 ] && echo yes || echo NO)"
  grep -aE 'FATAL|R1 |pending:|Pending:' "$WORK/d3-preflight.log" | head -5 | sed 's/^/      /' | tee -a "$WORK/run.log"
  if [ "$pre3" != 0 ] && [ "${named3:-0}" -ge 1 ] && [ "$applied3b" = "$applied3" ] && [ "$tables3b" = "$tables3" ]; then
    record "D3/2b role migration pending" "preflight still REFUSES EARLY" "PASS" "exit=$pre3; $pend3; nothing applied (tables=$tables3b)"
  else
    record "D3/2b role migration pending" "preflight still REFUSES EARLY" "FAIL" "exit=$pre3 ${pend3:-?} applied=$applied3b tables=$tables3b (was $applied3/$tables3)"
  fi

  # ---- D4: negative control — the same database, the admin owner ------------
  local pre4; pre4="$(d_preflight "$dpart_admin" "$WORK/d4-preflight.log")"
  say "  D4 preflight as the SUPERUSER admin on the same partially applied db: exit=$pre4"
  if [ "$pre4" = 0 ]; then
    record "D4 admin control" "preflight PASSES for a superuser on the same database" "PASS" "exit=0"
  else
    record "D4 admin control" "preflight PASSES for a superuser on the same database" "FAIL" "exit=$pre4"
  fi

  # ---- D5: the pass is pending-awareness, not a loosened condition ----------
  # An owner that satisfies NEITHER R1 NOR R2 (NOSUPERUSER NOBYPASSRLS
  # NOCREATEROLE) still passes a fully applied database, and is still refused the
  # moment a privileged migration is pending.
  prepare_dschema
  local m5; m5="$(d_migrate "$(swapdb "$ADMIN_URL" "$D_WEAK_DB")" "$WORK/d5-migrate.log")"
  d_grant "$D_WEAK_DB" "$D_WEAK_ROLE"
  local pre5; pre5="$(d_preflight "$dweak" "$WORK/d5-preflight.log")"
  local pend5; pend5="$(grep -ao 'pending=[0-9]*' "$WORK/d5-preflight.log" | tail -1)"
  say "  D5 admin applied the chain into $D_WEAK_DB (exit=$m5); preflight as $D_WEAK_ROLE: exit=$pre5 ${pend5:-pending=?}"
  if [ "$m5" = 0 ] && [ "$pre5" = 0 ] && [ "$pend5" = "pending=0" ]; then
    record "D5/weakest owner redeploy" "preflight PASSES although R1 and R2 are both unsatisfiable" "PASS" "exit=0; $pend5"
  else
    record "D5/weakest owner redeploy" "preflight PASSES although R1 and R2 are both unsatisfiable" "FAIL" "migrate=$m5 preflight=$pre5 ${pend5:-?}"
  fi
  # and the same weakest owner is refused when the chain has not run yet
  psql_admin >/dev/null 2>&1 -c "DROP DATABASE IF EXISTS ${D_WEAK_DB}_fresh"
  psql_admin > "$WORK/d5fresh.db.log" 2>&1 -c "CREATE DATABASE ${D_WEAK_DB}_fresh OWNER $D_WEAK_ROLE"
  if [ -f "$WORK/d5fresh.db.log" ] && [ ! -s "$WORK/d5fresh.db.log" ]; then
    local weak_fresh="postgresql://${D_WEAK_ROLE}:${dwpw}@${PGHOST}:${PGPORT}/${D_WEAK_DB}_fresh?schema=public"
    local pre6; pre6="$(d_preflight "$weak_fresh" "$WORK/d5b-preflight.log")"
    local tbl6; tbl6="$(psql "$(stripq "$(swapdb "$ADMIN_URL" "${D_WEAK_DB}_fresh")")" -tAc "select count(*) from information_schema.tables where table_schema='public'" 2>/dev/null || echo '?')"
    say "  D5b same weakest owner, EMPTY database: preflight exit=$pre6 tables=$tbl6 (must refuse before any DDL)"
    if [ "$pre6" != 0 ] && [ "$tbl6" = 0 ]; then
      record "D5b/weakest owner fresh db" "preflight REFUSES EARLY when the chain is pending" "PASS" "exit=$pre6; 0 tables"
    else
      record "D5b/weakest owner fresh db" "preflight REFUSES EARLY when the chain is pending" "FAIL" "exit=$pre6 tables=$tbl6"
    fi
    psql_admin >/dev/null 2>&1 -c "DROP DATABASE IF EXISTS ${D_WEAK_DB}_fresh"
  else
    record "D5b/weakest owner fresh db" "preflight REFUSES EARLY when the chain is pending" "BLOCKED" "could not create the fresh database"
  fi

  rm -rf "$DROOT"
  say "  D series: the delivered tree was never modified (all fixtures lived in $DROOT)"
}

# the role migration's directory name, for the D3 truncation comparison
ROLE_MIGRATION_NAME="202607050001_flexora_app_role_force_rls"
run_dseries

# ---------------------------------------------------------------------------
# 4. matrix + verdict
# ---------------------------------------------------------------------------
hr; say "MATRIX"
printf '%-26s %-50s %-9s %s\n' "PROFILE" "CHECK" "RESULT" "DETAIL" | tee -a "$WORK/run.log"
while IFS=$'\t' read -r prof chk res det; do
  printf '%-26s %-50s %-9s %s\n' "$prof" "$chk" "$res" "${det:0:74}" | tee -a "$WORK/run.log"
done < "$WORK/matrix.tsv"

passes=$(awk -F'\t' '$3=="PASS"' "$WORK/matrix.tsv" | wc -l | tr -d ' ')
fails=$(awk -F'\t' '$3=="FAIL"' "$WORK/matrix.tsv" | wc -l | tr -d ' ')
blocked=$(awk -F'\t' '$3=="BLOCKED" || $3=="NOT RUN"' "$WORK/matrix.tsv" | wc -l | tr -d ' ')
hr
say "PASS=$passes FAIL=$fails BLOCKED/NOT-RUN=$blocked   (logs: $WORK)"
say "A FAIL against a profile that is expected to be refused is a real failure: the"
say "preflight must refuse it EARLY, before any DDL, and leave the database empty."

# ---------------------------------------------------------------------------
# 5. cleanup
# ---------------------------------------------------------------------------
[ -n "$LIC_PID" ] && kill "$LIC_PID" 2>/dev/null
pkill -f 'license-server/[s]erver.ts' 2>/dev/null
for id in "${PROFILE_IDS[@]}"; do
  safe="${id//[^a-zA-Z0-9]/_}"
  psql_admin >/dev/null 2>&1 -c "DROP DATABASE IF EXISTS flexora_c_${safe}"
  psql_admin >/dev/null 2>&1 -c "DROP ROLE IF EXISTS flexora_c_${safe}"
done
# PHASE Q1 D series fixtures
for d in "$D_DB" "$D_PART_DB" "$D_WEAK_DB" "${D_WEAK_DB}_fresh"; do
  psql_admin >/dev/null 2>&1 -c "DROP DATABASE IF EXISTS $d"
done
for r in "$D_ROLE" "$D_WEAK_ROLE"; do
  psql_admin >/dev/null 2>&1 -c "DROP ROLE IF EXISTS $r"
done
rm -rf "$DROOT"
if [ "$KEEP" = 1 ]; then say "kept $WORK (0600 fixtures inside a 0700 directory)"
else rm -rf "$WORK"; say "removed $WORK including every generated credential"; fi
say "P1_DB_COMPAT_DONE PASS=$passes FAIL=$fails BLOCKED=$blocked"
[ "$fails" = 0 ]
