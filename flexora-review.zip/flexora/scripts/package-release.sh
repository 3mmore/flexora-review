#!/usr/bin/env bash
# FLEXORA — build the lean, source-only delivery zip.
#
# Reproducible packaging so build artifacts, developer scripts and credentials
# can never leak into a delivery again (apps/web/tsconfig.tsbuildinfo and
# apps/api/.env both escaped earlier zips because the exclude list was written
# ad-hoc on the command line).
#
# Usage:
#   bash scripts/package-release.sh [output.zip]     # build + verify
#   bash scripts/package-release.sh --check-only X.zip   # verify an existing zip
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PARENT_DIR="$(dirname "$PROJECT_DIR")"
BASE="$(basename "$PROJECT_DIR")"

# ---------------------------------------------------------------------------
# Files that must never appear in a delivery, by exact name (PHASE L1).
# These used to sit at the project root; they are either deleted or moved into
# dev-tools/. Naming them here means the check still fires if one is re-added.
# ---------------------------------------------------------------------------
BANNED_NAMES=(
  mknb.js
  mk-nobranch.js
  reproduce_500s.js
  reproduce_500s.ts
  ensure-attendance-fixtures.js
  clean_ar.py
  clean_en.py
  clean_final.py
)

leak_check() {
  local ZIP="$1"
  local TMP
  TMP="$(mktemp -d)"
  trap 'rm -rf "$TMP"' RETURN

  unzip -q "$ZIP" -d "$TMP" || { echo "ERROR: cannot read $ZIP" >&2; return 1; }

  local leaks=0
  local found

  echo "── leak check ─────────────────────────────────────────────────────"

  # 1. build artifacts -------------------------------------------------------
  found="$(find "$TMP" \( -type d -o -type f \) -path '*/node_modules' -o -type d -name '.next' -o -type d -name 'dist' -o -type d -name 'build' -o -type d -name 'coverage' -o -type d -name '.turbo' -o -type d -name '.git' 2>/dev/null | sed "s|$TMP/||" | head -5 || true)"
  if [ -n "$found" ]; then
    echo "FAIL build artifacts:"; echo "$found"; leaks=$((leaks+1))
  else
    echo "ok   no build artifacts"
  fi

  # 2. development scripts, by name -----------------------------------------
  local banned=0
  local n
  for n in "${BANNED_NAMES[@]}"; do
    found="$(find "$TMP" -type f -name "$n" 2>/dev/null | sed "s|$TMP/||" | head -3 || true)"
    if [ -n "$found" ]; then
      echo "FAIL dev script present: $n"; echo "$found"; leaks=$((leaks+1)); banned=1
    fi
  done
  # 3. the dev-tools folder itself ------------------------------------------
  found="$(find "$TMP" -type d -name 'dev-tools' 2>/dev/null | sed "s|$TMP/||" | head -3 || true)"
  if [ -n "$found" ]; then
    echo "FAIL dev-tools/ shipped:"; echo "$found"; leaks=$((leaks+1)); banned=1
  fi

  # 4. stray helper scripts at the project root ------------------------------
  found="$(find "$TMP/$BASE" -maxdepth 1 -type f \( -name '*.js' -o -name '*.py' -o -name '*.ts' -o -name '*.sh' -o -name '*.rb' \) 2>/dev/null | sed "s|$TMP/||" | head -5 || true)"
  if [ -n "$found" ]; then
    echo "FAIL stray script(s) at project root:"; echo "$found"; leaks=$((leaks+1)); banned=1
  fi

  # 4b. generated tool state (Next.js telemetry, editor/agent config) --------
  # A guard, not just an exclusion: the exclusion above can be defeated by a future edit or by a
  # new path shape, and this is what actually fails the build.
  found="$(find "$TMP" -type d -name '.config' 2>/dev/null | sed "s|$TMP/||" | head -3 || true)"
  if [ -n "$found" ]; then
    echo "FAIL generated .config/ shipped (Next.js telemetry state):"; echo "$found"; leaks=$((leaks+1)); banned=1
  fi
  found="$(find "$TMP" -type f -path '*nextjs-nodejs*' 2>/dev/null | sed "s|$TMP/||" | head -3 || true)"
  if [ -n "$found" ]; then
    echo "FAIL Next.js telemetry state shipped:"; echo "$found"; leaks=$((leaks+1)); banned=1
  fi
  found="$(find "$TMP" -type f \( -name '*.pyc' -o -name '*.pyo' \) 2>/dev/null | sed "s|$TMP/||" | head -3 || true)"
  if [ -n "$found" ]; then
    echo "FAIL python bytecode shipped:"; echo "$found"; leaks=$((leaks+1)); banned=1
  fi

  # Generated certificates, keys and ACME state are never deliverables.
  if [ -d "$TMP/$BASE/certbot/conf" ] || [ -d "$TMP/$BASE/certbot/www" ]; then
    echo "FAIL generated certbot state shipped"; leaks=$((leaks+1)); banned=1
  fi

  # 5. .env files (only .env.example may ship) -------------------------------
  found="$(find "$TMP" -type f -name '.env' -o -type f -name '.env.*' 2>/dev/null | grep -v '\.env\.example$' | sed "s|$TMP/||" | head -10 || true)"
  if [ -n "$found" ]; then
    echo "FAIL .env file(s) shipped:"; echo "$found"; leaks=$((leaks+1)); banned=1
  fi

  [ "$banned" -eq 0 ] && echo "ok   no banned files" || true

  # 6. credential-looking strings in file CONTENTS ---------------------------
  #
  # PHASE M3.1: the rules live in scripts/check-secrets.sh and are shared with
  # `npm run check:secrets`. One implementation, two callers, so what a
  # developer runs locally can never drift from what gates a delivery.
  # PHASE P5 — the archive credential gate lives in its own script so that
  # package-release.sh and scripts/check-archive-scan-selftest.sh run the SAME
  # code. It scans the WRAPPED project root (not the extraction root, which
  # holds only the wrapper folder), prints how many files it read, and fails
  # when that count is 0 or below 90% of the scannable files — so a green
  # result always means something was actually scanned.
  if ! bash "$PROJECT_DIR/scripts/check-archive-scan.sh" "$ZIP" "delivery archive"; then
    leaks=$((leaks+1))
  fi

  # 6b. PHASE O1.2 — compose/environment guard, run against the EXTRACTED
  #     archive (not the working tree), so what ships is what was checked.
  #     The archive contains scripts/ and apps/*/src, so it is self-contained.
  #     The guard prints variable NAMES and interpolation kinds only — never a
  #     secret value (same rule as check-secrets.sh).
  if command -v python3 >/dev/null 2>&1; then
    if python3 "$PROJECT_DIR/scripts/check-compose-env.py" --repo "$TMP/$BASE" --quiet; then
      echo "ok   compose passes every variable the app reads (guard, extracted archive)"
    else
      echo "FAIL compose/env guard on the extracted archive (see findings above)"
      leaks=$((leaks+1))
    fi
    if ! python3 "$PROJECT_DIR/scripts/check-compose-env.py" --self-test >/dev/null 2>&1; then
      echo "FAIL compose/env guard self-test (the guard itself is broken)"
      leaks=$((leaks+1))
    fi
  else
    echo "FAIL python3 is required to run scripts/check-compose-env.py"
    leaks=$((leaks+1))
  fi

  echo "────────────────────────────────────────────────────────────────────"
  if [ "$leaks" -ne 0 ]; then
    echo "LEAK CHECK FAILED — $leaks problem(s). Archive NOT clean: $ZIP" >&2
    return 1
  fi
  echo "PASS leak check — archive is clean."
  return 0
}

# Standalone verification mode (used to re-check an existing delivery).
if [ "${1:-}" = "--check-only" ]; then
  ZIP="${2:?usage: package-release.sh --check-only <archive.zip>}"
  case "$ZIP" in /*) ;; *) ZIP="$PWD/$ZIP" ;; esac
  leak_check "$ZIP"
  exit $?
fi

OUT="${1:-flexora-release.zip}"
case "$OUT" in
  /*) ABS_OUT="$OUT" ;;
  *)  ABS_OUT="$PWD/$OUT" ;;
esac

# ---------------------------------------------------------------------------
# npm audit gate (owner instruction, 2026-11-08).
#
# Runs BEFORE the archive is built on purpose: a gate that runs afterwards still produces the
# artifact it was supposed to block, and then someone has to remember to delete it.
#
# Scope is --omit=dev as requested. This does NOT establish that dev dependencies are absent
# from deployed images: the API Dockerfiles currently install dev dependencies and copy their
# node_modules into the runtime image to support the migration and bootstrap tooling. A separate
# full audit and image review are necessary to assess those packages. Each app has its OWN
# package-lock.json and its Docker build installs from it, so audit each lock separately.
#
# Exit codes are distinguished rather than collapsed: npm audit exits 1 for "vulnerabilities at or
# above the threshold" and something else for "I could not run" (no network, no lockfile, a
# registry error). Treating the second as a pass would let a release ship unaudited whenever the
# network was down, which is the failure mode a gate exists to prevent. So an audit that could not
# run FAILS the gate and says so.
# ---------------------------------------------------------------------------
# Block HIGH and CRITICAL production advisories by default. A failed or missing audit fails closed.
AUDIT_LEVEL="${FLEXORA_AUDIT_LEVEL:-high}"
# Allow a stricter threshold, never one that silently permits high findings.
case "$AUDIT_LEVEL" in
  low|moderate|high) ;;
  *) echo "FAIL invalid or weaker npm audit threshold: $AUDIT_LEVEL" >&2; exit 1 ;;
esac
audit_gate() {
  local rc out dir fail=0 ran=0
  echo ""
  echo "── npm audit gate (--omit=dev, level $AUDIT_LEVEL) ────────────────"
  for dir in . apps/api apps/web license-server; do
    [ -f "$PROJECT_DIR/$dir/package-lock.json" ] && [ -f "$PROJECT_DIR/$dir/package.json" ] || { echo "FAIL $dir: missing manifest or lockfile"; fail=$((fail+1)); continue; }
    ran=$((ran+1))
    # Audited in an ISOLATED copy of just that app's package.json + package-lock.json. This is
    # not ceremony: apps/api, apps/web and license-server are members of the root npm workspace,
    # and `npm audit` run inside a workspace member walks UP and audits the ROOT lockfile
    # instead. Measured on 2026-11-08: apps/api audited in place reported 8 findings and still
    # flagged @nestjs/swagger; the same lockfile audited in isolation reported 7 and did not,
    # because the app's own lockfile had already been fixed to 11.4.8. A gate that audits the
    # wrong lockfile four times is worse than no gate - it reports a number nobody can act on.
    # Isolation also matches reality: each Dockerfile runs `npm ci` in the app context, so the
    # app lockfile is what actually gets installed into the image.
    local iso
    iso="$(mktemp -d)"
    cp "$PROJECT_DIR/$dir/package.json" "$PROJECT_DIR/$dir/package-lock.json" "$iso/" 2>/dev/null
    # Root lockfile contains workspace packages. Include their manifests in the isolated copy;
    # otherwise npm omits workspace vulnerabilities and a red root audit can appear green.
    if [ "$dir" = . ]; then
      for workspace in apps/api apps/web apps/mobile-member apps/mobile-staff; do
        if [ -f "$PROJECT_DIR/$workspace/package.json" ]; then
          mkdir -p "$iso/$workspace"
          cp "$PROJECT_DIR/$workspace/package.json" "$iso/$workspace/package.json"
        fi
      done
    fi
    set +e
    out="$(cd "$iso" && npm audit --omit=dev --audit-level="$AUDIT_LEVEL" 2>&1)"
    rc=$?
    set -e
    rm -rf "$iso"
    case "$rc" in
      0) echo "ok   $dir: no $AUDIT_LEVEL+ production vulnerabilities" ;;
      1) echo "FAIL $dir: production vulnerabilities at or above $AUDIT_LEVEL"
         printf '%s\n' "$out" | grep -E "^[a-z@].*$|Severity|fix available|no fix available|# npm audit report" | head -20 | sed 's/^/       /'
         printf '%s\n' "$out" | tail -3 | sed 's/^/       /'
         fail=$((fail+1)) ;;
      *) echo "FAIL $dir: npm audit COULD NOT RUN (exit $rc) - a release must not ship unaudited"
         printf '%s\n' "$out" | tail -4 | sed 's/^/       /'
         fail=$((fail+1)) ;;
    esac
  done
  [ "$ran" = 0 ] && { echo "FAIL no lockfile was found to audit"; return 1; }
  [ "$fail" = 0 ] || return 1
  return 0
}
if ! audit_gate; then
  echo ""
  echo "ABORT: the npm audit gate failed, so no archive was built."
  echo "  Fix the findings, or if one has no available fix, record the decision and its expiry in"
  echo "  docs/ADMIN_CONSOLE.md and lower the gate for that workspace deliberately - not silently."
  exit 1
fi

# Each Node app must install and compile from its own lockfile, before packaging.
bash "$PROJECT_DIR/scripts/check-isolated-builds.sh" || { echo "ABORT: isolated build gate failed" >&2; exit 1; }

rm -f "$ABS_OUT"

# ---------------------------------------------------------------------------
# Build the file list explicitly (instead of `zip -r`), so the exclusions are
# reviewable and a stray file cannot be picked up just because it is new.
# ---------------------------------------------------------------------------
cd "$PARENT_DIR"
LIST="$(mktemp)"
trap 'rm -f "$LIST"' EXIT

# Everything except the paths below. `.env.example` files are filtered out by
# the .env rule and then added back — they are templates, not secrets.
#
# `.config/` is excluded because it is generated tool state, not source: the only file under it is
# .config/nextjs-nodejs/config.json, which Next.js writes to record that it showed you its
# telemetry notice, carrying a machine-specific `anonymousId` and `salt`. It is per-developer
# state that means nothing on another machine, it is not read by the build, and shipping a stable
# anonymous identifier in a delivery is exactly the sort of thing a recipient should not have to
# discover by unpacking. Found in the 2026-11-08 local-run archive on the owner's review.
#
# Python bytecode caches are excluded because they are GENERATED, and they are generated by
# running the guards themselves - so a packaging run that first invoked check-secrets.sh could
# carry scripts/__pycache__/check-secrets.cpython-313.pyc into the delivery. Observed for real on
# 2026-11-08: it was the single entry that made one build 777 files and the next 776, i.e. the
# archive was not reproducible from the same tree. A delivery that changes depending on whether
# you happened to run a guard first is a delivery nobody can verify by hash.
#
# `load-test/` is excluded on the owner's instruction for the local-run archive (2026-11-08):
# it is not needed to run the product, it requires k6 which is not a dependency, and three of
# its six files were CI output artifacts (k6-run-output.txt and friends) - generated logs, which
# a delivery must never carry. Consequence, stated rather than hidden: the root package.json's
# `load-test`, `load-test:capacity` and `load-test:tenant` scripts point at files that are not in
# this archive, so they fail if invoked. They already required a k6 install, so nothing that ever
# worked out of the box stops working. Put the directory back if a delivery needs load testing.
find "$BASE" -type f \
  | grep -Ev '(^|/)(node_modules|\.next|dist|build|out|coverage|\.turbo|\.cache|\.git|\.uploads|dev-tools|__pycache__|\.pytest_cache|\.mypy_cache|\.ruff_cache|\.config)(/|$)' \
  | grep -Ev '\.(tsbuildinfo|log|zip|tar|tgz|tar\.gz|dump|sql\.gz|DS_Store|pem|key|p12|pfx|pyc|pyo)$' \
  | grep -Ev '(^|/)\.env(\.[A-Za-z0-9_-]+)?$' \
  | grep -Ev '(^|/)docker-compose\.(test|loadtest-override)\.yml$' \
  | grep -Ev '(^|/)\.github/' \
  | grep -Ev '(^|/)licenses\.json$' \
  | grep -Ev '(^|/)load-test/' \
  | grep -Ev '(^|/)certbot/(conf|www)/' \
  > "$LIST"

# .env.example templates are meant to ship.
find "$BASE" -type f -name '.env.example' >> "$LIST"

sort -u "$LIST" -o "$LIST"
zip -q -@ "$ABS_OUT" < "$LIST"

echo "Created: $ABS_OUT"
echo "Size:    $(du -h "$ABS_OUT" | cut -f1)"
echo "Files:   $(unzip -l "$ABS_OUT" | tail -1 | awk '{print $2}')"

leak_check "$ABS_OUT"
