#!/bin/bash
set -e

echo "=== Building test images ==="
docker build -f Dockerfile.api -t test-api .
docker build -f Dockerfile.web -t test-web .

echo "=== Verifying API runtime image ==="
docker run --rm test-api ls /app

echo "=== Verifying WEB runtime image ==="
docker run --rm test-web ls /app

echo "✅ Dockerfiles verified successfully"
