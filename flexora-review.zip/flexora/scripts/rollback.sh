#!/bin/bash
PREVIOUS=${1:-""}

if [ -z "$PREVIOUS" ]; then
  echo "Usage: ./rollback.sh <previous-version>"
  exit 1
fi

echo "⏪ Rolling back to $PREVIOUS..."
docker pull flexora-api:$PREVIOUS
docker-compose stop api
docker tag flexora-api:$PREVIOUS \
  flexora-api:current
docker-compose up -d api
echo "✅ Rollback complete"
