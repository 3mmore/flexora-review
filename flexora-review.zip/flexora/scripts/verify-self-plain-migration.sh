#!/usr/bin/env bash
# PACK 2 item 5 — re-runnable proof for 20261117090000_pack2_self_plain_source.
#
# WHAT IT PROVES
#   1. the forward migration, its down.sql, and a second forward pass leave EVERY
#      EXISTING ROW byte-identical (digest of id||source, plus relfilenode/size);
#   2. a rollback is REFUSED (and leaves nothing behind) when a row already uses
#      SELF_PLAIN — the migration fails loudly instead of rewriting data;
#   3. after the cycle the allowlist accepts SELF_PLAIN and refuses a bogus value.
#
# HOW IT STAYS SAFE
#   It never touches public."Attendance" of the database named in PGURL. It builds an exact COPY in a scratch
#   schema `migproof` — same columns, same 6-value CHECK under the SAME constraint
#   name the previous migration used — fills it with a copy of the real rows, and
#   runs the real migration files there with search_path pointed at the copy. The
#   scratch schema is dropped at the end, on success or failure.
#
#   That isolation matters: the live database may already contain SELF_PLAIN rows
#   written by the smoke run, and a rollback legitimately refuses in that state.
#   The refusal is a property to PROVE, not an obstacle to work around by deleting
#   real rows.
#
#   PGURL=postgresql://postgres:password@host:5432/dbname bash scripts/verify-self-plain-migration.sh
set -euo pipefail
export PATH=/usr/lib/postgresql/16/bin:$PATH
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -d "$HERE/../apps/api/prisma/migrations" ]; then ROOT="$(cd "$HERE/.." && pwd)"
elif [ -d "$HERE/../flexora/apps/api/prisma/migrations" ]; then ROOT="$(cd "$HERE/../flexora" && pwd)"
else echo "cannot locate the repo from $HERE" >&2; exit 2; fi
# The connection string is REQUIRED and is never defaulted to a real
# credential: a script that ships a password is a script that leaks one.
PGURL="${PGURL:?set PGURL=postgresql://postgres:password@host:5432/dbname (an OWNER role, never the runtime role)}"
PSQL=(psql "$PGURL")
M="$ROOT/apps/api/prisma/migrations/20261117090000_pack2_self_plain_source"

cleanup() {
  for sch in migproof_hist migproof_cur; do
    "${PSQL[@]}" -q -c "drop schema if exists $sch cascade" >/dev/null 2>&1 || true
  done
}
trap cleanup EXIT
build_copy() {  # $1 = schema suffix, $2 = where clause over source
  local SCH="migproof$1"
  "${PSQL[@]}" -q -v ON_ERROR_STOP=1 \
    -c "drop schema if exists $SCH cascade" \
    -c "create schema $SCH" \
    -c "create table $SCH.\"Attendance\" (like public.\"Attendance\" including all)" \
    -c "insert into $SCH.\"Attendance\" select * from public.\"Attendance\" where $2"
  "${PSQL[@]}" -q -Atc "select conname from pg_constraint where conrelid=to_regclass('$SCH.\"Attendance\"') and contype='c'" \
  | while read -r cname; do
      [ -n "$cname" ] && "${PSQL[@]}" -q -c "alter table $SCH.\"Attendance\" drop constraint \"$cname\""
    done
  "${PSQL[@]}" -q -v ON_ERROR_STOP=1 \
    -c "alter table $SCH.\"Attendance\" add constraint \"Attendance_source_check\" check (\"source\" is null or \"source\" = any (array['SELF_QR','SELF_IP','SELF_GEO','SELF_IP_GEO','STAFF','KIOSK'])) not valid"
}

# -q suppresses the "SET" command tag that -c would otherwise print and that
# would corrupt every value this script compares
q()  { "${PSQL[@]}" -Atq -c "set search_path=$S; $1"; }
rows()   { q "select count(*) from \"Attendance\""; }
digest() { q "select md5(string_agg(id||coalesce(source,'~'), ',' order by id)) from \"Attendance\""; }
shape()  { q "select relfilenode||'/'||pg_relation_size('\"Attendance\"') from pg_class where relname='Attendance' and relnamespace='$S'::regnamespace"; }
cons()   { q "select string_agg(conname||':'||convalidated, ' ' order by conname) from pg_constraint where conrelid=to_regclass('$S.\"Attendance\"') and contype='c'"; }

S=migproof_hist
q()  { "${PSQL[@]}" -Atq -c "set search_path=$S; $1"; }
rows()   { q "select count(*) from \"Attendance\""; }
digest() { q "select md5(string_agg(id||coalesce(source,'~'), ',' order by id)) from \"Attendance\""; }
shape()  { q "select relfilenode||'/'||pg_relation_size('\"Attendance\"') from pg_class where relname='Attendance' and relnamespace='$S'::regnamespace"; }
cons()   { q "select string_agg(conname||':'||convalidated, ' ' order by conname) from pg_constraint where conrelid=to_regclass('$S.\"Attendance\"') and contype='c'"; }

echo "== A. the FULL cycle on the rows a pre-migration table could hold"
echo "   (every row whose source is NULL or one of the six 16130000 values)"
build_copy _hist "\"source\" is null or \"source\" in ('SELF_QR','SELF_IP','SELF_GEO','SELF_IP_GEO','STAFF','KIOSK')"
N=$(rows)
if [ "$N" -eq 0 ]; then
  echo "REFUSING: no historical rows exist, so 'existing rows unchanged' proves nothing." >&2
  exit 2
fi
BASE_D=$(digest); BASE_S=$(shape)
echo "rows=$N digest=$BASE_D shape=$BASE_S"
echo "constraints: $(cons)"

echo
echo "== A1 forward"
"${PSQL[@]}" -1 -q -v ON_ERROR_STOP=1 -c "set search_path=$S" -f "$M/migration.sql"
echo "after apply: rows=$(rows) digest=$(digest) shape=$(shape)"; echo "constraints: $(cons)"
[ "$(digest)" = "$BASE_D" ] || { echo "FAILED: rows changed by the forward migration" >&2; exit 1; }

echo
echo "== A2 reverse"
"${PSQL[@]}" -1 -q -v ON_ERROR_STOP=1 -c "set search_path=$S" -f "$M/down.sql"
echo "after down:  rows=$(rows) digest=$(digest) shape=$(shape)"; echo "constraints: $(cons)"
[ "$(digest)" = "$BASE_D" ] || { echo "FAILED: rows changed by the rollback" >&2; exit 1; }

echo
echo "== A3 forward again"
"${PSQL[@]}" -1 -q -v ON_ERROR_STOP=1 -c "set search_path=$S" -f "$M/migration.sql"
echo "after again: rows=$(rows) digest=$(digest) shape=$(shape)"; echo "constraints: $(cons)"
[ "$(digest)" = "$BASE_D" ] || { echo "FAILED: rows changed by the second apply" >&2; exit 1; }

echo
echo "== A4 behaves: SELF_PLAIN accepted, a bogus value refused"
q "insert into \"Attendance\" (id,\"gymId\",\"memberId\",\"branchId\",at,method,source)
   select 'ok1',\"gymId\",\"memberId\",\"branchId\",now(),'QR','SELF_PLAIN' from \"Attendance\" limit 1" >/dev/null && echo "SELF_PLAIN: accepted"
if q "insert into \"Attendance\" (id,\"gymId\",\"memberId\",\"branchId\",at,method,source)
      select 'bad1',\"gymId\",\"memberId\",\"branchId\",now(),'QR','BOGUS' from \"Attendance\" limit 1" 2>/tmp/bogus.log; then
  echo "FAILED: a bogus source was accepted" >&2; exit 1
fi
echo "BOGUS: refused"

echo
echo "== B. on the CURRENT rows (SELF_PLAIN in use), a rollback must be refused and change nothing"
S=migproof_cur
build_copy _cur "true"
N2=$(rows); C_D=$(digest)
echo "rows=$N2"
"${PSQL[@]}" -1 -q -v ON_ERROR_STOP=1 -c "set search_path=$S" -f "$M/migration.sql"
echo "forward ok: digest unchanged? $([ "$(digest)" = "$C_D" ] && echo yes || echo NO)"
[ "$(digest)" = "$C_D" ] || { echo "FAILED: the forward migration changed current rows" >&2; exit 1; }
BEFORE=$(cons)
if "${PSQL[@]}" -1 -q -v ON_ERROR_STOP=1 -c "set search_path=$S" -f "$M/down.sql" 2>/tmp/down-refused.log; then
  echo "FAILED: the rollback succeeded while rows use SELF_PLAIN" >&2; exit 1
fi
echo "rollback refused: $(grep -oE 'check constraint \"[^\"]+\" of relation \"[^\"]+\" is violated' /tmp/down-refused.log | head -1)"
[ "$(cons)" = "$BEFORE" ] && echo "no half-added constraint left behind" || { echo "FAILED: a stray constraint remains" >&2; exit 1; }
[ "$(digest)" = "$C_D" ] || { echo "FAILED: the refused rollback still changed rows" >&2; exit 1; }

echo
echo "PASS: $N historical rows identical through apply → rollback → re-apply;"
echo "      $N2 current rows unchanged by the forward pass, and the rollback is refused while SELF_PLAIN is in use"
