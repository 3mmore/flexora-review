#!/usr/bin/env bash
# PHASE P5 — self-test for the delivery-archive credential gate.
#
# A gate that scans nothing prints green, so the gate itself has to be tested:
#
#   T1  a clean wrapped archive                      -> the gate PASSES
#   T2  the SAME archive with a fake credential file
#       planted inside a COPY of the extracted tree  -> the gate FAILS
#   T3  the same planted archive, but with the wrapper
#       folder removed (an unwrapped archive)        -> the gate still FAILS,
#       i.e. the coverage check does not depend on the wrapping
#   T4  an EMPTY archive (0 files)                   -> the gate FAILS
#
# The planted value is a fake, generated here, and is printed masked by the
# scanner — no real credential exists anywhere in this test.
set -uo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GATE="$HERE/check-archive-scan.sh"
W="$(mktemp -d)"
trap 'rm -rf "$W"' EXIT
BASE=flexora
pass=0; fail=0

build_tree() { # $1 = destination root
  local root="$1"
  mkdir -p "$root/$BASE/apps/api/src" "$root/$BASE/scripts" "$root/$BASE/docs"
  cp "$HERE/secrets-exemptions.txt" "$root/$BASE/scripts/" 2>/dev/null || :
  printf '{"name":"p5-selftest","version":"0.0.0"}\n' > "$root/$BASE/package.json"
  printf 'export const answer = 42;\n' > "$root/$BASE/apps/api/src/index.ts"
  printf '# P5 self-test fixture\n\nNo credentials here.\n' > "$root/$BASE/docs/README.md"
  printf 'DATABASE_URL=postgresql://USER:PLACEHOLDER@localhost:5432/db\n' > "$root/$BASE/.env.example"
}

plant_credential() { # $1 = extracted tree root
  # a fake, freshly generated value in a file that MUST be reported
  printf 'export const apiKey = "%s";\n' "sk-live-$(openssl rand -hex 12)" \
    > "$1/$BASE/apps/api/src/planted-credential.ts"
}

expect() { # $1 label, $2 expected rc, $3 actual rc
  if [ "$2" = "$3" ]; then echo "  PASS  $1 (exit $3)"; pass=$((pass+1));
  else echo "  FAIL  $1 — expected exit $2, got $3"; fail=$((fail+1)); fi
}

echo "── PHASE P5 archive-gate self-test ─────────────────────────"

# T1 clean
build_tree "$W/clean"
( cd "$W/clean" && zip -qr "$W/clean.zip" "$BASE" )
bash "$GATE" "$W/clean.zip" "self-test T1 clean archive" > "$W/t1.log" 2>&1
expect "T1 clean wrapped archive passes" 0 $?
grep -q 'files scanned: [1-9]' "$W/t1.log" && { echo "  PASS  T1 reported a non-zero scanned count"; pass=$((pass+1)); } \
  || { echo "  FAIL  T1 did not report a scanned count"; fail=$((fail+1)); }

# T2 planted credential inside a COPY of the extracted tree
rm -rf "$W/planted"; mkdir -p "$W/planted"
unzip -q "$W/clean.zip" -d "$W/planted"
plant_credential "$W/planted"
( cd "$W/planted" && zip -qr "$W/planted.zip" "$BASE" )
bash "$GATE" "$W/planted.zip" "self-test T2 planted archive" > "$W/t2.log" 2>&1
expect "T2 planted credential fails the gate" 1 $?
grep -q 'planted-credential.ts' "$W/t2.log" && { echo "  PASS  T2 names the planted file"; pass=$((pass+1)); } \
  || { echo "  FAIL  T2 did not name the planted file"; fail=$((fail+1)); }
# masking: the scanner prints the first 3 characters + *** — so the full fake
# value must NOT appear anywhere in the output, while a mask must.
if grep -q '\*\*\*' "$W/t2.log" && ! grep -qF "$(cat "$W/planted/$BASE/apps/api/src/planted-credential.ts" | sed -E 's/.*"(sk-live-[0-9a-f]+)".*/\1/')" "$W/t2.log"; then
  echo "  PASS  T2 value is masked, never echoed in full"; pass=$((pass+1))
else
  echo "  FAIL  T2 masking: the full planted value appeared, or no mask was printed"; fail=$((fail+1))
fi

# T3 the same planted archive without the wrapper folder
rm -rf "$W/flat"; mkdir -p "$W/flat"
unzip -q "$W/planted.zip" -d "$W/flat"
( cd "$W/flat/$BASE" && zip -qr "$W/flat.zip" . )
bash "$GATE" "$W/flat.zip" "self-test T3 unwrapped archive" > "$W/t3.log" 2>&1
expect "T3 unwrapped planted archive still fails" 1 $?

# T4 an empty archive
mkdir -p "$W/empty"; ( cd "$W/empty" && zip -qr "$W/empty.zip" . 2>/dev/null )
bash "$GATE" "$W/empty.zip" "self-test T4 empty archive" > "$W/t4.log" 2>&1
rc=$?
if [ "$rc" != 0 ]; then echo "  PASS  T4 empty/unlocatable archive fails (exit $rc)"; pass=$((pass+1));
else echo "  FAIL  T4 empty archive passed — the gate would scan nothing"; fail=$((fail+1)); fi

# T5 the diagnostic mode (--no-exemptions) must still fail on the planted archive
bash "$GATE" "$W/planted.zip" "self-test T5 no-exemptions" --no-exemptions > "$W/t5.log" 2>&1
expect "T5 --no-exemptions also fails on the planted archive" 1 $?
grep -q 'exemptions: DISABLED' "$W/t5.log" && { echo "  PASS  T5 reports that exemptions were disabled"; pass=$((pass+1)); } \
  || { echo "  FAIL  T5 did not report the exemption mode"; fail=$((fail+1)); }

echo "  SELF-TEST: $pass passed, $fail failed"
[ "$fail" = 0 ]
