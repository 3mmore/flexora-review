#!/usr/bin/env python3
"""
PHASE O4.4 — every nginx location that proxies must forward the client's address.

WHY
---
The API sits behind nginx and derives the client IP from X-Forwarded-For, with
`trust proxy` set to TRUST_PROXY_HOPS (default 1). The login, OTP and security
rate limiters key on that IP. A proxied location that forgets the header does not
fail loudly: the API simply sees nginx's own address, so every client shares one
bucket — one attacker's failed logins throttle the whole platform, and a spoofed
X-Forwarded-For becomes the only way to get a distinct key.

This check found two such locations in nginx/nginx.conf:
  location /socket.io/     forwarded Host and X-Real-IP only
  location /_next/static/  forwarded nothing at all
Both are fixed; this script is the regression test that fails without the fix.

WHICH FILE IT CHECKS
--------------------
By default it discovers the config from docker-compose.yml — the volume mounted at
/etc/nginx/conf.d/ — so it can never be satisfied by a stale duplicate. (The repo
carried nginx/flexora.conf, byte-identical and referenced by nothing; it has been
deleted. docker-compose.yml mounts ./nginx/nginx.conf.)

RULES
  H1  a location containing proxy_pass must set Host $host
  H2  ... must set X-Forwarded-For $proxy_add_x_forwarded_for
  H3  ... must set X-Forwarded-Proto $scheme
  H4  X-Forwarded-For must NOT be set to $remote_addr — that discards the upstream
      chain and makes TRUST_PROXY_HOPS meaningless
  H5  X-Forwarded-For must be set exactly once per location
  H6  (PHASE R0) Host may be the gate variable $flexora_gate_host ONLY if the config
      defines it correctly: `map $flexora_admin_host $flexora_gate_host` must yield
      `$host` for an admin hostname and a name under the RFC 6761 reserved `.invalid`
      TLD otherwise, and `map $host $flexora_admin_host` must default to 0 with no
      wildcard entry. Any other Host value is a finding. This is a tightening, not an
      exemption: nginx/nginx.conf's console location deliberately hands the api a
      hostname that can never be allow-listed, and this rule proves that is still true.

usage: scripts/check-nginx-proxy-headers.py [--repo DIR] [--config FILE]
                                            [--self-test] [--quiet]
exit:  0 clean · 1 findings · 2 usage/self-test failure
"""
from __future__ import annotations

import argparse
import os
import re
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)

REQUIRED = [
    ("H1", r"proxy_set_header\s+Host\s+(\$host|\$flexora_gate_host)\b",
     "Host $host (or the verified R0 gate variable $flexora_gate_host)"),
    ("H2", r"proxy_set_header\s+X-Forwarded-For\s+\$proxy_add_x_forwarded_for\b",
     "X-Forwarded-For $proxy_add_x_forwarded_for"),
    ("H3", r"proxy_set_header\s+X-Forwarded-Proto\s+\$scheme\b", "X-Forwarded-Proto $scheme"),
]


def discover_config(repo: str) -> tuple[str | None, str]:
    """The nginx config compose actually mounts, so a dead duplicate cannot pass."""
    import yaml
    compose = os.path.join(repo, "docker-compose.yml")
    if not os.path.exists(compose):
        return None, f"{compose} not found"
    data = yaml.safe_load(open(compose, encoding="utf8"))
    nginx = (data.get("services") or {}).get("nginx") or {}
    for vol in nginx.get("volumes") or []:
        vol = str(vol)
        if ":" not in vol:
            continue
        src, dst = vol.split(":")[0], vol.split(":")[1]
        if dst.startswith("/etc/nginx/conf.d") or dst.startswith("/etc/nginx/"):
            path = src if os.path.isabs(src) else os.path.join(repo, src)
            if os.path.exists(path):
                return path, f"mounted by docker-compose.yml at {dst}"
            return None, f"compose mounts {src} at {dst}, but that file does not exist"
    return None, "docker-compose.yml's nginx service mounts no config file"


def location_blocks(text: str) -> list[tuple[int, str, str]]:
    """(line number, location header, block body) for every location { ... }."""
    out = []
    for m in re.finditer(r"location\s+([^{};]*?)\s*\{", text):
        start = m.end() - 1
        depth = 0
        i = start
        while i < len(text):
            if text[i] == "{":
                depth += 1
            elif text[i] == "}":
                depth -= 1
                if depth == 0:
                    break
            i += 1
        body = text[start + 1:i]
        line = text.count("\n", 0, m.start()) + 1
        out.append((line, m.group(1).strip(), body))
    return out


GATE_VAR = "$flexora_gate_host"


def gate_host_findings(text: str, where: str) -> list[str]:
    """H6: prove the R0 gate variable is defined so that it can never widen access.

    nginx hands the api `$flexora_gate_host` instead of `$host` for console paths.
    That is only safe if the variable is the client's own hostname on an admin
    hostname, and a name under the reserved `.invalid` TLD everywhere else - a name
    ADMIN_HOSTS refuses to accept (apps/api/src/config/admin-hosts.ts rejects it at
    parse time), so the api's own gate produces the refusal.
    """
    out: list[str] = []
    gate = re.search(r"map\s+\$flexora_admin_host\s+\$flexora_gate_host\s*\{([^}]*)\}", text)
    if not gate:
        out.append(f"H6 {where}: Host uses {GATE_VAR} but the config defines no "
                   "`map $flexora_admin_host $flexora_gate_host`")
        return out
    gbody = gate.group(1)
    gdefault = re.search(r"default\s+([^;]+);", gbody)
    gadmin = re.search(r"^\s*1\s+([^;]+);", gbody, re.M)
    gval = gdefault.group(1).strip() if gdefault else ""
    if not gval.endswith(".invalid"):
        out.append(f"H6 {where}: {GATE_VAR}'s default must be a name under the reserved "
                   f"`.invalid` TLD so ADMIN_HOSTS can never accept it (found `{gval or 'none'}`)")
    if not gadmin or gadmin.group(1).strip() != "$host":
        out.append(f"H6 {where}: {GATE_VAR} must yield `$host` on an admin hostname, or the "
                   f"console breaks on its own hostname (found `{gadmin.group(1).strip() if gadmin else 'none'}`)")
    admin = re.search(r"map\s+\$host\s+\$flexora_admin_host\s*\{([^}]*)\}", text)
    if not admin:
        out.append(f"H6 {where}: {GATE_VAR} keys on $flexora_admin_host, which the config does "
                   "not define with `map $host $flexora_admin_host`")
    else:
        abody = admin.group(1)
        adefault = re.search(r"default\s+([^;]+);", abody)
        if not adefault or adefault.group(1).strip() != "0":
            out.append(f"H6 {where}: `map $host $flexora_admin_host` must default to 0 (fail "
                       f"closed); found `{adefault.group(1).strip() if adefault else 'none'}`")
        for bad in ("*", "*.*", "all", "any"):
            if re.search(r"^\s*" + re.escape(bad) + r"\s+1\s*;", abody, re.M):
                out.append(f"H6 {where}: `map $host $flexora_admin_host` treats `{bad}` as an "
                           "admin host - a wildcard makes the console public")
    return out


def check_text(text: str, label: str) -> list[str]:
    findings: list[str] = []
    for line, header, body in location_blocks(text):
        if "proxy_pass" not in body:
            continue
        where = f"{label}:{line} location {header or '/'}"
        for rule, pattern, want in REQUIRED:
            if not re.search(pattern, body):
                findings.append(f"{rule} {where}: missing `{want}`")
        for value in re.findall(r"proxy_set_header\s+Host\s+([^;}\s]+)", body):
            if value == "$host":
                continue
            if value == GATE_VAR:
                findings.extend(gate_host_findings(text, where))
                continue
            findings.append(
                f"H6 {where}: Host is set to `{value}`; the api derives the client's identity "
                "from Host, so it must be `$host` (or the verified R0 gate variable "
                f"{GATE_VAR})"
            )
        xff = re.findall(r"proxy_set_header\s+X-Forwarded-For\s+([^;}\s]+)", body)
        if len(xff) > 1:
            findings.append(f"H5 {where}: sets X-Forwarded-For {len(xff)} times (the last one wins silently)")
        for value in xff:
            if value.strip() == "$remote_addr":
                findings.append(
                    f"H4 {where}: X-Forwarded-For is set to $remote_addr, which discards the upstream "
                    "chain and makes TRUST_PROXY_HOPS meaningless — use $proxy_add_x_forwarded_for"
                )
    return findings


def self_test() -> int:
    passed = failed = 0

    def check(name: str, ok: bool) -> None:
        nonlocal passed, failed
        if ok:
            passed += 1
            print(f"    PASS  {name}")
        else:
            failed += 1
            print(f"    FAIL  {name}")

    tmp = tempfile.mkdtemp(prefix="nginx-hdr-selftest-")

    # the defect this check exists for: a proxied location without the headers
    bad = os.path.join(tmp, "bad.conf")
    open(bad, "w", encoding="utf8").write(
        "server {\n"
        "  location /api/ { proxy_pass http://api:4000; proxy_set_header Host $host;"
        " proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;"
        " proxy_set_header X-Forwarded-Proto $scheme; }\n"
        "  location /socket.io/ { proxy_pass http://api:4000; proxy_set_header Host $host;"
        " proxy_set_header X-Real-IP $remote_addr; }\n"
        "  location /_next/static/ { proxy_pass http://web:3000; expires 1y; }\n"
        "}\n"
    )
    f = check_text(open(bad, encoding="utf8").read(), "bad.conf")
    check("a proxied location missing X-Forwarded-For is caught", any(x.startswith("H2") and "socket.io" in x for x in f))
    check("a proxied location with no headers at all is caught", any("_next/static" in x for x in f))
    check("it names the line and the location", any(":3 location /socket.io/" in x for x in f))
    check("the compliant location produces no findings", not any("/api/" in x for x in f))

    # H4: the subtle mistake that silently breaks TRUST_PROXY_HOPS
    remote = os.path.join(tmp, "remote.conf")
    open(remote, "w", encoding="utf8").write(
        "server {\n  location / { proxy_pass http://web:3000; proxy_set_header Host $host;"
        " proxy_set_header X-Forwarded-For $remote_addr; proxy_set_header X-Forwarded-Proto $scheme; }\n}\n"
    )
    f = check_text(open(remote, encoding="utf8").read(), "remote.conf")
    check("X-Forwarded-For $remote_addr is refused (H4)", any(x.startswith("H4") for x in f))

    # H5: duplicate directives
    dup = os.path.join(tmp, "dup.conf")
    open(dup, "w", encoding="utf8").write(
        "server {\n  location / { proxy_pass http://web:3000; proxy_set_header Host $host;"
        " proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;"
        " proxy_set_header X-Forwarded-For $remote_addr; proxy_set_header X-Forwarded-Proto $scheme; }\n}\n"
    )
    f = check_text(open(dup, encoding="utf8").read(), "dup.conf")
    check("a duplicated X-Forwarded-For is reported (H5)", any(x.startswith("H5") for x in f))

    # negative control: a correct multi-line config passes
    good = os.path.join(tmp, "good.conf")
    open(good, "w", encoding="utf8").write(
        "server {\n"
        "  location /api/ {\n"
        "    proxy_pass http://api:4000;\n"
        "    proxy_set_header Host $host;\n"
        "    proxy_set_header X-Real-IP $remote_addr;\n"
        "    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;\n"
        "    proxy_set_header X-Forwarded-Proto $scheme;\n"
        "  }\n"
        "  location ~ /\\. { return 404; }\n"
        "}\n"
    )
    f = check_text(open(good, encoding="utf8").read(), "good.conf")
    check("a correct multi-line config passes (negative control)", f == [])
    check("a non-proxying location is not required to forward anything", not any("404" in x for x in f))

    # H6 (PHASE R0): the console location hands the api a gate variable, not $host
    gate_ok = os.path.join(tmp, "gate-ok.conf")
    open(gate_ok, "w", encoding="utf8").write(
        "map $host $flexora_admin_host {\n  default 0;\n  localhost 1;\n}\n"
        "map $flexora_admin_host $flexora_gate_host {\n  default host-gate.denied.invalid;\n  1 $host;\n}\n"
        "server {\n  location /api/platform/ { proxy_pass http://api:4000$request_uri;"
        " proxy_set_header Host $flexora_gate_host;"
        " proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;"
        " proxy_set_header X-Forwarded-Proto $scheme; }\n}\n"
    )
    f = check_text(open(gate_ok, encoding="utf8").read(), "gate-ok.conf")
    check("the R0 gate variable passes H1 and H6 when its maps are correct (negative control)", f == [])

    def gate_variant(name: str, mutate) -> list[str]:
        path = os.path.join(tmp, name)
        text = open(gate_ok, encoding="utf8").read()
        open(path, "w", encoding="utf8").write(mutate(text))
        return check_text(open(path, encoding="utf8").read(), name)

    f = gate_variant("gate-nomap.conf", lambda t: t.split("server {")[1].join(["", "server {"]))
    check("a gate variable with no map definition is caught (H6)", any(x.startswith("H6") for x in f))
    f = gate_variant("gate-notinvalid.conf", lambda t: t.replace("host-gate.denied.invalid", "localhost"))
    check("a gate default that ADMIN_HOSTS could accept is caught (H6)",
          any("reserved" in x or ".invalid" in x for x in f))
    f = gate_variant("gate-adminnothost.conf", lambda t: t.replace("  1 $host;", "  1 $http_x_forwarded_host;"))
    check("a gate that does not yield $host on an admin hostname is caught (H6)",
          any("admin hostname" in x for x in f))
    f = gate_variant("gate-wildcard.conf", lambda t: t.replace("  localhost 1;", "  localhost 1;\n  * 1;"))
    check("a wildcard admin host in the map is caught (H6)", any("wildcard" in x for x in f))
    f = gate_variant("gate-defaultopen.conf", lambda t: t.replace("  default 0;", "  default 1;"))
    check("a map that defaults to admin is caught (H6)", any("fail " in x or "default to 0" in x for x in f))
    f = gate_variant("host-arbitrary.conf", lambda t: t.replace("Host $flexora_gate_host", "Host $http_x_forwarded_host"))
    check("an arbitrary Host value is caught (H6)", any("arbitrary" in x or "must be `$host`" in x for x in f))

    for p in (bad, remote, dup, good, gate_ok):
        os.remove(p)
    for name in ("gate-nomap.conf", "gate-notinvalid.conf", "gate-adminnothost.conf",
                 "gate-wildcard.conf", "gate-defaultopen.conf", "host-arbitrary.conf"):
        q = os.path.join(tmp, name)
        if os.path.exists(q):
            os.remove(q)
    os.rmdir(tmp)
    total = passed + failed
    print(f"  SELF-TEST: {passed}/{total} cases behaved correctly")
    return 0 if failed == 0 else 2


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=REPO)
    ap.add_argument("--config", default=None, help="check this file instead of the compose-mounted one")
    ap.add_argument("--self-test", action="store_true")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    if args.self_test:
        return self_test()

    if args.config:
        path, why = args.config, "given on the command line"
    else:
        path, why = discover_config(args.repo)
    if not path:
        print(f"FAIL could not determine which nginx config to check: {why}")
        return 1
    if not os.path.exists(path):
        print(f"FAIL {path} does not exist ({why})")
        return 1

    text = open(path, encoding="utf8").read()
    findings = check_text(text, os.path.relpath(path, args.repo))
    proxied = sum(1 for _l, _h, body in location_blocks(text) if "proxy_pass" in body)

    if not args.quiet:
        print(f"nginx config:      {os.path.relpath(path, args.repo)} ({why})")
        print(f"proxied locations: {proxied}")
    if findings:
        print(f"{len(findings)} finding(s):")
        for f in findings:
            print(f"  FAIL {f}")
        return 1
    if not args.quiet:
        print(f"PASS — all {proxied} proxied location(s) forward Host, X-Forwarded-For "
              "($proxy_add_x_forwarded_for) and X-Forwarded-Proto.")
        print("       With one proxy hop, TRUST_PROXY_HOPS=1 makes req.ip the client address.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
