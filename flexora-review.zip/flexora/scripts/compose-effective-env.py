#!/usr/bin/env python3
"""
PHASE O1.6 — compute the environment each compose service ACTUALLY gets, without
Docker.

WHY THIS EXISTS
---------------
`docker compose config` is the normal way to answer "what will this container
see?". Docker is not available in this sandbox, so this script implements the
documented Compose interpolation grammar itself and prints the effective
environment per service. Everything it produces is labelled SUBSTITUTE EVIDENCE:
same file, same grammar, no daemon.

Grammar implemented (docs.docker.com/reference/compose-file/interpolation):
  ${VAR}          value if set, else EMPTY STRING + a warning (Compose's own
                  behaviour for an unresolvable variable with no default)
  ${VAR:-def}     def when VAR is unset OR EMPTY
  ${VAR-def}      def only when VAR is UNSET (an empty value is kept)
  ${VAR:?err}     error when unset or empty
  ${VAR?err}      error only when unset
  ${VAR:+rep}     rep when set and non-empty, else empty
  ${VAR+rep}      rep when set (even empty), else empty
  ${A:-${B:-c}}   nesting, to any depth
  $$              a literal '$' (no interpolation) -- how compose passes
                  $$REDIS_PASSWORD through to the container's own shell
  $VAR            bare form, same as ${VAR}
Precedence: the shell/scenario environment wins over the --env-file, which is
how Compose behaves.

WHAT IT ASSERTS (scenarios A-D from the brief)
  A production-like   api NODE_ENV=production; api holds NO POSTGRES_PASSWORD and
                      no owner DIRECT_URL (its DIRECT_URL resolves from
                      DATABASE_URL); the migrate service is the only one with an
                      owner-privileged DIRECT_URL
  B NODE_ENV unset    every service still gets NODE_ENV=production (`:-` default)
  C unset + dev defaults
                      the effective env shows which required secrets came from a
                      development default -- the exact input the boot matrix's C1
                      scenario refuses with a FATAL naming those variables
  D NODE_ENV=development
                      development propagates; nothing forces production

Secret values are never printed: a secret-shaped variable is shown as its SOURCE
(shell env / env file / default / unset) and, when a literal is present in the
compose file, masked to its first three characters plus '***'.

usage:
  scripts/compose-effective-env.py [--repo DIR] [--compose FILE] [--env-file FILE]
                                   [--scenario A|B|C|D|all] [--service NAME]
                                   [--self-test] [--emit-env-file SCENARIO PATH]
                                   [--host-boot] [--quiet]
exit: 0 all assertions passed · 1 a finding · 2 usage/self-test failure
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)

# Names whose VALUES must never be printed. Deliberately broad: it is cheaper to
# mask a non-secret than to leak one (standing constraint L1/M).
SECRET_NAME = re.compile(
    r"(SECRET|PASSWORD|PASSWD|TOKEN|KEY|CREDENTIAL|SIGNATURE|HMAC|DSN|"
    r"DATABASE_URL|DIRECT_URL|REDIS_URL|LICENSE)",
    re.I,
)
# The development defaults the api's own validator rejects in production
# (apps/api/src/config/env-validation.ts DEV_DEFAULT_VALUES). Listed here only to
# CLASSIFY scenario C's input; the authoritative list stays in the validator.
DEV_DEFAULTS = {
    "changeme", "change_me", "dev", "development", "test", "testing", "secret",
    "password", "flexora_dev_pw", "flexora_app_dev_pw", "flexora", "postgres",
    "localhost", "http://localhost:3000", "redis://localhost:6379",
}


class InterpolationError(Exception):
    """${VAR:?message} / ${VAR?message} with the variable missing."""


# ------------------------------------------------------------------ grammar ---
def _find_matching_brace(text: str, start: int) -> int:
    """Index of the '}' that closes the '${' at `start`, honouring nesting."""
    depth = 0
    i = start
    while i < len(text):
        if text[i] == "$" and i + 1 < len(text) and text[i + 1] == "{":
            depth += 1
            i += 2
            continue
        if text[i] == "}" and depth:
            depth -= 1
            if depth == 0:
                return i
        i += 1
    raise InterpolationError(f"unterminated interpolation in {text[start:start + 40]!r}")


OPS = (":-", ":?", ":+", "-", "?", "+")          # two-character operators first


def _split_operator(body: str) -> tuple[str, str | None, str]:
    """Split 'VAR<op>argument' on the first top-level operator."""
    depth = 0
    i = 0
    while i < len(body):
        ch = body[i]
        if ch == "$" and i + 1 < len(body) and body[i + 1] == "{":
            depth += 1
            i += 2
            continue
        if ch == "}":
            depth -= 1
            i += 1
            continue
        if depth == 0:
            for op in OPS:
                if body.startswith(op, i):
                    return body[:i], op, body[i + len(op):]
            # a bare ':' is not an operator in compose; skip it
        i += 1
    return body, None, ""


def interpolate(text: str, env: dict[str, str], warnings: list[str]) -> str:
    """Resolve every ${...}/$VAR in `text` against `env`, per the Compose grammar."""
    if not isinstance(text, str) or "$" not in text:
        return text if isinstance(text, str) else str(text)
    out: list[str] = []
    i = 0
    while i < len(text):
        ch = text[i]
        if ch == "$":
            if text.startswith("$$", i):                      # literal dollar
                out.append("$")
                i += 2
                continue
            if text.startswith("${", i):
                close = _find_matching_brace(text, i)
                body = text[i + 2:close]
                out.append(_resolve(body, env, warnings, text))
                i = close + 1
                continue
            m = re.match(r"\$([A-Za-z_][A-Za-z0-9_]*)", text[i:])
            if m:
                name = m.group(1)
                if name not in env:
                    warnings.append(f"${name} is not set and has no default — substituted with an empty string")
                out.append(env.get(name, ""))
                i += m.end()
                continue
            out.append("$")                                   # a lone '$' stays literal
            i += 1
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def _resolve(body: str, env: dict[str, str], warnings: list[str], whole: str) -> str:
    name, op, arg = _split_operator(body)
    name = name.strip()
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
        raise InterpolationError(f"invalid variable name in ${{{body}}}")
    arg_val = interpolate(arg, env, warnings) if arg else ""  # nested defaults
    present = name in env
    value = env.get(name, "")
    nonempty = present and value != ""

    if op is None:
        if not present:
            warnings.append(f"${{{name}}} is not set and has no default — substituted with an empty string")
        return value
    if op == ":-":
        return value if nonempty else arg_val
    if op == "-":
        return value if present else arg_val
    if op == ":?":
        if not nonempty:
            raise InterpolationError(f"{arg_val or f'required variable {name} is not set'}")
        return value
    if op == "?":
        if not present:
            raise InterpolationError(f"{arg_val or f'required variable {name} is not set'}")
        return value
    if op == ":+":
        return arg_val if nonempty else ""
    if op == "+":
        return arg_val if present else ""
    raise InterpolationError(f"unsupported operator {op!r} in ${{{body}}}")


# ------------------------------------------------------------- compose model ---
def load_env_file(path: str | None) -> dict[str, str]:
    """A .env file: KEY=VALUE, '#' comments, optional quotes, 'export ' prefix."""
    env: dict[str, str] = {}
    if not path or not os.path.exists(path):
        return env
    for raw in open(path, encoding="utf8", errors="replace"):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export "):].lstrip()
        if "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip()
        v = v.strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
            v = v[1:-1]
        elif "#" in v and not (v.startswith('"') or v.startswith("'")):
            v = v.split(" #", 1)[0].rstrip()      # an unquoted inline comment
        env[k] = v
    return env


def parse_compose(path: str) -> dict:
    import yaml                                            # PyYAML 6.0.3 here
    with open(path, encoding="utf8") as fh:
        return yaml.safe_load(fh)


def environment_pairs(spec) -> list[tuple[str, str]]:
    """Normalise both compose forms: a mapping and a list of 'KEY=value'."""
    if spec is None:
        return []
    if isinstance(spec, dict):
        return [(str(k), "" if v is None else str(v)) for k, v in spec.items()]
    if isinstance(spec, list):
        pairs = []
        for item in spec:
            item = str(item)
            if "=" in item:
                k, v = item.split("=", 1)
                pairs.append((k, v))
            else:
                pairs.append((item, None))          # pass-through from the host
        return pairs
    raise ValueError(f"unsupported environment form: {type(spec)}")


def effective_env(service: dict, host_env: dict[str, str], warnings: list[str]) -> dict[str, str]:
    """Resolve one service's `environment:` (and note its build args separately)."""
    out: dict[str, str] = {}
    for key, template in environment_pairs(service.get("environment")):
        if template is None:                        # short form: pass the host value through
            if key in host_env:
                out[key] = host_env[key]
            else:
                warnings.append(f"{key}: listed without a value and not set in the environment — not passed to the container")
            continue
        out[key] = interpolate(template, host_env, warnings)
    return out


def build_args(service: dict, host_env: dict[str, str], warnings: list[str]) -> dict[str, str]:
    build = service.get("build") or {}
    args = build.get("args") if isinstance(build, dict) else None
    return {k: interpolate("" if v is None else str(v), host_env, warnings)
            for k, v in environment_pairs(args)}


# ----------------------------------------------------------------- reporting ---
def provenance(template: str | None, host_env: dict[str, str]) -> str:
    """Where a value came from: the host environment, a compose default, or a literal."""
    if template is None:
        return "passed through from the host"
    if "$" not in template:
        return "LITERAL in compose"
    m = re.search(r"\$\{([A-Za-z_][A-Za-z0-9_]*)(:?[-?+])?", template)
    if not m:
        m2 = re.search(r"\$([A-Za-z_][A-Za-z0-9_]*)", template)
        if not m2:
            return "interpolated"
        name = m2.group(1)
        return f"= ${name} ({'set in the environment' if name in host_env else 'UNSET -> empty string + warning'})"
    name, op = m.group(1), m.group(2)
    if op in (":-", ":?"):
        if host_env.get(name):
            return f"= ${name} (set in the environment)"
        if op == ":-":
            return f"= the compose default, because ${name} is unset or EMPTY"
        return f"= ${name} — REQUIRED, and it is unset or empty"
    if op == "-":
        return (f"= ${name} (set in the environment)" if name in host_env
                else f"= the compose default, because ${name} is UNSET (an empty value would be kept)")
    return f"= ${name} ({'set' if name in host_env else 'unset'})"


def describe(name: str, value: str, template: str | None = None) -> str:
    """A printable description that never reveals a secret value."""
    if SECRET_NAME.search(name):
        if value == "":
            return "<empty>"
        if re.match(r"^[a-z][a-z0-9+.-]*://", value):
            # keep everything that is not a credential: scheme, user, host, port, path
            return re.sub(r"(://[^:/@\s]*:)[^@]*(@)", r"\1***\2", value)
        # provenance() already says where the value came from, so no suffix here
        return f"<set, {len(value)} chars, not printed>"
    return value if value != "" else "<empty>"


def user_of(url: str) -> str:
    """The username of a connection URL, or '' — used for assertions, never printed
    with its password."""
    m = re.match(r"^[a-z][a-z0-9+.-]*://([^:@/]*)(?::[^@/]*)?@", url or "")
    return m.group(1) if m else ""


# ------------------------------------------------------------------ scenarios ---
def scenario_envs(repo: str, extra_env_file: str | None) -> dict[str, dict[str, str]]:
    """
    The four scenarios' host environments. Values are NAMES for anything the api
    validator would reject, and placeholders for secrets: this script reasons about
    which variable comes from where, never about real credentials. Real secrets for
    the host-boot run come from /var/tmp/o1-fixtures (see --emit-env-file).
    """
    compose = parse_compose(os.path.join(repo, "docker-compose.yml"))
    required = sorted({
        m.group(1)
        for svc in compose.get("services", {}).values()
        for _, t in environment_pairs(svc.get("environment"))
        if isinstance(t, str)
        for m in re.finditer(r"\$\{([A-Za-z_][A-Za-z0-9_]*):?\?", t)
    })
    base_file = load_env_file(extra_env_file)

    # A production-like operator environment: every `:?` variable supplied, no
    # NODE_ENV override (compose defaults it to production).
    a = dict(base_file)
    for name in required:
        a.setdefault(name, f"SCENARIO_A_{name}")
    # Connection strings get a realistic shape so the "runtime user vs migration
    # user" assertion is about users, not about placeholders. The passwords are
    # obviously synthetic and are masked in every report.
    a["DATABASE_URL"] = "postgresql://flexora_runtime:SCENARIO_A_PW@db:5432/flexora?schema=public"
    a["DIRECT_URL"] = "postgresql://flexora_owner:SCENARIO_A_PW@db:5432/flexora?schema=public"
    a.update({
        "DOMAIN": "app.example.com",
        "COOKIE_SECURE": "true",
        "CORS_ORIGIN": "https://app.example.com",
        "TRUST_PROXY_HOPS": "1",
        "API_PROXY_TARGET": "http://api:4000",
    })
    a.pop("NODE_ENV", None)

    b = dict(a)                                     # identical, NODE_ENV explicitly absent
    b.pop("NODE_ENV", None)

    c = dict(a)                                     # a developer's .env: dev defaults
    c.pop("NODE_ENV", None)
    for name, value in list(c.items()):
        # every placeholder this script invented becomes the classic dev default,
        # which is what a real .env copied from .env.example still carries
        if isinstance(value, str) and value.startswith("SCENARIO_A_"):
            c[name] = "changeme"
    c.update({
        "DATABASE_URL": "postgresql://flexora:flexora_dev_pw@db:5432/flexora?schema=public",
        "DIRECT_URL": "postgresql://flexora:flexora_dev_pw@db:5432/flexora?schema=public",
        "REDIS_PASSWORD": "flexora_dev_pw",
        "COOKIE_SECURE": "false",
        "CORS_ORIGIN": "http://localhost:3000",
    })

    d = dict(a)
    d["NODE_ENV"] = "development"

    return {"A": a, "B": b, "C": c, "D": d}


def check_scenario(name: str, repo: str, host_env: dict[str, str], quiet: bool) -> tuple[list[str], dict]:
    compose = parse_compose(os.path.join(repo, "docker-compose.yml"))
    services = compose.get("services", {})
    findings: list[str] = []
    asserts: list[tuple[str, bool]] = []
    warnings: list[str] = []
    detail: dict[str, dict] = {}

    def expect(label: str, ok: bool) -> None:
        asserts.append((label, bool(ok)))
        if not ok:
            findings.append(f"{name}: {label}")

    for svc_name in ("api", "web", "migrate"):
        svc = services.get(svc_name)
        if not svc:
            expect(f"compose has a `{svc_name}` service", False)
            continue
        detail[svc_name] = {
            "env": effective_env(svc, host_env, warnings),
            "args": build_args(svc, host_env, warnings),
            "templates": dict(environment_pairs(svc.get("environment"))),
        }

    api = detail.get("api", {}).get("env", {})
    api_t = detail.get("api", {}).get("templates", {})
    migrate = detail.get("migrate", {}).get("env", {})
    web_args = detail.get("web", {}).get("args", {})

    # ---- the brief's assertions ------------------------------------------
    if name in ("A", "B"):
        expect(f"api NODE_ENV resolves to production (got {api.get('NODE_ENV')!r})",
               api.get("NODE_ENV") == "production")
        for banned in ("POSTGRES_PASSWORD", "POSTGRES_USER", "REDIS_PASSWORD"):
            expect(f"api holds no {banned}", banned not in api)
        expect("api DIRECT_URL resolves from DATABASE_URL (same restricted user "
               f"{user_of(api.get('DIRECT_URL', ''))!r})",
               api.get("DIRECT_URL") == api.get("DATABASE_URL")
               and api_t.get("DIRECT_URL", "").startswith("${DATABASE_URL"))
        expect("the migrate service has a DIRECT_URL", bool(migrate.get("DIRECT_URL")))
        if "://" in migrate.get("DIRECT_URL", "") and "://" in api.get("DATABASE_URL", ""):
            expect(f"only migrate holds the owner credential (migrate user "
                   f"{user_of(migrate['DIRECT_URL'])!r} != api user {user_of(api.get('DATABASE_URL', ''))!r})",
                   user_of(migrate["DIRECT_URL"]) != user_of(api.get("DATABASE_URL", "")))
        expect("SUPER_ADMIN_PASSWORD stays OPTIONAL (present, empty, no default value)",
               "SUPER_ADMIN_PASSWORD" in api and api["SUPER_ADMIN_PASSWORD"] == ""
               and api_t.get("SUPER_ADMIN_PASSWORD") == "${SUPER_ADMIN_PASSWORD:-}")
    if name == "B":
        expect("NODE_ENV is genuinely unset in the host environment", "NODE_ENV" not in host_env)
    if name == "C":
        devish = sorted(k for k, v in api.items() if isinstance(v, str) and v.strip().lower() in DEV_DEFAULTS)
        detail["C_dev_defaults"] = devish
        expect(f"development defaults are visible in the api environment ({len(devish)}: "
               + ", ".join(devish[:6]) + ")", len(devish) >= 3)
        expect("NODE_ENV still resolves to production (a dev .env does not opt out of the checks)",
               api.get("NODE_ENV") == "production")
    if name == "D":
        expect(f"api NODE_ENV resolves to development (got {api.get('NODE_ENV')!r})",
               api.get("NODE_ENV") == "development")

    for arg in ("NEXT_PUBLIC_API_URL", "NEXT_PUBLIC_SUPPORT_URL", "NEXT_PUBLIC_VAPID_PUBLIC_KEY", "API_PROXY_TARGET"):
        expect(f"web build args include {arg}", arg in web_args)

    if not quiet:
        print(f"===== scenario {name} =====")
        print(f"  NODE_ENV in the host environment: "
              f"{'set to ' + host_env['NODE_ENV'] if 'NODE_ENV' in host_env else 'UNSET'}")
        for svc_name in ("api", "web", "migrate"):
            d = detail.get(svc_name)
            if d:
                print(f"  [{svc_name}] {len(d['env'])} environment entries"
                      + (f", {len(d['args'])} build args" if d["args"] else ""))
        show = [k for k in ("NODE_ENV", "DATABASE_URL", "DIRECT_URL", "REDIS_URL",
                            "REDIS_ALLOW_PLAINTEXT_INTERNAL", "COOKIE_SECURE", "TRUST_PROXY_HOPS",
                            "CORS_ORIGIN", "API_PORT", "JWT_ACCESS_SECRET", "ENCRYPTION_KEY",
                            "SUPER_ADMIN_PASSWORD", "PLATFORM_ADMIN_PASSWORD") if k in api]
        print("  [api] the entries that decide this scenario:")
        for k in show:
            print(f"        {k} = {describe(k, api[k], api_t.get(k))}")
            print(f"          ^ {provenance(api_t.get(k), host_env)}")
        if name == "C":
            print(f"  [C] development defaults in the api environment ({len(detail['C_dev_defaults'])}): "
                  + ", ".join(detail["C_dev_defaults"]))
        print("  assertions:")
        for label, ok in asserts:
            print(f"        {'PASS' if ok else 'FAIL'}  {label}")
        for w in sorted(set(warnings))[:6]:
            print(f"  WARN {w}")
        print()
    return findings, detail


# --------------------------------------------------------------- host boot ----
def emit_env_file(scenario: str, repo: str, path: str, host_boot: bool, quiet: bool) -> int:
    """
    Write KEY=VALUE lines for one scenario so the REAL built API can be booted with
    exactly what compose declares. With --host-boot the container hostnames are
    remapped to localhost, because Docker networking does not exist here; real
    secrets are read from /var/tmp/o1-fixtures so nothing is invented or printed.
    """
    host_env = scenario_envs(repo, None)[scenario]
    compose = parse_compose(os.path.join(repo, "docker-compose.yml"))
    warnings: list[str] = []
    eff = effective_env(compose["services"]["api"], host_env, warnings)

    fx = "/var/tmp/o1-fixtures"
    secrets = {}
    if host_boot and os.path.isdir(fx):
        prod = open(os.path.join(fx, "flexora_prod.pw")).read().strip()
        redispw = open(os.path.join(fx, "redis.pw")).read().strip()
        secrets = {
            "DATABASE_URL": f"postgresql://flexora_prod:{prod}@localhost:5432/flexora?schema=public",
            "DIRECT_URL": f"postgresql://flexora_prod:{prod}@localhost:5432/flexora?schema=public",
            "REDIS_URL": f"redis://:{redispw}@localhost:6379",
            "REDIS_ALLOW_PLAINTEXT_INTERNAL": "true",
        }
        import subprocess
        for name in ("JWT_ACCESS_SECRET", "JWT_REFRESH_SECRET", "JWT_MEMBER_SECRET", "ENCRYPTION_KEY",
                     "ENCRYPTION_SEARCH_KEY", "OTP_HMAC_SECRET", "WHATSAPP_APP_SECRET", "PAYMOB_HMAC_SECRET"):
            secrets[name] = subprocess.run(["openssl", "rand", "-hex", "32"], capture_output=True, text=True).stdout.strip()
        secrets["BACKUP_ENCRYPTION_KEY"] = subprocess.run(["openssl", "rand", "-hex", "16"], capture_output=True, text=True).stdout.strip()
        secrets["FLEXORA_LICENSE_KEY"] = "FLX-ENT-9F3A7C21-O16HOST"
        secrets["CORS_ORIGIN"] = "https://app.example.com"
        secrets["COOKIE_SECURE"] = "true"
        secrets["IMPORT_UPLOAD_DIR"] = "/tmp/flexora/imports"
        secrets["BACKUP_DIR"] = "/tmp/flexora/backups"
        secrets["CONTRACT_PDF_DIR"] = "/tmp/flexora/contracts"
        secrets["API_PORT"] = os.environ.get("O16_PORT", "4451")
        secrets["PRISMA_QUERY_LOG"] = "off"

    merged = {**eff, **secrets}
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf8") as fh:
        for k in sorted(merged):
            fh.write(f"{k}={merged[k]}\n")
    os.chmod(path, 0o600)
    if not quiet:
        print(f"scenario {scenario}: wrote {len(merged)} entries to {path} (mode 600, values not printed)")
        if host_boot:
            print("  host-boot remap: db/pgbouncer/redis hostnames -> localhost, real secrets from /var/tmp/o1-fixtures")
            print("  (SUBSTITUTE EVIDENCE: Docker networking is unavailable in this sandbox)")
    return 0


# ---------------------------------------------------------------- self-test ---
SELF_TEST_ROWS = [
    # (template, env, expected value or InterpolationError, note)
    ("${VAR}", {"VAR": "x"}, "x", "plain substitution"),
    ("${VAR}", {}, "", "unset with no default -> empty string + warning"),
    ("${VAR:-def}", {"VAR": ""}, "def", "`:-` treats EMPTY as missing"),
    ("${VAR:-def}", {}, "def", "`:-` treats UNSET as missing"),
    ("${VAR:-def}", {"VAR": "x"}, "x", "`:-` keeps a real value"),
    ("${VAR-def}", {"VAR": ""}, "", "`-` keeps an EMPTY value (the difference the brief asks about)"),
    ("${VAR-def}", {}, "def", "`-` substitutes only when UNSET"),
    ("${VAR:?is required}", {"VAR": ""}, InterpolationError, "`:?` errors on empty"),
    ("${VAR:?is required}", {}, InterpolationError, "`:?` errors on unset"),
    ("${VAR?is required}", {"VAR": ""}, "", "`?` accepts an empty value"),
    ("${VAR?is required}", {}, InterpolationError, "`?` errors only when unset"),
    ("${VAR:+rep}", {"VAR": "x"}, "rep", "`:+` replacement when set and non-empty"),
    ("${VAR:+rep}", {"VAR": ""}, "", "`:+` empty when the value is empty"),
    ("${VAR+rep}", {"VAR": ""}, "rep", "`+` replacement when set, even empty"),
    ("${VAR+rep}", {}, "", "`+` empty when unset"),
    ("${A:-${B:-c}}", {"B": "b"}, "b", "nested default, inner resolves"),
    ("${A:-${B:-c}}", {}, "c", "nested default, both missing"),
    ("${A:-${B:-c}}", {"A": "a", "B": "b"}, "a", "nested default, outer wins"),
    ("$$REDIS_PASSWORD", {"REDIS_PASSWORD": "leak"}, "$REDIS_PASSWORD", "`$$` yields a literal $ (no interpolation)"),
    ("redis://:$$PW@redis:6379", {"PW": "leak"}, "redis://:$PW@redis:6379", "`$$` inside a URL"),
    ("$VAR", {"VAR": "x"}, "x", "bare form"),
    ("prefix-${VAR}-suffix", {"VAR": "x"}, "prefix-x-suffix", "embedded"),
    ("${REDIS_URL:-redis://:${REDIS_PASSWORD}@redis:6379}", {"REDIS_PASSWORD": "p"},
     "redis://:p@redis:6379", "the derived default compose actually uses for REDIS_URL"),
    ("${NODE_ENV:-production}", {}, "production", "compose's production default"),
    ("${NODE_ENV:-production}", {"NODE_ENV": "development"}, "development", "an explicit development wins"),
]


def self_test() -> int:
    passed = failed = 0
    for template, env, expected, note in SELF_TEST_ROWS:
        warnings: list[str] = []
        try:
            got = interpolate(template, dict(env), warnings)
            err = None
        except InterpolationError as exc:
            got, err = None, exc
        if expected is InterpolationError:
            ok = err is not None
        else:
            ok = err is None and got == expected
        if ok:
            passed += 1
            print(f"    PASS  {note}")
        else:
            failed += 1
            print(f"    FAIL  {note}: {template} with {env} -> {got!r} (expected {expected!r}, error={err})")

    # the unset-with-no-default warning must actually be raised
    warnings = []
    interpolate("${MISSING}", {}, warnings)
    if warnings and "empty string" in warnings[0]:
        passed += 1
        print("    PASS  an unresolvable variable warns, like compose does")
    else:
        failed += 1
        print(f"    FAIL  expected a warning for ${{MISSING}}, got {warnings!r}")

    # describe() must never print a secret value
    if "hunter2" not in describe("JWT_ACCESS_SECRET", "hunter2secret", "${JWT_ACCESS_SECRET:?required}"):
        passed += 1
        print("    PASS  describe() masks a secret value")
    else:
        failed += 1
        print("    FAIL  describe() leaked a secret value")
    if describe("API_PORT", "4000") == "4000":
        passed += 1
        print("    PASS  describe() shows a non-secret value unchanged")
    else:
        failed += 1
        print("    FAIL  describe() mangled a non-secret value")

    total = passed + failed
    print(f"  SELF-TEST: {passed}/{total} rows behaved correctly")
    return 0 if failed == 0 else 2


# --------------------------------------------------------------------- main ---
def main() -> int:
    ap = argparse.ArgumentParser(add_help=True, description=__doc__.split("\n")[1])
    ap.add_argument("--repo", default=REPO)
    ap.add_argument("--compose", default=None)
    ap.add_argument("--env-file", default=None)
    ap.add_argument("--scenario", default="all", choices=["A", "B", "C", "D", "all"])
    ap.add_argument("--service", default=None)
    ap.add_argument("--self-test", action="store_true")
    ap.add_argument("--emit-env-file", nargs=2, metavar=("SCENARIO", "PATH"), default=None)
    ap.add_argument("--host-boot", action="store_true",
                    help="with --emit-env-file: remap container hostnames to localhost and use real fixture secrets")
    ap.add_argument("--json", action="store_true", help="print the effective env as JSON (secrets masked)")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    if args.self_test:
        return self_test()

    repo = args.repo
    if args.emit_env_file:
        return emit_env_file(args.emit_env_file[0], repo, args.emit_env_file[1], args.host_boot, args.quiet)

    wanted = ["A", "B", "C", "D"] if args.scenario == "all" else [args.scenario]
    envs = scenario_envs(repo, args.env_file)
    all_findings: list[str] = []
    for name in wanted:
        findings, detail = check_scenario(name, repo, envs[name], args.quiet or args.json)
        all_findings += findings
        if args.json:
            masked = {svc: {k: describe(k, v) for k, v in d["env"].items()} for svc, d in detail.items() if isinstance(d, dict) and "env" in d}
            print(json.dumps({"scenario": name, "effective_env": masked}, indent=2))

    if args.service:
        for name in wanted:
            compose = parse_compose(os.path.join(repo, "docker-compose.yml"))
            svc = compose.get("services", {}).get(args.service)
            if not svc:
                print(f"FAIL scenario {name}: compose has no `{args.service}` service")
                all_findings.append(f"{name}: no `{args.service}` service")
                continue
            warns: list[str] = []
            eff = effective_env(svc, envs[name], warns)
            argz = build_args(svc, envs[name], warns)
            print(f"===== scenario {name} · service `{args.service}` · {len(eff)} entries"
                  + (f" + {len(argz)} build args" if argz else "") + " =====")
            for k in sorted(eff):
                print(f"    {k} = {describe(k, eff[k])}")
            for k in sorted(argz):
                print(f"    [build arg] {k} = {describe(k, argz[k])}")
            print()

    if all_findings:
        print(f"{len(all_findings)} finding(s):")
        for f in all_findings:
            print(f"  FAIL {f}")
        return 1
    if not args.quiet:
        print("PASS — every scenario resolves to the environment the brief expects "
              "(no secret values printed).")
        print("NOTE SUBSTITUTE EVIDENCE: computed from docker-compose.yml with this script's")
        print("     implementation of the Compose interpolation grammar; no Docker daemon")
        print("     exists in this sandbox. The matching live proof is the built API booted")
        print("     with `env -i` in work/o1-evidence/boot-matrix/ (scenarios B1, C1, D1, D2).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
