#!/usr/bin/env python3
r"""
PHASE O2 — the credential scanner. Replaces the grep pipeline that
scripts/check-secrets.sh used to run (that shell script is now a thin wrapper, so
there is one implementation and one set of rules).

TWO DEFECTS THIS FIXES
----------------------
1. The URL rule required a non-empty username:
       (postgres(ql)?|mysql|redis|mongodb(\+srv)?)://[^:/@[:space:]]+:[^@[:space:]]+@
   `redis://:Sup3rSecret@redis:6379` — the NORMAL way to write a Redis URL, since
   Redis has no username by default — did not match, so a real Redis password was
   reported clean. `rediss://` and `amqp://` were missing entirely.
2. Findings were printed as raw grep output, i.e. the scanner echoed the very
   credential it was reporting. `scripts/package-release.sh` runs this on the
   delivery archive, so a leak would have been copied into the release log.
   Every value is now masked to its first three characters plus `***`.

RULES
  R1  a connection url with an inline password: scheme://[user]:password@host
      schemes: postgres, postgresql, mysql, mongodb, mongodb+srv, redis, rediss,
      amqp, amqps. The username is OPTIONAL.
  R2  a credential-shaped assignment with a literal value:
      (password|passwd|pwd|secret|token|api[_-]?key|hmac) = "literal"
  R3  a known provider key shape: Google AIza…, Stripe sk_live_…, AWS AKIA…,
      GitHub ghp_…, Slack xox[baprs]-…, OpenAI sk-…, npm npm_…
  R4  a PEM private key block
  R5  an HTTP basic-auth url with an inline password (https://user:pass@host)

WHAT IS *NOT* A FINDING (and why it is safe rather than convenient)
  * the whole password token is a template: <…>, ${…}, $VAR, {{…}}, CHANGE_ME…,
    xxx, ***, ...
  * for R1/R5 only: username AND password are both obvious dummies
    (postgres:postgres, build:build@localhost, user:password)
  * the value is a reference, not a literal: process.env.X, os.environ[...],
    getenv(...), ${{ secrets.X }}
There are NO directory or file-type allow-lists: a `.md` file carrying
`postgresql://svc:Tr0ub4dorAnd3x9@db.prod:5432/app` is a leak exactly like a
`.ts` file, and git-ignored files (`.env`, `.env.local`) are scanned like any
other — only `.env.example` templates are expected to hold placeholders, which
the template rule above already covers.

usage: scripts/check-secrets.py [TARGET_DIR] [--label TEXT] [--self-test]
                              [--json] [--quiet] [--max N]
exit:  0 clean · 1 findings · 2 usage/self-test failure
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys

SCHEMES = r"(?:postgres|postgresql|mysql|mongodb\+srv|mongodb|rediss|redis|amqps|amqp)"
# a password token: anything up to the '@' that ends the authority. Percent-encoded
# characters (%40, %3A, %2F) are part of the value, not delimiters.
USER = r"(?:[^:/@\s]*)"          # OPTIONAL — redis:// :pw@host is the common form
PASS = r"(?P<val>(?:[^@\s/?#]|%[0-9A-Fa-f]{2})+)"

RULES = [
    ("R1", re.compile(SCHEMES + r":\/\/" + USER + r":" + PASS + r"@", re.I), "connection url with an inline password"),
    ("R5", re.compile(r"https?:\/\/" + USER + r":" + PASS + r"@", re.I), "http basic-auth url with an inline password"),
    # R2: a credential-shaped name assigned a LITERAL. Two spellings only:
    #   quoted   — password = "X9mQ2vLp7wR4t"
    #   bare     — JWT_ACCESS_SECRET=9f2c1a4b7e8d3f6a1c5b9e2d  (env / yaml)
    # Code punctuation ( . ( ) [ ] => ) and whitespace are excluded from the bare
    # value, which is what keeps `req.cookies['flx_access']` and `z.string()` out.
    ("R2", re.compile(
        r"(?P<name>\b[A-Za-z0-9_]*(?:password|passwd|pwd|secret|token|api[_-]?key|hmac)[A-Za-z0-9_]*)"
        r"\s*[:=]\s*"
        r'(?:["\x27`](?P<val>[^"\x27`\s]{12,})["\x27`]'
        r'|(?P<val2>[A-Za-z0-9!@#$%^&*_+\-]{12,})(?=[\s;,})"\x27`]|$))', re.I),
     "credential-shaped assignment with a literal value"),
    ("R3", re.compile(
        r"(?P<val>AIza[0-9A-Za-z_\-]{35}|sk_live_[0-9a-zA-Z]{16,}|rk_live_[0-9a-zA-Z]{16,}|"
        r"AKIA[0-9A-Z]{16}|ghp_[A-Za-z0-9]{36}|gho_[A-Za-z0-9]{36}|github_pat_[A-Za-z0-9_]{20,}|"
        r"xox[baprs]-[A-Za-z0-9-]{10,}|sk-[A-Za-z0-9]{20,}|npm_[A-Za-z0-9]{36})"), "known provider credential shape"),
    ("R4", re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY-----"), "PEM private key block"),
]

TEMPLATES = [
    re.compile(r"^<.*>$"),                       # <password>, <user>:<password>@<host>
    re.compile(r"^\$\{.*\}$"),                   # ${REDIS_PASSWORD}
    re.compile(r"^\$[A-Za-z_][A-Za-z0-9_]*$"),   # $REDIS_PASSWORD
    re.compile(r"^\{\{.*\}\}$"),                 # {{ secrets.X }}
    re.compile(r"^CHANGE_?ME", re.I),            # CHANGE_ME, CHANGEME, CHANGE_ME_...
    re.compile(r"^x{3,}$", re.I),                # xxx, xxxx
    re.compile(r"^\*{3,}$"),                     # ***
    re.compile(r"^\.{3}$"),                      # ...
    re.compile(r"^[%_\-]*$"),                    # placeholders made of punctuation
    re.compile(r"^\$\(.*\)$"),                  # $(openssl rand -hex 32)
    re.compile(r"^<[^>]*>.*$"),                   # <OWNER_PASSWORD>@host style
    re.compile(r"^[A-Za-z0-9_]*\$\{.*\}$"),    # PREFIX${VAR}
    re.compile(r"^\{[A-Za-z0-9_]+\}.*$"),        # an f-string interpolation: {prod_pw}
    re.compile(r".*\{[A-Za-z0-9_]+\}.*"),        # …or one embedded in the value
]
DUMMY = {
    "postgres", "postgresql", "mysql", "mongo", "redis", "admin", "root", "user",
    "username", "build", "test", "demo", "example", "guest", "svc", "service",
    "password", "passwd", "pwd", "pass", "changeme", "change_me", "secret",
    "default", "none", "null", "your_password", "yourpassword", "placeholder",
    "xxx", "123456", "1234", "12345678",
}
REFERENCE = re.compile(
    r"(process\.env|os\.environ|getenv|System\.getenv|\$\{\{\s*secrets\.|"
    r"ENV\[|vault:|keybase:|sops:|from\s+secret|"
    # a shell command substitution generates the value; it is not a literal
    r"^\$\(|\$\(openssl|\$\(cat\s)", re.I)
# values that are structurally not credentials
NOT_A_SECRET = re.compile(r"^[A-Za-z0-9_./:\-]*$", re.I)


def is_template(value: str) -> bool:
    v = value.strip().strip("\"'")
    if not v:
        return True
    return any(p.match(v) for p in TEMPLATES)


def is_dummy(value: str) -> bool:
    return value.strip().strip("\"'").lower() in DUMMY


def mask(value: str) -> str:
    """First three characters plus *** — enough to recognise, never to reuse."""
    v = value.strip()
    if len(v) <= 3:
        return "***"
    return v[:3] + "***"


def mask_line(line: str, value: str) -> str:
    """The line with the credential replaced by its mask (context kept)."""
    if not value:
        return line.strip()[:180]
    out = line.replace(value, mask(value))
    return out.strip()[:180]


def looks_like_credential(value: str) -> bool:
    """R2's second half: a literal that could actually be a secret."""
    v = value.strip().strip("\"'`")
    if len(v) < 12:
        return False
    # a secret has letters AND digits (or is a long provider token). This is what
    # keeps i18n prose, identifiers and paths out without any allow-list.
    if not (re.search(r"[A-Za-z]", v) and re.search(r"[0-9]", v)):
        return False
    if re.search(r"[.()\[\]{}]", v):
        return False                      # code, not a credential
    if re.fullmatch(r"[A-Z][A-Z0-9_]*", v):
        # SCREAMING_SNAKE_CASE is a constant or an env reference, e.g.
        # `secretAccessKey: S3_SECRET_KEY`. Found in backups.service.ts:951 and
        # fixed as a rule rather than exempted: a source file should never need
        # an entry in the exemption list.
        return False
    if is_template(v) or is_dummy(v):
        return False
    if REFERENCE.search(v):
        return False
    if " " in v or "\t" in v:
        return False                      # prose, e.g. i18n `new_password: 'New password'`
    if not re.search(r"[A-Za-z]", v):
        return False
    # a path, a url without credentials, a css colour, a version — not a secret
    if v.startswith(("/", "./", "../", "http://", "https://", "#")):
        return False
    if re.fullmatch(r"[0-9a-fA-F]{7,40}", v) and len(v) in (7, 8):
        return False                      # a short git sha
    return True


def scan_text(text: str, filename: str) -> list[dict]:
    findings: list[dict] = []
    for lineno, line in enumerate(text.split("\n"), 1):
        if not line.strip():
            continue
        for rule_id, rx, why in RULES:
            for m in rx.finditer(line):
                if rule_id == "R2":
                    value = m.group("val") or m.group("val2") or ""
                    if not looks_like_credential(value):
                        continue
                elif "val" in rx.groupindex and m.group("val"):
                    value = m.group("val")
                else:
                    value = m.group(0)
                if rule_id in ("R1", "R5"):
                    if is_template(value):
                        continue
                    # the whole authority, to judge "both ends are dummies"
                    auth = m.group(0)
                    user = re.sub(r"^[^:]+://", "", auth).rsplit(":", 1)[0]
                    # an EMPTY username counts as a dummy: `redis://:password@host`
                    # is how every Redis document writes the placeholder form
                    if (is_dummy(user) or user == "") and is_dummy(value):
                        continue
                    if REFERENCE.search(value):
                        continue
                elif rule_id == "R4":
                    value = m.group(0)
                else:  # R3 shapes are credentials by construction
                    if is_template(value):
                        continue
                findings.append({
                    "file": filename,
                    "line": lineno,
                    "rule": rule_id,
                    "why": why,
                    "masked": mask(value),
                    "context": mask_line(line, value),
                })
    # de-duplicate identical (file, line, rule) triples
    seen: set[tuple] = set()
    out = []
    for f in findings:
        k = (f["file"], f["line"], f["rule"])
        if k in seen:
            continue
        seen.add(k)
        out.append(f)
    return out


SKIP_DIRS = {".git", "node_modules", ".next", "dist", "build", "out", "coverage",
             ".turbo", ".cache", "__pycache__", ".venv", "venv"}
BINARY_EXT = {".png", ".jpg", ".jpeg", ".gif", ".ico", ".webp", ".woff", ".woff2",
              ".ttf", ".eot", ".pdf", ".zip", ".gz", ".tgz", ".bz2", ".7z", ".mp4",
              ".mov", ".wasm", ".pyc", ".so", ".dylib", ".class", ".jar", ".lock"}


def iter_files(root: str):
    """Every text file, INCLUDING git-ignored ones (.env, .env.local): a credential
    in an ignored file is still a credential in the delivery archive."""
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for name in sorted(filenames):
            ext = os.path.splitext(name)[1].lower()
            if ext in BINARY_EXT or name.endswith((".lock", ".map")):
                continue
            yield os.path.join(dirpath, name)


EXEMPTIONS_FILE = "scripts/secrets-exemptions.txt"


def load_exemptions(root: str) -> tuple[dict[tuple[str, str], str], str | None]:
    """Exact-path + rule exemptions, each with a reason. Returns the map and an
    error string if the file is malformed."""
    path = os.path.join(root, EXEMPTIONS_FILE)
    out: dict[tuple[str, str], str] = {}
    if not os.path.exists(path):
        return out, None
    for lineno, raw in enumerate(open(path, encoding="utf8"), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(None, 2)
        if len(parts) < 3:
            return out, f"{EXEMPTIONS_FILE}:{lineno} needs `PATH RULE  # reason`"
        rel, rule, reason = parts[0], parts[1].upper(), parts[2]
        out[(rel, rule)] = reason
    return out, None


def find_repo_base(root: str) -> str:
    """The directory the exemption paths are relative to.

    A delivery archive is extracted into an empty directory and contains ONE
    wrapper folder (`flexora/`), so findings come back as
    `flexora/apps/api/...` while the exemption list says `apps/api/...`. Rather
    than duplicate the list or loosen the matching, locate the tree that actually
    carries scripts/secrets-exemptions.txt and make paths relative to it.
    """
    if os.path.exists(os.path.join(root, EXEMPTIONS_FILE)):
        return root
    try:
        entries = sorted(os.listdir(root))
    except OSError:
        return root
    for entry in entries:
        cand = os.path.join(root, entry)
        if os.path.isdir(cand) and os.path.exists(os.path.join(cand, EXEMPTIONS_FILE)):
            return cand
    return root


# PHASE P5 — how many files the last scan_tree() actually read. A credential gate
# that prints findings but never says what it looked at can pass while scanning
# nothing at all: that is exactly what happened when package-release.sh pointed it
# at the unwrapped extraction root of a wrapped archive. Printed on every run.
LAST_SCANNED = 0


def scannable_file_count(root: str) -> int:
    """The number of text files iter_files() would yield for `root`.

    Exposed so a caller can prove the scan covered the tree: the gate in
    package-release.sh compares the reported scan count against this, using the
    very same iterator, so the two numbers cannot drift apart.
    """
    return sum(1 for _ in iter_files(root))


def scan_tree(root: str, use_exemptions: bool = True) -> tuple[list[dict], list[str]]:
    """Returns (findings, stale exemption descriptions)."""
    global LAST_SCANNED
    LAST_SCANNED = 0
    base = find_repo_base(root)

    out: list[dict] = []
    for path in iter_files(root):
        LAST_SCANNED += 1
        try:
            with open(path, encoding="utf8", errors="strict") as fh:
                text = fh.read()
        except (UnicodeDecodeError, OSError, PermissionError):
            continue
        rel = os.path.relpath(path, base)
        out.extend(scan_text(text, rel))

    stale: list[str] = []
    if use_exemptions:
        exemptions, err = load_exemptions(base)
        if err:
            return [{"file": EXEMPTIONS_FILE, "line": 0, "rule": "E0", "why": err,
                     "masked": "", "context": err}], stale
        if exemptions:
            matched: set[tuple[str, str]] = set()
            kept: list[dict] = []
            for f in out:
                key = (f["file"], f["rule"])
                if key in exemptions:
                    matched.add(key)
                    f = dict(f)
                    f["exempt"] = exemptions[key]
                    continue
                kept.append(f)
            out = kept
            for key, reason in sorted(exemptions.items()):
                if key in matched:
                    continue
                # An exemption is STALE only when the file is still here and no
                # longer triggers the rule. If the file itself is absent — e.g.
                # scanning a delivery archive, which deliberately excludes .env*
                # — the entry is simply not applicable, not rotting.
                if os.path.exists(os.path.join(base, key[0])):
                    stale.append(f"{key[0]} {key[1]} — the file is present but no longer matches; delete the line ({reason})")
    return out, stale


# ------------------------------------------------------------------ self-test --
SELF_TEST_ROWS: list[tuple[str, str, bool]] = [
    # (content, filename, expected_to_be_flagged)
    # ---- must FAIL: the brief's list, in the file types it names
    ("const url = 'redis://:X9mQ2vLp7wR4tZ8y@redis:6379';", "src/config/redis.ts", True),
    ("REDIS_URL=redis://:X9mQ2vLp7wR4tZ8y@localhost:6379", "scripts/rotate.sh", True),
    ("REDIS_URL=rediss://:X9mQ2vLp7wR4tZ8y@cache.prod:6379", "notes.env-style.txt", True),
    ("url = 'rediss://default:X9mQ2vLp7wR4tZ8y@redis.example.com:6379'", "src/cache.py", True),
    ("postgresql://svc:Tr0ub4dorAnd3x9@db.prod:5432/app", "docs/RUNBOOK.md", True),
    ("JWT_ACCESS_SECRET=9f2c1a4b7e8d3f6a1c5b9e2d7f4a8c31b6e9d2f5a8c1b4e7d0f3a6c9b2e5d8f1", "ci/pipeline.yml", True),
    ('api_key: "AIzaSyDxY7mK2pQ9vL4nR8tB3wZ6jH1cF5gA0eUo"', "config/app.yaml", True),
    ("STRIPE_KEY=sk_live_4eC39HqLyjWDarjtT1zdp7dc", "src/payments.ts", True),
    ("-----BEGIN PRIVATE KEY-----", "certs/server.key", True),
    ("aws_access_key_id = AKIAIOSFODNN7EXAMPLE", "deploy/iam.tf", True),
    ("GITHUB_TOKEN=ghp_16C7e42F292c6912E7710c838347Ae178B4a", "scripts/release.sh", True),
    ("amqp://rabbit:W1nt3rSoldier99@mq.internal:5672/", "src/queue.ts", True),
    ("mongodb+srv://app:Tr0ub4dorAnd3x9@cluster0.example.mongodb.net/db", "README.md", True),
    ("https://deploy:X9mQ2vLp7wR4tZ8y@api.example.com/hook", "docs/deploy.md", True),
    # ---- must PASS: templates, references, dummies, prose
    ("REDIS_URL=redis://:${REDIS_PASSWORD}@redis:6379", "docker-compose.yml", False),
    ("DATABASE_URL=postgresql://user:CHANGE_ME@db:5432/app", ".env.example", False),
    ("DATABASE_URL=postgresql://postgres:postgres@db:5432/app", "docker-compose.test.yml", False),
    ("DATABASE_URL=postgresql://build:build@localhost:5432/build", "apps/api/Dockerfile", False),
    ("postgres://<user>:<password>@<host>:5432/<database>", "docs/DATABASE_SETUP.md", False),
    ("new_password: 'New password',", "src/i18n/en.ts", False),
    ("new_password: 'كلمة المرور الجديدة',", "src/i18n/ar.ts", False),
    ("const secret = process.env.JWT_ACCESS_SECRET;", "src/auth.ts", False),
    ("password: os.environ['DB_PASSWORD'],", "app/settings.py", False),
    ("REDIS_URL=redis://:$REDIS_PASSWORD@redis:6379", "docker-compose.yml", False),
    ("command: redis-server --requirepass \"$$REDIS_PASSWORD\"", "docker-compose.yml", False),
    ("# password=xxx", "notes.txt", False),
    ("apiKey: {{ secrets.ANTHROPIC_API_KEY }}", ".github/workflows/ci.yml", False),
    ("DATABASE_URL=postgresql://app:***@db:5432/app", "docs/SECRET_ROTATION.md", False),
    ("echo \"SUPER_ADMIN_PASSWORD=$(openssl rand -base64 24 | tr '+/' '-_')\" >> .env", "README.md", False),
    ("DATABASE_URL=postgresql://app:${DB_PW}@db:5432/app", "docker-compose.yml", False),
    ("DATABASE_URL=postgresql://app:<OWNER_PASSWORD>@db:5432/app", "docs/DEPLOYMENT.md", False),
    ("redis://:pw@redis:6379", "docs/notes.md", True),   # short but a real literal password
    ("rediss://:X9mQ2vLp7wR4tZ8y@cache:6379", "src/x.ts", True),
]


def self_test() -> int:
    passed = failed = 0
    for content, filename, should_flag in SELF_TEST_ROWS:
        found = scan_text(content, filename)
        flagged = len(found) > 0
        ok = flagged == should_flag
        want = "must FAIL (be reported)" if should_flag else "must PASS (stay clean)"
        if ok:
            passed += 1
            detail = found[0]["rule"] + " " + found[0]["masked"] if found else "clean"
            print(f"    PASS  {want}: {filename[:34]:<34} -> {detail}")
        else:
            failed += 1
            print(f"    FAIL  {want}: {filename} :: {content[:70]}")
            print(f"          got {len(found)} finding(s): {[f['rule'] for f in found]}")
    # masking must never reproduce the value
    leaky = scan_text("postgresql://svc:Tr0ub4dorAnd3x9@db.prod:5432/app", "x.md")
    if leaky and "Tr0ub4dorAnd3x9" not in json.dumps(leaky) and leaky[0]["masked"] == "Tr0***":
        passed += 1
        print("    PASS  the reported value is masked to 3 characters + *** (context included)")
    else:
        failed += 1
        print(f"    FAIL  masking: {leaky}")
    total = passed + failed
    print(f"  SELF-TEST: {passed}/{total} rows behaved correctly "
          f"({sum(1 for r in SELF_TEST_ROWS if r[2])} must-fail, "
          f"{sum(1 for r in SELF_TEST_ROWS if not r[2])} must-pass, 1 masking check)")
    return 0 if failed == 0 else 2


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("target", nargs="?", default=".")
    ap.add_argument("--label", default=None)
    ap.add_argument("--self-test", action="store_true")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--quiet", action="store_true")
    ap.add_argument("--max", type=int, default=40)
    ap.add_argument("--no-exemptions", action="store_true",
                    help="ignore scripts/secrets-exemptions.txt (use this on a delivery archive)")
    args = ap.parse_args()

    if args.self_test:
        return self_test()

    if not os.path.isdir(args.target):
        print(f"ERROR: {args.target} is not a directory", file=sys.stderr)
        return 2
    findings, stale = scan_tree(args.target, use_exemptions=not args.no_exemptions)
    label = args.label or os.path.basename(os.path.abspath(args.target))
    for item in stale:
        print(f"STALE EXEMPTION {item}")

    if args.json:
        print(json.dumps({"label": label, "findings": findings}, indent=2))
        return 1 if findings else 0

    if not args.quiet:
        base = find_repo_base(args.target)
        note = "" if os.path.abspath(base) == os.path.abspath(args.target) else f" (paths relative to {os.path.relpath(base, args.target)}/)"
        print(f"── credential scan: {label}{note} " + "─" * max(0, 40 - len(label) - len(note)))
    if findings:
        print(
            f"FAIL {len(findings)} credential-looking value(s) — masked, never echoed "
            f"(files scanned: {LAST_SCANNED}):"
        )
        if stale:
            return 1
        for f in findings[: args.max]:
            print(f"  {f['file']}:{f['line']}  {f['rule']}  {f['masked']}   ({f['why']})")
            print(f"      {f['context']}")
        if len(findings) > args.max:
            print(f"  … and {len(findings) - args.max} more")
        print("LEAK CHECK FAILED — replace every value above with a placeholder or a")
        print("reference, and rotate the exposed credential. Never commit a real secret.")
        return 1
    if stale:
        print("FAIL the exemption list has entries that match nothing (see STALE EXEMPTION above)")
        return 1
    if not args.quiet:
        # PHASE P5 — always say what was covered, so "0 findings" can never be
        # confused with "nothing was scanned".
        print(f"ok   no credential-looking strings (files scanned: {LAST_SCANNED})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
