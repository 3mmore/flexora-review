#!/usr/bin/env bash
# Test each Node app using only its own source, manifest and lockfile.
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
node -e 'const [a,b]=process.versions.node.split(".").map(Number);if(a<22||(a===22&&b<12)){console.error("Node 22.12 or newer is required");process.exit(1)}'
tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
for app in apps/api apps/web license-server; do
  echo "=== isolated build: $app ==="
  mkdir -p "$tmp/$app"
  (cd "$root/$app" && tar --exclude=node_modules --exclude=.next --exclude=dist --exclude=build --exclude=coverage --exclude='.env*' --exclude='*.tsbuildinfo' --exclude='.config' -cf - .) | (cd "$tmp/$app" && tar -xf -)
  (
    cd "$tmp/$app"
    npm ci --no-audit --no-fund
    case "$app" in
      apps/api) npm run prisma:generate; npm run build ;;
      apps/web) NEXT_TELEMETRY_DISABLED=1 NEXT_PUBLIC_API_URL='' API_PROXY_TARGET='http://api:4000' npm run build ;;
      license-server) ./node_modules/.bin/tsc --noEmit ;;
    esac
  )
done
echo 'PASS isolated Node app builds'
