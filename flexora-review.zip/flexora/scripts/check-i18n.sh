#!/bin/bash
# FLEXORA i18n Key Parity Check
# Fails if en.ts and ar.ts keys don't match exactly.

AR_KEYS=$(grep -oE "^\s{0,4}[a-zA-Z_][a-zA-Z0-9_]*\s*:" apps/web/src/lib/i18n/ar.ts | sed -E 's/^\s*//; s/\s*:$//' | sort -u)
EN_KEYS=$(grep -oE "^\s{0,4}[a-zA-Z_][a-zA-Z0-9_]*\s*:" apps/web/src/lib/i18n/en.ts | sed -E 's/^\s*//; s/\s*:$//' | sort -u)

DIFF_AR_EN=$(comm -23 <(echo "$AR_KEYS") <(echo "$EN_KEYS"))
DIFF_EN_AR=$(comm -23 <(echo "$EN_KEYS") <(echo "$AR_KEYS"))

RET=0

if [ -n "$DIFF_AR_EN" ]; then
  echo "❌ Error: Keys found in ar.ts but missing in en.ts:"
  echo "$DIFF_AR_EN"
  RET=1
fi

if [ -n "$DIFF_EN_AR" ]; then
  echo "❌ Error: Keys found in en.ts but missing in ar.ts:"
  echo "$DIFF_EN_AR"
  RET=1
fi

if [ $RET -eq 0 ]; then
  echo "✅ i18n key parity check passed."
fi

exit $RET
