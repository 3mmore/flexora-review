#!/usr/bin/env python3
"""
PHASE O1.2 — compose/environment guard.

Why this exists
---------------
`docker-compose.yml`'s `environment:` block is a WHITELIST. A variable the
application reads but compose does not pass simply does not exist inside the
container, and the failure surfaces at runtime, far from its cause. This already
bit the project: the production validator required `COOKIE_SECURE`, compose never
passed it, and production mode could not boot.

A hand-written list rots. This script derives the list from the source instead:

  1. every `process.env.NAME`, `process.env['NAME']` and
     `const { NAME } = process.env` read in `apps/api/src`, EXCLUDING specs and
     test directories;
  2. every name asserted by `apps/api/src/config/env-validation.ts`
     (REQUIRED_ENV, OPTIONAL_SECRETS, SECRET_RULES keys, RUNTIME_DIR_VARS,
     DISTINCT_GROUPS, DISTINCT_FROM_ALL);
  3. every `NEXT_PUBLIC_*` read in `apps/web/src` — these are inlined at BUILD
     time, so they must appear in the web service's build args, not only in its
     runtime environment.

and fails when a name is neither passed to the right service nor listed with a
one-line reason in `scripts/compose-env-exemptions.txt`.

The compose file is parsed with a real YAML parser (PyYAML), so map form,
list form (`- NAME=value`), `env_file`, anchors and merge keys are all handled.
Grepping compose would silently miss most of those.

It also encodes the structural rules from O1.1/O1.3/O1.5 so they cannot rot:
  C1   every name the app reads is passed to the api service or exempted
  C1b  no stale exemption (the name is no longer read anywhere)
  C2   a variable the production validator requires uses `${NAME:?...}`; the only
       accepted alternative is a DERIVED default (nested interpolation with no
       hardcoded credential, e.g. `redis://:${REDIS_PASSWORD}@redis:6379`)
  C3   api and web NODE_ENV default to production: `${NODE_ENV:-production}`
  C4   the api service holds no owner credential (POSTGRES_PASSWORD,
       POSTGRES_USER, REDIS_PASSWORD) and its DIRECT_URL is the same restricted
       connection string as DATABASE_URL
  C5   every NEXT_PUBLIC_* is a web build arg
  C5b  API_PROXY_TARGET is a web build arg — next.config.mjs bakes the /api/*
       rewrite DESTINATION at build time and falls back to http://localhost:4000
  C6   a one-shot `migrate` service exists (restart "no", owner URLs, `prisma
       migrate deploy`, waits for a HEALTHY db) and api depends on it with
       `condition: service_completed_successfully`
  C7   neither api Dockerfile runs migrations in CMD/ENTRYPOINT
  C8   both web Dockerfiles set HOSTNAME=0.0.0.0 and copy `.next/static` and
       `public` next to the standalone server
  C9   both web Dockerfiles accept ARG API_PROXY_TARGET (and export it to the
       build), and apps/web's build script runs the loopback build check

Secrets are never printed: for a secret-shaped name the script prints only the
interpolation KIND (required / derived-default / literal) — see `mask()`.

Usage
-----
  python3 scripts/check-compose-env.py                 # check the repo
  python3 scripts/check-compose-env.py --self-test     # prove the guard fails correctly
  python3 scripts/check-compose-env.py --print-inventory
Exit status: 0 = clean, 1 = findings, 2 = unusable environment.

Run by: .github/workflows/ci.yml (job `guard-compose-env`) and
scripts/package-release.sh (a packaging failure, not a warning).
"""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sys
import tempfile

try:
    import yaml
except ImportError:  # pragma: no cover
    sys.stderr.write(
        "FATAL: PyYAML is required (python3 -c 'import yaml'). The compose file must be\n"
        "       parsed as YAML, not grepped: map form, list form, env_file, anchors and\n"
        "       merge keys all occur in compose files.\n"
    )
    sys.exit(2)

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Names that are secret-shaped: their compose expression is never echoed.
SECRETISH = re.compile(r"(SECRET|PASSWORD|PASSWD|PWD|_KEY$|^ENCRYPTION|TOKEN|CREDENTIAL|API_KEY|DSN)", re.I)
# Credential connection strings, mirroring env-validation.ts's own patterns.
CREDENTIAL_URL = re.compile(r"(DATABASE|DIRECT|DB|POSTGRES|PG_|PGSQL|REDIS|CACHE|MEMCACHED|MONGO).*(URL|URI|DSN|CONNECTION)", re.I)

SKIP_DIR = re.compile(r"(^|/)(test|tests|__tests__|dist|node_modules)(/|$)")
SKIP_FILE = re.compile(r"\.(spec|test)\.tsx?$")


def paths(repo: str) -> dict[str, str]:
    return {
        "compose": os.path.join(repo, "docker-compose.yml"),
        "exemptions": os.path.join(repo, "scripts", "compose-env-exemptions.txt"),
        "api_src": os.path.join(repo, "apps", "api", "src"),
        "web_src": os.path.join(repo, "apps", "web", "src"),
        "validator": os.path.join(repo, "apps", "api", "src", "config", "env-validation.ts"),
        "api_dockerfiles": [os.path.join(repo, "Dockerfile.api"), os.path.join(repo, "apps", "api", "Dockerfile")],
        "web_dockerfiles": [os.path.join(repo, "Dockerfile.web"), os.path.join(repo, "apps", "web", "Dockerfile")],
    }


# ─────────────────────────────────────────────────────────────────────────────
# inventory: what the application actually reads
# ─────────────────────────────────────────────────────────────────────────────
def _walk_ts(root: str):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in ("node_modules", "dist", ".next")]
        rel = os.path.relpath(dirpath, root).replace(os.sep, "/")
        if rel != "." and SKIP_DIR.search(rel):
            continue
        for name in filenames:
            if not name.endswith((".ts", ".tsx")) or SKIP_FILE.search(name):
                continue
            yield os.path.join(dirpath, name)


ENV_PATTERNS = (
    re.compile(r"process\.env\.([A-Za-z_][A-Za-z0-9_]*)"),
    re.compile(r"process\.env\[\s*['\"]([^'\"]+)['\"]\s*\]"),
)
DESTRUCTURE = re.compile(r"(?:const|let|var)\s*\{([^}]+)\}\s*=\s*process\.env")


def api_env_reads(repo: str = REPO) -> dict[str, list[str]]:
    """Every process.env name read by application code (specs/tests excluded)."""
    api_src = paths(repo)["api_src"]
    found: dict[str, set[str]] = {}
    for path in _walk_ts(api_src):
        rel = os.path.relpath(path, api_src)
        try:
            src = open(path, encoding="utf8", errors="replace").read()
        except OSError:
            continue
        names: set[str] = set()
        for pat in ENV_PATTERNS:
            names.update(pat.findall(src))
        for group in DESTRUCTURE.findall(src):
            for part in group.split(","):
                token = part.split(":")[0].split("=")[0].strip()
                if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", token or ""):
                    names.add(token)
        for n in names:
            found.setdefault(n, set()).add(rel)
    return {k: sorted(v) for k, v in sorted(found.items())}


def _exported_string_list(src: str, name: str) -> list[str]:
    m = re.search(
        r"export const " + re.escape(name) + r"[^=]*=\s*(\[[\s\S]*?\]|\{[\s\S]*?\})\s*(?:as const)?;",
        src,
    )
    if not m:
        return []
    return sorted(set(re.findall(r"'([A-Z][A-Z0-9_]{2,})'", m.group(1))))


def validator_names(repo: str = REPO) -> dict[str, list[str]]:
    src = open(paths(repo)["validator"], encoding="utf8", errors="replace").read()
    return {
        "REQUIRED_ENV": _exported_string_list(src, "REQUIRED_ENV"),
        "OPTIONAL_SECRETS": _exported_string_list(src, "OPTIONAL_SECRETS"),
        "RUNTIME_DIR_VARS": _exported_string_list(src, "RUNTIME_DIR_VARS"),
        "DISTINCT_GROUPS": _exported_string_list(src, "DISTINCT_GROUPS"),
        "DISTINCT_FROM_ALL": _exported_string_list(src, "DISTINCT_FROM_ALL"),
        "SECRET_RULES": sorted(set(re.findall(r"key:\s*'([A-Z0-9_]+)'", src))),
    }


def web_public_reads(repo: str = REPO) -> dict[str, list[str]]:
    web_src = paths(repo)["web_src"]
    found: dict[str, set[str]] = {}
    for path in _walk_ts(web_src):
        rel = os.path.relpath(path, web_src)
        src = open(path, encoding="utf8", errors="replace").read()
        names = set(re.findall(r"process\.env\.(NEXT_PUBLIC_[A-Z0-9_]+)", src))
        names |= set(re.findall(r"process\.env\[\s*['\"](NEXT_PUBLIC_[A-Z0-9_]+)['\"]", src))
        for n in names:
            found.setdefault(n, set()).add(rel)
    return {k: sorted(v) for k, v in sorted(found.items())}


# ─────────────────────────────────────────────────────────────────────────────
# compose parsing and interpolation grammar
# (Compose reference: ${VAR}, ${VAR:-default}, ${VAR-default}, ${VAR:?error},
#  ${VAR?error}, ${VAR:+alt}, ${VAR+alt}, nesting ${V:-${FOO}}, `$$` = literal $)
# ─────────────────────────────────────────────────────────────────────────────
INTERP = re.compile(r"^\$\{([A-Za-z_][A-Za-z0-9_]*)(:?[-?]|:\?|\+|:\+)?(.*)\}$", re.S)


def classify(expr) -> tuple[str, str]:
    """(kind, source-var) for a compose value expression.

    kind: required (`${V:?msg}`/`${V?msg}`), default (`${V:-x}`/`${V-x}`),
    alternative (`${V:+x}`), bare (`${V}`), literal, empty.
    """
    if expr is None:
        return "empty", ""
    text = str(expr).strip()
    m = INTERP.match(text)
    if not m:
        return ("literal" if text else "empty"), text
    op = m.group(2) or ""
    if op in (":?", "?"):
        return "required", m.group(1)
    if op in (":-", "-"):
        return "default", m.group(1)
    if op in (":+", "+"):
        return "alternative", m.group(1)
    return "bare", m.group(1)


HARDCODED_CREDENTIAL = re.compile(r":[^/\s@]+@")


def derived_default(expr) -> bool:
    """True when a `${VAR:-default}` default is *derived*, not hardcoded.

    Derived = the default itself interpolates at least one other variable AND,
    once every `${...}` span is stripped, no credential-shaped literal remains.
    `redis://:${REDIS_PASSWORD}@redis:6379` qualifies: the password comes from the
    operator's environment and nothing secret is written in the file.
    `${JWT_ACCESS_SECRET:-changeme}` does not — `changeme` is a hardcoded secret
    default, exactly what rule C2 exists to prevent.
    """
    m = INTERP.match(str(expr).strip())
    if not m or (m.group(2) or "") not in (":-", "-"):
        return False
    default = m.group(3) or ""
    if "${" not in default:
        return False
    residual = re.sub(r"\$\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}", "", default)
    return not HARDCODED_CREDENTIAL.search(residual)


def service_env(service: dict, repo: str = REPO) -> dict[str, object]:
    """Names passed to a service: map form, list form and env_file."""
    env: dict[str, object] = {}
    raw = service.get("environment")
    if isinstance(raw, dict):
        for k, v in raw.items():
            env[str(k)] = v
    elif isinstance(raw, list):
        for item in raw:
            item = str(item)
            key = item.split("=", 1)[0].strip()
            env[key] = item.split("=", 1)[1] if "=" in item else None
    for ref in service.get("env_file") or []:
        path = ref if isinstance(ref, str) else (ref or {}).get("path")
        if not path:
            continue
        full = path if os.path.isabs(path) else os.path.join(repo, path)
        if not os.path.exists(full):
            continue  # a git-ignored local .env: its names still come from compose
        for line in open(full, encoding="utf8", errors="replace"):
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            env.setdefault(line.split("=", 1)[0].strip(), None)
    return env


def build_args(service: dict) -> dict[str, object]:
    build = service.get("build") or {}
    if isinstance(build, str):
        return {}
    args = build.get("args") or {}
    if isinstance(args, list):
        out = {}
        for a in args:
            a = str(a)
            out[a.split("=", 1)[0].strip()] = a.split("=", 1)[1] if "=" in a else None
        return out
    return {str(k): v for k, v in args.items()}


def load_compose(path: str) -> dict:
    with open(path, encoding="utf8") as fh:
        doc = yaml.safe_load(fh)
    if not isinstance(doc, dict) or "services" not in doc:
        raise SystemExit(f"FATAL: {path} has no `services:` mapping")
    return doc


def mask(name: str, expr) -> str:
    """Describe a compose expression WITHOUT ever printing a secret's text."""
    kind, _ = classify(expr)
    if SECRETISH.search(name) or CREDENTIAL_URL.search(name):
        return f"<{kind}>"
    if expr is None:
        return "<unset>"
    return str(expr)


def load_exemptions(path: str) -> dict[str, str]:
    out: dict[str, str] = {}
    if not os.path.exists(path):
        return out
    for lineno, line in enumerate(open(path, encoding="utf8"), 1):
        line = line.rstrip("\n")
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        parts = re.split(r"\s+#|\s{2,}|\t", line.strip(), maxsplit=1)
        name = parts[0].strip()
        reason = parts[1].strip().lstrip("#").strip() if len(parts) > 1 else ""
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name):
            raise SystemExit(f"FATAL: {path}:{lineno} must start with a variable name: {line!r}")
        if not reason:
            raise SystemExit(f"FATAL: {path}:{lineno} needs a one-line reason after the name: {name}")
        out[name] = reason
    return out


# ─────────────────────────────────────────────────────────────────────────────
# checks
# ─────────────────────────────────────────────────────────────────────────────
def run_checks(compose_path: str | None = None, repo: str = REPO, quiet: bool = False):
    """Return (findings, notes). findings are failures; notes are accepted-by-design."""
    P = paths(repo)
    compose_path = compose_path or P["compose"]
    findings: list[str] = []
    notes: list[str] = []

    doc = load_compose(compose_path)
    services = doc.get("services") or {}
    for needed in ("api", "web"):
        if needed not in services:
            findings.append(f"compose has no `{needed}` service")
    if findings:
        return findings, notes

    api_env = service_env(services["api"], repo)
    web_env = service_env(services["web"], repo)
    web_args = build_args(services["web"])
    exemptions = load_exemptions(P["exemptions"])

    reads = api_env_reads(repo)
    validator = validator_names(repo)
    required = set(validator["REQUIRED_ENV"]) | set(validator["SECRET_RULES"])
    asserted = {n for v in validator.values() for n in v}
    needed_names = (set(reads) | asserted) - {"process"}

    # ── C1 ──────────────────────────────────────────────────────────────────
    for name in sorted(n for n in needed_names if n not in api_env and n not in exemptions):
        where = ", ".join(reads.get(name, [])[:2]) or "config/env-validation.ts"
        findings.append(
            f"C1 api environment is missing {name} (read in {where}) — pass it, "
            "or list it in scripts/compose-env-exemptions.txt with a one-line reason"
        )

    # ── C1b ─────────────────────────────────────────────────────────────────
    for name in sorted(exemptions):
        if name not in needed_names:
            findings.append(
                f"C1b stale exemption: {name} is no longer read by apps/api/src nor asserted "
                "by config/env-validation.ts — delete the line"
            )

    # ── C2 ──────────────────────────────────────────────────────────────────
    for name in sorted(required & set(api_env)):
        expr = api_env[name]
        kind, _ = classify(expr)
        if kind in ("literal", "empty"):
            findings.append(
                f"C2 {name} is required by the production validator but compose hardcodes it "
                f"({kind}) — use ${{{name}:?required}}"
            )
        elif kind == "bare":
            findings.append(
                f"C2 {name} is required but compose uses the bare ${{{name}}} form, which Compose "
                "resolves to an EMPTY string when unset (warning only) — use "
                f"${{{name}:?required}} so compose refuses to start"
            )
        elif kind == "default":
            if derived_default(expr):
                notes.append(
                    f"C2 {name}: required, and compose supplies a DERIVED default (nested "
                    "interpolation, no hardcoded credential) — accepted by design"
                )
            else:
                findings.append(
                    f"C2 {name} is required by the production validator but compose supplies a "
                    f"default ({mask(name, expr)}) — a default for a secret is how `changeme` "
                    f"reaches production; use ${{{name}:?required}}"
                )

    # ── C3 ──────────────────────────────────────────────────────────────────
    for svc, env in (("api", api_env), ("web", web_env)):
        if "NODE_ENV" not in env:
            findings.append(f"C3 {svc} does not set NODE_ENV — it must be ${{NODE_ENV:-production}}")
            continue
        text = str(env["NODE_ENV"]).strip()
        if text != "${NODE_ENV:-production}":
            findings.append(
                f"C3 {svc} NODE_ENV must default to production (`${{NODE_ENV:-production}}`), found `{text}`"
            )

    # ── C4 ──────────────────────────────────────────────────────────────────
    for forbidden in ("POSTGRES_PASSWORD", "POSTGRES_USER", "REDIS_PASSWORD"):
        if forbidden in api_env:
            findings.append(
                f"C4 api environment must not contain {forbidden} — this process faces the "
                "internet and that value owns the database / authenticates to Redis directly"
            )
    if "DIRECT_URL" in api_env:
        _, direct_src = classify(api_env["DIRECT_URL"])
        _, db_src = classify(api_env.get("DATABASE_URL"))
        if direct_src != "DATABASE_URL" or db_src != "DATABASE_URL":
            findings.append(
                "C4 api DIRECT_URL must be the SAME restricted connection string as DATABASE_URL "
                f"(found {mask('DIRECT_URL', api_env['DIRECT_URL'])} vs {mask('DATABASE_URL', api_env.get('DATABASE_URL'))}); "
                "the owner-privileged URL belongs only to the one-shot `migrate` service"
            )

    # ── C5 ──────────────────────────────────────────────────────────────────
    web_public = web_public_reads(repo)
    for name in sorted(web_public):
        if name not in web_args and name not in exemptions:
            findings.append(
                f"C5 web build args are missing {name} (read in {', '.join(web_public[name][:2])}) — "
                "NEXT_PUBLIC_* values are inlined at BUILD time, so a runtime env entry is not enough"
            )

    # ── C5b (PHASE O1.5) ───────────────────────────────────────────────────
    # Not covered by C5's inventory: API_PROXY_TARGET is read in next.config.mjs,
    # not in apps/web/src, and it is not a NEXT_PUBLIC_* name. It still has to be
    # a BUILD arg, because the rewrite destination is baked into
    # .next/routes-manifest.json — a runtime env entry cannot change it.
    if "API_PROXY_TARGET" not in web_args and "API_PROXY_TARGET" not in exemptions:
        findings.append(
            "C5 web build args are missing API_PROXY_TARGET — next.config.mjs bakes the /api/* "
            "rewrite destination at BUILD time and falls back to http://localhost:4000, which is "
            "fatal inside a container (scripts/check-web-build.sh catches the resulting artifact)"
        )

    # ── C6 ──────────────────────────────────────────────────────────────────
    migrate = services.get("migrate")
    if not migrate:
        findings.append("C6 compose has no one-shot `migrate` service — migrations must not run on every api start")
    else:
        if str(migrate.get("restart", "")).strip('"').lower() != "no":
            findings.append(f"C6 migrate must have restart: \"no\" (found {migrate.get('restart')!r})")
        m_env = service_env(migrate, repo)
        for var in ("DIRECT_URL", "DATABASE_URL"):
            if var not in m_env:
                findings.append(f"C6 migrate environment is missing {var}")
            elif classify(m_env[var])[0] != "required":
                findings.append(f"C6 migrate {var} must be ${{{var}:?required}} (found {mask(var, m_env[var])})")
        cmd = migrate.get("command")
        joined = " ".join(map(str, cmd)) if isinstance(cmd, list) else str(cmd or "")
        if "migrate deploy" not in joined:
            findings.append(f"C6 migrate command must run `prisma migrate deploy` (found {joined!r})")
        deps = migrate.get("depends_on")
        db_cond = ((deps or {}).get("db") or {}).get("condition") if isinstance(deps, dict) else None
        db_health = (services.get("db") or {}).get("healthcheck")
        if db_cond != "service_healthy" or not db_health:
            findings.append(
                "C6 migrate must wait for a HEALTHY db (`depends_on: db: condition: service_healthy` "
                f"plus a db healthcheck); found condition={db_cond!r}, healthcheck={'yes' if db_health else 'no'} — "
                "a one-shot job with restart \"no\" gets no retry, so a cold-start race fails the stack"
            )
        deps = services["api"].get("depends_on")
        ok = isinstance(deps, dict) and (deps.get("migrate") or {}).get("condition") == "service_completed_successfully"
        if not ok:
            findings.append(
                "C6 api must depend on migrate with `condition: service_completed_successfully` "
                f"(found {deps!r}) — otherwise the api can serve traffic on an unmigrated schema"
            )

    # ── C7 / C8: the Dockerfiles ────────────────────────────────────────────
    for path in P["api_dockerfiles"]:
        rel = os.path.relpath(path, repo)
        if not os.path.exists(path):
            findings.append(f"C7 {rel} does not exist (the sibling search expects both api Dockerfiles)")
            continue
        for line in open(path, encoding="utf8", errors="replace"):
            stripped = line.strip()
            if stripped.startswith(("CMD", "ENTRYPOINT")) and "migrate deploy" in stripped:
                findings.append(f"C7 {rel}: {stripped.split(' ', 1)[0]} still runs `prisma migrate deploy` on every start")

    for path in P["web_dockerfiles"]:
        rel = os.path.relpath(path, repo)
        if not os.path.exists(path):
            findings.append(f"C8 {rel} does not exist (the sibling search expects both web Dockerfiles)")
            continue
        text = open(path, encoding="utf8", errors="replace").read()
        if not re.search(r"^ENV\s+HOSTNAME[= ]0\.0\.0\.0", text, re.M):
            findings.append(f"C8 {rel}: missing `ENV HOSTNAME=0.0.0.0` (the standalone server must bind every interface)")
        if ".next/static" not in text:
            findings.append(f"C8 {rel}: does not copy `.next/static` next to the standalone server (pages would ship without CSS/JS)")
        if not re.search(r"COPY[^\n]*\bpublic\b", text):
            findings.append(f"C8 {rel}: does not copy `public/` next to the standalone server")
        # ── C9 (PHASE O1.5) ────────────────────────────────────────────────
        if "ARG API_PROXY_TARGET" not in text:
            findings.append(
                f"C9 {rel}: missing `ARG API_PROXY_TARGET` — next.config.mjs bakes the /api/* "
                "rewrite destination at build time and falls back to http://localhost:4000"
            )
        elif not re.search(r"API_PROXY_TARGET=\$\{?API_PROXY_TARGET\}?", text):
            findings.append(f"C9 {rel}: ARG API_PROXY_TARGET is never exported to the build via ENV")

    web_pkg = os.path.join(repo, "apps", "web", "package.json")
    if not os.path.exists(web_pkg):
        findings.append("C9 apps/web/package.json does not exist")
    else:
        build_script = (json.load(open(web_pkg, encoding="utf8")).get("scripts") or {}).get("build", "")
        if "check-no-loopback" not in build_script:
            findings.append(
                "C9 apps/web/package.json's build script does not run the loopback check "
                "(apps/web/scripts/check-no-loopback.mjs) — a production build could then ship a "
                "baked loopback address without failing"
            )

    if not quiet:
        print(f"compose file:        {os.path.relpath(compose_path, repo)}")
        print(f"api env entries:     {len(api_env)}")
        print(
            f"names the app needs: {len(needed_names)} (process.env reads: {len(reads)}, "
            f"validator-asserted: {len(asserted)})"
        )
        print(f"  passed to api:     {len([n for n in needed_names if n in api_env])}")
        print(f"  exempted:          {len(exemptions)}")
        print(f"web build args:      {len(web_args)} ({', '.join(sorted(web_args)) or 'none'})")
        for n in notes:
            print(f"  note  {n}")
    return findings, notes


# ─────────────────────────────────────────────────────────────────────────────
# self-test: the guard must fail, and fail naming the right thing
# ─────────────────────────────────────────────────────────────────────────────
# Every file a self-test case may mutate. Declared once and used both to build the
# throwaway repo and to restore it between cases, so the two lists cannot drift.
MUTABLE_FILES: tuple[str, ...] = (
    "docker-compose.yml",
    "Dockerfile.api",
    "Dockerfile.web",
    os.path.join("apps", "api", "Dockerfile"),
    os.path.join("apps", "web", "Dockerfile"),
    os.path.join("apps", "web", "package.json"),
)


def _temp_repo() -> str:
    """A throwaway repo: source trees symlinked (read-only use), the four
    Dockerfiles and docker-compose.yml copied so mutations cannot touch the real
    tree. This makes every self-test case exercise the REAL check code."""
    tmp = tempfile.mkdtemp(prefix="compose-guard-selftest-")
    os.makedirs(os.path.join(tmp, "apps", "api"), exist_ok=True)
    os.makedirs(os.path.join(tmp, "apps", "web"), exist_ok=True)
    os.symlink(paths(REPO)["api_src"], os.path.join(tmp, "apps", "api", "src"))
    os.symlink(paths(REPO)["web_src"], os.path.join(tmp, "apps", "web", "src"))
    os.symlink(os.path.join(REPO, "scripts"), os.path.join(tmp, "scripts"))
    for rel in MUTABLE_FILES:
        shutil.copy2(os.path.join(REPO, rel), os.path.join(tmp, rel))
    return tmp


def _in_service(text: str, service: str, old: str, new: str) -> str:
    """Replace `old` with `new` INSIDE one service block (2-space indent level)."""
    start = text.index(f"\n  {service}:\n")
    rest = text[start + 1:]
    m = re.search(r"\n  [A-Za-z_][A-Za-z0-9_]*:\n", rest[1:])
    end = start + 1 + (m.start() + 1 if m else len(rest))
    block = text[start:end]
    if block.count(old) != 1:
        raise AssertionError(f"self-test precondition: {old!r} occurs {block.count(old)}× in `{service}`")
    return text[:start] + block.replace(old, new, 1) + text[end:]


CASES: list[tuple[str, str, str, str, str]] = [
    # (label, target, old-text, new-text ("" = delete the line), expected finding substring)
    #  target: "compose:SERVICE" | "file:RELPATH"
    ("COOKIE_SECURE deleted from the api environment (the defect this guard exists for)",
     "compose:api", "      COOKIE_SECURE: ${COOKIE_SECURE:-}\n", "", "C1 api environment is missing COOKIE_SECURE"),
    ("a required secret given a hardcoded default",
     "compose:api", "JWT_ACCESS_SECRET: ${JWT_ACCESS_SECRET:?required}",
     "JWT_ACCESS_SECRET: ${JWT_ACCESS_SECRET:-changeme}", "C2 JWT_ACCESS_SECRET"),
    ("a required secret using the bare ${VAR} form (Compose resolves unset to '')",
     "compose:api", "ENCRYPTION_KEY: ${ENCRYPTION_KEY:?required}",
     "ENCRYPTION_KEY: ${ENCRYPTION_KEY}", "C2 ENCRYPTION_KEY"),
    ("NODE_ENV defaulting back to development",
     "compose:api", "NODE_ENV: ${NODE_ENV:-production}",
     "NODE_ENV: ${NODE_ENV:-development}", "C3 api NODE_ENV"),
    ("the database owner's password handed to the api",
     "compose:api", "      API_PORT: 4000\n",
     "      API_PORT: 4000\n      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:?required}\n",
     "C4 api environment must not contain POSTGRES_PASSWORD"),
    ("the raw REDIS_PASSWORD handed to the api as its own variable",
     "compose:api", "      API_PORT: 4000\n",
     "      API_PORT: 4000\n      REDIS_PASSWORD: ${REDIS_PASSWORD:?required}\n",
     "C4 api environment must not contain REDIS_PASSWORD"),
    ("an owner-privileged DIRECT_URL handed back to the api",
     "compose:api", "DIRECT_URL: ${DATABASE_URL:?required}",
     "DIRECT_URL: ${DIRECT_URL:?required}", "C4 api DIRECT_URL"),
    ("REDIS_URL's derived default turned into a hardcoded credential",
     "compose:api", "REDIS_URL: ${REDIS_URL:-redis://:${REDIS_PASSWORD}@redis:6379}",
     "REDIS_URL: ${REDIS_URL:-redis://:Sup3rSecretPW@redis:6379}", "C2 REDIS_URL"),
    ("a NEXT_PUBLIC_* dropped from the web build args",
     "compose:web", "        NEXT_PUBLIC_VAPID_PUBLIC_KEY: ${NEXT_PUBLIC_VAPID_PUBLIC_KEY:-}\n", "",
     "C5 web build args are missing NEXT_PUBLIC_VAPID_PUBLIC_KEY"),
    ("API_PROXY_TARGET dropped from the web build args",
     "compose:web", "        API_PROXY_TARGET: ${API_PROXY_TARGET:-http://api:4000}\n", "",
     "C5 web build args are missing API_PROXY_TARGET"),
    ("ARG API_PROXY_TARGET removed from a web Dockerfile",
     "file:apps/web/Dockerfile", "ARG API_PROXY_TARGET\n", "",
     "C9 apps/web/Dockerfile: missing `ARG API_PROXY_TARGET`"),
    ("the loopback build check unhooked from the web build script",
     "file:apps/web/package.json",
     '"build": "next build && node scripts/check-no-loopback.mjs"', '"build": "next build"',
     "C9 apps/web/package.json's build script does not run the loopback check"),
    ("the api no longer waits for migrations to succeed",
     "compose:api", "        condition: service_completed_successfully",
     "        condition: service_started", "C6 api must depend on migrate"),
    ("the migrate job no longer waits for a HEALTHY db",
     "compose:migrate", "        condition: service_healthy",
     "        condition: service_started", "C6 migrate must wait for a HEALTHY db"),
    ("migrate turned into a long-running service",
     "compose:migrate", 'restart: "no"', "restart: unless-stopped", "C6 migrate must have restart"),
    ("migrate no longer holds the owner DIRECT_URL",
     "compose:migrate", "      DIRECT_URL: ${DIRECT_URL:?required}\n", "", "C6 migrate environment is missing DIRECT_URL"),
    ("prisma migrate deploy put back into an api Dockerfile CMD",
     "file:apps/api/Dockerfile", "@@CMD@@", "", "C7 apps/api/Dockerfile"),
    ("HOSTNAME removed from the web image",
     "file:apps/web/Dockerfile", "ENV HOSTNAME=0.0.0.0\n", "", "C8 apps/web/Dockerfile: missing `ENV HOSTNAME"),
    (".next/static no longer copied into the web image",
     "file:apps/web/Dockerfile", "COPY --from=builder /app/.next/static ./.next/static\n", "",
     "C8 apps/web/Dockerfile: does not copy `.next/static`"),
    ("a stale exemption left behind in compose-env-exemptions.txt",
     "file:scripts/compose-env-exemptions.txt", "@@STALE@@", "", "C1b stale exemption"),
]

# Negative controls: things that must KEEP passing, so the guard is not simply
# "fail everything" (brief 0.3). Each is (label, mutation, substring that must
# NOT appear in the findings).
NEGATIVE_CONTROLS: list[tuple[str, str, str, str, str]] = [
    ("REDIS_URL's derived default (nested interpolation, no hardcoded credential) stays accepted",
     "compose:api", "      LOG_LEVEL: ${LOG_LEVEL:-}", "      LOG_LEVEL: ${LOG_LEVEL:-info}", "C2 REDIS_URL"),
    ("an optional pass-through keeps its empty default",
     "compose:api", "      COOKIE_SECURE: ${COOKIE_SECURE:-}", "      COOKIE_SECURE: ${COOKIE_SECURE:-true}", "COOKIE_SECURE"),
]


def self_test() -> int:
    original_compose = open(paths(REPO)["compose"], encoding="utf8").read()
    tmp = _temp_repo()
    failures = 0
    total = 0

    def restore_temp_repo() -> None:
        for rel in MUTABLE_FILES:            # the SAME list the temp repo was built from
            shutil.copy2(os.path.join(REPO, rel), os.path.join(tmp, rel))
        link = os.path.join(tmp, "scripts")
        if not os.path.islink(link):
            shutil.rmtree(link, ignore_errors=True)
            os.symlink(os.path.join(REPO, "scripts"), link)

    def mutate(target: str, old: str, new: str) -> None:
        kind, where = target.split(":", 1)
        if kind == "compose":
            mutated = _in_service(original_compose, where, old, new)
            open(os.path.join(tmp, "docker-compose.yml"), "w", encoding="utf8").write(mutated)
        elif where.startswith("scripts/"):
            os.unlink(os.path.join(tmp, "scripts"))          # drop the symlink
            os.makedirs(os.path.join(tmp, "scripts"), exist_ok=True)
            shutil.copy2(paths(REPO)["exemptions"], os.path.join(tmp, "scripts", "compose-env-exemptions.txt"))
            with open(os.path.join(tmp, "scripts", "compose-env-exemptions.txt"), "a", encoding="utf8") as fh:
                fh.write("TOTALLY_UNUSED_VARIABLE   # self-test: nothing in apps/api/src reads this name\n")
        else:
            path = os.path.join(tmp, where)
            text = open(path, encoding="utf8").read()
            if old == "@@CMD@@":
                text = re.sub(r'^CMD .*$', 'CMD ["sh", "-c", "npx prisma migrate deploy && node dist/src/main.js"]',
                              text, flags=re.M)
            else:
                if text.count(old) != 1:
                    raise AssertionError(f"{old!r} occurs {text.count(old)}x in {where}")
                text = text.replace(old, new, 1)
            open(path, "w", encoding="utf8").write(text)

    try:
        # positive control — a guard that only ever fails is worthless (brief 0.3)
        total += 1
        findings, notes = run_checks(paths(REPO)["compose"], REPO, quiet=True)
        if findings:
            failures += 1
            print("  FAIL  positive control: the real tree should pass, but produced:")
            for f in findings[:8]:
                print("        -", f[:150])
        elif not any("REDIS_URL" in n for n in notes):
            failures += 1
            print("  FAIL  positive control: REDIS_URL's derived default was not reported as an accepted note")
        else:
            print("  PASS  positive control: the real tree passes, and the derived-default exception is reported")
            print(f"        -> note: {[n for n in notes if 'REDIS_URL' in n][0][:120]}")

        for label, target, old, new, expect in CASES:
            total += 1
            restore_temp_repo()
            try:
                mutate(target, old, new)
                findings, _ = run_checks(os.path.join(tmp, "docker-compose.yml"), tmp, quiet=True)
            except AssertionError as err:
                failures += 1
                print(f"  FAIL  {label} -> precondition: {err}")
                continue
            hit = [f for f in findings if expect in f]
            if hit:
                print(f"  PASS  {label}")
                print(f"        -> {hit[0][:155]}")
            else:
                failures += 1
                print(f"  FAIL  {label} -> expected a finding containing {expect!r}; got {len(findings)}:")
                for f in findings[:5]:
                    print("        -", f[:150])

        for label, target, old, new, must_not in NEGATIVE_CONTROLS:
            total += 1
            restore_temp_repo()
            try:
                mutate(target, old, new)
                findings, _ = run_checks(os.path.join(tmp, "docker-compose.yml"), tmp, quiet=True)
            except AssertionError as err:
                failures += 1
                print(f"  FAIL  {label} -> precondition: {err}")
                continue
            if any(must_not in f for f in findings):
                failures += 1
                print(f"  FAIL  {label} -> good input was rejected:")
                for f in findings[:5]:
                    print("        -", f[:150])
            elif findings:
                failures += 1
                print(f"  FAIL  {label} -> unrelated findings appeared: {findings[0][:130]}")
            else:
                print(f"  PASS  negative control: {label}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print(f"\nSELF-TEST: {total - failures}/{total} cases behaved correctly "
          f"({len(CASES)} must-fail, {len(NEGATIVE_CONTROLS)} must-pass, 1 positive control)")
    return 1 if failures else 0


def print_inventory(repo: str = REPO) -> None:
    reads = api_env_reads(repo)
    validator = validator_names(repo)
    web = web_public_reads(repo)
    doc = load_compose(paths(repo)["compose"])
    api_env = service_env(doc["services"]["api"], repo)
    args = build_args(doc["services"]["web"])
    exemptions = load_exemptions(paths(repo)["exemptions"])
    print(f"process.env reads in apps/api/src (specs/tests excluded): {len(reads)}")
    for name in sorted(reads):
        state = "passed" if name in api_env else ("exempt" if name in exemptions else "MISSING")
        print(f"  {name:<32} {state:<8} {', '.join(reads[name][:2])}")
    print("\nvalidator-asserted names:")
    for key, names in validator.items():
        print(f"  {key:<18} {', '.join(names) if names else '(none)'}")
    print(f"\nNEXT_PUBLIC_* in apps/web/src: {len(web)}")
    for name in sorted(web):
        print(f"  {name:<32} {'build-arg' if name in args else 'MISSING'}   {', '.join(web[name][:2])}")
    print(f"\nexemptions ({len(exemptions)}):")
    for name in sorted(exemptions):
        print(f"  {name:<32} {exemptions[name][:110]}")


def main() -> int:
    ap = argparse.ArgumentParser(description="Guard: compose passes every variable the application reads.")
    ap.add_argument("--compose", default=None)
    ap.add_argument("--repo", default=REPO)
    ap.add_argument("--self-test", action="store_true")
    ap.add_argument("--print-inventory", action="store_true")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    if args.self_test:
        return self_test()
    if args.print_inventory:
        print_inventory(args.repo)
        return 0

    findings, _ = run_checks(args.compose, args.repo, quiet=args.quiet)
    if findings:
        print(f"\nFAIL — {len(findings)} finding(s):")
        for f in findings:
            print("  -", f)
        print("\nFix compose/Dockerfiles, or add the name to scripts/compose-env-exemptions.txt with a reason.")
        return 1
    print("\nPASS — compose passes every variable the application reads (no secret values printed).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
