#!/bin/bash
# FLEXORA Gym OS — Disaster Recovery Restore Drill
# © 2024 Ammar Allam. All rights reserved.

set -e

echo "Starting Restore Drill..."

# 1. Setup Test Environment
# (Assuming the test is running in a controlled env with access to the API or internal services)

# We will use a Jest test to perform the actual logic as it has access to Prisma and the BackupsService.
# This script will trigger that specific Jest test.

cd apps/api
export IMPORT_UPLOAD_DIR=/tmp/flexora/imports
export BACKUP_DIR=/tmp/flexora/backups
export CONTRACT_PDF_DIR=/tmp/flexora/contracts
npm test src/test/integration/restore-drill.spec.ts

if [ $? -eq 0 ]; then
  echo "Restore Drill PASSED ✅"
else
  echo "Restore Drill FAILED ❌"
  exit 1
fi
