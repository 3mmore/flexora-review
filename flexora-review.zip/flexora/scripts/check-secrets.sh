#!/usr/bin/env bash
# PHASE O2 — thin wrapper. The rules live in scripts/check-secrets.py so that CI,
# `npm run check:secrets`, scripts/package-release.sh and a developer's terminal
# all run ONE implementation. (This file used to carry its own grep pipeline,
# whose URL rule required a non-empty username and therefore missed
# `redis://:password@host` — the normal way to write a Redis URL — and which
# printed the credentials it found.)
#
#   scripts/check-secrets.sh [TARGET_DIR] [LABEL] [--no-exemptions]
#
# exit: 0 clean · 1 findings or a stale exemption · 2 usage/self-test failure
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="."
LABEL=""
EXTRA=()
POSITIONAL=()
for a in "$@"; do
  case "$a" in
    --no-exemptions|--json|--quiet) EXTRA+=("$a") ;;
    -*) echo "check-secrets: unknown flag $a" >&2; exit 2 ;;
    *) POSITIONAL+=("$a") ;;
  esac
done
# usage: check-secrets.sh [TARGET_DIR] [LABEL]
[ "${#POSITIONAL[@]}" -ge 1 ] && TARGET="${POSITIONAL[0]}"
[ "${#POSITIONAL[@]}" -ge 2 ] && LABEL="${POSITIONAL[1]}"
if [ -z "$LABEL" ]; then
  LABEL="$(basename "$(cd "$TARGET" 2>/dev/null && pwd || echo "$TARGET")")"
fi

exec python3 "$HERE/check-secrets.py" "$TARGET" --label "$LABEL" "${EXTRA[@]+"${EXTRA[@]}"}"
