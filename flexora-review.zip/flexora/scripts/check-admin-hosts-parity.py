#!/usr/bin/env python3
"""
PHASE R0 - the owner-console host gate must be configured identically in all layers.

WHY
---
R0 enforces one rule in three independent places: nginx (nginx/nginx.conf), the Next
middleware (apps/web/src/middleware.ts) and Nest (apps/api/src/common/guards/
admin-host.guard.ts). Each reads its own list of admin hostnames:

    nginx   map $host $flexora_admin_host { ... }  +  nginx/admin-hosts.d/*.map
    api     ADMIN_HOSTS  (compose: environment)
    web     ADMIN_HOSTS  (compose: environment, read per request by the middleware)

If they drift the failure is silent and asymmetric: nginx allows a hostname the api
refuses (the owner sees a 404 on their own console and no log line explains it), or
the api allows a hostname nginx refuses (the console works only from inside the
docker network). Neither is discoverable at runtime, so this script fails the build.

RULES
  A1  nginx's built-in admin-host map defaults to 0 (fail closed), lists no wildcard,
      and names only loopback hosts - a real hostname belongs in a drop-in .map file,
      never in the shipped config.
  A2  every shipped nginx/admin-hosts.d/*.map is `<hostname> 1;` only, and compose
      mounts that directory read-only at /etc/nginx/admin-hosts.d.
  A3  compose passes ADMIN_HOSTS to BOTH api and web, from the same interpolation
      form, and passes TRUST_PROXY_HOPS to both (the middleware's X-Forwarded-Host
      handling must match the api's).
  A4  ADMIN_HOSTS is documented in the root, api and web .env.example files with a
      usable example value, and is absent from license-server's (it serves no console).
  A5  a hostname listed in a local .env but missing from nginx's admin hosts is a
      lockout: nginx would refuse what the apps allow. (Skipped when no .env exists.)
  A6  every hostname anywhere obeys the product's syntax rules: no wildcard, no
      reserved `.invalid` name, no scheme/path/query, a numeric port if pinned,
      brackets around an IPv6 literal that carries a port.

usage: scripts/check-admin-hosts-parity.py [--repo DIR] [--self-test] [--quiet]
exit:  0 clean - 1 findings - 2 usage/self-test failure
ASCII only. No secret value is printed (ADMIN_HOSTS is not a secret, but nothing else
from a .env file is ever echoed).
"""
from __future__ import annotations

import argparse
import os
import re
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.dirname(HERE)

WILDCARDS = ("*", "*.*", "all", "any")
LOOPBACK = ("localhost", "127.0.0.1", "::1", "[::1]")
IPV6_RE = re.compile(r"^[0-9a-f:]+$")
HOST_RE = re.compile(r"^(?=.{1,253}$)[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*\.?$")


def host_syntax_problem(token: str) -> str | None:
    """A6: the same syntax rules apps/api/src/config/admin-hosts.ts applies."""
    t = token.strip()
    if not t:
        return "empty entry (stray comma)"
    low = t.lower()
    if low in WILDCARDS or low.startswith("*.") or low.endswith(".*"):
        return f"wildcard `{t}` - a console that answers on every hostname is a console on the public origin"
    if "/" in t or "?" in t or "#" in t or re.match(r"^[a-z][a-z0-9+.-]*://", low):
        return f"`{t}` carries a scheme, path or query - write a bare hostname or host:port"
    host = low
    if host.startswith("["):
        close = host.find("]")
        if close == -1:
            return f"`{t}` opens an IPv6 bracket that is never closed"
        literal, rest = host[1:close], host[close + 1:]
        if rest and not rest.startswith(":"):
            return f"`{t}` has trailing characters after the IPv6 literal"
        if not IPV6_RE.match(literal) or literal.count(":") < 2:
            return f"`{t}` is not a valid IPv6 literal"
        if rest.startswith(":"):
            return port_problem(t, rest[1:])
        return None
    if host.count(":") >= 2:
        if not IPV6_RE.match(host):
            return f"`{t}` has two or more colons but is not an IPv6 literal - bracket it ([::1]:8443)"
        return None
    if ":" in host:
        name, _, port = host.partition(":")
        problem = port_problem(t, port)
        if problem:
            return problem
        host = name
    if host == "invalid" or host.endswith(".invalid"):
        return (f"reserved `.invalid` name `{t}` - nginx sends host-gate.denied.invalid as its own "
                "denial Host, so allow-listing it would turn the edge's refusal into an entry ticket")
    if not HOST_RE.match(host):
        return f"`{t}` is not a valid hostname"
    return None


def port_problem(token: str, port: str) -> str | None:
    if not re.match(r"^\d{1,5}$", port):
        return f"`{token}` pins a port that is not 1-5 digits"
    if not 1 <= int(port) <= 65535:
        return f"`{token}` pins a port outside 1-65535"
    return None


def nginx_admin_hosts(text: str) -> tuple[list[str], str | None, list[str]]:
    """(explicit entries, default value, findings about the map itself)."""
    findings: list[str] = []
    m = re.search(r"map\s+\$host\s+\$flexora_admin_host\s*\{([^}]*)\}", text)
    if not m:
        return [], None, ["A1 nginx/nginx.conf defines no `map $host $flexora_admin_host` - the console "
                          "host gate is missing from the edge"]
    body = m.group(1)
    default = re.search(r"default\s+([^;]+);", body)
    dval = default.group(1).strip() if default else None
    if dval != "0":
        findings.append(f"A1 the admin-host map must default to 0 (fail closed); found `{dval or 'none'}`")
    entries = [mm.group(1).strip() for mm in re.finditer(r"^\s*([^\s;#]+)\s+1\s*;", body, re.M)]
    for e in entries:
        if e in WILDCARDS or e.startswith("*."):
            findings.append(f"A1 the admin-host map lists the wildcard `{e}`")
    if "include" not in body:
        findings.append("A1 the admin-host map does not `include /etc/nginx/admin-hosts.d/*.map`, so a "
                        "production hostname can only be added by editing the shipped config")
    return entries, dval, findings


def drop_in_maps(directory: str) -> tuple[list[str], list[str]]:
    """A2: hostnames declared by shipped drop-in .map files."""
    hosts: list[str] = []
    findings: list[str] = []
    if not os.path.isdir(directory):
        return hosts, findings
    for name in sorted(os.listdir(directory)):
        path = os.path.join(directory, name)
        if not os.path.isfile(path) or not name.endswith(".map"):
            continue
        for lineno, line in enumerate(open(path, encoding="utf8"), 1):
            line = line.split("#", 1)[0].strip()
            if not line:
                continue
            m = re.match(r"^([^\s;]+)\s+1\s*;$", line)
            if not m:
                findings.append(f"A2 {name}:{lineno} must be `<hostname> 1;` (found `{line}`)")
                continue
            problem = host_syntax_problem(m.group(1))
            if problem:
                findings.append(f"A2 {name}:{lineno} {problem}")
            else:
                hosts.append(m.group(1))
    return hosts, findings


def compose_services(text: str) -> dict:
    import yaml
    data = yaml.safe_load(text)
    return (data or {}).get("services") or {}


def env_file_value(path: str, key: str) -> str | None:
    if not os.path.exists(path):
        return None
    for line in open(path, encoding="utf8", errors="replace"):
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        name, _, value = line.partition("=")
        if name.strip() != key:
            continue
        value = value.strip()
        if value and value[0] in "\"'":
            quote = value[0]
            end = value.find(quote, 1)
            if end > 0:
                return value[1:end]
            return value[1:]
        # an unquoted value ends at the first whitespace-preceded comment
        return re.split(r"\s+#", value, maxsplit=1)[0].strip()
    return None


def check(repo: str, quiet: bool = False) -> list[str]:
    findings: list[str] = []
    say = (lambda *a: None) if quiet else (lambda *a: print(*a))

    nginx_path = os.path.join(repo, "nginx", "nginx.conf")
    compose_path = os.path.join(repo, "docker-compose.yml")
    for required in (nginx_path, compose_path):
        if not os.path.exists(required):
            return [f"A0 {os.path.relpath(required, repo)} not found"]

    nginx_text = open(nginx_path, encoding="utf8").read()
    entries, _default, map_findings = nginx_admin_hosts(nginx_text)
    findings.extend(map_findings)
    for e in entries:
        problem = host_syntax_problem(e)
        if problem:
            findings.append(f"A1 nginx/nginx.conf admin-host entry: {problem}")
        elif e not in LOOPBACK:
            findings.append(f"A1 nginx/nginx.conf lists `{e}` as an admin host in the shipped config; a "
                            "real hostname belongs in nginx/admin-hosts.d/*.map so that the repository "
                            "never hardcodes a customer's console hostname")
    dropins, drop_findings = drop_in_maps(os.path.join(repo, "nginx", "admin-hosts.d"))
    findings.extend(drop_findings)
    nginx_hosts = sorted(set(entries) | set(dropins))
    say(f"nginx admin hosts:   {', '.join(nginx_hosts) or '(none)'}")

    services = compose_services(open(compose_path, encoding="utf8").read())
    for svc in ("api", "web"):
        env = (services.get(svc) or {}).get("environment") or {}
        if isinstance(env, list):
            env = dict(str(x).split("=", 1) for x in env if "=" in str(x))
        for var in ("ADMIN_HOSTS", "TRUST_PROXY_HOPS"):
            if var not in env:
                findings.append(f"A3 compose service `{svc}` does not pass {var} - the {'host gate' if var == 'ADMIN_HOSTS' else 'X-Forwarded-Host policy'} "
                                f"would fall back to its built-in default in that container")
    api_form = ((services.get("api") or {}).get("environment") or {}).get("ADMIN_HOSTS")
    web_form = ((services.get("web") or {}).get("environment") or {}).get("ADMIN_HOSTS")
    if api_form and web_form and str(api_form) != str(web_form):
        findings.append(f"A3 compose passes ADMIN_HOSTS differently to api (`{api_form}`) and web "
                        f"(`{web_form}`) - the two layers would gate on different lists")
    if api_form and str(api_form).strip() not in ("${ADMIN_HOSTS:-}", "${ADMIN_HOSTS-}"):
        findings.append(f"A3 compose must pass ADMIN_HOSTS as `${{ADMIN_HOSTS:-}}` (found `{api_form}`): "
                        "`:?required` would break a trial install that legitimately leaves it empty, and "
                        "a hardcoded value would silently override the owner's .env")
    volumes = [str(v) for v in ((services.get("nginx") or {}).get("volumes") or [])]
    if not any(v.startswith("./nginx/admin-hosts.d:") and v.endswith(":ro") for v in volumes):
        findings.append("A2 compose does not mount ./nginx/admin-hosts.d read-only at "
                        "/etc/nginx/admin-hosts.d, so a production hostname cannot be added without "
                        "editing nginx.conf")

    examples = {
        ".env.example": True,
        "apps/api/.env.example": True,
        "apps/web/.env.example": True,
        "license-server/.env.example": False,
    }
    documented: dict[str, str] = {}
    for rel, wanted in examples.items():
        value = env_file_value(os.path.join(repo, rel), "ADMIN_HOSTS")
        if wanted:
            if value is None:
                findings.append(f"A4 {rel} does not document ADMIN_HOSTS")
                continue
            documented[rel] = value
            if not value:
                findings.append(f"A4 {rel} documents ADMIN_HOSTS with an empty example - show a usable "
                                "hostname so the operator knows the expected shape")
                continue
            for token in value.split(","):
                problem = host_syntax_problem(token)
                if problem:
                    findings.append(f"A4 {rel} example value: {problem}")
        elif value is not None:
            findings.append(f"A4 {rel} defines ADMIN_HOSTS, but that service serves no owner console")
    say(f"documented in:       {', '.join(sorted(documented)) or '(none)'}")

    # A5: a local .env that allows a hostname nginx would refuse = a silent lockout.
    local_lists: dict[str, str] = {}
    for rel in ("apps/api/.env", "apps/web/.env.local", ".env"):
        value = env_file_value(os.path.join(repo, rel), "ADMIN_HOSTS")
        if value:
            local_lists[rel] = value
    if local_lists:
        allowed = set()
        for value in local_lists.values():
            for token in value.split(","):
                token = token.strip().lower().rstrip(".")
                if token:
                    allowed.add(token)
                    problem = host_syntax_problem(token)
                    if problem:
                        findings.append(f"A6 {rel_or_value(local_lists, token)} {problem}")
        missing = sorted(h for h in allowed if h not in {x.lower().rstrip(".") for x in nginx_hosts}
                         and h not in LOOPBACK)
        if missing:
            findings.append(f"A5 ADMIN_HOSTS allows {', '.join(missing)} but nginx's admin hosts do not "
                            f"include them ({', '.join(nginx_hosts) or 'none'}) - nginx would refuse the "
                            "console that the apps allow. Add a nginx/admin-hosts.d/*.map drop-in.")
        say(f"local .env lists:    {', '.join(sorted(local_lists))} (values not printed)")
    else:
        say("local .env lists:    (no ADMIN_HOSTS in any local .env - trial mode)")

    return findings


def rel_or_value(local_lists: dict[str, str], token: str) -> str:
    for rel, value in local_lists.items():
        if token in [t.strip().lower().rstrip(".") for t in value.split(",")]:
            return f"{rel} lists `{token}`:"
    return f"a local .env lists `{token}`:"


def self_test() -> int:
    passed = failed = 0

    def ck(name: str, ok: bool) -> None:
        nonlocal passed, failed
        if ok:
            passed += 1
            print(f"    PASS  {name}")
        else:
            failed += 1
            print(f"    FAIL  {name}")

    good_nginx = """map $host $flexora_admin_host {
  default        0;
  localhost      1;
  127.0.0.1      1;
  include /etc/nginx/admin-hosts.d/*.map;
}
map $flexora_admin_host $flexora_gate_host {
  default        host-gate.denied.invalid;
  1              $host;
}
server { location /api/platform/ { proxy_pass http://api:4000$request_uri; } }
"""
    good_compose = """services:
  api:
    environment:
      ADMIN_HOSTS: ${ADMIN_HOSTS:-}
      TRUST_PROXY_HOPS: ${TRUST_PROXY_HOPS:-}
  web:
    environment:
      ADMIN_HOSTS: ${ADMIN_HOSTS:-}
      TRUST_PROXY_HOPS: ${TRUST_PROXY_HOPS:-}
  nginx:
    volumes:
      - ./nginx/nginx.conf:/etc/nginx/conf.d/default.conf:ro
      - ./nginx/admin-hosts.d:/etc/nginx/admin-hosts.d:ro
"""
    good_root_env = "DOMAIN=flexora.example.com\nADMIN_HOSTS=console.flexora.example.com\n"
    good_license_env = "LICENSE_PORT=9100\n"

    def build(tmp: str, nginx=good_nginx, compose=good_compose, root_env=good_root_env,
              api_env=good_root_env, web_env=good_root_env, license_env=good_license_env,
              dropins=None, local_env=None) -> str:
        repo = tempfile.mkdtemp(prefix="admin-hosts-parity-", dir=tmp)
        os.makedirs(os.path.join(repo, "nginx", "admin-hosts.d"), exist_ok=True)
        os.makedirs(os.path.join(repo, "apps", "api"), exist_ok=True)
        os.makedirs(os.path.join(repo, "apps", "web"), exist_ok=True)
        os.makedirs(os.path.join(repo, "license-server"), exist_ok=True)
        open(os.path.join(repo, "nginx", "nginx.conf"), "w", encoding="utf8").write(nginx)
        open(os.path.join(repo, "docker-compose.yml"), "w", encoding="utf8").write(compose)
        for rel, text in ((".env.example", root_env), ("apps/api/.env.example", api_env),
                          ("apps/web/.env.example", web_env), ("license-server/.env.example", license_env)):
            open(os.path.join(repo, rel), "w", encoding="utf8").write(text)
        for name, text in (dropins or {}).items():
            open(os.path.join(repo, "nginx", "admin-hosts.d", name), "w", encoding="utf8").write(text)
        if local_env:
            for rel, text in local_env.items():
                path = os.path.join(repo, rel)
                os.makedirs(os.path.dirname(path), exist_ok=True)
                open(path, "w", encoding="utf8").write(text)
        return repo

    tmp = tempfile.mkdtemp(prefix="admin-hosts-selftest-")

    repo = build(tmp)
    ck("negative control: a consistent trial-mode tree has no findings", check(repo, quiet=True) == [])

    repo = build(tmp, dropins={"console.map": "console.example.com 1;\n"},
                 local_env={"apps/api/.env": "ADMIN_HOSTS=console.example.com\n"})
    ck("a production hostname in a drop-in plus a matching .env is accepted", check(repo, quiet=True) == [])

    repo = build(tmp, local_env={"apps/api/.env": "ADMIN_HOSTS=console.example.com\n"})
    f = check(repo, quiet=True)
    ck("A5 a hostname the apps allow but nginx refuses is a lockout", any(x.startswith("A5") for x in f))

    repo = build(tmp, nginx=good_nginx.replace("  default        0;", "  default        1;"))
    ck("A1 a map that defaults to admin is caught", any(x.startswith("A1") for x in check(repo, quiet=True)))

    repo = build(tmp, nginx=good_nginx.replace("  localhost      1;", "  localhost      1;\n  *            1;"))
    ck("A1 a wildcard admin host is caught", any("wildcard" in x for x in check(repo, quiet=True)))

    repo = build(tmp, nginx=good_nginx.replace("  127.0.0.1      1;", "  127.0.0.1      1;\n  console.example.com 1;"))
    ck("A1 a customer hostname baked into the shipped config is caught", any("shipped config" in x for x in check(repo, quiet=True)))

    repo = build(tmp, nginx=good_nginx.replace("  include /etc/nginx/admin-hosts.d/*.map;", ""))
    ck("A1 a map with no drop-in include is caught", any("include" in x for x in check(repo, quiet=True)))

    repo = build(tmp, dropins={"bad.map": "console.example.com 1\n"})
    ck("A2 a malformed drop-in line is caught", any(x.startswith("A2") for x in check(repo, quiet=True)))

    repo = build(tmp, dropins={"bad.map": "*.example.com 1;\n"})
    ck("A2/A6 a wildcard in a drop-in is caught", any("wildcard" in x for x in check(repo, quiet=True)))

    repo = build(tmp, dropins={"bad.map": "host-gate.denied.invalid 1;\n"})
    ck("A6 a reserved .invalid name in a drop-in is caught", any(".invalid" in x for x in check(repo, quiet=True)))

    repo = build(tmp, compose=good_compose.replace("  web:\n    environment:\n      ADMIN_HOSTS: ${ADMIN_HOSTS:-}\n", "  web:\n    environment:\n"))
    f = check(repo, quiet=True)
    ck("A3 web without ADMIN_HOSTS is caught", any("`web` does not pass ADMIN_HOSTS" in x for x in f))

    repo = build(tmp, compose=good_compose.replace("      ADMIN_HOSTS: ${ADMIN_HOSTS:-}\n      TRUST_PROXY_HOPS: ${TRUST_PROXY_HOPS:-}\n  web:", "      ADMIN_HOSTS: ${ADMIN_HOSTS:-}\n  web:"))
    ck("A3 api without TRUST_PROXY_HOPS is caught", any("TRUST_PROXY_HOPS" in x for x in check(repo, quiet=True)))

    repo = build(tmp, compose=good_compose.replace("${ADMIN_HOSTS:-}", "${ADMIN_HOSTS:?required}", 1))
    f = check(repo, quiet=True)
    ck("A3 api and web receiving different interpolations is caught", any("differently" in x for x in f))
    ck("A3 `:?required` (which would break a trial install) is caught", any("ADMIN_HOSTS:-" in x for x in f))

    repo = build(tmp, compose=good_compose.replace("      - ./nginx/admin-hosts.d:/etc/nginx/admin-hosts.d:ro\n", ""))
    ck("A2 a missing read-only drop-in mount is caught", any("read-only" in x for x in check(repo, quiet=True)))

    repo = build(tmp, root_env="DOMAIN=flexora.example.com\n")
    ck("A4 an undocumented ADMIN_HOSTS is caught", any(x.startswith("A4") for x in check(repo, quiet=True)))

    repo = build(tmp, api_env="ADMIN_HOSTS=*\n")
    ck("A4 a wildcard example value is caught", any("wildcard" in x for x in check(repo, quiet=True)))

    repo = build(tmp, api_env="ADMIN_HOSTS=https://console.example.com\n")
    ck("A4 an example value with a scheme is caught", any("scheme" in x for x in check(repo, quiet=True)))

    repo = build(tmp, license_env="LICENSE_PORT=9100\nADMIN_HOSTS=console.example.com\n")
    ck("A4 ADMIN_HOSTS in the license-server example is caught", any("serves no owner console" in x for x in check(repo, quiet=True)))

    repo = build(tmp, local_env={"apps/api/.env": "ADMIN_HOSTS=console.example.com:99999\n"})
    ck("A6 an out-of-range pinned port in a local .env is caught", any("port" in x for x in check(repo, quiet=True)))

    ck("A6 host_syntax_problem accepts a bracketed IPv6 with a port", host_syntax_problem("[::1]:8443") is None)
    # `::1:8443` IS a valid IPv6 literal (it expands to 0:0:0:0:0:0:1:8443), so the
    # product parser treats it as an address with no port - which is exactly why a
    # port with an IPv6 literal must be bracketed. The guard must agree with the
    # parser, not invent a stricter rule.
    ck("A6 an unbracketed IPv6 is read as an address, not host:port (parity with the parser)",
       host_syntax_problem("::1:8443") is None)
    ck("A6 a multi-colon name that is not IPv6 is refused", host_syntax_problem("console.example.com:80:443") is not None)
    ck("A6 host_syntax_problem accepts a trailing root dot", host_syntax_problem("console.example.com.") is None)

    total = passed + failed
    print(f"  SELF-TEST: {passed}/{total} cases behaved correctly")
    return 0 if failed == 0 else 2


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=REPO)
    ap.add_argument("--self-test", action="store_true")
    ap.add_argument("--quiet", action="store_true")
    args = ap.parse_args()

    if args.self_test:
        return self_test()

    try:
        import yaml  # noqa: F401
    except ImportError:
        print("FATAL: PyYAML is required (python3 -c 'import yaml').")
        return 2

    findings = check(args.repo, quiet=args.quiet)
    if findings:
        print(f"{len(findings)} finding(s):")
        for f in findings:
            print(f"  FAIL {f}")
        print("FAIL - the owner-console host gate is not configured identically in every layer.")
        return 1
    print("PASS - nginx, compose (api + web) and the .env.example files agree on the console host gate.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
