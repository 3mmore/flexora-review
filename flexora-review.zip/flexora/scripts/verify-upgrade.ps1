# Read-only comparison of a running local database before and after an upgrade.
# Run from the project directory. Output contains gym names and operational data;
# store it privately. No passwords, hashes, tokens or TOTP material are selected.
$ErrorActionPreference = 'Stop'
$sql = @'
BEGIN TRANSACTION READ ONLY;
SET LOCAL statement_timeout = '2min';
\pset pager off
\echo === Main table row counts ===
SELECT 'Gym' AS table_name, count(*) AS rows FROM public."Gym"
UNION ALL SELECT 'Subscription', count(*) FROM public."Subscription"
UNION ALL SELECT 'User', count(*) FROM public."User"
UNION ALL SELECT 'Member', count(*) FROM public."Member"
UNION ALL SELECT 'Branch', count(*) FROM public."Branch"
UNION ALL SELECT 'Payment', count(*) FROM public."Payment"
UNION ALL SELECT 'Transaction', count(*) FROM public."Transaction"
UNION ALL SELECT 'PlatformAdmin', count(*) FROM public."PlatformAdmin"
UNION ALL SELECT 'PlatformAuditLog', count(*) FROM public."PlatformAuditLog"
ORDER BY table_name;
\echo === Audit chain ===
SELECT rows_checked, valid, head_seq FROM public.platform_audit_verify();
\echo === Platform admin count ===
SELECT count(*) AS platform_admins FROM public."PlatformAdmin";
\echo === Gym subscription summary; timestamps UTC ===
SELECT g.name AS gym_name, g.status AS gym_status, s.tier AS plan,
       s.status AS subscription_status,
       CASE WHEN s.status::text = 'TRIALING' THEN s."trialStartDate" ELSE s."currentPeriodStart" END AS start_utc,
       CASE WHEN s.status::text = 'TRIALING' THEN COALESCE(s."trialEndDate", s."currentPeriodEnd") ELSE s."currentPeriodEnd" END AS end_utc
  FROM public."Gym" g LEFT JOIN public."Subscription" s ON s."gymId" = g.id
 ORDER BY g.name, g.id;
COMMIT;
'@
# The database container supplies its own existing user and database settings.
# Credentials are not put in the command line or printed by this script.
$sql | docker compose -p flexora -f docker-compose.yml -f docker-compose.dev.yml exec -T db sh -c 'exec psql -X -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB"'
if ($LASTEXITCODE -ne 0) { throw 'Read-only verification failed; do not rely on this output.' }
