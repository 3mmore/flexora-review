#!/usr/bin/env bash
# PHASE P5 — the delivery-archive credential gate, as ONE implementation that both
# `scripts/package-release.sh` and `scripts/check-archive-scan-selftest.sh` call.
#
# Why this exists: the gate used to run the credential scanner against the
# EXTRACTION ROOT of the release zip. The zip is wrapped — it contains a single
# top-level folder — so that root holds nothing but the wrapper, and a scan could
# print "0 findings" having read almost nothing. A gate that scans nothing is
# worse than no gate, because it prints green.
#
# So this script:
#   1. extracts the archive into an empty directory;
#   2. locates the WRAPPED tree (the directory that carries
#      scripts/secrets-exemptions.txt, i.e. the real project root);
#   3. runs the shared scanner over that tree with --no-exemptions, so a
#      credential can never be waved through by a stale allow-list entry;
#   4. reports `archive file entries`, `scannable text files` and
#      `files scanned`, and FAILS when the scan covered 0 files or fewer than
#      90% of the scannable files.
#
# exit: 0 clean and provably covered · 1 findings or insufficient coverage · 2 usage
set -uo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "$HERE/.." && pwd)"

ZIP="${1:-}"
LABEL="${2:-delivery archive}"
# Exemptions apply by default: scripts/secrets-exemptions.txt carries the
# credential-shaped literals that live in SPEC FIXTURES on purpose, each with a
# written reason, and they are part of the delivered tree. Pass --no-exemptions
# for the diagnostic the PHASE P5 brief asks for — it proves those fixtures are
# really inside the archive, i.e. that the scan is reading the shipped content and
# not an empty wrapper directory.
NO_EXEMPTIONS=0
for a in "$@"; do [ "$a" = "--no-exemptions" ] && NO_EXEMPTIONS=1; done
if [ -z "$ZIP" ] || [ ! -f "$ZIP" ]; then
  echo "usage: scripts/check-archive-scan.sh <archive.zip> [label]" >&2
  exit 2
fi
command -v unzip >/dev/null 2>&1 || { echo "ERROR: unzip is required" >&2; exit 2; }

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
unzip -q "$ZIP" -d "$TMP" || { echo "ERROR: cannot read $ZIP" >&2; exit 2; }

# The wrapped project root: the directory that carries the exemption list. This is
# the same rule the scanner itself uses (find_repo_base), applied here so the scan
# target and the exemption paths agree.
BASE=""
if [ -f "$TMP/scripts/secrets-exemptions.txt" ]; then
  BASE="$TMP"
else
  for d in "$TMP"/*/; do
    [ -f "${d}scripts/secrets-exemptions.txt" ] && { BASE="${d%/}"; break; }
  done
fi
if [ -z "$BASE" ]; then
  echo "── archive credential scan: $LABEL ─────────────────────────"
  echo "FAIL could not locate the wrapped project root in $ZIP"
  echo "     (expected a directory containing scripts/secrets-exemptions.txt)"
  exit 1
fi

echo "── archive credential scan: $LABEL ─────────────────────────"
echo "     archive: $ZIP"
echo "     wrapped project root: ${BASE#$TMP/}"

OUT="$(mktemp)"
SCAN_ARGS=()
[ "$NO_EXEMPTIONS" = 1 ] && SCAN_ARGS+=(--no-exemptions)
echo "     exemptions: $([ "$NO_EXEMPTIONS" = 1 ] && echo DISABLED || echo applied)"
if bash "$HERE/check-secrets.sh" "$BASE" "$LABEL" ${SCAN_ARGS+"${SCAN_ARGS[@]}"} 2>&1 | tee "$OUT"; then
  SCAN_RC=0
else
  SCAN_RC=1
fi

SCANNED="$(sed -nE 's/.*files scanned: ([0-9]+).*/\1/p' "$OUT" | tail -1)"
ARCHIVE_FILES="$(unzip -Z1 "$ZIP" 2>/dev/null | grep -vc '/$')"
SCANNABLE="$(python3 - "$HERE" "$BASE" <<'PY'
import importlib.util, sys
spec = importlib.util.spec_from_file_location("cs", sys.argv[1] + "/check-secrets.py")
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
print(mod.scannable_file_count(sys.argv[2]))
PY
)"
SCANNABLE="${SCANNABLE:-0}"
echo "     archive file entries: ${ARCHIVE_FILES:-0}   scannable text files: $SCANNABLE   files scanned: ${SCANNED:-0}"
rm -f "$OUT"

RC=$SCAN_RC
if [ -z "$SCANNED" ] || [ "$SCANNED" = 0 ]; then
  echo "FAIL the scan reported 0 files scanned — the gate covered nothing"
  RC=1
elif [ "$SCANNABLE" -gt 0 ]; then
  NEED=$(( (SCANNABLE * 90) / 100 ))
  if [ "$SCANNED" -lt "$NEED" ]; then
    echo "FAIL the scan covered $SCANNED of $SCANNABLE scannable files (<90%)"
    RC=1
  else
    echo "ok   scan coverage $SCANNED/$SCANNABLE scannable files (>=90%)"
  fi
else
  echo "FAIL could not compute the scannable file count of the extracted archive"
  RC=1
fi

[ "$RC" = 0 ] && echo "ok   archive credential gate PASSED (findings 0, coverage proven)"
exit "$RC"
