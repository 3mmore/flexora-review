#!/usr/bin/env bash
# PHASE O1.5 — thin wrapper so CI, package-release and a host build all invoke the
# SAME implementation that already runs inside `npm run build`
# (apps/web/scripts/check-no-loopback.mjs). One implementation, no sibling copy
# that can drift.
#
#   scripts/check-web-build.sh                 # scans apps/web/.next
#   scripts/check-web-build.sh --self-test     # proves the scanner's own behaviour
#   scripts/check-web-build.sh --next-dir=DIR
#
# Exit codes: 0 clean · 1 findings · 2 usage/self-test failure
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="$(cd "$HERE/.." && pwd)"
IMPL="$REPO/apps/web/scripts/check-no-loopback.mjs"

if [ ! -f "$IMPL" ]; then
  echo "check-web-build: missing implementation $IMPL" >&2
  exit 2
fi
if [[ " $* " == *" --next-dir="* ]]; then
  exec node "$IMPL" "$@"
fi
exec node "$IMPL" --next-dir="$REPO/apps/web/.next" "$@"
