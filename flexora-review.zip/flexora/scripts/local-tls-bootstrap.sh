#!/usr/bin/env bash
# FLEXORA - bootstrap a SELF-SIGNED certificate so a local `docker compose up` can start nginx.
# (c) 2024 Ammar Allam. All rights reserved.
#
# WHY THIS EXISTS. nginx/nginx.conf terminates TLS with
#     ssl_certificate     /etc/letsencrypt/live/domain/fullchain.pem;
#     ssl_certificate_key /etc/letsencrypt/live/domain/privkey.pem;
# and docker-compose.yml mounts ./certbot/conf at /etc/letsencrypt. A fresh checkout ships
# certbot/README.md and NOTHING ELSE, so those two files do not exist and the nginx container
# exits immediately with "cannot load certificate". The real certificates come from Let's Encrypt
# via the certbot service, which needs a public DNS name and port 80 reachable from the internet
# - neither of which a laptop has. So local runs need a self-signed stand-in at the same paths.
#
# This is a DEVELOPMENT affordance only. It writes into certbot/conf/live/domain/, which is
# exactly where certbot would put a real certificate, so it refuses to touch a directory that
# already looks like a real one rather than silently replacing it.
#
# ASCII only. Prints no key material: only paths, dates and exit codes.
#
#   bash scripts/local-tls-bootstrap.sh            create if absent, otherwise no-op
#   bash scripts/local-tls-bootstrap.sh --force    regenerate (only if it is self-signed)
#   bash scripts/local-tls-bootstrap.sh --check    report state, change nothing, exit 1 if absent
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="$(dirname "$HERE")"
LIVE="$REPO/certbot/conf/live/domain"
WWW="$REPO/certbot/www"
CRT="$LIVE/fullchain.pem"
KEY="$LIVE/privkey.pem"
DAYS=825            # Apple/mozilla cap; longer than this is rejected by some clients
FORCE=0
CHECK=0
for a in "$@"; do
  case "$a" in
    --force) FORCE=1 ;;
    --check) CHECK=1 ;;
    -h|--help) sed -n '2,26p' "${BASH_SOURCE[0]}"; exit 0 ;;
    *) echo "local-tls-bootstrap: unknown flag $a" >&2; exit 2 ;;
  esac
done

# An explicit marker is written only for certificates created by this script. A CA:TRUE
# extension or equal issuer/subject does not prove a certificate is disposable. Never overwrite
# an unmarked, partial, invalid or changed pair, even when --force is supplied.
MARKER="$LIVE/.flexora-local-tls-sha256"
state() {
  if [ ! -e "$CRT" ] && [ ! -e "$KEY" ] && [ ! -e "$MARKER" ]; then
    echo absent
  elif [ -f "$CRT" ] && [ -f "$KEY" ] && [ -f "$MARKER" ] &&
       openssl x509 -in "$CRT" -noout >/dev/null 2>&1 &&
       openssl pkey -in "$KEY" -noout >/dev/null 2>&1 &&
       [ "$(openssl x509 -in "$CRT" -noout -fingerprint -sha256 2>/dev/null)" = "$(cat "$MARKER")" ] &&
       [ "$(openssl x509 -in "$CRT" -pubkey -noout 2>/dev/null | openssl pkey -pubin -outform DER 2>/dev/null | openssl dgst -sha256)" = "$(openssl pkey -in "$KEY" -pubout -outform DER 2>/dev/null | openssl dgst -sha256)" ]; then
    echo managed-local
  else
    echo existing-unmanaged-or-incomplete
  fi
}
CURRENT="$(state)"
if [ "$CHECK" = 1 ]; then
  echo "local-tls-bootstrap: certificate state = $CURRENT"
  [ "$CURRENT" = managed-local ] || { echo 'No verified local pair; inspect existing files before proceeding.'; exit 1; }
  exit 0
fi
if [ "$CURRENT" = existing-unmanaged-or-incomplete ]; then
  echo "REFUSING: existing certificate files are unmarked, changed, invalid, or incomplete; no files overwritten." >&2
  exit 1
fi
if [ "$CURRENT" = managed-local ] && [ "$FORCE" != 1 ]; then
  echo 'local-tls-bootstrap: verified local pair already exists; nothing to do.'
  exit 0
fi
mkdir -p "$WWW"

mkdir -p "$LIVE"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

# One self-signed certificate that is its own CA, so fullchain.pem and privkey.pem are the pair
# nginx expects. subjectAltName must carry localhost and 127.0.0.1: modern clients ignore
# commonName entirely, and without a SAN curl and browsers both reject the connection even with
# -k / ignoreHTTPSErrors in some paths.
cat > "$TMP/openssl.cnf" <<CNF
[req]
distinguished_name = dn
x509_extensions    = v3
prompt             = no
[dn]
C  = EG
ST = Cairo
L  = Cairo
O  = FLEXORA local development
CN = localhost
[v3]
basicConstraints       = critical, CA:TRUE, pathlen:0
keyUsage               = critical, digitalSignature, keyEncipherment, keyCertSign
extendedKeyUsage       = serverAuth
subjectAltName         = @alt
[alt]
DNS.1 = localhost
IP.1  = 127.0.0.1
IP.2  = ::1
CNF

openssl req -x509 -newkey rsa:2048 -nodes \
  -keyout "$TMP/privkey.pem" \
  -out    "$TMP/fullchain.pem" \
  -days "$DAYS" \
  -config "$TMP/openssl.cnf" >/dev/null 2>&1

# Private key first and locked down, so there is no window where it is world-readable.
install -m 600 "$TMP/privkey.pem"   "$KEY"
install -m 644 "$TMP/fullchain.pem" "$CRT"
openssl x509 -in "$CRT" -noout -fingerprint -sha256 > "$MARKER"
chmod 600 "$MARKER"

echo "local-tls-bootstrap: wrote a SELF-SIGNED certificate for local development"
echo "  fullchain : ${CRT#"$REPO"/}"
echo "  privkey   : ${KEY#"$REPO"/}  (mode 600)"
echo "  not after : $(openssl x509 -in "$CRT" -noout -enddate | cut -d= -f2)"
echo "  SAN       : $(openssl x509 -in "$CRT" -noout -ext subjectAltName 2>/dev/null | tail -1 | sed 's/^ *//')"
echo ""
echo "  Browsers will warn: this certificate is not from a trusted authority. That is expected and"
echo "  is the whole point - it is a stand-in until certbot can issue a real one. curl needs -k."
echo "  NEVER ship this directory, and never reuse it outside a local machine: certbot/conf is"
echo "  excluded from the delivery archive precisely so it cannot travel."
