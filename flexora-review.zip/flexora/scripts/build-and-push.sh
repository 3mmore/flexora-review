#!/bin/bash
set -e

VERSION=${1:-3.2.3}
REGISTRY=ghcr.io/3mmore

echo "Building Flexora v${VERSION}..."

# Build API
docker build -f Dockerfile.api \
  -t ${REGISTRY}/flexora-api:${VERSION} \
  -t ${REGISTRY}/flexora-api:latest .

# Build Web
docker build -f Dockerfile.web \
  -t ${REGISTRY}/flexora-web:${VERSION} \
  -t ${REGISTRY}/flexora-web:latest .

# Push
docker push ${REGISTRY}/flexora-api:${VERSION}
docker push ${REGISTRY}/flexora-web:${VERSION}

echo "✅ Images pushed to registry"
echo "Give client: client-package/ folder only"