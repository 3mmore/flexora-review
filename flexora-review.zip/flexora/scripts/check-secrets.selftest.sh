#!/usr/bin/env bash
# PHASE O2.3 — the scanner's self-test, as its own entry point so CI can fail on a
# disagreement between a rule and its documented expectation.
#
# Every row is (content, filename, expected): a credential that MUST be reported,
# or a template/reference/dummy that MUST stay clean. The rows live next to the
# rules in scripts/check-secrets.py (SELF_TEST_ROWS) so a rule change and its
# expectations change in the same file.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python3 "$HERE/check-secrets.py" --self-test
code=$?
if [ "$code" -ne 0 ]; then
  echo "SELF-TEST DISAGREEMENT: the scanner and its documented expectations differ." >&2
  echo "Fix the rule or the row — never delete a row to get green." >&2
fi
exit "$code"
