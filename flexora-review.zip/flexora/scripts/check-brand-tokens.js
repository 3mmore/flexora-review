#!/usr/bin/env node
/**
 * check-brand-tokens — the guard against the recurring theme-color regression.
 *
 * WHY THIS EXISTS
 * The gym's accent color is a single value in the database, but it used to be
 * applied only to --cyan/--primary while ~200 other CSS/TSX rules hardcoded the
 * old gold default (#c5a059 / rgba(197,160,89,a) / its dark variant #4a3d21).
 * Rounds of patching those literals by hand never stuck: the next rule (or the
 * next page) reintroduced one, and the app went back to "black and gold with a
 * mismatched accent".
 *
 * The fix is one source of truth: `--brand` and `--brand-rgb` in globals.css,
 * overridden inline by BrandContext. This script fails the build/harness if a
 * gold literal reappears in tenant-facing code.
 *
 * Run:  node scripts/check-brand-tokens.js
 * Exit: 0 clean · 1 violations (each printed with file:line)
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const WEB_SRC = path.join(ROOT, 'apps', 'web', 'src');

// Tenant-facing surfaces: everything a gym staff member / member sees.
// Out of scope on purpose: the marketing site, the platform super-admin area,
// the license server and the billing pages keep the default brand identity.
const SKIP_DIRS = ['(public)', '(platform)', 'billing', 'license', 'landing'];

const PATTERNS = [
  { re: /197\s*,\s*160\s*,\s*89/, what: 'rgba(197,160,89,…) — the old gold with alpha' },
  { re: /74\s*,\s*61\s*,\s*33/, what: 'rgba(74,61,33,…) — the old dark-gold with alpha' },
  { re: /#c5a059/i, what: '#c5a059 — the old gold hex' },
  { re: /#4a3d21/i, what: '#4a3d21 — the old dark-gold hex' },
  { re: /#dcc08e/i, what: '#dcc08e — the old light-gold hex' },
];

/**
 * Every intentional exception, with the reason. Add a line here ONLY if the
 * literal cannot be a CSS variable (a JS fallback that must be a real color, an
 * <input type=color> default, SSR metadata, or the token definition itself).
 */
const ALLOW = [
  { file: 'app/globals.css', line: /--brand(-rgb|-dim|-dim-rgb)?:\s*(#c5a059|197, 160, 89|#4a3d21|74, 61, 33)/, why: 'the token definitions themselves (the ONE source of truth)' },
  { file: 'context/BrandContext.tsx', line: /^\s*\*|^\s*\/\//, why: 'documentation comments' },
  { file: 'context/BrandContext.tsx', line: /primary(Dim|Glow)?:\s*"(#c5a059|#4a3d21|rgba\(197, 160, 89)/, why: 'THEME_LIBRARY "orange" preset = the default identity for a gym with no accent; the brand override (same function, later) always wins — asserted live by work/brandswap-scan.js' },
  { file: 'context/BrandContext.tsx', line: /\|\|\s*"#c5a059"|>\s*#c5a059|'#c5a059'/, why: 'JS fallback when the gym has no accent' },
  { file: 'components/brand/Logo.tsx', line: /BRAND_GOLD\s*=\s*"#c5a059"/, why: 'default mark color when no gym accent is set' },
  { file: 'app/layout.tsx', line: /themeColor:\s*"#c5a059"/, why: 'SSR <meta name=theme-color>; repainted at runtime' },
  { file: 'app/onboarding/page.tsx', line: /'#c5a059'|"#c5a059"/, why: 'color-picker default for a gym that has not chosen yet' },
  { file: 'app/portal/dashboard/page.tsx', line: /"#c5a059"/, why: 'recharts color fallback (needs a real color string)' },
];

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (e.name === 'node_modules' || e.name.startsWith('.')) continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (SKIP_DIRS.some((s) => p.includes(path.sep + s + path.sep) || p.endsWith(path.sep + s))) continue;
      walk(p, out);
    } else if (/\.(tsx?|css)$/.test(e.name)) out.push(p);
  }
  return out;
}

const rel = (p) => path.relative(WEB_SRC, p).split(path.sep).join('/');
const stripComments = (src) => src
  .replace(/\/\*[\s\S]*?\*\//g, (m) => m.replace(/[^\n]/g, ' '))
  .replace(/(^|[^:])\/\/[^\n]*/g, (m, p1) => p1 + ' '.repeat(m.length - p1.length));

let violations = [];
const files = walk(WEB_SRC);

for (const f of files) {
  const r = rel(f);
  const raw = fs.readFileSync(f, 'utf8');
  const src = r.endsWith('.css') ? raw : stripComments(raw);
  src.split('\n').forEach((line, i) => {
    for (const p of PATTERNS) {
      if (!p.re.test(line)) continue;
      const allowed = ALLOW.some((a) => a.file === r && a.line.test(line));
      if (!allowed) violations.push({ file: r, line: i + 1, what: p.what, text: line.trim().slice(0, 110) });
    }
  });
}

// globals.css must define exactly the four token defaults — no more, no less.
const globals = fs.readFileSync(path.join(WEB_SRC, 'app', 'globals.css'), 'utf8');
const tokenDefs = globals.match(/--(brand|brand-rgb|brand-dim|brand-dim-rgb):\s*[^;]+;/g) || [];
if (!/--brand:\s*#c5a059/.test(globals) || !/--brand-rgb:\s*197, 160, 89/.test(globals)) {
  violations.push({ file: 'app/globals.css', line: 0, what: 'the --brand token defaults are missing', text: 'expected --brand:#c5a059 and --brand-rgb:197, 160, 89' });
}

console.log(`check-brand-tokens: scanned ${files.length} tenant files in apps/web/src`);
if (tokenDefs.length < 2) {
  console.log(`  note: found ${tokenDefs.length} brand token definitions in globals.css`);
}
if (violations.length === 0) {
  console.log('  OK — every tenant color derives from var(--brand) / rgba(var(--brand-rgb), a)');
  process.exit(0);
}
console.log(`\n  ${violations.length} hardcoded brand literal(s) found — these will NOT follow the gym's accent:\n`);
for (const v of violations) console.log(`  ${v.file}:${v.line}  ${v.what}\n     ${v.text}`);
console.log('\n  Fix: use var(--brand) or rgba(var(--brand-rgb), a) — see the BRAND block at the top of app/globals.css.');
console.log('  If the value cannot be a CSS variable, add an explicit entry to ALLOW in scripts/check-brand-tokens.js with a reason.');
process.exit(1);
