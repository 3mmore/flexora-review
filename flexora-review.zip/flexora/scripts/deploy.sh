#!/bin/bash
set -e

VERSION=${1:-latest}
echo "🚀 Deploying Flexora $VERSION"

# 1. Pull new image
docker pull flexora-api:$VERSION

# 1b. Create pre-deploy backup
echo "💾 Creating pre-deploy backup..."
BACKUP_DATE=$(date +%Y%m%d_%H%M%S)
mkdir -p backups
docker exec flexora-db pg_dump \
  -U "${DB_USER:-postgres}" \
  "${DB_NAME:-flexora}" \
  > "backups/pre-deploy-${BACKUP_DATE}.sql" \
  && echo "✅ Backup: pre-deploy-${BACKUP_DATE}.sql" \
  || echo "⚠️ Backup failed, continuing..."

# 2. Run migrations BEFORE switching traffic
echo "📦 Running migrations..."
docker run --rm \
  --env-file .env \
  flexora-api:$VERSION \
  npx prisma migrate deploy

# 3. Start new container alongside old one
echo "🔄 Starting new container..."
docker-compose up -d --no-deps \
  --scale api=2 api

# 4. Wait for new container to be healthy
echo "⏳ Waiting for health check..."
sleep 15
HEALTH=$(curl -sf \
  http://localhost:4000/api/health \
  | grep -c '"status":"ok"' || true)

if [ "$HEALTH" -eq 0 ]; then
  echo "❌ Health check failed! Rolling back..."
  docker-compose up -d --no-deps \
    --scale api=1 api
  exit 1
fi

# 5. Scale back to 1
echo "✅ Health check passed. Scaling down..."
docker-compose up -d --no-deps \
  --scale api=1 api

echo "🎉 Deployment complete! Version: $VERSION"
