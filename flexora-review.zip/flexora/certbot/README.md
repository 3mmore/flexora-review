# certbot (Item 4)

`docker-compose.yml` bind-mounts two directories into both the `nginx` and
`certbot` services:

- `./certbot/conf` → `/etc/letsencrypt` — where certbot stores issued
  certificates, account keys, and renewal configuration.
- `./certbot/www` → `/var/www/certbot` — the HTTP-01 challenge webroot nginx
  serves so Let's Encrypt can verify domain ownership.

Both directories are intentionally **empty** in git (only `.gitkeep` files
are tracked) — certificates are generated data, not source code, and must
never be committed.

## First-run certificate issuance

Before the very first `docker compose up`, nginx's config
(`../nginx/nginx.conf`) expects certificates to already exist at
`/etc/letsencrypt/live/<DOMAIN>/`, or it will fail to start. Bootstrap them
once with the standard certbot "webroot" flow:

```bash
# 1. Start only nginx (serving plain HTTP for the ACME challenge) + certbot's
#    dependencies, without requiring certs to already exist. If your
#    nginx.conf hard-requires TLS, temporarily comment out the `listen 443`
#    / ssl_certificate lines for this first run only.
docker compose up -d nginx

# 2. Ask certbot to obtain a certificate via the shared webroot:
docker compose run --rm certbot certonly \
  --webroot -w /var/www/certbot \
  -d yourdomain.example.com \
  --email you@example.com --agree-tos --no-eff-email

# 3. Restore/uncomment the real HTTPS server block in nginx.conf (if you
#    changed it in step 1), then reload nginx to pick up the new cert:
docker compose exec nginx nginx -s reload

# 4. From then on, the long-running `certbot` service (already defined in
#    docker-compose.yml) automatically renews the certificate every 12h
#    (`certbot renew` is a no-op until the cert is within its renewal
#    window), and `docker compose up -d` on subsequent deploys just works.
```

## Why this matters (Item 4)

Previously `docker-compose.yml` referenced `./certbot/conf` and
`./certbot/www` as bind mounts, but neither directory existed in the repo at
all, so `docker compose up` failed immediately (Docker refuses to bind-mount
a host path that doesn't exist as a directory, or in some configurations
silently creates it as `root`-owned, breaking the certbot/nginx containers'
ability to write to it). These directories (plus this README) now exist so
a fresh clone can run `docker compose config` / `docker compose up`
immediately, and a new operator has a documented, copy-pasteable path to
their very first real certificate.
