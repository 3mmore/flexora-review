# FLEXORA Gym OS — Member Mobile App (Phase 16)

Flutter app for gym members.
© 2024 Ammar Allam. WhatsApp: +20XXXXXXXXXX

## Build

```bash
cd apps/mobile-member
flutter pub get
flutter analyze
flutter build apk --release
flutter build ios --release
```

## Screens

- Login (OTP)
- Home (grid menu)
- QR (membership code)
- Renew membership
- Attendance history
- Payment history
- Notifications
- PT booking
- Class booking
- Digital contract (with signature)
- Referrals
