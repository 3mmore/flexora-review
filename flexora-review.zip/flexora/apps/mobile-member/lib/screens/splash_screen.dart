/**
 * FLEXORA Gym OS — Premium Splash + Onboarding (Phase 5 — Mobile UX)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _ctl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1500))..forward();
  late final Animation<double> _opacity = Tween<double>(begin: 0, end: 1).animate(_ctl);
  late final Animation<double> _scale = Tween<double>(begin: 0.85, end: 1).animate(CurvedAnimation(parent: _ctl, curve: Curves.easeOutBack));

  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1800), () {
      if (mounted) context.go('/login');
    });
  }

  @override
  void dispose() { _ctl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: Colors.black,
    body: Stack(children: [
      Positioned.fill(child: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topCenter, radius: 1.2,
            colors: [Color(0x3300CFFF), Colors.black],
          ),
        ),
      )),
      Center(child: FadeTransition(opacity: _opacity, child: ScaleTransition(scale: _scale, child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 80, height: 80,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFF00CFFF), Color(0xFF0099CC)], begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Center(child: Text('F', style: TextStyle(color: Colors.black, fontSize: 44, fontWeight: FontWeight.w800))),
          ),
          const SizedBox(height: 20),
          const Text('FLEXORA', style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w800, letterSpacing: 2)),
          const SizedBox(height: 6),
          const Text('GYM · OS', style: TextStyle(color: Color(0xFF00CFFF), fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: 4)),
        ],
      )))),
      Positioned(bottom: 40, left: 0, right: 0, child: Center(child: FadeTransition(opacity: _opacity, child: const Text(
        'Premium gym management',
        style: TextStyle(color: Color(0xFF7A95AD), fontSize: 12, letterSpacing: 1.2),
      )))),
    ]),
  );
}

