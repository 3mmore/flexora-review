/**
 * FLEXORA Gym OS — Member Login (Phase 16)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _phoneCtrl = TextEditingController();
  final _codeCtrl = TextEditingController();
  bool _sendingCode = false;
  bool _verifying = false;
  String? _error;

  Future<void> _requestOtp() async {
    setState(() { _sendingCode = true; _error = null; });
    await Future.delayed(const Duration(milliseconds: 500));
    setState(() { _sendingCode = false; });
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('OTP sent (dev: 123456)')));
  }

  Future<void> _verify() async {
    setState(() { _verifying = true; _error = null; });
    await Future.delayed(const Duration(milliseconds: 500));
    setState(() { _verifying = false; });
    if (mounted) Navigator.of(context).pushReplacementNamed('/home');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('FLEXORA', style: TextStyle(color: Color(0xFF00CFFF), fontSize: 36, fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            const Text('Member Portal', style: TextStyle(color: Colors.white70, fontSize: 14)),
            const SizedBox(height: 48),
            TextField(
              controller: _phoneCtrl,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                labelText: 'Mobile number',
                hintText: '01xxxxxxxxx',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: _sendingCode ? null : _requestOtp,
                child: Text(_sendingCode ? 'Sending…' : 'Send OTP'),
              ),
            ),
            const SizedBox(height: 24),
            TextField(
              controller: _codeCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: '6-digit code',
                border: OutlineInputBorder(),
              ),
            ),
            if (_error != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(_error!, style: const TextStyle(color: Colors.redAccent))),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                style: FilledButton.styleFrom(backgroundColor: const Color(0xFF00CFFF), foregroundColor: Colors.black),
                onPressed: _verifying ? null : _verify,
                child: Text(_verifying ? 'Verifying…' : 'Login'),
              ),
            ),
          ],
        ),
      ),
    ),
  );
}
