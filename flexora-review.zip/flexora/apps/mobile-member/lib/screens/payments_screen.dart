/**
 * FLEXORA Gym OS — Payments (Phase 16)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:flutter/material.dart';

class PaymentsScreen extends StatelessWidget {
  const PaymentsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final payments = [
      {'amount': 1100.0, 'date': '2026-04-12', 'method': 'Visa ****1234'},
      {'amount': 1100.0, 'date': '2026-01-12', 'method': 'Visa ****1234'},
      {'amount': 450.0, 'date': '2025-10-12', 'method': 'Cash'},
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Payment History'), backgroundColor: Colors.black),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: payments.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (_, i) => Card(
          color: Colors.grey[900],
          child: ListTile(
            leading: const Icon(Icons.payment, color: Color(0xFF00CFFF)),
            title: Text('EGP ${payments[i]['amount']}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            subtitle: Text('${payments[i]['date']} — ${payments[i]['method']}', style: const TextStyle(color: Colors.white60)),
          ),
        ),
      ),
    );
  }
}
