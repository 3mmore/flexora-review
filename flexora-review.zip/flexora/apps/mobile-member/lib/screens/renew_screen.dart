/**
 * FLEXORA Gym OS — Membership Renew (Phase 16)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class RenewScreen extends StatefulWidget {
  const RenewScreen({super.key});
  @override
  State<RenewScreen> createState() => _RenewScreenState();
}

class _RenewScreenState extends State<RenewScreen> {
  String _selected = '1 Month';
  final _plans = ['1 Month', '3 Months', '6 Months', '12 Months'];
  bool _loading = false;

  Future<void> _renew() async {
    setState(() => _loading = true);
    await Future.delayed(const Duration(seconds: 1));
    setState(() => _loading = false);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Renewal request submitted!')));
      context.pop();
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Renew Membership'), backgroundColor: Colors.black),
    body: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Card(color: Colors.grey[900], child: Padding(padding: const EdgeInsets.all(16), child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text('Current plan', style: TextStyle(color: Colors.white60, fontSize: 12)),
              SizedBox(height: 4),
              Text('3 Months — expires 2026-08-12', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
            ],
          ))),
          const SizedBox(height: 24),
          const Text('Choose new plan', style: TextStyle(color: Color(0xFF00CFFF), fontSize: 16)),
          const SizedBox(height: 12),
          ..._plans.map((p) => RadioListTile<String>(
            title: Text(p, style: const TextStyle(color: Colors.white)),
            value: p,
            groupValue: _selected,
            activeColor: const Color(0xFF00CFFF),
            onChanged: (v) => setState(() => _selected = v!),
          )),
          const SizedBox(height: 24),
          SizedBox(width: double.infinity, child: FilledButton(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFF00CFFF), foregroundColor: Colors.black),
            onPressed: _loading ? null : _renew,
            child: Text(_loading ? 'Processing…' : 'Renew with $_selected'),
          )),
        ],
      ),
    ),
  );
}
