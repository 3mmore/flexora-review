/**
 * FLEXORA Gym OS — PT Booking (Phase 16)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class PtBookingScreen extends StatefulWidget {
  const PtBookingScreen({super.key});
  @override
  State<PtBookingScreen> createState() => _PtBookingScreenState();
}

class _PtBookingScreenState extends State<PtBookingScreen> {
  String? _coach;
  DateTime _date = DateTime.now().add(const Duration(days: 1));

  @override
  Widget build(BuildContext context) {
    final coaches = ['Ahmed Hassan', 'Sara Salah', 'Khaled Raafat'];
    return Scaffold(
      appBar: AppBar(title: const Text('Book PT Session'), backgroundColor: Colors.black),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Choose coach', style: TextStyle(color: Color(0xFF00CFFF), fontSize: 16)),
          const SizedBox(height: 8),
          ...coaches.map((c) => RadioListTile<String>(
            title: Text(c, style: const TextStyle(color: Colors.white)),
            value: c, groupValue: _coach, activeColor: const Color(0xFF00CFFF),
            onChanged: (v) => setState(() => _coach = v!),
          )),
          const SizedBox(height: 24),
          ListTile(
            title: const Text('Date', style: TextStyle(color: Colors.white)),
            subtitle: Text(_date.toString().split(' ')[0], style: const TextStyle(color: Color(0xFF00CFFF))),
            trailing: const Icon(Icons.calendar_today, color: Color(0xFF00CFFF)),
            tileColor: Colors.grey[900],
            onTap: () async {
              final picked = await showDatePicker(context: context, initialDate: _date, firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 60)));
              if (picked != null) setState(() => _date = picked);
            },
          ),
          const SizedBox(height: 24),
          SizedBox(width: double.infinity, child: FilledButton(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFF00CFFF), foregroundColor: Colors.black),
            onPressed: _coach == null ? null : () {
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('PT session booked!')));
              context.pop();
            },
            child: const Text('Confirm booking'),
          )),
        ]),
      ),
    );
  }
}
