/**
 * FLEXORA Gym OS — Attendance History (Phase 16)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class AttendanceScreen extends StatelessWidget {
  const AttendanceScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final entries = List.generate(12, (i) => {
      'date': DateTime.now().subtract(Duration(days: i * 2)),
      'branch': i.isEven ? 'Nasr City' : 'Maadi',
    });
    final fmt = DateFormat('yyyy-MM-dd  HH:mm');
    return Scaffold(
      appBar: AppBar(title: const Text('Attendance History'), backgroundColor: Colors.black),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: entries.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (_, i) => Card(
          color: Colors.grey[900],
          child: ListTile(
            leading: const Icon(Icons.check_circle, color: Color(0xFF00CFFF)),
            title: Text('Checked in', style: const TextStyle(color: Colors.white)),
            subtitle: Text('${entries[i]['branch']} — ${fmt.format(entries[i]['date'] as DateTime)}', style: const TextStyle(color: Colors.white60)),
          ),
        ),
      ),
    );
  }
}
