/**
 * FLEXORA Gym OS — Referrals (Phase 16)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:flutter/material.dart';

class ReferralsScreen extends StatelessWidget {
  const ReferralsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Refer Friends'), backgroundColor: Colors.black),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          Card(color: Colors.grey[900], child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(children: [
              const Text('🎁', style: TextStyle(fontSize: 48)),
              const SizedBox(height: 8),
              const Text('Invite friends, earn rewards', style: TextStyle(color: Color(0xFF00CFFF), fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              const Text('Bring 3 friends → 1 free month\nBring 5 → 1 free PT session', style: TextStyle(color: Colors.white70)),
            ]),
          )),
          const SizedBox(height: 24),
          const Text('Your referrals', style: TextStyle(color: Color(0xFF00CFFF), fontSize: 16)),
          const SizedBox(height: 12),
          Expanded(child: ListView(children: [
            ListTile(leading: const Icon(Icons.person_add, color: Color(0xFF00CFFF)), title: const Text('Ahmed Mostafa', style: TextStyle(color: Colors.white)), subtitle: const Text('Visited yesterday · 2 slots used', style: TextStyle(color: Colors.white60))),
            ListTile(leading: const Icon(Icons.person_add, color: Color(0xFF00CFFF)), title: const Text('Mariam Saleh', style: TextStyle(color: Colors.white)), subtitle: const Text('Joined last week · 🎉', style: TextStyle(color: Colors.green))),
          ])),
        ]),
      ),
    );
  }
}
