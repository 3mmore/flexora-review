/**
 * FLEXORA Gym OS — Member Home (Phase 16)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final tiles = [
      ('🎟️', 'My QR', '/qr'),
      ('📅', 'Renew', '/renew'),
      ('📋', 'Attendance', '/attendance'),
      ('💳', 'Payments', '/payments'),
      ('🔔', 'Notifications', '/notifications'),
      ('🧑‍🏫', 'PT Booking', '/pt'),
      ('🗓️', 'Classes', '/classes'),
      ('📄', 'Contracts', '/contract'),
      ('🎁', 'Referrals', '/referrals'),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('FLEXORA'), backgroundColor: Colors.black, actions: [
        IconButton(icon: const Icon(Icons.person), onPressed: () => context.push('/profile')),
      ]),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, mainAxisSpacing: 12, crossAxisSpacing: 12),
        itemCount: tiles.length,
        itemBuilder: (_, i) => InkWell(
          onTap: () => context.push(tiles[i].$3),
          child: Card(
            color: Colors.grey[900],
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(tiles[i].$1, style: const TextStyle(fontSize: 40)),
                const SizedBox(height: 8),
                Text(tiles[i].$2, style: const TextStyle(color: Colors.white)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
