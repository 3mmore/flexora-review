/**
 * FLEXORA Gym OS — Class Booking (Phase 16)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class ClassBookingScreen extends StatelessWidget {
  const ClassBookingScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final classes = [
      ('HIIT', 'Tomorrow 7:00 AM', 'Ahmed H.', '8/12', false),
      ('Yoga', 'Tomorrow 8:30 AM', 'Sara S.', '4/15', false),
      ('CrossFit', 'Wed 6:00 PM', 'Khaled R.', '11/15', false),
      ('Spinning', 'Thu 7:00 PM', 'Mona A.', 'FULL', true),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Group Classes'), backgroundColor: Colors.black),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: classes.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (_, i) {
          final c = classes[i];
          return Card(
            color: Colors.grey[900],
            child: ListTile(
              title: Text(c.$1, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              subtitle: Text('${c.$2} — coach ${c.$3}\n${c.$4} spots', style: const TextStyle(color: Colors.white60)),
              isThreeLine: true,
              trailing: FilledButton(
                style: FilledButton.styleFrom(backgroundColor: c.$5 ? Colors.grey : const Color(0xFF00CFFF), foregroundColor: c.$5 ? Colors.white : Colors.black),
                onPressed: c.$5 ? null : () {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Booked ${c.$1}!')));
                  context.pop();
                },
                child: const Text('Book'),
              ),
            ),
          );
        },
      ),
    );
  }
}
