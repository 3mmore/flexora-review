/**
 * FLEXORA Gym OS — Member Profile (Phase 16 — extension)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile'), backgroundColor: Colors.black),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(child: Column(children: [
            const CircleAvatar(radius: 48, backgroundColor: Color(0xFF00CFFF), child: Text('AM', style: TextStyle(color: Colors.black, fontSize: 28, fontWeight: FontWeight.bold))),
            const SizedBox(height: 12),
            const Text('Ahmed Mostafa', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
            const Text('Member since 2024', style: TextStyle(color: Colors.white60)),
          ])),
          const SizedBox(height: 24),
          _InfoCard(title: 'Membership', rows: [
            ('Plan', '3 Months'),
            ('Expires', '2026-08-12'),
            ('Sessions left', '8'),
            ('Freezes used', '1'),
          ]),
          const SizedBox(height: 16),
          _InfoCard(title: 'Stats', rows: [
            ('Total visits', '47'),
            ('This month', '12'),
            ('Last visit', 'Today'),
          ]),
          const SizedBox(height: 16),
          _InfoCard(title: 'Quick actions', rows: [
            ('🎟️  My QR', '/qr'),
            ('📅  Renew', '/renew'),
            ('📄  Contracts', '/contract'),
          ], isActions: true),
          const SizedBox(height: 24),
          OutlinedButton(
            onPressed: () => Navigator.pushReplacementNamed(context, '/login'),
            style: OutlinedButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Sign out'),
          ),
        ],
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final String title; final List<(String, String)> rows; final bool isActions;
  const _InfoCard({required this.title, required this.rows, this.isActions = false});
  @override
  Widget build(BuildContext context) => Card(
    color: Colors.grey[900],
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title.toUpperCase(), style: const TextStyle(color: Color(0xFF00CFFF), fontSize: 11, letterSpacing: 1.5, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        ...rows.map((r) => isActions
          ? ListTile(contentPadding: EdgeInsets.zero, title: Text(r.$1, style: const TextStyle(color: Colors.white)), trailing: const Icon(Icons.chevron_right, color: Colors.white40), onTap: () => context.push(r.$2))
          : Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(r.$1, style: const TextStyle(color: Colors.white60)), Text(r.$2, style: const TextStyle(color: Colors.white))])),
        ),
      ]),
    ),
  );
}
