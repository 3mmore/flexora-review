/**
 * FLEXORA Gym OS — Member QR (Phase 16)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';

class QrScreen extends StatelessWidget {
  const QrScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final code = 'FLEX-${DateTime.now().millisecondsSinceEpoch.toString().substring(7).toUpperCase()}';
    return Scaffold(
      appBar: AppBar(title: const Text('My QR'), backgroundColor: Colors.black),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
                child: QrImageView(data: code, size: 240, backgroundColor: Colors.white),
              ),
              const SizedBox(height: 24),
              Text(code, style: const TextStyle(color: Color(0xFF00CFFF), fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'monospace')),
              const SizedBox(height: 12),
              const Text('Show this at reception to check in', style: TextStyle(color: Colors.white60)),
            ],
          ),
        ),
      ),
    );
  }
}
