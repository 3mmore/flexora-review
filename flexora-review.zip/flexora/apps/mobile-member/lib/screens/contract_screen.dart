/**
 * FLEXORA Gym OS — Digital Contract (Phase 16)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:flutter/material.dart';
import 'package:flutter_signature_pad/flutter_signature_pad.dart';

class ContractScreen extends StatefulWidget {
  const ContractScreen({super.key});
  @override
  State<ContractScreen> createState() => _ContractScreenState();
}

class _ContractScreenState extends State<ContractScreen> {
  final _signatureCtrl = GlobalKey<SignaturePadState>();
  bool _signing = false;
  bool _signed = false;

  Future<void> _save() async {
    setState(() => _signing = true);
    // In production: upload signature SVG + signed PDF to backend
    await Future.delayed(const Duration(milliseconds: 800));
    setState(() { _signing = false; _signed = true; });
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Contract signed successfully!')));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Membership Contract'), backgroundColor: Colors.black),
    body: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        Expanded(
          child: SingleChildScrollView(
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: Colors.grey[900], borderRadius: BorderRadius.circular(8)),
              child: const Text(
                'MEMBERSHIP AGREEMENT\n\n'
                '1. The member agrees to abide by gym rules.\n'
                '2. Membership is non-transferable.\n'
                '3. Cancellations require 30-day notice.\n'
                '4. Lost cards replaced for EGP 50.\n'
                '5. By signing below, the member agrees to the terms above.',
                style: TextStyle(color: Colors.white, height: 1.5),
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        if (!_signed) SignaturePad(
          key: _signatureCtrl,
          strokeColor: Colors.white,
          backgroundColor: Colors.grey[900]!,
        ),
        if (_signed) Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: Colors.green.withOpacity(0.2), borderRadius: BorderRadius.circular(8)),
          child: const Row(children: [
            Icon(Icons.check_circle, color: Colors.green),
            SizedBox(width: 12),
            Text('Contract signed', style: TextStyle(color: Colors.green)),
          ]),
        ),
        const SizedBox(height: 16),
        SizedBox(width: double.infinity, child: FilledButton(
          style: FilledButton.styleFrom(backgroundColor: const Color(0xFF00CFFF), foregroundColor: Colors.black),
          onPressed: _signed || _signing ? null : _save,
          child: Text(_signing ? 'Uploading…' : (_signed ? 'Signed ✓' : 'Sign & Submit')),
        )),
      ]),
    ),
  );
}
