/**
 * FLEXORA Gym OS — Member Mobile App (Phase 16)
 * © 2024 Ammar Allam. All rights reserved.
 * Contact: +20XXXXXXXXXX
 */
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'services/auth_service.dart';
import 'services/api_service.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'screens/qr_screen.dart';
import 'screens/renew_screen.dart';
import 'screens/attendance_screen.dart';
import 'screens/payments_screen.dart';
import 'screens/notifications_screen.dart';
import 'screens/pt_booking_screen.dart';
import 'screens/class_booking_screen.dart';
import 'screens/contract_screen.dart';
import 'screens/referrals_screen.dart';
import 'screens/profile_screen.dart';

void main() {
  runApp(const FlexoraMemberApp());
}

class FlexoraMemberApp extends StatelessWidget {
  const FlexoraMemberApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider<AuthService>(create: (_) => AuthService()),
        Provider<ApiService>(create: (_) => ApiService()),
      ],
      child: MaterialApp.router(
        title: 'FLEXORA Member',
        theme: ThemeData(
          brightness: Brightness.dark,
          primaryColor: const Color(0xFF00CFFF),
          scaffoldBackgroundColor: Colors.black,
          colorScheme: const ColorScheme.dark(
            primary: Color(0xFF00CFFF),
            surface: Colors.black,
          ),
          useMaterial3: true,
        ),
        routerConfig: GoRouter(
          initialLocation: '/splash',
          routes: [
            GoRoute(path: '/splash', builder: (_, __) => const SplashScreen()),
            GoRoute(path: '/login', builder: (_, __) => const LoginScreen()),
            GoRoute(path: '/home', builder: (_, __) => const HomeScreen()),
            GoRoute(path: '/qr', builder: (_, __) => const QrScreen()),
            GoRoute(path: '/renew', builder: (_, __) => const RenewScreen()),
            GoRoute(path: '/attendance', builder: (_, __) => const AttendanceScreen()),
            GoRoute(path: '/payments', builder: (_, __) => const PaymentsScreen()),
            GoRoute(path: '/notifications', builder: (_, __) => const NotificationsScreen()),
            GoRoute(path: '/pt', builder: (_, __) => const PtBookingScreen()),
            GoRoute(path: '/classes', builder: (_, __) => const ClassBookingScreen()),
            GoRoute(path: '/contract', builder: (_, __) => const ContractScreen()),
            GoRoute(path: '/referrals', builder: (_, __) => const ReferralsScreen()),
            GoRoute(path: '/profile', builder: (_, __) => const ProfileScreen()),
          ],
        ),
      ),
    );
  }
}
