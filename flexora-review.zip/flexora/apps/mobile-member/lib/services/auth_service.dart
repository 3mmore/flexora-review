/**
 * FLEXORA Gym OS — Member Auth Service (Phase 16)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  static const _tokenKey = 'flx_member_token';
  static const _memberIdKey = 'flx_member_id';

  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_tokenKey);
  }
  Future<void> setToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_tokenKey, token);
  }
  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
  }
  Future<String?> getMemberId() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_memberIdKey);
  }
}
