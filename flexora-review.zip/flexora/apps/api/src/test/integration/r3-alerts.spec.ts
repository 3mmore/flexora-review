/** @jest-environment node */
/**
 * FLEXORA Gym OS - Backend API
 * (c) 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R3 - owner decision A3, the platform alert outbox.
 *
 * BEFORE (work/r3-evidence/00-before.log, B8): the three files that implement the five
 * alert events contained ZERO owner-channel calls. An alert was a bare
 * notifications.whatsapp(null, PLATFORM_OWNER_PHONE, ...) which deliberately writes no
 * database row, so a missing channel or a rejected send left nothing but a log line.
 *
 * Each test below is written against a real Postgres and the real service, with only the
 * channel itself faked - because the channel is the thing under test, and faking the
 * database would prove nothing.
 */
import { PrismaClient } from '@prisma/client';
import { NotificationsService } from '../../modules/notifications/notifications.service';
import { PlatformAuditService } from '../../modules/platform/platform-audit.service';
import {
  PlatformAlertService,
  ALERT_DEDUPE_WINDOW_MS,
  ALERT_MAX_ATTEMPTS,
  ALERT_ERROR_CODES,
  PLATFORM_ALERT_TYPES,
  backoffFor,
  classifyChannelFailure,
  dedupeBucket,
} from '../../modules/platform/platform-alert.service';

jest.setTimeout(180_000);

const MARKER = 'r3-alerts-spec';
/**
 * Base 36 on purpose. Identifiers built here end up in `targetId`, and the console-routes
 * spec asserts - correctly - that no alert response contains a run of ten or more digits,
 * because that is what an Egyptian mobile number looks like. A decimal `Date.now()` is
 * thirteen digits, so this suite's own fixture data tripped another suite's privacy
 * assertion during a full run. The assertion was right; the fixture was not.
 */
const RUN_ID = Date.now().toString(36);
/** A string that must never appear anywhere in a stored alert row. */
const FORBIDDEN_SECRET = `${MARKER}-provider-token-DO-NOT-STORE`;
const FORBIDDEN_PHONE = '+201000000000';

type Sent = { to: string; body: string };

function makeChannel(options: { configured: boolean; failsWith?: string; delayMs?: number }) {
  const sent: Sent[] = [];
  const stub = {
    whatsapp: jest.fn(async (_gymId: string | null, to: string, body: string) => {
      if (options.delayMs) await new Promise((resolve) => setTimeout(resolve, options.delayMs));
      if (options.failsWith) throw new Error(options.failsWith);
      sent.push({ to, body });
      return null;
    }),
  };
  return { stub: stub as never, sent, options };
}

/**
 * Delivery is fire-and-forget by design (A3.3: recording an alert must never delay the action
 * that triggered it), so a fixed sleep before asserting the outcome is a race - it passed in
 * isolation and lost under parallel load, leaving the row still PENDING. Poll until the status
 * settles instead. PENDING is a legitimate resting place while a retry is backing off, so the
 * deadline is what ends the wait, not an assumption about how long a send takes.
 */
async function settledStatus(
  prisma: PrismaClient,
  alertId: string,
  timeoutMs = 8000,
): Promise<string> {
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    const row = await prisma.platformAlert.findUniqueOrThrow({ where: { id: alertId } });
    if (row.status !== 'PENDING' || Date.now() > deadline) return row.status;
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
}

function makeCronLeadership() {
  return {
    acquireLock: jest.fn(async () => true),
    releaseLock: jest.fn(async () => undefined),
  } as never;
}

describe('R3.9/R3.10/A3 - the platform alert outbox', () => {
  let prisma: PrismaClient;
  const savedEnv: Record<string, string | undefined> = {};
  const createdAlertIds: string[] = [];

  const setChannel = (configured: boolean) => {
    if (configured) process.env.PLATFORM_OWNER_PHONE = FORBIDDEN_PHONE;
    else delete process.env.PLATFORM_OWNER_PHONE;
  };

  const newService = (channel: { configured: boolean; failsWith?: string; delayMs?: number }) => {
    const made = makeChannel(channel);
    const service = new PlatformAlertService(prisma, made.stub, makeCronLeadership());
    return { service, sent: made.sent, whatsapp: (made.stub as unknown as { whatsapp: jest.Mock }).whatsapp };
  };

  const track = async (service: PlatformAlertService, input: Parameters<PlatformAlertService['raise']>[0]) => {
    const result = await service.raise(input);
    if (result && !result.deduped) createdAlertIds.push(result.id);
    return result;
  };

  beforeAll(async () => {
    prisma = new PrismaClient();
    for (const key of ['PLATFORM_OWNER_PHONE', 'WHATSAPP_PHONE_ID', 'WHATSAPP_TOKEN']) {
      savedEnv[key] = process.env[key];
    }
  });

  beforeEach(async () => {
    // WhatsApp credentials are set in the development environment, so a test that wants to
    // observe a channel failure has to control them explicitly.
    process.env.WHATSAPP_PHONE_ID = 'test-phone-id';
    process.env.WHATSAPP_TOKEN = 'test-token';
    setChannel(true);
  });

  afterAll(async () => {
    if (createdAlertIds.length) {
      await prisma.platformAlert.deleteMany({ where: { id: { in: createdAlertIds } } }).catch(() => undefined);
    }
    await prisma.platformAlert.deleteMany({ where: { dedupeKey: { startsWith: MARKER } } }).catch(() => undefined);
    for (const [key, value] of Object.entries(savedEnv)) {
      if (value === undefined) delete process.env[key];
      else process.env[key] = value;
    }
    await prisma.$disconnect();
  });

  it('A3.1 - an alert row stores the approved columns and nothing else', async () => {
    const { service } = newService({ configured: true });
    const result = await track(service, {
      type: 'GYM_DELETED',
      severity: 'warning',
      targetKind: 'gym',
      targetId: '11111111-1111-4111-8111-111111111111',
    });
    expect(result?.deduped).toBe(false);

    const row = await prisma.platformAlert.findUniqueOrThrow({ where: { id: result!.id } });
    // The A3.1 list, exactly: type, severity, target kind, optional target UUID, optional
    // audit chain position, channel, status, attempts, max attempts, error code, dedupe key
    // and timestamps. No phone number, no message body, no raw provider error.
    expect(row.type).toBe('GYM_DELETED');
    expect(row.severity).toBe('warning');
    expect(row.targetKind).toBe('gym');
    expect(row.targetId).toBe('11111111-1111-4111-8111-111111111111');
    expect(row.channel).toBe('WHATSAPP_OWNER');
    expect(row.maxAttempts).toBe(ALERT_MAX_ATTEMPTS);
    expect(typeof row.dedupeKey).toBe('string');

    const serialised = JSON.stringify(row);
    expect(serialised).not.toContain(FORBIDDEN_PHONE);
    expect(Object.keys(row)).not.toContain('body');
    expect(Object.keys(row)).not.toContain('message');
    expect(Object.keys(row)).not.toContain('phone');
  });

  it('A3.4 - with no owner phone the alert is recorded as NO_CHANNEL and the console can see why', async () => {
    setChannel(false);
    const { service, sent, whatsapp } = newService({ configured: false });

    const result = await track(service, {
      type: 'ADMIN_REMOVED',
      severity: 'warning',
      targetKind: 'admin',
      targetId: '22222222-2222-4222-8222-222222222222',
    });
    expect(await settledStatus(prisma, result!.id)).toBe('NO_CHANNEL');

    const row = await prisma.platformAlert.findUniqueOrThrow({ where: { id: result!.id } });
    expect(row.status).toBe('NO_CHANNEL');
    expect(row.errorCode).toBe('channel_not_configured');
    expect(row.attempts).toBe(0);
    expect(sent).toHaveLength(0);
    expect(whatsapp).not.toHaveBeenCalled();

    // The warning is data the console renders, not only a log line.
    const state = service.channelState();
    expect(state.configured).toBe(false);
    expect(state.missing).toContain('PLATFORM_OWNER_PHONE');
    // ...and it names variables only, never values.
    for (const name of state.missing) expect(name).toMatch(/^[A-Z0-9_]+$/);

    const listed = await service.listForConsole({ status: 'NO_CHANNEL' });
    expect(listed.channel.configured).toBe(false);
    expect(listed.rows.some((item) => item.id === row.id)).toBe(true);
  });

  it('A3.5 - the same type and target inside one window collapses; a different target or window does not', async () => {
    const { service } = newService({ configured: true });
    const target = '33333333-3333-4333-8333-333333333333';
    const unique = `${MARKER}-${RUN_ID}`;

    const first = await prisma.$queryRaw<Array<{ id: string }>>`SELECT gen_random_uuid()::text AS id`;
    void first;

    const insert = async (targetId: string | null, bucket: number) => {
      const id = `${unique}-${(targetId ?? 'none').split('-').pop()}-${bucket}`;
      const dedupeKey = `ADMIN_LOGIN_BURST|admin|${targetId ?? '-'}|${bucket}`;
      const now = new Date();
      const rows = await prisma.$queryRaw<Array<{ id: string }>>`
        INSERT INTO public."PlatformAlert"
          ("id","type","severity","targetKind","targetId","channel","status","attempts",
           "maxAttempts","dedupeKey","createdAt","updatedAt")
        VALUES (${id}::text,'ADMIN_LOGIN_BURST'::text,'warning'::text,'admin'::text,
                ${targetId}::text,'WHATSAPP_OWNER'::text,'SENT'::text,1::integer,
                ${ALERT_MAX_ATTEMPTS}::integer,${dedupeKey}::text,${now}::timestamp(3),${now}::timestamp(3))
        ON CONFLICT ("dedupeKey") DO NOTHING
        RETURNING "id"`;
      if (rows.length) createdAlertIds.push(rows[0].id);
      return rows.length === 1;
    };

    const bucket = dedupeBucket(Date.now());
    expect(await insert(target, bucket)).toBe(true);
    // same type, same target, same window -> collapsed
    expect(await insert(target, bucket)).toBe(false);
    // same type, DIFFERENT target, same window -> its own alert
    expect(await insert('44444444-4444-4444-8444-444444444444', bucket)).toBe(true);
    // same type, same target, NEXT window -> its own alert
    expect(await insert(target, bucket + 1)).toBe(true);

    // and the service's own raise() reports deduplication rather than silently inserting
    const raised = await service.raise({
      type: 'GYM_DELETED',
      targetKind: 'gym',
      targetId: `${unique}-gym`,
    });
    if (raised && !raised.deduped) createdAlertIds.push(raised.id);
    const again = await service.raise({
      type: 'GYM_DELETED',
      targetKind: 'gym',
      targetId: `${unique}-gym`,
    });
    expect(raised?.deduped).toBe(false);
    expect(again?.deduped).toBe(true);
    expect(again?.id).toBe(raised?.id);
  });

  it('A3.2 - retry is bounded: after the last attempt the alert is FAILED and is never claimed again', async () => {
    const { service, whatsapp } = newService({ configured: true, failsWith: FORBIDDEN_SECRET });
    const result = await track(service, {
      type: 'AUDIT_WRITE_FAILED',
      severity: 'danger',
      targetKind: 'platform',
    });
    await new Promise((resolve) => setTimeout(resolve, 150));

    let row = await prisma.platformAlert.findUniqueOrThrow({ where: { id: result!.id } });
    // Drive the remaining attempts through the claim path, exactly as the cron does. The loop
    // bound and every assertion below are ABSOLUTE NUMBERS, not expressions of
    // ALERT_MAX_ATTEMPTS: the first version of this test compared against the constant it was
    // supposed to be protecting, so the mutation cycle raised the cap to 500 and the test raised
    // its own expectation to match and passed. A test that moves with the thing it checks is not
    // a test.
    const HARD_CAP = 5;
    expect(ALERT_MAX_ATTEMPTS).toBe(HARD_CAP);
    for (let attempt = 0; attempt < HARD_CAP + 2; attempt += 1) {
      await prisma.platformAlert.update({
        where: { id: row.id },
        data: { status: 'PENDING', nextAttemptAt: new Date(Date.now() - 1000) },
      });
      await service.retryDue(10);
      row = await prisma.platformAlert.findUniqueOrThrow({ where: { id: row.id } });
      if (row.status === 'FAILED') break;
    }

    expect(row.status).toBe('FAILED');
    expect(row.attempts).toBeLessThanOrEqual(HARD_CAP);
    expect(whatsapp.mock.calls.length).toBeLessThanOrEqual(HARD_CAP);

    // A FAILED alert is not PENDING, so the claim function cannot pick it up again.
    await prisma.platformAlert.update({
      where: { id: row.id },
      data: { nextAttemptAt: new Date(Date.now() - 60_000) },
    });
    const claimed = await prisma.$queryRaw<Array<{ alert_id: string }>>`
      SELECT * FROM public.platform_claim_alerts_for_retry(now()::timestamp(3), 50::integer)`;
    expect(claimed.some((item) => item.alert_id === row.id)).toBe(false);

    // A3.1 - the provider's raw error text, which here contains a credential-shaped string,
    // never reached the database. Only a code from the fixed vocabulary did.
    const serialised = JSON.stringify(row);
    expect(serialised).not.toContain(FORBIDDEN_SECRET);
    expect(ALERT_ERROR_CODES).toContain(row.errorCode as never);
  });

  it('A3.2 - a SENT alert is never sent again, even if it is claimed', async () => {
    const { service, sent } = newService({ configured: true });
    const result = await track(service, { type: 'ADMIN_CREATED', targetKind: 'admin' });
    expect(await settledStatus(prisma, result!.id)).toBe('SENT');

    const row = await prisma.platformAlert.findUniqueOrThrow({ where: { id: result!.id } });
    expect(row.status).toBe('SENT');
    expect(row.sentAt).not.toBeNull();
    const firstCount = sent.length;

    // Force it back into the claim window and run the retry pass: delivery must refuse.
    await prisma.platformAlert.update({
      where: { id: row.id },
      data: { nextAttemptAt: new Date(Date.now() - 60_000) },
    });
    const status = await service.deliver(row.id);
    expect(status).toBe('SENT');
    expect(sent.length).toBe(firstCount);
  });

  it('A3.2 - FOR UPDATE SKIP LOCKED: two concurrent claimants take disjoint sets', async () => {
    const { service } = newService({ configured: true });
    const unique = `${MARKER}-lock-${RUN_ID}`;
    const ids: string[] = [];
    for (let index = 0; index < 6; index += 1) {
      const raised = await service.raise({
        type: 'SUBSCRIPTION_GRANTED',
        targetKind: 'subscription',
        targetId: `${unique}-${index}`,
      });
      if (raised && !raised.deduped) ids.push(raised.id);
    }
    createdAlertIds.push(...ids);
    // Put them all back into a claimable state so the race is real.
    await prisma.platformAlert.updateMany({
      where: { id: { in: ids } },
      data: { status: 'PENDING', attempts: 0, nextAttemptAt: new Date(Date.now() - 1000) },
    });

    // A race has to be FORCED, not hoped for. Two claims issued through Promise.all only
    // overlap if the pool happens to hand them to two connections at the same instant: this
    // passed in isolation and failed inside a full run, which is exactly what a
    // timing-dependent test looks like. So the first claimant holds its transaction OPEN
    // while the second runs - the situation SKIP LOCKED exists for. With the locking
    // removed, the second call would either block until the first committed and then re-take
    // the same rows, or take them concurrently; both are the double-send this prevents.
    const held = prisma.$transaction(async (tx) => {
      const rows = await tx.$queryRaw<Array<{ alert_id: string }>>`
        SELECT * FROM public.platform_claim_alerts_for_retry(now()::timestamp(3), 3::integer)`;
      // keep the row locks held while the second claimant runs
      await new Promise((resolve) => setTimeout(resolve, 2500));
      return rows;
    });
    // let the first claimant reach its FOR UPDATE before the second one starts
    await new Promise((resolve) => setTimeout(resolve, 600));
    const second = await prisma.$queryRaw<Array<{ alert_id: string }>>`
      SELECT * FROM public.platform_claim_alerts_for_retry(now()::timestamp(3), 3::integer)`;
    const first = await held;

    expect(first.length).toBeGreaterThan(0);
    const overlap = first.filter((item) => second.some((other) => other.alert_id === item.alert_id));
    expect(overlap).toHaveLength(0);
    expect(first.length + second.length).toBeLessThanOrEqual(ids.length);
    // Each claim increments the attempt counter in the same statement, so a crash between
    // claim and result costs one attempt rather than looping forever.
    const rows = await prisma.platformAlert.findMany({
      where: { id: { in: [...first, ...second].map((item) => item.alert_id) } },
      select: { attempts: true },
    });
    for (const row of rows) expect(row.attempts).toBeGreaterThanOrEqual(1);
  });

  it('A3.3 - a channel that hangs cannot hold the caller: raising returns before the send finishes', async () => {
    const { service } = newService({ configured: true, delayMs: 4000 });
    const startedAt = Date.now();
    const result = await track(service, { type: 'GYM_DELETED', targetKind: 'gym', targetId: `${MARKER}-slow` });
    const elapsed = Date.now() - startedAt;

    // Delivery is kicked without awaiting it, so a slow provider adds nothing to the caller.
    expect(elapsed).toBeLessThan(2000);
    expect(result?.deduped).toBe(false);
    await new Promise((resolve) => setTimeout(resolve, 4500));
  });

  it('A3.3 - a database failure while recording an alert returns null instead of throwing', async () => {
    const broken = {
      $queryRaw: jest.fn(async () => {
        throw new Error('simulated database failure');
      }),
      $transaction: jest.fn(),
      platformAlert: { findUnique: jest.fn(async () => null) },
    } as unknown as PrismaClient;
    const channel = makeChannel({ configured: true });
    const service = new PlatformAlertService(broken, channel.stub, makeCronLeadership());

    // The action that triggered the alert must survive: this resolves, it does not reject.
    await expect(
      service.raise({ type: 'ADMIN_LOGIN_BURST', targetKind: 'platform' }),
    ).resolves.toBeNull();
  });

  it('A3.7 - an alert references its audit row by chain position and the rendered message is built from it', async () => {
    const { service, sent } = newService({ configured: true });
    const auditRow = await prisma.platformAuditLog.create({
      data: {
        adminId: `${MARKER}-audit`,
        adminName: 'R3 alert spec',
        action: 'gym:delete-soft',
        target: 'gym-abc',
        reason: 'Owner asked for the demo gym to be removed',
        details: { previousStatus: 'ACTIVE' } as object,
      },
      select: { seq: true },
    });

    const result = await track(service, {
      type: 'GYM_DELETED',
      severity: 'warning',
      targetKind: 'gym',
      targetId: 'gym-abc',
      auditSeq: auditRow.seq,
    });
    await settledStatus(prisma, result!.id);

    const row = await prisma.platformAlert.findUniqueOrThrow({ where: { id: result!.id } });
    expect(row.auditSeq).toBe(auditRow.seq);

    // The message is rendered at send time from the referenced row; nothing about it is
    // stored. A3.14: no member PII, no credential, and not even the owner's own number,
    // which is the recipient and does not need to be told it.
    expect(sent).toHaveLength(1);
    const body = sent[0].body;
    expect(body).toContain('gym:delete-soft');
    expect(body).toContain(`audit seq: ${auditRow.seq}`);
    expect(body).not.toContain(FORBIDDEN_PHONE);
    expect(body).not.toMatch(/\b\d{10,}\b/);

    const rendered = await service.render(row.id);
    expect(rendered).toBe(body);
  });

  it('A3.1 - a provider error is mapped onto the fixed code vocabulary and its text is discarded', () => {
    expect(classifyChannelFailure(new Error('not-configured'))).toBe('channel_not_configured');
    expect(classifyChannelFailure(new Error('timeout after 8000ms'))).toBe('channel_timeout');
    expect(classifyChannelFailure(new Error('connect ECONNREFUSED 1.2.3.4:443'))).toBe('channel_error');
    const arbitrary = classifyChannelFailure(
      new Error(`(#131047) Re-engagement message: ${FORBIDDEN_SECRET}`),
    );
    expect(arbitrary).toBe('channel_rejected');
    expect(arbitrary).not.toContain(FORBIDDEN_SECRET);
    for (const code of ALERT_ERROR_CODES) expect(typeof code).toBe('string');
  });

  it('A3.2 - backoff increases with each attempt and the window is a fixed constant', () => {
    const sequence = [0, 1, 2, 3, 4, 9].map((attempts) => backoffFor(attempts));
    for (let index = 1; index < 5; index += 1) expect(sequence[index]).toBeGreaterThan(sequence[index - 1]);
    // clamped, not exponential forever
    expect(sequence[5]).toBe(sequence[4]);
    expect(ALERT_DEDUPE_WINDOW_MS).toBe(15 * 60 * 1000);
    expect(dedupeBucket(ALERT_DEDUPE_WINDOW_MS - 1)).toBe(0);
    expect(dedupeBucket(ALERT_DEDUPE_WINDOW_MS)).toBe(1);
  });

  it('R3.11 - the alert vocabulary covers the five events the owner asked for, and the list route is paginated', async () => {
    for (const required of [
      'ADMIN_LOGIN_BURST',
      'ADMIN_NEW_DEVICE',
      'ADMIN_CREATED',
      'ADMIN_REMOVED',
      'SUBSCRIPTION_GRANTED',
      'GYM_DELETED',
    ]) {
      expect(PLATFORM_ALERT_TYPES).toContain(required);
    }

    const { service } = newService({ configured: true });
    const unique = `${MARKER}-page-${RUN_ID}`;
    for (let index = 0; index < 3; index += 1) {
      const raised = await service.raise({
        type: 'ADMIN_CREATED',
        targetKind: 'admin',
        targetId: `${unique}-${index}`,
      });
      if (raised && !raised.deduped) createdAlertIds.push(raised.id);
    }
    const page = await service.listForConsole({ limit: 2, page: 1, type: 'ADMIN_CREATED' });
    expect(page.rows.length).toBeLessThanOrEqual(2);
    expect(page.limit).toBe(2);
    expect(page.total).toBeGreaterThanOrEqual(3);
    // A3.1 again, on the read model: no body, no phone, no raw error.
    const serialised = JSON.stringify(page.rows);
    expect(serialised).not.toContain(FORBIDDEN_PHONE);
    for (const row of page.rows) {
      expect(Object.keys(row)).not.toContain('body');
      if (row.errorCode) expect(ALERT_ERROR_CODES).toContain(row.errorCode as never);
    }
  });

  it('R3.12b - phone set but the WhatsApp globals unset: NO_CHANNEL, not PENDING, and no send attempted', async () => {
    // The second of the two cases R3.12 asks for, and the one the owner ruled on directly
    // (2026-11-07): channelState() must report all three requirements so the console banner
    // names whatever is missing, and NO_CHANNEL must match what deliver() actually needs.
    //
    // BEFORE that decision this path was measured doing something worse than wrong: the alert
    // was attempted, failed with 'not-configured', and went back to PENDING for a bounded
    // retry - five attempts against a channel that could never work, ending in FAILED, which
    // reads as "we tried and the provider refused". Meanwhile channelState() was ALREADY
    // reporting all three variables to the console, so the banner and the row disagreed. The
    // fix was in deliver(), which consulted ownerPhone() alone.
    //
    // This goes through the REAL NotificationsService, not a fake, because the point is that
    // it is never reached: NotificationsService(prisma, gymMessaging) has two dependencies so
    // it can be constructed here, and gymMessaging is a spy whose call count is the assertion.
    setChannel(true);
    delete process.env.WHATSAPP_PHONE_ID;
    delete process.env.WHATSAPP_TOKEN;

    const gymMessaging = { sendWhatsAppText: jest.fn(async () => ({ success: false, error: 'not-configured' })) };
    const notifications = new NotificationsService({} as never, gymMessaging as never);
    const service = new PlatformAlertService(prisma, notifications as never, makeCronLeadership());

    // The console's own read model must name the two missing globals and NOT the phone.
    const state = service.channelState();
    expect(state.configured).toBe(false);
    expect(state.missing).toEqual(expect.arrayContaining(['WHATSAPP_PHONE_ID', 'WHATSAPP_TOKEN']));
    expect(state.missing).not.toContain('PLATFORM_OWNER_PHONE');
    for (const name of state.missing) expect(name).toMatch(/^[A-Z0-9_]+$/);

    const targetId = `${MARKER}-r312b-${RUN_ID}`;
    const result = await track(service, {
      type: 'ADMIN_LOGIN_BURST',
      severity: 'warning',
      targetKind: 'admin',
      targetId,
    });
    expect(result).not.toBeNull();
    expect(result!.deduped).toBe(false);

    const settled = await settledStatus(prisma, result!.id);
    const row = await prisma.platformAlert.findUniqueOrThrow({ where: { id: result!.id } });
    // eslint-disable-next-line no-console
    console.log(`R3_12B_DIAGNOSTIC settled=${settled} status=${row.status} attempts=${row.attempts} errorCode=${row.errorCode ?? '-'}`);

    expect(settled).toBe('NO_CHANNEL');
    expect(row.status).toBe('NO_CHANNEL');
    expect(row.status).not.toBe('PENDING');
    expect(row.errorCode).toBe('channel_not_configured');
    // No attempt was burned on a channel that could never work.
    expect(row.attempts).toBe(0);
    expect(gymMessaging.sendWhatsAppText).not.toHaveBeenCalled();

    // A3.1 still holds: the provider's error text is not stored, and neither is the phone.
    const serialised = JSON.stringify(row);
    expect(serialised).not.toContain('not-configured');
    expect(serialised).not.toContain(FORBIDDEN_PHONE);

    // and it is visible in the console read model, which is the whole of A3.4
    const listed = await service.listForConsole({ status: 'NO_CHANNEL' });
    expect(listed.channel.configured).toBe(false);
    expect(listed.rows.some((item) => item.id === row.id)).toBe(true);

    // The requeue route is what makes this actionable once the globals exist. NO_CHANNEL is
    // not PENDING, so the retry cron will never pick it up on its own.
    process.env.WHATSAPP_PHONE_ID = 'test-phone-id';
    process.env.WHATSAPP_TOKEN = 'test-token';
    expect(service.channelState().configured).toBe(true);
  });

  it('R3.15 - a failed audit write is fail-open for the action and fail-CLOSED for the record', async () => {
    // BEFORE R3, platform-auth.service.ts wrapped its audit write in .catch() and only logged,
    // so an action could succeed with no record and nobody would ever know. recordBestEffort
    // keeps the first half of that - the action must not fail - and removes the second: the
    // failure is classified and handed to a hook, and every hook in the product raises an
    // AUDIT_WRITE_FAILED alert, so a missing audit row becomes a visible event.
    const broken = {
      platformAuditLog: {
        create: jest.fn(async () => {
          throw new Error('simulated audit write failure');
        }),
      },
      $queryRaw: jest.fn(async () => {
        throw new Error('simulated audit write failure');
      }),
      $transaction: jest.fn(async () => {
        throw new Error('simulated audit write failure');
      }),
    } as unknown as PrismaClient;

    const auditService = new PlatformAuditService(broken);
    const hook = jest.fn(async () => undefined);

    // fail-open: this resolves, it does not reject, so the audited action still succeeds
    await expect(
      auditService.recordBestEffort(
        { adminId: `${MARKER}-audit-fail`, adminName: MARKER, action: `${MARKER}:write-failed`, target: null },
        hook,
      ),
    ).resolves.not.toThrow();

    // fail-closed for the record: the hook was called with a classified code, not swallowed
    expect(hook).toHaveBeenCalledTimes(1);
    const [failedAction, code] = hook.mock.calls[0] as [string, string];
    expect(failedAction).toBe(`${MARKER}:write-failed`);
    expect(typeof code).toBe('string');
    expect(code.length).toBeGreaterThan(0);

    // and the product's hook raises an alert that lands in the outbox
    const { service } = newService({ configured: true });
    const alert = await track(service, {
      type: 'AUDIT_WRITE_FAILED',
      severity: 'danger',
      targetKind: 'platform',
      details: { action: failedAction, code } as never,
    });
    expect(alert).not.toBeNull();
    const row = await prisma.platformAlert.findUniqueOrThrow({ where: { id: alert!.id } });
    expect(row.type).toBe('AUDIT_WRITE_FAILED');
    expect(row.severity).toBe('danger');
    // The error CODE travels; the underlying message, which here is a simulated failure string,
    // does not.
    expect(JSON.stringify(row)).not.toContain('simulated audit write failure');
  });
});
