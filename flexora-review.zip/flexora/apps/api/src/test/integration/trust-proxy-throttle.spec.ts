/**
 * PHASE O4.4 — live proof of what TRUST_PROXY_HOPS does to the login rate limiter.
 *
 * The brief's scenario, exactly:
 *   1. with hops = 1 and `X-Forwarded-For: 6.6.6.6, 203.0.113.9`, req.ip must be
 *      203.0.113.9 — the RIGHT-MOST entry, i.e. the address the trusted proxy
 *      appended, not the attacker-supplied prefix;
 *   2. six failed logins from ONE real address, each with a different spoofed
 *      prefix, must still be throttled — the spoofing must not buy fresh buckets;
 *   3. a DIFFERENT real address must not be throttled by those attempts.
 *
 * Which limiter protects login, measured here rather than assumed:
 *   * `@Throttle({ auth: { ttl: 900000, limit: 5 } })` on POST /api/auth/login —
 *     @nestjs/throttler, IN-MEMORY AND PER-PROCESS (no shared storage is
 *     configured). With more than one api replica each has its own counters, so
 *     the durable limit is nginx's `limit_req zone=login burst=3 nodelay`.
 *   * `BruteForceGuard` also runs on that route; the status code observed below
 *     tells you which one answered first.
 *
 * NODE_ENV is switched to development for this suite on purpose: ThrottlerModule
 * is configured with `skipIf: () => isTest()`, so under NODE_ENV=test there is no
 * throttling to observe. It is restored in afterAll.
 */
import { INestApplication, Logger, ValidationPipe } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';   // default import: this repo compiles with esModuleInterop
import { AppModule } from '../../app.module';
import { logTrustProxyHops, trustProxyHops } from '../../config/trust-proxy.config';
import { PrismaService } from '../../prisma/prisma.service';

const REAL_A = '203.0.113.9';    // TEST-NET-3, safe to name in a test
const REAL_B = '198.51.100.7';   // TEST-NET-2
const SPOOF_PREFIXES = ['6.6.6.6', '1.1.1.1', '9.9.9.9', '8.8.8.8', '4.4.4.4', '5.5.5.5', '7.7.7.7'];

describe('O4.4 TRUST_PROXY_HOPS and the login rate limiter (live)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  const seenIps: string[] = [];
  const originalNodeEnv = process.env.NODE_ENV;
  const originalHops = process.env.TRUST_PROXY_HOPS;

  beforeAll(async () => {
    // throttling is skipped under NODE_ENV=test, so this suite runs the app in
    // development mode and puts the value back afterwards
    process.env.NODE_ENV = 'development';
    process.env.TRUST_PROXY_HOPS = '1';

    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
    app = moduleRef.createNestApplication({ logger: false });
    app.setGlobalPrefix('api');
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true, forbidNonWhitelisted: false }));
    // the same two calls main.ts makes (src/main.ts, step 6.6), so this measures
    // the shipped behaviour rather than a re-implementation of it
    const hops = trustProxyHops();
    const instance = app.getHttpAdapter().getInstance() as { set?: (k: string, v: unknown) => void };
    if (typeof instance.set === 'function') instance.set('trust proxy', hops);
    logTrustProxyHops(new Logger('TrustProxySpec'), hops);
    // test-only probe: record what the framework resolved req.ip to
    app.use((req: any, _res: any, next: any) => { seenIps.push(String(req.ip)); next(); });
    await app.init();
    prisma = app.get(PrismaService);
  });

  afterAll(async () => {
    process.env.NODE_ENV = originalNodeEnv;
    if (originalHops === undefined) delete process.env.TRUST_PROXY_HOPS;
    else process.env.TRUST_PROXY_HOPS = originalHops;
    if (app) await app.close();
    if (prisma) await prisma.$disconnect();
  });

  it('resolves req.ip to the RIGHT-MOST forwarded entry with hops = 1', async () => {
    seenIps.length = 0;
    await request(app.getHttpServer())
      .get('/api/health/live')
      .set('X-Forwarded-For', `6.6.6.6, ${REAL_A}`)
      .expect(200);
    expect(seenIps).toContain(REAL_A);
    expect(seenIps).not.toContain('6.6.6.6');
  });

  it('takes the socket peer when no X-Forwarded-For is present', async () => {
    seenIps.length = 0;
    await request(app.getHttpServer()).get('/api/health/live').expect(200);
    expect(seenIps.length).toBeGreaterThan(0);
    expect(seenIps[0]).toMatch(/127\.0\.0\.1|::1|::ffff:127\.0\.0\.1/);
  });

  it('does not trust a spoofed prefix: hops = 1 keeps the real address', async () => {
    seenIps.length = 0;
    // an attacker prepends as many entries as they like; the right-most one is
    // what the trusted proxy appended
    await request(app.getHttpServer())
      .get('/api/health/live')
      .set('X-Forwarded-For', `1.2.3.4, 5.6.7.8, 9.9.9.9, ${REAL_A}`)
      .expect(200);
    expect(seenIps).toContain(REAL_A);
  });

  it('throttles six failed logins from ONE real address despite varying spoofed prefixes', async () => {
    const email = `o44-throttle-${Date.now()}@example.test`;
    const statuses: number[] = [];
    for (let i = 0; i < 6; i++) {
      const res = await request(app.getHttpServer())
        .post('/api/auth/login')
        .set('X-Forwarded-For', `${SPOOF_PREFIXES[i]}, ${REAL_A}`)
        .send({ email, password: 'WrongPassword!123' });
      statuses.push(res.status);
    }
    // the first attempts are ordinary auth failures; once the limiter's 5-per-15min
    // budget for THIS ip is spent the answer becomes 429 (or 423 from the
    // brute-force guard). Either way the sixth attempt must not be a plain 401.
    expect(statuses.slice(0, 5).every((s) => s === 401 || s === 400 || s === 429 || s === 423)).toBe(true);
    expect([429, 423]).toContain(statuses[5]);
    expect(statuses.filter((s) => s === 429 || s === 423).length).toBeGreaterThan(0);
  });

  it('does NOT throttle a different real address for those same attempts', async () => {
    const email = `o44-other-${Date.now()}@example.test`;
    const res = await request(app.getHttpServer())
      .post('/api/auth/login')
      .set('X-Forwarded-For', `${SPOOF_PREFIXES[0]}, ${REAL_B}`)
      .send({ email, password: 'WrongPassword!123' });
    // a fresh bucket: an ordinary auth failure, not a rate-limit answer
    expect([429, 423]).not.toContain(res.status);
    expect([400, 401]).toContain(res.status);
  });

  it('keeps the limiter per-process and in-memory (documented, not assumed)', () => {
    // No ThrottlerStorage provider is registered, so @nestjs/throttler uses its
    // in-memory tracker: counters live in THIS process and die with it. Read from
    // the module source, because "we did not configure shared storage" is exactly
    // the kind of claim that should be checked, not remembered.
    const mod = require('fs').readFileSync(require.resolve('../../app.module'), 'utf8');
    expect(mod).toMatch(/ThrottlerModule\.forRoot/);
    expect(mod).not.toMatch(/ThrottlerStorage[A-Za-z]*Service/);
    expect(mod).toMatch(/skipIf:\s*\(\)\s*=>\s*isTest\(\)/);
  });
});
