/**
 * FLEXORA Gym OS — Item 2 regression test: dedicated non-superuser
 * `flexora_app` Postgres role cannot bypass Row Level Security.
 *
 * This is a REAL Postgres integration test (no mocks). It requires:
 *   1. Migration 202607050001_flexora_app_role_force_rls to have been
 *      applied against the test database (creates the `flexora_app` role
 *      and FORCEs RLS on every tenant table).
 *   2. An env var FLEXORA_APP_TEST_PASSWORD set to whatever password was
 *      assigned to `flexora_app` in this environment.
 *      If it is not set, the suite is skipped with a clear message rather
 *      than failing (so it does not break `npm test` on machines where the
 *      role/migration have not been provisioned).
 *
 * We only use `@prisma/client` (already a project dependency) — no new
 * dependency is added for this test, in keeping with "do only the current
 * item's scope."
 */
import { PrismaClient } from '@prisma/client';

const APP_PASSWORD = process.env.FLEXORA_APP_TEST_PASSWORD;
const OWNER_URL = process.env.DATABASE_URL;

const maybeDescribe = APP_PASSWORD && OWNER_URL ? describe : describe.skip;

function buildAppUrl(): string {
  const url = new URL(OWNER_URL!);
  url.username = 'flexora_app';
  url.password = APP_PASSWORD!;
  // Force a single physical connection for this test client. This test is
  // specifically about proving RLS enforcement/role privileges, not about
  // connection-pool behavior (that race is covered separately by Item 1's
  // rls-connection-affinity.spec.ts) — a pooled client could otherwise route
  // `set_config` and the following query to two different connections and
  // produce a flaky false failure here, unrelated to what this test checks.
  url.searchParams.set('connection_limit', '1');
  return url.toString();
}

maybeDescribe('Item 2 — flexora_app role cannot bypass RLS (real Postgres)', () => {
  let owner: PrismaClient;
  let appClient: PrismaClient;

  let gymA: { id: string };
  let gymB: { id: string };
  let branchA: { id: string };
  let branchB: { id: string };
  let planA: { id: string };
  let planB: { id: string };
  let memberA: { id: string };
  let memberB: { id: string };

  beforeAll(async () => {
    owner = new PrismaClient({ datasources: { db: { url: OWNER_URL } } });
    await owner.$connect();

    appClient = new PrismaClient({ datasources: { db: { url: buildAppUrl() } } });
    await appClient.$connect();

    gymA = await owner.gym.create({
      data: { name: 'Role Test Gym A', slug: `role-test-a-${Date.now()}`, email: `rta-${Date.now()}@test.com`, phone: '0111' },
    });
    gymB = await owner.gym.create({
      data: { name: 'Role Test Gym B', slug: `role-test-b-${Date.now()}`, email: `rtb-${Date.now()}@test.com`, phone: '0222' },
    });
    branchA = await owner.branch.create({ data: { gymId: gymA.id, name: 'Branch A' } });
    branchB = await owner.branch.create({ data: { gymId: gymB.id, name: 'Branch B' } });
    planA = await owner.plan.create({ data: { gymId: gymA.id, name: 'Plan A', type: 'TIME', price: 100, days: 30 } });
    planB = await owner.plan.create({ data: { gymId: gymB.id, name: 'Plan B', type: 'TIME', price: 100, days: 30 } });
    memberA = await owner.member.create({
      data: {
        gymId: gymA.id, branchId: branchA.id, planId: planA.id,
        name: 'Role Test Member A', mobile: '01099990001', code: `RTA-${Date.now()}`, startDate: new Date(),
      },
    });
    memberB = await owner.member.create({
      data: {
        gymId: gymB.id, branchId: branchB.id, planId: planB.id,
        name: 'Role Test Member B', mobile: '01099990002', code: `RTB-${Date.now()}`, startDate: new Date(),
      },
    });
  }, 30000);

  afterAll(async () => {
    await owner.member.deleteMany({ where: { gymId: { in: [gymA.id, gymB.id] } } });
    await owner.plan.deleteMany({ where: { gymId: { in: [gymA.id, gymB.id] } } });
    await owner.branch.deleteMany({ where: { gymId: { in: [gymA.id, gymB.id] } } });
    await owner.gym.deleteMany({ where: { id: { in: [gymA.id, gymB.id] } } });
    await appClient.$disconnect();
    await owner.$disconnect();
  }, 30000);

  it('confirms flexora_app is neither superuser nor bypassrls', async () => {
    const rows: { rolsuper: boolean; rolbypassrls: boolean }[] = await owner.$queryRaw`
      SELECT rolsuper, rolbypassrls FROM pg_roles WHERE rolname = 'flexora_app'
    `;
    expect(rows.length).toBe(1);
    expect(rows[0].rolsuper).toBe(false);
    expect(rows[0].rolbypassrls).toBe(false);
  });

  it('flexora_app sees ZERO Member rows with no app.gym_id set (RLS default-deny)', async () => {
    await appClient.$executeRawUnsafe(`RESET app.gym_id`);
    const res: { id: string }[] = await appClient.$queryRawUnsafe(
      `SELECT id FROM "Member" WHERE id = ANY($1)`,
      [memberA.id, memberB.id],
    );
    expect(res.length).toBe(0);
  });

  it('flexora_app sees ONLY the matching gym\'s Member when app.gym_id is set', async () => {
    await appClient.$executeRawUnsafe(`SELECT set_config('app.gym_id', $1, false)`, gymA.id);
    const res: { id: string }[] = await appClient.$queryRawUnsafe(
      `SELECT id FROM "Member" WHERE id = ANY($1)`,
      [memberA.id, memberB.id],
    );
    expect(res.map((r) => r.id)).toEqual([memberA.id]);
  });

  it('flexora_app CANNOT disable RLS on a tenant table directly', async () => {
    await expect(appClient.$executeRawUnsafe(`ALTER TABLE "Member" DISABLE ROW LEVEL SECURITY`)).rejects.toThrow(
      /must be owner/i,
    );
  });

  it('flexora_app CANNOT drop a tenant isolation policy', async () => {
    await expect(
      appClient.$executeRawUnsafe(`DROP POLICY "Member_tenant_isolation" ON "Member"`),
    ).rejects.toThrow(/must be owner/i);
  });

  it('flexora_app CANNOT SET ROLE to the owner/superuser role', async () => {
    await expect(appClient.$executeRawUnsafe(`SET ROLE postgres`)).rejects.toThrow(/permission denied/i);
  });

  it('every table with RLS enabled also has FORCE ROW LEVEL SECURITY set', async () => {
    const rows: { relname: string; relrowsecurity: boolean; relforcerowsecurity: boolean }[] = await owner.$queryRaw`
      SELECT relname, relrowsecurity, relforcerowsecurity
      FROM pg_class c
      JOIN pg_namespace n ON n.oid = c.relnamespace
      WHERE n.nspname = current_schema() AND c.relkind = 'r' AND c.relrowsecurity = true
    `;
    expect(rows.length).toBeGreaterThan(0);
    const notForced = rows.filter((r) => !r.relforcerowsecurity);
    expect(notForced).toEqual([]);
  });
});

describe('Item 2 — test suite guard', () => {
  it('documents why this suite may be skipped in some environments', () => {
    if (!APP_PASSWORD) {
      // eslint-disable-next-line no-console
      console.warn(
        'Item 2 db-role-rls-enforcement.spec.ts: skipped because FLEXORA_APP_TEST_PASSWORD is not set. ' +
          'Set it (and ensure migration 202607050001_flexora_app_role_force_rls has been applied) to run this suite for real.',
      );
    }
    expect(true).toBe(true);
  });
});
