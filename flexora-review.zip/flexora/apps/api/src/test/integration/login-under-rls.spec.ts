import { PrismaClient } from '@prisma/client';
import { AuthService } from '../../modules/auth/auth.service';
import { PermissionsService } from '../../modules/permissions/permissions.service';
import { PrismaService } from '../../config/prisma.service';
import { UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { PasswordResetMailer } from '../../modules/auth/password-reset-mailer.service';
import { TwoFactorService } from '../../modules/auth/two-factor.service';
import { TenantContextService } from '../../common/services/tenant-context.service';
import { hashPassword } from '../../config/password-hash';

const APP_PASSWORD = process.env.FLEXORA_APP_TEST_PASSWORD;
const OWNER_URL = process.env.DATABASE_URL;
// PHASE N2 — this suite repoints process.env.DATABASE_URL at the unprivileged
// flexora_app role. In the full `npm test` run every suite shares ONE worker
// process, and PrismaService reads DATABASE_URL when it connects, so leaving
// it repointed silently downgraded every later suite to the app role:
// flexora-critical-flows' `PUT /api/messaging/config` answered 500 (RLS
// blocked the write) although the same suite passes 4/4 in isolation. The
// original value is captured here and restored in afterAll.
const ORIGINAL_DATABASE_URL = process.env.DATABASE_URL;

const maybeDescribe = APP_PASSWORD && OWNER_URL ? describe : describe.skip;

function buildAppUrl(): string {
  const url = new URL(OWNER_URL!);
  url.username = 'flexora_app';
  url.password = APP_PASSWORD!;
  return url.toString();
}

maybeDescribe('Item 1 — login succeeds under real flexora_app + FORCE RLS', () => {
  let owner: PrismaClient;
  let appPrisma: PrismaService;
  let authService: AuthService;
  const tenantContext = new TenantContextService();

  let gymA: { id: string };
  let memberUser: { id: string; email: string };
  const plainPassword = 'LoginRlsTestPassword123!';

  beforeAll(async () => {
    // 1. Setup data as superuser owner
    owner = new PrismaClient({ datasources: { db: { url: OWNER_URL } } });
    await owner.$connect();

    gymA = await owner.gym.create({
      data: { name: 'Login RLS Gym', slug: `login-rls-gym-${Date.now()}`, email: `lr-${Date.now()}@test.com`, phone: '0111' },
    });

    const passwordHash = await hashPassword(plainPassword);

    memberUser = await owner.user.create({
      data: {
        gymId: gymA.id,
        email: `login-rls-${Date.now()}@test.com`,
        name: 'Login RLS User',
        role: 'OWNER',
        passwordHash,
      },
    });

    // 2. Initialize the application-side Prisma client using the flexora_app role
    process.env.DATABASE_URL = buildAppUrl();
    appPrisma = new PrismaService(tenantContext);
    await appPrisma.onModuleInit();

    // 3. Initialize AuthService directly (bypassing full Nest boot for speed,
    // we only care about its DB interaction).
    const jwt = new JwtService({ secret: 'test-secret' });
    authService = new AuthService(
      appPrisma,
      jwt,
      {} as PasswordResetMailer,
      { verifyCode: jest.fn() } as unknown as TwoFactorService,
      tenantContext,
      { get: (k: string) => process.env[k] || 'fallback-secret' } as any,

      // PHASE N2 — AuthService gained a 7th constructor parameter

      // (PermissionsService, which fills `effectivePermissions` on the login

      // response). This call passed only six, ts-jest does not type-check the

      // suites, so `this.permissions` was undefined at runtime and every login

      // died with "Cannot read properties of undefined (reading

      // 'effectivePermissions')". The REAL service is constructed here (it only

      // needs the same app-role Prisma client + tenant context) — nothing mocked.

      new PermissionsService(appPrisma, tenantContext),
    );
  }, 30000);

  afterAll(async () => {
    // PHASE N2 — put DATABASE_URL back BEFORE anything else runs (see above).
    process.env.DATABASE_URL = ORIGINAL_DATABASE_URL ?? OWNER_URL ?? '';
    if (appPrisma) await appPrisma.onModuleDestroy();
    if (owner) {
      await owner.user.deleteMany({ where: { gymId: gymA.id } });
      await owner.gym.deleteMany({ where: { id: gymA.id } });
      await owner.$disconnect();
    }
  }, 30000);

  it('login succeeds with real credentials under flexora_app + FORCE RLS', async () => {
    // This calls authService.login, which MUST run a pre-auth lookup
    // with no gymId set yet. If it used a normal Prisma query, FORCE RLS
    // would filter out the user row and return Unauthorized.
    const result = await authService.login({
      email: memberUser.email,
      password: plainPassword,
    });

    expect(result).toBeDefined();
    if ('user' in result) {
      expect(result.user.id).toBe(memberUser.id);
      expect(result.user.email).toBe(memberUser.email);
    } else {
      throw new Error('Expected full AuthResponse, got TwoFaLoginResponse');
    }
  });

  it('login fails with wrong password under flexora_app + FORCE RLS', async () => {
    await expect(
      authService.login({
        email: memberUser.email,
        password: 'WrongPassword!',
      }),
    ).rejects.toThrow(UnauthorizedException);
  });

  it('login fails for non-existent user under flexora_app + FORCE RLS', async () => {
    await expect(
      authService.login({
        email: 'doesnotexist@example.com',
        password: plainPassword,
      }),
    ).rejects.toThrow(UnauthorizedException);
  });
});

describe('Item 1 — login RLS test suite guard', () => {
  it('documents why this suite may be skipped in some environments', () => {
    if (!APP_PASSWORD) {
      // eslint-disable-next-line no-console
      console.warn(
        'Item 1 login-under-rls.spec.ts: skipped because FLEXORA_APP_TEST_PASSWORD is not set. ' +
          'Set it (and ensure migration 202607050001_flexora_app_role_force_rls has been applied) to run this suite for real.',
      );
    }
    expect(true).toBe(true);
  });
});
