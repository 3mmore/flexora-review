/**
 * PHASE N3 — the refreshed access token must carry the CURRENT permissions claim.
 *
 * THE REGRESSION THIS PINS DOWN
 * -----------------------------
 * `POST /auth/refresh` rotates the refresh token inside
 * `this.prisma.$transaction(async (tx) => ...)`. Since PHASE N2 that callback
 * form is a REAL transaction (before N2 every statement silently auto-committed
 * on its own connection). The N2 override also sets the `inInteractiveTransaction`
 * AsyncLocalStorage flag so the `$extends` middleware stops wrapping statements
 * in `$transaction([set_config('app.gym_id', ...), query])`.
 *
 * `issueTokens()` runs inside that callback and asks
 * `PermissionsService.effectivePermissions()` for the overrides — a read issued
 * on the ROOT client, not on `tx`. With the wrapping suppressed it lands on a
 * pooled connection where `app.gym_id` was never set, `UserPermission` has FORCE
 * ROW LEVEL SECURITY, and the lookup returns ZERO rows without erroring. The
 * refreshed access token was therefore minted with ROLE DEFAULTS ONLY: an
 * `accounting.view` grant the owner had made disappeared from the `permissions`
 * claim, the web route gate (which reads that claim) bounced the employee from
 * `/expenses` to `/dashboard`, and they only got access back by logging out and
 * in again. Found live by the round-14 harness (2 checks) and reproduced
 * end-to-end by `work/n3-r14-repro.js`.
 *
 * WHY THIS SUITE NEEDS THE `flexora_app` ROLE
 * -------------------------------------------
 * The jest environment's `DATABASE_URL` is the SUPERUSER, which has BYPASSRLS —
 * under it the bug is invisible, because RLS never filters anything. This suite
 * therefore runs the code under test against the unprivileged `flexora_app` role
 * (the production role), exactly like `login-under-rls.spec.ts` and
 * `db-role-rls-enforcement.spec.ts`, and restores `process.env.DATABASE_URL`
 * before anything else in afterAll (every suite shares one worker process).
 *
 * THE FIX UNDER TEST
 * ------------------
 *   1. `PrismaService.outsideTransaction(fn)` — re-enters the ALS with the
 *      interactive-transaction flag cleared, so a root-client read gets its
 *      normal `set_config` wrapping back.
 *   2. `PermissionsService.effectivePermissions()` uses it for the override lookup.
 *   3. `AuthService.refresh()` computes the claim BEFORE opening the rotation
 *      transaction and passes it into `issueTokens()`.
 *
 * Nothing here is mocked: real Postgres, real RLS, real `AuthService.refresh()`.
 */
import { PrismaClient } from '@prisma/client';
import { JwtService } from '@nestjs/jwt';
import * as jwt from 'jsonwebtoken';
import { createHash, randomBytes } from 'crypto';
import { AuthService } from '../../modules/auth/auth.service';
import { PermissionsService } from '../../modules/permissions/permissions.service';
import { PrismaService } from '../../config/prisma.service';
import { PasswordResetMailer } from '../../modules/auth/password-reset-mailer.service';
import { TwoFactorService } from '../../modules/auth/two-factor.service';
import { TenantContextService } from '../../common/services/tenant-context.service';

const APP_PASSWORD = process.env.FLEXORA_APP_TEST_PASSWORD;
const OWNER_URL = process.env.DATABASE_URL;
// Captured BEFORE anything is repointed, restored first thing in afterAll.
const ORIGINAL_DATABASE_URL = process.env.DATABASE_URL;

const maybeDescribe = APP_PASSWORD && OWNER_URL ? describe : describe.skip;

function buildAppUrl(): string {
  const url = new URL(OWNER_URL!);
  url.username = 'flexora_app';
  url.password = APP_PASSWORD!;
  return url.toString();
}

/** A permission RECEPTION does NOT hold by default — the grant has to show up. */
const GRANT = 'accounting.view';

maybeDescribe('PHASE N3 — refresh re-mints the permissions claim from the database', () => {
  let owner: PrismaClient;
  let appPrisma: PrismaService;
  let permissions: PermissionsService;
  let authService: AuthService;
  const tenantContext = new TenantContextService();

  let gymId: string;
  let userId: string;
  let userEmail: string;
  const stamp = randomBytes(3).toString('hex');

  /** Mint a refresh token + its DB row as the superuser, the way the API does. */
  async function issueRefreshToken(): Promise<string> {
    const familyId = randomBytes(16).toString('hex');
    const token = jwt.sign(
      { sub: userId, familyId },
      process.env.JWT_REFRESH_SECRET as string,
      { expiresIn: '7d', algorithm: 'HS256' } as jwt.SignOptions,
    );
    await owner.refreshToken.create({
      data: {
        userId,
        tokenHash: createHash('sha256').update(token).digest('hex'),
        familyId,
        expiresAt: new Date(Date.now() + 7 * 24 * 3600 * 1000),
      },
    });
    return token;
  }

  /** Refresh for real and return the `permissions` claim of the NEW access token. */
  async function refreshClaim(refreshToken: string): Promise<{ claim: string[]; rotated: string }> {
    const res = await authService.refresh(refreshToken);
    const payload = jwt.decode(res.accessToken) as { permissions?: string[]; role?: string } | null;
    expect(payload).not.toBeNull();
    expect(payload!.role).toBe('RECEPTION');
    return { claim: payload!.permissions ?? [], rotated: res.refreshToken };
  }

  async function setGrant(granted: boolean) {
    await owner.userPermission.upsert({
      where: { userId_permission: { userId, permission: GRANT } },
      create: { userId, gymId, permission: GRANT, granted },
      update: { granted },
    });
  }

  beforeAll(async () => {
    // 1. Fixture data as the superuser (BYPASSRLS) — the code under test will
    //    run as flexora_app and must go through the policies.
    owner = new PrismaClient({ datasources: { db: { url: OWNER_URL } } });
    await owner.$connect();

    const gym = await owner.gym.create({
      data: {
        name: 'Refresh Claim Gym',
        slug: `refresh-claim-${stamp}-${Date.now()}`,
        email: `rc-${stamp}@test.com`,
        phone: '0100000000',
        status: 'ACTIVE',
      },
    });
    gymId = gym.id;

    const user = await owner.user.create({
      data: {
        gymId,
        name: 'Refresh Claim Reception',
        email: `rc-${stamp}-reception@test.com`,
        // never used: this suite drives AuthService.refresh(), not login()
        passwordHash: '$argon2id$v=19$m=65536,t=3,p=1$c2FsdHNhbHQ$ZmFrZWhhc2hmb3J0ZXN0aW5nb25seQ',
        role: 'RECEPTION',
        active: true,
        onboardingCompleted: true,
      },
    });
    userId = user.id;
    userEmail = user.email;

    // 2. The application-side client, on the UNPRIVILEGED role.
    process.env.DATABASE_URL = buildAppUrl();
    appPrisma = new PrismaService(tenantContext);
    await appPrisma.onModuleInit();

    permissions = new PermissionsService(appPrisma, tenantContext);
    authService = new AuthService(
      appPrisma,
      new JwtService({ secret: 'test-secret' }),
      {} as PasswordResetMailer,
      { verifyCode: jest.fn() } as unknown as TwoFactorService,
      tenantContext,
      { get: (k: string) => process.env[k] || 'fallback-secret' } as any,
      permissions,
    );
  }, 40000);

  afterAll(async () => {
    // Put DATABASE_URL back BEFORE anything else runs — every suite shares one
    // worker process, and a leaked app-role URL downgrades all later suites.
    process.env.DATABASE_URL = ORIGINAL_DATABASE_URL ?? OWNER_URL ?? '';
    if (appPrisma) await appPrisma.onModuleDestroy();
    if (owner) {
      await owner.userPermission.deleteMany({ where: { userId } }).catch(() => undefined);
      await owner.refreshToken.deleteMany({ where: { userId } }).catch(() => undefined);
      await owner.user.deleteMany({ where: { id: userId } }).catch(() => undefined);
      await owner.gym.deleteMany({ where: { id: gymId } }).catch(() => undefined);
      await owner.$disconnect();
    }
  }, 40000);

  it('sanity: RECEPTION does not hold the grant by default, so this suite can fail', async () => {
    const rt = await issueRefreshToken();
    const { claim } = await refreshClaim(rt);
    expect(Array.isArray(claim)).toBe(true);
    expect(claim.length).toBeGreaterThan(0);
    expect(claim).not.toContain(GRANT);
    // and the server-side computation agrees (no override rows yet)
    const direct = await permissions.effectivePermissions({ id: userId, role: 'RECEPTION', gymId });
    expect(direct).not.toContain(GRANT);
  });

  it('THE REGRESSION: a grant made after the token was issued appears in the refreshed claim', async () => {
    // A token issued while the employee had no override — exactly the r14 setup:
    // login first, owner grants afterwards, then the client refreshes.
    const rt = await issueRefreshToken();
    await setGrant(true);

    const { claim } = await refreshClaim(rt);

    // BEFORE the fix this was the RECEPTION default list without the grant,
    // because the UserPermission read inside the rotation transaction was
    // filtered to zero rows by FORCE RLS.
    expect(claim).toContain(GRANT);
    // ... and the rest of the role defaults must survive the round trip.
    expect(claim).toContain('members.view');
  });

  it('the security direction: a revocation appears in the refreshed claim too', async () => {
    const rt = await issueRefreshToken();
    await setGrant(true);
    const first = await refreshClaim(rt);
    expect(first.claim).toContain(GRANT);

    // Owner takes the permission away; the rotated token is presented again.
    await setGrant(false);
    const second = await refreshClaim(first.rotated);
    expect(second.claim).not.toContain(GRANT);
  });

  it('mechanism: effectivePermissions sees overrides from INSIDE $transaction', async () => {
    await setGrant(true);
    // This is the exact shape AuthService.refresh() used to break on: a
    // root-client read performed while the interactive-transaction flag is set.
    const insideTx = await appPrisma.$transaction(async () => {
      return permissions.effectivePermissions({ id: userId, role: 'RECEPTION', gymId });
    });
    expect(insideTx).toContain(GRANT);
  });

  it('mechanism: effectivePermissions sees overrides from INSIDE withTenant()', async () => {
    await setGrant(true);
    const insideWithTenant = await appPrisma.withTenant(gymId, async () => {
      return permissions.effectivePermissions({ id: userId, role: 'RECEPTION', gymId });
    });
    expect(insideWithTenant).toContain(GRANT);
  });

  it('mechanism: the same read outside any transaction still works (no over-correction)', async () => {
    await setGrant(true);
    const outside = await permissions.effectivePermissions({ id: userId, role: 'RECEPTION', gymId });
    expect(outside).toContain(GRANT);
    // and a different tenant's user never sees this gym's overrides
    const stranger = await permissions.effectivePermissions({
      id: `not-a-real-user-${stamp}`,
      role: 'RECEPTION',
      gymId,
    });
    expect(stranger).not.toContain(GRANT);
    expect(userEmail).toMatch(/@test\.com$/);
  });
});
