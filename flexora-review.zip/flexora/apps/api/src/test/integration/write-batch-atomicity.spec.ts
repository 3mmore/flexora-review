/**
 * FLEXORA Gym OS — PHASE N2: write batches must be atomic.
 *
 * WHAT WAS BROKEN
 * `PrismaService`'s tenant-RLS `$extends` middleware wraps every STANDALONE
 * model operation in `self.$transaction([set_config('app.gym_id', …), query])`
 * so the row-level policies can see the tenant. That is correct for a single
 * statement — but it means the ARRAY form of `$transaction` is not a
 * transaction at all: each element has already been wrapped (and started) in
 * its own `set_config`+query transaction by the time `$transaction([...])`
 * receives it. A batch of writes expressed that way commits statement by
 * statement, so a failure halfway through leaves the database half-updated.
 *
 * Four write batches in the app were written that way and have been converted
 * to a single interactive transaction via `withTenant()` (the pattern
 * `PlansService.remove` got in PHASE N1.5):
 *   • ClassService.cancelTemplate  — cancel future sessions + deactivate template
 *   • ClassService.cancelSession   — cancel bookings + cancel the session
 *   • ClassService.complete        — bookings ATTENDED + session COMPLETED
 *   • ExpensesService.remove       — delete the ledger Transaction + the Expense
 * (The callback form, `prisma.$transaction(async (tx) => …)`, was broken too
 * and is fixed in PrismaService itself — see
 * paymob-transaction-atomicity.spec.ts and
 * billing-nested-app-transaction-diagnostic.spec.ts for that proof.)
 *
 * HOW THIS PROVES IT — real Postgres, real services, real fault injection.
 * A BEFORE DELETE trigger on "Expense", scoped to this run's probe row, raises
 * on the SECOND statement of the batch. Nothing is mocked and no code path is
 * bypassed: the failure is exactly what a constraint violation, a deadlock or a
 * downstream error would look like in production.
 *   1. the old array form  → the ledger Transaction is GONE while the Expense
 *                            survives: a half-applied batch (the bug);
 *   2. the real ExpensesService.remove → BOTH rows survive: rolled back
 *                            together (the fix);
 *   3. with the trigger dropped, the real service deletes BOTH (the fix did
 *                            not break the happy path).
 */
import { PrismaClient } from '@prisma/client';
import { randomBytes } from 'crypto';
import { PrismaService } from '../../prisma/prisma.service';
import { TenantContextService } from '../../common/services/tenant-context.service';
import { RedisService } from '../../config/redis.service';
import { ExpensesService } from '../../modules/expenses/expenses.service';

const OWNER_URL = process.env.DATABASE_URL;
const maybeDescribe = OWNER_URL ? describe : describe.skip;

maybeDescribe('PHASE N2 — write batches are atomic (withTenant), the array form is not', () => {
  const RUN_ID = randomBytes(3).toString('hex');
  const gymId = `n2wb-gym-${RUN_ID}`;
  const expenseId = `n2wb-expense-${RUN_ID}`;
  const ledgerId = `n2wb-ledger-${RUN_ID}`;
  const triggerName = `n2wb_fail_expense_delete_${RUN_ID}`;
  const fnName = `n2wb_fail_expense_delete_${RUN_ID}`;
  const FAULT = 'N2_SIMULATED_FAILURE_DURING_EXPENSE_DELETE';

  let admin: PrismaClient;
  let prisma: PrismaService;
  let tenantContext: TenantContextService;
  let expenses: ExpensesService;
  let redis: RedisService;

  /** The Expense plus the ledger Transaction that ExpensesService.remove deletes with it. */
  const seedBatch = async () => {
    await admin.expense.upsert({
      where: { id: expenseId },
      update: {},
      create: {
        id: expenseId,
        gymId,
        category: 'Maintenance',
        description: `N2 write-batch probe ${RUN_ID}`,
        amount: 120,
      },
    });
    await admin.transaction.upsert({
      where: { id: ledgerId },
      update: { expenseId },
      create: {
        id: ledgerId,
        gymId,
        type: 'EXPENSE',
        category: 'Maintenance',
        description: `N2 ledger row ${RUN_ID}`,
        amount: 120,
        expenseId,
      },
    });
  };

  const installFault = async () => {
    await admin.$executeRawUnsafe(
      `CREATE OR REPLACE FUNCTION ${fnName}() RETURNS trigger AS $fn$
       BEGIN
         RAISE EXCEPTION '${FAULT}';
       END
       $fn$ LANGUAGE plpgsql;`,
    );
    await admin.$executeRawUnsafe(
      `CREATE TRIGGER ${triggerName}
         BEFORE DELETE ON "Expense" FOR EACH ROW
         WHEN (OLD.id = '${expenseId}')
         EXECUTE FUNCTION ${fnName}();`,
    );
  };

  const removeFault = async () => {
    await admin.$executeRawUnsafe(`DROP TRIGGER IF EXISTS ${triggerName} ON "Expense";`);
    await admin.$executeRawUnsafe(`DROP FUNCTION IF EXISTS ${fnName}();`);
  };

  beforeAll(async () => {
    admin = new PrismaClient({ datasources: { db: { url: OWNER_URL } } });
    await admin.$connect();
    tenantContext = new TenantContextService();
    prisma = new PrismaService(tenantContext);
    await prisma.onModuleInit();
    // Held in a variable so afterAll can close it: an ioredis connection left
    // open is exactly the kind of handle that stops a jest worker from exiting.
    redis = new RedisService();
    expenses = new ExpensesService(prisma, redis);

    await admin.gym.create({
      data: {
        id: gymId,
        name: `N2 Write-Batch ${RUN_ID}`,
        slug: `n2wb-${RUN_ID}`,
        email: `n2wb-${RUN_ID}@test.com`,
        phone: '01000000000',
      },
    });
    await seedBatch();
    await installFault();
  }, 60000);

  afterAll(async () => {
    // The trigger is scoped to this run's expense id, but never leave one behind.
    await removeFault().catch(() => undefined);
    if (admin) {
      await admin.transaction.deleteMany({ where: { gymId } }).catch(() => undefined);
      await admin.expense.deleteMany({ where: { gymId } }).catch(() => undefined);
      await admin.gym.deleteMany({ where: { id: gymId } }).catch(() => undefined);
      await admin.$disconnect().catch(() => undefined);
    }
    if (redis) await redis.onModuleDestroy().catch(() => undefined);
    if (prisma) await prisma.onModuleDestroy().catch(() => undefined);
  }, 60000);

  it('the OLD array form leaves the batch HALF-APPLIED when the second statement fails', async () => {
    // Exactly what ExpensesService.remove used to do. tenantContext.run() is
    // what makes this reproduce: the middleware only wraps statements when a
    // tenant is in context, which is the case for every authenticated request.
    await tenantContext.run(gymId, async () => {
      await expect(
        prisma.$transaction([
          prisma.transaction.deleteMany({ where: { gymId, expenseId } }),
          prisma.expense.delete({ where: { id: expenseId, gymId } }),
        ]),
      ).rejects.toThrow(FAULT);
    });

    const ledgerRows = await admin.transaction.count({ where: { gymId, expenseId } });
    const expenseRow = await admin.expense.findUnique({ where: { id: expenseId } });

    // The ledger deletion COMMITTED on its own connection; the expense deletion
    // failed. Money data half-deleted, expense still on the books.
    expect(ledgerRows).toBe(0);
    expect(expenseRow).not.toBeNull();
  }, 30000);

  it('the REAL ExpensesService.remove rolls the whole batch back on the same failure', async () => {
    await seedBatch(); // put back the ledger row the previous test lost

    await tenantContext.run(gymId, async () => {
      await expect(expenses.remove(gymId, expenseId)).rejects.toThrow(FAULT);
    });

    const ledgerRows = await admin.transaction.count({ where: { gymId, expenseId } });
    const expenseRow = await admin.expense.findUnique({ where: { id: expenseId } });

    // One interactive transaction: both statements are gone together.
    expect(ledgerRows).toBe(1);
    expect(expenseRow).not.toBeNull();
  }, 30000);

  it('with the fault removed, the real service still deletes BOTH rows (happy path intact)', async () => {
    await removeFault();

    await tenantContext.run(gymId, async () => {
      await expect(expenses.remove(gymId, expenseId)).resolves.toEqual({ ok: true });
    });

    expect(await admin.expense.findUnique({ where: { id: expenseId } })).toBeNull();
    expect(await admin.transaction.count({ where: { gymId, expenseId } })).toBe(0);
  }, 30000);
});
