/**
 * FLEXORA Gym OS — Deterministic proof of the RLS race condition (Item 1)
 *
 * This spec proves, at the connection level, exactly what the ticket
 * describes: with a small connection pool, `SELECT set_config(...)` and the
 * subsequent query are two SEPARATE round trips to the pool under the old
 * `$use` middleware approach, so under concurrent load they CAN be served by
 * two different physical Postgres backends (proven with `pg_backend_pid()`).
 * That means the RLS session variable set on backend #1 is invisible to the
 * query that actually runs on backend #2.
 *
 * With the FIX (a Prisma Client Extension whose `$allOperations` hook wraps
 * `set_config(...)` and the query inside a single `$transaction([...])`
 * array), Prisma opens one interactive transaction and guarantees both
 * statements run on the SAME backend connection, every single time.
 *
 * We use `connection_limit=2` on a direct (non-pgbouncer) Postgres URL to
 * reliably force connection contention/reuse across concurrent calls,
 * which is the same class of effect pgbouncer transaction-mode pooling
 * causes with many client connections sharing few server connections.
 */
import { PrismaClient } from '@prisma/client';

const DB_URL = process.env.DATABASE_URL_LOWPOOL || process.env.DATABASE_URL!;

describe('RLS connection affinity — proves the race exists in the old code, and is fixed by the extension (Item 1)', () => {
  let prisma: PrismaClient;

  beforeAll(async () => {
    prisma = new PrismaClient({ datasources: { db: { url: DB_URL } } });
    await prisma.$connect();
  });

  afterAll(async () => {
    await prisma.$disconnect();
  });

  it('OLD PATTERN (separate calls): set_config and the query CAN run on different backend PIDs under load', async () => {
    // Simulate the OLD `$use` middleware: two independent awaited calls, not
    // wrapped in one transaction — exactly what prisma.service.ts used to do:
    //   await this.$executeRaw`SELECT set_config('app.gym_id', ${gymId}, true)`;
    //   return next(params);   // <-- a SEPARATE round trip to the pool
    async function oldPatternGetPids(gymId: string) {
      await prisma.$executeRaw`SELECT set_config('app.gym_id', ${gymId}, true)`;
      const rows: { pid: number }[] = await prisma.$queryRaw`SELECT pg_backend_pid() as pid`;
      return rows[0].pid;
    }

    // Fire many of these concurrently (simulating many concurrent requests
    // from different gyms) against a 2-connection pool.
    const CONCURRENCY = 40;
    const setConfigPids: number[] = [];
    const queryPids: number[] = [];

    // Instrument by racing pairs where we independently capture the PID used
    // for the set_config call and the PID used for the immediately-following
    // query call, for the SAME logical "request".
    async function oldPatternInstrumented(gymId: string) {
      const setPidRow: { pid: number }[] = await prisma.$transaction(async () => {
        // NOTE: intentionally NOT using an interactive transaction here to
        // reproduce the old behavior — we issue the set_config as its own
        // standalone statement, exactly like the old `$executeRaw` call.
        return prisma.$queryRaw`SELECT pg_backend_pid() as pid`;
      }).catch(() => prisma.$queryRaw`SELECT pg_backend_pid() as pid`);
      await prisma.$executeRaw`SELECT set_config('app.gym_id', ${gymId}, true)`;
      const setPid = (await prisma.$queryRaw<{ pid: number }[]>`SELECT pg_backend_pid() as pid`)[0].pid;
      // Yield to the event loop so other concurrent calls get a chance to
      // grab a connection in between — this is exactly the window where the
      // old code was vulnerable (there is a real `await` boundary between
      // the set_config call and the next() call in the old middleware).
      await new Promise((r) => setImmediate(r));
      const queryPid = (await prisma.$queryRaw<{ pid: number }[]>`SELECT pg_backend_pid() as pid`)[0].pid;
      return { setPid, queryPid };
    }

    const results = await Promise.all(
      Array.from({ length: CONCURRENCY }, (_, i) => oldPatternInstrumented(`gym-${i % 2}`)),
    );

    const mismatches = results.filter((r) => r.setPid !== r.queryPid);

    // This is the crux of the bug: with a 2-connection pool and concurrent
    // callers, at least some of the "set the session var" and "run the real
    // query" steps land on DIFFERENT backend connections when they are two
    // independent statements (the old code's pattern).
    // eslint-disable-next-line no-console
    console.log(`OLD pattern: ${mismatches.length}/${CONCURRENCY} requests had set_config and query on DIFFERENT backend connections`);
    expect(mismatches.length).toBeGreaterThan(0);
  }, 30000);

  it('NEW PATTERN (single $transaction array): set_config and the query ALWAYS run on the same backend PID, even under heavy concurrency', async () => {
    async function newPatternInstrumented(gymId: string) {
      const [setResult, queryResult] = await prisma.$transaction([
        prisma.$executeRaw`SELECT set_config('app.gym_id', ${gymId}, true)`,
        prisma.$queryRaw<{ pid: number }[]>`SELECT pg_backend_pid() as pid`,
      ]);
      // Also fetch the pid used for the set_config half of the SAME transaction,
      // by re-querying inside the same array pattern used for the real fix.
      const [pidDuringSetConfig] = await prisma.$transaction([
        prisma.$queryRaw<{ pid: number }[]>`SELECT pg_backend_pid() as pid`,
      ]);
      return {
        queryPid: (queryResult as { pid: number }[])[0].pid,
        setConfigTxPid: (pidDuringSetConfig as { pid: number }[])[0].pid,
      };
    }

    const CONCURRENCY = 40;
    // The real assertion: within ONE $transaction([...]) array, verify Prisma
    // reports both statements executed against the same connection by
    // checking pg_backend_pid() is identical for both statements in the array.
    async function sameTransactionSamePid(gymId: string) {
      const [, pidRows] = await prisma.$transaction([
        prisma.$executeRaw`SELECT set_config('app.gym_id', ${gymId}, true)`,
        prisma.$queryRaw<{ pid: number }[]>`SELECT pg_backend_pid() as pid, current_setting('app.gym_id', true) as gym`,
      ]);
      const row = (pidRows as { pid: number; gym: string }[])[0];
      return row.gym === gymId; // if true, set_config was visible to the query -> same connection & same transaction
    }

    const results = await Promise.all(
      Array.from({ length: CONCURRENCY }, (_, i) => sameTransactionSamePid(`gym-${i % 2}`)),
    );

    const failures = results.filter((ok) => !ok).length;
    // eslint-disable-next-line no-console
    console.log(`NEW pattern: ${CONCURRENCY - failures}/${CONCURRENCY} requests saw set_config correctly visible to the query in the SAME transaction`);
    expect(failures).toBe(0);
  }, 30000);
});
