/** @jest-environment node */
/**
 * FLEXORA Gym OS - Backend API
 * (c) 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R4 - R4.7 (the Overview is cached for 60 s) and R4.8 (bounded Redis timeouts: a slow
 * or dead Redis must neither hang nor fail the page, and the fallback is uncached data).
 *
 * R4.8 says the bound has to be PROVEN BY A TEST THAT MAKES REDIS SLOW, not by reading the
 * client configuration. So the central test below installs a Redis stub whose get() takes two
 * seconds, and asserts that read() still resolves - inside the bound, with outcome 'timeout',
 * and without throwing. A version of this service that simply awaited the client would hang
 * for two seconds here and fail the assertion on elapsed time.
 *
 * WHY A SECOND LAYER OF BOUNDING IS NEEDED AT ALL, given that PHASE P3 already made every Redis
 * command finite: P3's own comment states the contract callers owe - "caches fall back to the
 * database" - and warns that DependencyUnavailableFilter turns an unhandled rejection on a
 * request path into 503 + Retry-After. So without this service, a Redis outage would not hang
 * the Overview, it would FAIL it with a 503. P3 bounded the command; this bounds the caller's
 * tolerance and converts the failure into a cache miss.
 */
import {
  PlatformCacheService,
  PLATFORM_CACHE_REDIS_BOUND_MS,
  PLATFORM_CACHE_TTL_SECONDS,
  PLATFORM_CACHE_KEYS,
} from '../../modules/platform/platform-cache.service';
import { RedisService, REDIS_COMMAND_TIMEOUT_MS } from '../../config/redis.service';

jest.setTimeout(60_000);

type Stub = {
  get: jest.Mock;
  set: jest.Mock;
  del: jest.Mock;
};

function stubRedis(behaviour: {
  getDelayMs?: number;
  getRejects?: boolean;
  setDelayMs?: number;
  setRejects?: boolean;
  delRejects?: boolean;
  store?: Map<string, string>;
} = {}): Stub {
  const store = behaviour.store ?? new Map<string, string>();
  const wait = (ms?: number) => (ms ? new Promise((resolve) => setTimeout(resolve, ms)) : Promise.resolve());
  return {
    get: jest.fn(async (key: string) => {
      await wait(behaviour.getDelayMs);
      if (behaviour.getRejects) throw new Error('simulated redis outage');
      return store.has(key) ? (store.get(key) as string) : null;
    }),
    set: jest.fn(async (key: string, value: string, ttl?: number) => {
      await wait(behaviour.setDelayMs);
      if (behaviour.setRejects) throw new Error('simulated redis outage');
      store.set(key, value);
      return ttl ? 'OK' : 'OK';
    }),
    del: jest.fn(async (key: string) => {
      if (behaviour.delRejects) throw new Error('simulated redis outage');
      store.delete(key);
      return 1;
    }),
  };
}

const asRedis = (stub: Stub) => stub as unknown as RedisService;

describe('R4.7 / R4.8 - the platform read cache and its Redis bound', () => {
  it('R4.7 - the TTL is the 60 seconds the brief specifies, and the bound is tighter than the P3 command timeout', () => {
    expect(PLATFORM_CACHE_TTL_SECONDS).toBe(60);
    // The point of a separate, tighter bound: P3 caps a command at 1500 ms, which is far too
    // long to pay just to discover that an OPTIMISATION is unavailable. Asserting the
    // relationship rather than only the number means raising P3's timeout cannot silently make
    // the cache bound meaningless.
    expect(PLATFORM_CACHE_REDIS_BOUND_MS).toBeLessThan(REDIS_COMMAND_TIMEOUT_MS);
    expect(PLATFORM_CACHE_REDIS_BOUND_MS).toBe(250);
  });

  it('R4.7 - a value written is read back as a hit, with the 60 s TTL actually passed to Redis', async () => {
    const store = new Map<string, string>();
    const stub = stubRedis({ store });
    const cache = new PlatformCacheService(asRedis(stub));
    const key = PLATFORM_CACHE_KEYS.overview;

    const first = await cache.read<Record<string, unknown>>(key);
    expect(first.hit).toBe(false);
    expect(first.outcome).toBe('miss');
    expect(first.value).toBeNull();

    const payload = { totalGyms: 3, activeGyms: 2, monthlyRevenue: 1234.5 };
    expect(await cache.write(key, payload)).toBe('written');
    expect(stub.set).toHaveBeenCalledWith(key, JSON.stringify(payload), PLATFORM_CACHE_TTL_SECONDS);

    const second = await cache.read<Record<string, unknown>>(key);
    expect(second.hit).toBe(true);
    expect(second.outcome).toBe('hit');
    expect(second.value).toEqual(payload);
  });

  it('R4.8 - a SLOW Redis does not hang the read: it resolves inside the bound as a timeout miss', async () => {
    // Two seconds of delay against a 250 ms bound. This is the test R4.8 asks for by name.
    const cache = new PlatformCacheService(asRedis(stubRedis({ getDelayMs: 2000 })));
    const startedAt = Date.now();
    const result = await cache.read<Record<string, unknown>>(PLATFORM_CACHE_KEYS.overview);
    const elapsed = Date.now() - startedAt;

    expect(result.hit).toBe(false);
    expect(result.value).toBeNull();
    expect(result.outcome).toBe('timeout');
    // Generous slack for a loaded 2 GB box, but an order of magnitude below the stub's delay:
    // if the bound were removed this would take ~2000 ms and fail.
    expect(elapsed).toBeLessThan(PLATFORM_CACHE_REDIS_BOUND_MS + 400);
    expect(elapsed).toBeGreaterThanOrEqual(PLATFORM_CACHE_REDIS_BOUND_MS - 50);
  });

  it('R4.8 - a DEAD Redis is a miss, not an exception: the route would fall through to the database', async () => {
    const cache = new PlatformCacheService(asRedis(stubRedis({ getRejects: true })));
    await expect(cache.read(PLATFORM_CACHE_KEYS.overview)).resolves.toEqual({
      hit: false,
      value: null,
      outcome: 'unavailable',
    });
  });

  it('R4.8 - a slow or dead Redis cannot fail the WRITE either, and the response is already served', async () => {
    const slow = new PlatformCacheService(asRedis(stubRedis({ setDelayMs: 2000 })));
    const startedAt = Date.now();
    await expect(slow.write(PLATFORM_CACHE_KEYS.overview, { a: 1 })).resolves.toBe('skipped');
    expect(Date.now() - startedAt).toBeLessThan(PLATFORM_CACHE_REDIS_BOUND_MS + 400);

    const dead = new PlatformCacheService(asRedis(stubRedis({ setRejects: true })));
    await expect(dead.write(PLATFORM_CACHE_KEYS.overview, { a: 1 })).resolves.toBe('skipped');
  });

  it('R4.8 - invalidate() survives a dead Redis, so a mutation is never blocked by the cache', async () => {
    const stub = stubRedis({ delRejects: true });
    const cache = new PlatformCacheService(asRedis(stub));
    await expect(
      cache.invalidate(PLATFORM_CACHE_KEYS.overview, PLATFORM_CACHE_KEYS.revenueChart(12)),
    ).resolves.toBeUndefined();
    expect(stub.del).toHaveBeenCalledTimes(2);
  });

  it('invalidate() really removes the entries, so a mutation is not hidden behind a stale aggregate', async () => {
    const store = new Map<string, string>();
    const stub = stubRedis({ store });
    const cache = new PlatformCacheService(asRedis(stub));

    await cache.write(PLATFORM_CACHE_KEYS.overview, { totalGyms: 1 });
    await cache.write(PLATFORM_CACHE_KEYS.revenueChart(12), [{ month: '2026-11', value: 5 }]);
    expect((await cache.read(PLATFORM_CACHE_KEYS.overview)).hit).toBe(true);

    await cache.invalidate(PLATFORM_CACHE_KEYS.overview, PLATFORM_CACHE_KEYS.revenueChart(12));

    expect((await cache.read(PLATFORM_CACHE_KEYS.overview)).outcome).toBe('miss');
    expect((await cache.read(PLATFORM_CACHE_KEYS.revenueChart(12))).outcome).toBe('miss');
  });

  it('a corrupt cached payload is treated as a miss, never served half-decoded to the console', async () => {
    const store = new Map<string, string>([[PLATFORM_CACHE_KEYS.overview, '{"totalGyms":']]);
    const cache = new PlatformCacheService(asRedis(stubRedis({ store })));
    const result = await cache.read<Record<string, unknown>>(PLATFORM_CACHE_KEYS.overview);
    expect(result.hit).toBe(false);
    expect(result.value).toBeNull();
    expect(result.outcome).toBe('unavailable');
  });

  it('the chart keys are namespaced by month count, so ?months=6 cannot be served a 12-month payload', () => {
    expect(PLATFORM_CACHE_KEYS.revenueChart(6)).not.toBe(PLATFORM_CACHE_KEYS.revenueChart(12));
    expect(PLATFORM_CACHE_KEYS.gymGrowth(6)).not.toBe(PLATFORM_CACHE_KEYS.gymGrowth(12));
    expect(PLATFORM_CACHE_KEYS.revenueChart(12)).not.toBe(PLATFORM_CACHE_KEYS.gymGrowth(12));
    // versioned, so a changed response shape cannot be served from an entry written before it
    expect(PLATFORM_CACHE_KEYS.overview).toMatch(/:v\d+$/);
  });

  it('R4.7 - against the REAL Redis, a written entry carries a TTL of about 60 seconds', async () => {
    // The stubs above prove the service passes 60; this proves Redis accepts it and expires the
    // key, which is what makes "cached 60 s" true rather than merely intended.
    const redis = new RedisService();
    // PHASE P3 sets enableOfflineQueue:false, which means a command issued before the socket is
    // ready REJECTS AT ONCE rather than waiting - that is P3 working exactly as designed, and it
    // is why this test returned 'skipped' on its first run. Wait for readiness instead of racing
    // the connection, with a hard stop so a broken Redis cannot hang the suite.
    await new Promise<void>((resolve) => {
      if (redis.client.status === 'ready') {
        resolve();
        return;
      }
      const timer = setTimeout(resolve, 5000);
      redis.client.once('ready', () => {
        clearTimeout(timer);
        resolve();
      });
    });
    const cache = new PlatformCacheService(redis);
    const key = `platform:r4-spec:${Date.now().toString(36)}`;
    try {
      expect(await cache.write(key, { probe: true })).toBe('written');
      const ttl = await redis.client.ttl(key);
      expect(ttl).toBeGreaterThan(PLATFORM_CACHE_TTL_SECONDS - 5);
      expect(ttl).toBeLessThanOrEqual(PLATFORM_CACHE_TTL_SECONDS);
      expect((await cache.read<{ probe: boolean }>(key)).value).toEqual({ probe: true });
    } finally {
      await redis.client.del(key).catch(() => undefined);
      await redis.onModuleDestroy().catch(() => undefined);
    }
  });
});
