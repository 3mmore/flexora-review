import { Test, TestingModule } from '@nestjs/testing';
import { AppModule } from '../../app.module';
import { PrismaService } from '../../config/prisma.service';
import { BackupsService } from '../../modules/backups/backups.service';
import { EncryptionService } from '../../common/security/encryption.service';
import { randomBytes, randomInt } from 'crypto';
import { join } from 'path';
import * as fs from 'fs';

describe('Disaster Recovery: Restore Drill', () => {
  let prisma: PrismaService;
  let backups: BackupsService;
  let encryption: EncryptionService;
  // PHASE N2 — hoisted so afterAll can close the application (see below).
  let moduleFixture: TestingModule | undefined;
  let drillGymId: string | undefined;

  beforeAll(async () => {
    process.env.IMPORT_UPLOAD_DIR = '/tmp/flexora/imports';
    process.env.BACKUP_DIR = '/tmp/flexora/backups';
    process.env.CONTRACT_PDF_DIR = '/tmp/flexora/contracts';

    moduleFixture = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();
    // PHASE Q4a — FIXTURE fix #1. `.compile()` instantiates the providers but runs
    // NONE of their lifecycle hooks, and `EncryptionService.onModuleInit()` is what
    // derives `searchKey` from ENCRYPTION_SEARCH_KEY. Every deterministic-encryption
    // call in this drill therefore died before the first assertion:
    //     ● should accurately reconstruct data from an Excel backup
    //       Error: Search key not initialized
    //         at EncryptionService.encryptDeterministic (common/security/encryption.service.ts:129)
    // `init()` is what a real bootstrap does (`main.ts` reaches it through
    // `app.listen()`), so the fixture was missing a step the product always takes.
    // The existing `afterAll` already calls `moduleFixture.close()`.
    await moduleFixture.init();

    prisma = moduleFixture.get(PrismaService);
    backups = moduleFixture.get(BackupsService);
    encryption = moduleFixture.get(EncryptionService);
  });

  it('should accurately reconstruct data from an Excel backup', async () => {
    // Choice: We choose to restore into the same test database for this drill.
    // Safety: Every operation is scoped by gymId, and we create a unique one.
    
    const gymSlug = `drill-${randomBytes(4).toString('hex')}`;
    const gym = await prisma.gym.create({
      data: {
        name: 'Drill Gym',
        slug: gymSlug,
        email: `${gymSlug}@drill.com`,
        phone: '01000000000',
      },
    });

    // PHASE N2 — remembered so afterAll can delete the drill gym.
    drillGymId = gym.id;
    const branch = await prisma.branch.create({
      data: { gymId: gym.id, name: 'Drill Branch' }
    });

    const plan = await prisma.plan.create({
      data: { gymId: gym.id, name: 'Drill Plan', type: 'TIME', price: 100, days: 30 }
    });

    // 1. Seed N members, M sales, K attendance records
    const N = 5, M = 3, K = 4;
    
    // PHASE Q4a — FIXTURE fix #2. `mobile` is a deterministically encrypted column
    // in production: MembersService writes `encryption.encryptDeterministic(value)`
    // (modules/members/members.service.ts:433) and queries compare against the
    // ciphertext. This drill wrote the PLAINTEXT straight through Prisma, i.e. a
    // row shape production never contains, and then compared it with what the
    // restore produced — and the restore (correctly, per PHASE P2) re-encrypts the
    // value it reads back out of the sheet, so the assertion compared plaintext
    // with a `{"kid":"search-v1",...}` envelope:
    //     Expected: "01070140801"
    //     Received: "{\"kid\":\"search-v1\",\"iv\":\"00L0KQGqR07KV2KC\",...}"
    // Seeding through the same encryption the product uses makes the drill test the
    // real round trip, and the assertions below are STRICTER than before: the
    // ciphertext must come back byte for byte AND still decrypt to the plaintext.
    const memberMobiles: string[] = [];
    const members = [];
    for (let i = 0; i < N; i++) {
      const plainMobile = `010${randomInt(10000000, 99999999)}`;
      memberMobiles.push(plainMobile);
      members.push(await prisma.member.create({
        data: {
          gymId: gym.id,
          branchId: branch.id,
          planId: plan.id,
          name: `Member ${i}`,
          mobile: encryption.encryptDeterministic(plainMobile),
          // PHASE R2 - FIXTURE fix, no assertion touched. This was
          // `D${randomInt(1000, 9999)}`: 9000 possible codes for N=5 members, so a
          // birthday collision on the (gymId, code) unique constraint fails the whole
          // drill roughly one run in a thousand. Measured, not guessed: the full jest
          // run of 2026-11-07T03:02Z died with "Unique constraint failed on the fields:
          // (`gymId`,`code`)", and the same suite passes 1/1 in isolation. Deriving the
          // code from the already-unique gym slug plus the loop index makes it
          // deterministic and impossible to collide, and changes nothing the drill
          // asserts - it still writes, exports, wipes and reconstructs the same rows.
          code: `D${gymSlug.slice(-5).toUpperCase()}${i}`,
          startDate: new Date(),
        }
      }));
    }

    const sales = [];
    for (let i = 0; i < M; i++) {
      sales.push(await prisma.sale.create({
        data: {
          gymId: gym.id,
          memberId: members[0].id,
          invoiceNo: `INV-DRILL-${i}`,
          total: 100,
          method: 'CASH',
        }
      }));
    }

    const attendance = [];
    for (let i = 0; i < K; i++) {
      attendance.push(await prisma.attendance.create({
        data: {
          gymId: gym.id,
          memberId: members[0].id,
          branchId: branch.id,
          at: new Date(),
        }
      }));
    }

    process.stdout.write(`Seeded: ${N} members, ${M} sales, ${K} attendance.\n`);

    // 2. Trigger real backup via BackupsService.generateExcelBackup
    const { filename, path } = await backups.generateExcelBackup(gym.id, gym.slug);
    process.stdout.write(`Backup generated: ${filename} at ${path}\n`);

    // 3. Wipe the test data (Wiping only this gym's data)
    // This tests the actual 'restore' logic which includes a deleteMany step internally.
    // We choose to delete manually here to ENSURE it is empty before restore.
    await prisma.$transaction([
        prisma.attendance.deleteMany({ where: { gymId: gym.id } }),
        prisma.saleItem.deleteMany({ where: { sale: { gymId: gym.id } } }),
        prisma.sale.deleteMany({ where: { gymId: gym.id } }),
        prisma.member.deleteMany({ where: { gymId: gym.id } }),
        prisma.plan.deleteMany({ where: { gymId: gym.id } }),
        prisma.branch.deleteMany({ where: { gymId: gym.id } }),
    ]);

    const zeroCount = await prisma.member.count({ where: { gymId: gym.id } });
    expect(zeroCount).toBe(0);

    // 4. Run restore code path
    // restoreFromExcel(gymId, filePath, confirmed)
    const restoreResult = await backups.restoreFromExcel(gym.id, path, true);
    expect(restoreResult.success).toBe(true);

    // 5. Assert counts match exactly
    const [memberCount, saleCount, attendanceCount] = await Promise.all([
      prisma.member.count({ where: { gymId: gym.id } }),
      prisma.sale.count({ where: { gymId: gym.id } }),
      prisma.attendance.count({ where: { gymId: gym.id } }),
    ]);

    expect(memberCount).toBe(N);
    expect(saleCount).toBe(M);
    expect(attendanceCount).toBe(K);

    // 6. Spot-check specific field values byte for byte
    const restoredMember = await prisma.member.findFirst({
      where: { gymId: gym.id, name: 'Member 0' }
    });
    expect(restoredMember).toBeDefined();
    // byte for byte: the deterministic cipher means an unchanged key set must
    // produce exactly the ciphertext that was exported (PHASE P2's re-key rule)
    expect(restoredMember?.mobile).toBe(members[0].mobile);
    expect(restoredMember?.code).toBe(members[0].code);
    // and it must still READ: a restore that produced an unreadable envelope would
    // pass the byte comparison above only by accident
    expect(encryption.isEncrypted(restoredMember?.mobile)).toBe(true);
    expect(encryption.decrypt(String(restoredMember?.mobile))).toBe(memberMobiles[0]);

    const restoredSale = await prisma.sale.findFirst({
        where: { gymId: gym.id, invoiceNo: 'INV-DRILL-0' }
    });
    expect(restoredSale).toBeDefined();
    expect(Number(restoredSale?.total)).toBe(100);

    process.stdout.write('Restore Drill PASSED counts matched and spot-checks verified.\n');
  });

  /**
   * PHASE N2 — this suite compiles the WHOLE AppModule (scheduler + cron
   * leader, BullMQ queues, the socket.io gateway with its Redis pub/sub
   * clients, the Prisma pool) and used to never close it. Jest printed the
   * result and then waited forever on those open handles: run alone, the
   * process hung indefinitely after the test finished; in the full `npm test`
   * run it was what stopped jest from exiting after the summary had been
   * printed (68 suites, summary on screen, process still alive nine minutes
   * later — the run had to be killed). Closing the module releases them all.
   *
   * The drill gym is deleted too: it is created fresh on every run, so
   * repeated runs no longer accumulate gyms in the development database. The
   * non-cascading gym edges (RenewalRequest, Notification, GymSettings) are
   * cleared first, and a cleanup failure must never mask the test result.
   */
  afterAll(async () => {
    try {
      if (drillGymId && prisma) {
        await prisma.renewalRequest.deleteMany({ where: { gymId: drillGymId } }).catch(() => undefined);
        await prisma.notification.deleteMany({ where: { gymId: drillGymId } }).catch(() => undefined);
        await prisma.gymSettings.deleteMany({ where: { gymId: drillGymId } }).catch(() => undefined);
        await prisma.gym.deleteMany({ where: { id: drillGymId } }).catch(() => undefined);
      }
    } finally {
      await moduleFixture?.close();
    }
  }, 60000);
  });
