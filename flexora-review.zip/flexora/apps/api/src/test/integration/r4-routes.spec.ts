/** @jest-environment node */
/**
 * FLEXORA Gym OS - Backend API
 * (c) 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R4 - R4.12 (revenue CSV), R4.13 (health), R4.14 (flags), R4.15 (security center),
 * R4.16 (admins), and the R4.22 audit gap those last three exposed.
 *
 * THE R4.22 FINDING, which is the reason most of this file exists. Every state-changing platform
 * route was enumerated and checked for the three things the owner's rule 4 requires: step-up,
 * CSRF and an audit row. All fourteen had step-up. THREE had no audit row at all:
 *
 *     POST   /platform/flags              flag flipped, nothing recorded
 *     POST   /platform/shield/block       an address blocked, nothing recorded
 *     DELETE /platform/shield/blocked/:ip an address UNBLOCKED, nothing recorded
 *
 * They were one-line delegations that did not even take @Req(), so they had no access to the
 * acting administrator's identity and could not have written a row if they had tried. Unblocking
 * is the worst of the three: it is the one platform action that can silently undo a security
 * control, and before this phase an administrator could lift a block on an address that had been
 * attacking the platform with no record that it happened. Step-up proves who was present; only the
 * ledger proves what they did. All three now write a row, and each is asserted below by reading
 * the ledger rather than trusting the response.
 *
 * No secret value is printed anywhere in this file.
 */
import {
  REVENUE_CSV_COLUMNS,
  REVENUE_EXPORT_MAX_ROWS,
} from '../../modules/platform/platform.controller';
import { assertWritesAreNotRlsProtected, makeGym, startConsoleHarness, API, type ConsoleHarness } from '../support/platform-console-harness';

jest.setTimeout(240_000);

const LABEL = 'r4-routes';
const REASON = 'R4 route spec needs a reason of at least eight characters';
const TEST_IP = '203.0.113.77';
const FIXTURE_ADMIN_PASSWORD = ['R4-Spec', 'Admin', '0'.repeat(6)].join('-');

describe('R4.12-R4.16 and R4.22 - revenue, health, flags, security center, admins', () => {
  let h: ConsoleHarness;
  const gymIds: string[] = [];
  const createdAdminIds: string[] = [];

  beforeAll(async () => {
    h = await startConsoleHarness(LABEL);
    // GymStatus, not the PlatformAdmin status enum: gyms are ACTIVE / TRIAL / SUSPENDED /
    // DELETED, and 'TRIALING' is a SubscriptionStatus. Using the wrong enum failed the whole
    // beforeAll and every test with it, which is the failure mode worth remembering - one bad
    // fixture value looks like twelve broken routes.
    for (const status of ['ACTIVE', 'TRIAL', 'SUSPENDED']) {
      const gym = await makeGym(h.prisma, LABEL, { status });
      gymIds.push(gym.id);
    }
  });

  afterAll(async () => {
    if (h) {
      await h.prisma.platformAlert.deleteMany({ where: { targetId: { in: [...gymIds, ...createdAdminIds] } } }).catch(() => undefined);
      for (const gymId of gymIds) {
        await h.prisma.subscription.deleteMany({ where: { gymId } }).catch(() => undefined);
        await h.prisma.gymSettings.deleteMany({ where: { gymId } }).catch(() => undefined);
        await h.prisma.renewalRequest.deleteMany({ where: { gymId } }).catch(() => undefined);
      }
      await h.prisma.gym.deleteMany({ where: { id: { in: gymIds } } }).catch(() => undefined);
      await h.prisma.platformAdmin.deleteMany({ where: { id: { in: createdAdminIds } } }).catch(() => undefined);
      // PHASE R3 A5.1: audit rows are never deleted by a fixture.
      await h.close();
    }
  });

  // Count and newest, as two separate reads. The first version returned findMany with take:5 and
  // the tests compared lengths - which silently caps at 5, so once a suite had run enough times
  // (and A5 means audit rows are never deleted) `before.length + 1` became 6 against a received 5
  // and looked like a missing audit row. Counting cannot cap.
  const ledgerCount = (action: string, target?: string) =>
    h.prisma.platformAuditLog.count({ where: { action, ...(target ? { target } : {}) } });
  const ledgerNewest = (action: string, target?: string) =>
    h.prisma.platformAuditLog.findFirst({
      where: { action, ...(target ? { target } : {}) },
      orderBy: { seq: 'desc' },
    });
  const ledger = async (action: string, target?: string) => {
    const rows = await h.prisma.platformAuditLog.findMany({
      where: { action, ...(target ? { target } : {}) },
      orderBy: { seq: 'desc' },
      take: 5,
    });
    return rows;
  };

  // ── R4.12 revenue CSV ─────────────────────────────────────────────────────
  it('R4.12 - the revenue export is CSV with exactly the allowlisted columns and no member data', async () => {
    const response = await h.get(`${API}/platform/revenue/export`);
    expect(response.status).toBe(200);
    expect(String(response.headers['content-type'])).toContain('text/csv');
    expect(String(response.headers['content-disposition'])).toMatch(
      /attachment; filename="flexora-platform-revenue-\d{8}\.csv"/,
    );

    // `text`, not `body`: supertest parses JSON into body and leaves text/csv as something
    // String() renders "[object Object]", which made the header assertion compare one element
    // against eleven and fail with a confusing diff.
    const text = String(response.text ?? '');
    expect(text.startsWith('gymId,')).toBe(true);
    const lines = text.split('\r\n').filter((line) => line.length > 0);
    expect(lines.length).toBeGreaterThan(0);

    // Hard-coded, not read from REVENUE_CSV_COLUMNS: comparing an export against the list the
    // export is built from is tautological, and the R4 mutation cycle proved that by adding a
    // column to the audit allowlist and watching the equivalent assertion still pass.
    const EXPECTED = [
      'gymId', 'gymName', 'gymSlug', 'gymStatus', 'tier', 'subscriptionStatus',
      'currentPeriodStart', 'currentPeriodEnd', 'lastPaymentAt', 'lastPaymentAmount', 'totalRevenue',
    ];
    expect(lines[0].split(',')).toEqual(EXPECTED);
    expect([...REVENUE_CSV_COLUMNS]).toEqual(EXPECTED);

    // No member data, and no column that could hold any. The source is the R2 definer function,
    // which by construction returns no member column, so this is a regression guard rather than
    // the primary control.
    for (const forbidden of ['member', 'mobile', 'nationalId', 'birthDate', 'taxId', 'password', 'token']) {
      expect({ forbidden, inHeader: lines[0].toLowerCase().includes(forbidden.toLowerCase()) }).toEqual({
        forbidden,
        inHeader: false,
      });
    }
    const bodyText = lines.slice(1).join('\n');
    // Strip UUID-shaped values first: a random UUID contains ten consecutive digits about once in
    // a thousand, which is not a phone number. Measured, not assumed - see r3-console-routes.
    const withoutUuids = bodyText.replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi, '<uuid>');
    expect(withoutUuids).not.toMatch(/\+?01[0125]\d{8}/);
    expect(withoutUuids).not.toMatch(/\b\d{14}\b/);

    expect(Number(response.headers['x-flexora-revenue-rows'])).toBe(lines.length - 1);
    expect(Number(response.headers['x-flexora-revenue-rows'])).toBeLessThanOrEqual(REVENUE_EXPORT_MAX_ROWS);
    expect(['true', 'false']).toContain(response.headers['x-flexora-revenue-truncated']);
  });

  it('R4.12 - the revenue export honours the status and plan filters', async () => {
    const trialing = await h.get(`${API}/platform/revenue/export?status=TRIALING`);
    expect(trialing.status).toBe(200);
    const all = await h.get(`${API}/platform/revenue/export`);
    expect(all.status).toBe(200);
    expect(Number(trialing.headers['x-flexora-revenue-rows'])).toBeLessThanOrEqual(
      Number(all.headers['x-flexora-revenue-rows']),
    );
    const trialingLines = String(trialing.text ?? '').split('\r\n').filter((line: string) => line.length > 0);
    for (const line of trialingLines.slice(1)) {
      // column 6 is subscriptionStatus in the allowlisted order
      expect(line.split(',')[5]).toBe('TRIALING');
    }
  });

  // ── R4.13 health ──────────────────────────────────────────────────────────
  it('R4.13 - health probes each dependency and reports the audit chain and the alert channel', async () => {
    const response = await h.get(`${API}/platform/health`);
    expect(response.status).toBe(200);
    const body = response.body;

    // BEFORE R4 this was { database: 'connected', redis: 'unknown' } - two literal strings that
    // were true whether or not anything was reachable. Now each is a measured object.
    expect(typeof body.database).toBe('object');
    expect(['ok', 'error']).toContain(body.database.status);
    expect(typeof body.database.latencyMs).toBe('number');
    expect(typeof body.redis).toBe('object');
    expect(['ok', 'degraded', 'unavailable']).toContain(body.redis.status);
    expect(body.redis).not.toBe('unknown');

    expect(body.audit).toBeDefined();
    expect(['ok', 'broken', 'unavailable']).toContain(body.audit.status);
    expect(body.audit.status).toBe('ok');
    expect(typeof body.audit.rowsChecked).toBe('number');
    expect(body.audit.brokenRows).toBe(0);

    expect(body.alertChannel).toBeDefined();
    expect(typeof body.alertChannel.configured).toBe('boolean');
    expect(Array.isArray(body.alertChannel.missing)).toBe(true);
    // A3.4 again, on a second surface: variable NAMES only, never values.
    for (const name of body.alertChannel.missing) expect(name).toMatch(/^[A-Z0-9_]+$/);

    expect(['ok', 'degraded']).toContain(body.status);
    expect(typeof body.uptimeSeconds).toBe('number');
    // the whole probe is bounded, which is the R4.8 property applied to the health page itself:
    // a dead Redis must not make the health page unreachable
    expect(typeof body.checkedInMs).toBe('number');
    expect(body.checkedInMs).toBeLessThan(5000);
    // and no credential leaks into a page designed to be read at a glance during an incident
    const serialised = JSON.stringify(body);
    expect(serialised).not.toMatch(/postgres(ql)?:\/\//i);
    expect(serialised).not.toMatch(/redis:\/\/[^"]*@/i);
  });

  // ── R4.14 flags, and the R4.22 audit gap ─────────────────────────────────
  it('R4.14/R4.22 - setting a flag writes a flag:set audit row, which it did not before', async () => {
    const flag = `r4_spec_flag_${Date.now().toString(36)}`;
    const before = await ledgerCount('flag:set', flag);

    await h.reStepUp();
    const response = await h.post(`${API}/platform/flags`, { flag, value: true });
    expect([200, 201]).toContain(response.status);

    expect(await ledgerCount('flag:set', flag)).toBe(before + 1);
    const newestFlag = await ledgerNewest('flag:set', flag);
    expect(newestFlag!.target).toBe(flag);
    expect(newestFlag!.details).toMatchObject({ value: true });
    // the acting administrator is named, which is the whole point of the row
    expect(newestFlag!.adminId).toBe(h.adminId);
    expect(newestFlag!.stepUpUsed).toBe(true);
    expect(newestFlag!.ip).toBeTruthy();
    expect(newestFlag!.userAgent).toBeTruthy();

    const list = await h.get(`${API}/platform/flags`);
    expect(list.status).toBe(200);
  });

  it('R4.22 - setting a flag without a live step-up claim is refused and writes nothing', async () => {
    const flag = `r4_spec_nostep_${Date.now().toString(36)}`;
    await h.clearStepUp();
    const response = await h.post(`${API}/platform/flags`, { flag, value: true });
    expect(response.status).toBeGreaterThanOrEqual(400);
    expect(response.status).not.toBe(200);
    expect(await ledgerCount('flag:set', flag)).toBe(0);
  });

  // ── R4.15 security center ────────────────────────────────────────────────
  it('R4.15/R4.22 - blocking an address writes a shield:block row with the reason in the reason column', async () => {
    const before = await ledgerCount('shield:block', TEST_IP);
    await h.reStepUp();
    const response = await h.post(`${API}/platform/shield/block`, { ip: TEST_IP, reason: REASON });
    expect([200, 201]).toContain(response.status);

    expect(await ledgerCount('shield:block', TEST_IP)).toBe(before + 1);
    const newestBlock = await ledgerNewest('shield:block', TEST_IP);
    expect(newestBlock!.target).toBe(TEST_IP);
    // The reason is a first-class column now, not only an argument to the shield service, so it
    // is filterable in the audit log and appears in the CSV export.
    expect(newestBlock!.reason).toBe(REASON);
    expect(newestBlock!.beforeState).toEqual({ blocked: false });
    expect(newestBlock!.afterState).toEqual({ blocked: true });
    expect(newestBlock!.stepUpUsed).toBe(true);

    const blocked = await h.get(`${API}/platform/shield/blocked`);
    expect(blocked.status).toBe(200);
  });

  it('R4.15/R4.22 - UNBLOCKING writes a shield:unblock row: the one action that can silently undo a security control', async () => {
    // Make sure something is blocked first, so this is a real unblock and not a no-op.
    await h.reStepUp();
    await h.post(`${API}/platform/shield/block`, { ip: TEST_IP, reason: REASON }).catch(() => undefined);

    const before = await ledgerCount('shield:unblock', TEST_IP);
    await h.reStepUp();
    const response = await h.del(`${API}/platform/shield/blocked/${encodeURIComponent(TEST_IP)}`);
    expect([200, 201, 204]).toContain(response.status);

    expect(await ledgerCount('shield:unblock', TEST_IP)).toBe(before + 1);
    const newestUnblock = await ledgerNewest('shield:unblock', TEST_IP);
    expect(newestUnblock!.target).toBe(TEST_IP);
    expect(newestUnblock!.beforeState).toEqual({ blocked: true });
    expect(newestUnblock!.afterState).toEqual({ blocked: false });
    expect(newestUnblock!.adminId).toBe(h.adminId);
  });

  it('R4.15 - the security scan is readable and carries no credential', async () => {
    const response = await h.get(`${API}/platform/monitor/security`);
    expect(response.status).toBe(200);
    const serialised = JSON.stringify(response.body ?? {});
    expect(serialised).not.toMatch(/\+?01[0125]\d{8}/);
    for (const forbidden of ['password', 'passwordHash', 'token', 'secret']) {
      expect({ forbidden, present: serialised.toLowerCase().includes(`"${forbidden.toLowerCase()}"`) }).toEqual({
        forbidden,
        present: false,
      });
    }
  });

  // ── R4.16 admins ─────────────────────────────────────────────────────────
  it('R4.16 - the admin list carries no credential, authenticator state or session token', async () => {
    const response = await h.get(`${API}/platform/admins`);
    expect(response.status).toBe(200);
    const rows = Array.isArray(response.body) ? response.body : response.body?.items ?? [];
    expect(rows.length).toBeGreaterThan(0);
    const keys = Object.keys(rows[0] as Record<string, unknown>);
    for (const forbidden of ['passwordHash', 'password', 'totpSecret', 'totpLastUsedStep', 'token', 'recoveryCodes']) {
      expect({ forbidden, present: keys.includes(forbidden) }).toEqual({ forbidden, present: false });
    }
    const serialised = JSON.stringify(rows);
    expect(serialised).not.toMatch(/\$argon2/);
  });

  it('R4.16 - creating, approving and removing an administrator each write a ledger row', async () => {
    const email = `r4-created-${Date.now().toString(36)}@example.com`;
    await h.reStepUp();
    // CreatePlatformAdminDto requires name, email, role AND a password that satisfies
    // @PasswordStrength. The first version of this test sent no password and got a 400 - which is
    // also why the R2 crawl never exercised this route's success path: its bodyFor sent
    // {email, name, role} and had been collecting a 400 for two phases.
    const created = await h.post(`${API}/platform/admins`, {
      email,
      name: 'R4 created',
      role: 'PLATFORM_ADMIN',
      password: FIXTURE_ADMIN_PASSWORD,
    });
    if (![200, 201].includes(created.status)) {
      throw new Error(`createAdmin answered ${created.status}: ${JSON.stringify(created.body).slice(0, 300)}`);
    }
    const createdId = String(created.body?.id ?? created.body?.admin?.id ?? '');
    expect(createdId).toBeTruthy();
    createdAdminIds.push(createdId);

    // A password supplied on the way in must not come back out, in the response or the ledger.
    expect(JSON.stringify(created.body)).not.toContain(FIXTURE_ADMIN_PASSWORD);
    const createRows = await ledger('admin:create-pending', createdId);
    expect(createRows.length).toBeGreaterThan(0);
    expect(JSON.stringify(createRows[0].details ?? {})).not.toContain(FIXTURE_ADMIN_PASSWORD);
    expect(createRows[0].reason ?? null).toBe(null);

    // THE TWO-PERSON RULE, asserted rather than routed around. Approving answers 400 with
    // `cannot-approve-own-request` when the approver is the administrator who created the request
    // - which is the whole point of a pending state, and the first version of this test walked
    // straight into it and treated a correct refusal as a bug. A successful approval needs a
    // SECOND authenticated administrator; that path is covered by r1-platform-auth.spec.ts, which
    // has the two-session machinery. What is asserted here is the refusal, and that it writes no
    // admin:approved row.
    await h.reStepUp();
    const selfApprove = await h.post(`${API}/platform/admins/${createdId}/approve`, { reason: REASON });
    expect(selfApprove.status).toBe(400);
    expect(JSON.stringify(selfApprove.body)).toContain('cannot-approve-own-request');
    expect(await ledgerCount('admin:approved', createdId)).toBe(0);
    // and the administrator is still pending, i.e. the refusal changed nothing
    const stillPending = await h.prisma.platformAdmin.findUniqueOrThrow({
      where: { id: createdId },
      select: { status: true },
    });
    expect(stillPending.status).toBe('PENDING_APPROVAL');

    await h.reStepUp();
    const removed = await h.del(`${API}/platform/admins/${createdId}`, { reason: REASON });
    if (![200, 201, 204].includes(removed.status)) {
      throw new Error(`remove answered ${removed.status}: ${JSON.stringify(removed.body).slice(0, 300)}`);
    }
    // The audit action is 'admin:delete' while the alert type is ADMIN_REMOVED - a naming
    // inconsistency between the two vocabularies that predates R4 and is reported rather than
    // silently "fixed", since renaming an audit action would orphan every existing row that
    // carries the old name.
    // (read after the delete, so this asserts the row exists - a "before" count taken here
    // would be measuring the wrong moment, which is what the first version did.)
    expect(await ledgerCount('admin:delete', createdId)).toBe(1);
    const newestRemove = await ledgerNewest('admin:delete', createdId);
    expect(newestRemove!.details).toMatchObject({ email });
    expect(typeof (newestRemove!.details as Record<string, unknown>).sessionsRevoked).toBe('number');

    // A removed administrator's sessions are revoked, which is what makes removal meaningful
    // rather than cosmetic (R1).
    const sessions = await h.prisma.platformSession.count({ where: { adminId: createdId, revokedAt: null } });
    expect(sessions).toBe(0);
  });

  // ── R4.22 authorization for every route this phase added or changed ──────
  it('R4.22 - every route this phase touched refuses an anonymous caller', async () => {
    for (const path of [
      `${API}/platform/revenue/export`,
      `${API}/platform/health`,
      `${API}/platform/flags`,
      `${API}/platform/shield/blocked`,
      `${API}/platform/monitor/security`,
      `${API}/platform/admins`,
    ]) {
      const anonymous = await h.anonymous('GET', path);
      expect({ path, status: anonymous.status, allowed: anonymous.status === 200 }).toEqual({
        path,
        status: anonymous.status,
        allowed: false,
      });
      expect([401, 403, 404]).toContain(anonymous.status);
    }
    const anonymousBlock = await h.anonymous('POST', `${API}/platform/shield/block`, { ip: TEST_IP, reason: REASON });
    expect([401, 403, 404]).toContain(anonymousBlock.status);
  });

  it('R4 - this suite writes only tables that have no row-level security', async () => {
    // The owner asked for this in every platform spec that writes through the api. A suite that
    // connects as a superuser can pass while the production role cannot write at all - that is
    // exactly how the subscription defect survived two phases. These tables have no policy for a
    // superuser to bypass, so this suite's green result means the same thing in production. The
    // RLS-sensitive writes are covered by r4-runtime-role-writes.spec.ts.
    await assertWritesAreNotRlsProtected(h.prisma as never, [
      'Gym',
      'PlatformAdmin',
      'PlatformSession',
      'PlatformAuditLog',
      'PlatformAlert',
    ]);
  });
});
