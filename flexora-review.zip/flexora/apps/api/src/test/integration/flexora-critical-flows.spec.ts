import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication, ValidationPipe } from '@nestjs/common';
import request from 'supertest';
import cookieParser from 'cookie-parser';
import { AppModule } from '../../app.module';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { BruteForceService } from '../../common/security/brute-force.service';
import { EncryptionService } from '../../common/security/encryption.service';
import { randomBytes, randomInt } from 'crypto';
import * as argon2 from 'argon2';
import { PASSWORD_HASH_OPTIONS as SHARED_PASSWORD_HASH_OPTIONS } from '../../config/password-hash';

/**
 * FLEXORA Gym OS — Critical E2E Integration Suite
 */
describe('Flexora Critical Flows (E2E)', () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let redis: RedisService;
  let bruteForce: BruteForceService;
  let encryption: EncryptionService;

  beforeAll(async () => {
    process.env.IMPORT_UPLOAD_DIR = '/tmp/flexora/imports';
    process.env.BACKUP_DIR = '/tmp/flexora/backups';
    process.env.CONTRACT_PDF_DIR = '/tmp/flexora/contracts';
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    // FIX (launch-readiness, discovered while re-verifying the FULL test
    // suite is green after the QueueService DI cascade fix and the
    // RealtimeGateway socket.io-adapter fix): this suite's HTTP requests
    // all target `/api/...` paths (e.g. `/api/auth/login`, `/api/members`)
    // to match the real, production `setGlobalPrefix('api')` call made in
    // `main.ts`'s `bootstrap()` — but this test's own `beforeAll` never
    // called `setGlobalPrefix` on the `INestApplication` it builds
    // directly via `createNestApplication()` (which does NOT go through
    // `main.ts`'s `bootstrap()` at all). Every request in this suite was
    // therefore silently hitting an unprefixed route that Nest's router
    // has never registered, and supertest/Express correctly returned a
    // bare 404 for all of them. This was never caught before because this
    // suite could not get past `app.init()` at all until the QueueService
    // DI bug (fixed earlier in this pass) stopped crashing the whole
    // `AppModule` graph during construction — once that was fixed, this
    // suite ran for the first time, immediately surfacing this pre-existing
    // gap between the test's bootstrap and the real bootstrap in main.ts.
    app.setGlobalPrefix('api');
    // FIX (launch-readiness, same discovery pass as the setGlobalPrefix fix
    // just above): once login started reaching the real controller (after
    // the setGlobalPrefix fix), every subsequent authenticated request
    // still got 401 Unauthorized. Root cause: `JwtStrategy`
    // (modules/auth/jwt.strategy.ts) extracts the access token EXCLUSIVELY
    // from `request.cookies?.flx_access` (there is no Authorization-header
    // fallback in the real strategy), and `AuthController`'s login route
    // sets that token via `res.cookie('flx_access', ...)` — but Express
    // only populates `request.cookies` when the `cookie-parser` middleware
    // has been registered on the app (`main.ts`'s real bootstrap always
    // calls `app.use(cookieParser())`, see line ~81). This test's own
    // `beforeAll` never did, so every cookie set by `/api/auth/login` was
    // never parsed back out by the guard on the next request, making every
    // protected route 401. The correct fix (already used identically by
    // `refresh-token-expiry.spec.ts`, which imports and calls
    // `app.use(cookieParser())` for exactly this reason) is to mirror
    // main.ts's real middleware setup here too.
    app.use(cookieParser());
    // PHASE R4: forbidNonWhitelisted matches main.ts, so a body the production api would
    // reject with 400 cannot pass here.
    app.useGlobalPipes(new ValidationPipe({ transform: true, whitelist: true, forbidNonWhitelisted: true }));
    prisma = app.get(PrismaService);
    redis = app.get(RedisService);
    bruteForce = app.get(BruteForceService);
    encryption = app.get(EncryptionService);
    await app.init();
    // FIX (launch-readiness, same discovery pass as the two fixes above):
    // once login and cookie-based auth both started working for the first
    // time, this suite's THIRD real request to `/api/auth/login` (this
    // describe block calls `loginAndGetAgent` 3 separate times across its
    // `it` blocks, all from the same loopback IP) started getting 429 Too
    // Many Requests. Root cause: `AuthController.login` is guarded by the
    // real `BruteForceGuard` (`@UseGuards(BruteForceGuard)` +
    // `BruteForceService.checkAndIncrement`), which locks out an IP for 30
    // seconds after only 3 attempts — a real, intentional security control,
    // not a bug. Because this Redis-backed counter is keyed by IP and
    // persists across the whole `describe` block (and even across separate
    // `jest --runInBand` runs in the same sandbox, since Redis state
    // outlives any single test process), repeated runs of this exact suite
    // accumulate attempts against the same `ip:::ffff:127.0.0.1` /
    // `ip:127.0.0.1` key. `refresh-token-expiry.spec.ts` already
    // establishes the correct pattern for this exact scenario — reset the
    // relevant `BruteForceService` keys once in `beforeAll`, after
    // `app.init()`, so the suite is not flaky when run back-to-back. This
    // does not touch or weaken the real brute-force logic itself (covered
    // separately by `brute-force.service.spec.ts`); it only clears
    // leftover state specific to this spec's own loopback IP before this
    // suite's own assertions begin.
    await bruteForce.reset('ip:::ffff:127.0.0.1');
    await bruteForce.reset('ip:127.0.0.1');
  });

  afterAll(async () => {
    await app.close();
  });

  // PHASE O1.7: was a second copy with parallelism: 4 while the service used 1.
  // Verification still worked (argon2 embeds its parameters in the hash), but two
  // definitions of "how we hash passwords" is how a tool ships a hash the API
  // would never produce. Both now import the same module.
  const PASSWORD_HASH_OPTIONS = SHARED_PASSWORD_HASH_OPTIONS;

  const setupGym = async (name: string) => {
    const slug = `gym-${randomBytes(4).toString('hex')}`;
    const gym = await prisma.gym.create({
      data: {
        name,
        slug,
        email: `${slug}@test.com`,
        phone: '01000000000',
        status: 'ACTIVE',
      },
    });

    const branch = await prisma.branch.create({
      data: {
        gymId: gym.id,
        name: 'Main Branch',
      }
    });

    const plan = await prisma.plan.create({
      data: {
        gymId: gym.id,
        name: 'Standard Plan',
        type: 'TIME',
        days: 30,
        price: 500,
      }
    });

    const password = 'TestPassword123!';
    const owner = await prisma.user.create({
      data: {
        name: `${name} Owner`,
        email: `${slug}@owner.com`,
        passwordHash: await argon2.hash(password, PASSWORD_HASH_OPTIONS),
        role: 'OWNER',
        gymId: gym.id,
        branchId: branch.id,
      },
    });

    // FIX (launch-readiness, discovered while re-verifying the FULL apps/api
    // test suite is green after the QueueService DI cascade fix — the
    // "Sale & Inventory Lifecycle" test could never reach a real
    // POST /api/sales call before that fix, since the whole app failed to
    // boot): every route that carries `@RequiresFeature(...)` (e.g.
    // `SalesController`'s class-level `@RequiresFeature('pos')`) is guarded
    // by the real, globally-registered `LicenseGuard`, which calls
    // `LicenseService.assertFeature(gymId, feature)`. That method looks up
    // a real `License` row for the gym — with NONE at all, it returns
    // `{ ok: false, reason: 'missing' }` and the guard throws 403 Forbidden
    // BEFORE the controller handler ever runs, regardless of the caller's
    // role/permissions. `setupGym` never created a `License` (or
    // `Subscription`, which determines the tier's feature set —
    // `TIER_FEATURES.BASIC` is deliberately empty; `pos` requires PRO or
    // higher), so any test hitting a feature-gated route was always going
    // to 403 once it got far enough to reach the real guard chain. Real
    // gyms get a License/Subscription provisioned by a separate onboarding/
    // billing flow outside the scope of this E2E suite — creating them
    // directly here (as any real, licensed gym would already have) is the
    // correct test fixture, not a workaround around real security logic.
    await prisma.license.create({
      data: {
        gymId: gym.id,
        key: `FLEX-TEST-${randomBytes(4).toString('hex').toUpperCase()}`,
        status: 'ACTIVE',
        expiresAt: new Date(Date.now() + 365 * 86400000),
      },
    });
    await prisma.subscription.create({
      data: {
        gymId: gym.id,
        tier: 'PRO',
        status: 'ACTIVE',
        currentPeriodEnd: new Date(Date.now() + 365 * 86400000),
      },
    });

    return { gym, branch, plan, owner: { email: owner.email, password } };
  };

  const loginAndGetAgent = async (email: string, password: string) => {
    // FIX (launch-readiness, same discovery pass as the beforeAll-level
    // BruteForceService reset above): a single reset in `beforeAll` was not
    // enough. `BruteForceGuard` locks out an IP for 30s after only 3
    // attempts within its rolling window, and this suite calls
    // `loginAndGetAgent` (i.e. a real `/api/auth/login` request from the
    // same loopback IP) 3 separate times across its `it` blocks — so the
    // 3rd real login attempt itself was the one that tripped the lockout
    // for the guard's OWN counting logic (attempt #3 is still `allowed`,
    // but it's also the exact attempt that pushes the count to the
    // threshold, and a lingering count from a previous run/process in this
    // same sandbox could easily push a fresh run's very first attempt over
    // the edge too). Resetting immediately before every real login call
    // this suite makes (not just once at the very start) makes the suite
    // deterministic regardless of how many times it or its neighbors in
    // the same file have already exercised this endpoint.
    await bruteForce.reset('ip:::ffff:127.0.0.1');
    await bruteForce.reset('ip:127.0.0.1');
    const agent = request.agent(app.getHttpServer());
    await agent
      .post('/api/auth/login')
      .send({ email, password })
      .expect(201);
    return agent;
  };

  describe('Multi-tenant Isolation', () => {
    it('should NOT leak members between Gym A and Gym B', async () => {
      const gymA = await setupGym('Gym A');
      const gymB = await setupGym('Gym B');

      // Create a member in Gym B
      await prisma.member.create({
        data: {
          gymId: gymB.gym.id,
          branchId: gymB.branch.id,
          planId: gymB.plan.id,
          name: 'Gym B Member',
          mobile: '012' + randomInt(10000000, 99999999),
          startDate: new Date(),
          code: 'B' + randomInt(1000, 9999),
        }
      });

      // Login as Gym A Owner
      const agentA = await loginAndGetAgent(gymA.owner.email, gymA.owner.password);

      // GET /api/members for Gym A
      const res = await agentA
        .get('/api/members')
        .expect(200);

      const items = res.body.items || [];
      for (const m of items) {
        expect(m.gymId).toBe(gymA.gym.id);
        expect(m.name).not.toBe('Gym B Member');
      }
    });

    it('should reject x-gym-id header for another gym', async () => {
      const gymA = await setupGym('Gym A');
      const gymB = await setupGym('Gym B');
      const agentA = await loginAndGetAgent(gymA.owner.email, gymA.owner.password);

      await agentA
        .get('/api/members')
        .set('x-gym-id', gymB.gym.id)
        .expect(403);
    });
  });

  describe('Sale & Inventory Lifecycle', () => {
    it('should correctly decrement stock on sale and increment on refund', async () => {
      const data = await setupGym('Inventory Gym');
      const product = await prisma.product.create({
        data: {
          gymId: data.gym.id,
          name: 'Protein Shake',
          qty: 10,
          costPrice: 50,
          sellingPrice: 100,
        }
      });

      const agent = await loginAndGetAgent(data.owner.email, data.owner.password);

      // 1. Sale
      // FIX (launch-readiness, same discovery pass as the OTP path fix
      // below): this suite previously called `/api/sales/checkout`, but the
      // real, current `SalesController` (modules/sales/sales.controller.ts)
      // defines the checkout route as a bare `@Post()` directly under
      // `@Controller('sales')` — i.e. the real path is just `/api/sales`
      // (POST), with no `/checkout` suffix. This test never actually
      // exercised this endpoint before (the whole `AppModule` could not
      // boot at all until the QueueService DI cascade fix earlier in this
      // pass), so this pre-existing path mismatch was never caught — every
      // call here always 404'd. Fixed to call the real, current route.
      const saleRes = await agent
        .post('/api/sales')
        .send({
          items: [{ productId: product.id, qty: 2 }],
          paymentMethod: 'CASH',
          paymentStatus: 'PAID',
          branchId: data.branch.id,
        })
        .expect(201);

      let updatedProduct = await prisma.product.findUnique({ where: { id: product.id } });
      expect(updatedProduct?.qty).toBe(8);

      // 2. Refund
      await agent
        .post(`/api/sales/${saleRes.body.id}/refund`)
        .send({ reason: 'Customer changed mind' })
        .expect(201);

      updatedProduct = await prisma.product.findUnique({ where: { id: product.id } });
      expect(updatedProduct?.qty).toBe(10);
    });
  });

  describe('Portal OTP Security', () => {
    it('should rate-limit OTP verification after 5 attempts', async () => {
      const data = await setupGym('Portal Gym');
      // FIX (launch-readiness, discovered while re-verifying the FULL
      // apps/api test suite is green after the migration/schema fixes
      // above finally let a real POST /api/sales checkout run end-to-end,
      // clearing the way for this OTP test to actually reach its own real
      // logic for the first time): this used to create the Member with a
      // RAW, unencrypted `mobile` value. But `PortalService.requestOtp`/
      // `verifyOtp` both look up the member via
      // `this.encryption.encryptDeterministic(mobile)` (the exact same
      // deterministic-encryption method real production code
      // `MembersService.create` always applies to `mobile` via its own
      // `encryptSensitive` helper before ever writing a Member row) — so a
      // Member fixture created with a plaintext mobile can NEVER be found
      // by that lookup, and every OTP verify attempt (even the 6th) fails
      // with a generic "Invalid code" 401 for "member not found", never
      // actually reaching (or incrementing) the real per-account
      // `otp:fail:<memberId>` Redis counter this test is trying to
      // exercise. Confirmed directly via an isolated debug harness calling
      // `PortalService.verifyOtp` directly and inspecting the real Redis
      // key after each call: the counter stayed `null` across all 6
      // attempts. Fixed by encrypting the mobile the same way real
      // application code does before writing the fixture.
      const member = await prisma.member.create({
        data: {
          gymId: data.gym.id,
          branchId: data.branch.id,
          planId: data.plan.id,
          name: 'Portal Member',
          mobile: encryption.encryptDeterministic('01155554444'),
          startDate: new Date(),
          code: `P${randomBytes(2).toString('hex').toUpperCase()}${Date.now().toString(36).slice(-4)}`,
        }
      });

      // Request OTP
      // FIX (launch-readiness, same discovery pass as the 3 fixes above):
      // this suite previously called `/api/portal/otp/request` and
      // `/api/portal/otp/verify`, but the real, current `PortalController`
      // (modules/portal/portal.controller.ts) defines these routes as
      // `@Post('request-otp')` and `@Post('verify-otp')` under
      // `@Controller('portal')` — i.e. the real paths are
      // `/api/portal/request-otp` and `/api/portal/verify-otp`. This test
      // never actually exercised these endpoints before (the whole
      // `AppModule` could not boot at all until the QueueService DI cascade
      // fix earlier in this pass), so this pre-existing path mismatch was
      // never caught — every call here always 404'd, and the previous
      // `expected 200, got 404` failure message on this route was masking
      // the true routes to hit. Fixed to call the real, current routes.
      //
      // Also, same class of fix as `loginAndGetAgent` above:
      // `/api/portal/request-otp` is also guarded by the real, shared
      // `BruteForceGuard` on the same `ip:<loopback>` key `/api/auth/login`
      // uses — reset it immediately before this call too, so this test is
      // not flaky depending on how many login attempts the earlier
      // `describe` blocks in this same file already made against the same
      // IP.
      await bruteForce.reset('ip:::ffff:127.0.0.1');
      await bruteForce.reset('ip:127.0.0.1');
      // FIX (launch-readiness, same discovery pass as the route-path fixes
      // above): `PortalController.requestOtp` is a bare `@Post('request-otp')`
      // with no `@HttpCode(...)` override, so NestJS returns its default
      // status for POST handlers, 201 Created — not 200 OK as this test
      // previously (and incorrectly) expected. This was never caught before
      // because this whole route was unreachable (wrong path) until the
      // route-path fix above, which itself only became testable once the
      // QueueService DI cascade fix let the app boot at all.
      //
      // Also: `PortalService.requestOtp` has its OWN separate rate limiter,
      // independent of `BruteForceGuard` — a real, intentional Redis
      // counter keyed on the raw mobile number (`otp:rate:<mobile>`),
      // capped at 3 requests/hour (see the doc-comment on
      // `PortalService.requestOtp`: "Max 3 requests / mobile / hour
      // (Redis)"). Because this test always uses the same hardcoded mobile
      // number (`01155554444`), and Redis state persists across repeated
      // `jest --runInBand` runs in this same sandbox (a real Redis server,
      // not reset between runs), that counter accumulates indefinitely
      // across runs and eventually exceeds 3, making this call 400 instead
      // of 201 on any run after the first few. Clearing this key directly
      // (the real key format the real service code uses) before this call
      // makes the test deterministic regardless of how many times it has
      // already run in this environment — this does not touch or weaken
      // the real rate-limiting logic itself, only leftover counter state
      // from previous runs.
      await redis.client.del('otp:rate:01155554444');
      // PHASE N2 — order matters: PortalService rate-limits the mobile
      // BEFORE it checks the gym's WhatsApp channel, so the gate check below
      // consumes one slot of `otp:rate:<mobile>` and must run after this del.
      // PHASE N2 — `setupGym` creates a gym with NO WhatsApp channel, and
      // ROUND 14 (PHASE E) made `PortalService.requestOtp` refuse to answer
      // "sent" for a gym that cannot actually deliver a code:
      // 400 WHATSAPP_NOT_CONFIGURED. This test therefore never reached the rate
      // limiter it exists to exercise — and the failure stayed invisible through
      // the whole PHASE M/N1 baseline because this suite's `app.close()` crashed
      // the jest worker first (RealtimeGateway quit the socket.io adapter's
      // pub/sub connections in onModuleDestroy, i.e. BEFORE Nest's dispose()
      // closed the adapter — see that fix). Assert the gate as the security
      // behaviour it is, then enable the channel through the real endpoint
      // exactly as a gym manager would, and only then exercise the rate limiter.
      await request(app.getHttpServer())
        .post('/api/portal/request-otp')
        .send({ mobile: '01155554444', gymSlug: data.gym.slug })
        .expect(400)
        .expect((res) => {
          expect(res.body?.code).toBe('WHATSAPP_NOT_CONFIGURED');
        });
      const portalAgent = await loginAndGetAgent(data.owner.email, data.owner.password);
      // PHASE N2 — a per-run unique number. `GymMessagingConfig.whatsappPhoneId`
      // is UNIQUE *globally* (one WhatsApp Business number binds to one gym), so
      // the hardcoded '123456789' this test used collided with whichever gym had
      // claimed it first — the seeded demo gym, or this very suite's previous
      // run, whose gyms it never deletes. In isolation the suite passed; in the
      // full `npm test` run it answered 500. A test must not depend on a global
      // uniqueness race it does not own.
      // 14 random digits (range must stay <= 2^48-1 for crypto.randomInt)
      // prefixed with a 9 => a realistic, per-run-unique 15-digit phone id.
      const whatsappPhoneId = `9${randomInt(10000000000000, 99999999999999)}`;
      await portalAgent
        .put('/api/messaging/config')
        .send({
          whatsappEnabled: true,
          whatsappPhoneId,
          whatsappToken: 'fake-token-for-test',
        })
        .expect(200);

      // PHASE N2 — real abuse attempt for the conflict path: a SECOND gym tries
      // to bind the SAME WhatsApp number. Before the fix the raw Prisma P2002
      // escaped to the client — a 500 here (test apps do not register main.ts's
      // global HttpExceptionFilter, so Nest's default filter answers) and an
      // opaque 409 `unique_constraint_violation` in production. GymMessagingService
      // now answers a translated 409 that says what actually happened.
      const rival = await setupGym('Portal Rival Gym');
      const rivalAgent = await loginAndGetAgent(rival.owner.email, rival.owner.password);
      await rivalAgent
        .put('/api/messaging/config')
        .send({
          whatsappEnabled: true,
          whatsappPhoneId,
          whatsappToken: 'fake-token-for-test',
        })
        .expect(409)
        .expect((res) => {
          expect(res.body?.code).toBe('WHATSAPP_NUMBER_IN_USE');
          expect(res.body?.translationKey).toBe('whatsapp_number_in_use');
        });
      await request(app.getHttpServer())
        .post('/api/portal/request-otp')
        .send({ mobile: '01155554444', gymSlug: data.gym.slug })
        .expect(201);

      // 5 Failed attempts
      // FIX (launch-readiness, same discovery pass as the route-path/status
      // fixes above): `/api/portal/verify-otp` is ALSO guarded by the same
      // shared, IP-keyed `BruteForceGuard` as `/api/auth/login` and
      // `/api/portal/request-otp` (3 attempts/30s lockout). This test's own
      // intent is to exercise PortalService's SEPARATE, mobile-keyed OTP
      // failed-attempt counter (5 wrong codes -> 401 each, 6th call blocked
      // with 400) — a real, different rate-limiting mechanism from the IP
      // guard. Making 6 real HTTP calls to the same route in a loop tripped
      // the IP guard's own 3-attempt threshold partway through, returning
      // 429 instead of ever reaching the controller/service logic under
      // test for the later iterations. Reset the IP-keyed guard before each
      // iteration (mirroring the same pattern already used before every
      // other real login/OTP-request call in this suite) so only the
      // mobile-keyed OTP counter this test actually cares about is
      // exercised.
      for (let i = 0; i < 5; i++) {
        await bruteForce.reset('ip:::ffff:127.0.0.1');
        await bruteForce.reset('ip:127.0.0.1');
        await request(app.getHttpServer())
          .post('/api/portal/verify-otp')
          .send({ mobile: '01155554444', code: '000000', gymSlug: data.gym.slug })
          .expect(401);
      }

      // 6th attempt should be blocked with 400
      await bruteForce.reset('ip:::ffff:127.0.0.1');
      await bruteForce.reset('ip:127.0.0.1');
      await request(app.getHttpServer())
        .post('/api/portal/verify-otp')
        .send({ mobile: '01155554444', code: '000000', gymSlug: data.gym.slug })
        .expect(400);
    });
  });
});
