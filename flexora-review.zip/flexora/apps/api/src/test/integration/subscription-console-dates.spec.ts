/** @jest-environment node */
// Run only against a disposable test database. Never targets production data.
import { API, ConsoleHarness, startConsoleHarness } from '../support/platform-console-harness';

jest.setTimeout(240_000);
describe('subscription directory dates', () => {
  let h: ConsoleHarness;
  const ids: string[] = [];
  const stamp = Date.now().toString(36);
  beforeAll(async () => {
    h = await startConsoleHarness(`subdates-${stamp}`);
    const rows = [
      { label: 'trial', tier: 'PRO', status: 'TRIALING', start: new Date('2026-11-11T00:00:00Z'), end: new Date('2026-11-25T00:00:00Z') },
      { label: 'active', tier: 'ELITE', status: 'ACTIVE', start: new Date('2026-01-01T00:00:00Z'), end: new Date('2099-01-01T00:00:00Z') },
      { label: 'expired', tier: 'BASIC', status: 'ACTIVE', start: new Date('2020-01-01T00:00:00Z'), end: new Date('2020-02-01T00:00:00Z') },
    ];
    for (const row of rows) {
      const gym = await h.prisma.gym.create({ data: { name: `subdates-${stamp}-${row.label}`, slug: `subdates-${stamp}-${row.label}`, email: `${row.label}-${stamp}@example.test`, phone: '000' } });
      ids.push(gym.id);
      await h.prisma.subscription.create({ data: {
        gymId: gym.id, tier: row.tier as any, status: row.status as any, currentPeriodEnd: row.end,
        currentPeriodStart: row.status === 'TRIALING' ? null : row.start,
        trialStartDate: row.status === 'TRIALING' ? row.start : null,
        trialEndDate: row.status === 'TRIALING' ? row.end : null,
      } });
    }
  });
  afterAll(async () => {
    if (!h) return;
    for (const id of ids) await h.prisma.gym.delete({ where: { id } }).catch(() => undefined);
    await h.close();
  });
  it('returns the actual database instants for trial, active and expired in list and detail', async () => {
    const list = await h.get(`${API}/platform/subscriptions/console?search=subdates-${stamp}`);
    expect(list.status).toBe(200);
    expect(list.body.total).toBe(3);
    expect(list.body.limit).toBe(25);
    for (const id of ids) {
      const db = await h.prisma.subscription.findUniqueOrThrow({ where: { gymId: id } });
      const item = list.body.items.find((entry: any) => entry.gymId === id);
      const detail = await h.get(`${API}/platform/gyms/${id}`);
      expect(detail.status).toBe(200);
      const sub = detail.body.gym.subscription;
      const start = db.status === 'TRIALING' ? db.trialStartDate : db.currentPeriodStart;
      const end = db.status === 'TRIALING' ? (db.trialEndDate ?? db.currentPeriodEnd) : db.currentPeriodEnd;
      expect(item.startDate).toBe(start?.toISOString() ?? null);
      expect(item.endDate).toBe(end.toISOString());
      expect(sub.tier).toBe(item.tier);
      expect(sub.status).toBe(item.status);
      expect(db.status === 'TRIALING' ? sub.trialStartDate : sub.currentPeriodStart).toBe(item.startDate);
      expect(db.status === 'TRIALING' ? (sub.trialEndDate ?? sub.currentPeriodEnd) : sub.currentPeriodEnd).toBe(item.endDate);
    }
  });
  it('filters expired records and rejects an unrelated search', async () => {
    const expired = await h.get(`${API}/platform/subscriptions/console?search=subdates-${stamp}&window=expired`);
    expect(expired.status).toBe(200);
    expect(expired.body.items.some((row: any) => row.effectiveStatus === 'EXPIRED')).toBe(true);
    expect(expired.body.items.every((row: any) => new Date(row.endDate).getTime() < Date.now())).toBe(true);
    const none = await h.get(`${API}/platform/subscriptions/console?search=subdates-${stamp}-not-present`);
    expect(none.body.total).toBe(0);
  });
});
