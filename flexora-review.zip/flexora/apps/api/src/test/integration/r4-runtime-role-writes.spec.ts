/** @jest-environment node */
/**
 * FLEXORA Gym OS - Backend API
 * (c) 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R4 - the test that should have existed in PHASE R2, and the reason a production defect
 * survived two phases.
 *
 * THE DEFECT. public."Subscription" is FORCE ROW LEVEL SECURITY with one tenant-isolation
 * policy. PHASE R2 solved platform READS across tenants with eleven SECURITY DEFINER functions,
 * every one of them read-only, and never addressed platform WRITES. So all three routes that
 * write a subscription - PATCH gyms/:id/plan, POST gyms/:id/extend-trial, POST
 * gyms/:id/grant-subscription - failed in production with:
 *
 *     42501  new row violates row-level security policy for table "Subscription"
 *
 * WHY NOTHING CAUGHT IT. Two reasons that compound. The console had no surface for any of the
 * three (the gyms page was a 32-line JSON dump with no buttons), so no owner ever pressed one.
 * And every jest harness in this repository connects as `flexora`, a SUPERUSER - and a superuser
 * bypasses row-level security outright, FORCE or not. So the suites passed green while the
 * production role could not write at all. It was found by a browser proof driving the real api.
 *
 * WHAT THIS SPEC DOES DIFFERENTLY. It boots the Nest application with DATABASE_URL pointing at
 * the RUNTIME role, so every HTTP request below runs with exactly the privileges production runs
 * with, and it asserts current_user inside the booted app before testing anything - if that
 * assertion ever stops holding, this suite is worthless and says so instead of passing. Fixtures
 * stay on a separate superuser client, because creating administrators and gyms is setup, not the
 * thing under test.
 *
 * Repointing process.env.DATABASE_URL is normally forbidden in this repo's specs, for a good
 * reason: in a single-worker run it silently downgrades every other suite. It is safe here
 * because jest gives each worker its own process and runs files sequentially within it, the
 * original value is captured before it is touched and restored in afterAll, and the suite asserts
 * the role it actually got. The r2-runtime-role-privacy suite builds a second client instead,
 * which is the right pattern when only a QUERY needs the other role; here the whole APPLICATION
 * has to run as it.
 *
 * No secret value is printed anywhere in this file.
 */
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import { PrismaClient } from '@prisma/client';
import cookieParser from 'cookie-parser';
import request from 'supertest';

import { AppModule } from '../../app.module';
import { HttpExceptionFilter } from '../../common/filters/http-exception.filter';
import { API_GLOBAL_PREFIX } from '../../config/api-prefix';
import { ADMIN_HOSTS_VAR } from '../../config/admin-hosts';
import { PrismaService } from '../../config/prisma.service';
import { hashPassword } from '../../config/password-hash';
import { totpTokenAt } from '../../common/security/platform-totp';
import { grantPeriodEnd, trialPeriodEnd } from '../../modules/platform/platform.controller';

jest.setTimeout(240_000);

const ADMIN_HOST = 'localhost';
const API = `/${API_GLOBAL_PREFIX}`;
const RUNTIME_ROLE = 'flexora_app';
const LABEL = 'rls-write';
const RUN_ID = Date.now().toString(36);
const EMAIL = `r4-${LABEL}-${RUN_ID}@example.com`;
// Built from parts so no credential-shaped NAME is assigned a literal.
const PASSWORD = ['R4RlsWrite', 'password', '0'.repeat(6)].join('-');
const REASON = 'R4 runtime-role write spec needs a reason of at least eight characters';

/** The role the api runs as in production, derived from the owner URL the way r2 does. */
function runtimeUrl(ownerUrl: string, password: string): string {
  const url = new URL(ownerUrl);
  url.username = RUNTIME_ROLE;
  url.password = password;
  return url.toString();
}

describe('R4 - the platform subscription writes work AS THE RUNTIME ROLE, over HTTP', () => {
  let app: INestApplication;
  /** Fixtures only. Never used to make an assertion about what the api can do. */
  let owner: PrismaClient;
  let cookie = '';
  let adminId = '';
  let gymId = '';
  let totpSecret = '';
  const OWNER_URL = process.env.DATABASE_URL;
  const APP_PASSWORD = process.env.FLEXORA_APP_TEST_PASSWORD;
  let keyCounter = 0;
  const nextKey = (prefix: string) => `${prefix}-${RUN_ID}-${(keyCounter += 1).toString(36)}`;

  beforeAll(async () => {
    if (!OWNER_URL) throw new Error('DATABASE_URL is not set; run this through work/r2-one-spec.sh');
    if (!APP_PASSWORD) throw new Error('FLEXORA_APP_TEST_PASSWORD is not set; run this through work/r2-one-spec.sh');

    owner = new PrismaClient();
    process.env[ADMIN_HOSTS_VAR] = `${ADMIN_HOST},127.0.0.1`;

    // ── fixtures, as the owner ────────────────────────────────────────────────
    await owner.platformLoginAttempt.deleteMany({});
    const previous = await owner.platformAdmin.findUnique({ where: { email: EMAIL }, select: { id: true } });
    if (previous) {
      await owner.platformSession.deleteMany({ where: { adminId: previous.id } }).catch(() => undefined);
    }
    await owner.platformAdmin.deleteMany({ where: { email: EMAIL } });

    const admin = await owner.platformAdmin.create({
      data: {
        email: EMAIL,
        name: 'R4 runtime-role write',
        role: 'PLATFORM_ADMIN',
        passwordHash: await hashPassword(PASSWORD),
        status: 'ACTIVE',
      },
    });
    adminId = admin.id;

    const gym = await owner.gym.create({
      data: {
        name: `R4 rls write ${RUN_ID}`,
        slug: `r4-rls-${RUN_ID}`,
        email: `r4-rls-${RUN_ID}@test.local`,
        phone: '01000000007',
        status: 'ACTIVE' as any,
      },
    });
    gymId = gym.id;

    // ── boot the application AS THE RUNTIME ROLE ─────────────────────────────
    process.env.DATABASE_URL = runtimeUrl(OWNER_URL, APP_PASSWORD);
    process.env.DIRECT_URL = runtimeUrl(OWNER_URL, APP_PASSWORD);

    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
    app = moduleRef.createNestApplication({ logger: false });
    app.setGlobalPrefix(API_GLOBAL_PREFIX);
    app.use(cookieParser());
    app.useGlobalFilters(new HttpExceptionFilter());
    // PHASE R4: matches main.ts, including forbidNonWhitelisted.
    app.useGlobalPipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }));
    await app.init();

    // THE ASSERTION THAT MAKES THIS SUITE MEAN SOMETHING. If the application is not actually
    // connected as the runtime role, every "200 not 500" below would pass for the wrong reason
    // and the suite would go back to hiding the defect it exists to catch.
    const prisma = app.get(PrismaService);
    const identity = await prisma.$queryRaw<Array<{ current_user: string; rolsuper: boolean }>>`
      SELECT current_user, r.rolsuper FROM pg_roles r WHERE r.rolname = current_user`;
    expect(identity[0].current_user).toBe(RUNTIME_ROLE);
    expect(identity[0].rolsuper).toBe(false);

    // And the boundary is real from inside the app: the runtime role cannot read Subscription.
    const visible = await prisma.$queryRaw<Array<{ n: number }>>`SELECT count(*)::integer AS n FROM public."Subscription"`;
    expect(visible[0].n).toBe(0);

    // ── authenticate, still as the runtime role ──────────────────────────────
    const login = await request(app.getHttpServer())
      .post(`${API}/platform/auth/login`)
      .set('Host', ADMIN_HOST)
      .send({ email: EMAIL, password: PASSWORD });
    expect(login.status).toBe(201);
    cookie = jar(login);

    const begin = await call('POST', `${API}/platform/auth/totp/enrol`);
    expect(begin.status).toBe(200);
    totpSecret = begin.body.secret as string;
    const done = await call('POST', `${API}/platform/auth/totp/verify`, { code: totpTokenAt(totpSecret) });
    expect(done.status).toBe(200);
    const stepUp = await call('POST', `${API}/platform/auth/step-up`, {
      code: totpTokenAt(totpSecret, Date.now() + 30_000),
    });
    expect(stepUp.status).toBe(200);
  });

  afterAll(async () => {
    // Restore FIRST, so a later suite in this worker can never inherit the runtime URL.
    if (OWNER_URL) {
      process.env.DATABASE_URL = OWNER_URL;
      process.env.DIRECT_URL = OWNER_URL;
    }
    await app?.close().catch(() => undefined);
    if (owner) {
      await owner.platformAlert.deleteMany({ where: { targetId: gymId } }).catch(() => undefined);
      await owner.subscription.deleteMany({ where: { gymId } }).catch(() => undefined);
      await owner.gymSettings.deleteMany({ where: { gymId } }).catch(() => undefined);
      await owner.renewalRequest.deleteMany({ where: { gymId } }).catch(() => undefined);
      await owner.gym.deleteMany({ where: { id: gymId } }).catch(() => undefined);
      await owner.platformSession.deleteMany({ where: { adminId } }).catch(() => undefined);
      await owner.platformRecoveryCode.deleteMany({ where: { adminId } }).catch(() => undefined);
      // PHASE R3 decision A5.1: audit rows are never deleted by a fixture.
      await owner.platformAdmin.deleteMany({ where: { id: adminId } }).catch(() => undefined);
      await owner.$disconnect();
    }
  });

  function jar(response: request.Response): string {
    const raw = response.headers['set-cookie'];
    if (!raw) return '';
    return (Array.isArray(raw) ? raw : [raw]).map((entry) => String(entry).split(';')[0]).join('; ');
  }
  function csrfOf(value: string): string {
    return /flx_platform_csrf=([^;]+)/.exec(value)?.[1] ?? '';
  }
  async function call(method: string, url: string, body?: unknown) {
    const req = (request(app.getHttpServer()) as any)[method.toLowerCase()](url)
      .set('Host', ADMIN_HOST)
      .set('User-Agent', 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) R4RlsWrite/1.0')
      .set('Cookie', cookie)
      .set('x-csrf-token', csrfOf(cookie));
    const response: request.Response = body === undefined ? await req : await req.send(body as object);
    const fresh = jar(response);
    if (fresh.includes('flx_platform_token=')) cookie = fresh;
    return { status: response.status, body: response.body, headers: response.headers };
  }
  async function reStepUp(): Promise<void> {
    // FIXTURE reset of the TOTP replay counter, not a weakened control: the replay rule stays in
    // force for every call and is asserted by r1-platform-auth.spec.ts.
    await owner.platformAdmin.update({ where: { id: adminId }, data: { totpLastUsedStep: null } });
    const response = await call('POST', `${API}/platform/auth/step-up`, { code: totpTokenAt(totpSecret) });
    expect(response.status).toBe(200);
  }

  it('1. NEGATIVE CONTROL: as the runtime role a direct UPDATE on Subscription changes nothing', async () => {
    // This is the boundary the sanctioned function exists to cross. If it ever stops holding,
    // the function is no longer a narrow exception - it is a hole.
    const prisma = app.get(PrismaService);
    const result = await prisma.$executeRaw`
      UPDATE public."Subscription" SET tier = 'ELITE' WHERE "gymId" = ${gymId}`;
    expect(result).toBe(0);
    const ownerView = await owner.subscription.findUnique({ where: { gymId } });
    expect(ownerView?.tier).not.toBe('ELITE');
  });

  it('2. PATCH gyms/:id/plan answers 200 as the runtime role, not 500', async () => {
    await reStepUp();
    // ChangePlanDto has `plan` and no `tier`: with forbidNonWhitelisted matching main.ts, an
    // extra property is a 400 rather than being silently stripped. The first version of this
    // call copied the crawl's body, which had been getting away with the extra field for exactly
    // that reason.
    const response = await call('PATCH', `${API}/platform/gyms/${gymId}/plan`, { plan: 'PRO' });
    // Not 500. That single number is the whole point of this suite: before the R4 migration
    // this route answered 500 in production with a row-level-security violation, and answered
    // 200 in every jest run because jest connects as a superuser.
    expect(response.status).not.toBe(500);
    expect([200, 201]).toContain(response.status);

    // Read back as the OWNER, because the runtime role cannot see the row it just wrote.
    const row = await owner.subscription.findUniqueOrThrow({ where: { gymId } });
    expect(row.tier).toBe('PRO');
    expect(row.status).toBe('ACTIVE');
  });

  it('3. POST gyms/:id/extend-trial answers 200 as the runtime role, and writes the quoted date', async () => {
    await reStepUp();
    const quote = await call('GET', `${API}/platform/gyms/${gymId}/trial-quote?days=21`);
    expect(quote.status).toBe(200);
    const response = await call('POST', `${API}/platform/gyms/${gymId}/extend-trial`, {
      days: 21,
      reason: REASON,
      idempotencyKey: nextKey('rls-trial'),
      quotedTrialEndDate: quote.body.trialEndDate,
    });
    expect(response.status).toBeLessThan(500);
    expect([200, 201]).toContain(response.status);

    const row = await owner.subscription.findUniqueOrThrow({ where: { gymId } });
    expect(row.trialEndDate?.toISOString()).toBe(quote.body.trialEndDate);
    expect(row.status).toBe('TRIALING');
  });

  it('4. POST gyms/:id/grant-subscription answers 200 as the runtime role, and writes the quoted date', async () => {
    await reStepUp();
    const quote = await call('GET', `${API}/platform/gyms/${gymId}/grant-quote?plan=ELITE&months=2`);
    expect(quote.status).toBe(200);
    const key = nextKey('rls-grant');
    const response = await call('POST', `${API}/platform/gyms/${gymId}/grant-subscription`, {
      plan: 'ELITE',
      months: 2,
      reason: REASON,
      idempotencyKey: key,
      quotedPeriodEnd: quote.body.currentPeriodEnd,
    });
    expect([200, 201]).toContain(response.status);

    const row = await owner.subscription.findUniqueOrThrow({ where: { gymId } });
    expect(row.tier).toBe('ELITE');
    expect(row.currentPeriodEnd.toISOString()).toBe(quote.body.currentPeriodEnd);

    // and the ledger's afterState carries the STORED value, not the intended one
    const ledger = await owner.platformAuditLog.findFirst({
      where: { action: 'gym:grant-subscription', target: gymId, details: { path: ['idempotencyKey'], equals: key } },
      orderBy: { seq: 'desc' },
    });
    expect(ledger).not.toBeNull();
    expect((ledger!.afterState as Record<string, unknown>).currentPeriodEnd).toBe(quote.body.currentPeriodEnd);
    // beforeState is no longer silently null, which is what reading it through a direct
    // prisma.subscription.findUnique did for the runtime role
    expect(ledger!.beforeState).not.toBeNull();
    expect(Object.keys(ledger!.beforeState as object).length).toBeGreaterThan(0);
  });

  it('5. the double tap still grants exactly once, as the runtime role', async () => {
    await reStepUp();
    const quote = await call('GET', `${API}/platform/gyms/${gymId}/grant-quote?plan=PRO&months=4`);
    const body = {
      plan: 'PRO',
      months: 4,
      reason: REASON,
      idempotencyKey: nextKey('rls-double'),
      quotedPeriodEnd: quote.body.currentPeriodEnd,
    };
    const before = await owner.platformAuditLog.count({
      where: { action: 'gym:grant-subscription', target: gymId, details: { path: ['idempotencyKey'], equals: body.idempotencyKey } },
    });
    expect(before).toBe(0);

    const [first, second] = await Promise.all([
      call('POST', `${API}/platform/gyms/${gymId}/grant-subscription`, body),
      call('POST', `${API}/platform/gyms/${gymId}/grant-subscription`, body),
    ]);
    for (const response of [first, second]) expect([200, 201]).toContain(response.status);
    expect([first.headers['x-flexora-idempotent'], second.headers['x-flexora-idempotent']].sort()).toEqual([
      'applied',
      'replayed',
    ]);

    const rows = await owner.platformAuditLog.count({
      where: { action: 'gym:grant-subscription', target: gymId, details: { path: ['idempotencyKey'], equals: body.idempotencyKey } },
    });
    expect(rows).toBe(1);
  });

  it('6. the function refuses a soft-deleted gym, and the api turns that into a 400 rather than a 500', async () => {
    // Validation lives in the database as well as the api (owner requirement 2), so this checks
    // both halves: the function raises P4DEL, and translateSubscriptionWriteFailure maps it.
    await owner.gym.update({ where: { id: gymId }, data: { status: 'DELETED' as any, deletedAt: new Date() } });
    await reStepUp();
    const quote = await call('GET', `${API}/platform/gyms/${gymId}/grant-quote?plan=PRO&months=1`);
    const response = await call('POST', `${API}/platform/gyms/${gymId}/grant-subscription`, {
      plan: 'PRO',
      months: 1,
      reason: REASON,
      idempotencyKey: nextKey('rls-deleted'),
      quotedPeriodEnd: quote.body?.currentPeriodEnd ?? grantPeriodEnd(1).toISOString(),
    });
    expect(response.status).toBe(400);
    expect(String(JSON.stringify(response.body))).toMatch(/soft-deleted|restore/i);
    await owner.gym.update({ where: { id: gymId }, data: { status: 'ACTIVE' as any, deletedAt: null } });
  });

  it('7. an unknown plan is refused by the database enum, and the api answers 400', async () => {
    await reStepUp();
    const response = await call('POST', `${API}/platform/gyms/${gymId}/grant-subscription`, {
      plan: 'PLATINUM',
      months: 1,
      reason: REASON,
      idempotencyKey: nextKey('rls-badplan'),
      quotedPeriodEnd: grantPeriodEnd(1).toISOString(),
    });
    // clampPlan in the api rejects it first; the enum cast is the second line of defence and is
    // proven directly against the function in the migration verification log.
    expect(response.status).toBe(400);
    const row = await owner.subscription.findUniqueOrThrow({ where: { gymId } });
    expect(row.tier).not.toBe('PLATINUM');
  });

  it('8. a trial quote for a gym that does not exist is a 404, not a 500', async () => {
    const response = await call('GET', `${API}/platform/gyms/does-not-exist-${RUN_ID}/grant-quote?plan=PRO&months=1`);
    expect(response.status).toBe(404);
    void trialPeriodEnd;
  });
});
