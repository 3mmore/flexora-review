import { PrismaClient } from '@prisma/client';
import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import { AppModule } from '../../app.module';
const request = require('supertest');
import { randomBytes } from 'crypto';
import { hashPassword } from '../../config/password-hash';

const APP_PASSWORD = process.env.FLEXORA_APP_TEST_PASSWORD;
const OWNER_URL = process.env.DATABASE_URL;

const maybeDescribe = APP_PASSWORD && OWNER_URL ? describe : describe.skip;

function buildAppUrl(): string {
  const url = new URL(OWNER_URL!);
  url.username = 'flexora_app';
  url.password = APP_PASSWORD!;
  return url.toString();
}

maybeDescribe('Item 1 - Preauth lookup function integration', () => {
  let app: INestApplication;
  let owner: PrismaClient;
  let gymA: { id: string };
  let userA: { id: string, email: string };
  let plainPassword = 'PreauthTestPassword123!';

  beforeAll(async () => {
    // Setup db as owner
    owner = new PrismaClient({ datasources: { db: { url: OWNER_URL } } });
    await owner.$connect();

    gymA = await owner.gym.create({
      data: { name: 'Preauth Gym A', slug: `preauth-gym-a-${Date.now()}`, email: `preauth-a-${Date.now()}@test.com`, phone: '0111' },
    });

    const passwordHash = await hashPassword(plainPassword);
    
    userA = await owner.user.create({
      data: {
        gymId: gymA.id,
        email: `user-preauth-${Date.now()}@test.com`,
        name: 'Preauth User A',
        role: 'OWNER',
        passwordHash,
      }
    });

    // Start Nest App using the flexora_app role
    process.env.DATABASE_URL = buildAppUrl();
    const moduleRef = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleRef.createNestApplication();
    await app.init();
  }, 30000);

  afterAll(async () => {
    if (app) await app.close();
    process.env.DATABASE_URL = OWNER_URL; // restore
    if (owner) {
      await owner.user.deleteMany({ where: { gymId: gymA.id } });
      await owner.gym.deleteMany({ where: { id: gymA.id } });
      await owner.$disconnect();
    }
  }, 30000);

  it('connects as flexora_app and successfully authenticates via preauth_find_users_by_email', async () => {
    const res = await request(app.getHttpServer())
      .post('/auth/login')
      .send({ email: userA.email, password: plainPassword })
      .expect(201); // Created

    expect(res.body.user).toBeDefined();
    expect(res.body.user.id).toBe(userA.id);
    expect(res.headers['set-cookie']).toBeDefined();
    expect(res.headers['set-cookie'].some((c: string) => c.startsWith('flx_access='))).toBe(true);
  });
});
