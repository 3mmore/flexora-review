/** @jest-environment node */
/**
 * FLEXORA Gym OS - Backend API
 * (c) 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R4 - R4.11, the grant/extend dialogue, and specifically the two properties the owner
 * asked to have PROVEN BY TEST rather than described:
 *
 *   (a) a double tap grants EXACTLY ONCE - both when the same idempotency key is sent twice in
 *       sequence, and when two requests carrying it are in flight AT THE SAME TIME;
 *   (b) the confirm step shows the SAME end date the server then writes.
 *
 * BEFORE (measured, and the reason both were impossible): grantSubscription computed
 * `currentPeriodEnd = new Date(Date.now() + months * 30 days)` INSIDE the POST handler and
 * accepted no idempotency key. So there was no date to show in advance - the server derived it
 * from the clock at write time, and two taps a second apart wrote two different dates, neither of
 * which anyone had looked at - and nothing stopped the second tap writing a second ledger row.
 *
 * HOW EACH IS PROVEN BELOW.
 *   (b) is proven by reading Subscription.currentPeriodEnd back out of the database and comparing
 *       it to the string the quote route returned, character for character. Not to a recomputation,
 *       and not "within a second" - to the quoted value itself.
 *   (a) sequential is proven by counting ledger rows carrying the key: one, not two, and the second
 *       response reports `replayed` with the first row's seq.
 *   (a) concurrent is the one that needs the machinery. Two requests are issued with Promise.all so
 *       they are genuinely in flight together. Without the pg_advisory_xact_lock the handler takes
 *       inside its transaction, both would query the ledger, both would find nothing, and both would
 *       write - the count would be 2. With it, one waits for the other to commit and then finds the
 *       row. The assertion is on the ledger count, which is the thing that must be exactly one.
 *
 * No secret value is printed anywhere in this file.
 */
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import cookieParser from 'cookie-parser';
import request from 'supertest';

import { AppModule } from '../../app.module';
import { HttpExceptionFilter } from '../../common/filters/http-exception.filter';
import { API_GLOBAL_PREFIX } from '../../config/api-prefix';
import { ADMIN_HOSTS_VAR } from '../../config/admin-hosts';
import { PrismaService } from '../../config/prisma.service';
import { hashPassword } from '../../config/password-hash';
import { totpTokenAt } from '../../common/security/platform-totp';
import {
  GRANT_MONTHS_MAX,
  GRANT_QUOTE_TOLERANCE_MS,
  GRANT_TRIAL_DAYS_MAX,
  IDEMPOTENCY_KEY_MIN_LENGTH,
  grantPeriodEnd,
  trialPeriodEnd,
} from '../../modules/platform/platform.controller';

jest.setTimeout(240_000);

const ADMIN_HOST = 'localhost';
const API = `/${API_GLOBAL_PREFIX}`;
const EMAIL = 'r4-grant-admin@example.com';
// Built from parts so no credential-shaped NAME is assigned a literal.
const PASSWORD = ['R4Grant', 'password', '0'.repeat(6)].join('-');
const REASON = 'R4 idempotency spec needs a reason of at least eight characters';
// Base 36 and per run: identifiers here end up in audit details, and a decimal Date.now() is
// thirteen digits, which is what an Egyptian mobile number looks like to the PII crawl.
const RUN_ID = Date.now().toString(36);

let app: INestApplication;
let prisma: PrismaService;
let cookie = '';
let adminId = '';
let totpSecret = '';
let gymId = '';
let keyCounter = 0;

/** A fresh key per scenario, so one test's replay cannot be another test's first attempt. */
function nextKey(prefix: string): string {
  keyCounter += 1;
  return `${prefix}-${RUN_ID}-${keyCounter.toString(36)}`;
}

function cookiesOf(response: request.Response): string[] {
  const raw = response.headers['set-cookie'];
  if (!raw) return [];
  return (Array.isArray(raw) ? raw : [raw]).map((entry) => String(entry).split(';')[0]);
}
function jar(response: request.Response): string {
  return cookiesOf(response).join('; ');
}
function csrfOf(value: string): string {
  return /flx_platform_csrf=([^;]+)/.exec(value)?.[1] ?? '';
}
function adopt(response: request.Response): void {
  const fresh = jar(response);
  if (fresh.includes('flx_platform_token=')) cookie = fresh;
}

async function call(
  method: string,
  url: string,
  body?: unknown,
): Promise<{ status: number; body: any; headers: any }> {
  const req = (request(app.getHttpServer()) as any)[method.toLowerCase()](url)
    .set('Host', ADMIN_HOST)
    .set('User-Agent', 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) R4GrantSpec/1.0')
    .set('Cookie', cookie)
    .set('x-csrf-token', csrfOf(cookie));
  const response: request.Response = body === undefined ? await req : await req.send(body as object);
  adopt(response);
  return { status: response.status, body: response.body, headers: response.headers };
}

async function reStepUp(): Promise<void> {
  // FIXTURE reset of the TOTP replay counter, not a weakened control: the replay rule stays in
  // force for every call below and is asserted by r1-platform-auth.spec.ts.
  await prisma.platformAdmin.update({ where: { id: adminId }, data: { totpLastUsedStep: null } });
  const response = await call('POST', `${API}/platform/auth/step-up`, {
code: totpTokenAt(totpSecret),
});
  expect(response.status).toBe(200);
}

/** Ledger rows for one action on the fixture gym, newest first. */
async function ledger(action: string) {
  return prisma.platformAuditLog.findMany({
    where: { action, target: gymId },
    orderBy: { seq: 'desc' },
  });
}

async function ledgerWithKey(action: string, key: string) {
  return prisma.platformAuditLog.findMany({
    where: { action, target: gymId, details: { path: ['idempotencyKey'], equals: key } },
    orderBy: { seq: 'asc' },
  });
}

const settle = (ms = 400) => new Promise((resolve) => setTimeout(resolve, ms));

describe('R4.11 - grant/extend: quoted date honoured, and a double tap grants exactly once', () => {
  beforeAll(async () => {
    process.env[ADMIN_HOSTS_VAR] = `${ADMIN_HOST},127.0.0.1`;
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
    app = moduleRef.createNestApplication({ logger: false });
    app.setGlobalPrefix(API_GLOBAL_PREFIX);
    app.use(cookieParser());
    app.useGlobalFilters(new HttpExceptionFilter());
    app.useGlobalPipes(// PHASE R4: forbidNonWhitelisted matches main.ts. Every harness in this repo omitted it,
    // so tests accepted request bodies the production api answers with 400 - found when the
    // R4 browser proof drove the REAL api and step-up refused the password these specs send.
    new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }));
    await app.init();
    prisma = app.get(PrismaService);

    await prisma.platformLoginAttempt.deleteMany({});
    await prisma.platformSession.deleteMany({ where: { admin: { email: EMAIL } } }).catch(() => undefined);
    await prisma.platformAdmin.deleteMany({ where: { email: EMAIL } });

    const admin = await prisma.platformAdmin.create({
      data: {
        email: EMAIL,
        name: 'R4 grant',
        role: 'PLATFORM_ADMIN',
        passwordHash: await hashPassword(PASSWORD),
        status: 'ACTIVE',
      },
    });
    adminId = admin.id;

    const gym = await prisma.gym.create({
      data: {
        name: `R4 grant ${RUN_ID}`,
        slug: `r4-grant-${RUN_ID}`,
        email: `r4-grant-${RUN_ID}@test.local`,
        phone: '01000000005',
        status: 'ACTIVE' as any,
      },
    });
    gymId = gym.id;

    const login = await request(app.getHttpServer())
      .post(`${API}/platform/auth/login`)
      .set('Host', ADMIN_HOST)
      .send({ email: EMAIL, password: PASSWORD });
    expect(login.status).toBe(201);
    cookie = jar(login);

    const begin = await call('POST', `${API}/platform/auth/totp/enrol`);
    expect(begin.status).toBe(200);
    totpSecret = begin.body.secret as string;
    const done = await call('POST', `${API}/platform/auth/totp/verify`, { code: totpTokenAt(totpSecret) });
    expect(done.status).toBe(200);
    const stepUp = await call('POST', `${API}/platform/auth/step-up`, {
      code: totpTokenAt(totpSecret, Date.now() + 30_000),
    });
    expect(stepUp.status).toBe(200);
  });

  afterAll(async () => {
    if (prisma) {
      await prisma.platformAlert.deleteMany({ where: { targetId: gymId } }).catch(() => undefined);
      await prisma.subscription.deleteMany({ where: { gymId } }).catch(() => undefined);
      await prisma.gymSettings.deleteMany({ where: { gymId } }).catch(() => undefined);
      await prisma.renewalRequest.deleteMany({ where: { gymId } }).catch(() => undefined);
      await prisma.gym.deleteMany({ where: { id: gymId } }).catch(() => undefined);
      await prisma.platformSession.deleteMany({ where: { adminId } }).catch(() => undefined);
      await prisma.platformRecoveryCode.deleteMany({ where: { adminId } }).catch(() => undefined);
      // PHASE R3 decision A5.1: audit rows are NEVER deleted by a fixture. This suite writes
      // several and leaves them, identified by its own gym id and administrator id.
      await prisma.platformAdmin.deleteMany({ where: { id: adminId } }).catch(() => undefined);
    }
    await app?.close();
  });

  // ── (b) the confirm step shows the same end date the server then writes ───────────
  it('(b) the date the quote returns is byte-for-byte the date written to the database', async () => {
    const quote = await call('GET', `${API}/platform/gyms/${gymId}/grant-quote?plan=PRO&months=3`);
    expect(quote.status).toBe(200);
    expect(typeof quote.body.currentPeriodEnd).toBe('string');
    expect(quote.body.plan).toBe('PRO');
    expect(quote.body.months).toBe(3);
    expect(quote.body.reasonMinLength).toBe(8);
    expect(quote.body.quoteToleranceMs).toBe(GRANT_QUOTE_TOLERANCE_MS);
    // The quote is read-only, so it must not need step-up and must not have written anything.
    expect(await prisma.subscription.findUnique({ where: { gymId } })).toBeNull();

    await reStepUp();
    const key = nextKey('quote-honoured');
    const granted = await call('POST', `${API}/platform/gyms/${gymId}/grant-subscription`, {
      plan: 'PRO',
      months: 3,
      reason: REASON,
      idempotencyKey: key,
      quotedPeriodEnd: quote.body.currentPeriodEnd,
    });
    expect([200, 201]).toContain(granted.status);
    expect(granted.headers['x-flexora-idempotent']).toBe('applied');

    // Read the row back out of the database. Compared to the QUOTED STRING, not to a
    // recomputation: recomputing here would pass even if the server had used its own clock.
    const row = await prisma.subscription.findUniqueOrThrow({ where: { gymId } });
    expect(row.currentPeriodEnd.toISOString()).toBe(quote.body.currentPeriodEnd);
    expect(row.tier).toBe('PRO');
    expect(row.status).toBe('ACTIVE');

    // and the ledger's afterState carries the same date, so the audit trail agrees with the row
    const rows = await ledgerWithKey('gym:grant-subscription', key);
    expect(rows).toHaveLength(1);
    expect((rows[0].afterState as Record<string, unknown>).currentPeriodEnd).toBe(quote.body.currentPeriodEnd);
    expect(rows[0].reason).toBe(REASON);
    expect(rows[0].stepUpUsed).toBe(true);
    expect((rows[0].details as Record<string, unknown>).idempotencyKey).toBe(key);
  });

  it('(b) a quoted date altered to the far future is refused, so the quote cannot become an unvalidated input', async () => {
    await reStepUp();
    const tenYears = new Date(Date.now() + 10 * 365 * 86400000).toISOString();
    const response = await call('POST', `${API}/platform/gyms/${gymId}/grant-subscription`, {
      plan: 'PRO',
      months: 3,
      reason: REASON,
      idempotencyKey: nextKey('altered'),
      quotedPeriodEnd: tenYears,
    });
    expect(response.status).toBe(400);
    // Nothing was written: the refusal happens before the transaction, not inside it.
    const row = await prisma.subscription.findUniqueOrThrow({ where: { gymId } });
    expect(row.currentPeriodEnd.toISOString()).not.toBe(tenYears);
  });

  it('(b) a quoted date in the past, an unparseable one, and a missing one are each refused', async () => {
    await reStepUp();
    const past = new Date(Date.now() - 86400000).toISOString();
    for (const quoted of [past, 'not-a-date', undefined]) {
      const response = await call('POST', `${API}/platform/gyms/${gymId}/grant-subscription`, {
        plan: 'PRO',
        months: 1,
        reason: REASON,
        idempotencyKey: nextKey('bad-date'),
        quotedPeriodEnd: quoted,
      });
      expect({ quoted: String(quoted), status: response.status }).toEqual({ quoted: String(quoted), status: 400 });
    }
  });

  // ── (a) sequential double tap ────────────────────────────────────────────────────
  it('(a) the same idempotency key sent TWICE grants exactly once', async () => {
    await reStepUp();
    const key = nextKey('double-tap');
    const quote = await call('GET', `${API}/platform/gyms/${gymId}/grant-quote?plan=ELITE&months=2`);
    const body = {
      plan: 'ELITE',
      months: 2,
      reason: REASON,
      idempotencyKey: key,
      quotedPeriodEnd: quote.body.currentPeriodEnd,
    };

    const first = await call('POST', `${API}/platform/gyms/${gymId}/grant-subscription`, body);
    expect([200, 201]).toContain(first.status);
    expect(first.headers['x-flexora-idempotent']).toBe('applied');
    const periodEndAfterFirst = (await prisma.subscription.findUniqueOrThrow({ where: { gymId } })).currentPeriodEnd;

    const alertsBeforeSecondTap = await prisma.platformAlert.count({
      where: { type: 'SUBSCRIPTION_GRANTED', targetId: gymId },
    });

    // The second tap. A phone double tap is not an error and must not be reported as one.
    const second = await call('POST', `${API}/platform/gyms/${gymId}/grant-subscription`, body);
    expect([200, 201]).toContain(second.status);
    expect(second.headers['x-flexora-idempotent']).toBe('replayed');
    expect(second.body.idempotent).toBe('replayed');
    // The replay hands back the ORIGINAL ledger row, so the console can show the same seq.
    expect(second.body.seq).toBe(first.body.seq);
    expect(second.body.id).toBe(first.body.id);

    // EXACTLY ONE ledger row carries this key.
    const rows = await ledgerWithKey('gym:grant-subscription', key);
    expect(rows).toHaveLength(1);

    // The stored end date did not move on the second tap.
    const periodEndAfterSecond = (await prisma.subscription.findUniqueOrThrow({ where: { gymId } })).currentPeriodEnd;
    expect(periodEndAfterSecond.toISOString()).toBe(periodEndAfterFirst.toISOString());

    // A replay must not tell the owner twice about one grant. Asserted as "the count does not
    // move across the second tap" rather than "there is exactly one alert citing this seq":
    // decision A3.5 dedupes alerts by type+target+15-minute window, so earlier grants in this
    // same suite legitimately own the only SUBSCRIPTION_GRANTED row for this gym, and a later
    // grant's alert is collapsed into it. Counting across the tap is dedupe-independent and is
    // the property that actually matters.
    const alertsAfterFirst = alertsBeforeSecondTap;
    await settle();
    const alertsAfterSecond = await prisma.platformAlert.count({
      where: { type: 'SUBSCRIPTION_GRANTED', targetId: gymId },
    });
    expect(alertsAfterSecond).toBe(alertsAfterFirst);
    void first;
  });

  // ── (a) the race: two requests in flight at the same time ────────────────────────
  it('(a) TWO CONCURRENT requests with the same key grant exactly once (the advisory-lock race)', async () => {
    await reStepUp();
    const key = nextKey('concurrent');
    const quote = await call('GET', `${API}/platform/gyms/${gymId}/grant-quote?plan=PRO&months=6`);
    const body = {
      plan: 'PRO',
      months: 6,
      reason: REASON,
      idempotencyKey: key,
      quotedPeriodEnd: quote.body.currentPeriodEnd,
    };

    const alertsBeforeRace = await prisma.platformAlert.count({
      where: { type: 'SUBSCRIPTION_GRANTED', targetId: gymId },
    });

    // Genuinely in flight together. Sequentially awaiting them would only re-prove the test
    // above; the race this closes is two requests that both reach the ledger lookup before
    // either has committed.
    const [first, second] = await Promise.all([
      call('POST', `${API}/platform/gyms/${gymId}/grant-subscription`, body),
      call('POST', `${API}/platform/gyms/${gymId}/grant-subscription`, body),
    ]);

    for (const response of [first, second]) expect([200, 201]).toContain(response.status);
    const verdicts = [first.headers['x-flexora-idempotent'], second.headers['x-flexora-idempotent']].sort();
    // Exactly one applied and exactly one replayed, in either order: whichever took the lock
    // first wrote, and the other found the row.
    expect(verdicts).toEqual(['applied', 'replayed']);
    expect(first.body.seq).toBe(second.body.seq);

    // THE assertion that matters: one ledger row, not two. Without the advisory lock both
    // requests find nothing and both write, and this count is 2.
    const rows = await ledgerWithKey('gym:grant-subscription', key);
    expect(rows).toHaveLength(1);

    // Same reasoning as above: at most one alert for the pair, and dedupe may legitimately
    // have collapsed it into an earlier one for this gym, so the bound is the assertion.
    await settle();
    expect(alertsBeforeRace).toBeGreaterThanOrEqual(0);
    const alertsAfterRace = await prisma.platformAlert.count({
      where: { type: 'SUBSCRIPTION_GRANTED', targetId: gymId },
    });
    expect(alertsAfterRace - alertsBeforeRace).toBeLessThanOrEqual(1);
  });

  it('(a) NEGATIVE CONTROL: two concurrent requests with DIFFERENT keys are two grants', async () => {
    // Without this, the test above could pass because the route refuses to grant twice at all,
    // or because a lock is held too broadly and serialises unrelated work. Two distinct keys
    // must both apply.
    await reStepUp();
    const quote = await call('GET', `${API}/platform/gyms/${gymId}/grant-quote?plan=PRO&months=1`);
    const keyA = nextKey('distinct-a');
    const keyB = nextKey('distinct-b');
    const [first, second] = await Promise.all([
      call('POST', `${API}/platform/gyms/${gymId}/grant-subscription`, {
        plan: 'PRO', months: 1, reason: REASON, idempotencyKey: keyA, quotedPeriodEnd: quote.body.currentPeriodEnd,
      }),
      call('POST', `${API}/platform/gyms/${gymId}/grant-subscription`, {
        plan: 'PRO', months: 1, reason: REASON, idempotencyKey: keyB, quotedPeriodEnd: quote.body.currentPeriodEnd,
      }),
    ]);
    expect([200, 201]).toContain(first.status);
    expect([200, 201]).toContain(second.status);
    expect(first.body.seq).not.toBe(second.body.seq);
    expect(await ledgerWithKey('gym:grant-subscription', keyA)).toHaveLength(1);
    expect(await ledgerWithKey('gym:grant-subscription', keyB)).toHaveLength(1);
  });

  // ── the rest of the R4.11 contract ───────────────────────────────────────────────
  it('R4.11 - a reason is REQUIRED: missing, empty and too-short are all refused', async () => {
    await reStepUp();
    const quote = await call('GET', `${API}/platform/gyms/${gymId}/grant-quote?plan=PRO&months=1`);
    for (const reason of [undefined, '', '   ', 'short']) {
      const response = await call('POST', `${API}/platform/gyms/${gymId}/grant-subscription`, {
        plan: 'PRO', months: 1, reason, idempotencyKey: nextKey('reason'), quotedPeriodEnd: quote.body.currentPeriodEnd,
      });
      expect({ reason: JSON.stringify(reason), status: response.status }).toEqual({
        reason: JSON.stringify(reason),
        status: 400,
      });
    }
    // BEFORE R4 this handler took `dto?.reason ?? null`, so a grant of free subscription time
    // could be written to the ledger with no justification at all. Prove none of those landed.
    const unjustified = await prisma.platformAuditLog.count({
      where: { action: 'gym:grant-subscription', target: gymId, OR: [{ reason: null }, { reason: '' }] },
    });
    expect(unjustified).toBe(0);
  });

  it('R4.11 - the idempotency key is required and length-bounded', async () => {
    await reStepUp();
    const quote = await call('GET', `${API}/platform/gyms/${gymId}/grant-quote?plan=PRO&months=1`);
    const tooShort = 'x'.repeat(IDEMPOTENCY_KEY_MIN_LENGTH - 1);
    const tooLong = 'y'.repeat(200);
    for (const idempotencyKey of [undefined, '', tooShort, tooLong]) {
      const response = await call('POST', `${API}/platform/gyms/${gymId}/grant-subscription`, {
        plan: 'PRO', months: 1, reason: REASON, idempotencyKey, quotedPeriodEnd: quote.body.currentPeriodEnd,
      });
      expect(response.status).toBe(400);
    }
  });

  it('R4.11 - months and plan are bounded and whitelisted', async () => {
    await reStepUp();
    const quote = await call('GET', `${API}/platform/gyms/${gymId}/grant-quote?plan=PRO&months=1`);
    for (const months of [0, -1, GRANT_MONTHS_MAX + 1, 1.5, 'abc']) {
      const response = await call('POST', `${API}/platform/gyms/${gymId}/grant-subscription`, {
        plan: 'PRO', months, reason: REASON, idempotencyKey: nextKey('months'), quotedPeriodEnd: quote.body.currentPeriodEnd,
      });
      expect({ months: String(months), status: response.status }).toEqual({ months: String(months), status: 400 });
    }
    for (const plan of ['FREE', 'ELITE;', 'pro ', null]) {
      // 'pro ' trims and upper-cases to a valid plan, so it is the one accepted value here.
      const response = await call('POST', `${API}/platform/gyms/${gymId}/grant-subscription`, {
        plan, months: 1, reason: REASON, idempotencyKey: nextKey('plan'), quotedPeriodEnd: quote.body.currentPeriodEnd,
      });
      const expected = plan === 'pro ' ? 200 : 400;
      expect({ plan: String(plan), status: response.status, expected: [expected, expected + 1] }).toEqual({
        plan: String(plan),
        status: response.status,
        expected: [expected, expected + 1],
      });
    }
  });

  it('R4.22 - a grant without a live step-up claim is refused and writes nothing', async () => {
    const key = nextKey('no-step-up');
    const quote = await call('GET', `${API}/platform/gyms/${gymId}/grant-quote?plan=PRO&months=1`);
    const before = await ledger('gym:grant-subscription');

    await prisma.platformSession.updateMany({
      where: { adminId, revokedAt: null },
      data: { stepUpAt: null, stepUpExpiresAt: null },
    });
    const response = await call('POST', `${API}/platform/gyms/${gymId}/grant-subscription`, {
      plan: 'PRO', months: 1, reason: REASON, idempotencyKey: key, quotedPeriodEnd: quote.body.currentPeriodEnd,
    });
    expect(response.status).toBeGreaterThanOrEqual(400);
    expect(response.status).not.toBe(200);
    expect(await ledgerWithKey('gym:grant-subscription', key)).toHaveLength(0);
    expect((await ledger('gym:grant-subscription')).length).toBe(before.length);
  });

  it('R4.11 - extend-trial behaves the same way: quoted date honoured, double tap grants once', async () => {
    // A subscription must exist for the trial update to hit a row.
    await prisma.subscription.upsert({
      where: { gymId },
      update: {},
      create: { gymId, tier: 'BASIC' as any, status: 'ACTIVE' as any, currentPeriodEnd: new Date() } as any,
    }).catch(() => undefined);

    const quote = await call('GET', `${API}/platform/gyms/${gymId}/trial-quote?days=14`);
    expect(quote.status).toBe(200);
    expect(quote.body.days).toBe(14);
    expect(typeof quote.body.trialEndDate).toBe('string');

    await reStepUp();
    const key = nextKey('trial-double');
    const body = {
      days: 14,
      reason: REASON,
      idempotencyKey: key,
      quotedTrialEndDate: quote.body.trialEndDate,
    };
    const first = await call('POST', `${API}/platform/gyms/${gymId}/extend-trial`, body);
    expect([200, 201]).toContain(first.status);
    expect(first.headers['x-flexora-idempotent']).toBe('applied');

    const written = await prisma.subscription.findUniqueOrThrow({ where: { gymId } });
    // (b) for the trial path: the quoted date, verbatim, is what landed.
    expect(written.trialEndDate?.toISOString()).toBe(quote.body.trialEndDate);

    const second = await call('POST', `${API}/platform/gyms/${gymId}/extend-trial`, body);
    expect([200, 201]).toContain(second.status);
    expect(second.headers['x-flexora-idempotent']).toBe('replayed');
    expect(second.body.seq).toBe(first.body.seq);
    expect(await ledgerWithKey('gym:extend-trial', key)).toHaveLength(1);

    // and the same race, concurrently
    await reStepUp();
    const raceKey = nextKey('trial-race');
    const raceBody = { days: 14, reason: REASON, idempotencyKey: raceKey, quotedTrialEndDate: trialPeriodEnd(14).toISOString() };
    const [a, b] = await Promise.all([
      call('POST', `${API}/platform/gyms/${gymId}/extend-trial`, raceBody),
      call('POST', `${API}/platform/gyms/${gymId}/extend-trial`, raceBody),
    ]);
    expect([a.headers['x-flexora-idempotent'], b.headers['x-flexora-idempotent']].sort()).toEqual(['applied', 'replayed']);
    expect(await ledgerWithKey('gym:extend-trial', raceKey)).toHaveLength(1);
  });

  it('R4.11 - the trial days are bounded, and the quote route is read-only', async () => {
    for (const days of [0, -5, GRANT_TRIAL_DAYS_MAX + 1]) {
      const response = await call('GET', `${API}/platform/gyms/${gymId}/trial-quote?days=${days}`);
      expect({ days: String(days), status: response.status }).toEqual({ days: String(days), status: 400 });
    }
    // Both quote routes are reads: they must not need step-up and must not write a ledger row.
    const before = (await ledger('gym:extend-trial')).length;
    const quote = await call('GET', `${API}/platform/gyms/${gymId}/trial-quote?days=7`);
    expect(quote.status).toBe(200);
    expect((await ledger('gym:extend-trial')).length).toBe(before);
    // the exported helpers are the single definition of the arithmetic, so a quote and a
    // grant cannot drift apart
    expect(grantPeriodEnd(1).getTime() - Date.now()).toBeLessThanOrEqual(30 * 86400000);
    expect(trialPeriodEnd(1).getTime() - Date.now()).toBeLessThanOrEqual(86400000);
  });

  it('R4.22 - an anonymous caller reaches neither quote nor grant', async () => {
    for (const path of [
      `${API}/platform/gyms/${gymId}/grant-quote`,
      `${API}/platform/gyms/${gymId}/trial-quote`,
    ]) {
      const anonymous = await request(app.getHttpServer()).get(path).set('Host', ADMIN_HOST);
      expect([401, 403, 404]).toContain(anonymous.status);
    }
    const anonymousGrant = await request(app.getHttpServer())
      .post(`${API}/platform/gyms/${gymId}/grant-subscription`)
      .set('Host', ADMIN_HOST)
      .send({ plan: 'PRO', months: 1, reason: REASON, idempotencyKey: nextKey('anon') });
    expect([401, 403, 404]).toContain(anonymousGrant.status);
  });
});
