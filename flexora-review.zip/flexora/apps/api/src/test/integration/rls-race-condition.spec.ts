/**
 * FLEXORA Gym OS — RLS race-condition regression test (Item 1)
 *
 * Reproduces the exact scenario described in the ticket: pgbouncer in
 * "transaction" pooling mode means a bare `SELECT set_config(...)` followed
 * by a *separate* query call is not guaranteed to land on the same physical
 * Postgres connection. This test hammers the DB with many concurrent
 * requests from two different gymIds (using the real TenantContextService +
 * AsyncLocalStorage, exactly as production request handling does via
 * TenantGuard) and asserts that neither gym ever sees the other's rows.
 *
 * This test talks to a REAL Postgres instance (not mocked) and enables
 * `ENABLE ROW LEVEL SECURITY` + `FORCE ROW LEVEL SECURITY` on the `Member`
 * table for the duration of the test so that if the two-statement race
 * existed, it would manifest as either:
 *   (a) cross-tenant rows leaking into the wrong gym's result set, or
 *   (b) empty result sets where rows should exist (RLS silently filtering
 *       everything because app.gym_id was never actually set on that
 *       connection).
 */
import { PrismaClient } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { TenantContextService } from '../../common/services/tenant-context.service';
import { randomBytes } from 'crypto';

const RUN_ID = randomBytes(4).toString('hex');

describe('RLS race condition — concurrent multi-tenant requests (Item 1)', () => {
  let prisma: PrismaService;
  let tenantContext: TenantContextService;
  let admin: PrismaClient;

  let gymA: { id: string };
  let gymB: { id: string };
  let branchA: { id: string };
  let branchB: { id: string };
  let planA: { id: string };
  let planB: { id: string };

  // Captured so afterAll can restore the exact pre-test state instead of
  // unconditionally disabling RLS — this table's RLS/FORCE state is owned by
  // migration 202607050001_flexora_app_role_force_rls (Item 2) in real
  // environments, and this test must not permanently undo that.
  let originalRls: { relrowsecurity: boolean; relforcerowsecurity: boolean } | null = null;

  beforeAll(async () => {
    tenantContext = new TenantContextService();
    prisma = new PrismaService(tenantContext);
    await prisma.onModuleInit();

    // Separate, un-extended admin client to set up fixtures & RLS without
    // going through the tenant-scoped extension (setup must be able to see
    // both gyms at once).
    admin = new PrismaClient();
    await admin.$connect();

    const before: { relrowsecurity: boolean; relforcerowsecurity: boolean }[] = await admin.$queryRawUnsafe(
      `SELECT relrowsecurity, relforcerowsecurity FROM pg_class WHERE relname = 'Member'`,
    );
    originalRls = before[0] ?? { relrowsecurity: false, relforcerowsecurity: false };

    // Enable + FORCE RLS on Member for this test run so the race, if
    // present, cannot hide behind "RLS wasn't even on". (No-ops if Item 2's
    // migration already turned these on permanently.)
    await admin.$executeRawUnsafe(`ALTER TABLE "Member" ENABLE ROW LEVEL SECURITY`);
    await admin.$executeRawUnsafe(`ALTER TABLE "Member" FORCE ROW LEVEL SECURITY`);
    await admin.$executeRawUnsafe(`DROP POLICY IF EXISTS "Member_rls_race_test" ON "Member"`);
    await admin.$executeRawUnsafe(`
      CREATE POLICY "Member_rls_race_test" ON "Member"
        USING ("gymId" = current_setting('app.gym_id', true))
        WITH CHECK ("gymId" = current_setting('app.gym_id', true))
    `);

    gymA = await admin.gym.create({
      data: { name: `RLS Race A ${RUN_ID}`, slug: `rls-race-a-${RUN_ID}`, email: `a-${RUN_ID}@test.com`, phone: '0100' },
    });
    gymB = await admin.gym.create({
      data: { name: `RLS Race B ${RUN_ID}`, slug: `rls-race-b-${RUN_ID}`, email: `b-${RUN_ID}@test.com`, phone: '0200' },
    });
    branchA = await admin.branch.create({ data: { gymId: gymA.id, name: 'Branch A' } });
    branchB = await admin.branch.create({ data: { gymId: gymB.id, name: 'Branch B' } });
    planA = await admin.plan.create({ data: { gymId: gymA.id, name: 'Plan A', type: 'TIME', price: 100, days: 30 } });
    planB = await admin.plan.create({ data: { gymId: gymB.id, name: 'Plan B', type: 'TIME', price: 100, days: 30 } });
  }, 30000);

  afterAll(async () => {
    await admin.$executeRawUnsafe(`DROP POLICY IF EXISTS "Member_rls_race_test" ON "Member"`);
    // Restore exactly the state this table was in before the test ran,
    // instead of unconditionally disabling RLS (which would permanently
    // undo Item 2's FORCE ROW LEVEL SECURITY migration for every test run
    // after this one).
    if (originalRls && !originalRls.relforcerowsecurity) {
      await admin.$executeRawUnsafe(`ALTER TABLE "Member" NO FORCE ROW LEVEL SECURITY`);
    }
    if (originalRls && !originalRls.relrowsecurity) {
      await admin.$executeRawUnsafe(`ALTER TABLE "Member" DISABLE ROW LEVEL SECURITY`);
    }
    await admin.member.deleteMany({ where: { gymId: { in: [gymA.id, gymB.id] } } });
    await admin.plan.deleteMany({ where: { gymId: { in: [gymA.id, gymB.id] } } });
    await admin.branch.deleteMany({ where: { gymId: { in: [gymA.id, gymB.id] } } });
    await admin.gym.deleteMany({ where: { id: { in: [gymA.id, gymB.id] } } });
    await admin.$disconnect();
    await prisma.onModuleDestroy();
  }, 30000);

  it('creates seed members scoped correctly for each gym', async () => {
    await tenantContext.run(gymA.id, async () => {
      await prisma.member.create({
        data: {
          gymId: gymA.id, branchId: branchA.id, planId: planA.id,
          name: 'Alice (Gym A)', mobile: '01011110000', code: `A-${RUN_ID}`, startDate: new Date(),
        },
      });
    });
    await tenantContext.run(gymB.id, async () => {
      await prisma.member.create({
        data: {
          gymId: gymB.id, branchId: branchB.id, planId: planB.id,
          name: 'Bob (Gym B)', mobile: '01022220000', code: `B-${RUN_ID}`, startDate: new Date(),
        },
      });
    });
  });

  it('never leaks tenant data under heavy concurrent read/write load from two gymIds', async () => {
    const ITERATIONS = 60; // heavy concurrent hammering of the pooled connection

    const tasks: Promise<void>[] = [];

    for (let i = 0; i < ITERATIONS; i++) {
      // Interleave gym A and gym B calls tightly so they race for connections.
      tasks.push(
        tenantContext.run(gymA.id, async () => {
          const rows = await prisma.member.findMany({ where: { gymId: gymA.id } });
          for (const r of rows) {
            if (r.gymId !== gymA.id) {
              throw new Error(`LEAK: gymA context saw a row belonging to gymId=${r.gymId}`);
            }
          }
          if (rows.length === 0) {
            throw new Error('FALSE-EMPTY: gymA context got zero rows — RLS session var was not visible');
          }
        }),
      );
      tasks.push(
        tenantContext.run(gymB.id, async () => {
          const rows = await prisma.member.findMany({ where: { gymId: gymB.id } });
          for (const r of rows) {
            if (r.gymId !== gymB.id) {
              throw new Error(`LEAK: gymB context saw a row belonging to gymId=${r.gymId}`);
            }
          }
          if (rows.length === 0) {
            throw new Error('FALSE-EMPTY: gymB context got zero rows — RLS session var was not visible');
          }
        }),
      );
      // Also mix in writes to further stress connection reuse.
      tasks.push(
        tenantContext.run(gymA.id, async () => {
          const m = await prisma.member.create({
            data: {
              gymId: gymA.id, branchId: branchA.id, planId: planA.id,
              name: `Race A ${i}`, mobile: `0103${String(i).padStart(7, '0')}`, code: `RA-${RUN_ID}-${i}`, startDate: new Date(),
            },
          });
          if (m.gymId !== gymA.id) throw new Error('write returned wrong gymId for A');
        }),
      );
      tasks.push(
        tenantContext.run(gymB.id, async () => {
          const m = await prisma.member.create({
            data: {
              gymId: gymB.id, branchId: branchB.id, planId: planB.id,
              name: `Race B ${i}`, mobile: `0104${String(i).padStart(7, '0')}`, code: `RB-${RUN_ID}-${i}`, startDate: new Date(),
            },
          });
          if (m.gymId !== gymB.id) throw new Error('write returned wrong gymId for B');
        }),
      );
    }

    // No leak/false-empty errors should surface from any of the ~240 concurrent operations.
    await Promise.all(tasks);

    // Final sanity: query totals directly (bypassing RLS via admin) and confirm
    // strict separation — no cross-linked rows exist.
    const crossLeakA = await admin.member.count({ where: { gymId: gymA.id, NOT: { gymId: gymA.id } } });
    const crossLeakB = await admin.member.count({ where: { gymId: gymB.id, NOT: { gymId: gymB.id } } });
    expect(crossLeakA).toBe(0);
    expect(crossLeakB).toBe(0);

    const finalA = await tenantContext.run(gymA.id, () => prisma.member.findMany({ where: { gymId: gymA.id } }));
    const finalB = await tenantContext.run(gymB.id, () => prisma.member.findMany({ where: { gymId: gymB.id } }));
    expect(finalA.every((m) => m.gymId === gymA.id)).toBe(true);
    expect(finalB.every((m) => m.gymId === gymB.id)).toBe(true);
    expect(finalA.length).toBe(ITERATIONS + 1);
    expect(finalB.length).toBe(ITERATIONS + 1);
  }, 60000);
});
