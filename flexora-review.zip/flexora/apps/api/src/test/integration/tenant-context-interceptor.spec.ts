import { INestApplication, Controller, Get, UseGuards } from '@nestjs/common';
import { Test } from '@nestjs/testing';
const request = require('supertest');
import { PrismaClient } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';
import { TenantContextService } from '../../common/services/tenant-context.service';
import { TenantContextInterceptor } from '../../common/interceptors/tenant-context.interceptor';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { JwtStrategy } from '../../modules/auth/jwt.strategy';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';

const APP_PASSWORD = process.env.FLEXORA_APP_TEST_PASSWORD;
const OWNER_URL = process.env.DATABASE_URL;
// PHASE N2 — this suite overwrites JWT_ACCESS_SECRET with 'test-secret' so it
// can sign its own tokens. In the full `npm test` run every suite shares ONE
// worker process, so leaving it overwritten made every LATER suite verify
// real tokens against 'test-secret' (401s that have nothing to do with the
// code under test). Captured here, restored in afterAll.
const ORIGINAL_JWT_ACCESS_SECRET = process.env.JWT_ACCESS_SECRET;

const maybeDescribe = APP_PASSWORD && OWNER_URL ? describe : describe.skip;

function buildAppUrl(): string {
  const url = new URL(OWNER_URL!);
  url.username = 'flexora_app';
  url.password = APP_PASSWORD!;
  url.searchParams.set('connection_limit', '5');
  return url.toString();
}

@Controller('test-tenant')
class TestTenantController {
  constructor(private readonly prisma: PrismaService) {}

  @Get('members')
  @UseGuards(JwtAuthGuard, TenantGuard)
  async getMembers() {
    const members = await this.prisma.member.findMany({
      select: { code: true }
    });
    return { members };
  }
}

maybeDescribe('Item 1 - TenantContextInterceptor E2E', () => {
  let app: INestApplication;
  let owner: PrismaClient;

  let gymA: { id: string };
  let gymB: { id: string };
  let tokenA: string;
  let tokenB: string;

  beforeAll(async () => {
    owner = new PrismaClient({ datasources: { db: { url: OWNER_URL } } });
    await owner.$connect();

    gymA = await owner.gym.create({ data: { name: 'Tenant A', slug: `tenant-a-${Date.now()}`, email: `ta-${Date.now()}@test.com`, phone: '111' } });
    gymB = await owner.gym.create({ data: { name: 'Tenant B', slug: `tenant-b-${Date.now()}`, email: `tb-${Date.now()}@test.com`, phone: '222' } });

    const branchA = await owner.branch.create({ data: { gymId: gymA.id, name: 'Branch A' } });
    const branchB = await owner.branch.create({ data: { gymId: gymB.id, name: 'Branch B' } });

    const planA = await owner.plan.create({ data: { gymId: gymA.id, name: 'Plan A', type: 'TIME', price: 100, days: 30 } });
    const planB = await owner.plan.create({ data: { gymId: gymB.id, name: 'Plan B', type: 'TIME', price: 100, days: 30 } });

    await owner.member.create({ data: { gymId: gymA.id, branchId: branchA.id, planId: planA.id, name: 'Member A', mobile: '0101', code: `A-${Date.now()}`, startDate: new Date() } });
    await owner.member.create({ data: { gymId: gymA.id, branchId: branchA.id, planId: planA.id, name: 'Member A2', mobile: '0102', code: `A2-${Date.now()}`, startDate: new Date() } });
    await owner.member.create({ data: { gymId: gymB.id, branchId: branchB.id, planId: planB.id, name: 'Member B', mobile: '0103', code: `B-${Date.now()}`, startDate: new Date() } });

    // PHASE N2 — these tokens must be signed for REAL users. Since ROUND 13
    // (Phase 5), `JwtStrategy.validate` re-checks the account on EVERY request
    // through the SECURITY DEFINER helper `preauth_find_user_by_id(payload.sub)`
    // and returns null (=> 401 Unauthorized) when the user does not exist or is
    // inactive — deactivating a staff account has to kill their live sessions
    // immediately. This suite used to sign `{ sub: 'user-a' }` / `{ sub: 'user-b' }`,
    // ids that were never in the database, so both requests answered 401 and the
    // tenant propagation this suite exists to prove was never exercised at all.
    // passwordHash is a syntactically valid argon2id placeholder: nothing logs in
    // here, the strategy only reads id/active.
    const PLACEHOLDER_HASH = '$argon2id$v=19$m=65536,t=3,p=1$c2FsdHNhbHQ$ZmFrZWhhc2hmb3J0ZXN0aW5nb25seQ';
    const userA = await owner.user.create({
      data: { gymId: gymA.id, branchId: branchA.id, name: 'Tenant A Owner', email: `ta-owner-${Date.now()}@test.com`, role: 'OWNER', passwordHash: PLACEHOLDER_HASH },
    });
    const userB = await owner.user.create({
      data: { gymId: gymB.id, branchId: branchB.id, name: 'Tenant B Owner', email: `tb-owner-${Date.now()}@test.com`, role: 'OWNER', passwordHash: PLACEHOLDER_HASH },
    });

    process.env.DATABASE_URL = buildAppUrl();
    process.env.JWT_ACCESS_SECRET = 'test-secret';

    const moduleRef = await Test.createTestingModule({
      controllers: [TestTenantController],
      providers: [
        PrismaService,
        TenantContextService,
        JwtStrategy,
        {
          provide: ConfigService,
          useValue: { get: (k: string) => process.env[k] }
        },
        {
          provide: 'APP_INTERCEPTOR',
          useClass: TenantContextInterceptor,
        }
      ]
    }).compile();

    app = moduleRef.createNestApplication();
    await app.init();

    const jwtService = new JwtService({ secret: 'test-secret' });
    tokenA = jwtService.sign({ sub: userA.id, email: userA.email, name: userA.name, role: 'OWNER', gymId: gymA.id });
    tokenB = jwtService.sign({ sub: userB.id, email: userB.email, name: userB.name, role: 'OWNER', gymId: gymB.id });
  }, 30000);

  afterAll(async () => {
    if (app) await app.close();
    process.env.DATABASE_URL = OWNER_URL;
    process.env.JWT_ACCESS_SECRET = ORIGINAL_JWT_ACCESS_SECRET ?? '';
    if (owner) {
      // users first: "User".branchId/gymId are ON DELETE NO ACTION
      await owner.user.deleteMany({ where: { gymId: { in: [gymA.id, gymB.id] } } });
      await owner.member.deleteMany({ where: { gymId: { in: [gymA.id, gymB.id] } } });
      await owner.plan.deleteMany({ where: { gymId: { in: [gymA.id, gymB.id] } } });
      await owner.branch.deleteMany({ where: { gymId: { in: [gymA.id, gymB.id] } } });
      await owner.gym.deleteMany({ where: { id: { in: [gymA.id, gymB.id] } } });
      await owner.$disconnect();
    }
  }, 30000);

  it('correctly propagates context to Prisma so that only the caller tenant members are returned', async () => {
    const resA = await request(app.getHttpServer())
      .get('/test-tenant/members')
      .set('Authorization', `Bearer ${tokenA}`)
      .expect(200);

    expect(resA.body.members).toHaveLength(2);
    expect(resA.body.members[0].code).toMatch(/^A2?-/);

    const resB = await request(app.getHttpServer())
      .get('/test-tenant/members')
      .set('Authorization', `Bearer ${tokenB}`)
      .expect(200);

    expect(resB.body.members).toHaveLength(1);
    expect(resB.body.members[0].code).toMatch(/^B-/);
  });

  it('handles concurrent requests with different gymIds accurately', async () => {
    const reqA1 = request(app.getHttpServer()).get('/test-tenant/members').set('Authorization', `Bearer ${tokenA}`);
    const reqB1 = request(app.getHttpServer()).get('/test-tenant/members').set('Authorization', `Bearer ${tokenB}`);
    const reqA2 = request(app.getHttpServer()).get('/test-tenant/members').set('Authorization', `Bearer ${tokenA}`);
    const reqB2 = request(app.getHttpServer()).get('/test-tenant/members').set('Authorization', `Bearer ${tokenB}`);

    const [resA1, resB1, resA2, resB2] = await Promise.all([reqA1, reqB1, reqA2, reqB2]);

    expect(resA1.body.members).toHaveLength(2);
    expect(resB1.body.members).toHaveLength(1);
    expect(resA2.body.members).toHaveLength(2);
    expect(resB2.body.members).toHaveLength(1);
  });
});
