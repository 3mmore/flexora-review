/**
 * FLEXORA Gym OS — Item 2 regression test: BullModule.forRoot() uses the
 * single REDIS_URL source of truth (not the old silent-fallback
 * REDIS_HOST/REDIS_PORT/REDIS_PASSWORD pattern).
 *
 * CONCLUSIVE TEST DESIGN:
 * - Two Redis instances run: 6379 (default) and 6380 (non-default).
 * - REDIS_URL is set to redis://localhost:6380.
 * - We enqueue a real job via BullModule.forRoot({ url: REDIS_URL }).
 * - We then connect a separate raw Redis client to 6380 and verify the
 *   queue keys (bull:* prefix) actually exist there.
 * - We ALSO connect to 6379 and verify NO queue keys exist there.
 * - This proves the url option is genuinely parsed and used, not just
 *   falling through to Bull's own default of localhost:6379.
 */
import { Test, TestingModule } from '@nestjs/testing';
import { BullModule, InjectQueue } from '@nestjs/bull';
import { Injectable, Module } from '@nestjs/common';
import { Queue } from 'bull';
import Redis from 'ioredis';

const TEST_REDIS_URL = 'redis://localhost:6380';
const TEST_QUEUE_NAME = 'flexora-redis-url-verification';

@Injectable()
class TestJobProcessor {
  public processed = 0;
  public lastData: string | null = null;

  async process(job: { data: { msg: string } }) {
    this.processed += 1;
    this.lastData = job.data.msg;
    return { received: job.data.msg };
  }
}

@Module({
  imports: [
    BullModule.forRoot({
      url: TEST_REDIS_URL,
      defaultJobOptions: { attempts: 1, removeOnComplete: 10, removeOnFail: 10 },
    }),
    // PHASE N3 — Bull's worker starts a `stalledInterval` timer (30 s by default:
    // bull/lib/queue.js:226-228) that writes `bull:<queue>:stalled-check` (key
    // list at queue.js:271) on the very Redis instance this suite is asserting
    // about. When a full `npm test` run happened to land that tick between this
    // suite's own cleanup (`client6380.del(...)`, line ~84) and its "no leftovers
    // from a previous run" assertion (line ~88), the suite failed on a key IT had
    // just created — a timing flake, not a REDIS_URL defect. The boundary is easy
    // to hit: the whole run takes 31-32 s. `stalledInterval: 0` disables the timer
    // outright (the `> 0` guard at queue.js:1090), so the assertions below can
    // only ever observe keys this test enqueued itself. Stalled-job recovery is
    // irrelevant to what is proved here (that the queue lives on REDIS_URL's
    // instance and not on Bull's 6379 default) — the job is processed in
    // milliseconds by this suite's own processor.
    BullModule.registerQueue({ name: TEST_QUEUE_NAME, settings: { stalledInterval: 0 } }),
  ],
  providers: [TestJobProcessor],
})
class TestBullModule {}

describe('Item 2 — BullModule uses REDIS_URL single source of truth (conclusive)', () => {
  let queue: Queue;
  let processor: TestJobProcessor;
  let client6379: Redis;
  let client6380: Redis;

  beforeAll(async () => {
    // Raw Redis clients to inspect actual keys on each instance
    client6379 = new Redis({ port: 6379, lazyConnect: true });
    client6380 = new Redis({ port: 6380, lazyConnect: true });

    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [TestBullModule],
    }).compile();

    queue = moduleFixture.get<Queue>(`BullQueue_${TEST_QUEUE_NAME}`);
    processor = moduleFixture.get(TestJobProcessor);

    queue.process((job) => processor.process(job));
  }, 30000);

  afterAll(async () => {
    if (queue) {
      await queue.empty();
      await queue.close();
    }
    if (client6379) await client6379.quit();
    if (client6380) await client6380.quit();
  }, 30000);

  it('enqueues and processes a real job ONLY on the REDIS_URL instance (port 6380), not on the default 6379', async () => {
    // 1. Clean any leftover keys from previous runs, then verify both are empty
    const stale6379 = await client6379.keys(`bull:${TEST_QUEUE_NAME}:*`);
    if (stale6379.length) await client6379.del(...stale6379);
    const stale6380 = await client6380.keys(`bull:${TEST_QUEUE_NAME}:*`);
    if (stale6380.length) await client6380.del(...stale6380);
    const keysBefore6379 = await client6379.keys(`bull:${TEST_QUEUE_NAME}:*`);
    const keysBefore6380 = await client6380.keys(`bull:${TEST_QUEUE_NAME}:*`);
    expect(keysBefore6379).toEqual([]);
    expect(keysBefore6380).toEqual([]);

    // 2. Enqueue a job
    const job = await queue.add({ msg: 'redis-url-test-payload' });
    expect(job.id).toBeTruthy();

    // 3. Wait for the worker to process the job
    let attempts = 0;
    const maxAttempts = 50;
    while (attempts < maxAttempts) {
      const state = await job.getState();
      if (state === 'completed' || state === 'failed') break;
      await new Promise((r) => setTimeout(r, 100));
      attempts++;
    }

    const finalState = await job.getState();
    expect(finalState).toBe('completed');
    expect(processor.processed).toBeGreaterThanOrEqual(1);
    expect(processor.lastData).toBe('redis-url-test-payload');

    // 4. CONCLUSIVE CHECK: queue keys MUST exist on 6380 (the REDIS_URL target)
    const keysAfter6380 = await client6380.keys(`bull:${TEST_QUEUE_NAME}:*`);
    expect(keysAfter6380.length).toBeGreaterThan(0);

    // 5. CONCLUSIVE CHECK: queue keys MUST NOT exist on 6379 (the default port)
    // If the url option were silently ignored and Bull fell back to its own
    // default, the keys would appear on 6379 instead — this test would fail.
    const keysAfter6379 = await client6379.keys(`bull:${TEST_QUEUE_NAME}:*`);
    expect(keysAfter6379).toEqual([]);
  }, 30000);
});
