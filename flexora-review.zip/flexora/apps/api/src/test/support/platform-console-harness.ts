/**
 * FLEXORA Gym OS - Backend API
 * (c) 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R4 - the shared owner-console harness.
 *
 * A platform route cannot be exercised without a real session, and getting one means: create an
 * administrator with a real argon2 hash, log in, complete MANDATORY TOTP enrolment (R1.1 - the
 * console is unreachable until it is done), then take a step-up claim, because most platform
 * mutations require one. That is about ninety lines, and by R4 four specs had each grown their
 * own copy. This is that copy, once.
 *
 * It is deliberately a set of functions over a small state object rather than a base class: jest
 * does not run describe blocks in a class hierarchy well, and a function harness makes it obvious
 * which fixture reset is a reset and which is a weakened control.
 *
 * THE ONE FIXTURE RESET, DOCUMENTED: reStepUp() clears totpLastUsedStep before taking a fresh
 * claim, because R1.1's replay guard refuses the same TOTP step twice and several tests in one
 * suite need several claims inside the same minute. That is a reset of the FIXTURE, not of the
 * control - the replay rule stays in force for every call, is asserted by r1-platform-auth.spec.ts,
 * and a code from outside the window is still refused.
 *
 * No secret value is printed or returned by anything here.
 */
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import cookieParser from 'cookie-parser';
import request from 'supertest';

import { AppModule } from '../../app.module';
import { HttpExceptionFilter } from '../../common/filters/http-exception.filter';
import { API_GLOBAL_PREFIX } from '../../config/api-prefix';
import { ADMIN_HOSTS_VAR } from '../../config/admin-hosts';
import { PrismaService } from '../../config/prisma.service';
import { hashPassword } from '../../config/password-hash';
import { totpTokenAt } from '../../common/security/platform-totp';

export const ADMIN_HOST = 'localhost';
export const API = `/${API_GLOBAL_PREFIX}`;

export interface ConsoleResponse {
  status: number;
  body: any;
  /** The raw response text. Use this for CSV: supertest does not parse text/csv into `body`. */
  text: string;
  headers: any;
}

export interface ConsoleHarness {
  app: INestApplication;
  prisma: PrismaService;
  adminId: string;
  email: string;
  password: string;
  totpSecret: string;
  /** The live session cookie, including the CSRF token. Mutated by call(). */
  cookie: string;
  call: (method: string, url: string, body?: unknown) => Promise<ConsoleResponse>;
  get: (url: string) => Promise<ConsoleResponse>;
  post: (url: string, body?: unknown) => Promise<ConsoleResponse>;
  patch: (url: string, body?: unknown) => Promise<ConsoleResponse>;
  del: (url: string, body?: unknown) => Promise<ConsoleResponse>;
  reStepUp: () => Promise<void>;
  clearStepUp: () => Promise<void>;
  /** A request with no cookie at all, for the authorization matrix. */
  anonymous: (method: string, url: string, body?: unknown) => Promise<ConsoleResponse>;
  close: () => Promise<void>;
}

function cookiesOf(response: request.Response): string[] {
  const raw = response.headers['set-cookie'];
  if (!raw) return [];
  return (Array.isArray(raw) ? raw : [raw]).map((entry) => String(entry).split(';')[0]);
}
function jar(response: request.Response): string {
  return cookiesOf(response).join('; ');
}
function csrfOf(value: string): string {
  return /flx_platform_csrf=([^;]+)/.exec(value)?.[1] ?? '';
}

/**
 * Boot the api, create a disposable administrator, and get all the way to a live step-up claim.
 *
 * `label` goes into the email and the fixture's own markers, so two suites running in parallel
 * under --maxWorkers=2 cannot collide on the same administrator. It must be unique per suite.
 */
export async function startConsoleHarness(label: string): Promise<ConsoleHarness> {
  // Base 36 so no fixture identifier contains a run of ten or more digits, which is what an
  // Egyptian mobile number looks like to the PII crawl. A decimal Date.now() is thirteen.
  const runId = `${label}-${Date.now().toString(36)}`;
  const email = `${runId}@example.com`;
  // Built from parts so no credential-shaped NAME is assigned a literal.
  const password = ['R4Console', label, '0'.repeat(6)].join('-');

  process.env[ADMIN_HOSTS_VAR] = `${ADMIN_HOST},127.0.0.1`;
  const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
  const app = moduleRef.createNestApplication({ logger: false });
  app.setGlobalPrefix(API_GLOBAL_PREFIX);
  app.use(cookieParser());
  app.useGlobalFilters(new HttpExceptionFilter());
  app.useGlobalPipes(// PHASE R4: forbidNonWhitelisted matches main.ts. Every harness in this repo omitted it,
    // so tests accepted request bodies the production api answers with 400 - found when the
    // R4 browser proof drove the REAL api and step-up refused the password these specs send.
    new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true, transform: true }));
  await app.init();
  const prisma = app.get(PrismaService);

  // The login route is throttled per IP for 24 h and repeated suite runs leave enough attempts
  // behind to trip it before the first request. Clearing them is a fixture reset; the limits
  // themselves stay in force for every call made through this harness.
  await prisma.platformLoginAttempt.deleteMany({});
  // Sessions are cleared by adminId rather than through an `admin` relation, because
  // PlatformSession.adminId has NO foreign key at all (measured in PHASE R3: pg_constraint has
  // no 'f' row for that table) and so Prisma exposes no relation to filter through. That missing
  // FK is also how orphaned sessions come to exist, which is why R3's device seeding had to
  // resolve every candidate through PlatformAdmin.
  const previous = await prisma.platformAdmin.findUnique({ where: { email }, select: { id: true } });
  if (previous) {
    await prisma.platformSession.deleteMany({ where: { adminId: previous.id } }).catch(() => undefined);
    await prisma.platformRecoveryCode.deleteMany({ where: { adminId: previous.id } }).catch(() => undefined);
  }
  await prisma.platformAdmin.deleteMany({ where: { email } });

  const admin = await prisma.platformAdmin.create({
    data: {
      email,
      name: `R4 ${label}`,
      role: 'PLATFORM_ADMIN',
      passwordHash: await hashPassword(password),
      status: 'ACTIVE',
    },
  });

  const state: ConsoleHarness = {
    app,
    prisma,
    adminId: admin.id,
    email,
    password,
    totpSecret: '',
    cookie: '',
    call: async () => ({ status: 0, body: null, text: '', headers: {} }),
    get: async () => ({ status: 0, body: null, text: '', headers: {} }),
    post: async () => ({ status: 0, body: null, text: '', headers: {} }),
    patch: async () => ({ status: 0, body: null, text: '', headers: {} }),
    del: async () => ({ status: 0, body: null, text: '', headers: {} }),
    reStepUp: async () => undefined,
    clearStepUp: async () => undefined,
    anonymous: async () => ({ status: 0, body: null, text: '', headers: {} }),
    close: async () => undefined,
  };

  async function call(method: string, url: string, body?: unknown) {
    const req = (request(app.getHttpServer()) as any)[method.toLowerCase()](url)
      .set('Host', ADMIN_HOST)
      // A real user agent: supertest sends none, and a test that asserts "the audit row records
      // the user agent" would otherwise be asserting a tautology about a fixture that sent nothing.
      .set('User-Agent', `Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) R4-${label}/1.0`)
      .set('Cookie', state.cookie)
      .set('x-csrf-token', csrfOf(state.cookie));
    const response: request.Response = body === undefined ? await req : await req.send(body as object);
    // Step-up rotates the session cookie by design, so adopt the fresh one.
    const fresh = jar(response);
    if (fresh.includes('flx_platform_token=')) state.cookie = fresh;
    // `text` as well as `body`: supertest parses JSON into body and leaves a text/csv response
    // as something String() renders "[object Object]", so a CSV assertion against body silently
    // compares one element instead of eleven columns. Found by the revenue export test.
    return { status: response.status, body: response.body, text: response.text, headers: response.headers };
  }

  state.call = call;
  state.get = (url) => call('GET', url);
  state.post = (url, body) => call('POST', url, body);
  state.patch = (url, body) => call('PATCH', url, body);
  state.del = (url, body) => call('DELETE', url, body);

  state.anonymous = async (method, url, body) => {
    const req = (request(app.getHttpServer()) as any)[method.toLowerCase()](url).set('Host', ADMIN_HOST);
    const response: request.Response = body === undefined ? await req : await req.send(body as object);
    return { status: response.status, body: response.body, text: response.text, headers: response.headers };
  };

  state.reStepUp = async () => {
    await prisma.platformAdmin.update({ where: { id: admin.id }, data: { totpLastUsedStep: null } });
    const response = await call('POST', `${API}/platform/auth/step-up`, {
      code: totpTokenAt(state.totpSecret),
    });
    if (response.status !== 200) {
      throw new Error(`step-up failed with ${response.status} while preparing the harness`);
    }
  };

  state.clearStepUp = async () => {
    await prisma.platformSession.updateMany({
      where: { adminId: admin.id, revokedAt: null },
      data: { stepUpAt: null, stepUpExpiresAt: null },
    });
  };

  state.close = async () => {
    await prisma.platformAlert.deleteMany({ where: { targetId: admin.id } }).catch(() => undefined);
    await prisma.platformSession.deleteMany({ where: { adminId: admin.id } }).catch(() => undefined);
    await prisma.platformRecoveryCode.deleteMany({ where: { adminId: admin.id } }).catch(() => undefined);
    // PHASE R3 decision A5.1: audit rows are NEVER deleted by a fixture. They are identified by
    // this administrator id and left in place, which is what an append-only log means.
    await prisma.platformAdmin.deleteMany({ where: { id: admin.id } }).catch(() => undefined);
    await app.close();
  };

  const login = await request(app.getHttpServer())
    .post(`${API}/platform/auth/login`)
    .set('Host', ADMIN_HOST)
    .send({ email, password });
  if (login.status !== 201) throw new Error(`login returned ${login.status}`);
  state.cookie = jar(login);

  const begin = await call('POST', `${API}/platform/auth/totp/enrol`);
  if (begin.status !== 200) throw new Error(`totp/enrol returned ${begin.status}`);
  state.totpSecret = begin.body.secret as string;

  const done = await call('POST', `${API}/platform/auth/totp/verify`, { code: totpTokenAt(state.totpSecret) });
  if (done.status !== 200) throw new Error(`totp/verify returned ${done.status}`);

  // The enrolment spent the current TOTP step and R1.1 refuses a reused step, so claim the next
  // one inside the +/-1 window rather than resetting anything: no part of the replay guard is
  // bypassed to get the harness started.
  const stepUp = await call('POST', `${API}/platform/auth/step-up`, {
    code: totpTokenAt(state.totpSecret, Date.now() + 30_000),
  });
  if (stepUp.status !== 200) throw new Error(`step-up returned ${stepUp.status}`);

  return state;
}

/** A disposable gym, for suites that need one. The caller owns cleanup. */
export async function makeGym(
  prisma: PrismaService,
  label: string,
  options: { status?: string; name?: string } = {},
): Promise<{ id: string; slug: string; name: string }> {
  const runId = `${label}-${Date.now().toString(36)}-${Math.floor(Math.random() * 1e6).toString(36)}`;
  const gym = await prisma.gym.create({
    data: {
      name: options.name ?? `R4 ${label} ${runId}`,
      slug: `r4-${runId}`,
      email: `r4-${runId}@test.local`,
      phone: '01000000006',
      status: (options.status ?? 'ACTIVE') as any,
    },
  });
  return { id: gym.id, slug: gym.slug, name: gym.name };
}

/**
 * PHASE R4 - the guard the owner asked for by name.
 *
 * Every jest suite in this repo connects as `flexora`, a SUPERUSER, and a superuser bypasses
 * row-level security outright. That is how a production defect survived two phases: the platform
 * subscription writes all failed with 42501 for the runtime role while every suite stayed green
 * (see r4-runtime-role-writes.spec.ts). The writes that route covers are the RLS-sensitive ones.
 *
 * This is the complement. A suite whose writes go only to tables with NO row-level security cannot
 * be passing because of the superuser connection - there is no policy for the superuser to bypass.
 * So each suite states which tables it writes and asserts that none of them is RLS-protected. If a
 * future change points one of them at a protected table, this fails and says which, instead of
 * silently becoming another test that only works as a superuser.
 *
 * It also asserts the negative half: Subscription IS protected, so the check is not vacuous. A
 * guard that would pass for any table name proves nothing.
 */
export async function assertWritesAreNotRlsProtected(
  prisma: { $queryRaw: (strings: TemplateStringsArray, ...values: unknown[]) => Promise<unknown> },
  tablesWritten: string[],
): Promise<void> {
  const rows = (await prisma.$queryRaw`
    SELECT c.relname::text AS name, c.relrowsecurity AS rls, c.relforcerowsecurity AS force
      FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
     WHERE n.nspname = 'public'`) as Array<{ name: string; rls: boolean; force: boolean }>;
  const byName = new Map(rows.map((row) => [row.name, row]));

  for (const table of tablesWritten) {
    const row = byName.get(table);
    if (!row) throw new Error(`assertWritesAreNotRlsProtected: no such table "${table}"`);
    if (row.rls || row.force) {
      throw new Error(
        `assertWritesAreNotRlsProtected: this suite writes "${table}", which HAS row-level security ` +
          `(rls=${row.rls} force=${row.force}). Its green result may therefore depend on connecting ` +
          'as a superuser, which production does not. Either route the write through a sanctioned ' +
          'SECURITY DEFINER function as platform_admin_set_subscription does, or add a runtime-role ' +
          'test like r4-runtime-role-writes.spec.ts.',
      );
    }
  }

  // The negative control: the check must be able to fail.
  const subscription = byName.get('Subscription');
  if (!subscription || (!subscription.rls && !subscription.force)) {
    throw new Error(
      'assertWritesAreNotRlsProtected: Subscription is expected to be RLS-protected, and it is not, ' +
        'so this guard would pass for any table name and proves nothing.',
    );
  }
}
