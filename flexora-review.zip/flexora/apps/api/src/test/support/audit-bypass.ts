/**
 * FLEXORA Gym OS — Backend API
 * (c) 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R3 — the ONLY sanctioned way to delete platform audit rows from a test fixture.
 *
 * WHY THIS EXISTS. Owner decision A1=a makes PlatformAuditLog append-only for EVERY role:
 * a BEFORE UPDATE / BEFORE DELETE trigger raises SQLSTATE 42501 even for the migration
 * owner. Measured in work/r3-evidence/02-migration-verified.log section A4, both as the
 * owner and as flexora_app. Two R2 fixtures cleaned up with
 * `prisma.platformAuditLog.deleteMany(...).catch(() => undefined)` - the catch meant they
 * kept passing while silently leaving every row they created behind, which is exactly the
 * kind of green that rule 0.4 forbids. They now call this.
 *
 * THE BYPASS IS THE DOCUMENTED ONE. A1=a names two: SET session_replication_role = replica,
 * or ALTER TABLE ... DISABLE TRIGGER. This uses the first, because it needs no DDL
 * privilege and it cannot leave a trigger disabled if the process dies mid-test - the
 * setting is session-local and inside a transaction that resets it.
 *
 * IT REFUSES TO RUN AS A NON-SUPERUSER. session_replication_role is itself superuser-only,
 * so a runtime-role caller would get a permission error anyway; checking first turns that
 * into a message that says what went wrong. This is the negative control for the whole
 * append-only claim: if a test could delete audit rows without being a superuser, the
 * protection would be worth nothing.
 *
 * NOT FOR PRODUCT CODE. Nothing under src/modules, src/config or prisma/ may import this
 * file, and the R3 evidence grep asserts that it does not.
 */
import type { PrismaClient, Prisma } from '@prisma/client';

export type AuditWhere = Prisma.PlatformAuditLogWhereInput;

export interface AuditBypassResult {
  deleted: number;
  roleWasSuperuser: boolean;
}

/**
 * Delete audit rows as a superuser, with user triggers disabled for the duration of one
 * transaction. Returns how many rows went, so a fixture can assert it actually cleaned up
 * instead of assuming.
 */
export interface AuditBypassOptions {
  /**
   * Take the transaction-scoped advisory lock that the chain-assign trigger takes before it
   * reads the head row. Without it, another writer can append between this transaction
   * reading the head and deleting above it, which would remove a row that is no longer the
   * tail and break the chain for everyone. Owner decision A5.2 and A6.2 both require it.
   */
  holdChainLock?: boolean;
}

export async function deleteAuditRowsBypass(
  prisma: PrismaClient,
  where: AuditWhere,
  options: AuditBypassOptions = {},
): Promise<AuditBypassResult> {
  const roles = await prisma.$queryRaw<Array<{ rolsuper: boolean }>>`
    SELECT rolsuper FROM pg_roles WHERE rolname = current_user`;
  const superuser = roles[0]?.rolsuper === true;
  if (!superuser) {
    throw new Error(
      'deleteAuditRowsBypass refuses to run: the connecting role is not a superuser, and ' +
        'PHASE R3 makes PlatformAuditLog append-only for every role. A fixture that needs to ' +
        'remove audit rows must connect with the database owner credential.',
    );
  }

  const deleted = await prisma.$transaction(async (tx) => {
    if (options.holdChainLock) {
      // Same key the trigger uses: hashtextextended('flexora.platform.audit.chain', 3).
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended('flexora.platform.audit.chain', 3))`;
    }
    await tx.$executeRaw`SET LOCAL session_replication_role = replica`;
    try {
      const result = await tx.platformAuditLog.deleteMany({ where });
      return result.count;
    } finally {
      await tx.$executeRaw`SET LOCAL session_replication_role = DEFAULT`;
    }
  });

  return { deleted, roleWasSuperuser: superuser };
}

/**
 * Tamper with one audit row inside a transaction that is ALWAYS rolled back, with user
 * triggers disabled, and return what the chain verifier said about it.
 *
 * This is how R3.5's tamper test runs in CI. It is not the whole of the A2.5 requirement -
 * the owner asked for the tamper to happen on a COPY of the database, and that copy-based
 * proof is work/r3-tamper-on-copy.sh, which creates a template copy, tampers there, drops
 * it, and never lets a superuser write to the live log even transiently. This spec-level
 * version complements it: it runs on every test pass, and the ROLLBACK is verified by
 * asserting the head hash is unchanged afterwards.
 */
export interface TamperResult {
  verify: Record<string, unknown>;
  headHashBefore: string | null;
  headHashAfter: string | null;
  rolledBack: boolean;
}

export async function tamperAndVerify(
  prisma: PrismaClient,
  tamperSql: string,
): Promise<TamperResult> {
  const before = await prisma.$queryRaw<Array<{ head_hash: string | null }>>`
    SELECT head_hash FROM public.platform_audit_verify()`;

  const verify = await prisma.$transaction(async (tx) => {
    await tx.$executeRaw`SET LOCAL session_replication_role = replica`;
    // executeRawUnsafe on purpose: this is a test-only helper and every caller passes a
    // literal string written in the spec. No product code may import this file.
    await tx.$executeRawUnsafe(tamperSql);
    const rows = await tx.$queryRaw<Array<Record<string, unknown>>>`
      SELECT rows_checked::integer      AS "rowsChecked",
             valid,
             broken_rows::integer        AS "brokenRows",
             first_broken_seq::integer   AS "firstBrokenSeq",
             first_broken_reason         AS "firstBrokenReason",
             head_seq::integer           AS "headSeq"
        FROM public.platform_audit_verify()`;
    // Deliberately no COMMIT: throwing rolls the tamper back.
    throw new RollbackSignal(rows[0] ?? {});
  }).catch((error: unknown) => {
    if (error instanceof RollbackSignal) return error.payload;
    throw error;
  });

  const after = await prisma.$queryRaw<Array<{ head_hash: string | null }>>`
    SELECT head_hash FROM public.platform_audit_verify()`;
  const headHashBefore = before[0]?.head_hash ?? null;
  const headHashAfter = after[0]?.head_hash ?? null;

  return {
    verify: verify as Record<string, unknown>,
    headHashBefore,
    headHashAfter,
    // The rollback is itself asserted, not assumed: if the tamper had escaped the
    // transaction the head digest would have moved.
    rolledBack: headHashBefore === headHashAfter,
  };
}

/**
 * The same sanctioned bypass, for a caller that already holds a transaction - and, per owner
 * decision A5.2, already holds the chain advisory lock.
 *
 * It exists for exactly one situation: the negative control in r3-audit-chain.spec.ts has to
 * CREATE a row and DELETE it inside a single lock-holding transaction, because only then is
 * the row it removes provably the tail and the chain left valid. deleteAuditRowsBypass opens
 * its own transaction, so it cannot be nested (and calling the root client inside a
 * transaction is forbidden in this codebase anyway).
 *
 * The caller is responsible for the lock. This does the superuser-only refusal itself, so it
 * cannot be reached from a runtime-role connection.
 */
export async function deleteAuditRowsInTransaction(
  tx: Prisma.TransactionClient,
  where: AuditWhere,
): Promise<number> {
  const roles = await tx.$queryRaw<Array<{ rolsuper: boolean }>>`
    SELECT rolsuper FROM pg_roles WHERE rolname = current_user`;
  if (roles[0]?.rolsuper !== true) {
    throw new Error(
      'deleteAuditRowsInTransaction refuses to run: the connecting role is not a superuser.',
    );
  }
  await tx.$executeRaw`SET LOCAL session_replication_role = replica`;
  try {
    const result = await tx.platformAuditLog.deleteMany({ where });
    return result.count;
  } finally {
    await tx.$executeRaw`SET LOCAL session_replication_role = DEFAULT`;
  }
}

/** The lock the chain-assign trigger takes, so callers and the trigger cannot interleave. */
export const CHAIN_LOCK_SQL =
  "SELECT pg_advisory_xact_lock(hashtextextended('flexora.platform.audit.chain', 3))";

export interface ChainTrimReport {
  repaired: boolean;
  reason: string;
  firstMissingSeq: number | null;
  removedSeqs: number[];
  rowsBefore: number;
  rowsAfter: number;
  lastValidSeq: number | null;
  lastValidHash: string | null;
  belowGapCountBefore: number;
  belowGapChecksumBefore: string | null;
  belowGapCountAfter: number;
  belowGapChecksumAfter: string | null;
  belowGapUnchanged: boolean;
  verifyAfter: Record<string, unknown>;
  probeSeq: number | null;
}

/**
 * PHASE R3, owner decision A6 - repair a chain that a sanctioned deletion broke, by removing
 * every row at or above the first gap.
 *
 * WHY THIS SHAPE. Deleting a row from the middle of a hash chain invalidates its successor's
 * link, and there is no honest way to "fix" the survivor short of rewriting history, which is
 * the thing the chain exists to prevent. So the repair does not rewrite anything: it accepts
 * that the rows above the gap can no longer be trusted to link, removes them, and leaves a
 * valid shorter chain. Everything below the gap is asserted byte-identical by count AND by a
 * checksum of the stored columns, inside the same transaction, and a mismatch throws so the
 * transaction rolls back and nothing is removed at all.
 *
 * The chain advisory lock is taken first (A6.2), which is the lock the insert trigger itself
 * takes, so no writer can append between reading the head and deleting above it and turn the
 * intended tail-trim into a mid-chain deletion.
 *
 * This is a repair after an accident, not a maintenance routine. With decision A5 in force no
 * fixture deletes audit rows any more, so nothing should ever need to call it again.
 */
export type AuditDb = PrismaClient | Prisma.TransactionClient;

/** Run fn in the caller's transaction if one was passed, otherwise open one. */
async function inTransaction<T>(
  db: AuditDb,
  fn: (tx: Prisma.TransactionClient) => Promise<T>,
): Promise<T> {
  if ('$transaction' in db) return (db as PrismaClient).$transaction(fn);
  return fn(db as Prisma.TransactionClient);
}

export async function trimChainFromFirstGap(
  db: AuditDb,
  options: { dryRun?: boolean } = {},
): Promise<ChainTrimReport> {
  const readVerify = async () => {
    const rows = await db.$queryRaw<
      Array<{
        rows_checked: number; valid: boolean; broken_rows: number;
        first_broken_seq: number | null; head_seq: number | null; head_hash: string | null;
      }>
    >`SELECT rows_checked::integer, valid, broken_rows::integer, first_broken_seq::integer,
             head_seq::integer, head_hash
        FROM public.platform_audit_verify()`;
    return rows[0];
  };

  const before = await readVerify();
  const rowsBefore = await db.platformAuditLog.count();

  if (before.valid) {
    return {
      repaired: false,
      reason: 'the chain already verifies; nothing was removed',
      firstMissingSeq: null, removedSeqs: [], rowsBefore, rowsAfter: rowsBefore,
      lastValidSeq: before.head_seq, lastValidHash: before.head_hash,
      belowGapCountBefore: rowsBefore, belowGapChecksumBefore: null,
      belowGapCountAfter: rowsBefore, belowGapChecksumAfter: null,
      belowGapUnchanged: true,
      verifyAfter: before as unknown as Record<string, unknown>,
      probeSeq: null,
    };
  }

  // The first seq in 1..head that has no row. Everything at or above it is untrustworthy.
  const gapRows = await db.$queryRaw<Array<{ first_missing: number | null }>>`
    SELECT min(g)::integer AS first_missing
      FROM generate_series(1, coalesce((SELECT max(seq) FROM public."PlatformAuditLog"), 0)) g
     WHERE NOT EXISTS (SELECT 1 FROM public."PlatformAuditLog" a WHERE a.seq = g)`;
  const firstMissingSeq = gapRows[0]?.first_missing ?? null;
  if (firstMissingSeq === null) {
    throw new Error(
      'the chain reports invalid but there is no gap in the seq numbering, so this is a ' +
        'content or link fault rather than a deletion. Refusing to remove anything: trimming ' +
        'would destroy evidence and would not repair a hash mismatch.',
    );
  }

  const doomed = await db.$queryRaw<Array<{ seq: number }>>`
    SELECT seq::integer FROM public."PlatformAuditLog" WHERE seq >= ${firstMissingSeq} ORDER BY seq`;
  const removedSeqs = doomed.map((row) => row.seq);
  const lastValid = await db.$queryRaw<Array<{ seq: number | null; hash: string | null }>>`
    SELECT seq::integer, hash FROM public."PlatformAuditLog"
     WHERE seq < ${firstMissingSeq} ORDER BY seq DESC LIMIT 1`;

  const checksumBelow = async (client: AuditDb) => {
    const rows = await client.$queryRaw<Array<{ n: number; checksum: string | null }>>`
      SELECT count(*)::integer AS n,
             md5(coalesce(string_agg(
               a.seq::text || '|' || a.id || '|' || a."adminId" || '|' || a."adminName" || '|' ||
               a.action || '|' || coalesce(a.target, '') || '|' || coalesce(a.details::text, '') || '|' ||
               coalesce(a.reason, '') || '|' || coalesce(a.ip, '') || '|' || coalesce(a."userAgent", '') || '|' ||
               a."stepUpUsed"::text || '|' || coalesce(a.hash, '') || '|' || coalesce(a."prevHash", '') || '|' ||
               to_char(a."createdAt" at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS.MS'),
               ';' ORDER BY a.seq), '')) AS checksum
        FROM public."PlatformAuditLog" a
       WHERE a.seq < ${firstMissingSeq}`;
    return rows[0];
  };

  const belowBefore = await checksumBelow(db);

  if (options.dryRun) {
    return {
      repaired: false,
      reason: `dry run: ${removedSeqs.length} row(s) at or above seq ${firstMissingSeq} would be removed`,
      firstMissingSeq,
      removedSeqs,
      rowsBefore,
      rowsAfter: rowsBefore,
      lastValidSeq: lastValid[0]?.seq ?? null,
      lastValidHash: lastValid[0]?.hash ?? null,
      belowGapCountBefore: belowBefore.n,
      belowGapChecksumBefore: belowBefore.checksum,
      belowGapCountAfter: belowBefore.n,
      belowGapChecksumAfter: belowBefore.checksum,
      belowGapUnchanged: true,
      verifyAfter: before as unknown as Record<string, unknown>,
      probeSeq: null,
    };
  }

  const outcome = await inTransaction(db, async (tx) => {
    // A6.2 - the same lock the chain-assign trigger takes, before anything is read or removed.
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtextextended('flexora.platform.audit.chain', 3))`;
    await tx.$executeRaw`SET LOCAL session_replication_role = replica`;
    const result = await tx.platformAuditLog.deleteMany({ where: { seq: { gte: firstMissingSeq } } });
    await tx.$executeRaw`SET LOCAL session_replication_role = DEFAULT`;

    // A6.3 - the rows below the gap must be byte-identical, or nothing is removed at all.
    const belowAfter = await checksumBelow(tx);
    if (belowAfter.n !== belowBefore.n || belowAfter.checksum !== belowBefore.checksum) {
      throw new RollbackSignal({
        belowAfter,
        deleted: result.count,
      } as unknown as Record<string, unknown>);
    }
    return { deleted: result.count, belowAfter };
  }).catch((error: unknown) => {
    if (error instanceof RollbackSignal) return { rolledBack: true, ...error.payload } as never;
    throw error;
  }) as { deleted: number; belowAfter: { n: number; checksum: string | null }; rolledBack?: boolean };

  if (outcome.rolledBack) {
    throw new Error(
      'the repair rolled itself back: the rows below the gap changed while it was running ' +
        `(count ${belowBefore.n} -> ${(outcome as never as { belowAfter: { n: number } }).belowAfter.n}). ` +
        'Nothing was removed. Investigate before trying again.',
    );
  }

  const after = await readVerify();
  const rowsAfter = await db.platformAuditLog.count();

  // A6.4 - prove the numbering continues gaplessly: the next insert must take max(seq)+1.
  // rowsAfter is counted BEFORE this insert, so a gapless chain means probeSeq === rowsAfter+1.
  // The probe row is LEFT IN PLACE, because decision A5 means nothing deletes audit rows.
  const probe = await db.platformAuditLog.create({
    data: {
      adminId: 'chain-repair-probe',
      adminName: 'PHASE R3 chain repair',
      action: 'platform:chain-repair-probe',
      target: null,
      details: { removedSeqs, firstMissingSeq } as object,
      reason: 'probe row: confirms seq continues gaplessly after the A6 repair',
    },
    select: { seq: true },
  });

  return {
    repaired: true,
    reason: `removed ${removedSeqs.length} row(s) at or above the first gap`,
    firstMissingSeq,
    removedSeqs,
    rowsBefore,
    rowsAfter,
    lastValidSeq: lastValid[0]?.seq ?? null,
    lastValidHash: lastValid[0]?.hash ?? null,
    belowGapCountBefore: belowBefore.n,
    belowGapChecksumBefore: belowBefore.checksum,
    belowGapCountAfter: outcome.belowAfter.n,
    belowGapChecksumAfter: outcome.belowAfter.checksum,
    belowGapUnchanged:
      belowBefore.n === outcome.belowAfter.n && belowBefore.checksum === outcome.belowAfter.checksum,
    verifyAfter: after as unknown as Record<string, unknown>,
    probeSeq: probe.seq,
  };
}

class RollbackSignal extends Error {
  constructor(readonly payload: Record<string, unknown>) {
    super('rollback');
  }
}
