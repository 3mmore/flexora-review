/**
 * FLEXORA Gym OS — shared harness for TENANT-side integration specs (Phase A/B).
 *
 * Boots the REAL AppModule the way main.ts does (global `api` prefix,
 * cookie-parser, the same ValidationPipe options) so a route that would 400 in
 * production cannot pass in a test, and gives every spec the same fixtures:
 * two gyms, an owner per gym, staff roles, a licence/subscription so
 * feature-gated controllers are reachable, and a SECOND PrismaClient connected
 * as the runtime role `flexora_app` (NOSUPERUSER NOBYPASSRLS).
 *
 * The runtime client exists because this project already learned the hard way
 * that jest runs as a superuser and therefore bypasses FORCE RLS: a green suite
 * on the owner connection says nothing about what the app can actually read.
 * `assertRuntimeRole()` re-proves the role's attributes in every spec that uses
 * it, so a misconfigured environment fails loudly instead of silently testing
 * the wrong thing.
 */
import { INestApplication, ValidationPipe } from '@nestjs/common';
import { Test, TestingModule } from '@nestjs/testing';
import request from 'supertest';
import cookieParser from 'cookie-parser';
import { randomBytes } from 'crypto';
import * as argon2 from 'argon2';

import { AppModule } from '../../app.module';
import { PrismaService } from '../../config/prisma.service';
import { BruteForceService } from '../../common/security/brute-force.service';
import { PASSWORD_HASH_OPTIONS } from '../../config/password-hash';
import { PrismaClient } from '@prisma/client';

export const API = '/api';
export const FIXTURE_PASSWORD = ['Tenant', 'Spec', 'Password', '1'].join('-');

export interface FixtureUser {
  id: string;
  name: string;
  email: string;
  role: string;
  branchId: string | null;
}

export interface GymFixture {
  gymId: string;
  branchId: string;
  secondBranchId: string;
  planId: string;
  owner: FixtureUser;
  manager: FixtureUser;
  receptionist: FixtureUser;
  coach: FixtureUser;
  accountant: FixtureUser;
}

export interface TenantHarness {
  app: INestApplication;
  prisma: PrismaService;
  /** connected as flexora_app — NO tenant context, NO superuser */
  runtime: PrismaClient;
  gymA: GymFixture;
  gymB: GymFixture;
  agent: (email: string, password?: string) => Promise<TenantSession>;
  close: () => Promise<void>;
}

export interface TenantSession {
  /** cookie-carrying supertest agent with the CSRF header wired up */
  agent: ReturnType<typeof request.agent>;
  user: FixtureUser;
  get: (path: string) => request.Test;
  post: (path: string, body?: unknown) => request.Test;
  patch: (path: string, body?: unknown) => request.Test;
  del: (path: string) => request.Test;
  csrf: string;
}

const RUNTIME_ROLE = 'flexora_app';

/** Build a connection URL for the runtime role from the owner URL + its password. */
export function runtimeUrlFrom(ownerUrl: string | undefined, password: string | undefined): string | null {
  if (!ownerUrl || !password) return null;
  try {
    const url = new URL(ownerUrl);
    url.username = RUNTIME_ROLE;
    url.password = password;
    url.searchParams.set('connection_limit', '1');
    return url.toString();
  } catch {
    return null;
  }
}

export function runtimeRolePassword(): string | undefined {
  return process.env.FLEXORA_APP_TEST_PASSWORD;
}

/**
 * Prove — on a real connection — that the runtime client is the least-privilege
 * role and that FORCE RLS hides tenant rows when no tenant is set.
 */
export async function assertRuntimeRole(runtime: PrismaClient, tenantTable = 'OwnerNotification'): Promise<void> {
  const who = await runtime.$queryRawUnsafe<Array<{ u: string; s: boolean; b: boolean }>>(
    `SELECT current_user AS u,
            (SELECT rolsuper FROM pg_roles WHERE rolname = current_user) AS s,
            (SELECT rolbypassrls FROM pg_roles WHERE rolname = current_user) AS b`,
  );
  expect(who[0].u).toBe(RUNTIME_ROLE);
  expect(who[0].s).toBe(false);
  expect(who[0].b).toBe(false);
  const rows = await runtime.$queryRawUnsafe<Array<{ n: string }>>(
    `SELECT COUNT(*)::text AS n FROM public."${tenantTable}"`,
  );
  expect(Number(rows[0].n)).toBe(0);
}

/**
 * Boot a SECOND application whose PrismaClient connects as `flexora_app`.
 *
 * Why this exists: jest itself runs with the OWNER url, so every integration
 * spec in this project silently tests RLS tables as a superuser — a `$queryRaw`
 * that forgets `set_config('app.gym_id')` returns rows in the test and ZERO rows
 * in production. FEATURE B shipped exactly that bug and the live smoke caught
 * it. This helper makes the "production role" path testable.
 *
 * `process.env.DATABASE_URL` is swapped only while the module is constructed
 * (PrismaService reads it in its constructor) and restored immediately after.
 */
export async function startRuntimeApp(): Promise<{ app: INestApplication; agent: (email: string, password?: string) => Promise<TenantSession>; close: () => Promise<void> }> {
  const runtimeUrl = runtimeUrlFrom(process.env.DATABASE_URL, runtimeRolePassword());
  if (!runtimeUrl) throw new Error('FLEXORA_APP_TEST_PASSWORD is required for the runtime-role app');
  const previous = process.env.DATABASE_URL;
  let moduleFixture: TestingModule;
  try {
    process.env.DATABASE_URL = runtimeUrl;
    moduleFixture = await Test.createTestingModule({ imports: [AppModule] }).compile();
  } finally {
    process.env.DATABASE_URL = previous;
  }
  const app = moduleFixture.createNestApplication();
  app.setGlobalPrefix('api');
  app.use(cookieParser());
  app.useGlobalPipes(new ValidationPipe({ transform: true, whitelist: true, forbidNonWhitelisted: true }));
  await app.init();
  const bruteForce = app.get(BruteForceService);

  const agent = async (email: string, password = FIXTURE_PASSWORD): Promise<TenantSession> => {
    await bruteForce.reset('ip:::ffff:127.0.0.1');
    await bruteForce.reset('ip:127.0.0.1');
    const a = request.agent(app.getHttpServer());
    const first = await a.get(`${API}/health/live`).expect(200);
    const csrf = readCookie(first.headers['set-cookie'], '_csrf') || '';
    const login = await a.post(`${API}/auth/login`).send({ email, password }).expect(201);
    const csrfAfter = readCookie(login.headers['set-cookie'], '_csrf') || csrf;
    const user = (login.body as { user?: FixtureUser }).user as FixtureUser;
    if (!user) throw new Error(`login for ${email} returned no user`);
    const withCsrf = (t: request.Test) => t.set('X-CSRF-Token', csrfAfter).set('Origin', 'http://localhost:3000');
    return {
      agent: a,
      user,
      csrf: csrfAfter,
      get: (p: string) => a.get(`${API}${p}`),
      post: (p: string, body?: unknown) => withCsrf(a.post(`${API}${p}`).send(body ?? {})),
      patch: (p: string, body?: unknown) => withCsrf(a.patch(`${API}${p}`).send(body ?? {})),
      del: (p: string) => withCsrf(a.delete(`${API}${p}`)),
    };
  };

  return { app, agent, close: async () => { await app.close(); } };
}

export async function startTenantHarness(label: string): Promise<TenantHarness> {
  process.env.IMPORT_UPLOAD_DIR = process.env.IMPORT_UPLOAD_DIR || '/tmp/flexora/imports';
  process.env.BACKUP_DIR = process.env.BACKUP_DIR || '/tmp/flexora/backups';
  process.env.CONTRACT_PDF_DIR = process.env.CONTRACT_PDF_DIR || '/tmp/flexora/contracts';

  const moduleFixture: TestingModule = await Test.createTestingModule({ imports: [AppModule] }).compile();
  const app = moduleFixture.createNestApplication();
  app.setGlobalPrefix('api');
  app.use(cookieParser());
  app.useGlobalPipes(new ValidationPipe({ transform: true, whitelist: true, forbidNonWhitelisted: true }));
  await app.init();
  const prisma = app.get(PrismaService);
  const bruteForce = app.get(BruteForceService);

  const ownerUrl = process.env.DATABASE_URL;
  const runtimeUrl = runtimeUrlFrom(ownerUrl, runtimeRolePassword());
  if (!runtimeUrl) {
    throw new Error(
      'FLEXORA_APP_TEST_PASSWORD is required: these specs must be able to prove behaviour as the runtime role.',
    );
  }
  const runtime = new PrismaClient({ datasources: { db: { url: runtimeUrl } } });
  await runtime.$connect();

  const makeGym = async (suffix: string): Promise<GymFixture> => {
    const slug = `${label}-${suffix}-${Date.now().toString(36)}-${randomBytes(2).toString('hex')}`;
    const gym = await prisma.gym.create({
      data: { name: `Harness ${suffix}`, slug, email: `${slug}@harness.test`, phone: '01000000000', status: 'ACTIVE' },
    });
    const branch = await prisma.branch.create({ data: { gymId: gym.id, name: `Main ${suffix}` } });
    const secondBranch = await prisma.branch.create({ data: { gymId: gym.id, name: `Second ${suffix}` } });
    const plan = await prisma.plan.create({
      data: { gymId: gym.id, name: `Plan ${suffix}`, type: 'TIME', days: 30, price: 500 },
    });
    // A real gym has these; feature-gated controllers 403 without them.
    await prisma.license.create({
      data: { gymId: gym.id, key: `FLEX-HARNESS-${randomBytes(4).toString('hex').toUpperCase()}`, status: 'ACTIVE', expiresAt: new Date(Date.now() + 365 * 86400000) },
    });
    await prisma.subscription.create({
      data: { gymId: gym.id, tier: 'PRO', status: 'ACTIVE', currentPeriodEnd: new Date(Date.now() + 365 * 86400000) },
    });

    const passwordHash = await argon2.hash(FIXTURE_PASSWORD, PASSWORD_HASH_OPTIONS);
    const mk = async (name: string, role: string, branchId: string | null): Promise<FixtureUser> => {
      const email = `${role.toLowerCase()}-${suffix}-${randomBytes(3).toString('hex')}@harness.test`;
      const user = await prisma.user.create({
        data: { gymId: gym.id, branchId, name, email, passwordHash, role: role as never, onboardingCompleted: true },
      });
      return { id: user.id, name: user.name, email: user.email, role: user.role, branchId: user.branchId };
    };
    return {
      gymId: gym.id,
      branchId: branch.id,
      secondBranchId: secondBranch.id,
      planId: plan.id,
      owner: await mk(`Owner ${suffix} Person`, 'OWNER', branch.id),
      manager: await mk(`Manager ${suffix} Person`, 'MANAGER', branch.id),
      receptionist: await mk(`Reception ${suffix} Person`, 'RECEPTION', branch.id),
      coach: await mk(`Coach ${suffix} Person`, 'COACH', branch.id),
      accountant: await mk(`Accountant ${suffix} Person`, 'ACCOUNTANT', branch.id),
    };
  };

  const gymA = await makeGym('a');
  const gymB = await makeGym('b');

  const agent = async (email: string, password = FIXTURE_PASSWORD): Promise<TenantSession> => {
    // The brute-force guard locks an IP after a few attempts; every spec that
    // logs in more than three times must clear its own key first (the same
    // pattern flexora-critical-flows.spec.ts documents).
    await bruteForce.reset('ip:::ffff:127.0.0.1');
    await bruteForce.reset('ip:127.0.0.1');
    const a = request.agent(app.getHttpServer());
    // A GET first: the CSRF middleware issues the `_csrf` cookie on any
    // non-exempt GET, and every non-GET below sends it back as a header.
    const first = await a.get(`${API}/health/live`).expect(200);
    const csrf = readCookie(first.headers['set-cookie'], '_csrf') || '';
    const login = await a.post(`${API}/auth/login`).send({ email, password }).expect(201);
    const csrfAfter = readCookie(login.headers['set-cookie'], '_csrf') || csrf;
    const user = (login.body as { user?: FixtureUser }).user as FixtureUser;
    if (!user) throw new Error(`login for ${email} returned no user`);
    const withCsrf = (t: request.Test) => t.set('X-CSRF-Token', csrfAfter).set('Origin', 'http://localhost:3000');
    return {
      agent: a,
      user,
      csrf: csrfAfter,
      get: (p: string) => a.get(`${API}${p}`),
      post: (p: string, body?: unknown) => withCsrf(a.post(`${API}${p}`).send(body ?? {})),
      patch: (p: string, body?: unknown) => withCsrf(a.patch(`${API}${p}`).send(body ?? {})),
      del: (p: string) => withCsrf(a.delete(`${API}${p}`)),
    };
  };

  /**
   * Tear down and LEAVE NO TRACE.
   *
   * Measured, both directions:
   *   * a fixture gym left ACTIVE moves r4-gyms-list.spec.ts's own rows off
   *     page 1 (that spec paginates the platform list at 25; ~80 leftovers made it
   *     fail with "expected >= 5, received 4");
   *   * a fixture gym left DELETED breaks r1-platform-auth.spec.ts 7b/7c, because
   *     platform_count_members() deliberately excludes members of DELETED gyms
   *     while that spec's "truth" counts every Member row — so the oracle only
   *     holds when no deleted gyms exist.
   *
   * Deleting the Gym row cascades to everything these fixtures created (members,
   * sales, refunds, sessions, bookings, targets, audit rows — verified by a
   * transactional delete of a fixture gym with 8 members). If the delete ever
   * fails, the gym is retired as DELETED and a loud warning is printed instead of
   * silently polluting later suites.
   */
  const close = async () => {
    await runtime.$disconnect().catch(() => undefined);
    for (const gym of [gymA, gymB]) {
      try {
        await prisma.gym.delete({ where: { id: gym.gymId } });
      } catch (e) {
        console.warn(
          `[tenant-app-harness] could not delete fixture gym ${gym.gymId} (${(e as Error)?.message}); marking it DELETED instead. Later platform-wide specs may see it.`,
        );
        await prisma.gym
          .update({ where: { id: gym.gymId }, data: { status: 'DELETED', deletedAt: new Date() } })
          .catch(() => undefined);
      }
    }
    await app.close();
  };

  return { app, prisma, runtime, gymA, gymB, agent, close };
}

function readCookie(setCookie: string | string[] | undefined, name: string): string | null {
  const list = Array.isArray(setCookie) ? setCookie : setCookie ? [setCookie] : [];
  for (const raw of list) {
    const pair = raw.split(';')[0] || '';
    const idx = pair.indexOf('=');
    if (idx > 0 && pair.slice(0, idx).trim() === name) return decodeURIComponent(pair.slice(idx + 1));
  }
  return null;
}

/** Small helper: ISO date N days from now (UTC). */
export function daysAgo(n: number, hourUtc = 12): Date {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() - n);
  d.setUTCHours(hourUtc, 0, 0, 0);
  return d;
}

/** The period key ("YYYY-MM") of a date, as the targets table stores it. */
export function monthKeyOf(d: Date): string {
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`;
}
