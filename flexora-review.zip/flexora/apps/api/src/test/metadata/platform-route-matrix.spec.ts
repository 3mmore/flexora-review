/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1 — the platform route matrix, derived from METADATA.
 *
 * Review item 4 asks for a test that fails if any @PlatformRoute() controller lacks
 * CSRF coverage; R1.5 asks for step-up on the sensitive actions; R1.1/review item 3
 * asks that an unenrolled administrator can reach nothing except enrolment. All
 * three are properties of the whole route set, so all three are asserted by
 * ENUMERATING the controllers through the same Reflect metadata Nest uses - never by
 * listing URLs, which is how a new endpoint quietly escapes a rule.
 *
 * Every expectation below is a security property. If you add a console endpoint and
 * this file fails, that is the file working.
 */
import 'reflect-metadata';
import { PATH_METADATA, METHOD_METADATA } from '@nestjs/common/constants';
import { RequestMethod } from '@nestjs/common';
import { IS_PLATFORM_ROUTE_KEY } from '../../common/decorators/platform-route.decorator';
import {
  ALLOWED_BEFORE_TOTP_KEY,
  PLATFORM_CSRF_EXEMPT_KEY,
  REQUIRE_STEP_UP_KEY,
} from '../../common/decorators/platform-auth.decorators';
import { IS_PUBLIC_KEY } from '../../common/decorators/public.decorator';
import { PlatformController } from '../../modules/platform/platform.controller';
import { PlatformAuthController } from '../../modules/platform-auth/platform-auth.controller';
import { PlatformCsrfGuard } from '../../common/guards/platform-csrf.guard';
import { PlatformSessionGuard } from '../../common/guards/platform-session.guard';
import { PlatformStepUpGuard } from '../../common/guards/platform-step-up.guard';
import { PlatformTotpEnrolmentGuard } from '../../common/guards/platform-totp-enrolment.guard';

// Nest stores RequestMethod enum values in METHOD_METADATA (GET=0, POST=1, PUT=2,
// DELETE=3, PATCH=4, ...). Reading the enum by name is the only way to be sure this
// file agrees with Nest; a hand-written list silently mislabels every route, which
// is how a matrix test passes while proving nothing.
const HTTP_METHODS = Object.keys(RequestMethod).filter((key) => Number.isNaN(Number(key)));
/** The methods that change state and therefore need both step-up and CSRF. */
const UNSAFE_METHODS = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);

interface RouteInfo {
  controller: string;
  handler: string;
  method: string;
  path: string;
  isPlatformRoute: boolean;
  isPublic: boolean;
  stepUpReason: string | undefined;
  allowedBeforeTotp: string | undefined;
  csrfExemptReason: string | undefined;
}

function readMetadata(target: unknown, key: string): unknown {
  const fromHandler = Reflect.getMetadata(key, target as object);
  return fromHandler;
}

function enumerate(controllerClass: unknown): RouteInfo[] {
  const prototype = (controllerClass as { prototype: Record<string, unknown> }).prototype;
  const controllerPath = String(readMetadata(controllerClass, PATH_METADATA) ?? '');
  const controllerIsPlatform = readMetadata(controllerClass, IS_PLATFORM_ROUTE_KEY) === true;
  const controllerIsPublic = readMetadata(controllerClass, IS_PUBLIC_KEY) === true;
  const routes: RouteInfo[] = [];

  for (const name of Object.getOwnPropertyNames(prototype)) {
    if (name === 'constructor') continue;
    const descriptor = Object.getOwnPropertyDescriptor(prototype, name);
    if (!descriptor || typeof descriptor.value !== 'function') continue;
    const handler = descriptor.value;
    const routePath = readMetadata(handler, PATH_METADATA);
    if (routePath === undefined) continue; // not an HTTP handler
    const methodIndex = readMetadata(handler, METHOD_METADATA);
    const method = RequestMethod[Number(methodIndex)] ?? 'ALL';
    routes.push({
      controller: (controllerClass as { name: string }).name,
      handler: name,
      method,
      path: `/${controllerPath}/${String(routePath)}`.replace(/\/{2,}/g, '/'),
      isPlatformRoute: controllerIsPlatform || readMetadata(handler, IS_PLATFORM_ROUTE_KEY) === true,
      isPublic: controllerIsPublic || readMetadata(handler, IS_PUBLIC_KEY) === true,
      stepUpReason: (readMetadata(handler, REQUIRE_STEP_UP_KEY) ?? readMetadata(controllerClass, REQUIRE_STEP_UP_KEY)) as string | undefined,
      allowedBeforeTotp: (readMetadata(handler, ALLOWED_BEFORE_TOTP_KEY) ?? readMetadata(controllerClass, ALLOWED_BEFORE_TOTP_KEY)) as string | undefined,
      csrfExemptReason: (readMetadata(handler, PLATFORM_CSRF_EXEMPT_KEY) ?? readMetadata(controllerClass, PLATFORM_CSRF_EXEMPT_KEY)) as string | undefined,
    });
  }
  return routes;
}

const PLATFORM_CONTROLLERS = [PlatformController, PlatformAuthController];
const ALL_ROUTES = PLATFORM_CONTROLLERS.flatMap(enumerate);

/**
 * State-changing routes that legitimately do NOT need a step-up assertion, each with
 * the reason it is on this list. A test that silently accepted an unmarked mutation
 * would be worthless, so the allow-list is explicit and any addition has to be
 * justified here in writing.
 */
const STEP_UP_EXEMPT: Record<string, string> = {
  'PlatformAuthController.login': 'pre-authentication: there is no session to assert into, and the account lockouts plus BruteForceGuard cover it',
  'PlatformAuthController.logout': 'revoking your own session must always be possible, including while locked out of a second factor',
  'PlatformAuthController.beginTotpEnrolment': 'part of first-login enrolment, which happens before any second factor exists',
  'PlatformAuthController.completeTotpEnrolment': 'the code presented here IS the proof of possession; a step-up would need the factor being created',
  'PlatformAuthController.stepUp': 'this route is what creates the assertion',
  'PlatformAuthController.cspReport': 'a browser posts CSP violations without credentials; it is public and throttled',
};

/** Routes reachable before TOTP enrolment, with why. Anything else must be refused. */
const EXPECTED_ALLOWED_BEFORE_TOTP = [
  'PlatformAuthController.me',
  'PlatformAuthController.logout',
  'PlatformAuthController.beginTotpEnrolment',
  'PlatformAuthController.completeTotpEnrolment',
];

/** Routes exempt from the double-submit token, with why. */
const EXPECTED_CSRF_EXEMPT = ['PlatformAuthController.login', 'PlatformAuthController.cspReport'];

describe('R1 platform route matrix — 1. enumeration sanity', () => {
  it('1a. both platform controllers were enumerated and yield the known route count', () => {
    expect(ALL_ROUTES.length).toBeGreaterThanOrEqual(27);
    expect(new Set(ALL_ROUTES.map((route) => route.controller)).size).toBe(2);
  });

  it('1b. EVERY route in a platform controller carries the @PlatformRoute marker', () => {
    // This is what puts the whole controller behind the R0 host gate, the R1
    // credential guard, the enrolment gate, the step-up gate and the CSRF guard.
    const unmarked = ALL_ROUTES.filter((route) => !route.isPlatformRoute);
    expect(unmarked.map((route) => `${route.controller}.${route.handler}`)).toEqual([]);
  });

  it('1c. no duplicate handler names hide a route from the checks below', () => {
    const keys = ALL_ROUTES.map((route) => `${route.controller}.${route.handler}`);
    expect(new Set(keys).size).toBe(keys.length);
  });
});

describe('R1 platform route matrix — 2. R1.5 step-up on every sensitive action', () => {
  const mutations = ALL_ROUTES.filter((route) => UNSAFE_METHODS.has(route.method));

  it('2a. every state-changing platform route either requires step-up or is justified here', () => {
    const unjustified = mutations
      .filter((route) => !route.stepUpReason)
      .map((route) => `${route.controller}.${route.handler} (${route.method} ${route.path})`)
      .filter((label) => !Object.keys(STEP_UP_EXEMPT).some((exempt) => label.startsWith(exempt)));
    expect(unjustified).toEqual([]);
  });

  it('2b. the allow-list contains no stale entries (every name still exists)', () => {
    const present = new Set(mutations.map((route) => `${route.controller}.${route.handler}`));
    const stale = Object.keys(STEP_UP_EXEMPT).filter((name) => !present.has(name));
    expect(stale).toEqual([]);
  });

  it('2c. the eleven actions the brief names are all marked', () => {
    const required = [
      'setFlag',
      'manualBlock',
      'unblockIp',
      'updatePlan',
      'suspendGym',
      'reactivateGym',
      'deleteGym',
      'extendTrial',
      'grantSubscription',
      'createAdmin',
      'removeAdmin',
    ];
    const marked = ALL_ROUTES.filter((route) => Boolean(route.stepUpReason)).map((route) => route.handler);
    for (const handler of required) expect(marked).toContain(handler);
  });

  it('2d. change-password and recovery-code regeneration require step-up too', () => {
    for (const handler of ['changePassword', 'regenerateRecoveryCodes', 'approveAdmin']) {
      const route = ALL_ROUTES.find((candidate) => candidate.handler === handler);
      expect(route?.stepUpReason).toBeTruthy();
    }
  });

  it('2e. every step-up marker carries a human reason, not a bare true', () => {
    const reasons = ALL_ROUTES.filter((route) => route.stepUpReason !== undefined).map((route) => route.stepUpReason);
    expect(reasons.length).toBeGreaterThanOrEqual(14);
    expect(reasons.every((reason) => typeof reason === 'string' && reason.length > 8)).toBe(true);
  });
});

describe('R1 platform route matrix — 3. review item 4: CSRF coverage by metadata', () => {
  it('3a. every platform controller is covered by the metadata-driven CSRF guard', () => {
    // The guard is global and selects by @PlatformRoute, so coverage is a property
    // of the marker plus the registration. Both are asserted here.
    const source = require('fs').readFileSync(`${__dirname}/../../app.module.ts`, 'utf8');
    expect(source).toMatch(/APP_GUARD,\s*useClass:\s*PlatformCsrfGuard/);
    for (const controller of PLATFORM_CONTROLLERS) {
      expect(readMetadata(controller, IS_PLATFORM_ROUTE_KEY)).toBe(true);
    }
  });

  it('3b. the CSRF guard really is driven by the marker and not by a URL list', () => {
    const source = require('fs').readFileSync(`${__dirname}/../../common/guards/platform-csrf.guard.ts`, 'utf8');
    expect(source).toContain('IS_PLATFORM_ROUTE_KEY');
    // No path may be matched as a string: that is the trap R0 and Q2 both documented.
    expect(source).not.toMatch(/req(uest)?\.path\s*===?\s*['"]/);
    expect(source).not.toMatch(/startsWith\(\s*['"]\/api\/platform/);
  });

  it('3c. only the two routes that cannot present a token are exempt, each with a reason', () => {
    const exempt = ALL_ROUTES.filter((route) => route.csrfExemptReason !== undefined).map((route) => `${route.controller}.${route.handler}`);
    expect(exempt.sort()).toEqual([...EXPECTED_CSRF_EXEMPT].sort());
    for (const route of ALL_ROUTES.filter((candidate) => candidate.csrfExemptReason)) {
      expect(String(route.csrfExemptReason).length).toBeGreaterThan(20);
    }
  });

  it('3d. every unsafe platform route is either exempt or reaches the token check', () => {
    const uncovered = ALL_ROUTES.filter(
      (route) => UNSAFE_METHODS.has(route.method) && !route.csrfExemptReason && route.isPublic,
    ).map((route) => `${route.controller}.${route.handler}`);
    // A public, non-exempt unsafe route would be a hole: the guard would demand a
    // token from a caller who has no session to get one with.
    expect(uncovered).toEqual([]);
  });
});

describe('R1 platform route matrix — 4. review item 3: nothing is reachable before enrolment', () => {
  it('4a. exactly the documented routes are marked @AllowedBeforeTotp', () => {
    const allowed = ALL_ROUTES.filter((route) => route.allowedBeforeTotp !== undefined).map(
      (route) => `${route.controller}.${route.handler}`,
    );
    expect(allowed.sort()).toEqual([...EXPECTED_ALLOWED_BEFORE_TOTP].sort());
  });

  it('4b. every exemption carries a written reason', () => {
    for (const route of ALL_ROUTES.filter((candidate) => candidate.allowedBeforeTotp)) {
      expect(String(route.allowedBeforeTotp).length).toBeGreaterThan(20);
    }
  });

  it('4c. no READ or WRITE of platform data is reachable while enrolment is pending', () => {
    // Everything the console actually does - gyms, subscriptions, admins, audit,
    // health, flags, shield, monitor, revenue - must be behind the gate.
    const sensitive = ALL_ROUTES.filter((route) => route.controller === 'PlatformController');
    expect(sensitive.length).toBeGreaterThanOrEqual(25);
    expect(sensitive.filter((route) => route.allowedBeforeTotp).map((route) => route.handler)).toEqual([]);
  });

  it('4d. public platform routes are only the two that must be', () => {
    const publicRoutes = ALL_ROUTES.filter((route) => route.isPublic).map((route) => `${route.controller}.${route.handler}`);
    expect(publicRoutes.sort()).toEqual(['PlatformAuthController.cspReport', 'PlatformAuthController.login']);
  });
});

describe('R1 platform route matrix — 5. the guards exist and are registered in order', () => {
  it('5a. all four R1 guards are registered as APP_GUARD, after the R0 host gate', () => {
    const source = require('fs').readFileSync(`${__dirname}/../../app.module.ts`, 'utf8');
    const order = [
      'AdminHostGuard',
      'LicenceAvailabilityGuard',
      'ThrottlerGuard',
      'PlatformSessionGuard',
      'PlatformTotpEnrolmentGuard',
      // CSRF before step-up: a forged request must be rejected for being forged, not
      // answered with a prompt for a second factor.
      'PlatformCsrfGuard',
      'PlatformStepUpGuard',
      'JwtAuthGuard',
      'TenantGuard',
    ];
    const positions = order.map((name) => source.indexOf(`useClass: ${name}`));
    positions.forEach((position, index) => {
      expect(position).toBeGreaterThan(-1);
      if (index > 0) expect(position).toBeGreaterThan(positions[index - 1]);
    });
    // The credential chain must run BEFORE the tenant strategy, or the tenant
    // strategy would answer for a platform route again (the pre-R1 bug).
    expect(source.indexOf('useClass: PlatformSessionGuard')).toBeLessThan(source.indexOf('useClass: JwtAuthGuard'));
  });

  it('5b. the guards are the classes this file reasoned about', () => {
    expect(typeof PlatformCsrfGuard).toBe('function');
    expect(typeof PlatformSessionGuard).toBe('function');
    expect(typeof PlatformStepUpGuard).toBe('function');
    expect(typeof PlatformTotpEnrolmentGuard).toBe('function');
  });
});
