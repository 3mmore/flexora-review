/**
 * FLEXORA Gym OS — Tenant Isolation Regression Test
 *
 * Security hardening: ensures every Prisma query in tenant-scoped service files
 * includes gymId in the where clause, preventing cross-tenant data leakage.
 *
 * Run with: npx jest tenant-isolation --verbose
 */
import * as fs from 'fs';
import * as path from 'path';

// ─────────────────────────────────────────────────────────────────────────────
// Modules to audit — every Prisma query must include gymId in where clause
// ─────────────────────────────────────────────────────────────────────────────
const PROJECT_ROOT = path.resolve(process.cwd());

const SERVICES: Array<{ module: string; file: string }> = [
  { module: 'members',      file: path.join(PROJECT_ROOT, 'src/modules/members/members.service.ts') },
  { module: 'attendance',   file: path.join(PROJECT_ROOT, 'src/modules/attendance/attendance.service.ts') },
  { module: 'sales',        file: path.join(PROJECT_ROOT, 'src/modules/sales/sales.service.ts') },
  { module: 'inventory',    file: path.join(PROJECT_ROOT, 'src/modules/inventory/inventory.service.ts') },
  { module: 'crm',          file: path.join(PROJECT_ROOT, 'src/modules/crm/crm.service.ts') },
  { module: 'campaigns',    file: path.join(PROJECT_ROOT, 'src/modules/campaigns/campaigns.service.ts') },
  { module: 'classes',      file: path.join(PROJECT_ROOT, 'src/modules/classes/classes.service.ts') },
  { module: 'reports',      file: path.join(PROJECT_ROOT, 'src/modules/reports/reports.service.ts') },
  { module: 'wa-bot',       file: path.join(PROJECT_ROOT, 'src/modules/wa-bot/wa-bot.service.ts') },
  { module: 'invitations',  file: path.join(PROJECT_ROOT, 'src/modules/invitations/invitations.service.ts') },
  { module: 'leads',        file: path.join(PROJECT_ROOT, 'src/modules/leads/leads.service.ts') },
  { module: 'products',     file: path.join(PROJECT_ROOT, 'src/modules/products/products.service.ts') },
  { module: 'pt',           file: path.join(PROJECT_ROOT, 'src/modules/pt/pt.service.ts') },
  { module: 'expenses',     file: path.join(PROJECT_ROOT, 'src/modules/expenses/expenses.service.ts') },
  { module: 'branches',     file: path.join(PROJECT_ROOT, 'src/modules/branches/branches.service.ts') },
  { module: 'scheduler',    file: path.join(PROJECT_ROOT, 'src/modules/scheduler/scheduler.service.ts') },
  { module: 'plans',        file: path.join(PROJECT_ROOT, 'src/modules/plans/plans.service.ts') },
  { module: 'billing',      file: path.join(PROJECT_ROOT, 'src/modules/billing/billing.service.ts') },
  { module: 'backups',      file: path.join(PROJECT_ROOT, 'src/modules/backups/backups.service.ts') },
  { module: 'users',        file: path.join(PROJECT_ROOT, 'src/modules/users/users.service.ts') },
  { module: 'contracts',    file: path.join(PROJECT_ROOT, 'src/modules/contracts/contracts.service.ts') },
  { module: 'biometric',    file: path.join(PROJECT_ROOT, 'src/modules/biometric/biometric.service.ts') },
  { module: 'transfers',    file: path.join(PROJECT_ROOT, 'src/modules/transfers/transfers.service.ts') },
];

// Platform-level models — queries on these do NOT need gymId
const PLATFORM_MODELS = [
  'PlatformLog', 'PlatformAdmin', 'PlatformAuditLog', 'GymMessagingConfig',
  'SaasPlan', 'MarketplaceModule', 'GymModuleInstallation',
  'License', 'Subscription', 'AiInsight', 'AiChatMessage',
  'AiSuggestion', 'GymSettings', 'RefreshToken', 'OnboardingProgress',
  'PaymentProviderEvent', // billing provider event logging — no tenant filter needed
];

const QUERY_METHODS = [
  'findMany', 'findFirst', 'findUnique', 'findRaw', 'createMany',
  'count', 'aggregate', 'groupBy',
];

function hasGymIdInQuery(queryContext: string): boolean {
  const lines = queryContext.split('\n');
  let inWhere = false;
  let braceDepth = 0;

  for (const line of lines) {
    if (!inWhere) {
      if (/where[:\s]*\{/.test(line)) {
        inWhere = true;
        braceDepth = (line.match(/\{/g) || []).length - (line.match(/\}/g) || []).length;
      }
    } else {
      braceDepth += (line.match(/\{/g) || []).length;
      braceDepth -= (line.match(/\}/g) || []).length;
      if (braceDepth <= 0) inWhere = false;
    }

    if (inWhere && /gymId/.test(line)) return true;
    if (/const\s+where\s*=\s*\{[^}]*gymId/.test(line)) return true;
    if (/\bwhere\.gymId\s*=/.test(line)) return true;
    if (/where\s*=\s*\{[^}]*gymId/.test(line) && !/where[:\s]*{/.test(line)) return true;
  }
  return false;
}

interface QueryCheck {
  module: string;
  line: number;
  query: string;
  passed: boolean;
  note: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// Audit function — runs at test execution time (not module load)
// ─────────────────────────────────────────────────────────────────────────────
function runAudit(): QueryCheck[] {
  const results: QueryCheck[] = [];

  for (const svc of SERVICES) {
    if (!fs.existsSync(svc.file)) {
      results.push({ module: svc.module, line: 0, query: '(file not found)', passed: false, note: 'FILE NOT FOUND' });
      continue;
    }

    const content = fs.readFileSync(svc.file, 'utf8');
    const lines = content.split('\n');

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      const isQuery = QUERY_METHODS.some((m) => line.includes(`.${m}(`) || line.includes(`prisma.${m}`));

      if (!isQuery) continue;

      // 200-line context window (full method body)
      const context = lines.slice(Math.max(0, i - 100), Math.min(i + 100, lines.length)).join('\n');

      if (PLATFORM_MODELS.some((m) => context.includes(m))) {
        results.push({ module: svc.module, line: i + 1, query: line, passed: true, note: 'platform-level model' });
        continue;
      }

      // Special case: Gym.findMany without a WHERE clause is platform-level
      // (listing all gym IDs for platform admin tasks like S3 backup tracking)
      if (/\.gym\.findMany/.test(context) && !/where[:\s]*\{/.test(line)) {
        results.push({ module: svc.module, line: i + 1, query: line, passed: true, note: 'Gym.findMany without WHERE — platform admin operation' });
        continue;
      }

      const hasGymId = hasGymIdInQuery(context);
      results.push({
        module: svc.module, line: i + 1, query: line,
        passed: hasGymId,
        note: hasGymId ? 'gymId found in where clause' : 'MISSING gymId ❌',
      });
    }
  }
  return results;
}

// ─────────────────────────────────────────────────────────────────────────────
// Test suite
// ─────────────────────────────────────────────────────────────────────────────
describe('Tenant Isolation Security — Service Layer Regression', () => {
  // Run audit at test execution time (not module load)
  const checks = runAudit();
  const total = checks.length;
  const passed = checks.filter((c) => c.passed).length;
  const failed = checks.filter((c) => !c.passed).length;
  const modulesFound = [...new Set(checks.map((c) => c.module))];

  it(`audited at least 100 scoped queries (found ${total})`, () => {
    expect(total).toBeGreaterThanOrEqual(100);
  });

  it(`covered all 23 critical service files (found ${modulesFound.length})`, () => {
    expect(modulesFound.length).toBeGreaterThanOrEqual(23);
  });

  // Per-module
  for (const svc of SERVICES) {
    const modChecks = checks.filter((c) => c.module === svc.module);
    if (modChecks.length === 0) continue;
    const modFailed = modChecks.filter((c) => !c.passed).length;

    it(`${svc.module}: ${modChecks.length - modFailed} PASS, ${modFailed} FAILED`, () => {
      expect(modFailed).toBe(0);
    });
  }

  // Overall
  it(`${total} queries — ${passed} passed, ${failed} failed`, () => {
    expect(failed).toBe(0);
  });
});