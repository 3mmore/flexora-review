/**
 * FLEXORA Gym OS — gym-local time (shared by owner notifications and team
 * performance).
 *
 * WHY: timestamps are stored in UTC (`DateTime @default(now())`), but an owner
 * reads a calendar. "Today", "this month" and a date-range filter must therefore
 * be computed in the GYM's timezone, not the server's and not UTC. Egypt is
 * UTC+2 with a DST period since 2023, so a naive `+2h` shift is wrong twice a
 * year; everything below goes through Intl's tz database.
 *
 * The gym timezone is read from the existing `GymSettings` key/value table
 * (key `timezone`) with `Africa/Cairo` as the documented default. No schema
 * change is involved — a gym that never set it gets Cairo, which is the locale
 * of every deployment this product has shipped to.
 */

export const DEFAULT_GYM_TZ = 'Africa/Cairo';

/** A YYYY-MM-DD calendar date in some timezone. */
export interface CalendarDate {
  year: number;
  month: number; // 1-12
  day: number; // 1-31
}

const YMD_RE = /^(\d{4})-(\d{2})-(\d{2})$/;
const MONTH_RE = /^(\d{4})-(0[1-9]|1[0-2])$/;

/** Is `tz` an IANA zone this runtime knows? */
export function isValidTimeZone(tz: unknown): boolean {
  if (typeof tz !== 'string' || !tz || tz.length > 64) return false;
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

/** Normalise a stored setting to a usable zone, falling back to the default. */
export function resolveGymTimeZone(raw?: string | null): string {
  return isValidTimeZone(raw) ? (raw as string) : DEFAULT_GYM_TZ;
}

const partsCache = new Map<string, Intl.DateTimeFormat>();
function formatter(tz: string): Intl.DateTimeFormat {
  let f = partsCache.get(tz);
  if (!f) {
    f = new Intl.DateTimeFormat('en-US', {
      timeZone: tz,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hourCycle: 'h23',
    });
    partsCache.set(tz, f);
  }
  return f;
}

/** Offset of `tz` at the instant `date`, in ms (UTC+2 → +7_200_000). */
export function tzOffsetMs(date: Date, tz: string): number {
  const parts = formatter(tz).formatToParts(date);
  const get = (t: string) => Number(parts.find((p) => p.type === t)?.value ?? '0');
  const asUtc = Date.UTC(
    get('year'),
    get('month') - 1,
    get('day'),
    get('hour'),
    get('minute'),
    get('second'),
  );
  return asUtc - Math.floor(date.getTime() / 1000) * 1000;
}

/** Calendar date of `date` as seen in `tz`. */
export function calendarDateIn(date: Date, tz: string): CalendarDate {
  const parts = formatter(tz).formatToParts(date);
  const get = (t: string) => Number(parts.find((p) => p.type === t)?.value ?? '0');
  return { year: get('year'), month: get('month'), day: get('day') };
}

/**
 * UTC instant of a wall-clock time in `tz`.
 *
 * Two-pass: guess with the offset at the guessed instant, then re-resolve with
 * the offset at the corrected instant. That is exactly right except inside the
 * one-hour DST gap, where the second pass lands on the first valid instant
 * after the gap — the behaviour every scheduling product documents.
 */
export function zonedTimeToUtc(tz: string, y: number, m: number, d: number, h = 0, min = 0, s = 0, ms = 0): Date {
  const guess = Date.UTC(y, m - 1, d, h, min, s, ms);
  const off1 = tzOffsetMs(new Date(guess), tz);
  const t1 = guess - off1;
  const off2 = tzOffsetMs(new Date(t1), tz);
  return new Date(off2 === off1 ? t1 : guess - off2);
}

/** Parse a strict YYYY-MM-DD string; null when it is not a real calendar date. */
export function parseYmd(value: unknown): CalendarDate | null {
  if (typeof value !== 'string') return null;
  const m = YMD_RE.exec(value.trim());
  if (!m) return null;
  const year = Number(m[1]);
  const month = Number(m[2]);
  const day = Number(m[3]);
  if (year < 1970 || year > 2100 || month < 1 || month > 12 || day < 1 || day > 31) return null;
  // Reject 2026-02-30: build the date in UTC and require the parts to survive.
  const probe = new Date(Date.UTC(year, month - 1, day));
  if (probe.getUTCMonth() !== month - 1 || probe.getUTCDate() !== day) return null;
  return { year, month, day };
}

export function formatYmd(c: CalendarDate): string {
  return `${String(c.year).padStart(4, '0')}-${String(c.month).padStart(2, '0')}-${String(c.day).padStart(2, '0')}`;
}

/** First instant of a gym-local calendar day. */
export function startOfDayUtc(c: CalendarDate, tz: string): Date {
  return zonedTimeToUtc(tz, c.year, c.month, c.day, 0, 0, 0, 0);
}

/** First instant of the NEXT gym-local day (exclusive upper bound). */
export function endOfDayExclusiveUtc(c: CalendarDate, tz: string): Date {
  const next = new Date(Date.UTC(c.year, c.month - 1, c.day + 1));
  return zonedTimeToUtc(tz, next.getUTCFullYear(), next.getUTCMonth() + 1, next.getUTCDate(), 0, 0, 0, 0);
}

/** Whole days between two calendar dates (b - a), DST-proof. */
export function daysBetween(a: CalendarDate, b: CalendarDate): number {
  const MS = 86_400_000;
  return Math.round((Date.UTC(b.year, b.month - 1, b.day) - Date.UTC(a.year, a.month - 1, a.day)) / MS);
}

/** Add `n` days to a calendar date (pure calendar arithmetic). */
export function addDays(c: CalendarDate, n: number): CalendarDate {
  const d = new Date(Date.UTC(c.year, c.month - 1, c.day + n));
  return { year: d.getUTCFullYear(), month: d.getUTCMonth() + 1, day: d.getUTCDate() };
}

/** Start of the calendar month containing `c`. */
export function startOfMonth(c: CalendarDate): CalendarDate {
  return { year: c.year, month: c.month, day: 1 };
}

/** Last day of the calendar month containing `c`. */
export function endOfMonth(c: CalendarDate): CalendarDate {
  const d = new Date(Date.UTC(c.year, c.month, 0));
  return { year: d.getUTCFullYear(), month: d.getUTCMonth() + 1, day: d.getUTCDate() };
}

/** The period key used by StaffTarget, e.g. "2026-11". */
export function monthKey(c: CalendarDate): string {
  return `${String(c.year).padStart(4, '0')}-${String(c.month).padStart(2, '0')}`;
}

export function isValidMonthKey(value: unknown): boolean {
  return typeof value === 'string' && MONTH_RE.test(value);
}

/**
 * A closed date filter expressed as gym-local calendar days, already converted
 * to the UTC instants Prisma needs.
 */
export interface ResolvedRange {
  /** inclusive lower bound */
  gte: Date;
  /** exclusive upper bound */
  lt: Date;
  /** the calendar days as they will be echoed back to the client */
  from: string;
  to: string;
  tz: string;
  /** whole days covered — used to enforce the documented maximum */
  days: number;
}

/**
 * Build a range from two YYYY-MM-DD strings (inclusive), or from a named preset.
 * Throws nothing: the caller validates and maps to a 400.
 */
export function buildRange(
  from: CalendarDate | null,
  to: CalendarDate | null,
  tz: string,
  fallbackDays = 30,
): ResolvedRange {
  const today = calendarDateIn(new Date(), tz);
  const toC = to ?? today;
  const fromC = from ?? addDays(toC, -(fallbackDays - 1));
  const days = daysBetween(fromC, toC) + 1;
  return {
    gte: startOfDayUtc(fromC, tz),
    lt: endOfDayExclusiveUtc(toC, tz),
    from: formatYmd(fromC),
    to: formatYmd(toC),
    tz,
    days,
  };
}
