import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { IS_PUBLIC_KEY } from '../decorators/public.decorator';
import { IS_PLATFORM_ROUTE_KEY } from '../decorators/platform-route.decorator';
import { applyPlatformHeaders } from '../interceptors/platform-headers.interceptor';

@Injectable()
export class PlatformAdminGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    // PHASE R1 — this guard is applied per-controller, but the platform auth
    // controller also carries @Public() routes (login, the CSP report sink) where
    // there is no administrator yet. It is also a no-op off the platform, so that
    // registering it more widely later cannot break a tenant route.
    const handler = context.getHandler();
    const controller = context.getClass();
    if (!this.reflector.getAllAndOverride<boolean>(IS_PLATFORM_ROUTE_KEY, [handler, controller])) return true;
    if (this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [handler, controller])) return true;

    const user = context.switchToHttp().getRequest().user;
    if (!user || user.type !== 'platform') {
      applyPlatformHeaders(context.switchToHttp().getResponse());
      throw new ForbiddenException('Platform session required');
    }
    // PLATFORM_ADMIN has full access
    if (user.role === 'PLATFORM_ADMIN') return true;
    // PLATFORM_VIEWER is allowed read-only (GET/HEAD) access
    if (user.role === 'PLATFORM_VIEWER') {
      const method = context.switchToHttp().getRequest().method;
      if (method === 'GET' || method === 'HEAD') return true;
      throw new ForbiddenException('PLATFORM_VIEWER role does not allow write operations');
    }
    throw new ForbiddenException('Unknown platform role');
  }
}
