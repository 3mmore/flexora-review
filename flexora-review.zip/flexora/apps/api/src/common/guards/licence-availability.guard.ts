/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
/**
 * PHASE P3 / PHASE Q2 / PHASE Q3 — global enforcement of the licence state.
 *
 * Registered as an APP_GUARD *ahead of* ThrottlerGuard/JwtAuthGuard, because when
 * it does refuse it must be the first thing that answers: the guards behind it
 * need Redis and the database, and the whole point of this one is to answer
 * 503 + Retry-After within a bounded time even when those are also unhappy.
 *
 * ---------------------------------------------------------------------------
 * PHASE Q3 — ENFORCEMENT IS OPT-IN, AND OFF BY DEFAULT
 * ---------------------------------------------------------------------------
 * `FLEXORA_LICENSE_REQUIRED` (see modules/license/licence-policy.ts) decides
 * whether this guard enforces anything at all:
 *
 *   false / unset (the SaaS default, and the behaviour of every deployment before
 *   this variable existed): the guard returns true immediately. There is no
 *   licence phone-home — `LicenseCheckService` is not even registered (see
 *   license.module.ts) — nothing populates `LicenceStateService`, and no route can
 *   ever receive a 503 LICENCE_UNVERIFIED.
 *
 *   true (a self-hosted, licensed deployment): the PHASE P3 policy applies in
 *   full. Only an AUTHORITATIVE verification opens licensed routes
 *   (`isServingLicensedRoutes()`, i.e. state === 'verified'), so a process that
 *   has just booted and not yet verified answers 503 on every licensed route —
 *   the agreed "boot but 503 licensed routes" behaviour. A REVOKED or EXPIRED
 *   licence can never become valid through a transport failure (`refused` is
 *   sticky in that direction, enforced in LicenceStateService), and recovery is
 *   automatic: the first successful verification clears the state with no
 *   restart.
 *
 * This is the flip that PHASE P3 documented but deliberately did not make, because
 * making it unconditionally would have 503'd every licensed route on every
 * deployment with no reachable licence server. It is now made, behind the switch.
 *
 * ---------------------------------------------------------------------------
 * PHASE Q2 — THE PROBES ARE IDENTIFIED BY ROUTE METADATA
 * ---------------------------------------------------------------------------
 * `/api/health/live` and `/api/health/ready` are the only routes that answer while
 * enforcement is on and the licence is not verified: an orchestrator has to be
 * able to see the container in order to decide whether to restart it, and
 * `/ready` REPORTS the licence state without blocking on it.
 *
 * They are recognised by the `@HealthProbe(...)` marker on the handlers
 * (`probeKindOfContext`), never by comparing the request URL against a list of
 * strings. With `app.setGlobalPrefix('api')` the URL a guard sees is rewritten
 * (measured live: a request for `/api/members?limit=1` arrived with
 * `req.url === '/?limit=1'`), so the string allow-list this guard carried in
 * PHASE P3 could not be relied on; metadata is the same source Nest itself routes
 * on and cannot be spoofed by a query string or a rewritten path.
 *
 * Nothing else is exempt. `/api/health`, `/api/health/metrics` and
 * `/api/health/details` are licensed work behind SUPER_ADMIN and are refused like
 * everything else. A non-HTTP context (a gateway, a queue job, an internal
 * invocation) has no handler to exempt it, so it is refused too: "no route to
 * check" must never mean "allowed".
 */
import { CanActivate, ExecutionContext, Injectable, ServiceUnavailableException } from '@nestjs/common';
import { LicenceStateService } from '../../modules/license/licence-state.service';
import { isLicenceEnforcementRequired } from '../../modules/license/licence-policy';
import { LICENCE_UNVERIFIED } from '../filters/dependency-unavailable.filter';
import { probeKindOfContext, resolvedProbes } from '../health/probe-routes';

/**
 * The routes that answer while enforcement is on and the licence is not verified.
 * DERIVED from the `@HealthProbe` markers, so it cannot drift from the controller.
 */
export function licenceExemptProbePaths(): string[] {
  return resolvedProbes().map((p) => p.prefixed);
}

@Injectable()
export class LicenceAvailabilityGuard implements CanActivate {
  constructor(private readonly licenceState: LicenceStateService) {}

  canActivate(context: ExecutionContext): boolean {
    // PHASE Q3 — enforcement is opt-in. When it is off this guard is inert, which
    // is what keeps SaaS behaviour identical to a tree that never had it.
    if (!isLicenceEnforcementRequired()) return true;

    // PHASE Q2 — the infrastructure probes always answer, identified by the
    // marker on the matched handler.
    if (probeKindOfContext(context)) return true;

    // Enforcement is on: only an authoritative verification serves licensed
    // routes. 'unknown' (booted, not verified yet), 'unverified' (grace
    // exhausted) and 'refused' (revoked/expired) all fail closed.
    if (this.licenceState.isServingLicensedRoutes()) return true;

    const http = context.switchToHttp?.();
    const req = http?.getRequest<{ url?: string; originalUrl?: string }>();
    // No request object at all -> a gateway, a queue job or an internal call.
    // Fail closed: there is no probe marker to exempt it.
    const path = req ? String(req.originalUrl || req.url || '').split('?')[0] : 'non-http context';
    throw this.refuse(path || 'unknown route');
  }

  private refuse(path: string): ServiceUnavailableException {
    return new ServiceUnavailableException({
      statusCode: 503,
      code: LICENCE_UNVERIFIED,
      // No licence key, no server URL, no expiry, no reason string: nothing about
      // the licence leaves the process.
      message: 'Service temporarily unavailable: the licence could not be verified. Retry shortly.',
      retryAfterSeconds: 5,
      path: path.split('?')[0],
      timestamp: new Date().toISOString(),
    });
  }
}
