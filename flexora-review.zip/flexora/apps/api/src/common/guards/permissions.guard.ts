import { Injectable, CanActivate, ExecutionContext, ForbiddenException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { PERMISSIONS_KEY } from '../decorators/permissions.decorator';
import { PermissionsService } from '../../modules/permissions/permissions.service';
import { TenantContextService } from '../services/tenant-context.service';

/**
 * ROUND 13 (Phase 5) — enforces @Permissions('...') metadata.
 *
 * Runs AFTER RolesGuard (which still guards platform/SUPER_ADMIN endpoints and
 * the few coarse endpoints the fixed catalog cannot express). An endpoint with
 * no @Permissions metadata passes — any authenticated user, same as before.
 * Branch scoping is orthogonal and unaffected: TenantGuard + the Prisma scope
 * middleware keep pinning restricted users to their branch.
 */
@Injectable()
export class PermissionsGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly permissions: PermissionsService,
    private readonly tenantContext: TenantContextService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const required = this.reflector.getAllAndOverride<string[]>(PERMISSIONS_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (!required || required.length === 0) return true;

    const request = context.switchToHttp().getRequest();
    const user = request.user;
    if (!user) throw new ForbiddenException('Insufficient permissions');

    // The tenant ALS context is established by TenantContextInterceptor, which
    // runs AFTER the guards — so without this frame the override lookup below
    // would run without app.gym_id and FORCE RLS on UserPermission would
    // silently filter it to zero rows (every check would see role defaults
    // only). Mirror the interceptor's store: gymId + the branch scope the
    // TenantGuard already resolved onto the request.
    const scope = request?.branchScope as
      | { unrestricted?: boolean; filterBranchId?: string | null }
      | undefined;
    const store = {
      gymId: user.gymId ?? null,
      branchId: scope?.filterBranchId ?? null,
      unrestrictedBranch: scope ? scope.unrestricted === true : true,
    };
    const ok = await this.tenantContext.run(store, () => this.permissions.hasAll(user, required));
    if (!ok) {
      throw new ForbiddenException({
        code: 'PERMISSION_DENIED',
        message: 'Insufficient permissions',
        required,
      });
    }
    return true;
  }
}
