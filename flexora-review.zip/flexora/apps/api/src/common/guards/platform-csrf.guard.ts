/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1.6 / review item 4 — CSRF on the platform routes, driven by metadata.
 *
 * WHAT WAS MEASURED FIRST (work/r1-evidence/00-before.log B2): the global
 * CsrfMiddleware is registered `.forRoutes("api/*splat")`, and Nest prepends the
 * global prefix to that string exactly as it does to every `.exclude()` entry, so
 * the middleware is registered at /api/api/* and NEVER RUNS. Proof: no GET on the
 * api ever received the `_csrf` cookie the middleware sets on every request it
 * sees (csrf.middleware.ts:123-127), on three different routes, and a POST with no
 * token and no cookies was answered by the route rather than by the middleware.
 * PHASE Q could only guess at this ("likely inert"); it is now measured.
 *
 * Correcting that registration would switch CSRF enforcement ON for every tenant
 * route at once, which the owner ruled out of scope for PHASE R. So this guard
 * enforces CSRF where it is in scope — the platform routes — and selects them by
 * @PlatformRoute() metadata, never by URL strings. A companion test enumerates
 * every @PlatformRoute() controller and fails if one is not covered, and another
 * asserts that tenant routes are unaffected.
 *
 * Two independent checks, in this order:
 *   1. Origin/Referer, when present, must name an ADMIN_HOSTS entry. Applied to
 *      every state-changing platform request INCLUDING the exempt ones, so the
 *      login itself cannot be driven cross-site (login CSRF).
 *   2. Double submit: the x-csrf-token header must equal the readable
 *      flx_platform_csrf cookie, compared in constant time.
 *
 * SameSite=Strict on the session cookie already stops a browser from sending it
 * cross-site; these checks are what remains true if that ever changes, if a
 * sibling subdomain is compromised, or if a client is not a browser.
 */
import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { timingSafeEqual } from 'crypto';
import { IS_PLATFORM_ROUTE_KEY } from '../decorators/platform-route.decorator';
import { PLATFORM_CSRF_EXEMPT_KEY } from '../decorators/platform-auth.decorators';
import { PLATFORM_CSRF_COOKIE_NAME, PLATFORM_CSRF_HEADER } from '../../modules/platform-auth/platform-session.service';
import { isAdminHost } from '../../config/admin-hosts';
import { applyPlatformHeaders } from '../interceptors/platform-headers.interceptor';

export const CSRF_FAILURE_CODE = 'CSRF_VALIDATION_FAILED';
export const ORIGIN_FAILURE_CODE = 'ORIGIN_NOT_ALLOWED';
const SAFE_METHODS = ['GET', 'HEAD', 'OPTIONS'];

function constantTimeEquals(a: string, b: string): boolean {
  const bufferA = Buffer.from(String(a));
  const bufferB = Buffer.from(String(b));
  if (bufferA.length !== bufferB.length || bufferA.length === 0) return false;
  return timingSafeEqual(bufferA, bufferB);
}

@Injectable()
export class PlatformCsrfGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const handler = context.getHandler();
    const controller = context.getClass();
    if (!this.reflector.getAllAndOverride<boolean>(IS_PLATFORM_ROUTE_KEY, [handler, controller])) return true;

    const request = context.switchToHttp().getRequest<{
      method: string;
      headers: Record<string, string | string[] | undefined>;
      cookies?: Record<string, string>;
      /** Express puts the response on the request; typed loosely because the only
       *  thing done with it is handing it to applyPlatformHeaders. */
      res?: unknown;
    }>();
    if (SAFE_METHODS.includes(String(request.method).toUpperCase())) return true;

    // 1. Origin / Referer, always — including routes exempt from the token check.
    this.assertOriginIsAnAdminHost(request.headers, request.res);

    // 2. Double submit, unless this route cannot present a token.
    const exemption = this.reflector.getAllAndOverride<string>(PLATFORM_CSRF_EXEMPT_KEY, [handler, controller]);
    if (exemption) return true;

    const cookie = request.cookies?.[PLATFORM_CSRF_COOKIE_NAME];
    const headerValue = request.headers[PLATFORM_CSRF_HEADER];
    const header = Array.isArray(headerValue) ? headerValue[0] : headerValue;
    if (!cookie || !header || !constantTimeEquals(cookie, header)) {
      applyPlatformHeaders(request.res);
      throw new ForbiddenException({
        statusCode: 403,
        code: CSRF_FAILURE_CODE,
        message: 'CSRF validation failed',
      });
    }
    return true;
  }

  private assertOriginIsAnAdminHost(headers: Record<string, string | string[] | undefined>, response?: unknown): void {
    const origin = headers.origin;
    const referer = headers.referer;
    const source = (Array.isArray(origin) ? origin[0] : origin) || (Array.isArray(referer) ? referer[0] : referer);
    // No Origin and no Referer: a non-browser client. The session cookie is
    // SameSite=Strict, so a browser cannot get here cross-site without one.
    if (!source) return;

    let hostname: string;
    try {
      hostname = new URL(String(source)).hostname;
    } catch {
      applyPlatformHeaders(response);
      throw new ForbiddenException({ statusCode: 403, code: ORIGIN_FAILURE_CODE, message: 'Origin not allowed' });
    }
    if (!isAdminHost({ host: hostname })) {
      // Hostname only in the log line a caller might write; never the full Origin,
      // which can carry a path and query from the victim's session.
      applyPlatformHeaders(response);
      throw new ForbiddenException({ statusCode: 403, code: ORIGIN_FAILURE_CODE, message: 'Origin not allowed' });
    }
  }
}
