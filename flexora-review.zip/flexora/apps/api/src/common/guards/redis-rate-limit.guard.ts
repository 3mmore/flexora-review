/**
 * FLEXORA Gym OS — Redis-based rate limiter (Phase 3 — production hardening)
 * © 2024 Ammar Allam. All rights reserved.
 *
 * @deprecated No route currently uses @RateLimit or RedisRateLimitGuard.
 * The global ThrottlerModule (in-memory, per-process) is the active rate
 * limiter. This guard is kept only as a reference implementation for a
 * future distributed sliding-window limiter. Do NOT use in production
 * without first completing:
 *   1. Register it as a global guard or on specific routes
 *   2. Add fail-closed integration tests
 *   3. Expose limiter health and hit-rate metrics
 * See F-012 in SELF_AUDIT_CURRENT_2026-07-16.md for context.
 *
 * Sliding-window rate limiter using Redis INCR + EXPIRE.
 * More accurate than Throttler's fixed-window and survives multi-instance.
 */
import { CanActivate, ExecutionContext, HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Request } from 'express';
import { RedisService } from '../../config/redis.service';

export const RATE_LIMIT_KEY = 'rate_limit';
export interface RateLimitOptions {
  windowSeconds: number;
  max: number;
  keyFn?: (req: Request) => string;
}

@Injectable()
export class RedisRateLimitGuard implements CanActivate {
  private readonly logger = new Logger(RedisRateLimitGuard.name);
  private static warned = false;
  constructor(private readonly redis: RedisService, private readonly reflector: Reflector) {
    if (!RedisRateLimitGuard.warned) {
      this.logger.warn('RedisRateLimitGuard is deprecated and NOT used by any route. See F-012.');
      RedisRateLimitGuard.warned = true;
    }
  }

  async canActivate(ctx: ExecutionContext): Promise<boolean> {
    const opts = this.reflector.get<RateLimitOptions | undefined>(RATE_LIMIT_KEY, ctx.getHandler());
    if (!opts) return true;

    const req = ctx.switchToHttp().getRequest<Request>();
    const key = opts.keyFn ? opts.keyFn(req) : this.defaultKey(req);
    const fullKey = `rl:${key}:${opts.windowSeconds}`;

    try {
      const count = await this.redis.client.incr(fullKey);
      if (count === 1) await this.redis.client.expire(fullKey, opts.windowSeconds);
      if (count > opts.max) {
        const ttl = await this.redis.client.ttl(fullKey);
        this.logger.warn(`Rate limit exceeded: ${key} (${count}/${opts.max}, retry in ${ttl}s)`);
        throw new HttpException({
          statusCode: HttpStatus.TOO_MANY_REQUESTS,
          error: 'Too Many Requests',
          message: `Rate limit exceeded. Try again in ${ttl}s.`,
          retryAfter: ttl,
        }, HttpStatus.TOO_MANY_REQUESTS);
      }
      return true;
    } catch (e) {
      if (e instanceof HttpException) throw e;
      // Fail closed: on Redis error, deny the request rather than allowing
      // unlimited traffic. This is the safe default for a rate limiter.
      this.logger.error(`Redis rate limit check failed, denying request: ${(e as Error).message}`);
      throw new HttpException({
        statusCode: HttpStatus.TOO_MANY_REQUESTS,
        error: 'Rate limiter unavailable',
        message: 'Rate limiter temporarily unavailable. Try again later.',
      }, HttpStatus.TOO_MANY_REQUESTS);
    }
  }

  private defaultKey(req: Request & { user?: { sub?: string; id?: string } }): string {
    const ip = req.ip || (Array.isArray(req.headers['x-forwarded-for']) ? req.headers['x-forwarded-for'][0] : req.headers['x-forwarded-for']) || 'unknown';
    const userId = req.user?.sub || req.user?.id || 'anon';
    return `${ip}:${userId}`;
  }
}

export const RateLimit = (opts: RateLimitOptions) =>
  (target: object, _key: string, descriptor: PropertyDescriptor) => {
    Reflect.defineMetadata(RATE_LIMIT_KEY, opts, descriptor.value);
    return descriptor;
  };
