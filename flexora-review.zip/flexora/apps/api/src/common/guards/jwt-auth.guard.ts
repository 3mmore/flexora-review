import { Injectable, ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { Reflector } from '@nestjs/core';
import { IS_PUBLIC_KEY } from '../decorators/public.decorator';
import { IS_PLATFORM_ROUTE_KEY } from '../decorators/platform-route.decorator';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {
  private reflector: Reflector;
  private jwtService?: { verifyAsync: (token: string, options: Record<string, unknown>) => Promise<unknown> };

  constructor(reflectorOrJwt: Reflector | { verifyAsync: (token: string, options: Record<string, unknown>) => Promise<unknown> }, maybeReflector?: Reflector) {
    super();
    this.reflector = (maybeReflector || reflectorOrJwt) as Reflector;
    // FIX (launch-readiness: fourth bug found in the same masked chain as
    // the QueueService/BackupsService/HealthModule fixes above -- this one
    // is a genuine runtime null-safety bug, not a module-wiring bug).
    // This constructor supports two call shapes: `new JwtAuthGuard(reflector)`
    // (1 arg — real production use, see main.ts/app.module.ts's global
    // APP_GUARD registration) and `new JwtAuthGuard(jwtServiceLike,
    // reflector)` (2 args — used only by test files that want to inject a
    // fake/mocked JWT verifier). The problem: `reflectorOrJwt`'s TypE is a
    // union (`Reflector | { verifyAsync: ... }`), which TypeScript can only
    // emit as the generic `Object` in the compiled `design:paramtypes`
    // metadata Nest's DI reads (confirmed directly: compiled output is
    // `__metadata("design:paramtypes", [Object, core_1.Reflector])`). Nest
    // cannot resolve a concrete provider for a bare `Object` token, so when
    // it constructs this guard automatically via the global
    // `{ provide: APP_GUARD, useClass: JwtAuthGuard }` registration, it
    // calls the constructor with `reflectorOrJwt` as `undefined` and
    // `maybeReflector` correctly resolved to the real `Reflector` instance
    // (Nest DOES attempt to inject both declared constructor parameters,
    // not just the first). The next line then unconditionally did
    // `'verifyAsync' in (reflectorOrJwt as object)` whenever `maybeReflector`
    // was truthy -- with `reflectorOrJwt` actually `undefined` in this real
    // DI-driven case, `'in' operator` on `undefined` throws a raw
    // `TypeError`, crashing the ENTIRE application's bootstrap (this guard
    // is a global guard, applied to every route). Confirmed directly:
    // running the full apps/api test suite hit exactly this crash the
    // moment the earlier QueueService/BackupsService/HealthModule DI-wiring
    // bugs were fixed and bootstrap finally got this far. FIX: guard the
    // `'in'` check with an explicit truthiness/type check on `reflectorOrJwt`
    // itself first, so a `reflectorOrJwt` of `undefined` (the real DI case)
    // is handled safely and falls through to the normal
    // `super.canActivate(...)` / passport-jwt path below, exactly as the
    // single-argument `new JwtAuthGuard(reflector)` call shape already
    // does.
    if (maybeReflector && reflectorOrJwt && typeof reflectorOrJwt === 'object' && 'verifyAsync' in reflectorOrJwt) {
      this.jwtService = reflectorOrJwt as { verifyAsync: (token: string, options: Record<string, unknown>) => Promise<unknown> };
    }
  }

  canActivate(context: ExecutionContext) {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPublic) return true;

    // PHASE R1 / review item 1 — a platform route is authenticated by
    // PlatformSessionGuard, which is registered earlier in the APP_GUARD chain and
    // only accepts a token signed with JWT_PLATFORM_SECRET that names a live
    // PlatformSession row. Running the TENANT strategy here as well is what made
    // every console call 401 before R1: validate() resolves payload.sub against
    // the "User" table, and a platform subject is a PlatformAdmin id, so the
    // lookup returned zero rows and the guard threw "Invalid or expired token"
    // (measured: work/r1-evidence/00-before.log B1.1). This guard therefore hands
    // platform routes over instead of answering for them.
    const isPlatformRoute = this.reflector.getAllAndOverride<boolean>(IS_PLATFORM_ROUTE_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPlatformRoute) return true;

    if (this.jwtService) {
      const request = context.switchToHttp().getRequest();
      const token = request?.headers?.authorization?.replace('Bearer ', '') || request?.cookies?.flx_access;
      if (!token) throw new UnauthorizedException('Invalid or expired token');
      return this.jwtService.verifyAsync(token, { secret: process.env.JWT_ACCESS_SECRET, algorithms: ['HS256'] }).then((payload: unknown) => { request.user = payload; return true; });
    }
    return super.canActivate(context);
  }

  handleRequest<TUser = unknown>(err: unknown, user: TUser, info: unknown, context: ExecutionContext, status?: unknown): TUser {
    if (err || !user) {
      throw new UnauthorizedException('Invalid or expired token');
    }
    return user;
  }
}
