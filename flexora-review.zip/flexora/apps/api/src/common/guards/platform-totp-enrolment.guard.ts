/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1.1 / review item 3 — the TOTP enrolment gate.
 *
 * "TOTP mandatory and enrolled before any other console action." A password-only
 * console session is useless: it can reach the enrolment routes and nothing else.
 *
 * The authority is the PlatformAdmin row, not the session flag. That matters for
 * the CLI reset in decision D4: when an operator clears an enrolment, every
 * session that administrator already holds must become enrolment-pending again on
 * its next request, without anybody having to log out first.
 *
 * Routes that stay reachable are marked @AllowedBeforeTotp('reason'), so the
 * exemption is documented where it is granted, and a test enumerates every
 * @PlatformRoute() handler and fails if an unmarked one is reachable while
 * pending.
 */
import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { IS_PUBLIC_KEY } from '../decorators/public.decorator';
import { IS_PLATFORM_ROUTE_KEY } from '../decorators/platform-route.decorator';
import { ALLOWED_BEFORE_TOTP_KEY } from '../decorators/platform-auth.decorators';
import type { PlatformRequest } from './platform-session.guard';
import { applyPlatformHeaders } from '../interceptors/platform-headers.interceptor';

export const TOTP_ENROLMENT_REQUIRED_CODE = 'TOTP_ENROLMENT_REQUIRED';

@Injectable()
export class PlatformTotpEnrolmentGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const handler = context.getHandler();
    const controller = context.getClass();
    if (!this.reflector.getAllAndOverride<boolean>(IS_PLATFORM_ROUTE_KEY, [handler, controller])) return true;
    if (this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [handler, controller])) return true;
    // The decorator's value is the reason; its presence is the exemption.
    if (this.reflector.getAllAndOverride<string>(ALLOWED_BEFORE_TOTP_KEY, [handler, controller])) return true;

    const request = context.switchToHttp().getRequest<PlatformRequest>();
    const user = request.user;
    // No user means PlatformSessionGuard already refused this request. Answering
    // again here would produce two different bodies for the same failure.
    if (!user) return true;
    if (!user.totpPending) return true;

    applyPlatformHeaders(context.switchToHttp().getResponse());
    throw new ForbiddenException({
      statusCode: 403,
      code: TOTP_ENROLMENT_REQUIRED_CODE,
      message: 'Authenticator enrolment is required before any other console action',
    });
  }
}
