/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * CRITICAL FIX (tenant-context / AsyncLocalStorage E2E investigation):
 *
 * ROOT CAUSE (confirmed via direct, real-HTTP bisection — not speculation):
 * TenantGuard used to call `this.tenantContext.enter(req.gymId)`, where
 * `enter()` is implemented via `AsyncLocalStorage.enterWith(store)`.
 * `enterWith()` only mutates the ALS store for the CURRENT synchronous/
 * microtask execution context at the moment it's called — it does NOT
 * "attach" the store to the request for the rest of the request's life.
 *
 * Real, timestamped instrumentation added directly into @nestjs/core's
 * internal `GuardsConsumer.tryActivate()`, `RouterExecutionContext.create()`,
 * and `InterceptorsConsumer.intercept()` (temporary, local-only, never
 * committed) proved EXACTLY where the store reverts to null:
 *
 *   - Immediately after TenantGuard's own `canActivate()` call returns
 *     (still inside GuardsConsumer's `for (const guard of guards)` loop,
 *     synchronously in the same tick as `enterWith()`), `getGymId()`
 *     still correctly returns the real gymId.
 *   - By the time `RouterExecutionContext.create()`'s outer
 *     `await fnCanActivate([req, res, next])` call *resolves* (i.e. one
 *     microtask/await-continuation later, back in the caller that
 *     originally invoked `fnCanActivate`), `getGymId()` is ALREADY back to
 *     null — even though no interceptor, no `setTimeout`, and no
 *     `$allOperations` code has run yet at that point.
 *
 * This is not a bug in any interceptor or in prisma.service.ts's
 * extension — it is a fundamental property of `enterWith()`: the ALS
 * frame it mutates belongs to whatever async execution context happened
 * to be active at the exact moment it was called (here: the inner
 * `Promise` continuation created by `GuardsConsumer.tryActivate()`'s own
 * `await this.pickResult(result)` for the previous guard, or the guard
 * loop's own execution frame), NOT to the outer request-handling
 * continuation that resumes after `await fnCanActivate(...)` in
 * `RouterExecutionContext.create()`. Once execution returns to that outer
 * frame, it never inherited the mutated store — so every guard positioned
 * after the one that calls `enterWith()`, in the SAME `tryActivate` loop,
 * still (coincidentally) sees the right value (confirmed: TenantGuard →
 * RolesGuard → LicenseGuard all showed the correct gymId in the
 * bisection trace), but the controller/interceptor/handler code that
 * resumes in the RouterExecutionContext's own outer continuation does
 * not.
 *
 * THE FIX: do not rely on `enterWith()` to make context "stick" across an
 * unrelated `await` boundary at all. Instead, use `AsyncLocalStorage.run()`
 * (via `TenantContextService.run()`, already used correctly by
 * registerGym's tenant-child-table writes) to synchronously wrap the
 * ENTIRE remaining request pipeline — every subsequent interceptor and
 * the controller handler itself — in one call. This interceptor is
 * registered as the outermost global `APP_INTERCEPTOR` (see app.module.ts
 * — it must be listed BEFORE AuditInterceptor so that its `next.handle()`
 * call represents "the rest of the interceptor chain + the handler",
 * not just the handler alone). Wrapping via RxJS `defer()` ensures
 * `next.handle()` (which recursively invokes every remaining interceptor
 * and, eventually, the controller method) is not actually CALLED until
 * subscription time, and that call happens synchronously inside the
 * `tenantContext.run()` callback — so the ALS frame is the ambient
 * context for that entire synchronous call stack, including every
 * microtask/`await` continuation spawned from within it (Node's
 * AsyncLocalStorage correctly propagates `run()`'s context across
 * `await`/Promise continuations that originate inside the `run()`
 * callback — this is exactly the guarantee `enterWith()` lacks across a
 * *pre-existing* continuation it did not itself originate).
 *
 * `TenantGuard` no longer calls `tenantContext.enter(...)` at all (see
 * that file's own comment) — it only sets `req.gymId`, which this
 * interceptor reads. Guards run before interceptors in every case (this
 * is a hard Nest execution-order guarantee, unaffected by the ALS bug
 * above), so `req.gymId` is always already correct by the time this
 * interceptor runs, including for the SUPER_ADMIN branch (`x-gym-id`
 * header, possibly null) and for `@Public()` routes (TenantGuard returns
 * true immediately without touching `req.gymId`, so it stays undefined —
 * this interceptor then correctly runs with `gymId=null`, which is
 * exactly the existing, intentional "no tenant" behavior pre-auth flows
 * already depend on via the SECURITY DEFINER preauth_* functions).
 */
import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common';
import { Observable, defer } from 'rxjs';
import { TenantContextService } from '../services/tenant-context.service';

@Injectable()
export class TenantContextInterceptor implements NestInterceptor {
  constructor(private readonly tenantContext: TenantContextService) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const req = context.switchToHttp().getRequest();
    const gymId: string | null | undefined = req?.gymId ?? null;
    // PHASE 4: carry the branch scope TenantGuard resolved into the async
    // context as well, so the Prisma extension can pin `branchId` on every
    // branch-scoped model for the whole request — including calls made from
    // code that has no access to the HTTP request object.
    const scope = req?.branchScope as
      | { unrestricted?: boolean; filterBranchId?: string | null }
      | undefined;
    const store = {
      gymId,
      branchId: scope?.filterBranchId ?? null,
      unrestrictedBranch: scope ? scope.unrestricted === true : true,
    };
    return defer(() => this.tenantContext.run(store, () => next.handle()));
  }
}
