import { Injectable, NestInterceptor, ExecutionContext, CallHandler, Logger } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Observable, tap, catchError, throwError } from 'rxjs';
import { PrismaService } from '../../prisma/prisma.service';
import { maskSensitive } from '../security/data-masking';
import { Prisma } from '@prisma/client';

export const AUDIT_KEY = 'audit';
export interface AuditMeta { action: string; entity: string; }

@Injectable()
export class AuditInterceptor implements NestInterceptor {
  private readonly logger = new Logger(AuditInterceptor.name);

  constructor(private prisma: PrismaService, private reflector: Reflector) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const meta = this.reflector.get<AuditMeta>(AUDIT_KEY, context.getHandler());
    if (!meta) return next.handle();

    const req = context.switchToHttp().getRequest();

    const boundedAuditValue = (value: unknown): Prisma.InputJsonValue => {
      const masked = maskSensitive(value || {}) as Prisma.InputJsonValue;
      const serialized = JSON.stringify(masked);
      return serialized.length <= 16_384
        ? masked
        : { truncated: true, originalBytes: Buffer.byteLength(serialized) };
    };

    const writeAudit = (result: unknown, status: string) => {
      try {
        const maskedBody = boundedAuditValue(req.body || {});
        const maskedResult = boundedAuditValue(result || {}) as Record<string, unknown>;
        const gymId = req.gymId || req.user?.gymId || null;
        const data = {
          gymId,
          userId: req.user?.id || req.user?.sub || null,
          actorId: req.user?.sub || req.user?.id || null,
          actorName: req.user?.name || null,
          action: `${meta.action}:${status}`,
          entity: meta.entity,
          entityId: (maskedResult?.id as string) || req.params?.id || null,
          ip: req.ip,
          metadata: { method: req.method, path: req.url, body: maskedBody, result: maskedResult as Prisma.InputJsonValue, errorStatus: status === 'FAILURE' ? true : undefined },
          meta: { method: req.method, path: req.url, body: maskedBody, result: maskedResult as Prisma.InputJsonValue, errorStatus: status === 'FAILURE' ? true : undefined },
        };
        // FIX: this write runs fire-and-forget, often AFTER the request's
        // tenant context has been torn down — the standalone Prisma wrapper
        // then sees no app.gym_id and AuditLog's FORCE RLS rejected every
        // insert ("new row violates row-level security policy for table
        // AuditLog"), silently wiping the audit trail. withTenant() pins the
        // gym context on the same connection as the insert.
        // ROUND 14 (security review, PHASE F): a failed audit write was
        // silently swallowed (`.catch(() => {})`) — the audit trail lost rows
        // without a trace. Log it so the gap is observable.
        if (gymId) {
          this.prisma.withTenant(gymId, (tx) => tx.auditLog.create({ data })).catch((e) => { this.logger.error(`audit write failed (${status}): ${(e as Error)?.message}`); });
        } else {
          this.prisma.auditLog.create({ data }).catch((e) => { this.logger.error(`audit write failed (${status}): ${(e as Error)?.message}`); });
        }
      } catch (e) {
        this.logger.warn(`audit persistence failed: ${(e as Error).message}`);
      }
    };

    return next.handle().pipe(
      tap((result) => writeAudit(result, 'SUCCESS')),
      catchError((err) => { writeAudit({}, 'FAILURE'); return throwError(() => err); }),
    );
  }
}
