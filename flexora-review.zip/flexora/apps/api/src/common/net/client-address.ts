/**
 * PACK 2 · STEP 0.2 — which address may a trust decision believe?
 *
 * The problem this file exists to solve
 * -------------------------------------
 * A gym's "you are on the gym network" check has to answer one question: what is
 * the address of the device that made this request? There are exactly two
 * sources, and only one of them is honest:
 *
 *   • `req.socket.remoteAddress` — the peer of the TCP connection. The client
 *     cannot write it. But behind nginx (or any reverse proxy, or a CDN) the
 *     peer is THE PROXY, so every member of the gym looks like one address and
 *     an allowlist of gym addresses never matches. That was the shipped bug.
 *
 *   • `X-Forwarded-For` — a request HEADER. Any client can write it. It is only
 *     meaningful when a proxy we control appended the address IT saw. Trusting
 *     it in any other situation turns the gate into a self-certification.
 *
 * So neither alone is right, and "just use req.ip" is wrong in the dangerous
 * direction: with `app.set('trust proxy', 1)` Express resolves `req.ip` from the
 * header EVEN WHEN THE API IS REACHABLE DIRECTLY, so a client can send
 * `X-Forwarded-For: <gym address>` and walk through the gate from anywhere.
 *
 * The rule implemented here
 * -------------------------
 *   1. No socket address  → unknown. Fail closed; never fall back to a header.
 *   2. TRUST_PROXY_HOPS = 0 → the socket peer. The header is never read.
 *   3. The socket peer is NOT one of the configured trusted proxies → the
 *      socket peer. The header is never read (this is the "forged header, no
 *      proxy" case).
 *   4. Otherwise the request really did arrive through proxies: take the
 *      TRUST_PROXY_HOPS-th entry from the RIGHT of the X-Forwarded-For chain
 *      (the last hop we do not trust), and verify that every entry to the right
 *      of it is itself a trusted proxy. Entries further left were written by the
 *      client and are ignored — a client that prepends `6.6.6.6` cannot move
 *      the answer.
 *   5. Anything malformed (unparsable entry, missing entries, chain shorter than
 *      the configured hops) → the socket peer. A broken chain is not evidence.
 *
 * The result is a decision that is right in both deployments: direct (socket) and
 * behind nginx/Cloudflare (the real client, taken from the header only because a
 * trusted proxy appended it).
 *
 * Trusted proxy list
 * ------------------
 * `TRUSTED_PROXY_CIDRS` (comma separated). Default: loopback, RFC1918,
 * link-local and IPv6 loopback — i.e. the shipped Docker/nginx setup, where the
 * proxy reaches the API over the compose bridge (172.16.0.0/12). A proxy on a
 * public address (a CDN, or nginx on another host) MUST be listed there; until it
 * is, the gate falls back to the proxy address, which fails closed rather than
 * trusting a header.
 */
import ipaddr from 'ipaddr.js';

/** Where the address in a deployment comes from — kept for the audit trail. */
export type AddressSource = 'socket' | 'forwarded' | 'unknown';

export interface ClientAddress {
  /** Canonical address, or null when nothing trustworthy is known. */
  address: string | null;
  /** How it was decided. Logged, never trusted by a gate. */
  source: AddressSource;
  /** True when a header was present but deliberately ignored. */
  headerIgnored: boolean;
}

export interface AddressRequest {
  ip?: string;
  socket?: { remoteAddress?: string };
  headers?: Record<string, string | string[] | undefined>;
}

export const DEFAULT_TRUSTED_PROXY_CIDRS = [
  '127.0.0.0/8', // loopback
  '::1/128', // IPv6 loopback
  '10.0.0.0/8', // RFC1918 / docker bridge
  '172.16.0.0/12', // RFC1918 / docker compose default network
  '192.168.0.0/16', // RFC1918 / LAN
  '169.254.0.0/16', // link-local (cloud metadata networks, some LBs)
];

/** Canonicalise an address; null when it is not an address at all. */
export function canonicalIp(raw: string | undefined | null): string | null {
  const value = (raw ?? '').trim();
  if (!value) return null;
  // strip a bracketed IPv6 literal and an optional :port, as some proxies write
  // `[2001:db8::1]:443`; a plain IPv4 with :port is handled by the parser below
  const bracket = /^\[([^\]]+)\](?::\d+)?$/.exec(value);
  const candidate = bracket ? bracket[1] : value;
  try {
    const addr = ipaddr.parse(candidate);
    if (addr.kind() === 'ipv6' && (addr as ipaddr.IPv6).isIPv4MappedAddress()) {
      return (addr as ipaddr.IPv6).toIPv4Address().toString();
    }
    return addr.toString();
  } catch {
    // an IPv4 address with a port, e.g. "41.33.10.7:51234" (some proxies/express
    // write this into X-Forwarded-For)
    const v4port = /^(\d{1,3}(?:\.\d{1,3}){3}):\d+$/.exec(candidate);
    if (v4port) return canonicalIp(v4port[1]);
    return null;
  }
}

/** Parse the configured CIDR list. Invalid entries are dropped, not trusted. */
export function parseTrustedProxies(raw: string | undefined | null): string[] {
  const list = (raw ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  if (list.length === 0) return DEFAULT_TRUSTED_PROXY_CIDRS;
  const valid: string[] = [];
  for (const entry of list) {
    try {
      if (entry.includes('/')) ipaddr.parseCIDR(entry);
      else ipaddr.parse(entry);
      valid.push(entry);
    } catch {
      // a typo must never widen trust: it is ignored
    }
  }
  return valid.length > 0 ? valid : DEFAULT_TRUSTED_PROXY_CIDRS;
}

/** Trusted proxies from the environment (defaults when unset/empty). */
export function trustedProxiesFromEnv(env: NodeJS.ProcessEnv = process.env): string[] {
  return parseTrustedProxies(env.TRUSTED_PROXY_CIDRS);
}

/** Is this address one of the proxies we deliberately sit behind? */
export function isTrustedProxy(ip: string, trusted: string[] = DEFAULT_TRUSTED_PROXY_CIDRS): boolean {
  const canonical = canonicalIp(ip);
  if (!canonical) return false;
  try {
    const addr = ipaddr.parse(canonical);
    return trusted.some((entry) => {
      try {
        if (entry.includes('/')) return addr.match(ipaddr.parseCIDR(entry));
        return addr.toString() === canonicalIp(entry);
      } catch {
        return false;
      }
    });
  } catch {
    return false;
  }
}

/** Split X-Forwarded-For into canonical addresses; null when any entry is junk. */
function forwardedChain(header: string | string[] | undefined): string[] | null {
  if (header === undefined || header === null) return [];
  const raw = Array.isArray(header) ? header.join(',') : header;
  const parts = raw
    .split(',')
    .map((s) => s.trim())
    .filter((s) => s.length > 0);
  if (parts.length === 0) return [];
  const out: string[] = [];
  for (const part of parts) {
    const canonical = canonicalIp(part);
    if (!canonical) return null; // one unparsable entry poisons the whole chain
    out.push(canonical);
  }
  return out;
}

/**
 * The address a trust decision may use, and how it was decided.
 *
 * `hops` is TRUST_PROXY_HOPS (validated 0..3 elsewhere). Never throws.
 */
export function resolveClientAddress(
  req: AddressRequest,
  opts: { hops: number; trustedProxies?: string[] },
): ClientAddress {
  const trusted = opts.trustedProxies ?? DEFAULT_TRUSTED_PROXY_CIDRS;
  const socket = canonicalIp(req.socket?.remoteAddress);
  const header = req.headers?.['x-forwarded-for'];

  if (!socket) return { address: null, source: 'unknown', headerIgnored: header !== undefined };

  const hops = Number.isInteger(opts.hops) ? opts.hops : 0;
  if (hops <= 0) {
    return { address: socket, source: 'socket', headerIgnored: header !== undefined };
  }
  if (!isTrustedProxy(socket, trusted)) {
    // the connection did not come from a proxy we configured: whatever the
    // header says, the caller wrote it themselves
    return { address: socket, source: 'socket', headerIgnored: header !== undefined };
  }

  const chain = forwardedChain(header);
  if (!chain || chain.length < hops) {
    // absent, malformed, or shorter than the number of proxies we know about —
    // the chain cannot be explained by our topology, so it is not evidence
    return { address: socket, source: 'socket', headerIgnored: header !== undefined };
  }

  const index = chain.length - hops;
  const candidate = chain[index];
  // every hop to the right of the answer must be one of our proxies
  for (let i = index + 1; i < chain.length; i += 1) {
    if (!isTrustedProxy(chain[i], trusted)) {
      return { address: socket, source: 'socket', headerIgnored: true };
    }
  }
  return { address: candidate, source: 'forwarded', headerIgnored: false };
}
