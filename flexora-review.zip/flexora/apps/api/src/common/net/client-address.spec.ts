/**
 * PACK 2 · STEP 0.2 — the truth table of the network-gate address.
 *
 * Each test names a deployment that really exists, because that is where the
 * wrong answer hurts:
 *   • direct API, client forges the header          → must be ignored
 *   • behind nginx with one trusted hop             → must be the real client
 *   • behind nginx, client ALSO prepends a fake IP  → must still be the real one
 *   • hops = 0                                      → header is never read
 *   • two hops with a configured CDN                → the client, not the CDN
 *   • broken / short / junk chain                   → socket, fail closed
 *   • no socket at all                              → null, fail closed
 */
import {
  canonicalIp,
  DEFAULT_TRUSTED_PROXY_CIDRS,
  isTrustedProxy,
  parseTrustedProxies,
  resolveClientAddress,
} from './client-address';

const DOCKER_PROXY = '172.18.0.5';     // nginx on the compose bridge
const PUBLIC_CLIENT = '41.33.10.7';    // a member's phone on mobile data
const GYM_ADDRESS = '197.45.20.10';    // what a cheater would claim to be
const CDN = '203.0.113.5';             // a public CDN edge (not private)

describe('resolveClientAddress — which address a trust decision may use', () => {
  describe('direct connection (no proxy in front)', () => {
    it('IGNOBES a forged X-Forwarded-For and returns the socket peer', () => {
      const d = resolveClientAddress(
        { socket: { remoteAddress: PUBLIC_CLIENT }, headers: { 'x-forwarded-for': GYM_ADDRESS } },
        { hops: 1 },
      );
      expect(d).toEqual({ address: PUBLIC_CLIENT, source: 'socket', headerIgnored: true });
    });

    it('returns the socket peer when no header is present', () => {
      const d = resolveClientAddress({ socket: { remoteAddress: PUBLIC_CLIENT } }, { hops: 1 });
      expect(d).toEqual({ address: PUBLIC_CLIENT, source: 'socket', headerIgnored: false });
    });

    it('ignores the header even when the caller claims to be a private address', () => {
      // the classic "I am on the gym Wi-Fi" forgery, sent from a phone on 4G
      const d = resolveClientAddress(
        { socket: { remoteAddress: PUBLIC_CLIENT }, headers: { 'x-forwarded-for': '10.0.0.1' } },
        { hops: 1 },
      );
      expect(d.address).toBe(PUBLIC_CLIENT);
    });
  });

  describe('behind nginx (one trusted hop) — the deployment this step fixes', () => {
    it('takes the real client appended by the proxy', () => {
      const d = resolveClientAddress(
        { socket: { remoteAddress: DOCKER_PROXY }, headers: { 'x-forwarded-for': PUBLIC_CLIENT } },
        { hops: 1 },
      );
      expect(d).toEqual({ address: PUBLIC_CLIENT, source: 'forwarded', headerIgnored: false });
    });

    it('is not moved by an entry the CLIENT prepended', () => {
      // client sent "197.45.20.10", nginx appended the address it really saw
      const d = resolveClientAddress(
        {
          socket: { remoteAddress: DOCKER_PROXY },
          headers: { 'x-forwarded-for': `${GYM_ADDRESS}, ${PUBLIC_CLIENT}` },
        },
        { hops: 1 },
      );
      expect(d.address).toBe(PUBLIC_CLIENT);
    });

    it('normalises the IPv4-mapped IPv6 form docker/express sometimes use', () => {
      const d = resolveClientAddress(
        {
          socket: { remoteAddress: '::ffff:172.18.0.5' },
          headers: { 'x-forwarded-for': PUBLIC_CLIENT },
        },
        { hops: 1 },
      );
      expect(d.address).toBe(PUBLIC_CLIENT);
    });

    it('honours a proxy on a public address when it is configured as trusted', () => {
      const d = resolveClientAddress(
        { socket: { remoteAddress: CDN }, headers: { 'x-forwarded-for': PUBLIC_CLIENT } },
        { hops: 1, trustedProxies: [...DEFAULT_TRUSTED_PROXY_CIDRS, CDN] },
      );
      expect(d.address).toBe(PUBLIC_CLIENT);
    });

    it('does NOT trust a public proxy that was never configured', () => {
      const d = resolveClientAddress(
        { socket: { remoteAddress: CDN }, headers: { 'x-forwarded-for': GYM_ADDRESS } },
        { hops: 1 },
      );
      expect(d).toEqual({ address: CDN, source: 'socket', headerIgnored: true });
    });
  });

  describe('TRUST_PROXY_HOPS = 0', () => {
    it('never reads the header, even from a private peer', () => {
      const d = resolveClientAddress(
        { socket: { remoteAddress: DOCKER_PROXY }, headers: { 'x-forwarded-for': GYM_ADDRESS } },
        { hops: 0 },
      );
      expect(d).toEqual({ address: DOCKER_PROXY, source: 'socket', headerIgnored: true });
    });
  });

  describe('two hops (CDN → nginx → API)', () => {
    const trusted = [...DEFAULT_TRUSTED_PROXY_CIDRS, CDN];

    it('picks the client and verifies the CDN is one of ours', () => {
      const d = resolveClientAddress(
        {
          socket: { remoteAddress: DOCKER_PROXY },
          headers: { 'x-forwarded-for': `${PUBLIC_CLIENT}, ${CDN}` },
        },
        { hops: 2, trustedProxies: trusted },
      );
      expect(d.address).toBe(PUBLIC_CLIENT);
    });

    it('refuses the chain when the nearer hop is not a configured proxy', () => {
      const d = resolveClientAddress(
        {
          socket: { remoteAddress: DOCKER_PROXY },
          headers: { 'x-forwarded-for': `${PUBLIC_CLIENT}, ${GYM_ADDRESS}` },
        },
        { hops: 2, trustedProxies: trusted },
      );
      expect(d).toEqual({ address: DOCKER_PROXY, source: 'socket', headerIgnored: true });
    });
  });

  describe('chains that cannot be explained are not evidence', () => {
    it('falls back to the socket when the chain is shorter than the hop count', () => {
      const d = resolveClientAddress(
        { socket: { remoteAddress: DOCKER_PROXY }, headers: { 'x-forwarded-for': PUBLIC_CLIENT } },
        { hops: 2 },
      );
      expect(d).toEqual({ address: DOCKER_PROXY, source: 'socket', headerIgnored: true });
    });

    it('lets a junk entry poison the chain even when another entry would match', () => {
      // hops=1 with "client, junk": skipping the junk would leave a single
      // entry that LOOKS like a valid answer. It is not — nobody we trust wrote
      // the whole chain, so the socket peer is the answer.
      const d = resolveClientAddress(
        { socket: { remoteAddress: DOCKER_PROXY }, headers: { 'x-forwarded-for': `${PUBLIC_CLIENT}, not-an-ip` } },
        { hops: 1 },
      );
      expect(d).toEqual({ address: DOCKER_PROXY, source: 'socket', headerIgnored: true });
    });

    it('falls back to the socket when any entry is not an address', () => {
      const d = resolveClientAddress(
        {
          socket: { remoteAddress: DOCKER_PROXY },
          headers: { 'x-forwarded-for': `${PUBLIC_CLIENT}, not-an-ip` },
        },
        { hops: 2 },
      );
      expect(d.address).toBe(DOCKER_PROXY);
    });

    it('falls back to the socket when the proxy forwarded no header at all', () => {
      const d = resolveClientAddress({ socket: { remoteAddress: DOCKER_PROXY } }, { hops: 1 });
      expect(d).toEqual({ address: DOCKER_PROXY, source: 'socket', headerIgnored: false });
    });
  });

  describe('nothing to trust', () => {
    it('returns null when there is no socket address — never the header', () => {
      const d = resolveClientAddress(
        { ip: GYM_ADDRESS, headers: { 'x-forwarded-for': GYM_ADDRESS } },
        { hops: 1 },
      );
      expect(d).toEqual({ address: null, source: 'unknown', headerIgnored: true });
    });

    it('treats a nonsense hop count as zero rather than as "trust everything"', () => {
      const d = resolveClientAddress(
        { socket: { remoteAddress: DOCKER_PROXY }, headers: { 'x-forwarded-for': GYM_ADDRESS } },
        { hops: Number.NaN },
      );
      expect(d.address).toBe(DOCKER_PROXY);
    });
  });
});

describe('canonicalIp', () => {
  it.each([
    ['41.33.10.7', '41.33.10.7'],
    [' 41.33.10.7 ', '41.33.10.7'],
    ['::ffff:41.33.10.7', '41.33.10.7'],
    ['41.33.10.7:51234', '41.33.10.7'],
    ['[2001:db8::1]:443', '2001:db8::1'],
    ['not-an-ip', null],
    ['', null],
  ])('%s → %s', (input, expected) => {
    expect(canonicalIp(input)).toBe(expected);
  });
});

describe('trusted proxy list', () => {
  it('drops invalid entries instead of widening trust', () => {
    const list = parseTrustedProxies('10.0.0.0/8, not-a-cidr, 203.0.113.5');
    expect(list).toEqual(['10.0.0.0/8', '203.0.113.5']);
  });

  it('falls back to the defaults when the variable is empty', () => {
    expect(parseTrustedProxies('')).toEqual(DEFAULT_TRUSTED_PROXY_CIDRS);
    expect(parseTrustedProxies(undefined)).toEqual(DEFAULT_TRUSTED_PROXY_CIDRS);
  });

  it('matches single addresses and ranges, IPv4 and IPv6', () => {
    expect(isTrustedProxy('172.18.0.5')).toBe(true);
    expect(isTrustedProxy('127.0.0.1')).toBe(true);
    expect(isTrustedProxy('::1')).toBe(true);
    expect(isTrustedProxy('::ffff:10.1.2.3')).toBe(true);
    expect(isTrustedProxy('41.33.10.7')).toBe(false);
    expect(isTrustedProxy('nonsense')).toBe(false);
  });
});
