/**
 * FLEXORA Gym OS — Role-based branch scoping (Phase 4)
 * © 2024 Ammar Allam. All rights reserved.
 *
 * WHY THIS FILE EXISTS
 * ────────────────────
 * Branch filtering used to be a purely *presentational* concern: every staff
 * role saw the same branch picker, and the only thing standing between a
 * receptionist and another branch's members was a query parameter the browser
 * happened to send. Changing `?branchId=` by hand — or calling the API
 * directly with curl — returned another branch's data.
 *
 * The rule now is:
 *   • OWNER / MANAGER (general manager) / SUPER_ADMIN → unrestricted. They see
 *     every branch and may filter by any of them (exactly the old behaviour).
 *   • EVERY other staff role (RECEPTION, COACH, ACCOUNTANT, custom roles…) →
 *     pinned to the single branch stored on their user row. They may not see,
 *     create, update or delete anything that belongs to another branch, and
 *     they may not widen the filter by passing `branchId=all` (or omitting it).
 *   • A restricted role with NO branch assigned is pinned to an impossible
 *     branch id, i.e. deny-by-default — never "all branches".
 *
 * ENFORCEMENT POINTS (defence in depth — none of them relies on the UI):
 *   1. TenantGuard  — rewrites/rejects every branch-carrying query & body
 *                     parameter for restricted roles, and pins `req.branchScope`.
 *   2. PrismaService `$allOperations` — injects `branchId = <scope>` into every
 *                     query against a branch-scoped model, so an individual
 *                     record (e.g. GET /members/<id-of-another-branch>) is
 *                     invisible even when the service forgets to filter.
 *   3. BranchesService — a restricted user only ever sees their own branch.
 */

/** Sentinel accepted by the UI/API meaning "do not filter by branch". */
export const BRANCH_ALL = 'all';

/**
 * Value used to pin a restricted user who has NO branch assigned. It can never
 * match a real cuid, so every branch-scoped query returns zero rows: deny by
 * default instead of silently falling back to "all branches".
 */
export const BRANCH_SCOPE_NO_BRANCH = '__no_branch_assigned__';

/**
 * Roles allowed to work across every branch. Everything else (including
 * unknown/new roles) is restricted — the safe default.
 */
export const BRANCH_UNRESTRICTED_ROLES: ReadonlySet<string> = new Set([
  'OWNER',
  'MANAGER',
  'SUPER_ADMIN',
]);

/**
 * Request/body parameters that carry a branch id. `fromBranchId`/`toBranchId`
 * are the stock-transfer pair: a restricted user may only ever use their own
 * branch for both, which makes cross-branch transfers impossible by
 * construction rather than by a separate rule.
 */
export const BRANCH_PARAM_KEYS: readonly string[] = Object.freeze([
  'branchId',
  'fromBranchId',
  'toBranchId',
]);

/**
 * PHASE 8 — models where a NULL `branchId` means "belongs to the whole gym",
 * not "belongs to nobody".
 *
 * A product is either assigned to one branch (visible there and nowhere else)
 * or left unassigned, which makes it part of the gym-wide catalogue that every
 * branch sells. Reads for a restricted role therefore match their own branch
 * OR the unassigned rows; they can still never see another branch's
 * assignment. Everything else keeps the strict `branchId = <own>` rule.
 */
export const BRANCH_SCOPE_INCLUDE_UNASSIGNED: ReadonlySet<string> = new Set(['Product']);

/** Prisma models that carry a `branchId` column and must therefore be scoped. */
/**
 * Models whose table actually carries a `branchId` column.
 *
 * Derived at runtime from the Prisma DMMF instead of being hand-maintained.
 * The distinction matters: injecting `{ branchId }` into a model that has no
 * such column makes Prisma throw `PrismaClientValidationError` (found live in
 * Phase 4 verification — a hand-written list contained `Product`, which has no
 * `branchId` column yet, so every `GET /products` for a branch-restricted user
 * returned HTTP 500). Deriving the set from the schema means the scoping can
 * never drift out of sync with `schema.prisma` again: the day a model gains the
 * column it is scoped automatically, and a model without it is never touched.
 */
function deriveBranchScopedModels(): { models: ReadonlySet<string>; source: string } {
  const FALLBACK = [
    'User',
    'KioskDevice',
    'Member',
    'Attendance',
    'Sale',
    'Expense',
    'Transaction',
    'ClassTemplate',
    'ClassSession',
    'PtSession',
    'Invitation',
    'Lead',
    'StaffAttendance',
    'PurchaseOrder',
    'GoodsReceipt',
    'StockMovement',
    'ProductEvent',
  ];
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const { Prisma } = require('@prisma/client');
    const models: Array<{ name: string; fields?: Array<{ name: string }> }> =
      Prisma?.dmmf?.datamodel?.models ?? [];
    const derived = models
      .filter((m) => Array.isArray(m.fields) && m.fields.some((f) => f.name === 'branchId'))
      .map((m) => m.name);
    if (derived.length) return { models: new Set(derived), source: 'prisma-dmmf' };
  } catch {
    // Fall through to the static list (e.g. Prisma client not generated yet).
  }
  return { models: new Set(FALLBACK), source: 'static-fallback' };
}

const _scoped = deriveBranchScopedModels();

/** Set of Prisma model names that get `branchId` injected. */
export const BRANCH_SCOPED_MODELS: ReadonlySet<string> = _scoped.models;

/** Where the set above came from - 'prisma-dmmf' in normal operation. */
export const BRANCH_SCOPED_MODELS_SOURCE: string = _scoped.source;

export interface BranchScope {
  /** Upper-cased staff role, or '' when unknown. */
  role: string;
  /** True for OWNER / MANAGER / SUPER_ADMIN — they may use every branch. */
  unrestricted: boolean;
  /** For restricted users: the ONLY branch they may touch (null = unassigned). */
  branchId: string | null;
  /**
   * Value that must be forced into every branch filter for a restricted user.
   * null for unrestricted users (meaning "do not force anything").
   */
  filterBranchId: string | null;
  /** Why the scope turned out the way it did — surfaced for logs/debugging. */
  source: 'unrestricted-role' | 'assigned-branch' | 'unassigned-branch';
}

/**
 * The single source of truth for "which branches may this user touch?".
 *
 * Pure and dependency-free so it can be unit-tested and reused by guards,
 * interceptors, the Prisma extension and controllers alike.
 */
export function resolveBranchScope(
  user: { role?: string | null; branchId?: string | null } | null | undefined,
): BranchScope {
  const role = String(user?.role ?? '').toUpperCase();
  if (BRANCH_UNRESTRICTED_ROLES.has(role)) {
    return { role, unrestricted: true, branchId: null, filterBranchId: null, source: 'unrestricted-role' };
  }
  const branchId = user?.branchId ? String(user.branchId) : null;
  return {
    role,
    unrestricted: false,
    branchId,
    filterBranchId: branchId ?? BRANCH_SCOPE_NO_BRANCH,
    source: branchId ? 'assigned-branch' : 'unassigned-branch',
  };
}

/** True when `value` means "no branch filter" rather than a real branch id. */
export function isAnyBranchValue(value: unknown): boolean {
  if (value === undefined || value === null) return true;
  const s = String(value).trim();
  return s === '' || s.toLowerCase() === BRANCH_ALL;
}

/**
 * Compare an explicit `branchId` a caller supplied with the scope they are
 * allowed to use. Returns true when the value is acceptable for this scope
 * (i.e. it is empty/"all", which gets re-pointed at the pinned branch).
 */
export function branchValueIsAllowed(
  scope: BranchScope,
  value: unknown,
): boolean {
  if (scope.unrestricted) return true;
  return isAnyBranchValue(value) || String(value) === scope.filterBranchId;
}

/**
 * Mutation applied by TenantGuard to the incoming request.
 *
 * `where` receives the raw query object, `body` the parsed JSON body. Both are
 * mutated IN PLACE so that every existing `@Query('branchId')` / `body.branchId`
 * reader in the codebase — including code written later — is automatically
 * constrained without having to be touched.
 *
 * Returns the list of parameters that were rejected (for logging/tests).
 */
export function applyBranchScopeToRequest(
  scope: BranchScope,
  query: Record<string, unknown> | undefined,
  body: Record<string, unknown> | undefined,
): { rejected: string[] } {
  if (scope.unrestricted) return { rejected: [] };
  const forced = scope.filterBranchId as string;
  const rejected: string[] = [];

  for (const key of BRANCH_PARAM_KEYS) {
    for (const bag of [query, body]) {
      if (!bag || typeof bag !== 'object') continue;
      if (!Object.prototype.hasOwnProperty.call(bag, key)) continue;
      const raw = bag[key];
      if (isAnyBranchValue(raw) || String(raw) === forced) {
        // Either "no filter" or already our own branch → pin it explicitly so
        // the downstream service can never fall back to "all branches".
        bag[key] = forced;
      } else {
        rejected.push(`${key}=${String(raw)}`);
        bag[key] = forced;
      }
    }
  }

  // Even when the caller sent nothing at all we still pin the filter: an
  // omitted branchId means "all branches" for an unrestricted user and MUST
  // NOT mean the same thing for a restricted one.
  if (query && typeof query === 'object' && !Object.prototype.hasOwnProperty.call(query, 'branchId')) {
    query.branchId = forced;
  }

  return { rejected };
}

/**
 * Writes the normalised query object back onto the request as an OWN data
 * property.
 *
 * WHY THIS IS NECESSARY (found live, Phase 4): this project runs Express 5,
 * where `req.query` is defined as a *prototype getter* with no setter that
 * re-parses the query string on EVERY access:
 *
 *   Object.getOwnPropertyDescriptor(express.request, 'query')
 *     => { get: [Function: query], set: undefined, configurable: true }
 *
 * Mutating the object returned by `req.query` therefore throws away the
 * change on the very next read, and NestJS's own `@Query('branchId')` decorator
 * reads `req.query` again when the handler runs. The visible symptom was
 * `GET /members?branchId=all` reaching the service with the literal string
 * "all" and returning zero rows instead of the caller's own branch.
 *
 * Defining a configurable data property on the request *instance* shadows the
 * prototype getter for the rest of the request, so every later reader —
 * Nest's param decorators included — sees the normalised query.
 */
export function pinRequestQuery(
  req: { query?: unknown },
  normalisedQuery: Record<string, unknown> | undefined,
): void {
  if (!normalisedQuery) return;
  try {
    Object.defineProperty(req, 'query', {
      value: normalisedQuery,
      writable: true,
      configurable: true,
      enumerable: true,
    });
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (req as any).query = normalisedQuery;
  } catch {
    // A frozen/sealed request object would make this impossible; the Prisma
    // branch scope still enforces the rule in that case.
  }
}

/**
 * Shapes the `args` object of a Prisma operation so the query can only ever
 * touch rows of `branchId`.
 *
 * A top-level merge is used for every operation shape: Prisma ANDs sibling
 * keys together, so `{ ...where, branchId }` is equivalent to
 * `{ AND: [where, { branchId }] }` while ALSO staying valid for the
 * unique-shaped operations (`findUnique` / `update` / `delete` / `upsert`),
 * which require a unique selector at the top level (Prisma ≥ 5 "extended where
 * unique"). This keeps one implementation for every operation.
 */
export function scopePrismaArgs(
  model: string,
  action: string,
  args: Record<string, any> | undefined,
  branchId: string,
): Record<string, any> | undefined {
  if (!BRANCH_SCOPED_MODELS.has(model)) return args;
  const a: Record<string, any> = { ...(args || {}) };

  const pinWhere = () => {
    const base: Record<string, any> = { ...(a.where && typeof a.where === 'object' ? a.where : {}) };
    if (!BRANCH_SCOPE_INCLUDE_UNASSIGNED.has(model)) {
      a.where = { ...base, branchId };
      return;
    }
    // Gym-wide rows stay visible; a caller-supplied branchId is replaced by
    // the scope rule so it can never widen the query.
    const { branchId: _ignored, ...rest } = base;
    const scopeFilter = { OR: [{ branchId }, { branchId: null }] };
    const existingAnd = rest.AND;
    if (existingAnd) {
      rest.AND = [...(Array.isArray(existingAnd) ? existingAnd : [existingAnd]), scopeFilter];
      a.where = rest;
    } else {
      a.where = { ...rest, ...scopeFilter };
    }
  };

  switch (action) {
    case 'findUnique':
    case 'findUniqueOrThrow':
    case 'findFirst':
    case 'findFirstOrThrow':
    case 'findMany':
    case 'count':
    case 'aggregate':
    case 'groupBy':
    case 'update':
    case 'updateMany':
    case 'delete':
    case 'deleteMany':
      pinWhere();
      break;
    case 'create':
      a.data = { ...(a.data && typeof a.data === 'object' ? a.data : {}), branchId };
      break;
    case 'createMany':
      if (Array.isArray(a.data)) a.data = a.data.map((d) => ({ ...d, branchId }));
      else a.data = { ...(a.data && typeof a.data === 'object' ? a.data : {}), branchId };
      break;
    case 'upsert':
      pinWhere();
      a.create = { ...(a.create && typeof a.create === 'object' ? a.create : {}), branchId };
      a.update = { ...(a.update && typeof a.update === 'object' ? a.update : {}), branchId };
      break;
    default:
      // Unknown/new operation: pin the where if there is one, otherwise leave
      // it alone rather than corrupting the args.
      if (a.where) pinWhere();
      break;
  }
  return a;
}
