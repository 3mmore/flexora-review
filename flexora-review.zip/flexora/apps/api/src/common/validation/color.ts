/**
 * FLEXORA Gym OS — brand color validation
 * © 2024 Ammar Allam. All rights reserved.
 *
 * The gym's accent color is written into CSS custom properties that the whole
 * tenant shell derives from: `--brand` (the hex) and `--brand-rgb` (the same
 * color as "r, g, b", used by every rgba() tint). If the two ever disagree the
 * UI shows one hue on solid fills and another on borders/glows — which is
 * exactly the "accent looks wrong / half the app is still gold" class of bug.
 *
 * `--brand-rgb` can only be derived from a real hex value, so the API refuses
 * anything else at the boundary instead of storing a color the frontend cannot
 * render.
 */
export const HEX_COLOR_RE = /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/;
export const HEX_COLOR_MESSAGE = 'color must be a hex value like #6366F1';

export function isHexColor(value: unknown): value is string {
  return typeof value === 'string' && HEX_COLOR_RE.test(value.trim());
}

/** Normalizes #abc → #aabbcc and lowercases; returns null for invalid input. */
export function normalizeHexColor(value: unknown): string | null {
  if (!isHexColor(value)) return null;
  const hex = String(value).trim().toLowerCase();
  if (hex.length === 7) return hex;
  return `#${hex[1]}${hex[1]}${hex[2]}${hex[2]}${hex[3]}${hex[3]}`;
}
