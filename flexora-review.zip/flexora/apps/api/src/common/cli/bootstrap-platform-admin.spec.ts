/**
 * PHASE P6 — `npm run bootstrap:admin` must keep refusing to run unless it is
 * explicitly confirmed, and must keep refusing when a platform admin already
 * exists. The command itself is unchanged (P6 says: keep it, do not extend it);
 * what was missing is a TEST that pins those two refusals, so a future edit
 * cannot silently turn a guarded first-admin bootstrap into an unguarded one.
 *
 * The CLI is spawned for real (ts-node, exactly as the npm script does) because
 * the guards live in its argument handling and its pre-flight database check —
 * mocking them would test the mock. Nothing here writes to the database:
 *   T1  no --confirm            -> exit 1, refuses before touching any data
 *   T2  --confirm, admin exists -> exit 1, names the refusal, creates nothing
 *   T3  --help                  -> exit 0 with usage (negative control: the
 *                                  command still works, the guards did not
 *                                  brick it)
 * T2 needs a database that already has a platform admin, which is the state the
 * canonical test environment is seeded into; if that precondition is missing the
 * test FAILS loudly rather than skipping, because a silently skipped guard test
 * is worse than no test.
 */
import { spawnSync } from 'child_process';
import { existsSync } from 'fs';
import { join } from 'path';

const API_DIR = join(__dirname, '..', '..', '..');
const SCRIPT = join(API_DIR, 'prisma', 'bootstrap-platform-admin.ts');
const TS_NODE = join(API_DIR, '..', '..', 'node_modules', '.bin', 'ts-node');
const SPAWN_TIMEOUT_MS = 120_000;

function runCli(args: string[], stdin = '') {
  const bin = existsSync(TS_NODE) ? TS_NODE : 'npx';
  const fullArgs = existsSync(TS_NODE) ? args : ['ts-node', ...args];
  const res = spawnSync(bin, fullArgs, {
    cwd: API_DIR,
    input: stdin,
    encoding: 'utf8',
    timeout: SPAWN_TIMEOUT_MS,
    env: { ...process.env, NODE_OPTIONS: '' },
  });
  const out = `${res.stdout || ''}${res.stderr || ''}`;
  return { status: res.status, out };
}

describe('PHASE P6 — bootstrap:admin guard tests', () => {
  it('the bootstrap script and its npm script still exist (nothing was renamed away)', () => {
    expect(existsSync(SCRIPT)).toBe(true);
    const pkg = JSON.parse(require('fs').readFileSync(join(API_DIR, 'package.json'), 'utf8'));
    expect(pkg.scripts['bootstrap:admin']).toMatch(/bootstrap-platform-admin\.ts/);
  });

  it('T1 refuses without --confirm, before touching any data', () => {
    const { status, out } = runCli([SCRIPT]);
    expect(status).toBe(1);
    expect(out).toMatch(/refusing to run without an explicit --confirm/);
    expect(out).toMatch(/--confirm/);
    // it must not have proceeded to the password prompt or to a write
    expect(out).not.toMatch(/platform admin created/i);
  }, SPAWN_TIMEOUT_MS + 10_000);

  it('T2 refuses when a platform admin already exists, and names that reason', async () => {
    // Precondition, checked rather than assumed: the seeded test database has a
    // PLATFORM_ADMIN. Without it the guard cannot be observed at all.
    const { PrismaClient } = require('@prisma/client');
    const prisma = new PrismaClient();
    let admins = 0;
    try {
      // Platform admins are their own model (PLATFORM_ADMIN is not a value of the
      // User.role enum), so this is the table the CLI itself checks.
      admins = await prisma.platformAdmin.count();
    } finally {
      await prisma.$disconnect();
    }
    expect(admins).toBeGreaterThan(0);

    const { status, out } = runCli([SCRIPT, '--confirm'], 'SomeStrongPass123!\n');
    expect(status).toBe(1);
    expect(out).toMatch(/a platform admin already exists/i);
    expect(out).not.toMatch(/platform admin created/i);
  }, SPAWN_TIMEOUT_MS + 20_000);

  it('T3 negative control: --help still exits 0 and prints usage, so the guards did not brick the command', () => {
    const { status, out } = runCli([SCRIPT, '--help']);
    expect(status).toBe(0);
    expect(out).toMatch(/--confirm/);
    expect(out).toMatch(/bootstrap/i);
  }, SPAWN_TIMEOUT_MS + 10_000);
});
