import { Injectable, Logger, OnModuleDestroy } from '@nestjs/common';
import { RedisService } from '../../config/redis.service';

export interface CheckResult {
  allowed: boolean;
  failures?: number;
  retryAfterSeconds?: number;
  lockoutSeconds?: number;
}

@Injectable()
export class BruteForceService implements OnModuleDestroy {
  private readonly logger = new Logger(BruteForceService.name);
  private localCache = new Map<string, { count: number; lockedUntil: number }>();
  private cleanupInterval: NodeJS.Timeout;

  constructor(private readonly redis: RedisService) {
    this.cleanupInterval = setInterval(() => {
      const now = Date.now();
      for (const [key, val] of this.localCache.entries()) {
        if (val.lockedUntil && val.lockedUntil < now) this.localCache.delete(key);
      }
    }, 300_000);
    this.cleanupInterval.unref?.();
  }

  onModuleDestroy() {
    clearInterval(this.cleanupInterval);
  }

  async checkAndIncrement(key: string): Promise<{ allowed: boolean; lockoutSeconds?: number }> {
    const limits = [
      { attempts: 3, lockoutMs: 30_000 },
      { attempts: 5, lockoutMs: 900_000 },
      { attempts: 10, lockoutMs: 86_400_000 },
    ];

    try {
      if (!this.redis?.client) throw new Error('Redis not available');
      const countKey = `bf:count:${key}`;
      const lockKey = `bf:lock:${key}`;
      const existingLockTtl = await this.redis.client.ttl(lockKey);
      if (existingLockTtl > 0) return { allowed: false, lockoutSeconds: existingLockTtl };

      // INCR is atomic across every API replica. The old GET/parse/SET
      // sequence lost increments under concurrent login attempts.
      const count = await this.redis.client.incr(countKey);
      if (count === 1) await this.redis.client.expire(countKey, 86_400);
      for (const limit of [...limits].reverse()) {
        if (count >= limit.attempts) {
          const seconds = Math.ceil(limit.lockoutMs / 1000);
          await this.redis.client.set(lockKey, '1', 'EX', seconds);
          return { allowed: false, lockoutSeconds: seconds };
        }
      }
      return { allowed: true };
    } catch {
      this.logger.warn('Redis unavailable — using in-memory brute-force protection');
      const local = this.localCache.get(key) || { count: 0, lockedUntil: 0 };
      const now = Date.now();

      local.count += 1;
      for (const limit of [...limits].reverse()) {
        if (local.count >= limit.attempts) {
          local.lockedUntil = now + limit.lockoutMs;
          this.localCache.set(key, local);
          return { allowed: false, lockoutSeconds: Math.ceil(limit.lockoutMs / 1000) };
        }
      }

      this.localCache.set(key, local);
      return { allowed: true };
    }
  }

  async reset(keyOrScope: string, maybeKey?: string): Promise<void> {
    const key = maybeKey ? `${keyOrScope}:${maybeKey}` : keyOrScope;
    try {
      await this.redis?.client?.del(`bf:count:${key}`, `bf:lock:${key}`);
    } catch {}
    this.localCache.delete(key);
  }

  async check(scope: string, key: string): Promise<CheckResult> {
    const rawKey = `${scope}:${key}`;
    try {
      const [countRaw, lockTtl] = await Promise.all([
        this.redis.client.get(`bf:count:${rawKey}`),
        this.redis.client.ttl(`bf:lock:${rawKey}`),
      ]);
      const failures = Number(countRaw || 0);
      if (lockTtl > 0) {
        return { allowed: false, failures, retryAfterSeconds: lockTtl, lockoutSeconds: lockTtl };
      }
      return { allowed: true, failures, retryAfterSeconds: 0 };
    } catch {
      const local = this.localCache.get(rawKey) || { count: 0, lockedUntil: 0 };
      const now = Date.now();
      if (local.lockedUntil && local.lockedUntil > now) {
        const seconds = Math.ceil((local.lockedUntil - now) / 1000);
        return { allowed: false, failures: local.count, retryAfterSeconds: seconds, lockoutSeconds: seconds };
      }
      return { allowed: true, failures: local.count, retryAfterSeconds: 0 };
    }
  }

  async registerFailure(scope: string, key: string): Promise<CheckResult> {
    const result = await this.checkAndIncrement(`${scope}:${key}`);
    return { allowed: result.allowed, retryAfterSeconds: result.lockoutSeconds || 0, lockoutSeconds: result.lockoutSeconds };
  }
}
