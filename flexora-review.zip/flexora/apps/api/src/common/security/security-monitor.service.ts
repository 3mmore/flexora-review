/**
 * FLEXORA Gym OS — Security Monitor (Phase 3)
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Real-time security event tracking with severity classification.
 * Emits structured events that can be shipped to SIEM (Datadog, Sentry, ELK).
 */
import { Injectable, Logger } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';
import { createHash } from 'crypto';
import { Prisma } from '@prisma/client';

export enum SecuritySeverity {
  INFO = 'INFO',
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL',
}

export interface SecurityEvent {
  gymId?: string | null;
  actorId?: string | null;
  type: string;
  severity: SecuritySeverity;
  ip?: string | null;
  meta?: Record<string, any>;
}

@Injectable()
export class SecurityMonitorService {
  private readonly logger = new Logger(SecurityMonitorService.name);

  constructor(private readonly prisma: PrismaService) {}

  async record(event: SecurityEvent): Promise<void> {
    // Always log to Winston
    this.logger.warn(`[SECURITY:${event.severity}] ${event.type} from ip=${event.ip ?? '-'} gym=${event.gymId ?? '-'}`);
    // Persist HIGH and CRITICAL events to DB for audit
    if (event.severity === SecuritySeverity.HIGH || event.severity === SecuritySeverity.CRITICAL) {
      try {
        await this.prisma.auditLog.create({
          data: {
            gymId: event.gymId ?? null,
            actorId: event.actorId ?? null,
            action: `security:${event.type}`,
            entity: 'security',
            ip: event.ip ?? null,
            meta: event.meta as Prisma.InputJsonValue,
          },
        });
      } catch (e) {
        this.logger.error(`Failed to persist security event: ${(e as Error).message}`);
      }
    }
  }

  /** Convenience helpers — all auto-pull IP from request. */
  async loginFailed(ip: string | undefined, gymId: string | null, email: string, reason: string) {
    await this.record({
      gymId, ip: ip ?? null, type: 'login_failed', severity: SecuritySeverity.LOW,
      meta: { email: email.replace(/(.{2}).+(@.+)/, '$1***$2'), reason },
    });
  }

  async loginSucceeded(ip: string | undefined, gymId: string | null, userId: string) {
    await this.record({
      gymId, actorId: userId, ip: ip ?? null, type: 'login_succeeded', severity: SecuritySeverity.INFO,
    });
  }

  async crossTenantBlocked(ip: string | undefined, claimedGymId: string, pinnedGymId: string, userId?: string) {
    await this.record({
      gymId: pinnedGymId, actorId: userId ?? null, ip: ip ?? null,
      type: 'cross_tenant_blocked', severity: SecuritySeverity.HIGH,
      meta: { claimedGymId, pinnedGymId },
    });
  }

  async bruteForceLocked(ip: string | undefined, gymId: string | null, scope: string, key: string, durationSeconds: number) {
    await this.record({
      gymId, ip: ip ?? null, type: 'brute_force_locked', severity: SecuritySeverity.MEDIUM,
      meta: { scope, keyHash: createHash('sha256').update(key).digest('hex').slice(0, 8), durationSeconds },
    });
  }

  async csrfRejected(ip: string | undefined, gymId: string | null) {
    await this.record({
      gymId, ip: ip ?? null, type: 'csrf_rejected', severity: SecuritySeverity.MEDIUM,
    });
  }

  async twoFactorDisabled(ip: string | undefined, gymId: string, userId: string) {
    await this.record({
      gymId, actorId: userId, ip: ip ?? null,
      type: '2fa_disabled', severity: SecuritySeverity.HIGH,
    });
  }

  async privilegeEscalation(ip: string | undefined, gymId: string, actorId: string, attempted: string) {
    await this.record({
      gymId, actorId, ip: ip ?? null,
      type: 'privilege_escalation', severity: SecuritySeverity.CRITICAL,
      meta: { attempted },
    });
  }

  async anomalousExport(gymId: string, actorId: string, rows: number, ip: string | undefined) {
    if (rows > 10000) {
      await this.record({
        gymId, actorId, ip: ip ?? null,
        type: 'anomalous_export', severity: SecuritySeverity.HIGH,
        meta: { rows },
      });
    }
  }
}

