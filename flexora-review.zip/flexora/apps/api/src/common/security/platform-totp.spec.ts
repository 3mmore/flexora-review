/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1 — platform-totp.spec.ts
 *
 * The point of this file is that the console's TOTP is PROVABLY the standard and
 * not a private dialect. Section 1 cross-validates every token against otplib,
 * the implementation the tenant 2FA flow already ships; section 2 pins the two
 * RFC 4226 known-answer vectors. If either fails, the implementation is wrong —
 * not the test.
 */
import { readFileSync } from 'fs';
import { authenticator } from 'otplib';
import {
  TOTP_DIGITS,
  TOTP_ISSUER,
  TOTP_STEP_SECONDS,
  TOTP_WINDOW,
  RECOVERY_CODE_LENGTH,
  base32Decode,
  base32Encode,
  currentTotpStep,
  generateRecoveryCode,
  generateTotpSecret,
  hotpToken,
  looksLikeRecoveryCode,
  normaliseRecoveryCode,
  totpCounter,
  totpKeyUri,
  totpTokenAt,
  verifyTotpCode,
} from './platform-totp';

/** RFC 4226 Appendix D uses the ASCII secret "12345678901234567890". */
const RFC_SECRET_ASCII = '12345678901234567890';
const RFC_SECRET_BASE32 = 'GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ';

const STEP_MS = TOTP_STEP_SECONDS * 1000;
/** An instant comfortably inside one step, so a test never straddles a boundary. */
const atStep = (step: number) => step * STEP_MS + Math.floor(STEP_MS / 2);

describe('platform TOTP — 1. interop with otplib (the RFC 6238 proof)', () => {
  it('1a. produces the SAME token as otplib for 20 secrets x 5 instants', () => {
    let compared = 0;
    for (let i = 0; i < 20; i++) {
      const secret = generateTotpSecret();
      for (const step of [1, 59_000_000, 59_000_001, currentTotpStep(), currentTotpStep() + 7]) {
        const instant = atStep(step);
        const mine = totpTokenAt(secret, instant);
        const realNow = Date.now;
        Date.now = () => instant;
        let theirs: string;
        try {
          theirs = authenticator.generate(secret);
        } finally {
          Date.now = realNow;
        }
        expect(mine).toBe(theirs);
        compared++;
      }
    }
    expect(compared).toBe(100);
  });

  it('1b. otplib accepts what this module produces, and this module accepts what otplib produces', () => {
    const secret = generateTotpSecret();
    const instant = atStep(currentTotpStep());
    const mine = totpTokenAt(secret, instant);

    const realNow = Date.now;
    Date.now = () => instant;
    let theirs: string;
    let otplibAcceptsMine: boolean;
    try {
      theirs = authenticator.generate(secret);
      otplibAcceptsMine = authenticator.check(mine, secret);
    } finally {
      Date.now = realNow;
    }

    expect(theirs).toBe(mine);
    expect(otplibAcceptsMine).toBe(true);
    expect(verifyTotpCode({ secret, code: theirs, atMs: instant })).toEqual({ ok: true, step: totpCounter(instant) });
  });

  it('1c. a code from a REAL authenticator flow (otplib secret + otplib token) verifies here', () => {
    // generateSecret() is otplib's, so the secret spelling a phone app would be
    // given is otplib's, and the code it displays is otplib's.
    const secret = authenticator.generateSecret();
    const instant = atStep(currentTotpStep());
    const realNow = Date.now;
    Date.now = () => instant;
    let code: string;
    try {
      code = authenticator.generate(secret);
    } finally {
      Date.now = realNow;
    }
    const result = verifyTotpCode({ secret, code, atMs: instant });
    expect(result.ok).toBe(true);
  });

  it('1d. this module never imports otplib, so it cannot mutate the tenant singleton', () => {
    // modules/auth/two-factor.service.ts sets authenticator.options on otplib's
    // process-wide singleton. If this module imported otplib and did the same,
    // tenant 2FA behaviour would depend on import order. Structural guarantee,
    // asserted against the source: remove it and this test fails.
    // Comments are stripped first: the header of platform-totp.ts NAMES
    // authenticator.options while explaining why this module does not touch it,
    // and a structural check that trips over its own explanation is a check that
    // will be deleted rather than trusted. Same technique as the CSP spec repaired
    // in PHASE R0.
    const source = readFileSync(`${__dirname}/platform-totp.ts`, 'utf8')
      .replace(/\/\*[\s\S]*?\*\//g, '')
      .split('\n')
      .filter((line) => !line.trim().startsWith('//') && !line.trim().startsWith('*'))
      .join('\n');
    expect(source).toContain('createHmac'); // it really does implement RFC 4226
    expect(source).not.toMatch(/from 'otplib'/);
    expect(source).not.toMatch(/require\('otplib'\)/);
    expect(source).not.toMatch(/authenticator\.options/);
  });
});

describe('platform TOTP — 2. RFC 4226 known-answer vectors', () => {
  it('2a. the RFC secret encodes to the RFC base32 spelling', () => {
    expect(base32Encode(Buffer.from(RFC_SECRET_ASCII, 'ascii'))).toBe(RFC_SECRET_BASE32);
    expect(base32Decode(RFC_SECRET_BASE32).toString('ascii')).toBe(RFC_SECRET_ASCII);
  });

  it('2b. HOTP counters 0 and 1 match RFC 4226 Appendix D', () => {
    expect(hotpToken(RFC_SECRET_BASE32, 0)).toBe('755224');
    expect(hotpToken(RFC_SECRET_BASE32, 1)).toBe('287082');
  });

  it('2c. the counter is floor(unix seconds / 30)', () => {
    expect(totpCounter(0)).toBe(0);
    expect(totpCounter(29_999)).toBe(0);
    expect(totpCounter(30_000)).toBe(1);
    expect(totpCounter(59_999)).toBe(1);
    expect(currentTotpStep(atStep(1234))).toBe(1234);
  });
});

describe('platform TOTP — 3. the +/-1 step window (R1.1)', () => {
  const secret = generateTotpSecret();
  const centre = 1_800_000;

  it('3a. accepts the current step', () => {
    expect(verifyTotpCode({ secret, code: totpTokenAt(secret, atStep(centre)), atMs: atStep(centre) })).toEqual({
      ok: true,
      step: centre,
    });
  });

  it('3b. accepts one step late and one step early, and reports WHICH step matched', () => {
    const late = verifyTotpCode({ secret, code: totpTokenAt(secret, atStep(centre - 1)), atMs: atStep(centre) });
    expect(late).toEqual({ ok: true, step: centre - 1 });
    const early = verifyTotpCode({ secret, code: totpTokenAt(secret, atStep(centre + 1)), atMs: atStep(centre) });
    expect(early).toEqual({ ok: true, step: centre + 1 });
  });

  it('3c. rejects two steps out, in both directions', () => {
    expect(
      verifyTotpCode({ secret, code: totpTokenAt(secret, atStep(centre - 2)), atMs: atStep(centre) }).ok,
    ).toBe(false);
    expect(
      verifyTotpCode({ secret, code: totpTokenAt(secret, atStep(centre + 2)), atMs: atStep(centre) }).ok,
    ).toBe(false);
  });

  it('3d. the window is exactly TOTP_WINDOW and the constants are what R1.1 specifies', () => {
    expect(TOTP_WINDOW).toBe(1);
    expect(TOTP_STEP_SECONDS).toBe(30);
    expect(TOTP_DIGITS).toBe(6);
    // a code that matches only at the far edge of the window still verifies,
    // which is the observable consequence of walking the whole window instead of
    // returning on the first match
    const edge = verifyTotpCode({ secret, code: totpTokenAt(secret, atStep(centre - TOTP_WINDOW)), atMs: atStep(centre) });
    expect(edge.ok).toBe(true);
  });
});

describe('platform TOTP — 4. replay protection via the last-used step (R1.1)', () => {
  const secret = generateTotpSecret();
  const centre = 1_900_000;

  it('4a. the same code cannot be spent twice', () => {
    const code = totpTokenAt(secret, atStep(centre));
    const first = verifyTotpCode({ secret, code, lastUsedStep: null, atMs: atStep(centre) });
    expect(first).toEqual({ ok: true, step: centre });
    const second = verifyTotpCode({ secret, code, lastUsedStep: first.ok ? first.step : null, atMs: atStep(centre) });
    expect(second).toEqual({ ok: false, reason: 'replayed' });
  });

  it('4b. a code from an EARLIER step cannot be replayed inside the current window', () => {
    // The admin spent the step-(centre-1) code, which recorded centre-1. Ten
    // seconds later the attacker replays it: still inside the +/-1 window, so a
    // "was this exact token used" check would accept it. The step check does not.
    const oldCode = totpTokenAt(secret, atStep(centre - 1));
    const spent = verifyTotpCode({ secret, code: oldCode, lastUsedStep: null, atMs: atStep(centre - 1) });
    expect(spent.ok).toBe(true);
    const replay = verifyTotpCode({
      secret,
      code: oldCode,
      lastUsedStep: spent.ok ? spent.step : null,
      atMs: atStep(centre),
    });
    expect(replay).toEqual({ ok: false, reason: 'replayed' });
  });

  it('4c. a genuinely NEW code at a later step is accepted', () => {
    const next = verifyTotpCode({
      secret,
      code: totpTokenAt(secret, atStep(centre + 1)),
      lastUsedStep: centre,
      atMs: atStep(centre + 1),
    });
    expect(next).toEqual({ ok: true, step: centre + 1 });
  });

  it('4d. the recorded step never lets an older step through, even far later', () => {
    expect(
      verifyTotpCode({
        secret,
        code: totpTokenAt(secret, atStep(centre - 1)),
        lastUsedStep: centre + 50,
        atMs: atStep(centre + 50),
      }),
    ).toEqual({ ok: false, reason: 'invalid' });
  });
});

describe('platform TOTP — 5. malformed input', () => {
  const secret = generateTotpSecret();
  const instant = atStep(1_950_000);

  it.each([
    ['empty', ''],
    ['five digits', '12345'],
    ['seven digits', '1234567'],
    ['letters', 'abcdef'],
    ['a space inside', '123 456'],
    ['sql-ish', "1' OR '1"],
  ])('5a. %s is rejected as malformed, not as invalid', (_label, code) => {
    expect(verifyTotpCode({ secret, code, atMs: instant })).toEqual({ ok: false, reason: 'malformed-code' });
  });

  it('5b. surrounding whitespace from a paste is tolerated', () => {
    const code = totpTokenAt(secret, instant);
    expect(verifyTotpCode({ secret, code: `  ${code}  `, atMs: instant }).ok).toBe(true);
  });

  it('5c. a wrong-but-well-formed code is invalid', () => {
    const code = totpTokenAt(secret, instant);
    const wrong = String((Number(code) + 1) % 1_000_000).padStart(6, '0');
    expect(verifyTotpCode({ secret, code: wrong, atMs: instant })).toEqual({ ok: false, reason: 'invalid' });
  });

  it('5d. no secret is reported distinctly, so the caller cannot 500', () => {
    expect(verifyTotpCode({ secret: null, code: '123456', atMs: instant })).toEqual({ ok: false, reason: 'no-secret' });
    expect(verifyTotpCode({ secret: undefined, code: '123456', atMs: instant })).toEqual({ ok: false, reason: 'no-secret' });
  });
});

describe('platform TOTP — 6. base32 handling', () => {
  it('6a. round-trips arbitrary buffers', () => {
    for (const length of [1, 5, 16, 20, 32, 64]) {
      const buffer = require('crypto').randomBytes(length) as Buffer;
      expect(base32Decode(base32Encode(buffer)).subarray(0, length)).toEqual(buffer);
    }
  });

  it('6b. tolerates the ways a human re-types a manual key', () => {
    const canonical = base32Encode(Buffer.from(RFC_SECRET_ASCII, 'ascii'));
    const spaced = canonical.replace(/(.{4})/g, '$1 ').trim();
    expect(base32Decode(spaced.toLowerCase()).toString('ascii')).toBe(RFC_SECRET_ASCII);
    expect(base32Decode(`${spaced}====`).toString('ascii')).toBe(RFC_SECRET_ASCII);
    expect(base32Decode(canonical.replace(/(.{4})(?=.)/g, '$1-')).toString('ascii')).toBe(RFC_SECRET_ASCII);
  });

  it('6c. refuses a character outside the alphabet instead of guessing', () => {
    expect(() => base32Decode('GEZDGNBVGY3TQOJQ1')).toThrow(/invalid base32/);
    expect(() => base32Decode('')).toThrow(/empty base32/);
  });

  it('6d. a generated secret has at least 128 bits of entropy and is unpadded base32', () => {
    const secret = generateTotpSecret();
    expect(secret).toMatch(/^[A-Z2-7]+$/);
    expect(secret.length).toBeGreaterThanOrEqual(26); // 160 bits / 5 bits per char
    expect(base32Decode(secret).length).toBe(20);
  });
});

describe('platform TOTP — 7. enrolment payload', () => {
  it('7a. the otpauth URI carries everything an authenticator app needs', () => {
    const secret = generateTotpSecret();
    const uri = totpKeyUri({ accountName: 'owner@flexora.app', secret });
    const parsed = new URL(uri);
    expect(parsed.protocol).toBe('otpauth:');
    expect(parsed.host).toBe('totp');
    expect(parsed.pathname).toBe(`/${encodeURIComponent(TOTP_ISSUER)}:owner%40flexora.app`);
    expect(parsed.searchParams.get('secret')).toBe(secret);
    expect(parsed.searchParams.get('issuer')).toBe(TOTP_ISSUER);
    expect(parsed.searchParams.get('algorithm')).toBe('SHA1');
    expect(parsed.searchParams.get('digits')).toBe(String(TOTP_DIGITS));
    expect(parsed.searchParams.get('period')).toBe(String(TOTP_STEP_SECONDS));
  });

  it('7b. a code minted from the URI secret verifies', () => {
    const secret = generateTotpSecret();
    const uri = totpKeyUri({ accountName: 'admin@example.com', secret });
    const uriSecret = new URL(uri).searchParams.get('secret') as string;
    const instant = atStep(2_000_000);
    expect(verifyTotpCode({ secret: uriSecret, code: totpTokenAt(uriSecret, instant), atMs: instant }).ok).toBe(true);
  });
});

describe('platform TOTP — 8. recovery codes (R1.1)', () => {
  it('8a. ten codes are unique, well formed and unambiguous to read aloud', () => {
    const codes = Array.from({ length: 10 }, () => generateRecoveryCode());
    expect(new Set(codes).size).toBe(10);
    for (const code of codes) {
      expect(code).toMatch(/^[A-HJ-KM-NP-TV-Z2-9]{5}(-[A-HJ-KM-NP-TV-Z2-9]{5}){4}$/);
      expect(looksLikeRecoveryCode(code)).toBe(true);
      // no character that an admin could confuse on the phone with the owner
      expect(code).not.toMatch(/[0O1IL]/);
    }
  });

  it('8b. normalisation accepts a pasted code with spaces or lower case', () => {
    const code = generateRecoveryCode();
    const canonical = code.replace(/-/g, '');
    expect(normaliseRecoveryCode(code.toLowerCase().replace(/-/g, ' '))).toBe(canonical);
    expect(normaliseRecoveryCode(code)).toBe(canonical);
    expect(looksLikeRecoveryCode(code.toLowerCase().replace(/-/g, ' '))).toBe(true);
    expect(looksLikeRecoveryCode(canonical)).toBe(true);
    expect(canonical.length).toBe(RECOVERY_CODE_LENGTH);
  });

  it('8c. a truncated or over-long code is not shaped like a recovery code', () => {
    expect(looksLikeRecoveryCode('')).toBe(false);
    expect(looksLikeRecoveryCode('ABCDE-FGHJK')).toBe(false);
    expect(looksLikeRecoveryCode(`${generateRecoveryCode()}XXXXX`)).toBe(false);
  });
});
