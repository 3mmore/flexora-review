/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1 — RFC 6238 TOTP for the owner console.
 *
 * WHY THIS IS NOT `otplib`'s SHARED SINGLETON
 * --------------------------------------------
 * The tenant 2FA service (modules/auth/two-factor.service.ts) sets
 * `authenticator.options = { window: 1, step: 30 }` on otplib's process-wide
 * singleton at module scope. A second consumer that needs different options
 * would silently change tenant 2FA behaviour, and otplib's `verify({timestamp})`
 * ignores its timestamp argument (measured: work/r1-evidence, R1 recon), so the
 * matched step cannot be recovered from `check()`.
 *
 * So this module implements RFC 4226/6238 directly on node:crypto — HMAC-SHA1
 * over an 8-byte big-endian counter, dynamic truncation, decimal mod — and is
 * cross-validated against otplib in platform-totp.spec.ts: for the same secret
 * and the same instant, both implementations must produce the SAME token, and
 * otplib must accept what this module produces. That test is the interop proof;
 * nothing here is a private dialect.
 *
 * The reason the matched step matters: R1.1 requires replay protection via the
 * last-used step, which needs to know WHICH step a presented code came from.
 * Recording only "a code was accepted" would let a code from the previous step
 * be replayed for the rest of the current window.
 */
import { createHmac, randomBytes, timingSafeEqual } from 'crypto';

const BASE32_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

/** Step length in seconds. 30 is what every consumer authenticator defaults to. */
export const TOTP_STEP_SECONDS = 30;
/** Digits per code. */
export const TOTP_DIGITS = 6;
/** Accepted clock skew, in steps, either side of the current one (R1.1: +/-1). */
export const TOTP_WINDOW = 1;
/** Issuer shown in the authenticator app and embedded in the otpauth:// URI. */
export const TOTP_ISSUER = 'Flexora Owner Console';
/** Secret length in bytes: 160 bits. RFC 4226 requires at least 128. */
export const TOTP_SECRET_BYTES = 20;

/** RFC 4648 base32, unpadded — the spelling otplib's generateSecret() uses. */
export function base32Encode(buffer: Buffer): string {
  let bits = 0;
  let value = 0;
  let out = '';
  for (const byte of buffer) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      out += BASE32_ALPHABET[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) out += BASE32_ALPHABET[(value << (5 - bits)) & 31];
  return out;
}

/**
 * Decode base32. Tolerates lower case, spaces, dashes and '=' padding, because
 * admins copy the manual key by hand and authenticator apps display it in
 * groups. Throws on any character outside the alphabet rather than silently
 * producing a different secret.
 */
export function base32Decode(input: string): Buffer {
  const cleaned = String(input ?? '')
    .toUpperCase()
    .replace(/[\s-]/g, '')
    .replace(/=+$/g, '');
  if (!cleaned) throw new Error('empty base32 input');
  let bits = 0;
  let value = 0;
  const bytes: number[] = [];
  for (const char of cleaned) {
    const index = BASE32_ALPHABET.indexOf(char);
    if (index < 0) throw new Error('invalid base32 character');
    value = (value << 5) | index;
    bits += 5;
    if (bits >= 8) {
      bytes.push((value >>> (bits - 8)) & 0xff);
      bits -= 8;
    }
  }
  return Buffer.from(bytes);
}

/** A fresh base32 secret. Returned to the admin exactly once, at enrolment. */
export function generateTotpSecret(bytes: number = TOTP_SECRET_BYTES): string {
  return base32Encode(randomBytes(bytes));
}

/** The RFC 6238 counter for an instant: floor(unix seconds / step). */
export function totpCounter(atMs: number): number {
  return Math.floor(atMs / 1000 / TOTP_STEP_SECONDS);
}

/** Alias with the name R1 uses in the database column and the audit trail. */
export function currentTotpStep(atMs: number = Date.now()): number {
  return totpCounter(atMs);
}

/** RFC 4226 HOTP for an explicit counter. This is the whole of TOTP. */
export function hotpToken(secretBase32: string, counter: number, digits: number = TOTP_DIGITS): string {
  const key = base32Decode(secretBase32);
  const message = Buffer.alloc(8);
  message.writeBigUInt64BE(BigInt(counter));
  const digest = createHmac('sha1', key).update(message).digest();
  const offset = digest[digest.length - 1] & 0x0f;
  // RFC 4226 s5.3 dynamic truncation. The top bit of the first byte is masked
  // off so the result is a 31-bit unsigned integer; the other three bytes are
  // taken whole. (An earlier draft of this line masked the second byte with
  // 0x16 instead of 0xff, which produced tokens no authenticator app would
  // agree with — the interop test below is what catches that class of mistake.)
  const binary =
    ((digest[offset] & 0x7f) << 24) |
    ((digest[offset + 1] & 0xff) << 16) |
    ((digest[offset + 2] & 0xff) << 8) |
    (digest[offset + 3] & 0xff);
  const modulus = 10 ** digits;
  return String(binary % modulus).padStart(digits, '0');
}

/** The code an authenticator app shows for this secret at this instant. */
export function totpTokenAt(secretBase32: string, atMs: number = Date.now()): string {
  return hotpToken(secretBase32, totpCounter(atMs));
}

export type TotpFailureReason = 'no-secret' | 'malformed-code' | 'invalid' | 'replayed';
export type TotpVerification = { ok: true; step: number } | { ok: false; reason: TotpFailureReason };

export interface VerifyTotpParams {
  /** The stored secret (already decrypted by the caller). */
  secret: string | null | undefined;
  /** The code as typed by the admin. */
  code: string | null | undefined;
  /** The step of the last accepted code for this admin, or null when unused. */
  lastUsedStep?: number | null;
  /** Injectable clock, so tests do not need fake timers. */
  atMs?: number;
  /** Override the skew window; defaults to TOTP_WINDOW (+/-1 step). */
  window?: number;
}

/**
 * Verify a presented code and, when it is accepted, say which step it came from
 * so the caller can store it and refuse a replay.
 *
 * The comparison is constant-time and every candidate in the window is checked,
 * so the time taken does not reveal how far from correct a code was.
 */
export function verifyTotpCode(params: VerifyTotpParams): TotpVerification {
  const { secret, code, lastUsedStep = null } = params;
  const atMs = params.atMs ?? Date.now();
  const window = params.window ?? TOTP_WINDOW;
  if (!secret) return { ok: false, reason: 'no-secret' };

  const presented = String(code ?? '').trim();
  if (!new RegExp(`^\\d{${TOTP_DIGITS}}$`).test(presented)) return { ok: false, reason: 'malformed-code' };

  const centre = totpCounter(atMs);
  const presentedBuffer = Buffer.from(presented);
  let matchedStep: number | null = null;
  // Always walk the whole window: returning early on a match would make the
  // response time depend on where in the window the code landed.
  for (let delta = -window; delta <= window; delta++) {
    const candidate = Buffer.from(hotpToken(secret, centre + delta));
    if (candidate.length === presentedBuffer.length && timingSafeEqual(candidate, presentedBuffer)) {
      matchedStep = centre + delta;
    }
  }
  if (matchedStep === null) return { ok: false, reason: 'invalid' };
  if (lastUsedStep !== null && lastUsedStep !== undefined && matchedStep <= lastUsedStep) {
    return { ok: false, reason: 'replayed' };
  }
  return { ok: true, step: matchedStep };
}

/**
 * The otpauth:// URI an authenticator app scans. Carries the secret in plain
 * text BY DESIGN — that is how enrolment works — so it is returned only in the
 * enrolment response and must never be written to a log or an audit row.
 */
export function totpKeyUri(params: { accountName: string; secret: string; issuer?: string }): string {
  const issuer = params.issuer ?? TOTP_ISSUER;
  const label = `${encodeURIComponent(issuer)}:${encodeURIComponent(params.accountName)}`;
  const query = new URLSearchParams({
    secret: params.secret,
    issuer,
    algorithm: 'SHA1',
    digits: String(TOTP_DIGITS),
    period: String(TOTP_STEP_SECONDS),
  });
  return `otpauth://totp/${label}?${query.toString()}`;
}

/**
 * A recovery code an admin can spend instead of a TOTP code: 5 groups of 5
 * characters from an unambiguous alphabet (no 0/O, 1/I/L), 25 characters plus
 * separators. Ten are issued per enrolment (R1.1).
 */
export function generateRecoveryCode(): string {
  const alphabet = 'ABCDEFGHJKMNPQRSTVWXYZ23456789';
  const bytes = randomBytes(25);
  let out = '';
  for (let i = 0; i < 25; i++) {
    if (i > 0 && i % 5 === 0) out += '-';
    out += alphabet[bytes[i] % alphabet.length];
  }
  return out;
}

/**
 * Canonical form of a recovery code: upper case, no separators.
 *
 * Codes are DISPLAYED in groups of five separated by dashes, because 25
 * unbroken characters cannot be read aloud accurately. They are stored and
 * compared in this canonical form, so an admin who types the code without the
 * dashes, with spaces, or in lower case still succeeds. Every caller that hashes
 * or compares a recovery code MUST normalise through here first, or the display
 * form and the typed form will not match.
 */
export function normaliseRecoveryCode(code: string): string {
  return String(code ?? '')
    .toUpperCase()
    .replace(/[\s-]/g, '');
}

/** Length of a recovery code in canonical form. */
export const RECOVERY_CODE_LENGTH = 25;

/** Shape check only — never a validity claim. Validity is the argon2 hash's job. */
export function looksLikeRecoveryCode(code: string): boolean {
  return /^[A-HJ-KM-NP-TV-Z2-9]{25}$/.test(normaliseRecoveryCode(code));
}
