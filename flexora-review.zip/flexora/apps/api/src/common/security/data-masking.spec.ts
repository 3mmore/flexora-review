/**
 * FLEXORA Gym OS — data-masking tests
 * © 2024 Ammar Allam. All rights reserved.
 */
import { maskSensitive } from './data-masking';

describe('maskSensitive', () => {
  it('redacts password / token / secret / apiKey / twoFaSecret', () => {
    const out = maskSensitive({
      password: 'hunter2',
      token: 'abc.def.ghi',
      secret: 'shh',
      apiKey: 'sk-1234',
      twoFaSecret: 'JBSWY3DPEHPK3PXP',
    });
    expect(out).toEqual({
      password: '[REDACTED]',
      token: '[REDACTED]',
      secret: '[REDACTED]',
      apiKey: '[REDACTED]',
      twoFaSecret: '[REDACTED]',
    });
  });

  it('redacts any field ending in Token or Secret', () => {
    const out = maskSensitive({
      accessToken: 'a',
      refreshToken: 'b',
      clientSecret: 'c',
      anythingSecret: 'd',
    });
    expect(out.accessToken).toBe('[REDACTED]');
    expect(out.refreshToken).toBe('[REDACTED]');
    expect(out.clientSecret).toBe('[REDACTED]');
    expect(out.anythingSecret).toBe('[REDACTED]');
  });

  it('masks phone numbers to *******1234', () => {
    const out = maskSensitive({
      mobile: '01012345678',
      phone: '+201112223334',
      visitorPhone: '01199998888',
    });
    expect(out.mobile).toBe('*******5678');
    expect(out.phone).toBe('*******3334');
    expect(out.visitorPhone).toBe('*******8888');
  });

  it('masks nested objects and arrays', () => {
    const out = maskSensitive({
      user: { email: 'a@b.com', password: 'pw' },
      logs: [{ token: 't' }, { mobile: '01000000000' }],
    });
    expect(out.user.password).toBe('[REDACTED]');
    expect(out.user.email).toBe('a@b.com');
    expect(out.logs[0].token).toBe('[REDACTED]');
    expect(out.logs[1].mobile).toBe('*******0000');
  });

  it('handles circular references without throwing', () => {
    const a: any = { name: 'a' };
    a.self = a;
    const out = maskSensitive(a);
    expect(out.self).toBe('[CIRCULAR]');
  });

  it('converts Date to ISO string', () => {
    const d = new Date('2024-01-01T00:00:00Z');
    const out = maskSensitive({ createdAt: d });
    expect(out.createdAt).toBe('2024-01-01T00:00:00.000Z');
  });
});
