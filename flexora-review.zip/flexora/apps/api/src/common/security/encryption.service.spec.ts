/**
 * FLEXORA Gym OS — encryption service tests
 * © 2024 Ammar Allam. All rights reserved.
 */
import { EncryptionService } from './encryption.service';

describe('EncryptionService', () => {
  const ORIGINAL_ENV = process.env.ENCRYPTION_KEY;

  beforeEach(() => {
    process.env.ENCRYPTION_KEY = 'a'.repeat(64); // 64 hex chars
    process.env.ENCRYPTION_SEARCH_KEY = 'b'.repeat(64);
  });
  afterAll(() => {
    process.env.ENCRYPTION_KEY = ORIGINAL_ENV;
    delete process.env.ENCRYPTION_SEARCH_KEY;
  });

  it('refuses to initialise without ENCRYPTION_KEY', () => {
    delete process.env.ENCRYPTION_KEY;
    delete process.env.ENCRYPTION_KEY_V1;
    const svc = new EncryptionService();
    expect(() => svc.onModuleInit()).toThrow(/ENCRYPTION_KEY or ENCRYPTION_KEY_VX is missing/);
  });

  it('refuses to initialise with non-hex key', () => {
    process.env.ENCRYPTION_KEY = 'not-hex-key-padding-to-make-64-chars-long-enough-okay';
    const svc = new EncryptionService();
    expect(() => svc.onModuleInit()).toThrow(/must be exactly 64 hex/);
  });

  it('round-trips arbitrary plaintext', () => {
    const svc = new EncryptionService();
    svc.onModuleInit();
    const plaintext = 'JBSWY3DPEHPK3PXP-the-secret';
    const enc = svc.encrypt(plaintext);
    expect(enc).not.toBe(plaintext);
    expect(svc.decrypt(enc)).toBe(plaintext);
  });

  it('produces a different ciphertext each time (random IV)', () => {
    const svc = new EncryptionService();
    svc.onModuleInit();
    const a = svc.encrypt('same');
    const b = svc.encrypt('same');
    expect(a).not.toBe(b);
    expect(svc.decrypt(a)).toBe('same');
    expect(svc.decrypt(b)).toBe('same');
  });

  it('detects tampering via auth tag', () => {
    const svc = new EncryptionService();
    svc.onModuleInit();
    const enc = svc.encrypt('hello');
    const buf = Buffer.from(enc, 'base64');
    // flip a byte in the ciphertext region
    buf[buf.length - 1] ^= 0x01;
    const tampered = buf.toString('base64');
    expect(() => svc.decrypt(tampered)).toThrow();
  });
});
