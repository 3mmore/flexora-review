/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Data-masking helpers used BEFORE persisting any audit log
 * or third-party payload that may contain sensitive fields.
 *
 * Rules:
 *   - 'password', 'token', 'secret', 'apiKey', 'twoFaSecret',
 *     'accessToken', 'refreshToken'  -> '[REDACTED]'
 *   - any field ending in 'Token' or 'Secret'               -> '[REDACTED]'
 *   - 'mobile', 'phone', 'mobilePhone', 'visitorPhone'      -> '*******1234'
 *
 * Recurses through plain objects and arrays. Handles circular refs.
 */

const REDACT_KEYS = new Set([
  'password',
  'passwordhash',
  'token',
  'tokens',
  'accesstoken',
  'refreshtoken',
  'secret',
  'apikey',
  'api_key',
  'twofasecret',
  'twofabackupcodes',
  'temptoken',
  'otpauthurl',
  'authorization',
  'cookie',
  'set-cookie',
  'currentpassword',
  'newpassword',
  'oldpassword',
  'confirmpassword',
  'code',
  'totpcode',
  'backupcode',
  'nationalid',
  'signaturesvg',
  'paymentreference',
]);

const PHONE_KEYS = new Set([
  'mobile',
  'phone',
  'mobilephone',
  'visitorphone',
  'whatsapp',
  'senderphone',
]);

const EMAIL_KEYS = new Set([
  'email',
  'contactemail',
  'owneremail',
]);

const REDACTED = '[REDACTED]';

function maskPhone(value: string): string {
  const digits = String(value).replace(/\D/g, '');
  if (digits.length < 4) return '****';
  return `*******${digits.slice(-4)}`;
}

function mask(value: unknown, seen = new WeakSet<object>()): unknown {
  if (value == null) return value;
  if (typeof value === 'string') return value;
  if (typeof value !== 'object') return value;
  if (seen.has(value as object)) return '[CIRCULAR]';
  seen.add(value as object);

  if (Array.isArray(value)) {
    return value.map((v) => mask(v, seen));
  }

  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
    const lower = k.toLowerCase();
    if (REDACT_KEYS.has(lower) || lower.includes('password') || lower.endsWith('token') || lower.endsWith('secret')) {
      out[k] = REDACTED;
    } else if (PHONE_KEYS.has(lower) && typeof v === 'string') {
      out[k] = maskPhone(v);
    } else if (EMAIL_KEYS.has(lower) && typeof v === 'string') {
      const parts = v.split('@');
      out[k] = parts.length === 2 && parts[0].length > 1 ? `${parts[0][0]}***@${parts[1]}` : v;
    } else if (v instanceof Date) {
      out[k] = v.toISOString();
    } else if (typeof v === 'object') {
      // ROUND 14 (security review, PHASE F): Prisma Decimals (and any other
      // toJSON-able value) serialize cleanly as strings. Without this, the
      // masked object kept non-serializable internals (e.g. a `constructor`
      // function) and every audit write for a response containing a Decimal
      // failed silently — the audit trail lost those rows entirely.
      if (v && typeof (v as { toJSON?: unknown }).toJSON === 'function') {
        out[k] = (v as { toJSON: () => unknown }).toJSON();
      } else {
        out[k] = mask(v, seen);
      }
    } else if (typeof v === 'function') {
      // never serialize functions into audit metadata
    } else {
      out[k] = v;
    }
  }
  return out;
}

/** Convenience wrapper used by interceptors and services. */
export function maskSensitive<T = unknown>(input: T): T {
  return mask(input) as T;
}
