import { readFileSync } from 'fs';
import { join } from 'path';
import { EncryptionService } from './encryption.service';

const srcRoot = join(__dirname, '../..');
const apiRoot = join(__dirname, '../../..');
const file = (path: string) => readFileSync(join(srcRoot, path), 'utf8');

describe('pre-launch security regressions', () => {
  it('the console login endpoint has brute-force protection', () => {
    // PHASE R1 / owner decision: this test used to cover TWO login endpoints. The
    // second one, modules/admin/admin.controller.ts, was a duplicate public
    // administrator login outside the R0 host gate; the module has been deleted, so
    // its assertions are deleted with it and /api/platform/auth/login is now the only
    // console login. The invariant is unchanged for the endpoint that remains: it may
    // not run unthrottled, and it must carry BruteForceGuard.
    const platform = file('modules/platform-auth/platform-auth.controller.ts');
    expect(platform).toContain('@UseGuards(BruteForceGuard)');
    expect(platform).toContain('@Throttle({ auth: { limit: 5, ttl: 60000 }, default: { limit: 5, ttl: 60000 } })');
    // and the deleted module must stay deleted
    expect(() => file('modules/admin/admin.controller.ts')).toThrow();
  });

  it('platform routes are protected by middleware when unauthenticated', () => {
    const middleware = readFileSync(join(apiRoot, '../web/src/middleware.ts'), 'utf8');
    expect(middleware).toContain("pathname.startsWith('/platform')");
    expect(middleware).toContain("request.cookies.get('flx_platform_token')");
    const publicLine = middleware.split('\n').find((line) => line.includes('publicPaths')) || '';
    expect(publicLine).not.toContain("'/platform'");
  });

  it('tenant RLS migration covers newly added sensitive tenant tables', () => {
    const migration = readFileSync(join(apiRoot, 'prisma/migrations/202606200002_add_missing_rls_policies/migration.sql'), 'utf8');
    for (const table of ['GymMessagingConfig', 'AiSuggestion', 'AiChatMessage', 'ProductEvent']) {
      expect(migration).toContain(`ALTER TABLE "${table}" ENABLE ROW LEVEL SECURITY`);
    }
    expect(migration).toContain('AuditLog_platform_access');
  });

  it('encryption service fails closed without a strong non-zero key', () => {
    const previous = process.env.ENCRYPTION_KEY;
    const previousSearch = process.env.ENCRYPTION_SEARCH_KEY;
    process.env.ENCRYPTION_SEARCH_KEY = 'b'.repeat(64);
    delete process.env.ENCRYPTION_KEY;
    expect(() => new EncryptionService().onModuleInit()).toThrow('ENCRYPTION_KEY')
    process.env.ENCRYPTION_KEY = '0'.repeat(64);
    expect(() => new EncryptionService().onModuleInit()).toThrow('ENCRYPTION_KEY')
    process.env.ENCRYPTION_KEY = previous;
    process.env.ENCRYPTION_SEARCH_KEY = previousSearch;
  });

  it('redirect allowlist rejects javascript and untrusted hosts', () => {
    const source = readFileSync(join(apiRoot, '../web/src/lib/validate-url.ts'), 'utf8');
    expect(source).toContain('checkout.stripe.com');
    expect(source).toContain("parsed.protocol === 'https:'");
    expect(source).not.toContain('javascript:');
  });
});
