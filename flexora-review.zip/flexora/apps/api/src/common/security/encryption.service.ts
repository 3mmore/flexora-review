import { Injectable, OnModuleInit } from '@nestjs/common';
import { createCipheriv, createDecipheriv, createHash, randomBytes } from 'crypto';

interface EncryptedPayload {
  kid: string;       // e.g. "v1", "v2", or "search-v1"
  iv: string;
  authTag: string;
  ciphertext: string;
}

@Injectable()
export class EncryptionService implements OnModuleInit {
  private readonly algorithm = 'aes-256-gcm';
  private keys: Map<string, Buffer> = new Map();
  private searchKey!: Buffer;
  private currentKid: string = 'v0';

  constructor() {}

  onModuleInit() {
    // 1. Load rotating keys: ENCRYPTION_KEY_V1, ENCRYPTION_KEY_V2, ... from env
    for (let i = 1; i <= 9; i++) {
      const raw = process.env[`ENCRYPTION_KEY_V${i}`];
      if (raw) {
        if (!/^[0-9a-fA-F]{64}$/.test(raw) || raw === '0'.repeat(64)) {
          throw new Error(`ENCRYPTION_KEY_V${i} must be exactly 64 hex chars and non-zero`);
        }
        this.keys.set(`v${i}`, Buffer.from(raw, 'hex'));
      }
    }

    // 2. Legacy fallback: the original single-key env var becomes "v0"
    if (process.env.ENCRYPTION_KEY) {
      const raw = process.env.ENCRYPTION_KEY;
      if (!/^[0-9a-fA-F]{64}$/.test(raw) || raw === '0'.repeat(64)) {
        throw new Error('ENCRYPTION_KEY must be exactly 64 hex chars and non-zero');
      }
      this.keys.set('v0', Buffer.from(raw, 'hex'));
    }

    if (this.keys.size === 0) {
      throw new Error('ENCRYPTION_KEY or ENCRYPTION_KEY_VX is missing');
    }

    // 3. Load deterministic search key (Approach A)
    const searchRaw = process.env.ENCRYPTION_SEARCH_KEY;
    if (!searchRaw) {
      throw new Error('ENCRYPTION_SEARCH_KEY is missing. This key is required for deterministic (searchable) encryption.');
    }
    if (!/^[0-9a-fA-F]{64}$/.test(searchRaw) || searchRaw === '0'.repeat(64)) {
      throw new Error('ENCRYPTION_SEARCH_KEY must be exactly 64 hex chars and non-zero');
    }
    this.searchKey = Buffer.from(searchRaw, 'hex');
    this.keys.set('search-v1', this.searchKey);

    // Determine current key ID for standard encryption
    this.currentKid = process.env.ENCRYPTION_CURRENT_KID || Array.from(this.keys.keys()).filter(k => k.startsWith('v')).pop() || 'v0';
  }

  encrypt(plaintext: string): string {
    const key = this.keys.get(this.currentKid);
    if (!key) throw new Error(`Current key id ${this.currentKid} not found`);

    const iv = randomBytes(12);
    const cipher = createCipheriv(this.algorithm, key, iv);
    const ciphertext = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);

    const payload: EncryptedPayload = {
      kid: this.currentKid,
      iv: iv.toString('base64'),
      authTag: cipher.getAuthTag().toString('base64'),
      ciphertext: ciphertext.toString('base64'),
    };

    return JSON.stringify(payload);
  }

  decrypt(value: string): string {
    let payload: EncryptedPayload;
    try {
      payload = JSON.parse(value);
      if (!payload.kid) {
        // Compatibility with older JSON format (v0 fallback)
        if ((payload as any).encrypted) {
           return this.decryptV0(payload as any);
        }
        payload.kid = 'v0'; 
      }
    } catch {
      throw new Error('Invalid ciphertext format');
    }

    const key = this.keys.get(payload.kid);
    if (!key) throw new Error(`Unknown key id: ${payload.kid}`);

    try {
      const decipher = createDecipheriv(this.algorithm, key, Buffer.from(payload.iv, 'base64'));
      decipher.setAuthTag(Buffer.from(payload.authTag, 'base64'));
      return Buffer.concat([
        decipher.update(Buffer.from(payload.ciphertext, 'base64')),
        decipher.final(),
      ]).toString('utf8');
    } catch (e) {
      throw new Error(`Decryption failed: ${(e as Error).message}`);
    }
  }

  private decryptV0(payload: any): string {
    const key = this.keys.get('v0');
    if (!key) throw new Error('Legacy key (v0) not found');
    const decipher = createDecipheriv(this.algorithm, key, Buffer.from(payload.iv, 'hex'));
    decipher.setAuthTag(Buffer.from(payload.tag || payload.authTag, 'hex'));
    return Buffer.concat([
      decipher.update(Buffer.from(payload.encrypted || payload.ciphertext, 'hex')),
      decipher.final(),
    ]).toString('utf8');
  }

  isEncrypted(value: string | null | undefined): boolean {
    if (!value) return false;
    return value.startsWith('{"kid":') || value.startsWith('{"encrypted":');
  }

  /**
   * Deterministic encryption for searchable fields (e.g. mobile numbers).
   * Uses a fixed key (searchKey) and a hash-based IV to ensure stable ciphertext.
   */
  encryptDeterministic(plaintext: string): string {
    if (!this.searchKey) throw new Error('Search key not initialized');
    
    // Hash-based IV for determinism
    const iv = createHash('sha256').update(String(plaintext)).digest().subarray(0, 12);
    const cipher = createCipheriv(this.algorithm, this.searchKey, iv);
    const ciphertext = Buffer.concat([cipher.update(String(plaintext), 'utf8'), cipher.final()]);
    
    const payload: EncryptedPayload = {
      kid: 'search-v1',
      iv: iv.toString('base64'),
      authTag: cipher.getAuthTag().toString('base64'),
      ciphertext: ciphertext.toString('base64'),
    };
    return JSON.stringify(payload);
  }
}
