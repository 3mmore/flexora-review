/**
 * FLEXORA Gym OS — JWT algorithm-pinning regression tests
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Ensures every JWT verification path pins algorithms:['HS256'] so an attacker
 * cannot forge a token with "alg":"none" or an asymmetric-key swap.
 */
import { ExecutionContext } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { JwtService } from '@nestjs/jwt';
import { JwtAuthGuard } from '../guards/jwt-auth.guard';
import { MemberAuthGuard } from '../guards/member-auth.guard';

function ctxWith(token?: string, cookie = 'flx_member_access'): ExecutionContext {
  // ROUND 14 (Phase F2): the MemberAuthGuard accepts the member token from the
  // HttpOnly cookie only — never from an Authorization header. The staff
  // JwtAuthGuard reads flx_access (cookie) or the Authorization header.
  const req = { headers: {}, cookies: token ? { [cookie]: token } : {} } as any;
  return {
    switchToHttp: () => ({ getRequest: () => req }),
    getHandler: () => ({}),
    getClass: () => ({}),
  } as any as ExecutionContext;
}

describe('JWT algorithm pinning (HS256)', () => {
  it('JwtAuthGuard verifies with algorithms:[HS256]', async () => {
    const verifyAsync = jest.fn().mockResolvedValue({ sub: 'u1', gymId: 'g1' });
    const jwt = { verifyAsync } as any as { verifyAsync: (token: string, options: Record<string, unknown>) => Promise<unknown> };
    const reflector = { getAllAndOverride: jest.fn().mockReturnValue(false) } as any as Reflector;
    const guard = new JwtAuthGuard(jwt, reflector);

    await guard.canActivate(ctxWith('tok', 'flx_access'));

    expect(verifyAsync).toHaveBeenCalledWith(
      'tok',
      expect.objectContaining({ algorithms: ['HS256'] }),
    );
  });

  it('MemberAuthGuard verifies with algorithms:[HS256]', async () => {
    const verifyAsync = jest.fn().mockResolvedValue({ role: 'MEMBER', sub: 'm1', gymId: 'g1' });
    const jwt = { verifyAsync } as any as JwtService;
    const guard = new MemberAuthGuard(jwt);

    await guard.canActivate(ctxWith('tok'));

    expect(verifyAsync).toHaveBeenCalledWith(
      'tok',
      expect.objectContaining({ algorithms: ['HS256'] }),
    );
  });

  it('MemberAuthGuard rejects a non-member token even if signature valid', async () => {
    const verifyAsync = jest.fn().mockResolvedValue({ role: 'OWNER', sub: 'u1' });
    const jwt = { verifyAsync } as any as JwtService;
    const guard = new MemberAuthGuard(jwt);
    await expect(guard.canActivate(ctxWith('tok'))).rejects.toThrow();
  });
});
