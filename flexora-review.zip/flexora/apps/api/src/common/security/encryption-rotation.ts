/**
 * PHASE M3.3 — encryption key rotation over data that is ALREADY encrypted.
 *
 * Two very different kinds of key live in this system, and they do not rotate
 * the same way:
 *
 *  1. STANDARD keys (`ENCRYPTION_KEY`, `ENCRYPTION_KEY_V1..V9`). Every
 *     ciphertext is a JSON envelope that names the key that produced it
 *     (`{"kid":"v1",...}`), so several versions can be loaded at once. Rotation
 *     is therefore ONLINE-SAFE: add the new version, point
 *     `ENCRYPTION_CURRENT_KID` at it, restart, and re-encrypt the backlog at
 *     your leisure. Old rows keep decrypting until you delete the old key.
 *
 *  2. The SEARCH key (`ENCRYPTION_SEARCH_KEY`) powers deterministic encryption
 *     (member mobiles, national IDs) so rows can be looked up by equality. It
 *     is NOT versioned — every deterministic payload is stamped `search-v1`
 *     whatever key produced it. Rotating it therefore invalidates every
 *     searchable ciphertext at once, which means it needs a maintenance window
 *     and a single pass that decrypts with the OLD key and encrypts with the
 *     NEW one. This module supports that pass; the runbook
 *     (`docs/SECRET_ROTATION.md`) says when to use it.
 *
 * The rule this module never breaks: a value that cannot be decrypted is an
 * ABORT, never a skipped row. Losing the old key and rewriting the row anyway
 * is how a rotation turns into permanent data loss.
 */
import { EncryptionService } from './encryption.service';

export interface RotationTarget {
  /** Prisma delegate name, e.g. `member`. */
  model: string;
  /** Column holding the ciphertext. */
  field: string;
  /** `deterministic` fields are encrypted with the search key. */
  kind: 'standard' | 'deterministic';
  /** Extra filter, e.g. `{ key: 'ai.apiKey' }` for the settings key/value store. */
  where?: Record<string, unknown>;
}

/**
 * Every column in the schema that holds a ciphertext, with the call site that
 * produces it. `prisma/rotate-encryption.ts` verifies each entry exists on the
 * generated client before it touches anything, so a renamed column fails loudly
 * instead of silently skipping a table.
 */
export const ENCRYPTED_FIELDS: readonly RotationTarget[] = [
  // ---- standard (versioned, kid in the payload) --------------------------
  { model: 'user', field: 'twoFaSecret', kind: 'standard' }, // two-factor.service.ts
  { model: 'user', field: 'twoFaBackupCodes', kind: 'standard' }, // two-factor.service.ts
  { model: 'gym', field: 'waBotToken', kind: 'standard' }, // wa-bot.service.ts
  { model: 'gymMessagingConfig', field: 'whatsappToken', kind: 'standard' },
  { model: 'gymMessagingConfig', field: 'smsApiKey', kind: 'standard' },
  { model: 'gymMessagingConfig', field: 'smsApiSecret', kind: 'standard' },
  { model: 'gymMessagingConfig', field: 'smtpPass', kind: 'standard' },
  { model: 'gymSettings', field: 'value', kind: 'standard', where: { key: 'ai.apiKey' } },
  { model: 'ownerNotification', field: 'metadata', kind: 'standard' },
  // ---- deterministic (search key, always stamped search-v1) --------------
  { model: 'member', field: 'mobile', kind: 'deterministic' },
  { model: 'member', field: 'nationalId', kind: 'deterministic' },
  { model: 'lead', field: 'mobile', kind: 'deterministic' },
] as const;

/** What the writer half of a rotation must be able to do. */
export interface EnforcementWriter {
  encrypt(plaintext: string): string;
  encryptDeterministic(plaintext: string): string;
  /** Needed only to detect "this row was already rotated by an earlier run". */
  decrypt(value: string): string;
}

export interface FieldStats {
  model: string;
  field: string;
  scanned: number;
  plaintext: number;
  alreadyCurrent: number;
  rotated: number;
  failed: number;
  /** Message from the FIRST failure, so an operator can see why. Never the value. */
  firstError?: string;
}

export interface RotationRow {
  id: string;
  value: unknown;
}

/** Can this service read the value? Used only to detect "already rotated". */
function canDecrypt(svc: EnforcementWriter, value: string): boolean {
  try {
    svc.decrypt(value);
    return true;
  } catch {
    return false;
  }
}

/** Read the `kid` out of a ciphertext envelope without decrypting it. */
export function readKid(value: string): string | null {
  try {
    const parsed = JSON.parse(value);
    if (parsed && typeof parsed.kid === 'string') return parsed.kid;
    // legacy envelope from before kid existed
    return parsed && parsed.encrypted ? 'v0' : null;
  } catch {
    return null;
  }
}

/**
 * Re-encrypts one stored value.
 *
 * @param reader  service that can still DECRYPT the old key
 * @param writer  service that ENCRYPTS with the new current key
 * @param targetKid the kid `writer` stamps (e.g. `v2`, or `search-v1`)
 * @param always  true for deterministic fields: the kid never changes, so a
 *                kid comparison cannot tell you a row is stale — it has to be
 *                re-encrypted whenever the key behind the kid changed.
 * @returns the new ciphertext, or null when the row needs no change.
 * @throws  when the value is encrypted but cannot be decrypted (missing old
 *          key, corrupt row). Callers must treat this as an abort.
 */
export function rotateValue(
  value: unknown,
  reader: EncryptionService,
  writer: EnforcementWriter,
  targetKid: string,
  deterministic = false,
): string | null {
  if (typeof value !== 'string' || value.length === 0) return null;
  if (!reader.isEncrypted(value)) return null;

  // Deterministic rows are always stamped `search-v1`, so the kid can never
  // tell you whether a row is stale — the key behind the kid is what changed.
  if (!deterministic) {
    const kid = readKid(value);
    if (kid === targetKid) return null; // already on the current key
  } else if (canDecrypt(writer, value)) {
    // Idempotency, and a safety net: if the NEW key already reads this row then
    // it was rotated by an earlier run. Reporting it as a failure instead would
    // (a) make re-running the same command abort with a scary error and (b)
    // tempt an operator to "fix" it by swapping the keys, which double-rotates
    // the row and destroys it.
    return null;
  }

  // Throws if the old key is gone or the row is corrupt — never "fixed up".
  const plaintext = reader.decrypt(value);
  const rotated = deterministic ? writer.encryptDeterministic(plaintext) : writer.encrypt(plaintext);
  return rotated === value ? null : rotated;
}

/**
 * Walks one column and returns the writes to perform. Nothing is written here:
 * the caller decides (dry run vs apply), and a single undecryptable row fails
 * the whole plan rather than being skipped.
 */
export function planField(
  target: RotationTarget,
  rows: RotationRow[],
  reader: EncryptionService,
  writer: EncryptionService,
  targetKid: string,
): { stats: FieldStats; writes: RotationRow[] } {
  const stats: FieldStats = {
    model: target.model,
    field: target.field,
    scanned: 0,
    plaintext: 0,
    alreadyCurrent: 0,
    rotated: 0,
    failed: 0,
  };
  const writes: RotationRow[] = [];
  const deterministic = target.kind === 'deterministic';

  for (const row of rows) {
    stats.scanned++;
    if (typeof row.value !== 'string' || !reader.isEncrypted(row.value)) {
      stats.plaintext++;
      continue;
    }
    try {
      const next = rotateValue(row.value, reader, writer, targetKid, deterministic);
      if (next === null) {
        stats.alreadyCurrent++;
        continue;
      }
      writes.push({ id: row.id, value: next });
      stats.rotated++;
    } catch (e) {
      stats.failed++;
      // Report the reason, never the ciphertext or the row's contents.
      if (!stats.firstError) stats.firstError = (e as Error).message;
    }
  }
  return { stats, writes };
}
