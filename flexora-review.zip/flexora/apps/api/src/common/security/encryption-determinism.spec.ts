import { EncryptionService } from './encryption.service';
import { randomBytes } from 'crypto';

describe('EncryptionService: Deterministic Stability', () => {
  let service: EncryptionService;
  const key1 = '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef';
  const key2 = 'fedcba9876543210fedcba9876543210fedcba9876543210fedcba9876543210';
  const searchKey = 'aaaabbbbccccddddeeeeffff0000111122223333444455556666777788889999';

  beforeEach(() => {
    service = new EncryptionService();
    delete process.env.ENCRYPTION_KEY;
    delete process.env.ENCRYPTION_KEY_V1;
    delete process.env.ENCRYPTION_KEY_V2;
    delete process.env.ENCRYPTION_CURRENT_KID;
    delete process.env.ENCRYPTION_SEARCH_KEY;
  });

  it('ciphertext remains stable even when current standard key rotates', () => {
    const mobile = '01234567890';
    
    // 1. Initial state: v1 is current
    process.env.ENCRYPTION_KEY_V1 = key1;
    process.env.ENCRYPTION_SEARCH_KEY = searchKey;
    service.onModuleInit();
    const cipher1 = service.encryptDeterministic(mobile);
    
    // 2. Rotate state: v2 is current
    process.env.ENCRYPTION_KEY_V2 = key2;
    process.env.ENCRYPTION_CURRENT_KID = 'v2';
    const service2 = new EncryptionService();
    service2.onModuleInit();
    const cipher2 = service2.encryptDeterministic(mobile);
    
    // 3. Assert IDENTICAL ciphertexts
    expect(cipher1).toBe(cipher2);
    expect(service2.decrypt(cipher1)).toBe(mobile);
    
    console.log('Deterministic Stability Verified: Ciphertexts are identical across rotations.');
  });
});
