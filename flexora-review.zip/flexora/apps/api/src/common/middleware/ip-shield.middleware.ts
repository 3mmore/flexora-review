import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { SecurityShieldService } from '../../modules/security/security-shield.service';
import { probeKindOfRequest } from '../health/probe-routes';
import ipaddr from 'ipaddr.js';

/**
 * Trusted proxy CIDRs. Requests claiming to come from these addresses
 * via X-Forwarded-For are accepted; all other X-Forwarded-For values
 * are ignored (the IP is taken from req.ip / the connection socket).
 *
 * Update this list to match your actual reverse proxy / load balancer
 * infrastructure. The defaults cover common Docker bridge networks and
 * local development.
 */
const TRUSTED_PROXY_CIDRS = [
  '127.0.0.0/8',      // localhost
  '10.0.0.0/8',       // private / Docker bridge
  '172.16.0.0/12',    // private / Docker bridge
  '192.168.0.0/16',   // private LAN
  '::1/128',          // IPv6 localhost
];

function canonicalizeIp(raw: string): string {
  try {
    const addr = ipaddr.parse(raw.trim());
    // Normalize IPv4-mapped IPv6 (::ffff:1.2.3.4) to plain IPv4
    if (addr.kind() === 'ipv6' && (addr as ipaddr.IPv6).isIPv4MappedAddress()) {
      return (addr as ipaddr.IPv6).toIPv4Address().toString();
    }
    return addr.toString();
  } catch {
    return '0.0.0.0';
  }
}

function isTrustedProxy(ip: string): boolean {
  try {
    const addr = ipaddr.parse(ip.trim());
    return TRUSTED_PROXY_CIDRS.some((cidr) => addr.match(ipaddr.parseCIDR(cidr)));
  } catch {
    return false;
  }
}

function extractClientIp(req: Request): string {
  // Use Express's trust-proxy-resolved IP as the primary source
  const socketIp = req.ip || req.socket.remoteAddress || '0.0.0.0';

  // Only trust X-Forwarded-For if the immediate connection is from a known proxy
  const forwarded = req.headers['x-forwarded-for'];
  if (forwarded && isTrustedProxy(socketIp)) {
    const first = (Array.isArray(forwarded) ? forwarded[0] : forwarded).split(',')[0].trim();
    return canonicalizeIp(first);
  }

  return canonicalizeIp(socketIp);
}

@Injectable()
export class IpShieldMiddleware implements NestMiddleware {
  constructor(
    private shield: SecurityShieldService
  ) {}

  async use(req: Request, res: Response, next: NextFunction) {
    const ip = extractClientIp(req);

    req.__clientIp = ip;

    // PHASE Q2 — the infrastructure probes never consult the blocklist.
    //
    // `isBlocked()` is one Redis GET. This middleware is applied to "*", so it
    // ran on `/api/health/live` too, and with Redis unreachable that GET rejected
    // (bounded since PHASE P3, so it rejected fast) and the probe answered
    // 503 REDIS_UNAVAILABLE instead of 200 — the container reported itself broken
    // because a dependency its liveness probe does not need was down.
    //
    // PHASE P3 tried to fix this with `.exclude("api/health/live", …)` in
    // app.module.ts. That never worked: Nest's RouteInfoPathExtractor PREPENDS the
    // global prefix to a non-wildcard exclude path, so the exclusion was
    // registered as `/api/api/health/live` (measured against Nest 11's own
    // extractor in common/health/health-probe-isolation.spec.ts).
    //
    // The check here is by ROUTE IDENTITY: `probeKindOfRequest` matches against
    // the path set derived from the `@HealthProbe(...)` marker on the health
    // controller's handlers, in both prefixed and prefix-free form, so it is
    // correct whichever rewrite Express or Nest applied. The client IP is still
    // canonicalised above (pure, no I/O) so nothing downstream loses it.
    if (probeKindOfRequest(req)) return next();

    const blocked = await this.shield.isBlocked(ip);
    if (blocked) {
      res.status(403).json({
        statusCode: 403,
        message: 'Access denied',
      });
      return;
    }
    next();
  }
}

// Extend Express Request to include canonicalized client IP
declare global {
  namespace Express {
    interface Request {
      __clientIp?: string;
    }
  }
}
