import { isProduction } from '../../config/env-mode';
import { Injectable, NestMiddleware, HttpException, HttpStatus } from '@nestjs/common';
import { randomBytes, timingSafeEqual } from 'crypto';
import { Request, Response, NextFunction } from 'express';
import { isCookieSecure } from '../../config/cookie-secure';
import { probeKindOfRequest } from '../health/probe-routes';

// SECURITY (Item 7 fix): explicit allow-list of the real webhook routes in
// this codebase, enumerated by exact prefix.
const WEBHOOK_ROUTE_PREFIXES = [
  '/api/billing/webhook',
  '/api/stripe/webhook',
  '/api/paymob/webhook',
  '/api/webhooks/whatsapp',
  '/api/wa-bot/webhook/',
] as const;

function isKnownWebhookRoute(path: string): boolean {
  return WEBHOOK_ROUTE_PREFIXES.some((prefix) =>
    prefix.endsWith('/') ? path.startsWith(prefix) : path === prefix,
  );
}

/**
 * Routes that set or clear cookies, excluded from CSRF token checks.
 * These are protected by SameSite=Strict/Lax + Origin/Referer validation
 * (see validateOriginReferer below).
 *
 * Per-route rationale (F-025):
 * - auth/login, auth/register, auth/refresh:  Set flx_access/flx_refresh cookies
 * - auth/logout:                               Clear auth cookies
 * - auth/forgot-password, auth/reset-password: No cookies, but pre-auth
 * - auth/2fa/login:                            Set flx_access/flx_refresh after TOTP
 * - platform/auth/login:                       Set flx_platform_token cookie
 * - portal/request-otp:                        No cookies, but pre-auth
 * - portal/verify-otp:                         Set flx_member_access cookie
 * - billing/webhook, stripe/webhook,
 *   paymob/webhook, webhooks,
 *   wa-bot/webhook:                            Authenticated via HMAC/Bearer
 */
const COOKIE_SETTING_ROUTES = [
  '/api/auth/login', '/api/auth/register', '/api/auth/refresh', '/api/auth/logout',
  '/api/auth/forgot-password', '/api/auth/reset-password', '/api/auth/2fa/login',
  '/api/platform/auth/login',
  '/api/portal/request-otp', '/api/portal/verify-otp',
  // P2 kiosk: the device has NO browser session/cookie — it authenticates with
  // its secret x-device-token header (not forgeable cross-site). Still guarded
  // by the Origin/Referer check below.
  '/api/kiosk/checkin',
] as const;

function isCookieSettingRoute(path: string): boolean {
  return COOKIE_SETTING_ROUTES.some((route) => path === route);
}

/**
 * Validate Origin or Referer header for cookie-setting routes.
 * This provides defense-in-depth beyond SameSite cookies:
 * if SameSite is bypassed (e.g. legacy browser, proxy stripping,
 * or future SameSite=None deployment), the Origin/Referer check
 * still prevents cross-site request forgery.
 */
function validateOriginReferer(req: Request): void {
  const origin = req.headers.origin;
  const referer = req.headers.referer as string | undefined;
  const source = origin || referer;

  // No origin/referer header — likely a server-to-server or CLI call.
  // Allow through (the route's own auth/rate-limiting still applies).
  if (!source) return;

  try {
    const parsed = new URL(source);
    const hostname = parsed.hostname;

    // Allow localhost in development
    if (hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '::1') return;

    // Allow sandboxed live-preview hosts in development (proxied previews).
    // Production still requires an exact CORS_ORIGIN match below.
    if (!isProduction() && hostname.endsWith('.e2b.app')) return;

    // Check against configured CORS origins
    const allowedOrigins = (process.env.CORS_ORIGIN || 'http://localhost:3000').split(',');
    for (const allowed of allowedOrigins) {
      if (parsed.origin === allowed.trim()) return;
    }
  } catch {
    // Malformed Origin/Referer — reject
    throw new HttpException('Invalid origin', HttpStatus.FORBIDDEN);
  }

  // Origin/Referer does not match any allowed origin — reject
  throw new HttpException('Origin not allowed', HttpStatus.FORBIDDEN);
}

@Injectable()
export class CsrfMiddleware implements NestMiddleware {
  use(req: Request, res: Response, next: NextFunction) {
    // PHASE Q2 — infrastructure probes are GET-only, change no state and are
    // excluded by ROUTE IDENTITY (the `@HealthProbe` marker on the health
    // controller), not by a URL string. The `"api/health/live"` entry this
    // middleware's `.exclude()` list carried in app.module.ts never matched
    // anything: Nest prepends the global prefix to exclude paths, so it was
    // registered as `/api/api/health/live`. This check does not consult Redis or
    // the database either way — CSRF state lives in the `_csrf` cookie — but a
    // liveness probe must not be answerable only when every global component
    // happens to cooperate, so it is exempted here on the same terms.
    if (probeKindOfRequest(req)) return next();
    if (isKnownWebhookRoute(req.path)) return next();
    if (req.headers.authorization?.startsWith('Bearer ')) return next();

    // Cookie-setting routes: validate Origin/Referer instead of CSRF token
    if (isCookieSettingRoute(req.path)) {
      if (!['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
        validateOriginReferer(req);
      }
      return next();
    }

    const request = req as Request & { cookies?: Record<string, string> };
    const csrfCookie = request.cookies?._csrf;
    if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
      if (!csrfCookie) {
        res.cookie('_csrf', randomBytes(24).toString('hex'), { httpOnly: false, sameSite: 'lax', secure: isCookieSecure(), path: '/' });
      }
      return next();
    }

    const csrfHeader = String(req.headers['x-csrf-token'] || '');
    if (!csrfCookie || !csrfHeader) throw new HttpException('CSRF validation failed', HttpStatus.FORBIDDEN);
    const a = Buffer.from(csrfCookie);
    const b = Buffer.from(csrfHeader);
    if (a.length !== b.length || !timingSafeEqual(a, b)) throw new HttpException('CSRF validation failed', HttpStatus.FORBIDDEN);
    next();
  }
}
