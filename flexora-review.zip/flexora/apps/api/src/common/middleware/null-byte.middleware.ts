/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1 / review item 2 — refuse a NUL byte in the request target, for EVERY
 * path, before routing.
 *
 * Why it has to be path-independent: measured BEFORE R1
 * (work/r1-evidence/00-before.log B3 and 00c S1), `/platform%00` reached directly at
 * Next answered 307 -> /platform/login while `/definitely-not-a-route%00` answered
 * 404. That difference alone tells a scanner the console exists. A rule that only
 * fired on console paths would keep the signal; one rule for all paths removes it,
 * and it matches what nginx already does at the edge (400 for any path with a NUL).
 *
 * This is a Nest middleware rather than an `app.use()` in main.ts on purpose: main.ts
 * only runs in the real bootstrap, so a rule placed there is invisible to every
 * integration test that builds the app from AppModule - which is exactly where the
 * assertion belongs.
 *
 * Node's HTTP parser rejects a literal NUL in the request line, but a
 * percent-encoded %00 survives into req.url, so both spellings are checked.
 */
import { Injectable, NestMiddleware } from '@nestjs/common';
import { NextFunction, Request, Response } from 'express';

export function targetContainsNulByte(value: string | undefined | null): boolean {
  const target = String(value ?? '');
  return target.indexOf('\0') !== -1 || /%00/i.test(target);
}

@Injectable()
export class NullByteMiddleware implements NestMiddleware {
  use(req: Request, res: Response, next: NextFunction): void {
    // originalUrl keeps the query string; url is what the router will match. Both are
    // checked so `?redirect=%2Fplatform%00` cannot slip through either.
    if (targetContainsNulByte(req.originalUrl) || targetContainsNulByte(req.url)) {
      // The same status and the same body for every path: no path is echoed back, so
      // the response cannot be used to learn anything about what is being hidden.
      res.status(400).type('text/plain').send('Bad Request');
      return;
    }
    next();
  }
}
