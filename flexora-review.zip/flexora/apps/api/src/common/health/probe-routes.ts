/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
/**
 * PHASE Q2 — route IDENTITY for the infrastructure probes.
 *
 * The requirement: `/api/health/live` must answer 200 whatever Redis does, and
 * `/api/health/ready` must be free to report `redis: down` and answer 503. Every
 * global component that runs before the health controller therefore has to be
 * able to recognise those two routes — and it has to recognise them by ROUTE
 * IDENTITY, not by comparing a request URL against a hardcoded string.
 *
 * Why a string is not enough (all three were measured, not assumed):
 *
 *  1. `app.setGlobalPrefix('api')` rewrites `req.url`. A request for
 *     `/api/members?limit=1` reaches a guard with `req.url === '/?limit=1'`, so a
 *     string allow-list keyed on the full path silently matches nothing (this is
 *     how the PHASE P3 licence guard first refused `/api/health/live`).
 *  2. Nest's `MiddlewareConsumer.exclude()` does the OPPOSITE rewrite: its
 *     `RouteInfoPathExtractor` PREPENDS the global prefix to every non-wildcard
 *     path, so `.exclude('api/health/live')` is registered as `/api/api/health/live`
 *     and never matches. The PHASE P3 exclusions in `app.module.ts` were dead for
 *     exactly this reason, and `IpShieldMiddleware` kept calling
 *     `SecurityShieldService.isBlocked()` — one Redis GET — on the liveness probe.
 *     With Redis unreachable that rejection became the probe's answer: 503 instead
 *     of 200, i.e. the container reported itself broken because a dependency its
 *     liveness probe does not need was down.
 *  3. A URL can be decorated (`//api/health/live`, `/%61pi/health/live`, a trailing
 *     slash, a query string) while the route identity cannot.
 *
 * So the source of truth is a METHOD DECORATOR on the two handlers. This module
 * keeps the registry the decorator populates and answers two questions:
 *
 *   - `probeKindOfContext(ctx)` — for guards, interceptors and filters, which DO
 *     have the matched handler: read the marker straight off it. No strings at all.
 *   - `probeKindOfRequest(req)`  — for middleware, which runs BEFORE routing and
 *     therefore has no handler yet: compare every path representation Express
 *     exposes against the set of probe paths DERIVED FROM THE SAME METADATA
 *     (controller `path` + handler `path` + the global prefix), in both prefixed
 *     and prefix-free form, so whichever rewrite Nest or Express applied still
 *     resolves to the same route.
 *
 * Adding a probe is a one-line decorator on the handler; nothing else in the
 * codebase has to be told about it.
 */
import { ExecutionContext, SetMetadata } from '@nestjs/common';
import { PATH_METADATA } from '@nestjs/common/constants';
import { API_GLOBAL_PREFIX } from '../../config/api-prefix';

/** Metadata key carrying the probe kind on a route handler. */
export const HEALTH_PROBE_METADATA = 'flexora:health-probe';

/**
 * `live`  — pure ping. Must answer 200 whatever any dependency does.
 * `ready` — reports dependency state. May answer 503 when one is down.
 */
export type HealthProbeKind = 'live' | 'ready';

type ProbeEntry = {
  controllerClass: object;
  handler: object;
  kind: HealthProbeKind;
};

/**
 * Populated while controller classes are being defined, i.e. long before the
 * first request. Read lazily so that the controller-level `path` metadata (set by
 * `@Controller(...)`, which runs AFTER the method decorators) is available.
 */
const ENTRIES: ProbeEntry[] = [];

/**
 * Mark a route handler as an infrastructure probe.
 *
 * This is the ONLY place the probe routes are declared. It sets the marker that
 * guards/interceptors/filters read, and registers the handler so middleware can
 * resolve the same route by path before routing has happened.
 */
export function HealthProbe(kind: HealthProbeKind): MethodDecorator {
  return (target, propertyKey, descriptor) => {
    SetMetadata(HEALTH_PROBE_METADATA, kind)(target, propertyKey, descriptor);
    ENTRIES.push({
      controllerClass: (target as object).constructor as object,
      handler: (descriptor as TypedPropertyDescriptor<unknown>).value as object,
      kind,
    });
    return descriptor;
  };
}

function normaliseSlashes(...parts: Array<string | undefined>): string {
  const joined = parts
    .map((p) => String(p ?? '').trim())
    .filter((p) => p.length > 0 && p !== '/')
    .map((p) => p.replace(/^\/+/, '').replace(/\/+$/, ''))
    .filter(Boolean)
    .join('/');
  return joined ? `/${joined}` : '/';
}

type ResolvedProbe = { kind: HealthProbeKind; prefixed: string; unprefixed: string };

/** Resolve the registry: metadata -> the two path forms of each probe. */
export function resolvedProbes(prefix: string = API_GLOBAL_PREFIX): ResolvedProbe[] {
  return ENTRIES.map((entry) => {
    const controllerPath = String(Reflect.getMetadata(PATH_METADATA, entry.controllerClass) ?? '');
    const handlerPath = String(Reflect.getMetadata(PATH_METADATA, entry.handler) ?? '');
    const unprefixed = normaliseSlashes(controllerPath, handlerPath);
    return {
      kind: entry.kind,
      unprefixed,
      prefixed: normaliseSlashes(prefix, unprefixed),
    };
  });
}

/** How many probes are registered — used by the spec to catch an empty registry. */
export function registeredProbeCount(): number {
  return ENTRIES.length;
}

let cache: { paths: Map<string, HealthProbeKind>; prefix: string } | undefined;

function probePathIndex(prefix: string): Map<string, HealthProbeKind> {
  if (cache && cache.prefix === prefix) return cache.paths;
  const paths = new Map<string, HealthProbeKind>();
  for (const probe of resolvedProbes(prefix)) {
    // Every form the path can legitimately arrive in. Derived from metadata, so
    // a renamed route or a changed prefix follows automatically.
    for (const candidate of [probe.prefixed, probe.unprefixed]) {
      paths.set(candidate, probe.kind);
      paths.set(candidate.replace(/^\//, ''), probe.kind);
      if (candidate.length > 1) paths.set(`${candidate}/`, probe.kind);
    }
  }
  cache = { paths, prefix };
  return paths;
}

/**
 * The strings to hand `MiddlewareConsumer.exclude()`.
 *
 * Nest prepends the global prefix to them itself, so these are the PREFIX-FREE
 * forms. Passing the prefixed form is the PHASE P3 bug described above; the spec
 * pins both halves of that fact against Nest's own extractor.
 */
export function probeExclusionsForNest(prefix: string = API_GLOBAL_PREFIX): string[] {
  return resolvedProbes(prefix).map((p) => p.unprefixed.replace(/^\//, ''));
}

function pathCandidates(req: unknown): string[] {
  const r = (req || {}) as Record<string, unknown>;
  const raw: Array<string | undefined> = [];
  const push = (v: unknown) => {
    if (typeof v === 'string' && v.length) raw.push(v);
  };
  push(r.originalUrl);
  push(r.url);
  push(r.path);
  if (typeof r.baseUrl === 'string' && typeof r.url === 'string') push(`${r.baseUrl}${r.url}`);
  const out: string[] = [];
  for (const value of raw) {
    if (!value) continue;
    const noQuery = value.split('?')[0].split('#')[0];
    out.push(noQuery);
    // a doubled prefix is what a mis-derived exclusion produces; tolerating it
    // here costs nothing and keeps the probe working if a future Nest version
    // rewrites paths differently again
    out.push(noQuery.replace(new RegExp(`^/${API_GLOBAL_PREFIX}/${API_GLOBAL_PREFIX}/`), `/${API_GLOBAL_PREFIX}/`));
  }
  return out;
}

/**
 * Middleware-time identification. Returns the probe kind, or undefined for every
 * other route. Exact match only — no prefix wildcards, so `/api/health/live-x`
 * or `/api/health/liveness` are NOT probes.
 */
export function probeKindOfRequest(req: unknown): HealthProbeKind | undefined {
  const index = probePathIndex(API_GLOBAL_PREFIX);
  if (!index.size) return undefined;
  for (const candidate of pathCandidates(req)) {
    const direct = index.get(candidate);
    if (direct) return direct;
    const noTrailing = candidate.length > 1 ? candidate.replace(/\/+$/, '') : candidate;
    const trimmed = index.get(noTrailing);
    if (trimmed) return trimmed;
  }
  return undefined;
}

/** True when this request is one of the infrastructure probes. */
export function isProbeRequest(req: unknown): boolean {
  return probeKindOfRequest(req) !== undefined;
}

/**
 * Guard/interceptor/filter-time identification: read the marker off the matched
 * handler. This is pure route identity — no URL is inspected at all.
 */
export function probeKindOfContext(context: ExecutionContext): HealthProbeKind | undefined {
  const handler = context.getHandler?.();
  if (!handler) return undefined;
  const kind = Reflect.getMetadata(HEALTH_PROBE_METADATA, handler) as HealthProbeKind | undefined;
  return kind === 'live' || kind === 'ready' ? kind : undefined;
}

/** True when the matched route is one of the infrastructure probes. */
export function isProbeContext(context: ExecutionContext): boolean {
  return probeKindOfContext(context) !== undefined;
}
