import { Test, TestingModule } from '@nestjs/testing';
import { CronLeadershipService } from './cron-leadership.service';
import { InstanceIdService } from './instance-id.service';
import { RedisService } from '../../config/redis.service';

describe('CronLeadershipService (Distributed Lock Stress)', () => {
  let redis: any;

  beforeEach(() => {
    const store = new Map();
    redis = {
      client: {
        set: jest.fn(async (key, val, px, ttl, nx) => {
          if (nx === 'NX' && store.has(key)) return null;
          store.set(key, val);
          return 'OK';
        }),
        get: jest.fn(async (key) => store.get(key)),
        del: jest.fn(async (key) => store.delete(key)),
        eval: jest.fn(async (_script, _keys, key, owner) => {
          if (store.get(key) !== owner) return 0;
          store.delete(key);
          return 1;
        }),
      }
    };
  });

  it('Instance A should acquire lock, Instance B should be rejected', async () => {
    const instanceA = { id: 'uuid-a' };
    const instanceB = { id: 'uuid-b' };

    const serviceA = new CronLeadershipService(redis, instanceA as any);
    const serviceB = new CronLeadershipService(redis, instanceB as any);

    const jobName = 'test-job';

    // 1. A acquires
    const acqA = await serviceA.acquireLock(jobName, 1000);
    expect(acqA).toBe(true);
    expect(redis.client.set).toHaveBeenCalledWith(`cron:lock:${jobName}`, 'uuid-a', 'PX', 1000, 'NX');

    // 2. B tries to acquire (rejected)
    const acqB = await serviceB.acquireLock(jobName, 1000);
    expect(acqB).toBe(false);

    // 3. B tries to release A's lock (should fail)
    await serviceB.releaseLock(jobName);
    expect(await redis.client.get(`cron:lock:${jobName}`)).toBe('uuid-a');

    // 4. A releases its lock
    await serviceA.releaseLock(jobName);
    expect(await redis.client.get(`cron:lock:${jobName}`)).toBeUndefined();
  });
});
