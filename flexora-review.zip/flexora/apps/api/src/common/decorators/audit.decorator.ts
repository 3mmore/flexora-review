import { SetMetadata } from '@nestjs/common';
import { AUDIT_KEY } from '../interceptors/audit.interceptor';
export interface AuditMeta { action: string; entity: string; }
export const Audit = (action: string, entity: string) => SetMetadata(AUDIT_KEY, { action, entity } as AuditMeta);
