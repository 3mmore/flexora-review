/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { createParamDecorator, ExecutionContext, ForbiddenException } from '@nestjs/common';

/** Resolves the tenant id pinned by TenantGuard. */
export function resolveGymId(_data: unknown, ctx: ExecutionContext): string {
  const req = ctx.switchToHttp().getRequest();
  if (!req.gymId) {
    throw new ForbiddenException('Tenant context is missing');
  }
  return req.gymId;
}

export const GYM_ID_METADATA_TEST_ONLY = resolveGymId;

export const GymId = createParamDecorator(resolveGymId);
