/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { DependencyUnavailableFilter } from './dependency-unavailable.filter';
import {
  ArgumentsHost,
  Catch,
  ExceptionFilter,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { Request, Response } from 'express';
import * as Sentry from '@sentry/node';
import { requestContext } from '../middleware/request-id.middleware';
import { maskSensitive } from '../security/data-masking';

@Catch()
export class HttpExceptionFilter implements ExceptionFilter {
  /**
   * PHASE P3 — a bounded Redis rejection, or the licence guard's 503, is answered
   * here rather than by the generic path below. `main.ts` registers this filter
   * with `useGlobalFilters`, which runs ahead of the APP_FILTER provider, so
   * delegating from here is what actually reaches the client: without it a Redis
   * outage surfaced as a bare 500 `server_error` with no Retry-After, telling the
   * client to give up instead of retrying a transient dependency failure.
   */
  private readonly dependencyFilter = new DependencyUnavailableFilter();

  private readonly logger = new Logger('Http');

  catch(exception: unknown, host: ArgumentsHost) {
    if (this.dependencyFilter.handles(exception)) {
      this.dependencyFilter.catch(exception, host);
      return;
    }
    const ctx = host.switchToHttp();
    const res = ctx.getResponse<Response>();
    const req = ctx.getRequest<Request>();

    let status = HttpStatus.INTERNAL_SERVER_ERROR;
    let message: string | object = 'server_error';

    if (exception instanceof HttpException) {
      status = exception.getStatus();
      message = exception.getResponse();
    } else if (exception && (exception as Record<string, unknown>).code === 'P2002') {
      status = HttpStatus.CONFLICT;
      message = 'unique_constraint_violation';
    } else if (exception && (exception as Record<string, unknown>).code === 'P2025') {
      status = HttpStatus.NOT_FOUND;
      message = 'not_found';
    } else if (exception && (exception as Record<string, unknown>).code === 'P2003') {
      status = HttpStatus.BAD_REQUEST;
      message = 'foreign_key_constraint_violation';
    } else if (
      exception &&
      (exception as Record<string, unknown>).type === 'entity.too.large'
    ) {
      // express/body-parser 413. Previously this fell through to the 500
      // "server_error" branch, which turned "payload too large" into an
      // opaque server error (the Phase 1 logo-upload regression).
      status = HttpStatus.PAYLOAD_TOO_LARGE;
      message = 'Request payload is too large. The maximum allowed size is 8MB.';
    }

    if (status >= 500) {
      const requestId = requestContext.getStore()?.requestId;
      this.logger.error(`${req.method} ${req.url} [${requestId || 'no-id'}]`, (exception as Error)?.stack);
      // Capture 5xx errors to Sentry with request context
      if (Sentry.getClient()) {
        Sentry.captureException(exception, (scope) => {
          if (requestId) scope.setTag('request_id', requestId);
          scope.setExtra('http', {
            method: req.method,
            url: req.url,
            query: maskSensitive(req.query),
            body: maskSensitive(req.body),
            headers: {
              'user-agent': req.get('user-agent'),
              'content-type': req.get('content-type'),
            },
          });
          return scope;
        });
      }
    }

    /**
     * `message` is passed through AS-IS when it is a list: DTO validation can
     * fail on several fields at once and the client renders every reason. This
     * used to keep only message[0] — and only a fixed set of metadata keys — so
     * a rejected request reached the UI as one truncated line (or "HTTP 400").
     */
    const body: Record<string, unknown> = {
      statusCode: status,
      path: req.url,
      timestamp: new Date().toISOString(),
      message: Array.isArray(message)
        ? message
        : (typeof message === 'string' ? message : (message as any).message || message),
    };
    // Pass through structured error metadata (code/translationKey + real
    // numbers like current/limit/tier, plus the per-field validation issues)
    // so the web client can render translated, specific messages
    // (see web src/lib/safe-error.ts and common/validation/validation-errors.ts).
    if (message && typeof message === 'object' && !Array.isArray(message)) {
        // PHASE N1.5: 'memberCount' joins the numeric, non-sensitive fields
        // (current/limit/tier). The plans page renders it in the "move these
        // members to another plan first" dialog; it was being dropped here, so the
        // dialog claimed "0 members" while asking the operator to move them.
        for (const key of ['code', 'translationKey', 'current', 'limit', 'tier', 'memberCount', 'messages', 'errors']) {
        if ((message as any)[key] !== undefined) body[key] = (message as any)[key];
      }
    }
    res.status(status).json(body);
  }

}
