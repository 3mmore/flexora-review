import { Injectable, Logger } from '@nestjs/common';
import { ProductEventSignalBridge } from '../events/PRODUCT_EVENT_SIGNAL_BRIDGE';
import { NormalizedProductEvent } from '../events/PRODUCT_EVENT_SCHEMA';

@Injectable()
export class ProductEventWorker {
  private readonly logger = new Logger(ProductEventWorker.name);

  constructor(private readonly signalBridge: ProductEventSignalBridge) {}

  async processEvent(event: Record<string, unknown>) {
    const enriched = await this.enrichEvent(event);
    const signals = this.signalBridge.toSignals(enriched as unknown as NormalizedProductEvent);
    await this.routeEventToConsumers(enriched, signals);
    await this.triggerSideEffects(enriched, signals);
    return { event: enriched, signals };
  }

  async enrichEvent(event: Record<string, unknown>): Promise<Record<string, unknown>> {
    return { ...event, processedAt: new Date() };
  }

  async routeEventToConsumers(event: Record<string, unknown>, signals: unknown[]) {
    this.logger.debug(`Routing ${String(event.type)} to ${signals.length} signal consumer(s)`);
  }

  async triggerSideEffects(event: Record<string, unknown>, signals: unknown[]) {
    this.logger.debug(`Side effects evaluated for ${String(event.type)}: ${signals.map((s) => (s as { kind: string }).kind).join(',')}`);
  }
}
