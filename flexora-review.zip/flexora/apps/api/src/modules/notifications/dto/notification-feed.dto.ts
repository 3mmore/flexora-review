/**
 * FLEXORA Gym OS — DTOs for the owner notification INBOX (Phase A).
 *
 * The existing `GET /owner/notifications` keeps its query handling untouched
 * (no DTO, capped at 100, bare array). Everything here belongs to the NEW
 * `/owner/notifications/feed` route, so the global ValidationPipe
 * (whitelist + forbidNonWhitelisted) rejects unknown parameters instead of
 * silently ignoring them, and every value is bounded.
 */
import { Type } from 'class-transformer';
import {
  IsIn,
  IsInt,
  IsOptional,
  IsString,
  Matches,
  Max,
  MaxLength,
  Min,
} from 'class-validator';

export const NOTIFICATION_STATUS_VALUES = ['all', 'unread', 'read'] as const;
export const NOTIFICATION_SEVERITY_VALUES = ['info', 'warning', 'danger', 'success'] as const;
export const NOTIFICATION_SORT_VALUES = ['newest', 'oldest'] as const;

/** Hard ceiling on a page. The UI asks for 20; nothing may ask for more. */
export const NOTIFICATION_MAX_PAGE_SIZE = 100;
/** Hard ceiling on a filter range, inclusive of both ends. */
export const NOTIFICATION_MAX_RANGE_DAYS = 366;
/** Longest accepted search string. */
export const NOTIFICATION_MAX_SEARCH = 100;

export class NotificationFeedQueryDto {
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(100000)
  page?: number;

  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(NOTIFICATION_MAX_PAGE_SIZE)
  pageSize?: number;

  @IsOptional() @IsIn(NOTIFICATION_STATUS_VALUES as unknown as string[])
  status?: (typeof NOTIFICATION_STATUS_VALUES)[number];

  @IsOptional() @IsIn(NOTIFICATION_SEVERITY_VALUES as unknown as string[])
  severity?: (typeof NOTIFICATION_SEVERITY_VALUES)[number];

  /**
   * Notification type is data, not an enum: new producers may add types without a
   * migration. The filter is therefore shape-validated (upper snake case) and, if
   * it matches nothing, returns an empty page — never an error that would leak
   * which types exist in another gym.
   */
  @IsOptional() @IsString() @Matches(/^[A-Z][A-Z0-9_]{0,39}$/, { message: 'type must be an upper-snake-case code' })
  type?: string;

  /** Gym-local calendar day, YYYY-MM-DD, inclusive. */
  @IsOptional() @IsString() @Matches(/^\d{4}-\d{2}-\d{2}$/, { message: 'from must be YYYY-MM-DD' })
  from?: string;

  /** Gym-local calendar day, YYYY-MM-DD, inclusive. */
  @IsOptional() @IsString() @Matches(/^\d{4}-\d{2}-\d{2}$/, { message: 'to must be YYYY-MM-DD' })
  to?: string;

  /** Free text matched against title and body (case-insensitive, literal). */
  @IsOptional() @IsString() @MaxLength(NOTIFICATION_MAX_SEARCH) q?: string;

  @IsOptional() @IsIn(NOTIFICATION_SORT_VALUES as unknown as string[])
  sort?: (typeof NOTIFICATION_SORT_VALUES)[number];
}

/** Query for the lightweight type list used to fill the filter dropdown. */
export class NotificationTypesQueryDto {
  @IsOptional() @IsString() @Matches(/^\d{4}-\d{2}-\d{2}$/)
  from?: string;

  @IsOptional() @IsString() @Matches(/^\d{4}-\d{2}-\d{2}$/)
  to?: string;
}
