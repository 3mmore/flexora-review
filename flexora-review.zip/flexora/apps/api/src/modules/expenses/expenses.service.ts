/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { CreateExpenseDto, ListExpensesDto } from './dto';

@Injectable()
export class ExpensesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly redis: RedisService,
  ) {}

  private async invalidate(gymId: string) {
    try { await this.redis.del(`reports:dashboard:${gymId}`); } catch { /* redis down */ }
  }

  /** Paginated + filterable (branch / category / date range), tenant-scoped. */
  async list(gymId: string, q: ListExpensesDto) {
    const where: Prisma.ExpenseWhereInput = { gymId };
    if (q.branchId && q.branchId !== 'all') where.branchId = q.branchId;
    if (q.category && q.category !== 'all') where.category = q.category;
    if (q.from || q.to) {
      where.createdAt = {};
      if (q.from) (where.createdAt as Prisma.DateTimeFilter).gte = new Date(q.from);
      if (q.to) (where.createdAt as Prisma.DateTimeFilter).lte = new Date(q.to);
    }
    const page = q.page ?? 1;
    const limit = q.limit ?? 20;
    const [items, total] = await this.prisma.$transaction([
      this.prisma.expense.findMany({
        where,
        include: { branch: true },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      this.prisma.expense.count({ where }),
    ]);
    return { items, total, page, limit };
  }

  /** Atomically write Expense + matching EXPENSE Transaction. */
  async create(gymId: string, userName: string, dto: CreateExpenseDto) {
    if (dto.branchId) {
      const branch = await this.prisma.branch.findFirst({ where: { id: dto.branchId, gymId } });
      if (!branch) throw new BadRequestException('Invalid branch');
    }
    const exp = await this.prisma.withTenant(gymId, async (tx) => {
      const exp = await tx.expense.create({
        data: {
          gymId,
          category: dto.category || 'general',
          description: dto.description || 'Expense',
          amount: dto.amount,
          branchId: dto.branchId || undefined,
          userName: userName || '',
        },
      });
      await tx.transaction.create({
        data: {
          gymId,
          type: 'EXPENSE',
          category: dto.category || 'general',
          description: dto.description || 'Expense',
          amount: dto.amount,
          userName: userName || '',
          expenseId: exp.id,
        },
      });
      return exp;
    });
    await this.invalidate(gymId);
    return exp;
  }

  /** Delete an expense and its linked ledger Transaction atomically. */
  async remove(gymId: string, id: string) {
    const exp = await this.prisma.expense.findFirst({ where: { id, gymId } });
    if (!exp) throw new NotFoundException('Expense not found');
    // PHASE N2 — this was `$transaction([ ... ])` (array form). Under the
    // tenant-RLS $extends middleware every element of an array batch is
    // wrapped in its OWN set_config+query transaction, so the batch was never
    // atomic: if the second statement failed, the first stayed committed.
    // One interactive transaction via withTenant() instead — the same fix
    // PlansService.remove got in PHASE N1.5, and what the doc-comment on
    // PrismaService.$transaction now requires of every write batch.
    await this.prisma.withTenant(gymId, async (tx) => {
      await tx.transaction.deleteMany({ where: { gymId, expenseId: id } });
      await tx.expense.delete({ where: { id, gymId } });
    });
    return { ok: true };
  }
}
