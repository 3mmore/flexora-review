/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Delete, Get, Param, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ExpensesService } from './expenses.service';
import { CreateExpenseDto, ListExpensesDto } from './dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

@ApiTags('expenses')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller('expenses')
export class ExpensesController {
  constructor(private readonly svc: ExpensesService) {}

  @Get() @Permissions('accounting.view')
  list(@GymId() g: string, @Query() q: ListExpensesDto) {
    return this.svc.list(g, q);
  }

  @Post() @Permissions('accounting.manage') @Audit('create', 'Expense')
  create(@GymId() g: string, @CurrentUser('name') u: string, @Body() d: CreateExpenseDto) {
    return this.svc.create(g, u, d);
  }

  @Delete(':id') @Permissions('accounting.manage') @Audit('delete', 'Expense')
  remove(@GymId() g: string, @Param('id') id: string) {
    return this.svc.remove(g, id);
  }
}
