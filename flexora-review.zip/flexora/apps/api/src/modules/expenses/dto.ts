/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { IsNumber, IsOptional, IsString, Min, IsInt, IsDateString } from 'class-validator';
import { Type } from 'class-transformer';

export class CreateExpenseDto {
  @IsString() category!: string;
  @IsOptional() @IsString() description?: string;
  @IsNumber() @Min(0) amount!: number;
  @IsOptional() @IsString() branchId?: string;
}

export class ListExpensesDto {
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) page = 1;
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) limit = 20;
  @IsOptional() @IsString() branchId?: string;
  @IsOptional() @IsString() category?: string;
  @IsOptional() @IsDateString() from?: string;
  @IsOptional() @IsDateString() to?: string;
}
