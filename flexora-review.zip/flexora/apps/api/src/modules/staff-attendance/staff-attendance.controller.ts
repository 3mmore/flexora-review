/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { IsIn, IsNumber, IsOptional, IsString } from 'class-validator';
import { StaffAttendanceService } from './staff-attendance.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { RequiresFeature } from '../license/license.module';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

class StaffAttendanceBulkDto {
  @IsString() userId!: string;
  @IsNumber() hourlyRate!: number;
  @IsOptional() @IsString() currency?: string;
}

/** P2-3: shift schedule rows (per-staff or gym-wide template when userId is omitted). */
class CreateShiftDto {
  @IsOptional() @IsString() userId?: string;
  @IsOptional() @IsString() name?: string;
  @IsNumber() dayOfWeek!: number;
  @IsNumber() startMin!: number;
  @IsNumber() endMin!: number;
  @IsOptional() @IsNumber() graceMin?: number;
  @IsOptional() @IsString() tz?: string;
  @IsOptional() @IsIn([true, false]) active?: boolean;
}

class UpdateShiftDto {
  @IsOptional() @IsString() name?: string;
  @IsOptional() @IsNumber() dayOfWeek?: number;
  @IsOptional() @IsNumber() startMin?: number;
  @IsOptional() @IsNumber() endMin?: number;
  @IsOptional() @IsNumber() graceMin?: number;
  @IsOptional() @IsString() tz?: string;
  @IsOptional() @IsIn([true, false]) active?: boolean;
}

class CheckInDto {
  @IsOptional() @IsIn(['QR', 'MANUAL']) method?: 'QR' | 'MANUAL';
  @IsOptional() @IsString() branchId?: string;
  @IsOptional() @IsString() notes?: string;
}

@ApiTags('staff-attendance')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@RequiresFeature('staff_attendance')
@Controller('staff-attendance')
export class StaffAttendanceController {
  constructor(private readonly svc: StaffAttendanceService) {}

  @Post('checkin') @Permissions('attendance.manual') @Audit('staff_check_in', 'StaffAttendance')
  checkinAlias(@GymId() gymId: string, @CurrentUser('sub') userId: string, @Body() dto: CheckInDto) { return this.svc.checkIn(gymId, userId, dto); }

  @Post('check-in') @Permissions('attendance.manual') @Audit('staff_check_in', 'StaffAttendance')
  checkIn(
    @GymId() gymId: string,
    @CurrentUser('sub') userId: string,
    @Body() dto: CheckInDto,
  ) { return this.svc.checkIn(gymId, userId, dto); }

  @Post('checkout') @Permissions('attendance.manual') @Audit('staff_check_out', 'StaffAttendance')
  checkoutAlias(@GymId() gymId: string, @CurrentUser('sub') userId: string) { return this.svc.checkOut(gymId, userId); }

  @Post('check-out') @Permissions('attendance.manual') @Audit('staff_check_out', 'StaffAttendance')
  checkOut(@GymId() gymId: string, @CurrentUser('sub') userId: string) {
    return this.svc.checkOut(gymId, userId);
  }

  // ROUND 13 (Phase 1): the staff-attendance page is Reception-visible and
  // "who is on the floor today" is front-desk operational data. Branch-safe:
  // StaffAttendance carries branchId, so the Prisma branch-scope middleware
  // pins a Reception user to their own branch automatically.
  @Get('today')
  @Permissions('attendance.manual')
  today(@GymId() gymId: string) { return this.svc.listToday(gymId); }

  @Get('user/:userId')
  @Permissions('staff.manage')
  forUser(
    @GymId() gymId: string,
    @Param('userId') userId: string,
    @Query('from') from?: string,
    @Query('to') to?: string,
  ) {
    const fromD = from ? new Date(from) : new Date(Date.now() - 30 * 86400000);
    const toD = to ? new Date(to) : new Date();
    return this.svc.listForUser(gymId, userId, fromD, toD);
  }

  @Post('pay-profile') @Permissions('staff.manage') @Audit('upsert_pay_profile', 'StaffPayProfile')
  payProfile(
    @GymId() gymId: string,
    @Body() dto: StaffAttendanceBulkDto,
  ) {
    return this.svc.upsertPayProfile(gymId, dto.userId, Number(dto.hourlyRate), dto.currency || 'EGP');
  }

  @Get('payroll/export')
  @Permissions('staff.manage')
  payrollExport(@GymId() gymId: string, @Query('from') from?: string, @Query('to') to?: string) {
    const fromD = from ? new Date(from) : new Date(Date.now() - 14 * 86400000);
    const toD = to ? new Date(to) : new Date();
    return this.svc.exportPayroll(gymId, fromD, toD);
  }

  // ── P2-3: shift schedules ──────────────────────────────────────────────
  @Get('shifts')
  @Permissions('staff.manage')
  shifts(@GymId() gymId: string) {
    return this.svc.listShifts(gymId);
  }

  @Post('shifts')
  @Permissions('staff.manage')
  @Audit('create', 'StaffShift')
  createShift(@GymId() gymId: string, @Body() dto: CreateShiftDto) {
    return this.svc.createShift(gymId, dto);
  }

  @Patch('shifts/:id')
  @Permissions('staff.manage')
  @Audit('update', 'StaffShift')
  updateShift(@GymId() gymId: string, @Param('id') id: string, @Body() dto: UpdateShiftDto) {
    return this.svc.updateShift(gymId, id, dto);
  }

  @Delete('shifts/:id')
  @Permissions('staff.manage')
  @Audit('delete', 'StaffShift')
  deleteShift(@GymId() gymId: string, @Param('id') id: string) {
    return this.svc.deleteShift(gymId, id);
  }
}
