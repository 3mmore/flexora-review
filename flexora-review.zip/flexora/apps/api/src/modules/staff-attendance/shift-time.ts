/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * P2-3: timezone-aware shift math.
 *
 * Shifts store startMin/endMin as minutes-from-midnight in THEIR OWN
 * timezone (tz, defaults to Africa/Cairo). All lateness math below works in
 * that wall clock so a 09:00 shift means 09:00 local gym time regardless of
 * the server's clock — including across DST changes (Egypt reintroduced DST
 * in 2023).
 */

export interface ShiftLike {
  dayOfWeek: number;
  startMin: number;
  graceMin: number;
  tz: string;
}

const WEEKDAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

/** Wall-clock parts of `date` in timezone `tz` (hourCycle h23 — no "24:00"). */
export function wallParts(date: Date, tz: string) {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: tz,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
    hourCycle: 'h23', weekday: 'short',
  }).formatToParts(date);
  const get = (type: string) => parts.find((p) => p.type === type)?.value || '';
  return {
    year: Number(get('year')),
    month: Number(get('month')),
    day: Number(get('day')),
    hour: Number(get('hour')),
    minute: Number(get('minute')),
    dayOfWeek: WEEKDAYS.indexOf(get('weekday')),
  };
}

/** Milliseconds `tz` is ahead of UTC at `date` (UTC+2 → +7200000). */
export function tzOffsetMs(date: Date, tz: string): number {
  const asUtc = new Date(date.toLocaleString('en-US', { timeZone: 'UTC' }));
  const asLocal = new Date(date.toLocaleString('en-US', { timeZone: tz }));
  return asLocal.getTime() - asUtc.getTime();
}

export interface LatenessResult {
  /** null when the shift does not apply to `now`'s weekday in its tz. */
  expectedAt: Date | null;
  /** 0 = on time (or early / within grace), >0 = minutes late. */
  lateMinutes: number;
}

/**
 * Evaluate how late `now` is against `shift`.
 * Returns expectedAt=null when today (in the shift's timezone) is not the
 * shift's weekday — check-ins on unscheduled days are never marked late.
 */
export function evaluateLateness(now: Date, shift: ShiftLike): LatenessResult {
  const tz = shift.tz || 'Africa/Cairo';
  const wall = wallParts(now, tz);
  if (wall.dayOfWeek !== shift.dayOfWeek) return { expectedAt: null, lateMinutes: 0 };

  // Epoch of "startMin minutes past midnight, local gym time, today".
  const expectedEpoch =
    Date.UTC(wall.year, wall.month - 1, wall.day) + shift.startMin * 60_000 - tzOffsetMs(now, tz);
  const expectedAt = new Date(expectedEpoch);

  const minutesLate = Math.floor((now.getTime() - expectedEpoch) / 60_000) - shift.graceMin;
  return { expectedAt, lateMinutes: Math.max(0, minutesLate) };
}

/** Format minutes-from-midnight as HH:MM (for API responses). */
export function minutesToHHMM(min: number): string {
  const h = Math.floor(min / 60);
  const m = min % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}
