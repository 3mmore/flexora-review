/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Autonomous Execution Service (Level 2).
 * Turns validated Product-Brain decisions into REAL, persisted, traceable,
 * reversible operational actions. Mirrors scripts/execute-product-brain.mjs.
 *
 *  - Non-destructive only (hard allowlist; destructive types are impossible).
 *  - Level 2: tasks/workflows auto-EXECUTED; high-impact intents stored as
 *    PENDING_APPROVAL and never executed without a human.
 *  - Every action persisted to AutonomousAction (Signal→Decision→Action→Owner→Outcome).
 *  - Tenant-isolated by gymId on every read/write.
 */
import { BadRequestException, ForbiddenException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';
import { Prisma, TaskStatus, AutonomousActionType, AutonomousActionStatus, AutonomousOutcome } from '@prisma/client';

/* Decision thresholds — parity with the validated brain (validate-product-brain.mjs). */
export const THRESHOLDS = {
  CHURN_CRITICAL: 30,
  CHURN_WATCH: 15,
  RETENTION_HEALTHY: 80,
  UTILIZATION_LOW: 40,
} as const;

const ALLOWED: AutonomousActionType[] = [
  AutonomousActionType.CREATE_TASK, AutonomousActionType.CREATE_WORKFLOW, AutonomousActionType.ASSIGN_STAFF, AutonomousActionType.SCHEDULE_REMINDER,
  AutonomousActionType.CREATE_RECOMMENDATION, AutonomousActionType.QUEUE_COMMUNICATION, AutonomousActionType.OPEN_REVIEW_REQUEST,
];
/** High-impact intents that may NEVER be auto-executed (Level 4 / human only). */
export const HIGH_IMPACT = ['change_pricing', 'cancel_subscription', 'charge_payment', 'modify_contract', 'delete_member'];

export interface ChurnCtx { gymId: string; churnRisk: number; memberId?: string; bestCoachUserId?: string; bestCoachLabel?: string; }
export interface RevenueCtx { gymId: string; revenueTrendDown: boolean; ownerUserId?: string; segments?: string[]; }
export interface UtilizationCtx { gymId: string; utilization: number; staffCount: number; opsManagerUserId?: string; }
export interface RecoveryCtx { gymId: string; memberId: string; status: 'expired' | 'frozen' | 'inactive'; ownerUserId?: string; }

interface ActionDraft {
  flow: string;
  signal: string;
  decision: string;
  reason: string;
  type: AutonomousActionType;
  title: string;
  ownerUserId?: string | null;
  ownerLabel: string;
  subjectType?: string | null;
  subjectId?: string | null;
  dueInHours?: number | null;
  pendingIntent?: string | null;
  meta?: Record<string, unknown>;
}

const TASK_OPEN_STATUS = TaskStatus.TODO;

@Injectable()
export class ExecutionService {
  private readonly logger = new Logger(ExecutionService.name);
  constructor(private readonly prisma: PrismaService) {}

  /* ---- Hard safety guard: refuse anything outside the allowlist ---- */
  private assertSafe(type: AutonomousActionType) {
    if (!ALLOWED.includes(type)) {
      throw new ForbiddenException(`Autonomous action '${type}' is not permitted (non-destructive allowlist).`);
    }
  }

  /** Persist one safe action. CREATE_TASK also creates a real CRM Task and links it. */
  private async persist(gymId: string, d: ActionDraft) {
    this.assertSafe(d.type);
    const isApproval = d.type === AutonomousActionType.OPEN_REVIEW_REQUEST && !!d.pendingIntent;
    const dueAt = d.dueInHours ? new Date(Date.now() + d.dueInHours * 3600 * 1000) : null;

    // Side effect: a CREATE_TASK action creates an actual Task record (Level 2).
    let taskId: string | null = null;
    if (d.type === AutonomousActionType.CREATE_TASK) {
      const task = await this.prisma.task.create({
        data: {
          gymId,
          userId: d.ownerUserId ?? undefined,
          title: d.title,
          description: `[autonomous] ${d.decision} — ${d.reason}`,
          status: TASK_OPEN_STATUS,
          dueAt: dueAt ?? undefined,
        },
      });
      taskId = task.id;
    }

    const action = await this.prisma.autonomousAction.create({
      data: {
        gymId,
        flow: d.flow,
        signal: d.signal,
        decision: d.decision,
        reason: d.reason,
        type: d.type,
        title: d.title,
        ownerUserId: d.ownerUserId ?? null,
        ownerLabel: d.ownerLabel,
        subjectType: d.subjectType ?? null,
        subjectId: d.subjectId ?? null,
        status: isApproval ? AutonomousActionStatus.PENDING_APPROVAL : AutonomousActionStatus.EXECUTED,
        autonomyLevel: isApproval ? 4 : 2,
        pendingIntent: d.pendingIntent ?? null,
        dueAt,
        taskId,
        meta: (d.meta || {}) as Prisma.InputJsonValue,
      },
    });
    return action;
  }

  /* =====================================================================
     1. CHURN EXECUTION FLOW (churnRisk >= 30)
     ===================================================================== */
  async runChurnFlow(ctx: ChurnCtx) {
    if (ctx.churnRisk < THRESHOLDS.CHURN_CRITICAL) return [];
    const owner = ctx.bestCoachLabel || 'best-available-coach';
    const sig = `churnRisk=${ctx.churnRisk}%`;
    const reason = `Churn risk is critical at ${ctx.churnRisk}% (at/above the ${THRESHOLDS.CHURN_CRITICAL}% line); intervention is needed.`;
    return Promise.all([
      this.persist(ctx.gymId, { flow: 'churn', signal: sig, decision: 'critical retention risk', reason, type: 'CREATE_TASK', title: `Retention outreach — churn risk ${ctx.churnRisk}%`, ownerUserId: ctx.bestCoachUserId, ownerLabel: owner, subjectType: 'member', subjectId: ctx.memberId, dueInHours: 48 }),
      this.persist(ctx.gymId, { flow: 'churn', signal: sig, decision: 'critical retention risk', reason: 'AI best-coach match', type: 'ASSIGN_STAFF', title: 'Assign best coach to at-risk member', ownerUserId: ctx.bestCoachUserId, ownerLabel: owner, subjectType: 'member', subjectId: ctx.memberId, dueInHours: 48 }),
      this.persist(ctx.gymId, { flow: 'churn', signal: sig, decision: 'critical retention risk', reason: 'ensure intervention happens within 48h', type: 'SCHEDULE_REMINDER', title: 'Follow-up reminder (48h)', ownerUserId: ctx.bestCoachUserId, ownerLabel: owner, subjectType: 'member', subjectId: ctx.memberId, dueInHours: 48 }),
    ]);
  }

  /* =====================================================================
     2. REVENUE EXECUTION FLOW (revenue trend down)
     change_pricing is HIGH-IMPACT -> approval request, never auto-executed.
     ===================================================================== */
  async runRevenueFlow(ctx: RevenueCtx) {
    if (!ctx.revenueTrendDown) return [];
    const sig = 'revenue_trend=down';
    const reason = 'Monthly revenue is trending down; protect recurring revenue.';
    return Promise.all([
      this.persist(ctx.gymId, { flow: 'revenue', signal: sig, decision: 'revenue protection mode', reason, type: 'CREATE_TASK', title: 'Revenue review — declining trend', ownerUserId: ctx.ownerUserId, ownerLabel: 'owner', dueInHours: 72 }),
      this.persist(ctx.gymId, { flow: 'revenue', signal: sig, decision: 'revenue protection mode', reason: 'flag affected segments for pricing review', type: 'CREATE_RECOMMENDATION', title: 'Smart-pricing review (segments flagged)', ownerUserId: ctx.ownerUserId, ownerLabel: 'owner', meta: { segments: ctx.segments ?? [] } }),
      this.persist(ctx.gymId, { flow: 'revenue', signal: sig, decision: 'revenue protection mode', reason: 'Pricing changes are high-impact and require human approval (Level 4).', type: 'OPEN_REVIEW_REQUEST', title: 'Approval required: change pricing', ownerUserId: ctx.ownerUserId, ownerLabel: 'owner', pendingIntent: 'change_pricing' }),
    ]);
  }

  /* =====================================================================
     3. UTILIZATION EXECUTION FLOW (utilization < 40 with staff)
     ===================================================================== */
  async runUtilizationFlow(ctx: UtilizationCtx) {
    if (!(ctx.staffCount > 0 && ctx.utilization < THRESHOLDS.UTILIZATION_LOW)) return [];
    const sig = `utilization=${ctx.utilization}%`;
    const reason = `Gym utilization is below the optimal threshold (${ctx.utilization}%), signalling underused capacity.`;
    return Promise.all([
      this.persist(ctx.gymId, { flow: 'utilization', signal: sig, decision: 'operational inefficiency', reason, type: 'CREATE_TASK', title: `Staffing review — utilization ${ctx.utilization}%`, ownerUserId: ctx.opsManagerUserId, ownerLabel: 'operations-manager', dueInHours: 24 }),
      this.persist(ctx.gymId, { flow: 'utilization', signal: sig, decision: 'operational inefficiency', reason: 'move trainers to high-demand slots', type: 'CREATE_RECOMMENDATION', title: 'Recommend trainer redistribution to peak slots', ownerUserId: ctx.opsManagerUserId, ownerLabel: 'operations-manager' }),
      this.persist(ctx.gymId, { flow: 'utilization', signal: sig, decision: 'operational inefficiency', reason: 'operational alert', type: 'QUEUE_COMMUNICATION', title: 'Notify operations manager', ownerUserId: ctx.opsManagerUserId, ownerLabel: 'operations-manager' }),
    ]);
  }

  /* =====================================================================
     4. MEMBER RECOVERY FLOW (expired / inactive / frozen)
     ===================================================================== */
  async runRecoveryFlow(ctx: RecoveryCtx) {
    const sig = `lifecycle=${ctx.status}`;
    const reason = ctx.status === 'expired'
      ? 'Membership has lapsed; a timely reactivation offer can win the member back.'
      : 'Member is inactive/frozen; proactive recovery reduces permanent loss.';
    return Promise.all([
      this.persist(ctx.gymId, { flow: 'recovery', signal: sig, decision: 'reactivation opportunity', reason, type: 'CREATE_WORKFLOW', title: `Reactivation workflow — ${ctx.status} member`, ownerUserId: ctx.ownerUserId, ownerLabel: 'reception', subjectType: 'member', subjectId: ctx.memberId, dueInHours: 72 }),
      this.persist(ctx.gymId, { flow: 'recovery', signal: sig, decision: 'reactivation opportunity', reason: 'staged reactivation outreach', type: 'QUEUE_COMMUNICATION', title: 'Queue win-back outreach sequence', ownerUserId: ctx.ownerUserId, ownerLabel: 'reception', subjectType: 'member', subjectId: ctx.memberId, dueInHours: 72 }),
      this.persist(ctx.gymId, { flow: 'recovery', signal: sig, decision: 'reactivation opportunity', reason: 'clear ownership of recovery', type: 'ASSIGN_STAFF', title: 'Assign responsible staff for recovery', ownerUserId: ctx.ownerUserId, ownerLabel: 'reception', subjectType: 'member', subjectId: ctx.memberId }),
    ]);
  }

  /* =====================================================================
     READ / OUTCOME / ROLLBACK / APPROVAL  (all tenant-isolated)
     ===================================================================== */
  list(gymId: string, filter?: { flow?: string; status?: AutonomousActionStatus; outcome?: AutonomousOutcome }) {
    return this.prisma.autonomousAction.findMany({
      where: {
        gymId,
        ...(filter?.flow ? { flow: filter.flow } : {}),
        ...(filter?.status ? { status: filter.status } : {}),
        ...(filter?.outcome ? { outcome: filter.outcome } : {}),
      },
      orderBy: { createdAt: 'desc' },
      take: 200,
    });
  }

  /** Full audit record for one action (Signal→Decision→Action→Owner→Outcome). */
  async get(gymId: string, id: string) {
    const a = await this.prisma.autonomousAction.findFirst({ where: { id, gymId } });
    if (!a) throw new NotFoundException('Action not found');
    return a;
  }

  /** 7. Outcome tracking — close the loop with a measured result. */
  async measure(gymId: string, id: string, outcome: AutonomousOutcome, note?: string) {
    await this.get(gymId, id); // tenant guard
    return this.prisma.autonomousAction.update({
      where: { id },
      data: { outcome, outcomeNote: note, measuredAt: new Date() },
    });
  }

  /** 6. Rollback / reversal — mark reverted; if a Task was created, cancel it. */
  async revert(gymId: string, id: string, reason?: string) {
    const a = await this.get(gymId, id);
    if (a.reverted) throw new BadRequestException('Action already reverted');
    if (a.taskId) {
      await this.prisma.task.update({ where: { id: a.taskId }, data: { status: TaskStatus.CANCELLED } }).catch(() => undefined);
    }
    return this.prisma.autonomousAction.update({
      where: { id },
      data: { reverted: true, revertedAt: new Date(), revertReason: reason, status: AutonomousActionStatus.REVERTED },
    });
  }

  /** 10. Approval gating — approve/reject a PENDING_APPROVAL high-impact action.
   *  NOTE: approval only flips status; the actual high-impact change is still
   *  performed by a human in the relevant module (never auto-executed here). */
  async resolveApproval(gymId: string, id: string, decision: AutonomousActionStatus, actorName?: string) {
    const a = await this.get(gymId, id);
    if (a.status !== AutonomousActionStatus.PENDING_APPROVAL) throw new BadRequestException('Action is not awaiting approval');
    return this.prisma.autonomousAction.update({
      where: { id },
      data: { status: decision, outcomeNote: actorName ? `resolved by ${actorName}` : undefined },
    });
  }
}
