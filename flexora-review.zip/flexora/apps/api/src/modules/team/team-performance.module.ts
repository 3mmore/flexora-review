/** FLEXORA Gym OS — FEATURE B module (team performance). */
import { Module } from '@nestjs/common';
import { TeamPerformanceController } from './team-performance.controller';
import { TeamPerformanceService } from './team-performance.service';
import { TeamMonthlyService } from './team-monthly.service';
import { PermissionsGuard } from '../../common/guards/permissions.guard';

@Module({
  controllers: [TeamPerformanceController],
  providers: [TeamPerformanceService, TeamMonthlyService, PermissionsGuard],
  exports: [TeamPerformanceService, TeamMonthlyService],
})
export class TeamPerformanceModule {}
