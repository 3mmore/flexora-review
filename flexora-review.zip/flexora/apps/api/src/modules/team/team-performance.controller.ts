/**
 * FLEXORA Gym OS — FEATURE B routes.
 *
 *   GET  /api/team/performance                 list + totals + not-attributable
 *   GET  /api/team/performance/export.csv      same data, allowlisted columns
 *   GET  /api/team/performance/me              a staff member's OWN numbers
 *   GET  /api/team/performance/targets         monthly targets for a period
 *   POST /api/team/performance/targets         upsert (idempotent), audited
 *   GET  /api/team/performance/:userId         one person, per-class-type detail
 *
 * Literal paths are declared BEFORE `:userId` so `me`, `targets` and
 * `export.csv` can never be parsed as an id.
 *
 * Access: `/me` requires `profile.self` — held by every role by default — which
 * is the honest expression of "your own numbers" and satisfies the project rule
 * that every tenant endpoint carries @Roles/@Permissions/@Public (enforced by
 * common/security/tenant-endpoint-guards.spec.ts).
 *
 * The reading routes need the NEW permission `team.performance.view`
 * (OWNER by default; any other role only when the owner grants it on the Team
 * page). `/me` needs no permission — it is scoped to the caller's own id and
 * returns nothing about anyone else. Writes need the same permission: a person
 * who may read everyone's numbers is exactly the person who may set their
 * targets, and a coach without it can neither read nor write.
 */
import {
  Body, Controller, Get, Param, Post, Query, Req, Res, UseGuards,
} from '@nestjs/common';
import type { Response } from 'express';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { Audit } from '../../common/decorators/audit.decorator';
import { Throttle } from '@nestjs/throttler';
import { Actor, TeamPerformanceService } from './team-performance.service';
import { TeamMonthlyService } from './team-monthly.service';
import { csvRow } from './team-metrics';
import {
  TeamPerformanceQueryDto,
  TeamRangeDto,
  TeamTargetQueryDto,
  UpsertTeamTargetsDto,
} from './dto/team-performance.dto';

/** Build the Actor from the authenticated request, including branch scope. */
function actorOf(req: any): Actor {
  const user = req.user as { id: string; role: string; gymId: string; branchId?: string | null };
  const scope = req.branchScope as { unrestricted?: boolean; filterBranchId?: string | null } | undefined;
  return {
    id: user.id,
    role: user.role,
    gymId: user.gymId,
    branchId: user.branchId ?? null,
    unrestrictedBranch: scope ? scope.unrestricted === true : true,
    filterBranchId: scope?.filterBranchId ?? null,
  };
}

@Controller('team/performance')
@UseGuards(JwtAuthGuard, TenantGuard, PermissionsGuard)
// MEASURED lesson from Feature A: the app's named throttlers are
// global/short/auth/read/write — there is no `default`, so only those names work.
@Throttle({ short: { limit: 120, ttl: 60000 }, global: { limit: 120, ttl: 60000 } })
export class TeamPerformanceController {
  constructor(
    private readonly svc: TeamPerformanceService,
    private readonly monthlySvc: TeamMonthlyService,
  ) {}

  // ── own numbers: no permission, scoped to the caller ────────────────────
  @Get('me')
  @Permissions('profile.self')
  async me(@GymId() gymId: string, @Req() req: any, @Query() q: TeamRangeDto) {
    return this.svc.me(gymId, actorOf(req), q);
  }

  // ── list ────────────────────────────────────────────────────────────────
  @Get()
  @Permissions('team.performance.view')
  async list(@GymId() gymId: string, @Req() req: any, @Query() q: TeamPerformanceQueryDto) {
    return this.svc.list(gymId, q, actorOf(req));
  }

  // ── CSV export (heavier: its own tighter limit) ─────────────────────────
  @Get('export.csv')
  @Permissions('team.performance.view')
  @Throttle({ short: { limit: 10, ttl: 60000 }, global: { limit: 10, ttl: 60000 } })
  @Audit('team.performance.export', 'TeamPerformance')
  async export(
    @GymId() gymId: string,
    @Req() req: any,
    @Query() q: TeamPerformanceQueryDto,
    @Res({ passthrough: true }) res: Response,
  ) {
    const { rows, meta } = await this.svc.listForExport(gymId, { ...q, page: 1, pageSize: 100 }, actorOf(req));

    // RFC 4180: CRLF line endings, a header row, quoted cells where needed.
    // The leading BOM keeps Arabic names readable when Excel opens the file.
    const header = [
      'staff', 'role', 'branch', 'active',
      'new_subscriptions', 'renewals', 'membership_gross', 'pos_gross', 'refunds', 'net', 'average_sale',
      'sessions_held', 'booked', 'members_attended', 'attendance_rate_pct', 'low_sample',
      'sales_target', 'sales_progress_pct', 'new_subs_target', 'new_subs_progress_pct',
      'attendance_target', 'attendance_progress_pct', 'days_left',
    ];
    const lines = [csvRow(header)];
    for (const r of rows) {
      lines.push(csvRow([
        r.name, r.role, r.branchName ?? '', r.active ? 'yes' : 'no',
        r.newSubscriptions, r.renewals, r.membershipGross, r.posGross, r.refunds, r.net, r.average,
        r.sessionsHeld, r.booked, r.membersAttended, r.attendanceRate ?? '', r.attendanceLowSample ? 'yes' : 'no',
        r.salesTarget?.target ?? '', r.salesTarget?.progressPct ?? '',
        r.newSubsTarget?.target ?? '', r.newSubsTarget?.progressPct ?? '',
        r.attendanceTarget?.target ?? '', r.attendanceTarget?.progressPct ?? '',
        meta.daysLeft,
      ]));
    }
    // "not attributable" is a ROW, not a silent omission (owner decision Q2/Q3)
    const na = meta.notAttributable;
    lines.push(csvRow([
      'not attributable', '', '', '',
      '', '', na.membershipGross, na.posGross, na.refunds, '', '',
      '', '', '', '', '',
      '', '', '', '', '', '', '',
    ]));

    const filename = `team-performance-${meta.range.from}-to-${meta.range.to}.csv`;
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('X-Row-Count', String(rows.length));
    res.setHeader('X-Report-Timezone', meta.range.tz);
    res.setHeader('Cache-Control', 'no-store');
    return `\uFEFF${lines.join('\r\n')}\r\n`;
  }

  // ── targets ─────────────────────────────────────────────────────────────
  /**
   * PACK 2, item 4 — per employee × per month, last 6 or 12 months.
   *
   * Declared before `:userId` so "monthly" is never parsed as a user id.
   * `?format=csv` returns exactly the matrix the page shows.
   */
  @Get('monthly')
  @Permissions('team.performance.view')
  async monthly(
    @GymId() gymId: string,
    @Req() req: any,
    @Res({ passthrough: true }) res: Response,
    @Query('months') months?: string,
    @Query('branchId') branchId?: string,
    @Query('includeInactive') includeInactive?: string,
    @Query('format') format?: string,
  ) {
    const actor = actorOf(req);
    const payload = await this.monthlySvc.monthly(gymId, actor, { months, branchId, includeInactive });
    if (String(format || '').toLowerCase() === 'csv') {
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', 'attachment; filename="team-monthly.csv"');
      // a BOM so Excel opens the Arabic names correctly
      return '\uFEFF' + this.monthlySvc.csvOf(payload);
    }
    return payload;
  }

  @Get('targets')
  @Permissions('team.performance.view')
  async targets(@GymId() gymId: string, @Req() req: any, @Query() q: TeamTargetQueryDto) {
    return this.svc.targets(gymId, q, actorOf(req));
  }

  @Post('targets')
  @Permissions('team.performance.view')
  @Throttle({ short: { limit: 30, ttl: 60000 }, global: { limit: 30, ttl: 60000 } })
  @Audit('team.targets.upsert', 'StaffTarget')
  async upsertTargets(@GymId() gymId: string, @Req() req: any, @Body() body: UpsertTeamTargetsDto) {
    return this.svc.upsertTargets(gymId, actorOf(req), body);
  }

  // ── one person ──────────────────────────────────────────────────────────
  @Get(':userId')
  @Permissions('team.performance.view')
  async detail(@GymId() gymId: string, @Param('userId') userId: string, @Req() req: any, @Query() q: TeamRangeDto) {
    return this.svc.detail(gymId, userId, q, actorOf(req));
  }
}
