/**
 * FLEXORA Gym OS — PACK 2, item 4: the MONTHLY team-money matrix.
 *
 * The existing team page answers "who sold what in the chosen range". The owner
 * asked for a different question: **per employee × per month**, last 6 or 12
 * months, with a trend, a totals row and a month-over-month delta — because a
 * single good month is not a trend, and a sudden drop is a conversation.
 *
 * WHAT IS PROVABLE, AND WHAT IS NOT (measured in evidence/13-TEAM-MEASURE.md):
 *  · sold — provable per employee: membership from the ledger (`Transaction`,
 *    attributed by `createdBy`, an id) and POS from `Sale` (attributed by exact
 *    display name, the Q2 rule), minus `Refund`s in the month they happen;
 *  · collected — provable ONLY for membership money: `Payment` rows with
 *    `status = PAID` and `purpose = MANUAL_MEMBERSHIP`, dated by `paidAt`,
 *    attributed by `createdBy` (an id). A POS sale has no user id and its
 *    payment is not a row of its own, so **who collected a POS sale is not in
 *    the data** — the response says so instead of printing a misleading zero.
 *
 * Every month boundary is a CAIRO month, so a sale at 23:59 on the 31st belongs
 * to that month and one at 00:01 on the 1st belongs to the next.
 */
import { BadRequestException, Injectable } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';
import {
  calendarDateIn,
  formatYmd,
  monthKey,
  parseYmd,
  resolveGymTimeZone,
  startOfMonth,
  buildRange,
} from '../../common/time/gym-time';
import { MEMBERSHIP_CATEGORIES, attributeByExactName, csvCell, decimalSum, money, normaliseName } from './team-metrics';
import { Actor } from './team-performance.service';

export interface MonthCell {
  /** YYYY-MM */
  month: string;
  newSubscriptions: number;
  renewals: number;
  membershipSold: string;
  posSold: string;
  refunds: string;
  /** sold share of the money that is actually collected for memberships */
  collected: string;
  /** membership + pos − refunds */
  net: string;
}

export interface MonthlyRow {
  userId: string;
  name: string;
  role: string;
  active: boolean;
  branchId: string | null;
  branchName: string | null;
  months: MonthCell[];
  totals: Omit<MonthCell, 'month'>;
  /** the month with the highest net, or null when the person sold nothing */
  bestMonth: { month: string; net: string } | null;
  /** average net over the months with any activity (null, never 0, when idle) */
  averageNet: string | null;
  /**
   * True for the single row that carries money whose `createdBy` is not a staff
   * member (deleted user, other branch under a branch filter, cross-tenant id).
   * It has an empty name on purpose — the UI labels it in Arabic.
   */
  unattributed?: boolean;
}

const zeroCell = (month: string): MonthCell => ({
  month,
  newSubscriptions: 0,
  renewals: 0,
  membershipSold: '0.00',
  posSold: '0.00',
  refunds: '0.00',
  collected: '0.00',
  net: '0.00',
});

/** The Cairo month range [gte, lt) for a YYYY-MM key. */
export function monthRange(key: string, tz: string): { gte: Date; lt: Date } | null {
  const parts = /^(\d{4})-(\d{2})$/.exec(key);
  if (!parts) return null;
  const y = Number(parts[1]);
  const m = Number(parts[2]);
  if (m < 1 || m > 12) return null;
  const from = { year: y, month: m, day: 1 };
  const to = m === 12 ? { year: y + 1, month: 1, day: 1 } : { year: y, month: m + 1, day: 1 };
  const gte = buildRange(from, from, tz, 1).gte;
  const lt = buildRange(to, to, tz, 1).gte;
  return { gte, lt };
}

/** The last `count` Cairo months, oldest first, ending with the current one. */
export function lastMonths(count: number, tz: string, now = new Date()): string[] {
  const today = calendarDateIn(now, tz);
  const out: string[] = [];
  let y = today.year;
  let m = today.month;
  for (let i = 0; i < count; i += 1) {
    out.unshift(`${y}-${String(m).padStart(2, '0')}`);
    m -= 1;
    if (m === 0) { m = 12; y -= 1; }
  }
  return out;
}

@Injectable()
export class TeamMonthlyService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * The matrix. One query set per month (≤ 12), each groupBy done in the
   * database — this is a report for a gym with a few hundred staff at most, and
   * pushing 12 × 4 aggregates through Postgres is far cheaper than pulling rows
   * into Node.
   */
  async monthly(
    gymId: string,
    actor: Actor,
    opts: { months?: number | string; branchId?: string | null; includeInactive?: boolean | string },
  ) {
    const monthsWanted = Number(opts.months ?? 6);
    if (![6, 12].includes(monthsWanted)) {
      throw new BadRequestException({ code: 'INVALID_MONTHS', message: 'months must be 6 or 12' });
    }
    const settings = await this.prisma.gymSettings.findFirst({
      where: { gymId, key: 'timezone' }, select: { value: true },
    });
    const tz = resolveGymTimeZone(settings?.value ?? null);
    const months = lastMonths(monthsWanted, tz);

    let branchId: string | null = null;
    if (opts.branchId) {
      if (actor.unrestrictedBranch === false && actor.filterBranchId && actor.filterBranchId !== opts.branchId) {
        throw new BadRequestException({ code: 'BRANCH_NOT_ALLOWED', message: 'branch is outside your scope' });
      }
      const branch = await this.prisma.branch.findFirst({ where: { id: opts.branchId, gymId }, select: { id: true } });
      if (!branch) throw new BadRequestException({ code: 'BRANCH_NOT_FOUND', message: 'unknown branch for this gym' });
      branchId = opts.branchId;
    } else if (actor.unrestrictedBranch === false) {
      branchId = actor.filterBranchId ?? null;
    }

    const includeInactive = opts.includeInactive === true || opts.includeInactive === 'true';
    const staffWhere: Prisma.UserWhereInput = { gymId };
    if (branchId) staffWhere.branchId = branchId;
    // NOTE: `active` is deliberately NOT part of the query. A deactivated
    // employee who sold something must still appear, otherwise their money
    // disappears from the page while staying in the gym total and the
    // reconciliation breaks. Visible = active, OR has money in the window, OR
    // includeInactive.

    return this.prisma.withTenant(gymId, async (tx) => {
      const staff = await tx.user.findMany({
        where: staffWhere,
        select: { id: true, name: true, role: true, active: true, branchId: true, branch: { select: { name: true } } },
        orderBy: { name: 'asc' },
      });

      // per month, a compact aggregate keyed by user id
      const perMonth = new Map<string, Map<string, MonthCell>>();
      const posUnattributedByMonth = new Map<string, string>();
      for (const key of months) {
        const range = monthRange(key, tz);
        if (!range) throw new BadRequestException({ code: 'INVALID_MONTH', message: `bad month ${key}` });
        const { cells, posUnattributed } = await this.monthCells(tx, gymId, key, range, branchId);
        perMonth.set(key, cells);
        posUnattributedByMonth.set(key, posUnattributed);
      }

      const buildRow = (s: (typeof staff)[number]): MonthlyRow => {
        const cells = months.map((key) => perMonth.get(key)!.get(s.id) ?? zeroCell(key));
        const totals = {
          newSubscriptions: cells.reduce((a, c) => a + c.newSubscriptions, 0),
          renewals: cells.reduce((a, c) => a + c.renewals, 0),
          membershipSold: money(decimalSum(cells.map((c) => new Prisma.Decimal(c.membershipSold)))),
          posSold: money(decimalSum(cells.map((c) => new Prisma.Decimal(c.posSold)))),
          refunds: money(decimalSum(cells.map((c) => new Prisma.Decimal(c.refunds)))),
          collected: money(decimalSum(cells.map((c) => new Prisma.Decimal(c.collected)))),
          net: money(decimalSum(cells.map((c) => new Prisma.Decimal(c.net)))),
        };
        const active = cells.filter((c) => !new Prisma.Decimal(c.net).isZero() || c.newSubscriptions + c.renewals > 0);
        const best = cells.reduce<MonthCell | null>((bestSoFar, c) => {
          if (!bestSoFar) return c;
          return new Prisma.Decimal(c.net).greaterThan(bestSoFar.net) ? c : bestSoFar;
        }, null);
        return {
          userId: s.id,
          name: s.name,
          role: s.role,
          active: s.active,
          branchId: s.branchId,
          branchName: s.branch?.name ?? null,
          months: cells,
          totals,
          bestMonth: best && (active.length > 0) ? { month: best.month, net: best.net } : null,
          averageNet: active.length
            ? money(decimalSum(active.map((c) => new Prisma.Decimal(c.net))).div(active.length))
            : null,
        };
      };

      const hasMoney = (r: MonthlyRow) =>
        r.months.some((c) =>
          c.newSubscriptions + c.renewals !== 0 ||
          !new Prisma.Decimal(c.membershipSold).isZero() ||
          !new Prisma.Decimal(c.posSold).isZero() ||
          !new Prisma.Decimal(c.refunds).isZero() ||
          !new Prisma.Decimal(c.collected).isZero(),
        );

      const rows: MonthlyRow[] = staff
        .map(buildRow)
        // active staff always; a deactivated employee only when they moved money
        // in the window (history must not vanish) or when explicitly asked for
        .filter((r) => includeInactive || r.active || hasMoney(r));

      // Money whose `createdBy` is not a staff row at all — a deleted user, a
      // user of another branch under a branch filter, or a cross-tenant id.
      // It is real money in the gym total, so it gets its own row instead of
      // being dropped on the floor.
      const known = new Set(rows.map((r) => r.userId));
      const orphanCells = months.map((key) => {
        const merged = zeroCell(key);
        for (const [id, c] of perMonth.get(key)!) {
          if (known.has(id)) continue;
          merged.newSubscriptions += c.newSubscriptions;
          merged.renewals += c.renewals;
          merged.membershipSold = money(new Prisma.Decimal(merged.membershipSold).plus(c.membershipSold));
          merged.posSold = money(new Prisma.Decimal(merged.posSold).plus(c.posSold));
          merged.refunds = money(new Prisma.Decimal(merged.refunds).plus(c.refunds));
          merged.collected = money(new Prisma.Decimal(merged.collected).plus(c.collected));
          merged.net = money(new Prisma.Decimal(merged.net).plus(c.net));
        }
        return merged;
      });
      const orphanRow: MonthlyRow | null = orphanCells.some((c) =>
        !new Prisma.Decimal(c.net).isZero() ||
        !new Prisma.Decimal(c.membershipSold).isZero() ||
        !new Prisma.Decimal(c.posSold).isZero() ||
        !new Prisma.Decimal(c.refunds).isZero() ||
        !new Prisma.Decimal(c.collected).isZero() ||
        c.newSubscriptions + c.renewals !== 0,
      )
        ? {
            userId: '',
            name: '',
            role: '',
            active: false,
            branchId: null,
            branchName: null,
            months: orphanCells,
            totals: {
              newSubscriptions: orphanCells.reduce((a, c) => a + c.newSubscriptions, 0),
              renewals: orphanCells.reduce((a, c) => a + c.renewals, 0),
              membershipSold: money(decimalSum(orphanCells.map((c) => new Prisma.Decimal(c.membershipSold)))),
              posSold: money(decimalSum(orphanCells.map((c) => new Prisma.Decimal(c.posSold)))),
              refunds: money(decimalSum(orphanCells.map((c) => new Prisma.Decimal(c.refunds)))),
              collected: money(decimalSum(orphanCells.map((c) => new Prisma.Decimal(c.collected)))),
              net: money(decimalSum(orphanCells.map((c) => new Prisma.Decimal(c.net)))),
            },
            bestMonth: null,
            averageNet: null,
            unattributed: true,
          }
        : null;
      if (orphanRow) rows.push(orphanRow);

      // totals per month + month-over-month delta, computed from the same cells
      const totalsPerMonth = months.map((key, i) => {
        const sums = rows.map((r) => r.months[i]);
        const total = {
          ...zeroCell(key),
          newSubscriptions: sums.reduce((a, c) => a + c.newSubscriptions, 0),
          renewals: sums.reduce((a, c) => a + c.renewals, 0),
          membershipSold: money(decimalSum(sums.map((c) => new Prisma.Decimal(c.membershipSold)))),
          posSold: money(decimalSum(sums.map((c) => new Prisma.Decimal(c.posSold)))),
          refunds: money(decimalSum(sums.map((c) => new Prisma.Decimal(c.refunds)))),
          collected: money(decimalSum(sums.map((c) => new Prisma.Decimal(c.collected)))),
          net: money(decimalSum(sums.map((c) => new Prisma.Decimal(c.net)))),
        };
        return total;
      });
      const deltas = totalsPerMonth.map((t, i) => {
        if (i === 0) return null;
        const prev = totalsPerMonth[i - 1];
        const nowNet = new Prisma.Decimal(t.net);
        const prevNet = new Prisma.Decimal(prev.net);
        const diff = nowNet.minus(prevNet);
        const pct = prevNet.isZero() ? null : Number(diff.div(prevNet).times(100).toFixed(1));
        return { month: t.month, netDelta: money(diff), netDeltaPct: pct };
      });

      return {
        months,
        rows,
        totalsPerMonth,
        monthOverMonth: deltas,
        // POS money that carries no staff name (or a name two people share):
        // shown as its own line, per month, never merged into a person.
        posNotAttributable: months.map((m) => ({ month: m, amount: posUnattributedByMonth.get(m) ?? '0.00' })),
        branch: branchId,
        // Printed by the UI next to the "collected" column. This is not a
        // footnote: it is the limit of what the database can prove.
        attribution: {
          sold: 'membership ledger + POS sales − refunds (POS by exact display name)',
          collected: 'PAID manual membership payments by the staff member who took them (paidAt)',
          posCollected: 'NOT ATTRIBUTABLE — a POS sale records no user id and its payment is not a separate row',
        },
      };
    });
  }

  /** One month's cells, keyed by user id. */
  private async monthCells(
    tx: Prisma.TransactionClient,
    gymId: string,
    key: string,
    range: { gte: Date; lt: Date },
    branchId: string | null,
  ): Promise<{ cells: Map<string, MonthCell>; posUnattributed: string }> {
    const cells = new Map<string, MonthCell>();
    const cell = (id: string | null) => {
      if (!id) return null;
      let c = cells.get(id);
      if (!c) cells.set(id, (c = zeroCell(key)));
      return c;
    };

    // 1 — membership sold (ledger, attributed by id)
    const txWhere: Prisma.TransactionWhereInput = {
      gymId, type: 'INCOME', category: { in: [...MEMBERSHIP_CATEGORIES] },
      createdAt: { gte: range.gte, lt: range.lt },
    };
    if (branchId) txWhere.branchId = branchId;
    const ledger = await tx.transaction.groupBy({
      by: ['createdBy', 'category'], where: txWhere,
      _sum: { amount: true }, _count: { _all: true },
    });
    for (const g of ledger) {
      const c = cell(g.createdBy);
      if (!c) continue;
      c.membershipSold = money(new Prisma.Decimal(c.membershipSold).plus(g._sum.amount ?? 0));
      if (g.category === 'membership_create') c.newSubscriptions += g._count._all;
      if (g.category === 'membership_renewal') c.renewals += g._count._all;
    }

    // 2 — POS sold (by exact display name, the Q2 rule)
    const posRows = await tx.$queryRaw<Array<{ userName: string | null; total: unknown }>>(Prisma.sql`
      SELECT COALESCE("userName", '') AS "userName", SUM("total") AS total
        FROM "Sale"
       WHERE "gymId" = ${gymId}
         AND "createdAt" >= ${range.gte} AND "createdAt" < ${range.lt}
         ${branchId ? Prisma.sql`AND "branchId" = ${branchId}` : Prisma.empty}
         AND "voidedAt" IS NULL
         AND UPPER(status) NOT IN ('VOID', 'VOIDED')
       GROUP BY 1
    `);
    const staff = await this.staffIndex(tx, gymId);
    const { byName, unmatched } = attributeByExactName(
      posRows.map((r) => ({ ...r, total: Number(r.total ?? 0) })),
      staff.map((s2) => s2.name),
    );
    const idByName = new Map(staff.map((s2) => [normaliseName(s2.name), s2.id]));
    for (const [name, rows] of byName) {
      const c = cell(idByName.get(name) ?? null);
      if (!c) continue;
      c.posSold = money(new Prisma.Decimal(c.posSold).plus(
        rows.reduce((a, r) => a + Number(r.total ?? 0), 0),
      ));
    }
    // Not attributable is its own bucket, never spread across staff and never
    // hidden: it is reported next to the totals by the caller.
    const posUnattributed = money(new Prisma.Decimal(
      unmatched.reduce((a, r) => a + Number(r.total ?? 0), 0),
    ));

    // 3 — refunds (the month they happen)
    const refunds = await tx.refund.groupBy({
      by: ['createdBy'],
      where: {
        gymId,
        createdAt: { gte: range.gte, lt: range.lt },
        // RefundStatus is an enum of exactly COMPLETED | VOIDED. A VOIDED refund
        // did not happen, so it is excluded; everything else counts.
        status: { not: 'VOIDED' as any },
      },
      _sum: { amount: true },
    });
    for (const g of refunds) {
      const c = cell(g.createdBy);
      if (!c) continue;
      c.refunds = money(new Prisma.Decimal(c.refunds).plus(g._sum.amount ?? 0));
    }

    // 4 — collected: PAID manual membership payments, by paidAt, by the person
    // who took the money. POS collection is deliberately absent (see the header).
    const paid = await tx.payment.groupBy({
      by: ['createdBy'],
      where: {
        gymId,
        purpose: 'MANUAL_MEMBERSHIP' as any,
        status: 'PAID' as any,
        paidAt: { gte: range.gte, lt: range.lt },
      },
      _sum: { amount: true },
    });
    for (const g of paid) {
      const c = cell(g.createdBy);
      if (!c) continue;
      c.collected = money(new Prisma.Decimal(c.collected).plus(g._sum.amount ?? 0));
    }

    // 5 — net = membership + POS − refunds (never clamped: a refund in a month
    // with no sales is a real negative and must be visible)
    for (const c of cells.values()) {
      c.net = money(
        new Prisma.Decimal(c.membershipSold).plus(c.posSold).minus(c.refunds),
      );
    }
    return { cells, posUnattributed: posUnattributed ?? '0.00' };
  }

  /** id → normalised display name, for the exact-name POS rule. */
  private async staffIndex(tx: Prisma.TransactionClient, gymId: string) {
    const rows = await tx.user.findMany({ where: { gymId }, select: { id: true, name: true } });
    return rows;
  }

  /** The CSV of exactly the matrix the page shows. */
  csvOf(payload: Awaited<ReturnType<TeamMonthlyService['monthly']>>): string {
    const header = ['staff', 'role', 'branch', ...payload.months.flatMap((m) => [`${m} net`]), 'total net', 'total collected'];
    const lines = [header.map(csvCell).join(',')];
    for (const r of payload.rows) {
      lines.push([
        // the unattributed row has no name; label it so the file explains itself
        r.unattributed ? 'UNATTRIBUTED' : r.name, r.role, r.branchName ?? '',
        ...r.months.map((c) => c.net),
        r.totals.net, r.totals.collected,
      ].map(csvCell).join(','));
    }
    // a totals row, so the file reconciles with the screen by eye
    lines.push([
      'TOTAL', '', '',
      ...payload.totalsPerMonth.map((t) => t.net),
      payload.rows.reduce((a, r) => a + Number(r.totals.net), 0).toFixed(2),
      payload.rows.reduce((a, r) => a + Number(r.totals.collected), 0).toFixed(2),
    ].map(csvCell).join(','));
    return lines.join('\r\n');
  }
}
