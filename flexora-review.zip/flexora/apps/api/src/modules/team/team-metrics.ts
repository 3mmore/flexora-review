/**
 * FLEXORA Gym OS — FEATURE B metric arithmetic, with no database and no Nest.
 *
 * Every definition here is the one the owner approved in Q1–Q4, written down
 * once so the page, the CSV and the tests cannot drift apart:
 *
 *   SALES VALUE (per staff member, per period)
 *     = membership gross   (Transaction INCOME, category membership_create |
 *                           membership_renewal, createdBy = staff id)
 *     + POS gross          (Sale, not voided, exact name match to the staff name)
 *     − refunds            (Refund COMPLETED, in the period they happen,
 *                           attributed by the id on the refund row)
 *     NET may be NEGATIVE. It is never clamped to zero: a month where a
 *     receptionist refunded more than they sold is a real, reportable fact.
 *
 *   NEW SUBSCRIPTIONS = count of membership_create rows (a renewal is not a new
 *   subscription, and the UI says so in words).
 *
 *   ATTENDANCE (per coach, per period)
 *     denominator = non-cancelled bookings on COMPLETED sessions in the range
 *     numerator   = the ATTENDED subset of exactly those bookings
 *     rate        = numerator ÷ denominator; no denominator → null ("—"),
 *                   never 0 % and never NaN; fewer than 5 bookings → lowSample.
 */
import { Prisma } from '@prisma/client';

export const MEMBERSHIP_CATEGORIES = ['membership_create', 'membership_renewal'] as const;
export type MembershipCategory = (typeof MEMBERSHIP_CATEGORIES)[number];

/** Bookings below this count are reported with a "low sample" marker. */
export const LOW_SAMPLE_BOOKINGS = 5;

export type TargetKind = 'SALES_VALUE' | 'NEW_SUBSCRIPTIONS' | 'ATTENDANCE_RATE';
export const TARGET_KINDS: readonly TargetKind[] = ['SALES_VALUE', 'NEW_SUBSCRIPTIONS', 'ATTENDANCE_RATE'];

/** Decimal → string with exactly 2 places (money crosses the wire as string). */
export function money(value: Prisma.Decimal | string | number | null | undefined): string {
  if (value === null || value === undefined) return '0.00';
  const d = value instanceof Prisma.Decimal ? value : new Prisma.Decimal(value);
  return d.toFixed(2);
}

/** A rate as a percentage with one decimal, or null when there is no denominator. */
export function ratioPct(numerator: number, denominator: number): number | null {
  if (!Number.isFinite(numerator) || !Number.isFinite(denominator) || denominator <= 0) return null;
  const pct = (numerator / denominator) * 100;
  // keep it at one decimal without floating-point tails (33.3333 → 33.3)
  return Math.round(pct * 10) / 10;
}

export function isLowSample(bookings: number): boolean {
  return bookings > 0 && bookings < LOW_SAMPLE_BOOKINGS;
}

/** Progress towards a target: 0–∞ %, null when there is no target. */
export function targetProgress(kind: TargetKind, value: number, target: number | null): number | null {
  if (target === null || !Number.isFinite(target) || target <= 0) return null;
  if (kind === 'ATTENDANCE_RATE') {
    // a rate target is "how many of the 100 points did we reach", so the ratio
    // is value ÷ target, not value ÷ 100: a 90 % target met by 45 % is 50 %.
    if (value === null || !Number.isFinite(value)) return null;
    const pct = (value / target) * 100;
    return Math.round(pct * 10) / 10; // may exceed 100 — over-achievement is real
  }
  const pct = (value / target) * 100;
  return Math.round(pct * 10) / 10;
}

/** Days left in a period, inclusive of today, in the gym's calendar. */
export function daysLeftInPeriod(todayYmd: string, periodEndYmd: string): number {
  const a = Date.UTC(+todayYmd.slice(0, 4), +todayYmd.slice(5, 7) - 1, +todayYmd.slice(8, 10));
  const b = Date.UTC(+periodEndYmd.slice(0, 4), +periodEndYmd.slice(5, 7) - 1, +periodEndYmd.slice(8, 10));
  const diff = Math.round((b - a) / 86_400_000);
  return diff < 0 ? 0 : diff + 1;
}

/**
 * The staff name a POS row carries, normalised for the EXACT match the owner
 * approved: trim + case-fold, nothing else. No fuzzy matching, no diacritic
 * stripping, no substring — a name that does not match goes to
 * "not attributable", where it is visible.
 */
export function normaliseName(value: string | null | undefined): string {
  return String(value ?? '').trim().toLowerCase();
}

/**
 * Attribute rows by exact normalised name.
 *
 * Returns a Map name → rows, plus the matched ids and the unmatched count. The
 * caller needs the unmatched count because "not attributable" is its OWN row in
 * the report — never silently dropped, never spread across staff.
 */
export function attributeByExactName<T extends { userName?: string | null }>(
  rows: T[],
  staffNames: string[],
): { byName: Map<string, T[]>; unmatched: T[]; ambiguous: string[] } {
  const counts = new Map<string, number>();
  for (const n of staffNames) {
    const key = normaliseName(n);
    if (!key) continue;
    counts.set(key, (counts.get(key) ?? 0) + 1);
  }
  // A name shared by two staff members can never be attributed by name alone:
  // guessing which one made the sale would be inventing attribution.
  const ambiguous: string[] = [];
  for (const [key, n] of counts) if (n > 1) ambiguous.push(key);
  const byName = new Map<string, T[]>();
  const unmatched: T[] = [];
  for (const row of rows) {
    const key = normaliseName(row.userName);
    if (!key || counts.get(key) !== 1) {
      unmatched.push(row);
      continue;
    }
    const list = byName.get(key) ?? [];
    list.push(row);
    byName.set(key, list);
  }
  return { byName, unmatched, ambiguous };
}

/** Sum a Decimal column without ever going through float. */
export function decimalSum(values: Array<Prisma.Decimal | null | undefined>): Prisma.Decimal {
  return values.reduce<Prisma.Decimal>((acc, v) => acc.plus(v ?? 0), new Prisma.Decimal(0));
}

/**
 * CSV cell policy (RFC 4180 + formula neutralisation).
 *
 * Excel and Sheets execute a cell that starts with = + - @ (and a leading TAB or
 * CR is trimmed into one). A staff member named `=cmd|' /C calc'!A0`, or a
 * product called `-1+1`, must land in the file as TEXT. Prefixing with a single
 * quote is the documented, reversible convention; quoting is then applied by the
 * caller for commas/quotes/newlines.
 */
export function csvCell(value: unknown): string {
  if (value === null || value === undefined) return '';
  let s = String(value);
  // A negative MONEY value is data, not a formula: keep "-12.50" as a number.
  const isPlainNumber = /^-?\d+(\.\d+)?$/.test(s);
  if (!isPlainNumber && /^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return s;
}

/** Full RFC 4180 encoding for one row. */
export function csvRow(cells: Array<unknown>): string {
  return cells
    .map((c) => {
      const s = csvCell(c);
      return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    })
    .join(',');
}
