/** @jest-environment node */
/**
 * FEATURE B — team performance, proved against the real application and a real
 * PostgreSQL 16 database.
 *
 * The fixture below is small enough to compute BY HAND, and every expected
 * number in this file was written from that hand computation, not from a run of
 * the service. Each aggregate is additionally reconciled against INDEPENDENT SQL
 * (a different query, written in the test) so a wrong filter in the service
 * cannot quietly agree with itself.
 *
 *   MEMBERSHIP  11-05 create 1000 by Rania · 11-06 renewal 400 by Rania
 *               11-07 create 700 by the manager        → gross 2100, new 2, ren 1
 *   POS         500 Rania (2 sales) · 999 VOIDED Rania · 150 unknown name
 *               50 empty name                          → attributed 500, NA 200
 *   REFUNDS     100 Rania (COMPLETED) · 999 VOIDED · 300 on the voided sale
 *               The three refunded sales are made by "Refund Basis", a separate
 *               staff member, so a refund can never inflate or deflate Rania's
 *               own POS gross → attributed 100 to Rania, 800 POS to Refund
 *               Basis, and the voided sale/refund excluded entirely.
 *   COACH A     3 COMPLETED sessions: 4 bookings(3 attended) + 2 cancelled,
 *               2 bookings(2 attended), 0 bookings
 *               → 3 sessions, 6 non-cancelled booked, 5 attended, 83.3 %
 *               + 1 CANCELLED session with 5 attended bookings (must be ignored)
 *               + 1 SCHEDULED session (must be ignored)
 *   COACH B     1 COMPLETED session, 2 bookings, 0 attended → 0 %, low sample
 *   COACH C     no sessions → "—", never 0 % and never NaN
 *
 * Rania's net   = 1000 + 400 + 500 − 100 = 1800.00
 * Gym net total = 2100 + 700 − 100      = 2700.00  (NA POS 200 included once)
 */
import {
  assertRuntimeRole,
  daysAgo,
  monthKeyOf,
  runtimeRolePassword,
  startRuntimeApp,
  startTenantHarness,
  TenantHarness,
  API,
} from '../../test/support/tenant-app-harness';
import { csvRow, attributeByExactName, ratioPct, targetProgress, csvCell } from './team-metrics';
import { PrismaService } from '../../config/prisma.service';

jest.setTimeout(300_000);

const RUN = Date.now().toString(36);
const isIntegration = Boolean(process.env.DATABASE_URL && runtimeRolePassword());
const d = isIntegration ? describe : describe.skip;

d('FEATURE B — team performance (real app + real database)', () => {
  let h: TenantHarness;
  let gymId: string;
  let branchA: string;
  let branchB: string;
  const S = { rania: '', manager: '', coachA: '', coachB: '', coachC: '', owner: '', accountant: '' };
  let templateYoga = '';
  let templateBox = '';

  const inRange = (n: number) => daysAgo(n, 12);

  beforeAll(async () => {
    h = await startTenantHarness(`team${RUN}`);
    await assertRuntimeRole(h.runtime);
    gymId = h.gymA.gymId;
    branchA = h.gymA.branchId;
    branchB = h.gymA.secondBranchId;

    const mkUser = async (name: string, role: string, branchId: string | null) => {
      const u = await h.prisma.user.create({
        data: {
          gymId, branchId, name, role: role as never, onboardingCompleted: true, active: true,
          email: `${role.toLowerCase()}-${RUN}-${Math.random().toString(36).slice(2, 8)}@team.test`,
          passwordHash: 'x'.repeat(60),
        },
      });
      return u.id;
    };
    S.owner = h.gymA.owner.id;
    S.manager = h.gymA.manager.id;
    S.rania = await mkUser('Rania Reception', 'RECEPTION', branchA);
    S.coachA = await mkUser('Coach A', 'COACH', branchA);
    S.coachB = await mkUser('Coach B', 'COACH', branchA);
    S.coachC = await mkUser('Coach C', 'COACH', branchB);
    S.accountant = h.gymA.accountant.id;

    // ── membership ledger ────────────────────────────────────────────────
    const tx = (createdBy: string, category: string, amount: number, day: number, branchId = branchA) =>
      h.prisma.transaction.create({
        data: { gymId, type: 'INCOME', category, description: `${category} ${RUN}`, amount, branchId, createdBy, createdAt: inRange(day) },
      });
    await tx(S.rania, 'membership_create', 1000, 9);
    await tx(S.rania, 'membership_renewal', 400, 8);
    await tx(S.manager, 'membership_create', 700, 7);

    // ── POS sales (name-attributed) ──────────────────────────────────────
    let inv = 0;
    const sale = async (userName: string | null, total: number, day: number, voided = false, branchId = branchA) => {
      inv += 1;
      return h.prisma.sale.create({
        data: {
          gymId, branchId, invoiceNo: `POS-${RUN}-${inv}`, total, method: 'CASH', paymentMethod: 'CASH',
          userName, createdAt: inRange(day), ...(voided ? { voidedAt: inRange(day), status: 'VOID' } : {}),
        },
      });
    };
    await sale('Rania Reception', 300, 6);
    await sale('rania reception ', 200, 5); // case + trailing space → SAME person
    const voidedSale = await sale('Rania Reception', 999, 4, true);
    await sale('Ghost Seller', 150, 3); // a name that matches no staff member
    await sale('', 50, 2); // empty name

    // ── refunds ─────────────────────────────────────────────────────────
    const refundBasis = await mkUser('Refund Basis', 'RECEPTION', branchA);
    const basis1 = await sale('Refund Basis', 400, 5);
    const basis2 = await sale('Refund Basis', 400, 5);
    await h.prisma.refund.create({
      data: { gymId, saleId: basis1.id, amount: 100, reason: 'partial', status: 'COMPLETED', createdBy: S.rania, createdAt: inRange(5) },
    });
    await h.prisma.refund.create({
      data: { gymId, saleId: basis2.id, amount: 999, reason: 'voided refund', status: 'VOIDED', createdBy: S.rania, createdAt: inRange(4) },
    });
    await h.prisma.refund.create({
      data: { gymId, saleId: voidedSale.id, amount: 300, reason: 'void of voided sale', status: 'COMPLETED', createdBy: S.rania, createdAt: inRange(4) },
    });

    // ── classes ─────────────────────────────────────────────────────────
    templateYoga = (await h.prisma.classTemplate.create({ data: { gymId, name: 'Yoga', nameAr: 'يوغا', capacity: 20, branchId: branchA } })).id;
    templateBox = (await h.prisma.classTemplate.create({ data: { gymId, name: 'Boxing', nameAr: 'بوكس', capacity: 20, branchId: branchA } })).id;
    const members = await Promise.all(
      Array.from({ length: 8 }, (_, i) =>
        h.prisma.member.create({
          data: {
            gymId, branchId: branchA, name: `Member ${i} ${RUN}`,
            mobile: `0100000${String(i).padStart(4, '0')}`, code: `M${RUN}${i}`,
            planId: h.gymA.planId, status: 'ACTIVE' as never,
            startDate: daysAgo(20), expiry: daysAgo(-10),
          },
        }),
      ),
    );
    const session = async (coachId: string, templateId: string, status: string, day: number, attend: number, confirmed: number, cancelled = 0, branchId = branchA) => {
      const s = await h.prisma.classSession.create({
        data: {
          gymId, templateId, branchId, coachId, capacity: 20, status: status as never,
          startsAt: inRange(day), endsAt: new Date(inRange(day).getTime() + 3600_000),
        },
      });
      let m = 0;
      for (let i = 0; i < attend; i++) await h.prisma.classBooking.create({ data: { gymId, sessionId: s.id, memberId: members[m++ % members.length].id, status: 'ATTENDED' } });
      for (let i = 0; i < confirmed; i++) await h.prisma.classBooking.create({ data: { gymId, sessionId: s.id, memberId: members[m++ % members.length].id, status: 'CONFIRMED' } });
      for (let i = 0; i < cancelled; i++) await h.prisma.classBooking.create({ data: { gymId, sessionId: s.id, memberId: members[m++ % members.length].id, status: 'CANCELLED' } });
      return s;
    };
    await session(S.coachA, templateYoga, 'COMPLETED', 10, 3, 1, 2);
    await session(S.coachA, templateYoga, 'COMPLETED', 9, 2, 0);
    await session(S.coachA, templateBox, 'COMPLETED', 8, 0, 0);
    await session(S.coachB, templateBox, 'COMPLETED', 7, 0, 2);
    await session(S.coachB, templateBox, 'CANCELLED', 6, 5, 0, 3); // must be ignored entirely
    await session(S.coachA, templateYoga, 'SCHEDULED', 1, 0, 4); // future, must be ignored

    // ── targets ─────────────────────────────────────────────────────────
    await h.prisma.staffTarget.create({ data: { gymId, userId: S.rania, period: monthKeyOf(new Date()), kind: 'SALES_VALUE', targetValue: 2000, createdBy: S.owner } });
    await h.prisma.staffTarget.create({ data: { gymId, userId: S.coachA, period: monthKeyOf(new Date()), kind: 'ATTENDANCE_RATE', targetValue: 90, createdBy: S.owner } });

    // ── another gym with a same-named staff member (cross-tenant probe) ──
    await h.prisma.user.create({
      data: {
        gymId: h.gymB.gymId, branchId: h.gymB.branchId, name: 'Rania Reception', role: 'RECEPTION' as never,
        email: `rania-b-${RUN}@team.test`, passwordHash: 'x'.repeat(60),
      },
    });
    await h.prisma.sale.create({
      data: { gymId: h.gymB.gymId, branchId: h.gymB.branchId, invoiceNo: `POSB-${RUN}`, total: 5000, method: 'CASH', userName: 'Rania Reception', createdAt: inRange(3) },
    });
  });

  afterAll(async () => { if (h) await h.close(); });

  // ── helpers ─────────────────────────────────────────────────────────────
  const asOwner = () => h.agent(h.gymA.owner.email);
  const findRow = (body: any, name: string) => body.items.find((i: any) => i.name === name);

  // ── 1. the list, against hard-coded numbers ─────────────────────────────
  it('computes every per-person number exactly (hand-computed expectations)', async () => {
    const owner = await asOwner();
    const res = await owner.get(`/team/performance?period=custom&from=${ymd(inRange(14))}&to=${ymd(new Date())}`).expect(200);
    const rania = findRow(res.body, 'Rania Reception');

    expect(rania).toMatchObject({
      newSubscriptions: 1,
      renewals: 1,
      membershipGross: '1400.00',
      posGross: '500.00',
      refunds: '100.00',
      net: '1800.00',
      // average over attributed money rows: 1800 / (2 membership + 2 sales) = 450
      average: '450.00',
    });
    // the manager's membership is attributed to the manager, not to Rania
    expect(findRow(res.body, 'Manager a Person')).toMatchObject({ membershipGross: '700.00', net: '700.00' });

    // not attributable carries the 150 + 50 POS rows and nothing else
    expect(res.body.notAttributable).toMatchObject({
      posGross: '200.00',
      posCount: 2,
      membershipGross: '0.00',
      refunds: '0.00',
    });

    // the voided sale and the voided-sale refund are excluded everywhere
    expect(res.body.notAttributable.posGross).not.toBe('1199.00');
    expect(rania.refunds).not.toBe('1399.00');
  });

  it('reconciles attributed + not attributable against INDEPENDENT SQL', async () => {
    const owner = await asOwner();
    const body = (await owner.get(`/team/performance?period=custom&from=${ymd(inRange(14))}&to=${ymd(new Date())}`).expect(200)).body;

    const [mem, pos, ref] = await Promise.all([
      h.prisma.transaction.aggregate({ where: { gymId, type: 'INCOME', category: { in: ['membership_create', 'membership_renewal'] }, createdAt: { gte: inRange(14), lt: new Date(Date.now() + 86400000) } }, _sum: { amount: true } }),
      h.prisma.$queryRawUnsafe<Array<{ s: string }>>(`SELECT COALESCE(SUM(total),0)::text AS s FROM "Sale" WHERE "gymId"=$1 AND "voidedAt" IS NULL AND UPPER(status) NOT IN ('VOID','VOIDED')`, gymId),
      h.prisma.$queryRawUnsafe<Array<{ s: string }>>(
        `SELECT COALESCE(SUM(r.amount),0)::text AS s FROM "Refund" r JOIN "Sale" s ON s.id=r."saleId" WHERE r."gymId"=$1 AND r.status='COMPLETED' AND s."voidedAt" IS NULL`,
        gymId,
      ),
    ]);
    const gymMembership = Number(mem._sum.amount ?? 0);
    const gymPos = Number(pos[0].s);
    const gymRefunds = Number(ref[0].s);

    // independent SQL says: 2100 membership; 1500 POS = 500 Rania + 800 Refund
    // Basis + 200 not attributable; 100 refunds (voided sale + voided refund out)
    expect({ gymMembership, gymPos, gymRefunds }).toEqual({ gymMembership: 2100, gymPos: 1500, gymRefunds: 100 });

    const attributedNet = body.items.reduce((acc: number, r: any) => acc + Number(r.net), 0);
    const na = body.notAttributable;
    const reconstructed = attributedNet + Number(na.membershipGross) + Number(na.posGross) - Number(na.refunds);
    expect(reconstructed).toBe(gymMembership + gymPos - gymRefunds); // 2100 + 1500 − 100
    expect(reconstructed).toBe(3500);
  });

  it('handles the owner’s attribution edge cases: case/space, duplicates, unknown, empty', async () => {
    // duplicate staff name in the SAME gym → cannot be attributed by name
    const dup = await h.prisma.user.create({
      data: { gymId, branchId: branchA, name: 'Twin Name', role: 'RECEPTION' as never, email: `twin1-${RUN}@team.test`, passwordHash: 'x'.repeat(60) },
    });
    await h.prisma.user.create({
      // identical after trim + case-fold, which is the ENTIRE matching rule
      data: { gymId, branchId: branchA, name: ' twin name ', role: 'RECEPTION' as never, email: `twin2-${RUN}@team.test`, passwordHash: 'x'.repeat(60) },
    });
    // and a near-miss that must NOT be treated as a duplicate (double space)
    await h.prisma.user.create({
      data: { gymId, branchId: branchA, name: 'twin  name', role: 'RECEPTION' as never, email: `twin3-${RUN}@team.test`, passwordHash: 'x'.repeat(60) },
    });
    await h.prisma.sale.create({
      data: { gymId, branchId: branchA, invoiceNo: `POS-DUP-${RUN}`, total: 777, method: 'CASH', userName: 'Twin Name', createdAt: inRange(2) },
    });
    const owner = await asOwner();
    const body = (await owner.get(`/team/performance?period=custom&from=${ymd(inRange(14))}&to=${ymd(new Date())}`).expect(200)).body;
    // the ambiguous name is NOT guessed onto either twin, and it IS visible
    expect(findRow(body, 'Twin Name')?.posGross).toBe('0.00');
    expect(Number(body.notAttributable.posGross)).toBeGreaterThanOrEqual(200 + 777);
    await h.prisma.user.deleteMany({ where: { id: dup.id } });
  });

  it('attributes a sale to a DEACTIVATED staff member (history is kept)', async () => {
    const gone = await h.prisma.user.create({
      data: { gymId, branchId: branchA, name: 'Departed Seller', role: 'RECEPTION' as never, email: `gone-${RUN}@team.test`, passwordHash: 'x'.repeat(60), active: false },
    });
    await h.prisma.sale.create({ data: { gymId, branchId: branchA, invoiceNo: `POS-GONE-${RUN}`, total: 321, method: 'CASH', userName: 'Departed Seller', createdAt: inRange(2) } });
    const owner = await asOwner();
    // inactive staff are hidden by DEFAULT …
    const without = (await owner.get(`/team/performance?period=custom&from=${ymd(inRange(14))}&to=${ymd(new Date())}`).expect(200)).body;
    expect(findRow(without, 'Departed Seller')).toBeUndefined();
    // … their money is attributed to them by id, never guessed onto a colleague
    // and never dumped into "not attributable" (which would be a lie: we know
    // exactly whose sale it was). It reappears the moment they are included.
    expect(Number(without.notAttributable.posGross)).toBe(200);
    // … but it is visible on request
    const withInactive = (await owner.get(`/team/performance?includeInactive=true&period=custom&from=${ymd(inRange(14))}&to=${ymd(new Date())}`).expect(200)).body;
    expect(findRow(withInactive, 'Departed Seller').posGross).toBe('321.00');
    await h.prisma.sale.deleteMany({ where: { invoiceNo: `POS-GONE-${RUN}` } });
    await h.prisma.user.delete({ where: { id: gone.id } });
  });

  // ── 2. coaches ──────────────────────────────────────────────────────────
  it('computes attendance exactly and never invents a rate for a zero denominator', async () => {
    const owner = await asOwner();
    const body = (await owner.get(`/team/performance?period=custom&from=${ymd(inRange(14))}&to=${ymd(new Date())}`).expect(200)).body;
    expect(findRow(body, 'Coach A')).toMatchObject({ sessionsHeld: 3, booked: 6, membersAttended: 5, attendanceRate: 83.3, attendanceLowSample: false });
    expect(findRow(body, 'Coach B')).toMatchObject({ sessionsHeld: 1, booked: 2, membersAttended: 0, attendanceRate: 0, attendanceLowSample: true });
    const c = findRow(body, 'Coach C');
    expect(c).toMatchObject({ sessionsHeld: 0, booked: 0, membersAttended: 0, attendanceRate: null });
    expect(JSON.stringify(c)).not.toContain('NaN');
  });

  it('excludes CANCELLED and SCHEDULED sessions from every coach number', async () => {
    // the CANCELLED session carried 5 attended + 3 cancelled bookings and the
    // SCHEDULED one 4 confirmed: if either leaked, Coach A/B numbers would move.
    const owner = await asOwner();
    const body = (await owner.get(`/team/performance?period=custom&from=${ymd(inRange(14))}&to=${ymd(new Date())}`).expect(200)).body;
    expect(findRow(body, 'Coach B')).toMatchObject({ sessionsHeld: 1, booked: 2, membersAttended: 0 });
    expect(findRow(body, 'Coach A')).toMatchObject({ sessionsHeld: 3, booked: 6, membersAttended: 5 });
  });

  it('breaks the coach down per class type, with raw counts beside the percentage', async () => {
    const owner = await asOwner();
    const res = await owner.get(`/team/performance/${S.coachA}?period=custom&from=${ymd(inRange(14))}&to=${ymd(new Date())}`).expect(200);
    const yoga = res.body.attendance.byClassType.find((t: any) => t.name === 'Yoga');
    const box = res.body.attendance.byClassType.find((t: any) => t.name === 'Boxing');
    // Yoga: 4 non-cancelled on session 1 (3 attended + 1 confirmed) + 2 attended on session 2
expect(yoga).toMatchObject({ sessions: 2, booked: 6, attended: 5, rate: 83.3, nameAr: 'يوغا' });
    // Boxing: one COMPLETED session with ZERO bookings → rate must be null, not 0 %
expect(box).toMatchObject({ sessions: 1, booked: 0, attended: 0, rate: null, nameAr: 'بوكس' });
    expect(res.body.attendance).toMatchObject({ sessionsHeld: 3, booked: 6, membersAttended: 5, rate: 83.3 });
  });

  it('returns a daily trend computed in the gym timezone', async () => {
    const owner = await asOwner();
    const res = await owner.get(`/team/performance/${S.rania}?period=custom&from=${ymd(inRange(14))}&to=${ymd(new Date())}`).expect(200);
    expect(res.body.range.tz).toBe('Africa/Cairo');
    const days = res.body.trend.map((t: any) => t.day);
    expect([...days].sort()).toEqual(days); // ascending
    const total = res.body.trend.reduce((a: number, t: any) => a + Number(t.net), 0);
    expect(total).toBe(1400); // Rania's membership only: POS is name-attributed, not on the ledger
  });

  // ── 3. targets ──────────────────────────────────────────────────────────
  it('upserts a target ON CONFLICT: twice is one row, the second value wins, both are audited', async () => {
    const owner = await asOwner();
    const period = monthKeyOf(new Date());
    const payload = { items: [{ userId: S.rania, period, kind: 'NEW_SUBSCRIPTIONS', targetValue: '8' }] };
    const first = await owner.post('/team/performance/targets', payload).expect(201);
    expect(first.body.items[0]).toMatchObject({ target: '8.00', previous: null, created: true });
    const second = await owner.post('/team/performance/targets', payload.items ? { items: [{ ...payload.items[0], targetValue: '12' }] } : payload).expect(201);
    expect(second.body.items[0]).toMatchObject({ target: '12.00', previous: '8.00', created: false });

    const rows = await h.prisma.staffTarget.findMany({ where: { gymId, userId: S.rania, period, kind: 'NEW_SUBSCRIPTIONS' } });
    expect(rows).toHaveLength(1);
    expect(rows[0].targetValue.toFixed(2)).toBe('12.00');

    const audit = await h.prisma.auditLog.findMany({ where: { gymId, entity: 'StaffTarget', action: { in: ['team.target.created', 'team.target.updated'] } }, orderBy: { createdAt: 'desc' }, take: 4 });
    expect(audit.length).toBeGreaterThanOrEqual(2);
    const latest = audit.find((a) => (a.metadata as any).period === period && (a.metadata as any).kind === 'NEW_SUBSCRIPTIONS');
    expect((latest!.metadata as any)).toMatchObject({ previous: '8.00', next: '12.00' });
    expect(JSON.stringify(latest!.metadata)).not.toContain('@'); // no email in history
  });

  it('survives two concurrent upserts of the same key (race-safe)', async () => {
    const owner = await asOwner();
    const period = monthKeyOf(new Date());
    const mk = (v: string) => ({ items: [{ userId: S.manager, period, kind: 'SALES_VALUE', targetValue: v }] });
    const [a, b] = await Promise.all([
      owner.post('/team/performance/targets', mk('5000')).catch((e) => e.response),
      owner.post('/team/performance/targets', mk('6000')).catch((e) => e.response),
    ]);
    expect([201, 409, 429]).toContain(a.status ?? 201);
    expect([201, 409, 429]).toContain(b.status ?? 201);
    const rows = await h.prisma.staffTarget.findMany({ where: { gymId, userId: S.manager, period, kind: 'SALES_VALUE' } });
    expect(rows).toHaveLength(1);
    expect(['5000.00', '6000.00']).toContain(rows[0].targetValue.toFixed(2));
  });

  it('refuses a target for another gym’s staff member, an impossible rate, and a bad period', async () => {
    const owner = await asOwner();
    const period = monthKeyOf(new Date());
    const foreign = await h.prisma.user.findFirst({ where: { gymId: h.gymB.gymId }, select: { id: true } });
    const bad = await owner.post('/team/performance/targets', { items: [{ userId: foreign!.id, period, kind: 'SALES_VALUE', targetValue: '100' }] }).expect(400);
    expect(bad.body.code).toBe('UNKNOWN_STAFF');
    await owner.post('/team/performance/targets', { items: [{ userId: S.rania, period, kind: 'ATTENDANCE_RATE', targetValue: '150' }] }).expect(400);
    await owner.post('/team/performance/targets', { items: [{ userId: S.rania, period: '2026-13', kind: 'SALES_VALUE', targetValue: '1' }] }).expect(400);
    await owner.post('/team/performance/targets', { items: [{ userId: S.rania, period, kind: 'BONUS', targetValue: '1' }] }).expect(400);
    await owner.post('/team/performance/targets', { items: [{ userId: S.rania, period, kind: 'SALES_VALUE', targetValue: '-5' }] }).expect(400);
    // nothing was written for the foreign user
    expect(await h.prisma.staffTarget.count({ where: { gymId: h.gymB.gymId } })).toBe(0);
  });

  it('shows target progress, remaining and days left from the same numbers', async () => {
    const owner = await asOwner();
    const body = (await owner.get(`/team/performance?period=custom&from=${ymd(inRange(14))}&to=${ymd(new Date())}`).expect(200)).body;
    const rania = findRow(body, 'Rania Reception');
    expect(rania.salesTarget).toMatchObject({ target: '2000.00', progressPct: 90, remaining: '200.00' });
    expect(rania.salesTarget.daysLeft).toBeGreaterThanOrEqual(1);
    const coach = findRow(body, 'Coach A');
    expect(coach.attendanceTarget).toMatchObject({ target: '90.00' });
    expect(coach.attendanceTarget.progressPct).toBe(92.6); // 83.3 / 90
  });

  // ── 4. access control ──────────────────────────────────────────────────
  it('gates on the NEW permission: manager denied by default, allowed once the owner grants it', async () => {
    const manager = await h.agent(h.gymA.manager.email);
    const denied = await manager.get('/team/performance').expect(403);
    expect(denied.body.code).toBe('PERMISSION_DENIED');

    await h.prisma.userPermission.create({ data: { gymId, userId: S.manager, permission: 'team.performance.view', granted: true } });
    await manager.get('/team/performance').expect(200);
    await manager.get('/team/performance/targets').expect(200);
    await h.prisma.userPermission.deleteMany({ where: { gymId, userId: S.manager, permission: 'team.performance.view' } });
    await manager.get('/team/performance').expect(403);
  });

  it('denies reception, coach and accountant on every management route', async () => {
    for (const who of [h.gymA.receptionist, h.gymA.coach, h.gymA.accountant]) {
      const s = await h.agent(who.email);
      await s.get('/team/performance').expect(403);
      await s.get(`/team/performance/${S.rania}`).expect(403);
      await s.get('/team/performance/targets').expect(403);
      await s.post('/team/performance/targets', { items: [] }).expect(403);
      await s.get('/team/performance/export.csv').expect(403);
    }
  });

  it('lets a staff member read ONLY their own numbers through /me', async () => {
    const coach = await h.agent(h.gymA.coach.email);
    // /me is gated on `profile.self` (every role holds it by default) — not on
    // team.performance.view, so a coach can see their OWN numbers but nobody else's.
    const me = await coach.get(`/team/performance/me?period=custom&from=${ymd(inRange(14))}&to=${ymd(new Date())}`).expect(200);
    expect(me.body.staff.userId).toBe(h.gymA.coach.id);
    // no other staff member's name, revenue or target appears anywhere in the payload
    const blob = JSON.stringify(me.body);
    for (const name of ['Rania Reception', 'Manager a Person', 'Coach A', 'Coach B']) expect(blob).not.toContain(name);
    expect(blob).not.toContain('"items"');
  });

  it('answers 401 without a session', async () => {
    const request = require('supertest');
    await request(h.app.getHttpServer()).get(`${API}/team/performance`).expect(401);
    await request(h.app.getHttpServer()).get(`${API}/team/performance/export.csv`).expect(401);
  });

  // ── 5. tenancy ─────────────────────────────────────────────────────────
  it('keeps the other gym out of the numbers even with an identical staff name', async () => {
    const owner = await asOwner();
    const body = (await owner.get(`/team/performance?period=custom&from=${ymd(inRange(14))}&to=${ymd(new Date())}`).expect(200)).body;
    // gym B has a "Rania Reception" with a 5000 POS sale: none of it may appear
    expect(JSON.stringify(body)).not.toContain('5000.00');
    expect(body.notAttributable.posGross).not.toBe('5200.00');
  });

  it('404s another gym’s staff id, and 400s another gym’s branch id', async () => {
    const owner = await asOwner();
    const foreign = await h.prisma.user.findFirst({ where: { gymId: h.gymB.gymId }, select: { id: true } });
    await owner.get(`/team/performance/${foreign!.id}`).expect(404);
    await owner.get(`/team/performance?branchId=${h.gymB.branchId}`).expect(400);
    await owner.get(`/team/performance?branchId=${branchB}`).expect(200);

    // branch filter really filters
    const onlyB = (await owner.get(`/team/performance?branchId=${branchB}&period=custom&from=${ymd(inRange(14))}&to=${ymd(new Date())}`).expect(200)).body;
    expect(onlyB.items.map((i: any) => i.name)).toEqual(expect.arrayContaining(['Coach C']));
    expect(onlyB.items.map((i: any) => i.name)).not.toContain('Rania Reception');
  });

  it('proves FORCE RLS on StaffTarget as flexora_app', async () => {
    await assertRuntimeRole(h.runtime, 'StaffTarget');
    const rows = await h.runtime.$queryRawUnsafe<Array<{ n: string }>>(`SELECT COUNT(*)::text AS n FROM public."StaffTarget"`);
    expect(Number(rows[0].n)).toBe(0);
    // …while the owner connection (bypasses FORCE as table owner) sees the rows
    expect(await h.prisma.staffTarget.count({ where: { gymId } })).toBeGreaterThan(0);
  });

  /**
   * THE REGRESSION THAT MATTERS MOST.
   *
   * jest runs as the OWNER role, so the app under test is a superuser and every
   * FORCE-RLS policy is bypassed. That is how FEATURE B shipped with reads that
   * returned 0.00 in production while the whole suite was green: `groupBy` goes
   * through Prisma's model layer (which sets `app.gym_id`), but `$queryRaw` does
   * NOT — so POS, refunds and class aggregation came back empty for the real
   * runtime role.
   *
   * This test boots a SECOND application whose PrismaClient is `flexora_app`
   * (NOSUPERUSER NOBYPASSRLS) and asks the same question over HTTP. If any read
   * forgets withTenant, the numbers collapse to zero here.
   */
  it('returns identical numbers when the api itself connects as flexora_app (RLS from the inside)', async () => {
    const prod = await startRuntimeApp();
    try {
      // PROVE the second app really is the runtime role — otherwise this test
      // would silently pass as the superuser it is meant to expose.
      const prodPrisma = prod.app.get(PrismaService);
      const who = await prodPrisma.$queryRawUnsafe<Array<{ u: string }>>('SELECT current_user AS u');
      expect(who[0].u).toBe('flexora_app');
      const owner = await prod.agent(h.gymA.owner.email);
      const res = await owner.get(`/team/performance?period=custom&from=${ymd(inRange(14))}&to=${ymd(new Date())}`).expect(200);
      const rania = res.body.items.find((i: any) => i.name === 'Rania Reception');
      expect(rania).toMatchObject({ membershipGross: '1400.00', posGross: '500.00', refunds: '100.00', net: '1800.00' });
      const coach = res.body.items.find((i: any) => i.name === 'Coach A');
      expect(coach).toMatchObject({ sessionsHeld: 3, booked: 6, membersAttended: 5, attendanceRate: 83.3 });
      expect(Number(res.body.notAttributable.posGross)).toBeGreaterThanOrEqual(200);
      // …and the csv, which is built from the same reads
      const csv = await owner.get('/team/performance/export.csv').expect(200);
      expect(csv.text).toContain('Rania Reception');
    } finally {
      await prod.close();
    }
  });

  // ── 6. input validation ────────────────────────────────────────────────
  it('rejects impossible and oversized ranges', async () => {
    const owner = await asOwner();
    await owner.get('/team/performance?period=custom&from=2020-01-01&to=2026-01-01').expect(400);
    await owner.get('/team/performance?period=custom&from=2026-05-10&to=2026-05-01').expect(400);
    await owner.get('/team/performance?from=2026-02-30&to=2026-03-01').expect(400);
    await owner.get('/team/performance?period=custom&from=2026-05-01').expect(400); // incomplete
    await owner.get('/team/performance?pageSize=5000').expect(400);
    await owner.get('/team/performance?whatever=1').expect(400);
    await owner.get('/team/performance?sort=passwordHash').expect(400);
  });

  it('defaults to the current month and echoes the resolved range', async () => {
    const owner = await asOwner();
    const body = (await owner.get('/team/performance').expect(200)).body;
    expect(body.range.tz).toBe('Africa/Cairo');
    expect(body.range.to).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    expect(body.period).toMatch(/^\d{4}-\d{2}$/);
    expect(body.range.days).toBeLessThanOrEqual(31);
  });

  // ── 7. no PII ──────────────────────────────────────────────────────────
  it('never returns email, phone, password hash or member data — on EVERY new route', async () => {
    const owner = await asOwner();
    const period = monthKeyOf(new Date());
    const bodies: Record<string, string> = {};
    bodies['GET /team/performance'] = JSON.stringify((await owner.get('/team/performance').expect(200)).body);
    bodies['GET /team/performance?includeInactive=true'] = JSON.stringify((await owner.get('/team/performance?includeInactive=true').expect(200)).body);
    bodies['GET /team/performance/:id'] = JSON.stringify((await owner.get(`/team/performance/${S.rania}`).expect(200)).body);
    bodies['GET /team/performance/targets'] = JSON.stringify((await owner.get(`/team/performance/targets?period=${period}`).expect(200)).body);
    bodies['GET /team/performance/me'] = JSON.stringify((await owner.get('/team/performance/me').expect(200)).body);
    bodies['GET /team/performance/export.csv'] = (await owner.get('/team/performance/export.csv').expect(200)).text;
    // the posts' response carries ids only — assert that too
    bodies['POST /team/performance/targets'] = JSON.stringify(
      (await owner.post('/team/performance/targets', { items: [{ userId: S.coachC, period, kind: 'NEW_SUBSCRIPTIONS', targetValue: '3' }] }).expect(201)).body,
    );

    for (const [route, blob] of Object.entries(bodies)) {
      expect({ route, hasEmail: /@team\.test/.test(blob) }).toEqual({ route, hasEmail: false });
      expect({ route, hasHash: /passwordHash/.test(blob) }).toEqual({ route, hasHash: false });
      expect({ route, hasMemberPhone: /0100000\d{4}/.test(blob) }).toEqual({ route, hasMemberPhone: false });
      expect({ route, hasMemberName: /Member \d/.test(blob) }).toEqual({ route, hasMemberName: false });
      expect({ route, hasNationalId: /nationalId/.test(blob) }).toEqual({ route, hasNationalId: false });
    }
  });

  // ── 8. CSV ─────────────────────────────────────────────────────────────
  it('exports an allowlisted, RFC-4180 CSV with the not-attributable row', async () => {
    const owner = await asOwner();
    const res = await owner.get('/team/performance/export.csv').expect(200);
    expect(res.headers['content-type']).toContain('text/csv');
    expect(res.headers['content-disposition']).toContain('attachment; filename="team-performance-');
    expect(res.headers['x-report-timezone']).toBe('Africa/Cairo');
    const lines = res.text.replace(/^\uFEFF/, '').split('\r\n').filter(Boolean);
    const header = lines[0].split(',');
    expect(header).toContain('new_subscriptions');
    expect(header).toContain('attendance_rate_pct');
    expect(header).not.toContain('email');
    expect(header).not.toContain('phone');
    // every data row has the same column count (RFC 4180 shape)
    for (const line of lines.slice(1)) expect(line.split(',').length).toBeGreaterThanOrEqual(header.length);
    expect(lines[lines.length - 1].startsWith('not attributable')).toBe(true);
    expect(Number(res.headers['x-row-count'])).toBeGreaterThan(0);
  });

  it('neutralises a formula in a staff name and still writes Arabic', async () => {
    const evil = await h.prisma.user.create({
      data: { gymId, branchId: branchA, name: `=cmd|' /C calc'!A0`, role: 'RECEPTION' as never, email: `evil-${RUN}@team.test`, passwordHash: 'x'.repeat(60) },
    });
    const ar = await h.prisma.user.create({
      data: { gymId, branchId: branchA, name: 'رانيا استقبال', role: 'RECEPTION' as never, email: `ar-${RUN}@team.test`, passwordHash: 'x'.repeat(60) },
    });
    const owner = await asOwner();
    const csv = (await owner.get('/team/performance/export.csv').expect(200)).text;
    const evilLine = csv.split('\r\n').find((l) => l.includes('calc'))!;
    expect(evilLine.startsWith(`'=cmd|' /C calc'!A0,`)).toBe(true); // prefixed with ', so Excel stores text
    expect(evilLine.startsWith('=')).toBe(false);
    expect(csv).toContain('رانيا استقبال');
    expect(csv.split('\r\n')[0]).not.toContain('"');
    await h.prisma.user.deleteMany({ where: { id: { in: [evil.id, ar.id] } } });
  });

  // ── 9. pure helpers ────────────────────────────────────────────────────
  it('the shared helpers agree with the same hard-coded numbers', () => {
    expect(ratioPct(5, 6)).toBe(83.3);
    expect(ratioPct(0, 0)).toBeNull();
    expect(ratioPct(1, 0)).toBeNull();
    expect(targetProgress('SALES_VALUE', 1800, 2000)).toBe(90);
    expect(targetProgress('ATTENDANCE_RATE', 83.3, 90)).toBe(92.6);
    expect(targetProgress('SALES_VALUE', 5, null)).toBeNull();
    expect(targetProgress('SALES_VALUE', 5, 0)).toBeNull();
    expect(csvCell('=1+1')).toBe("'=1+1");
    expect(csvCell('-12.50')).toBe('-12.50'); // a negative amount stays a number
    expect(csvCell('@SUM(A1)')).toBe("'@SUM(A1)");
    expect(csvRow(['a,b', 'c"d'])).toBe('"a,b","c""d"');
    const att = attributeByExactName([{ userName: ' rania reception ' }, { userName: 'Rania Reception' }, { userName: 'Nobody' }], ['Rania Reception']);
    expect(att.byName.get('rania reception')).toHaveLength(2);
    expect(att.unmatched).toHaveLength(1);
  });
});

function ymd(d: Date): string {
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
}
