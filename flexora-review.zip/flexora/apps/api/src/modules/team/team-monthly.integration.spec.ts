/** @jest-environment node */
/**
 * PACK 2 item 4 — the monthly money matrix against a REAL database.
 *
 * Every expected number below is hand-computed from the fixture written here,
 * and the totals are additionally reconciled against INDEPENDENT SQL written in
 * this file (a different query from the service's). Skipped unless a database
 * and the runtime-role password are provided, like the rest of the integration
 * fleet.
 *
 * Fixture (current Cairo month = M, previous = P):
 *   Amal (active)
 *     P  create 1000  · renewal 300
 *     P  POS "Amal Hany" 200
 *     P  collected 1000 (MANUAL_MEMBERSHIP, PAID)
 *     M  POS "amal hany" 50 (case-fold) · POS "" 40 (no name)
 *     M  refund 500 on the P sale (COMPLETED) → lands in M, not P
 *     M  refund 70 (VOIDED) → excluded
 *     M  collected 0
 *   Bassem (active, idle)            → all zeros, averageNet null
 *   Nour  (DEACTIVATED, has money)   → must still appear, with her money
 *     P  renewal 120
 *   "Same Name" ×2 (active)          → one POS sale for that name is ambiguous
 *   orphan refund 15 whose createdBy is not a staff member → its own row
 *   voided sale 999                  → never counted (status VOIDED)
 *   soft-voided sale 777             → never counted (status COMPLETED, voidedAt set)
 *
 * Amal   P net = 1000+300+200            = 1500.00
 *        M net = 50 − 500                =  -450.00   (negative, never clamped)
 * Nour   P net = 120                     =   120.00
 * orphan M net = -15
 * gym    P total = 1620.00 · M total = -345.00 (rows -465 + not attributed 120)
 * POS    P attributed 200 · M attributed 50 · not attributable 40 (empty name)
 *        + 80 (ambiguous "Same Name") = 120
 */
import {
  assertRuntimeRole,
  runtimeRolePassword,
  startTenantHarness,
  TenantHarness,
} from '../../test/support/tenant-app-harness';
import { TeamMonthlyService } from './team-monthly.service';
import { Actor } from './team-performance.service';

jest.setTimeout(180_000);

const RUN = Date.now().toString(36);
const isIntegration = Boolean(process.env.DATABASE_URL && runtimeRolePassword());
const d = isIntegration ? describe : describe.skip;

/** The UTC instant at which the Cairo wall clock shows 00:00 on y-m-1. */
function cairoMidnightUtc(year: number, monthIndex: number): Date {
  const want = `${year}-${String(monthIndex + 1).padStart(2, '0')}-01`;
  const probe = new Date(Date.UTC(year, monthIndex, 1));
  for (let min = -180; min <= 180; min += 1) {
    const t = new Date(probe.getTime() + min * 60_000);
    const got = new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Africa/Cairo', year: 'numeric', month: '2-digit', day: '2-digit',
    }).format(t);
    if (got === want) return t;
  }
  throw new Error('no cairo midnight found');
}

const monthKeyAt = (t: Date) =>
  new Intl.DateTimeFormat('en-CA', { timeZone: 'Africa/Cairo', year: 'numeric', month: '2-digit' })
    .format(t);

d('PACK 2 item 4 — monthly money matrix (real app + real database)', () => {
  let h: TenantHarness;
  let gymId: string;
  let branchId: string;
  let svc: TeamMonthlyService;
  let actor: Actor;

  // M = current Cairo month, P = the one before it
  const nowCairo = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Africa/Cairo', year: 'numeric', month: '2-digit', day: '2-digit',
  }).format(new Date()).split('-').map(Number);
  const M_START = cairoMidnightUtc(nowCairo[0], nowCairo[1] - 1);
  const P_START = cairoMidnightUtc(nowCairo[1] === 1 ? nowCairo[0] - 1 : nowCairo[0], nowCairo[1] === 1 ? 11 : nowCairo[1] - 2);
  const M_KEY = monthKeyAt(M_START);
  const P_KEY = monthKeyAt(P_START);
  /** a safe day inside each month */
  const inM = (hours: number) => new Date(M_START.getTime() + hours * 3_600_000);
  const inP = (hours: number) => new Date(P_START.getTime() + hours * 3_600_000);

  const S = { amal: '', bassem: '', nour: '', same1: '', same2: '', edge: '', hany1: '', hany2: '' };

  beforeAll(async () => {
    h = await startTenantHarness(`monthly${RUN}`);
    await assertRuntimeRole(h.runtime);
    gymId = h.gymA.gymId;
    branchId = h.gymA.branchId;
    svc = h.app.get(TeamMonthlyService);
    actor = { id: h.gymA.owner.id, role: 'OWNER', gymId, unrestrictedBranch: true } as Actor;

    const mkUser = async (name: string, role: string, active = true) => (await h.prisma.user.create({
      data: {
        gymId, branchId, name, role: role as never, onboardingCompleted: true, active,
        email: `${role.toLowerCase()}-${RUN}-${Math.random().toString(36).slice(2, 8)}@monthly.test`,
        passwordHash: 'x'.repeat(60),
      },
    })).id;

    S.amal = await mkUser('Amal Hany', 'RECEPTION');
    S.bassem = await mkUser('Bassem Idle', 'RECEPTION');
    // deactivated, but she moved money in P
    S.nour = await mkUser('Nour Gone', 'RECEPTION', false);
    S.edge = await mkUser('Edge Midnight', 'RECEPTION');
    // share a four-letter prefix but not a name: a prefix match must not attribute
    S.hany1 = await mkUser('Hany Farouk', 'RECEPTION');
    S.hany2 = await mkUser('Hany Fouad', 'RECEPTION');
    S.same1 = await mkUser('Same Name', 'RECEPTION');
    S.same2 = await mkUser('Same Name', 'RECEPTION');

    const tx = (createdBy: string, category: string, amount: number, when: Date) =>
      h.prisma.transaction.create({
        data: { gymId, type: 'INCOME', category, description: `${category} ${RUN}`, amount, branchId, createdBy, createdAt: when },
      });
    await tx(S.amal, 'membership_create', 1000, inP(10));
    await tx(S.amal, 'membership_renewal', 300, inP(11));
    await tx(S.nour, 'membership_renewal', 120, inP(12));

    let inv = 0;
    const sale = (userName: string | null, total: number, when: Date, voided = false) => {
      inv += 1;
      return h.prisma.sale.create({
        data: {
          gymId, branchId, invoiceNo: `M${RUN}-${inv}`, subtotal: total, total, discount: 0,
          userName, paymentMethod: 'CASH', method: 'CASH', status: voided ? 'VOIDED' : 'COMPLETED',
          paymentStatus: 'PAID', createdAt: when, voidedAt: voided ? when : null,
        },
      });
    };
    const s1 = await sale('Amal Hany', 200, inP(13));
    await sale('amal hany', 50, inM(13));           // case-fold still attributes
    await sale('', 40, inM(14));                    // no name → not attributable
    await sale('Same Name', 80, inM(15));           // two people share the name → not attributable
    await sale('Amal Hany', 999, inM(16), true);    // voided → never counted
    // voided AFTER completion: status is still COMPLETED and only voidedAt says
    // otherwise. Without this row the voidedAt guard is not actually tested —
    // the status guard above would hide a missing voidedAt filter.
    await h.prisma.sale.create({
      data: {
        gymId, branchId, invoiceNo: `M${RUN}-soft`, subtotal: 777, total: 777, discount: 0,
        userName: 'Amal Hany', paymentMethod: 'CASH', method: 'CASH', status: 'COMPLETED',
        paymentStatus: 'PAID', createdAt: inM(17), voidedAt: inM(18),
      },
    });
    // and the mirror case: status says VOIDED but nothing was timestamped. Only the
    // status guard can exclude this one, so it isolates that guard on its own.
    await h.prisma.sale.create({
      data: {
        gymId, branchId, invoiceNo: `M${RUN}-stat`, subtotal: 333, total: 333, discount: 0,
        userName: 'Amal Hany', paymentMethod: 'CASH', method: 'CASH', status: 'VOIDED',
        paymentStatus: 'PAID', createdAt: inM(19),
      },
    });
    // exact name, but a second staff member shares the first four letters
    await sale('Hany Farouk', 90, inM(20));

    const refund = (saleId: string, amount: number, status: string, createdBy: string | null, when: Date) =>
      h.prisma.refund.create({
        data: { gymId, saleId, amount, reason: `refund ${RUN}`, status: status as never, createdBy, createdAt: when, type: 'PARTIAL' },
      });
    await refund(s1.id, 500, 'COMPLETED', S.amal, inM(2));   // later month than the sale
    await refund(s1.id, 70, 'VOIDED', S.amal, inM(3));       // voided → excluded
    await refund(s1.id, 15, 'COMPLETED', 'not-a-user-in-gym', inM(4)); // orphan → own row

    const invoice = await h.prisma.invoice.create({
      data: { gymId, invoiceNo: `MINV-${RUN}`, status: 'PAID', subtotal: 1000, total: 1000, paid: 1000, createdAt: inP(9) },
    });
    const payment = (purpose: string, status: string, amount: number, when: Date, createdBy: string) =>
      h.prisma.payment.create({
        data: { gymId, invoiceId: invoice.id, amount, method: 'CASH', status: status as never,
          paidAt: when, createdBy, purpose: purpose as never },
      });
    await payment('MANUAL_MEMBERSHIP', 'PAID', 1000, inP(10), S.amal);  // collected in P
    await payment('MANUAL_MEMBERSHIP', 'PENDING', 500, inM(5), S.amal); // not collected
    await payment('POS_SALE', 'PAID', 400, inM(6), S.amal);             // POS collection: not attributable
  });

  afterAll(async () => { if (h) await h.close(); });

  const rowFor = (payload: Awaited<ReturnType<TeamMonthlyService['monthly']>>, name: string) =>
    payload.rows.find((r) => r.name === name);

  it('has done all the work by hand: Amal, per month', async () => {
    const p = await svc.monthly(gymId, actor, { months: 6 });
    expect(p.months).toContain(M_KEY);
    expect(p.months).toContain(P_KEY);
    const amal = rowFor(p, 'Amal Hany')!;
    const pCell = amal.months.find((c) => c.month === P_KEY)!;
    const mCell = amal.months.find((c) => c.month === M_KEY)!;

    // P: 1000 create + 300 renewal + 200 POS, 1000 collected
    expect(pCell.newSubscriptions).toBe(1);
    expect(pCell.renewals).toBe(1);
    expect(pCell.membershipSold).toBe('1300.00');
    expect(pCell.posSold).toBe('200.00');
    expect(pCell.refunds).toBe('0.00');
    expect(pCell.collected).toBe('1000.00');
    expect(pCell.net).toBe('1500.00');

    // M: 50 POS (case-fold) − 500 refund. The refund of a P sale is NOT in P.
    expect(mCell.newSubscriptions).toBe(0);
    expect(mCell.membershipSold).toBe('0.00');
    // 50 only: the 999 (status VOIDED) and the 777 (voidedAt only) are both out
    expect(mCell.posSold).toBe('50.00');
    expect(mCell.refunds).toBe('500.00');   // 70 VOIDED not added
    expect(mCell.collected).toBe('0.00');   // PENDING 500 and POS_SALE 400 not collected
    expect(mCell.net).toBe('-450.00');      // negative, never clamped

    expect(amal.totals.net).toBe('1050.00');
    expect(amal.totals.collected).toBe('1000.00');
    expect(amal.bestMonth).toEqual({ month: P_KEY, net: '1500.00' });
    // average over the two months with activity
    expect(amal.averageNet).toBe('525.00');
  });

  it('keeps an idle employee visible as zeros with no average, never NaN', async () => {
    const p = await svc.monthly(gymId, actor, { months: 6 });
    const b = rowFor(p, 'Bassem Idle')!;
    expect(b.totals.net).toBe('0.00');
    expect(b.bestMonth).toBeNull();
    expect(b.averageNet).toBeNull();
  });

  it('keeps a deactivated employee who moved money (her money must not vanish)', async () => {
    const p = await svc.monthly(gymId, actor, { months: 6 });
    const nour = rowFor(p, 'Nour Gone');
    expect(nour).toBeDefined();
    expect(nour!.active).toBe(false);
    expect(nour!.totals.net).toBe('120.00');
  });

  it('attributes only an EXACT name — a shared prefix is not a match', async () => {
    const p = await svc.monthly(gymId, actor, { months: 6 });
    const farouk = rowFor(p, 'Hany Farouk')!;
    const fouad = rowFor(p, 'Hany Fouad')!;
    expect(farouk.totals.posSold).toBe('90.00');   // the sale, by exact name
    expect(fouad.totals.posSold).toBe('0.00');     // never borrowed by a prefix
  });

  it('reports POS it cannot attribute as its own amount, never spread across people', async () => {
    const p = await svc.monthly(gymId, actor, { months: 6 });
    const m = p.posNotAttributable.find((x) => x.month === M_KEY)!;
    const pp = p.posNotAttributable.find((x) => x.month === P_KEY)!;
    // 40 with no name + 80 under the shared name "Same Name". The 999 (status
    // VOIDED), the 777 (voidedAt only) and the 333 (status VOIDED, no timestamp)
    // are all excluded outright, not counted here.
    expect(m.amount).toBe('120.00');
    expect(pp.amount).toBe('0.00');
    // neither Sami row owns the 80
    expect(rowFor(p, 'Same Name')!.totals.posSold).toBe('0.00');
  });

  it('gives money with no staff row its own row instead of dropping it', async () => {
    const p = await svc.monthly(gymId, actor, { months: 6 });
    const orphan = p.rows.find((r) => r.unattributed);
    expect(orphan).toBeDefined();
    expect(orphan!.totals.net).toBe('-15.00');
    expect(orphan!.name).toBe('');
  });

  it('reconciles with independent SQL — every row, every month', async () => {
    const p = await svc.monthly(gymId, actor, { months: 6 });
    // independent: one query, no service helpers
    const rows = await h.prisma.$queryRaw<Array<{ month: string; net: string }>>`
      SELECT to_char((x."createdAt" AT TIME ZONE 'UTC') AT TIME ZONE 'Africa/Cairo', 'YYYY-MM') AS month,
             SUM(x.amount)::text AS net
        FROM (
          SELECT "createdAt", amount FROM "Transaction"
           WHERE "gymId" = ${gymId} AND type = 'INCOME'
             AND category IN ('membership_create','membership_renewal')
          UNION ALL
          SELECT "createdAt", total AS amount FROM "Sale"
           WHERE "gymId" = ${gymId} AND "voidedAt" IS NULL AND upper(status) NOT IN ('VOID','VOIDED')
          UNION ALL
          SELECT "createdAt", -amount FROM "Refund"
           WHERE "gymId" = ${gymId} AND status = 'COMPLETED'
        ) x
       GROUP BY 1`;
    const sqlTotal = (k: string) => Number(rows.find((r) => r.month === k)?.net ?? 0).toFixed(2);

    for (const key of [P_KEY, M_KEY]) {
      const apiRows = p.rows.reduce((a, r) => a + Number(r.months.find((c) => c.month === key)!.net), 0);
      const unattributed = Number(p.posNotAttributable.find((x) => x.month === key)!.amount);
      // rows + the not-attributable line = every piastre in the gym, from SQL
      expect((apiRows + unattributed).toFixed(2)).toBe(sqlTotal(key));
      // the totals row is the sum of the staff rows: the not-attributable money is
      // shown beside it, not silently folded in
      expect(p.totalsPerMonth.find((t) => t.month === key)!.net).toBe(apiRows.toFixed(2));
    }
  });

  it('subtracts a refund in the month it happens, not the month of the sale', async () => {
    const p = await svc.monthly(gymId, actor, { months: 6 });
    const amal = rowFor(p, 'Amal Hany')!;
    expect(amal.months.find((c) => c.month === P_KEY)!.refunds).toBe('0.00');
    expect(amal.months.find((c) => c.month === M_KEY)!.refunds).toBe('500.00');
  });

  it('splits the Cairo month boundary at midnight, not at UTC midnight', async () => {
    // one sale one second before Cairo midnight, one one second after
    const beforeMidnight = new Date(M_START.getTime() - 1000);
    const afterMidnight = new Date(M_START.getTime() + 1000);
    // sanity: the two instants really are in different Cairo months
    expect(monthKeyAt(beforeMidnight)).toBe(P_KEY);
    expect(monthKeyAt(afterMidnight)).toBe(M_KEY);

    const mk = async (no: string, when: Date) => h.prisma.sale.create({
      data: {
        gymId, branchId, invoiceNo: `B${RUN}-${no}`, subtotal: 1, total: 1, discount: 0,
        userName: 'Edge Midnight', paymentMethod: 'CASH', method: 'CASH', status: 'COMPLETED',
        paymentStatus: 'PAID', createdAt: when,
      },
    });
    await mk('b', beforeMidnight);
    await mk('a', afterMidnight);

    const p = await svc.monthly(gymId, actor, { months: 6 });
    const edge = rowFor(p, 'Edge Midnight')!;
    expect(edge.months.find((c) => c.month === P_KEY)!.posSold).toBe('1.00');
    expect(edge.months.find((c) => c.month === M_KEY)!.posSold).toBe('1.00');
    expect(edge.totals.net).toBe('2.00');
  });

  it('gives another gym nothing — not a row, not a total, not a CSV line', async () => {
    // The strongest test here is the one that could have failed: a SECOND real gym
    // with its own real sale, called through the real HTTP route with its own
    // owner's session. It must see its own money and NONE of gym A's staff.
    const b = h.gymB;
    await h.prisma.transaction.create({
      data: { gymId: b.gymId, type: 'INCOME', category: 'membership_create', amount: 4321,
        description: `gym B ${RUN}`, branchId: b.branchId, createdBy: b.owner.id, createdAt: inM(4) },
    });
    const session = await h.agent(b.owner.email);
    const res = await session.get('/team/performance/monthly?months=6').expect(200);
    const names = res.body.rows.map((r: any) => r.name).filter(Boolean);
    // gym B sees its own owner (4321) and none of gym A's people
    for (const leaked of ['Amal Hany', 'Bassem Idle', 'Nour Gone', 'Same Name', 'Hany Farouk']) {
      expect(names).not.toContain(leaked);
    }
    const allNet = res.body.rows.reduce(
      (a: number, r: any) => a + r.months.reduce((x: number, c: any) => x + Number(c.net), 0), 0);
    expect(allNet).toBe(4321);

    // and the export is scoped the same way
    const csv = await session.get('/team/performance/monthly?months=6&format=csv').expect(200);
    expect(csv.text).toContain('4321.00');
    expect(csv.text).not.toContain('Amal Hany');
    expect(csv.text).not.toContain('1580.00');
  });

  it('refuses the route and the export to a role without team.performance.view', async () => {
    // A coach may read their own numbers through the existing endpoint; the whole
    // gym's money is a different permission, and the CSV must not be a way around it.
    const coach = await h.agent(h.gymA.coach.email);
    await coach.get('/team/performance/monthly?months=6').expect(403);
    await coach.get('/team/performance/monthly?months=6&format=csv').expect(403);
  });

  it('refuses a month count other than 6 or 12 with a machine code', async () => {
    await expect(svc.monthly(gymId, actor, { months: 5 })).rejects.toMatchObject({
      response: { code: 'INVALID_MONTHS' },
    });
  });

  it('exports exactly the matrix it shows, with a TOTAL row', async () => {
    const p = await svc.monthly(gymId, actor, { months: 6 });
    const csv = svc.csvOf(p);
    const lines = csv.split('\r\n');
    expect(lines[0].startsWith('staff,role,branch,')).toBe(true);
    expect(lines[0]).toContain('total collected');
    // one line per row + header + TOTAL
    expect(lines.length).toBe(p.rows.length + 2);
    expect(lines[lines.length - 1].startsWith('TOTAL,')).toBe(true);
    // the orphan is labelled, not blank
    expect(lines.some((l) => l.startsWith('UNATTRIBUTED,'))).toBe(true);
    // and every staff row carries its own total
    const amalLine = lines.find((l) => l.startsWith('Amal Hany,'))!;
    expect(amalLine).toContain('1050.00');
  });
});
