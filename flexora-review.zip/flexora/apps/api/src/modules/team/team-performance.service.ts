/**
 * FLEXORA Gym OS — FEATURE B: team performance.
 *
 * ONE service, one definition of every number, used by the page, the detail
 * drawer and the CSV. The rules are the owner's answers Q1–Q4; where a rule had
 * to be interpreted, the interpretation is written next to the code and in
 * 03-DECISIONS.md, and the UI repeats it in words.
 *
 * Tenant safety: every query takes `gymId` from the session (never from the
 * request body) and runs inside `prisma.withTenant`, so FORCE RLS is set for the
 * statement. Branch safety: a branch-restricted caller is pinned to their own
 * branch by the TenantGuard; `branchId` from the query string is validated to
 * belong to this gym and can never widen a restricted caller's view.
 *
 * Money: summed in the DATABASE (groupBy / GROUP BY), never by loading rows and
 * adding floats. Every money value leaves this service as a 2-decimal STRING
 * produced from a Prisma.Decimal.
 */
import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';
import {
  DEFAULT_GYM_TZ,
  ResolvedRange,
  addDays,
  buildRange,
  calendarDateIn,
  endOfMonth,
  formatYmd,
  isValidMonthKey,
  monthKey,
  parseYmd,
  resolveGymTimeZone,
  startOfMonth,
} from '../../common/time/gym-time';
import {
  MEMBERSHIP_CATEGORIES,
  TARGET_KINDS,
  TargetKind,
  attributeByExactName,
  decimalSum,
  isLowSample,
  money,
  normaliseName,
  ratioPct,
  targetProgress,
  daysLeftInPeriod,
} from './team-metrics';
import {
  TEAM_EXPORT_MAX_ROWS,
  TEAM_MAX_RANGE_DAYS,
  TeamPerformanceQueryDto,
  TeamRangeDto,
  TeamTargetQueryDto,
  UpsertTeamTargetsDto,
} from './dto/team-performance.dto';

export interface Actor {
  id: string;
  role: string;
  gymId: string;
  branchId?: string | null;
  /** from TenantGuard: false = pinned to filterBranchId */
  unrestrictedBranch?: boolean;
  filterBranchId?: string | null;
}

export interface StaffRow {
  userId: string;
  name: string;
  role: string;
  active: boolean;
  branchId: string | null;
  branchName: string | null;
  // sales / reception
  newSubscriptions: number;
  renewals: number;
  membershipGross: string;
  posGross: string;
  refunds: string;
  net: string;
  average: string;
  newSubsTarget: { target: string; progressPct: number | null; remaining: string; daysLeft: number } | null;
  salesTarget: { target: string; progressPct: number | null; remaining: string; daysLeft: number } | null;
  // coaches
  sessionsHeld: number;
  membersAttended: number;
  booked: number;
  attendanceRate: number | null;
  attendanceLowSample: boolean;
  attendanceTarget: { target: string; progressPct: number | null; remaining: string; daysLeft: number } | null;
  rank: number | null;
  rankMetric: string | null;
}

interface MoneyBucket {
  membershipGross: Prisma.Decimal;
  membershipCount: number;
  newCount: number;
  renewalCount: number;
  posGross: Prisma.Decimal;
  posCount: number;
  refunds: Prisma.Decimal;
  refundCount: number;
}

const zeroBucket = (): MoneyBucket => ({
  membershipGross: new Prisma.Decimal(0),
  membershipCount: 0,
  newCount: 0,
  renewalCount: 0,
  posGross: new Prisma.Decimal(0),
  posCount: 0,
  refunds: new Prisma.Decimal(0),
  refundCount: 0,
});

@Injectable()
export class TeamPerformanceService {
  constructor(private readonly prisma: PrismaService) {}

  // ── range / timezone ────────────────────────────────────────────────────
  async gymTimeZone(gymId: string): Promise<string> {
    const row = await this.prisma.gymSettings.findFirst({ where: { gymId, key: 'timezone' }, select: { value: true } });
    return resolveGymTimeZone(row?.value ?? DEFAULT_GYM_TZ);
  }

  private resolveRange(dto: TeamRangeDto, tz: string): ResolvedRange {
    const today = calendarDateIn(new Date(), tz);
    const preset = dto.period ?? (dto.from || dto.to ? 'custom' : 'month');

    let from = dto.from ? parseYmd(dto.from) : null;
    let to = dto.to ? parseYmd(dto.to) : null;
    if (dto.from && !from) throw new BadRequestException({ code: 'INVALID_DATE', message: 'from is not a real date' });
    if (dto.to && !to) throw new BadRequestException({ code: 'INVALID_DATE', message: 'to is not a real date' });

    if (preset !== 'custom') {
      // A preset ignores from/to on purpose: the client's job is to send ONE of
      // the two forms, and a preset must mean what it says.
      from = null;
      to = null;
      if (preset === 'today') {
        from = today;
        to = today;
      } else if (preset === 'week') {
        // Monday-first week, the Egyptian business convention.
        const dow = new Date(Date.UTC(today.year, today.month - 1, today.day)).getUTCDay(); // 0=Sun
        const back = (dow + 6) % 7;
        from = addDays(today, -back);
        to = today;
      } else if (preset === 'month') {
        from = startOfMonth(today);
        to = today;
      }
    } else {
      if (from && to) {
        // validated below
      } else if (!from && !to) {
        // custom with nothing at all is the default month, not an error
        from = startOfMonth(today);
        to = today;
      } else {
        throw new BadRequestException({ code: 'RANGE_INCOMPLETE', message: 'custom range needs both from and to' });
      }
    }

    const range = buildRange(from, to, tz, 30);
    if (range.days < 1) throw new BadRequestException({ code: 'RANGE_INVERTED', message: 'to is before from' });
    if (range.days > TEAM_MAX_RANGE_DAYS) {
      throw new BadRequestException({
        code: 'RANGE_TOO_LARGE',
        message: `range is ${range.days} days; the maximum is ${TEAM_MAX_RANGE_DAYS}`,
        limit: TEAM_MAX_RANGE_DAYS,
        current: range.days,
      });
    }
    return range;
  }

  private async assertBranch(gymId: string, branchId: string | null | undefined, actor: Actor): Promise<string | null> {
    if (!branchId) {
      return actor.unrestrictedBranch === false ? actor.filterBranchId ?? null : null;
    }
    if (actor.unrestrictedBranch === false && actor.filterBranchId && actor.filterBranchId !== branchId) {
      // A branch-pinned caller cannot ask for another branch. 403, not 400:
      // the request is understood, it is not allowed.
      throw new BadRequestException({ code: 'BRANCH_NOT_ALLOWED', message: 'branch is outside your scope' });
    }
    const branch = await this.prisma.branch.findFirst({ where: { id: branchId, gymId }, select: { id: true } });
    if (!branch) throw new BadRequestException({ code: 'BRANCH_NOT_FOUND', message: 'unknown branch for this gym' });
    return branchId;
  }

  // ── money + attendance aggregation (database-side) ───────────────────────
  private async moneyBuckets(
    client: Prisma.TransactionClient,
    gymId: string,
    range: { gte: Date; lt: Date },
    branchId: string | null,
  ): Promise<{ byUser: Map<string, MoneyBucket>; unattributed: MoneyBucket; byName: Map<string, MoneyBucket> }> {
    const byUser = new Map<string, MoneyBucket>();
    const bump = (id: string | null): MoneyBucket => {
      const key = id ?? '__none__';
      let b = byUser.get(key);
      if (!b) byUser.set(key, (b = zeroBucket()));
      return b;
    };

    // MEMBERSHIP — Transaction ledger, attributed by createdBy (a real User.id).
    const txWhere: Prisma.TransactionWhereInput = {
      gymId,
      type: 'INCOME',
      category: { in: [...MEMBERSHIP_CATEGORIES] },
      createdAt: { gte: range.gte, lt: range.lt },
    };
    if (branchId) txWhere.branchId = branchId;
    const txGroups = await client.transaction.groupBy({
      by: ['createdBy', 'category'],
      where: txWhere,
      _sum: { amount: true },
      _count: { _all: true },
    });
    for (const g of txGroups) {
      const b = bump(g.createdBy ?? null);
      const sum = g._sum.amount ?? new Prisma.Decimal(0);
      b.membershipGross = b.membershipGross.plus(sum);
      b.membershipCount += g._count._all;
      if (g.category === 'membership_create') b.newCount += g._count._all;
      if (g.category === 'membership_renewal') b.renewalCount += g._count._all;
    }

    // POS — no user id exists on a Sale, only the display name. Aggregated per
    // normalised name in SQL, attributed in JS by EXACT match (Q2).
    const posWhere: Prisma.Sql[] = [
      Prisma.sql`"gymId" = ${gymId}`,
      Prisma.sql`"createdAt" >= ${range.gte}`,
      Prisma.sql`"createdAt" < ${range.lt}`,
      Prisma.sql`"voidedAt" IS NULL`,
      Prisma.sql`UPPER(status) NOT IN ('VOID', 'VOIDED')`,
    ];
    if (branchId) posWhere.push(Prisma.sql`"branchId" = ${branchId}`);
    const posRows = await client.$queryRaw<Array<{ n: string | null; c: bigint; gross: Prisma.Decimal }>>(
      Prisma.sql`
        SELECT lower(btrim(COALESCE("userName", ''))) AS n,
               count(*)::bigint AS c,
               COALESCE(sum(total), 0) AS gross
          FROM "Sale"
         WHERE ${Prisma.join(posWhere, ' AND ')}
         GROUP BY 1`,
    );

    const staffNames = await client.user.findMany({ where: { gymId }, select: { id: true, name: true } });
    const nameToId = new Map<string, string>();
    const dupes = new Set<string>();
    for (const s of staffNames) {
      const key = normaliseName(s.name);
      if (!key) continue;
      if (nameToId.has(key)) dupes.add(key);
      else nameToId.set(key, s.id);
    }

    let unattributedPos = zeroBucket();
    const byName = new Map<string, MoneyBucket>();
    for (const row of posRows) {
      const key = normaliseName(row.n ?? '');
      const gross = new Prisma.Decimal(row.gross ?? 0);
      const count = Number(row.c);
      // empty name, unknown name, or a name shared by two staff members: all
      // three are "not attributable" — the report never guesses.
      const staffId = key && !dupes.has(key) ? nameToId.get(key) : undefined;
      if (!staffId) {
        unattributedPos.posGross = unattributedPos.posGross.plus(gross);
        unattributedPos.posCount += count;
        continue;
      }
      const b = bump(staffId);
      b.posGross = b.posGross.plus(gross);
      b.posCount += count;
      const bn = byName.get(staffId) ?? zeroBucket();
      bn.posGross = bn.posGross.plus(gross);
      bn.posCount += count;
      byName.set(staffId, bn);
    }

    // REFUNDS — the period they HAPPEN in, from the staff id on the refund row.
    // A refund belonging to a VOIDED sale is the reversal of a sale we do not
    // count at all, so it is excluded here too (otherwise one void would both
    // disappear from gross and subtract again).
    const refundWhere: Prisma.Sql[] = [
      Prisma.sql`r."gymId" = ${gymId}`,
      Prisma.sql`r."createdAt" >= ${range.gte}`,
      Prisma.sql`r."createdAt" < ${range.lt}`,
      Prisma.sql`r.status = 'COMPLETED'`,
      Prisma.sql`s."voidedAt" IS NULL`,
    ];
    if (branchId) refundWhere.push(Prisma.sql`s."branchId" = ${branchId}`);
    const refundRows = await client.$queryRaw<Array<{ actor: string | null; c: bigint; amount: Prisma.Decimal }>>(
      Prisma.sql`
        SELECT COALESCE(r."createdBy", r."staffId") AS actor,
               count(*)::bigint AS c,
               COALESCE(sum(r.amount), 0) AS amount
          FROM "Refund" r
          JOIN "Sale" s ON s.id = r."saleId" AND s."gymId" = r."gymId"
         WHERE ${Prisma.join(refundWhere, ' AND ')}
         GROUP BY 1`,
    );
    let unattributedRefunds = zeroBucket();
    for (const row of refundRows) {
      const amount = new Prisma.Decimal(row.amount ?? 0);
      const count = Number(row.c);
      if (!row.actor) {
        unattributedRefunds.refunds = unattributedRefunds.refunds.plus(amount);
        unattributedRefunds.refundCount += count;
        continue;
      }
      const b = bump(row.actor);
      b.refunds = b.refunds.plus(amount);
      b.refundCount += count;
    }

    const unattributed = zeroBucket();
    unattributed.posGross = unattributedPos.posGross;
    unattributed.posCount = unattributedPos.posCount;
    unattributed.refunds = unattributedRefunds.refunds;
    unattributed.refundCount = unattributedRefunds.refundCount;
    const none = byUser.get('__none__');
    if (none) {
      unattributed.membershipGross = none.membershipGross;
      unattributed.membershipCount = none.membershipCount;
      unattributed.newCount = none.newCount;
      unattributed.renewalCount = none.renewalCount;
      byUser.delete('__none__');
    }
    return { byUser, unattributed, byName };
  }

  private async classBuckets(client: Prisma.TransactionClient, gymId: string, range: { gte: Date; lt: Date }, branchId: string | null) {
    const where: Prisma.Sql[] = [
      Prisma.sql`cs."gymId" = ${gymId}`,
      Prisma.sql`cs.status = 'COMPLETED'`,
      Prisma.sql`cs."startsAt" >= ${range.gte}`,
      Prisma.sql`cs."startsAt" < ${range.lt}`,
    ];
    if (branchId) where.push(Prisma.sql`cs."branchId" = ${branchId}`);
    // One indexed GROUP BY. Bookings are counted with FILTER so a session with
    // zero bookings still appears (and the coach gets "—", not 0 %).
    const rows = await client.$queryRaw<
      Array<{ coach: string | null; template: string; templateAr: string | null; sessions: bigint; booked: bigint; attended: bigint }>
    >(Prisma.sql`
      SELECT cs."coachId" AS coach,
             COALESCE(ct.name, '(deleted class type)') AS template,
             ct."nameAr" AS "templateAr",
             count(DISTINCT cs.id)::bigint AS sessions,
             count(b.id) FILTER (WHERE b.status <> 'CANCELLED')::bigint AS booked,
             count(b.id) FILTER (WHERE b.status = 'ATTENDED')::bigint AS attended
        FROM "ClassSession" cs
        LEFT JOIN "ClassTemplate" ct ON ct.id = cs."templateId"
        LEFT JOIN "ClassBooking" b ON b."sessionId" = cs.id AND b."gymId" = cs."gymId"
       WHERE ${Prisma.join(where, ' AND ')}
       GROUP BY cs."coachId", ct.name, ct."nameAr"`);

    const byCoach = new Map<string, { sessions: number; booked: number; attended: number; types: Map<string, { nameAr: string | null; sessions: number; booked: number; attended: number }> }>();
    let unattributedSessions = 0;
    for (const r of rows) {
      const sessions = Number(r.sessions);
      if (!r.coach) {
        unattributedSessions += sessions;
        continue;
      }
      const c = byCoach.get(r.coach) ?? { sessions: 0, booked: 0, attended: 0, types: new Map() };
      c.sessions += sessions;
      c.booked += Number(r.booked);
      c.attended += Number(r.attended);
      const t = c.types.get(r.template) ?? { nameAr: r.templateAr, sessions: 0, booked: 0, attended: 0 };
      t.sessions += sessions;
      t.booked += Number(r.booked);
      t.attended += Number(r.attended);
      c.types.set(r.template, t);
      byCoach.set(r.coach, c);
    }
    return { byCoach, unattributedSessions };
  }

  private async targetsFor(client: Prisma.TransactionClient, gymId: string, period: string) {
    const rows = await client.staffTarget.findMany({
      where: { gymId, period },
      select: { userId: true, kind: true, targetValue: true, updatedAt: true },
    });
    const map = new Map<string, Map<TargetKind, Prisma.Decimal>>();
    for (const r of rows) {
      if (!map.has(r.userId)) map.set(r.userId, new Map());
      map.get(r.userId)!.set(r.kind as TargetKind, r.targetValue);
    }
    return map;
  }

  // ── LIST ────────────────────────────────────────────────────────────────
  async list(gymId: string, dto: TeamPerformanceQueryDto, actor: Actor) {
    const tz = await this.gymTimeZone(gymId);
    const range = this.resolveRange(dto, tz);
    const branchId = await this.assertBranch(gymId, dto.branchId, actor);
    const page = dto.page ?? 1;
    const pageSize = dto.pageSize ?? 25;

    const staffWhere: Prisma.UserWhereInput = { gymId };
    if (branchId) staffWhere.branchId = branchId;
    if (!dto.includeInactive) staffWhere.active = true;
    if (dto.q) staffWhere.name = { contains: dto.q.trim(), mode: 'insensitive' };

    // EVERY read runs inside withTenant: the api connects as flexora_app, which
    // is NOSUPERUSER NOBYPASSRLS, so a $queryRaw WITHOUT `set_config('app.gym_id')`
    // returns ZERO rows and the report would silently show 0.00 everywhere. The
    // live smoke caught exactly that (the jest process connects as the owner and
    // could not see it) — see 05-FEATURE-B-EVIDENCE.md.
    return this.prisma.withTenant(gymId, async (tx) => {
    const [staff, total] = await Promise.all([
      tx.user.findMany({
        where: staffWhere,
        select: { id: true, name: true, role: true, active: true, branchId: true, branch: { select: { name: true } } },
        orderBy: [{ name: 'asc' }],
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
      tx.user.count({ where: staffWhere }),
    ]);

    const [{ byUser, unattributed }, classes, targets, tzNow] = await Promise.all([
      this.moneyBuckets(tx, gymId, range, branchId),
      this.classBuckets(tx, gymId, range, branchId),
      this.targetsFor(tx, gymId, monthKey(calendarDateIn(new Date(), tz))),
      Promise.resolve(calendarDateIn(new Date(), tz)),
    ]);

    const periodEnd = formatYmd(endOfMonth(tzNow));
    const todayYmd = formatYmd(tzNow);
    const daysLeft = daysLeftInPeriod(todayYmd, periodEnd);

    const rows: StaffRow[] = staff.map((s) => {
      const b = byUser.get(s.id) ?? zeroBucket();
      const c = classes.byCoach.get(s.id);
      const net = b.membershipGross.plus(b.posGross).minus(b.refunds);
      const count = b.membershipCount + b.posCount;
      const t = targets.get(s.id);
      const rate = c ? ratioPct(c.attended, c.booked) : null;
      return {
        userId: s.id,
        name: s.name,
        role: s.role,
        active: s.active,
        branchId: s.branchId,
        branchName: s.branch?.name ?? null,
        newSubscriptions: b.newCount,
        renewals: b.renewalCount,
        membershipGross: money(b.membershipGross),
        posGross: money(b.posGross),
        refunds: money(b.refunds),
        net: money(net),
        // average = net ÷ number of attributed money rows; 0 rows → "0.00"
        average: money(count > 0 ? net.div(count) : new Prisma.Decimal(0)),
        newSubsTarget: this.progressOf('NEW_SUBSCRIPTIONS', b.newCount, t?.get('NEW_SUBSCRIPTIONS') ?? null, daysLeft),
        salesTarget: this.progressOf('SALES_VALUE', Number(net), t?.get('SALES_VALUE') ?? null, daysLeft),
        sessionsHeld: c?.sessions ?? 0,
        membersAttended: c?.attended ?? 0,
        booked: c?.booked ?? 0,
        attendanceRate: rate,
        attendanceLowSample: isLowSample(c?.booked ?? 0),
        attendanceTarget: this.progressOf('ATTENDANCE_RATE', rate, t?.get('ATTENDANCE_RATE') ?? null, daysLeft),
        rank: null,
        rankMetric: null,
      };
    });

    // Ranking: by target progress when targets exist, else by net / attendance.
    // Deterministic tie-break on name so two equal rows never swap on refresh.
    this.rank(rows, dto.sort ?? 'net');

    const totals = {
      staffCount: total,
      newSubscriptions: rows.reduce((n, r) => n + r.newSubscriptions, 0),
      renewals: rows.reduce((n, r) => n + r.renewals, 0),
      net: money(rows.reduce((acc, r) => acc.plus(r.net), new Prisma.Decimal(0))),
      sessionsHeld: rows.reduce((n, r) => n + r.sessionsHeld, 0),
      membersAttended: rows.reduce((n, r) => n + r.membersAttended, 0),
    };

    return {
      items: rows,
      total,
      page,
      pageSize,
      totalPages: Math.max(1, Math.ceil(total / pageSize)),
      range: { from: range.from, to: range.to, tz: range.tz, days: range.days },
      period: monthKey(tzNow),
      daysLeft,
      totals,
      notAttributable: {
        membershipGross: money(unattributed.membershipGross),
        membershipCount: unattributed.membershipCount,
        posGross: money(unattributed.posGross),
        posCount: unattributed.posCount,
        refunds: money(unattributed.refunds),
        refundCount: unattributed.refundCount,
        sessionsWithoutCoach: classes.unattributedSessions,
      },
      definitions: this.definitions(),
    };
    });
  }

  private progressOf(kind: TargetKind, value: number | null, target: Prisma.Decimal | null, daysLeft: number) {
    if (target === null) return null;
    const t = Number(target);
    const v = value ?? 0;
    return {
      target: money(target),
      progressPct: targetProgress(kind, v, t),
      remaining:
        kind === 'ATTENDANCE_RATE'
          ? money(Math.max(0, t - (value ?? 0)))
          : money(new Prisma.Decimal(Math.max(0, t - v))),
      daysLeft,
    };
  }

  private rank(rows: StaffRow[], sort: string) {
    const score = (r: StaffRow): number => {
      if (sort === 'attendance') return r.attendanceRate ?? -1;
      if (sort === 'newSubs') return r.newSubscriptions;
      if (sort === 'name') return 0;
      // default: progress towards the sales target when there is one, else net
      return r.salesTarget?.progressPct ?? Number(r.net);
    };
    const ranked = [...rows].sort((a, b) => score(b) - score(a) || a.name.localeCompare(b.name));
    ranked.forEach((r, i) => {
      r.rank = i + 1;
      r.rankMetric = sort === 'name' ? null : sort;
    });
  }

  private definitions() {
    return {
      salesValue:
        'membership (create + renewal) + POS − refunds; refunds are counted in the month they happen, from the staff member on the refund row',
      newVsRenewal: 'a new subscription is a first activation; a renewal is any later payment for the same member',
      posAttribution: 'POS is matched by the exact staff name on the sale (trim + case only); 0 or 2+ matches are reported as not attributable',
      attendanceRate: 'attended ÷ non-cancelled bookings on COMPLETED sessions in the range — "booked and marked attended"',
      lowSample: 'fewer than 5 bookings is a low sample: the rate is shown, never hidden',
      netCanBeNegative: 'net is never clamped; a month with more refunds than sales is negative on purpose',
    };
  }

  // ── DETAIL ──────────────────────────────────────────────────────────────
  async detail(gymId: string, userId: string, dto: TeamRangeDto, actor: Actor) {
    const tz = await this.gymTimeZone(gymId);
    const range = this.resolveRange(dto, tz);
    const branchId = await this.assertBranch(gymId, dto.branchId, actor);
    return this.prisma.withTenant(gymId, async (tx) => {
    const staff = await tx.user.findFirst({
      where: { id: userId, gymId },
      select: { id: true, name: true, role: true, active: true, branchId: true, branch: { select: { name: true } } },
    });
    if (!staff) throw new NotFoundException({ code: 'STAFF_NOT_FOUND', message: 'staff member not found' });

    const [{ byUser, byName }, classes] = await Promise.all([
      this.moneyBuckets(tx, gymId, range, branchId),
      this.classBuckets(tx, gymId, range, branchId),
    ]);
    const b = byUser.get(staff.id) ?? zeroBucket();
    const c = classes.byCoach.get(staff.id);

    // daily trend, computed in the gym's timezone by the DATABASE so DST months
    // cannot shift a point into the wrong day
    const trendRows = await tx.$queryRaw<Array<{ d: string; net: Prisma.Decimal; subs: bigint }>>(Prisma.sql`
      WITH days AS (
        SELECT to_char((t."createdAt" AT TIME ZONE ${tz})::date, 'YYYY-MM-DD') AS d,
               CASE WHEN t.type = 'INCOME' AND t.category IN ('membership_create','membership_renewal') THEN t.amount ELSE 0 END AS amt,
               CASE WHEN t.type = 'INCOME' AND t.category = 'membership_create' THEN 1 ELSE 0 END AS subs
          FROM "Transaction" t
         WHERE t."gymId" = ${gymId}
           AND t."createdBy" = ${staff.id}
           AND t."createdAt" >= ${range.gte} AND t."createdAt" < ${range.lt}
      )
      SELECT d, COALESCE(sum(amt), 0) AS net, COALESCE(sum(subs), 0)::bigint AS subs
        FROM days GROUP BY d ORDER BY d`);

    return {
      staff: {
        userId: staff.id,
        name: staff.name,
        role: staff.role,
        active: staff.active,
        branchName: staff.branch?.name ?? null,
      },
      range: { from: range.from, to: range.to, tz: range.tz, days: range.days },
      sales: {
        newSubscriptions: b.newCount,
        renewals: b.renewalCount,
        membershipGross: money(b.membershipGross),
        posGross: money(b.posGross),
        refunds: money(b.refunds),
        net: money(b.membershipGross.plus(b.posGross).minus(b.refunds)),
        posSalesCount: byName.get(staff.id)?.posCount ?? 0,
        membershipCount: b.membershipCount,
        refundCount: b.refundCount,
      },
      attendance: c
        ? {
            sessionsHeld: c.sessions,
            booked: c.booked,
            membersAttended: c.attended,
            rate: ratioPct(c.attended, c.booked),
            lowSample: isLowSample(c.booked),
            byClassType: [...c.types.entries()]
              .map(([name, t]) => ({
                name,
                nameAr: t.nameAr,
                sessions: t.sessions,
                booked: t.booked,
                attended: t.attended,
                rate: ratioPct(t.attended, t.booked),
                lowSample: isLowSample(t.booked),
              }))
              .sort((x, y) => y.attended - x.attended || x.name.localeCompare(y.name)),
          }
        : null,
      trend: trendRows.map((r) => ({ day: r.d, net: money(r.net), newSubscriptions: Number(r.subs) })),
      definitions: this.definitions(),
    };
    });
  }

  // ── OWN (a staff member reading their own numbers) ───────────────────────
  async me(gymId: string, actor: Actor, dto: TeamRangeDto) {
    const out = await this.detail(gymId, actor.id, dto, { ...actor, unrestrictedBranch: true });
    // A staff member sees their own numbers, never the owners' target list.
    return { ...out, targets: undefined };
  }

  // ── TARGETS ─────────────────────────────────────────────────────────────
  async targets(gymId: string, dto: TeamTargetQueryDto, actor: Actor) {
    const tz = await this.gymTimeZone(gymId);
    const period = dto.period ?? monthKey(calendarDateIn(new Date(), tz));
    if (!isValidMonthKey(period)) throw new BadRequestException({ code: 'INVALID_PERIOD', message: 'period must be YYYY-MM' });
    const branchId = await this.assertBranch(gymId, dto.branchId, actor);
    const { rows, staff } = await this.prisma.withTenant(gymId, async (tx) => {
    const rows = await tx.staffTarget.findMany({
      where: { gymId, period, ...(branchId ? { user: undefined } : {}) },
      select: { userId: true, kind: true, targetValue: true, updatedAt: true, updatedBy: true },
      orderBy: [{ userId: 'asc' }, { kind: 'asc' }],
    });
    const staff = await tx.user.findMany({
      where: { gymId, ...(branchId ? { branchId } : {}) },
      select: { id: true, name: true, role: true },
    });
    return { rows, staff };
    });
    const names = new Map(staff.map((s) => [s.id, s]));
    return {
      period,
      tz,
      items: rows
        .filter((r) => names.has(r.userId))
        .map((r) => ({
          userId: r.userId,
          name: names.get(r.userId)!.name,
          role: names.get(r.userId)!.role,
          kind: r.kind,
          target: money(r.targetValue),
          updatedAt: r.updatedAt.toISOString(),
        })),
      kinds: TARGET_KINDS,
    };
  }

  /**
   * Idempotent, race-safe upsert: one statement per item inside ONE transaction,
   * `ON CONFLICT ("gymId","userId","period","kind") DO UPDATE`. Two concurrent
   * submissions of the same target therefore converge on one row and the last
   * writer wins — never a duplicate, never a lost row.
   *
   * The previous value is read inside the same transaction (FOR UPDATE via the
   * upsert's own row lock is not enough for the audit trail, so the read happens
   * first and the audit row records old → new). Each change writes one AuditLog
   * row in the existing tenant log — the owner asked for history without a new
   * history table.
   */
  async upsertTargets(gymId: string, actor: Actor, dto: UpsertTeamTargetsDto) {
    // Every user id must belong to THIS gym. The composite FK enforces it in the
    // database too, but failing here produces a clean 400 instead of a 500.
    const ids = [...new Set(dto.items.map((i) => i.userId))];
    const users = await this.prisma.user.findMany({ where: { gymId, id: { in: ids } }, select: { id: true, name: true } });
    const known = new Set(users.map((u) => u.id));
    const unknown = ids.filter((id) => !known.has(id));
    if (unknown.length) {
      throw new BadRequestException({ code: 'UNKNOWN_STAFF', message: 'a userId does not belong to this gym', count: unknown.length });
    }

    // The DB has the same CHECKs, but a constraint violation surfaces as a 500.
    // Validate first so the client gets the field-level 400 it can show.
    for (const item of dto.items) {
      if (item.kind === 'ATTENDANCE_RATE' && Number(item.targetValue) > 100) {
        throw new BadRequestException({
          code: 'TARGET_OUT_OF_RANGE',
          message: 'an attendance-rate target is a percentage and cannot exceed 100',
          field: 'targetValue',
          max: 100,
          current: Number(item.targetValue),
        });
      }
    }

    const results: Array<{ userId: string; period: string; kind: string; target: string; previous: string | null; created: boolean }> = [];

    await this.prisma.withTenant(gymId, async (tx) => {
      for (const item of dto.items) {
        const value = new Prisma.Decimal(item.targetValue);
        const previous = await tx.staffTarget.findFirst({
          where: { gymId, userId: item.userId, period: item.period, kind: item.kind },
          select: { targetValue: true },
        });
        const saved = await tx.$queryRaw<Array<{ id: string }>>(Prisma.sql`
          INSERT INTO "StaffTarget" ("id", "gymId", "userId", period, kind, "targetValue", "createdBy", "updatedBy", "createdAt", "updatedAt")
          VALUES (gen_random_uuid()::text, ${gymId}, ${item.userId}, ${item.period}, ${item.kind}, ${value}::numeric(14,2), ${actor.id}, ${actor.id}, now(), now())
          ON CONFLICT ("gymId", "userId", period, kind)
          DO UPDATE SET "targetValue" = EXCLUDED."targetValue", "updatedBy" = EXCLUDED."updatedBy", "updatedAt" = now()
          RETURNING "id"`);
        await tx.auditLog.create({
          data: {
            gymId,
            userId: actor.id,
            action: previous ? 'team.target.updated' : 'team.target.created',
            entity: 'StaffTarget',
            entityId: saved[0]?.id ?? null,
            metadata: {
              actorRole: actor.role,
              targetUserId: item.userId,
              period: item.period,
              kind: item.kind,
              previous: previous ? money(previous.targetValue) : null,
              next: money(value),
            },
          },
        });
        results.push({
          userId: item.userId,
          period: item.period,
          kind: item.kind,
          target: money(value),
          previous: previous ? money(previous.targetValue) : null,
          created: !previous,
        });
      }
    });
    return { updated: results.length, items: results };
  }

  // ── CSV ─────────────────────────────────────────────────────────────────
  /**
   * Built from `list()` so the file and the screen can never disagree.
   * Columns are an allowlist (no email, no phone, no member data). Values are
   * RFC-4180 quoted and formula-neutralised. Row cap: the caller passes the
   * same filters as the page, and we walk pages until TEAM_EXPORT_MAX_ROWS.
   */
  async listForExport(gymId: string, dto: TeamPerformanceQueryDto, actor: Actor) {
    const all: StaffRow[] = [];
    let page = 1;
    let meta: Awaited<ReturnType<TeamPerformanceService['list']>> | null = null;
    while (all.length < TEAM_EXPORT_MAX_ROWS) {
      const res = await this.list(gymId, { ...dto, page, pageSize: 100 }, actor);
      meta = meta ?? res;
      all.push(...res.items);
      if (page >= res.totalPages) break;
      page++;
    }
    return { rows: all.slice(0, TEAM_EXPORT_MAX_ROWS), meta: meta! };
  }
}
