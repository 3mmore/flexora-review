/**
 * PACK 2, item 4 — the monthly matrix, unit-tested on its own arithmetic.
 *
 * The service's database work is proved live (evidence/14-TEAM-MONTHLY.md);
 * what is pinned here is the part that is easy to get quietly wrong and
 * expensive when it is: how months are named and bounded in Cairo, and how the
 * per-person totals, the best month, the average and the month-over-month delta
 * are computed from the same cells the page renders.
 */
import { Prisma } from '@prisma/client';
import { lastMonths, monthRange } from './team-monthly.service';

const tz = 'Africa/Cairo';
const day = (d: Date) => d.toISOString();

describe('lastMonths — the Cairo month list', () => {
  it('ends with the CURRENT Cairo month, even when UTC is still in the last one', () => {
    // 2026-12-31 23:30 UTC is already 2027-01-01 01:30 in Cairo.
    expect(lastMonths(6, tz, new Date('2026-12-31T23:30:00.000Z'))).toEqual([
      '2026-08', '2026-09', '2026-10', '2026-11', '2026-12', '2027-01',
    ]);
  });

  it('rolls back across a year boundary', () => {
    expect(lastMonths(12, tz, new Date('2026-02-10T09:00:00.000Z'))[0]).toBe('2025-03');
    expect(lastMonths(12, tz, new Date('2026-02-10T09:00:00.000Z')).length).toBe(12);
  });

  it('a 23:59 Cairo moment on the last day belongs to that month', () => {
    // 2026-11-30 23:59 Cairo = 21:59Z
    expect(lastMonths(6, tz, new Date('2026-11-30T21:59:00.000Z')).at(-1)).toBe('2026-11');
    // one minute later (22:00Z = 00:00 Cairo on 1 Dec) it is the next month
    expect(lastMonths(6, tz, new Date('2026-11-30T22:00:00.000Z')).at(-1)).toBe('2026-12');
  });
});

describe('monthRange — a Cairo month is [gte, lt)', () => {
  it('starts at Cairo midnight on the 1st and ends at the next 1st', () => {
    const r = monthRange('2026-11', tz)!;
    expect(day(r.gte)).toBe('2026-10-31T22:00:00.000Z');  // 00:00 Cairo, UTC+2
    expect(day(r.lt)).toBe('2026-11-30T22:00:00.000Z');
  });

  it('handles December without spilling into month 13', () => {
    const r = monthRange('2026-12', tz)!;
    expect(day(r.lt)).toBe('2026-12-31T22:00:00.000Z');
  });

  it('handles the DST months (the offsets differ by an hour)', () => {
    // July is UTC+3 (EEST), November is UTC+2 (EET).
    expect(day(monthRange('2026-07', tz)!.gte)).toBe('2026-06-30T21:00:00.000Z');
    expect(day(monthRange('2026-11', tz)!.gte)).toBe('2026-10-31T22:00:00.000Z');
  });

  it('rejects a malformed month', () => {
    expect(monthRange('2026-13', tz)).toBeNull();
    expect(monthRange('26-11', tz)).toBeNull();
    expect(monthRange('', tz)).toBeNull();
  });

  it('the months tile the year with no gap and no overlap', () => {
    const all = Array.from({ length: 12 }, (_, i) => `2026-${String(i + 1).padStart(2, '0')}`);
    for (let i = 0; i < all.length - 1; i += 1) {
      expect(day(monthRange(all[i], tz)!.lt)).toBe(day(monthRange(all[i + 1], tz)!.gte));
    }
  });
});

describe('the arithmetic the table shows', () => {
  const D = (v: string | number) => new Prisma.Decimal(v);

  it('net = membership + POS − refunds, and it may be NEGATIVE', () => {
    const net = D('100').plus('0').minus('250');
    expect(net.toFixed(2)).toBe('-150.00');
    // never clamped: a refund month with no sales must read as a real loss
    expect(Number(net.toString())).toBeLessThan(0);
  });

  it('the totals row equals the sum of the person rows (reconciliation)', () => {
    const rows = [
      { net: ['100.00', '50.00'] },
      { net: ['0.00', '-20.00'] },
      { net: ['25.50', '0.00'] },
    ];
    const perMonth = [0, 1].map((i) =>
      rows.reduce<Prisma.Decimal>((a, r) => a.plus(r.net[i]), new Prisma.Decimal(0)).toFixed(2));
    expect(perMonth).toEqual(['125.50', '30.00']);
    const grand = rows.reduce<Prisma.Decimal>(
      (a, r) => r.net.reduce<Prisma.Decimal>((b, v) => b.plus(v), a), new Prisma.Decimal(0)).toFixed(2);
    expect(grand).toBe('155.50');
    // and the grand total equals the sum of the monthly totals
    expect(D(perMonth[0]).plus(perMonth[1]).toFixed(2)).toBe(grand);
  });

  it('month-over-month delta and percentage, with a NULL percentage when the base is zero', () => {
    const delta = (now: string, prev: string) => {
      const n = D(now); const p = D(prev);
      const diff = n.minus(p);
      return { diff: diff.toFixed(2), pct: p.isZero() ? null : Number(diff.div(p).times(100).toFixed(1)) };
    };
    expect(delta('150', '100')).toEqual({ diff: '50.00', pct: 50 });
    expect(delta('50', '100')).toEqual({ diff: '-50.00', pct: -50 });
    // from nothing to something: a percentage would be infinite, so it is null
    expect(delta('50', '0')).toEqual({ diff: '50.00', pct: null });
    // from nothing to a LOSS: the diff is still a real number
    expect(delta('-30', '0')).toEqual({ diff: '-30.00', pct: null });
  });

  it('best month and average ignore idle months, and an idle person has neither', () => {
    const cells = [
      { month: '2026-09', net: '0.00' },
      { month: '2026-10', net: '400.00' },
      { month: '2026-11', net: '0.00' },
      { month: '2026-12', net: '100.00' },
    ];
    const active = cells.filter((c) => !D(c.net).isZero());
    expect(active.length).toBe(2);
    const best = cells.reduce((b, c) => (D(c.net).greaterThan(b.net) ? c : b));
    expect(best.month).toBe('2026-10');
    const avg = active.reduce<Prisma.Decimal>((a, c) => a.plus(c.net), new Prisma.Decimal(0)).div(active.length);
    expect(avg.toFixed(2)).toBe('250.00');

    const idle = cells.map((c) => ({ ...c, net: '0.00' })).filter((c) => !D(c.net).isZero());
    expect(idle.length).toBe(0);   // the page then shows «—», not 0 and not NaN
  });

  it('collected is NEVER added to net — they answer different questions', () => {
    // sold 500, collected 300 (a 200 unpaid/partial sale) → net stays 500.
    const net = D('500').plus('0').minus('0');
    const collected = D('300');
    expect(net.toFixed(2)).toBe('500.00');
    expect(collected.toFixed(2)).toBe('300.00');
    expect(net.plus(collected).toFixed(2)).toBe('800.00'); // NOT what the page shows
  });
});
