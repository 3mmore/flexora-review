/**
 * FLEXORA Gym OS — DTOs for FEATURE B (team performance).
 *
 * Every value is bounded and allowlisted, because these routes read money and
 * attendance. `whitelist + forbidNonWhitelisted` is applied globally, so an
 * unknown parameter is a 400 rather than something silently ignored (the old
 * behaviour a reviewer flagged on the notification endpoints).
 */
import { Type } from 'class-transformer';
import {
  ArrayMaxSize,
  IsArray,
  IsBoolean,
  IsIn,
  IsInt,
  IsOptional,
  IsString,
  Matches,
  Max,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';
import { TARGET_KINDS, TargetKind } from '../team-metrics';

export const TEAM_PERIOD_PRESETS = ['today', 'week', 'month', 'custom'] as const;
export type TeamPeriodPreset = (typeof TEAM_PERIOD_PRESETS)[number];

export const TEAM_SORT_VALUES = ['name', 'net', 'newSubs', 'attendance'] as const;
export type TeamSort = (typeof TEAM_SORT_VALUES)[number];

/** A range wider than a year is not a team-performance question. */
export const TEAM_MAX_RANGE_DAYS = 366;
export const TEAM_MAX_PAGE_SIZE = 100;
export const TEAM_MAX_SEARCH = 100;
/** Export row cap — a gym with more staff than this needs a filter, not a file. */
export const TEAM_EXPORT_MAX_ROWS = 1000;
/** Targets submitted in one request. */
export const TEAM_MAX_TARGET_ITEMS = 200;

const YMD = /^\d{4}-\d{2}-\d{2}$/;
const MONTH = /^\d{4}-(0[1-9]|1[0-2])$/;
const ID = /^[A-Za-z0-9_-]{1,40}$/;

export class TeamRangeDto {
  @IsOptional() @IsIn(TEAM_PERIOD_PRESETS as unknown as string[])
  period?: TeamPeriodPreset;

  /** Gym-local calendar day, inclusive. Required shape; the service validates the calendar. */
  @IsOptional() @IsString() @Matches(YMD, { message: 'from must be YYYY-MM-DD' })
  from?: string;

  @IsOptional() @IsString() @Matches(YMD, { message: 'to must be YYYY-MM-DD' })
  to?: string;

  /** Branch filter. Must belong to the caller's gym — checked in the service. */
  @IsOptional() @IsString() @Matches(ID, { message: 'branchId is malformed' })
  branchId?: string;

  /** Name search for the staff list (never a member search). */
  @IsOptional() @IsString() @MaxLength(TEAM_MAX_SEARCH)
  q?: string;
}

export class TeamPerformanceQueryDto extends TeamRangeDto {
  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(100000)
  page?: number;

  @IsOptional() @Type(() => Number) @IsInt() @Min(1) @Max(TEAM_MAX_PAGE_SIZE)
  pageSize?: number;

  @IsOptional() @IsIn(TEAM_SORT_VALUES as unknown as string[])
  sort?: TeamSort;

  /** Include deactivated staff (they keep their history). Default false. */
  @IsOptional() @Type(() => Boolean) @IsBoolean()
  includeInactive?: boolean;
}

export class TeamTargetQueryDto {
  /** 'YYYY-MM' in the gym timezone. Defaults to the current month. */
  @IsOptional() @IsString() @Matches(MONTH, { message: 'period must be YYYY-MM' })
  period?: string;

  @IsOptional() @IsString() @Matches(ID, { message: 'branchId is malformed' })
  branchId?: string;
}

export class TeamTargetItemDto {
  @IsString() @Matches(ID, { message: 'userId is malformed' })
  userId!: string;

  @IsString() @Matches(MONTH, { message: 'period must be YYYY-MM' })
  period!: string;

  @IsIn(TARGET_KINDS as unknown as string[])
  kind!: TargetKind;

  /**
   * Decimal as a string so no float ever touches it. 2 decimal places max;
   * the DB has the same CHECKs (>= 0, ATTENDANCE_RATE <= 100), so a direct
   * writer cannot store what the API would refuse.
   */
  @IsString()
  @Matches(/^\d{1,12}(\.\d{1,2})?$/, { message: 'targetValue must be a non-negative decimal with at most 2 places' })
  targetValue!: string;
}

export class UpsertTeamTargetsDto {
  @IsArray() @ArrayMaxSize(TEAM_MAX_TARGET_ITEMS) @ValidateNested({ each: true }) @Type(() => TeamTargetItemDto)
  items!: TeamTargetItemDto[];
}
