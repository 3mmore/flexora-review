/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { InvitationsService } from './invitations.service';
import { InvitationsController } from './invitations.controller';
import { InvitationsCron } from './invitations.cron';
import { NotificationsModule } from '../notifications/notifications.module';

@Module({
  imports: [JwtModule.register({}), NotificationsModule],
  controllers: [InvitationsController],
  providers: [InvitationsService, InvitationsCron],
  exports: [InvitationsService],
})
export class InvitationsModule {}
