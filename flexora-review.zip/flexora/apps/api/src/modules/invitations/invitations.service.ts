/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import sanitizeHtml from 'sanitize-html';
import { BadRequestException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { Prisma, Invitation } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';
import { NotificationsService } from '../notifications/notifications.service';
import { SmsService } from '../notifications/sms.service';
import { ListVisitsDto, RegisterVisitDto } from './dto';
import { TenantContextService } from '../../common/services/tenant-context.service';

const AI_SYSTEM_PROMPT =
  'You are a friendly gym assistant for FLEXORA Gym OS. Write a short, warm WhatsApp ' +
  'message in Egyptian Arabic dialect to follow up with a visitor after their free gym ' +
  'visit. Be friendly and casual, not salesy. Ask about their experience. Max 3 sentences.';

@Injectable()
export class InvitationsService {
  private readonly logger = new Logger('InvitationsService');

  constructor(
    private readonly prisma: PrismaService,
    private readonly notify: NotificationsService,
    private readonly sms: SmsService,
    private readonly tenantContext: TenantContextService,
  ) {}

  private async publicInvitationGymId(invitationId: string): Promise<string | null> {
    const rows = await this.prisma.$queryRaw<Array<{ gymId: string | null }>>(
      Prisma.sql`SELECT public_invitation_gym_id(${invitationId}) AS "gymId"`,
    );
    return rows[0]?.gymId ?? null;
  }

  private get aiEnabled(): boolean {
    return process.env.AI_ENABLED === 'true' && !!process.env.ANTHROPIC_API_KEY;
  }

  private baseUrl(): string {
    return (process.env.PUBLIC_BASE_URL || process.env.API_BASE_URL || 'http://localhost:4000').replace(/\/$/, '');
  }

  /** EG normalize 01xxxxxxxxx -> +201xxxxxxxxx (matches SmsService behaviour). */
  private normalizePhone(raw: string): string {
    const digits = (raw || '').replace(/\D/g, '');
    if (digits.startsWith('20')) return `+${digits}`;
    if (digits.startsWith('0')) return `+20${digits.slice(1)}`;
    return `+20${digits}`;
  }

  // ---------------------------------------------------------------------------
  // Slots
  // ---------------------------------------------------------------------------
  async allocateSlots(gymId: string, memberId: string, total: number) {
    return this.setSlots(gymId, memberId, total);
  }

  async setSlots(gymId: string, memberId: string, totalSlots: number) {
    const member = await this.prisma.member.findFirst({ where: { id: memberId, gymId } });
    if (!member) throw new NotFoundException('Member not found');
    return this.prisma.invitationSlot.upsert({
      where: { gymId_memberId: { gymId, memberId } },
      update: { totalSlots },
      create: { gymId, memberId, totalSlots, usedSlots: 0 },
    });
  }

  async getSlots(gymId: string, memberId: string) {
    // ROUND 13 (Phase 1) — cross-branch leak fix, found by the live audit:
    // InvitationSlot has NO branchId column, so the Prisma branch-scope
    // middleware cannot pin it. Resolving the member through the scoped
    // Member model first makes another branch's member (and therefore their
    // slot row) invisible to a branch-restricted user — same guard setSlots
    // already had, now applied to the read path too.
    const member = await this.prisma.member.findFirst({ where: { id: memberId, gymId } });
    if (!member) return null;
    return this.prisma.invitationSlot.findFirst({ where: { gymId, memberId } });
  }

  /** Member list with their slot allocation (for the Slots tab). */
  async listSlots(gymId: string) {
    const members = await this.prisma.member.findMany({
      where: { gymId },
      select: {
        id: true, name: true,
        plan: { select: { name: true } },
        invitationSlot: { select: { totalSlots: true, usedSlots: true } },
      },
      orderBy: { name: 'asc' },
      take: 500,
    });
    return members.map((m) => ({
      memberId: m.id,
      name: m.name,
      plan: m.plan?.name ?? null,
      totalSlots: m.invitationSlot?.totalSlots ?? 0,
      usedSlots: m.invitationSlot?.usedSlots ?? 0,
      remaining: (m.invitationSlot?.totalSlots ?? 0) - (m.invitationSlot?.usedSlots ?? 0),
    }));
  }

  // ---------------------------------------------------------------------------
  // Register a visit (atomic slot decrement)
  // ---------------------------------------------------------------------------
  async registerVisit(gymId: string, dto: RegisterVisitDto): Promise<Invitation & { warning?: string }> {
    const member = await this.prisma.member.findFirst({ where: { id: dto.memberId, gymId } });
    if (!member) throw new NotFoundException('Inviting member not found');

    const visitorPhone = this.normalizePhone(dto.visitorPhone);

    // Soft warning if this visitor phone visited this gym before (does not block).
    const prior = await this.prisma.invitation.findFirst({
      where: { gymId, visitorPhone },
      select: { id: true },
    });

    const invitation = await this.prisma.withTenant(gymId, async (tx) => {
      // Ensure a slot row exists.
      const slot = await tx.invitationSlot.upsert({
        where: { gymId_memberId: { gymId, memberId: dto.memberId } },
        update: {},
        create: { gymId, memberId: dto.memberId, totalSlots: 2, usedSlots: 0 },
      });

      if (slot.usedSlots >= slot.totalSlots) {
        throw new BadRequestException('لا توجد دعوات متاحة');
      }

      // Atomic increment guarded by the current usedSlots value to prevent races.
      const bumped = await tx.invitationSlot.updateMany({
        where: { id: slot.id, usedSlots: slot.usedSlots },
        data: { usedSlots: { increment: 1 } },
      });
      if (bumped.count !== 1) {
        // Lost the race — another visit consumed the slot concurrently.
        throw new BadRequestException('لا توجد دعوات متاحة');
      }

      return tx.invitation.create({
        data: {
          gymId,
          slotId: slot.id,
          invitedBy: dto.memberId,
          visitorName: dto.visitorName,
          visitorPhone,
          branchId: dto.branchId || '',
          visitDate: dto.visitDate ? new Date(dto.visitDate) : new Date(),
          status: 'VISITED',
        },
      });
    });

    // Record an AI-follow-up intent in the Notification ledger (channel INAPP marker).
    try {
      await this.prisma.notification.create({
        data: {
          gymId, channel: 'INAPP', to: visitorPhone,
          subject: 'visitor-followup-queued',
          body: `Visitor ${dto.visitorName} registered; AI follow-up scheduled.`,
          status: 'PENDING',
        },
      });
    } catch { /* non-fatal */ }

    return prior ? { ...invitation, warning: 'visitor-phone-seen-before' } : invitation;
  }

  // ---------------------------------------------------------------------------
  // Convert visitor -> member
  // ---------------------------------------------------------------------------
  async convertVisitor(gymId: string, invitationId: string, newMemberId: string) {
    return this.convertToMember(gymId, invitationId, newMemberId);
  }

  async convertToMember(gymId: string, invitationId: string, newMemberId: string) {
    const inv = await this.prisma.invitation.findFirst({ where: { id: invitationId, gymId } });
    if (!inv) throw new NotFoundException('Invitation not found');
    const member = await this.prisma.member.findFirst({ where: { id: newMemberId, gymId } });
    if (!member) throw new BadRequestException('New member not found in this gym');

    return this.prisma.invitation.update({
      where: { id: invitationId },
      data: { status: 'CONVERTED', convertedToMember: true, convertedMemberId: newMemberId },
    });
  }

  async setStatus(gymId: string, invitationId: string, status: 'NO_SHOW' | 'DECLINED' | 'VISITED') {
    const inv = await this.prisma.invitation.findFirst({ where: { id: invitationId, gymId } });
    if (!inv) throw new NotFoundException('Invitation not found');
    return this.prisma.invitation.update({ where: { id: invitationId }, data: { status } });
  }

  // ---------------------------------------------------------------------------
  // Listing & stats
  // ---------------------------------------------------------------------------
  async listVisits(gymId: string, filters: ListVisitsDto) {
    const where: Prisma.InvitationWhereInput = { gymId };
    if (filters.status) where.status = filters.status;
    if (filters.memberId) where.invitedBy = filters.memberId;
    if (filters.from || filters.to) {
      where.visitDate = {};
      if (filters.from) (where.visitDate as Prisma.DateTimeFilter).gte = new Date(filters.from);
      if (filters.to) (where.visitDate as Prisma.DateTimeFilter).lte = new Date(filters.to);
    }
    const page = filters.page ?? 1;
    const limit = filters.limit ?? 20;
    const [data, total] = await this.prisma.$transaction([
      this.prisma.invitation.findMany({
        where,
        include: { member: { select: { name: true } } },
        orderBy: { visitDate: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      this.prisma.invitation.count({ where }),
    ]);
    return { data, total, page, limit };
  }

  async getStats(gymId: string) {
    const [totalVisits, converted, pendingFeedback, all] = await this.prisma.$transaction([
      this.prisma.invitation.count({ where: { gymId } }),
      this.prisma.invitation.count({ where: { gymId, status: 'CONVERTED' } }),
      this.prisma.invitation.count({ where: { gymId, status: 'VISITED', feedbackScore: null } }),
      this.prisma.invitation.findMany({
        where: { gymId },
        select: { invitedBy: true, member: { select: { name: true } } },
        take: 500,
      }),
    ]);
    // Aggregate top inviters in memory (avoids Prisma groupBy _count typing quirks).
    const counts = new Map<string, { name: string; count: number }>();
    for (const inv of all) {
      const cur = counts.get(inv.invitedBy) ?? { name: inv.member?.name ?? '—', count: 0 };
      cur.count += 1;
      counts.set(inv.invitedBy, cur);
    }
    const topInviters = [...counts.values()]
      .sort((a, b) => b.count - a.count)
      .slice(0, 5)
      .map((c) => ({ memberName: c.name, count: c.count }));
    return {
      totalVisits,
      converted,
      conversionRate: totalVisits ? Math.round((converted / totalVisits) * 100) : 0,
      pendingFeedback,
      topInviters,
    };
  }

  // ---------------------------------------------------------------------------
  // Feedback
  // ---------------------------------------------------------------------------
  async submitFeedback(gymId: string, invitationId: string, score: number, text: string) {
    return this.saveFeedback(gymId, invitationId, score, text);
  }

  async saveFeedback(gymId: string, invitationId: string, score: number, text: string) {
    const inv = await this.prisma.invitation.findFirst({ where: { id: invitationId, gymId } });
    if (!inv) throw new NotFoundException('Invitation not found');

    let aiSummary: string | null = null;
    if (this.aiEnabled && text) {
      aiSummary = (await this.callClaude(
        'You summarise gym visitor feedback in one short Arabic sentence for the owner.',
        `Visitor feedback (score ${score}/5): ${text}`,
      )) || null;
    }

    return this.prisma.invitation.update({
      where: { id: invitationId },
      data: { feedbackScore: score, feedbackText: text, aiSummary },
    });
  }

  /** Resolve a public invitation through a narrow tenant-id lookup, then RLS. */
  async findPublic(invitationId: string) {
    const gymId = await this.publicInvitationGymId(invitationId);
    if (!gymId) return null;
    return this.tenantContext.run(gymId, () =>
      this.prisma.invitation.findFirst({ where: { id: invitationId, gymId } }),
    );
  }

  /** Builds the full public feedback HTML for an invitation (with gym name). */
  async renderFeedbackForm(invitationId: string, nonce: string): Promise<string | null> {
    const gymId = await this.publicInvitationGymId(invitationId);
    if (!gymId) return null;
    return this.tenantContext.run(gymId, async () => {
      const inv = await this.prisma.invitation.findFirst({
        where: { id: invitationId, gymId },
        include: { gym: { select: { name: true } } },
      });
      if (!inv) return null;
      return this.feedbackFormHtml(inv.id, inv.gym?.name ?? 'الجيم', inv.visitorName, nonce);
    });
  }

  async savePublicFeedback(invitationId: string, score: number, text: string) {
    const gymId = await this.publicInvitationGymId(invitationId);
    if (!gymId) throw new NotFoundException('Invitation not found');
    return this.tenantContext.run(gymId, () =>
      this.saveFeedback(gymId, invitationId, score, text),
    );
  }

  // ---------------------------------------------------------------------------
  // AI follow-up
  // ---------------------------------------------------------------------------
  async sendVisitorFollowUp(gymId: string, invitationId: string): Promise<void> {
    const inv = await this.prisma.invitation.findFirst({
      where: { id: invitationId, gymId },
    });
    if (!inv || inv.aiFeedbackSent || inv.status === 'NO_SHOW') return;

    const gym = await this.prisma.gym.findUnique({ where: { id: gymId }, select: { name: true } });
    const feedbackLink = `${this.baseUrl()}/api/invitations/${inv.id}/feedback-form`;

    let message = `أهلاً ${inv.visitorName}! 👋 إزاي كانت تجربتك في ${gym?.name || 'الجيم'}؟ ` +
      `نتمنى تكون استمتعت — قولنا رأيك من هنا: ${feedbackLink}`;

    if (this.aiEnabled) {
      const ai = await this.callClaude(
        AI_SYSTEM_PROMPT,
        `Visitor name: ${inv.visitorName}\nGym name: ${gym?.name || 'the gym'}\n` +
          `Visit date: ${inv.visitDate.toISOString()}\nGenerate a follow-up WhatsApp message.`,
      );
      if (ai) message = `${ai}\n\n${feedbackLink}`;
    }

    // Additive delivery: WhatsApp + SMS (never replace one with the other).
    try { await this.notify.whatsapp(gymId, inv.visitorPhone, message); } catch { /* graceful */ }
    if (this.sms.configured) {
      try { await this.sms.sms(gymId, inv.visitorPhone, message); } catch { /* graceful */ }
    }

    await this.prisma.invitation.update({
      where: { id: inv.id },
      data: { aiFeedbackSent: true, aiFeedbackSentAt: new Date() },
    });
  }

  /** Returns invitations eligible for the hourly follow-up cron, scoped per gym. */
  eligibleForFollowUp(gymId: string) {
    const twoHoursAgo = new Date(Date.now() - 2 * 3600 * 1000);
    return this.prisma.invitation.findMany({
      where: { gymId, aiFeedbackSent: false, status: 'VISITED', visitDate: { lte: twoHoursAgo } },
      select: { id: true },
      take: 100,
    });
  }

  /** Minimal, never-throwing Claude call (mirrors AiService.ask). */
  private async callClaude(system: string, user: string): Promise<string> {
    if (!this.aiEnabled) return '';
    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'x-api-key': process.env.ANTHROPIC_API_KEY as string,
          'anthropic-version': '2023-06-01',
          'content-type': 'application/json',
        },
        body: JSON.stringify({
          model: 'claude-sonnet-4-6',
          max_tokens: 400,
          system,
          messages: [{ role: 'user', content: user }],
        }),
        signal: AbortSignal.timeout(15000),
      });
      if (!res.ok) { this.logger.warn(`Anthropic API ${res.status}`); return ''; }
      // Anthropic response shape is dynamic JSON; `any` is intentional here.
      const data = (await res.json()) as { content?: { text: string }[] };
      return Array.isArray(data?.content) ? data.content.map((c) => c?.text || '').join('').trim() : '';
    } catch (e: unknown) {
      this.logger.error(`AI follow-up failed: ${(e as Error).message}`);
      return '';
    }
  }

  /** Renders the public, no-auth feedback HTML form (mobile-first). */
  feedbackFormHtml(invitationId: string, gymName: string, visitorName: string, nonce: string): string {
    const safeName = sanitizeHtml(visitorName, { allowedTags: [], allowedAttributes: {} });
    const safeGym = sanitizeHtml(gymName, { allowedTags: [], allowedAttributes: {} });
    return `<!doctype html>
<!-- FLEXORA Gym OS — © 2024 Ammar Allam. All rights reserved. -->
<html lang="ar" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>رأيك يهمنا — ${safeGym}</title>
<style nonce="${nonce}">
  *{box-sizing:border-box;font-family:'Cairo',system-ui,sans-serif}
  body{margin:0;background:#000;color:#c8d6e5;display:grid;place-items:center;min-height:100vh;padding:20px}
  .card{background:#080d12;border:1px solid rgba(0,207,255,.15);border-radius:16px;padding:28px;max-width:420px;width:100%;box-shadow:0 0 40px rgba(0,207,255,.08)}
  h1{color:#fff;font-size:22px;margin:0 0 6px}
  p{color:#7a95ad;font-size:14px;margin:0 0 20px}
  .stars{display:flex;flex-direction:row-reverse;justify-content:center;gap:8px;margin-bottom:18px}
  .stars input{display:none}
  .stars label{font-size:40px;color:#3d5166;cursor:pointer;transition:.15s}
  .stars label:hover,.stars label:hover ~ label,.stars input:checked ~ label{color:#f5a623}
  textarea{width:100%;background:#0d1520;border:1px solid rgba(0,207,255,.15);border-radius:12px;color:#c8d6e5;padding:12px;font-size:14px;min-height:90px;outline:none}
  textarea:focus{border-color:#00cfff}
  button{width:100%;margin-top:16px;background:linear-gradient(135deg,#00cfff,#0099cc);color:#000;font-weight:700;border:none;border-radius:12px;padding:13px;font-size:15px;cursor:pointer}
  .ok{text-align:center;color:#00e5a0;font-weight:700}
</style></head><body>
<div class="card">
  <h1>أهلاً ${safeName} 👋</h1>
  <p>إزاي كانت زيارتك لـ ${safeGym}؟ رأيك بيساعدنا نتحسّن.</p>
  <form id="f">
    <div class="stars">
      ${[5, 4, 3, 2, 1].map((n) => `<input type="radio" name="score" id="s${n}" value="${n}"><label for="s${n}">★</label>`).join('')}
    </div>
    <textarea id="text" placeholder="اكتب رأيك هنا… (اختياري)"></textarea>
    <button type="submit">إرسال التقييم</button>
  </form>
  <div id="done" class="ok" style="display:none">شكراً لك! 🙏 تم استلام تقييمك.</div>
</div>
<script nonce="${nonce}">
  const f=document.getElementById('f');
  f.addEventListener('submit',async(e)=>{
    e.preventDefault();
    const score=Number((document.querySelector('input[name=score]:checked')||{}).value||0);
    if(!score){alert('من فضلك اختر عدد النجوم');return;}
    const text=document.getElementById('text').value;
    try{
      const csrf=(document.cookie.split(';').map(v=>v.trim()).find(v=>v.startsWith('_csrf='))||'').slice(6);
      const response=await fetch('/api/invitations/${invitationId}/feedback',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify({score,text})});
      if(!response.ok) throw new Error('submit failed');
      f.style.display='none';document.getElementById('done').style.display='block';
    }catch(err){alert('حدث خطأ، حاول مرة أخرى');}
  });
</script>
</body></html>`;
  }
}
