/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import {
  Body, Controller, Get, Param, Post, Query, Res, UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';
import type { Response } from 'express';
import { InvitationsService } from './invitations.service';
import {
  ConvertDto, FeedbackDto, ListVisitsDto, RegisterVisitDto, SetSlotsDto,
} from './dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { Public } from '../../common/decorators/public.decorator';
import { Audit } from '../../common/decorators/audit.decorator';
import { randomBytes } from 'crypto';

@ApiTags('invitations')
@Controller('invitations')
export class InvitationsController {
  // ROUND 13 (Phase 1): the /invitations page is Reception-visible in the nav
  // and guest invitations are front-desk daily work, so RECEPTION may read the
  // visit list/stats and manage invitation slots. Branch safety is enforced
  // by the Prisma branch-scope middleware (Invitation carries branchId; slot
  // writes resolve the member through the scoped Member model), so a Reception
  // user only ever sees and edits their own branch's data.
  constructor(private readonly svc: InvitationsService) {}

  // --- Authenticated staff endpoints (static routes FIRST to avoid :id conflicts) ---
  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Get('stats')
  @Permissions('members.create')
  stats(@GymId() g: string) { return this.svc.getStats(g); }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Get('slots')
  @Permissions('members.create')
  slotsList(@GymId() g: string) { return this.svc.listSlots(g); }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Post('slots')
  @Permissions('members.create')
  @Audit('set_slots', 'InvitationSlot')
  allocateSlots(@GymId() g: string, @Body() dto: SetSlotsDto & { memberId: string }) {
    return this.svc.allocateSlots(g, dto.memberId, dto.totalSlots);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Post('slots/:memberId')
  @Permissions('members.create')
  @Audit('set_slots', 'InvitationSlot')
  setSlots(@GymId() g: string, @Param('memberId') memberId: string, @Body() dto: SetSlotsDto) {
    return this.svc.setSlots(g, memberId, dto.totalSlots);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Get('slots/:memberId')
  @Permissions('members.create')
  getSlots(@GymId() g: string, @Param('memberId') memberId: string) {
    return this.svc.getSlots(g, memberId);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Post('visit')
  @Permissions('members.create')
  @Audit('register_visit', 'Invitation')
  visit(@GymId() g: string, @Body() dto: RegisterVisitDto) {
    return this.svc.registerVisit(g, dto);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Post('register')
  @Permissions('members.create')
  @Audit('register_visit', 'Invitation')
  register(@GymId() g: string, @Body() dto: RegisterVisitDto) {
    return this.svc.registerVisit(g, dto);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Get()
  @Permissions('members.create')
  list(@GymId() g: string, @Query() q: ListVisitsDto) { return this.svc.listVisits(g, q); }

  // --- Dynamic :id routes LAST (to avoid swallowing static routes) ---
  @Public()
  @Throttle({ default: { limit: 30, ttl: 60000 } })
  @Get(':id/feedback-form')
  async feedbackForm(@Param('id') id: string, @Res() res: Response) {
    const nonce = randomBytes(18).toString('base64');
    const html = await this.svc.renderFeedbackForm(id, nonce);
    if (!html) { res.status(404).send('Not found'); return; }
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('Content-Security-Policy', `default-src 'none'; script-src 'nonce-${nonce}'; style-src 'nonce-${nonce}'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'`);
    res.send(html);
  }

  @Public()
  @Throttle({ default: { limit: 10, ttl: 60000 } })
  @Post(':id/feedback')
  feedback(@Param('id') id: string, @Body() dto: FeedbackDto) {
    return this.svc.savePublicFeedback(id, dto.score, dto.text ?? '');
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Post(':id/convert')
  @Permissions('members.create')
  @Audit('convert_visitor', 'Invitation')
  convert(@GymId() g: string, @Param('id') id: string, @Body() dto: ConvertDto) {
    return this.svc.convertToMember(g, id, dto.newMemberId);
  }
}
