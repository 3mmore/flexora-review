/**
 * FLEXORA Gym OS — Inventory Pro (Phase 19)
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException, Injectable, Logger, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';
import { ProductEventEmitter } from '../../events/PRODUCT_EVENT_EMITTER';
import { Prisma, PurchaseOrderStatus, StockMovementType } from '@prisma/client';

@Injectable()
export class InventoryService {
  private readonly logger = new Logger(InventoryService.name);
  constructor(private readonly prisma: PrismaService, private readonly events?: ProductEventEmitter) {}

  listInventory(gymId: string, branchId?: string) {
    return this.prisma.product.findMany({ where: { gymId, ...(branchId ? { stockMovements: { some: { branchId } } } : {}) }, orderBy: { name: 'asc' }, take: 200 });
  }

  listSuppliers(gymId: string) {
    return this.prisma.supplier.findMany({ where: { gymId }, orderBy: { name: 'asc' }, take: 200 });
  }
  async createSupplier(gymId: string, dto: Omit<Prisma.SupplierCreateInput, 'gym'>) {
    return this.prisma.supplier.create({ data: { ...dto, gym: { connect: { id: gymId } } } });
  }

  listPOs(gymId: string, opts: { status?: PurchaseOrderStatus; supplierId?: string; branchId?: string } = {}) {
    return this.prisma.purchaseOrder.findMany({
      where: { gymId, ...(opts.status ? { status: opts.status } : {}), ...(opts.supplierId ? { supplierId: opts.supplierId } : {}), ...(opts.branchId ? { branchId: opts.branchId } : {}) },
      // P4-3: include the destination branch so the orders table can show it.
      include: { supplier: { select: { id: true, name: true } }, branch: { select: { id: true, name: true } } },
      orderBy: { createdAt: 'desc' },
      take: 100,
    });
  }
  async createPO(gymId: string, dto: { supplierId: string; branchId?: string; notes?: string; expectedAt?: Date; items?: Array<{ productId: string; qty: number; unitCost?: number; name?: string }> }, createdBy: string) {
    // FIX: an empty supplierId (the reorder form's untouched default) previously
    // fell through to the same "Invalid supplier" as a bogus id, which the UI
    // surfaced under "ذكاء المخزون غير متاح" with no way to know what to fix.
    if (!dto.supplierId || !String(dto.supplierId).trim()) {
      throw new BadRequestException('Supplier is required — add or select a supplier before creating the order');
    }
    const supplier = await this.prisma.supplier.findFirst({ where: { id: dto.supplierId, gymId } });
    if (!supplier) throw new BadRequestException('Invalid supplier');
    if (dto.branchId) {
      const branch = await this.prisma.branch.findFirst({ where: { id: dto.branchId, gymId } });
      if (!branch) throw new BadRequestException('Invalid branch');
    }
    for (const item of dto.items || []) {
      const product = await this.prisma.product.findFirst({ where: { id: item.productId, gymId } });
      if (!product) throw new BadRequestException('Invalid purchase order product');
      if (!item.qty || item.qty <= 0) throw new BadRequestException('Purchase order quantity must be positive');
    }
    const poNo = `PO-${Date.now().toString(36).toUpperCase()}`;
    const total = (dto.items || []).reduce((sum, item) => sum + Number(item.unitCost || 0) * Number(item.qty || 0), 0);
    return this.prisma.purchaseOrder.create({
      data: {
        gymId, supplierId: dto.supplierId, branchId: dto.branchId, poNo, notes: dto.notes, expectedAt: dto.expectedAt, total, status: PurchaseOrderStatus.DRAFT,
        items: { 
          create: (dto.items || []).map((item) => ({ 
            gymId, 
            productId: item.productId, 
            qtyOrdered: item.qty, 
            unitCost: item.unitCost || 0 
          })) 
        },
      },
    });
  }
  async sendPO(gymId: string, id: string) {
    const po = await this.getPO(gymId, id);
    if (po.status !== PurchaseOrderStatus.DRAFT) throw new BadRequestException('PO is not in draft');
    return this.prisma.purchaseOrder.update({ where: { id }, data: { status: PurchaseOrderStatus.SENT } });
  }
  async receivePO(gymId: string, id: string, dto: { items: Array<{ productId: string; qty: number; unitCost?: number }>; receivedBy: string; branchId?: string }) {
    const po = await this.prisma.purchaseOrder.findFirst({ where: { id, gymId }, include: { items: true } });
    if (!po) throw new NotFoundException('PO not found');
    if (dto.branchId) {
      const branch = await this.prisma.branch.findFirst({ where: { id: dto.branchId, gymId } });
      if (!branch) throw new BadRequestException('Invalid branch');
    }
    if (po.status !== PurchaseOrderStatus.SENT && po.status !== PurchaseOrderStatus.PARTIAL) throw new BadRequestException('PO not in receivable state');
    const gr = await this.prisma.goodsReceipt.create({ data: { gymId, purchaseOrderId: po.id, branchId: dto.branchId || po.branchId, receivedBy: dto.receivedBy } });
    for (const item of dto.items) {
      const product = await this.prisma.product.findFirst({ where: { id: item.productId, gymId } });
      if (!product) throw new BadRequestException('Invalid product');
      const ordered = po.items.find((x) => x.productId === item.productId);
      if (!ordered) throw new BadRequestException('Product was not ordered on this PO');
      if (ordered.qtyReceived + item.qty > ordered.qtyOrdered) throw new BadRequestException('Received quantity exceeds ordered quantity');
      await this.prisma.goodsReceiptItem.create({ data: { goodsReceiptId: gr.id, productId: item.productId, qtyReceived: item.qty, unitCost: item.unitCost || ordered.unitCost, varianceQty: ordered.qtyOrdered - (ordered.qtyReceived + item.qty) } });
      await this.prisma.purchaseOrderItem.update({ where: { id: ordered.id }, data: { qtyReceived: { increment: item.qty } } });
      await this.prisma.stockMovement.create({ data: { gymId, productId: item.productId, branchId: dto.branchId || po.branchId, type: StockMovementType.PURCHASE, qty: item.qty, unitCost: item.unitCost, reference: gr.id, createdBy: dto.receivedBy } });
      await this.prisma.product.update({ where: { id: product.id }, data: { qty: { increment: item.qty }, costPrice: item.unitCost || undefined } });
    }
    const allItems = await this.prisma.purchaseOrderItem.findMany({ where: { purchaseOrderId: po.id } });
    const complete = allItems.every((item) => item.qtyReceived >= item.qtyOrdered);
    const updated = await this.prisma.purchaseOrder.update({ where: { id }, data: { status: complete ? PurchaseOrderStatus.RECEIVED : PurchaseOrderStatus.PARTIAL, receivedAt: complete ? new Date() : undefined } });
    // P3 FIX: the product-event schema requires payload.productId. Emit one
    // inventory.updated per received product (was emitting a single event with
    // only purchaseOrderId, which failed schema validation and turned every
    // successful receipt into a 400 after the stock had already been written).
    for (const item of dto.items) {
      const product = await this.prisma.product.findUnique({ where: { id: item.productId }, select: { id: true, qty: true } });
      await this.events?.emitEvent({ type: 'inventory.updated', tenantId: gymId, branchId: dto.branchId || po.branchId, entityId: item.productId, payload: { productId: item.productId, qty: product?.qty, purchaseOrderId: po.id }, source: 'api' });
    }
    return updated;
  }
  async getPO(gymId: string, id: string) {
    const po = await this.prisma.purchaseOrder.findFirst({ where: { id, gymId }, include: { items: true } });
    if (!po) throw new NotFoundException('PO not found');
    return po;
  }

  async getPOItems(gymId: string, id: string) {
    const po = await this.prisma.purchaseOrder.findFirst({ where: { id, gymId }, include: { items: true } });
    if (!po) throw new NotFoundException('PO not found');
    return po.items;
  }

  /**
   * P4-3: pending/incoming stock from OPEN purchase orders. Flattens every
   * not-yet-fully-received line across DRAFT/SENT/PARTIAL POs into one
   * "what's on its way" list, with the product name, remaining quantity,
   * expected date, supplier and destination branch so the front desk knows
   * what to expect before anything is received.
   */
  async incoming(gymId: string, branchId?: string) {
    const pos = await this.prisma.purchaseOrder.findMany({
      where: { gymId, status: { in: [PurchaseOrderStatus.DRAFT, PurchaseOrderStatus.SENT, PurchaseOrderStatus.PARTIAL] }, ...(branchId ? { branchId } : {}) },
      include: { supplier: { select: { id: true, name: true } }, items: true },
      orderBy: { expectedAt: 'asc' },
    });
    const productIds = [...new Set(pos.flatMap((p) => p.items.map((i) => i.productId)))];
    const products = productIds.length
      ? await this.prisma.product.findMany({ where: { id: { in: productIds } }, select: { id: true, name: true } })
      : [];
    const productName = new Map(products.map((p) => [p.id, p.name]));
    const branchIds = [...new Set(pos.map((p) => p.branchId).filter(Boolean))] as string[];
    const branches = branchIds.length
      ? await this.prisma.branch.findMany({ where: { id: { in: branchIds } }, select: { id: true, name: true } })
      : [];
    const branchName = new Map(branches.map((b) => [b.id, b.name]));
    const rows: Array<Record<string, unknown>> = [];
    for (const po of pos) {
      for (const item of po.items) {
        const remaining = item.qtyOrdered - item.qtyReceived;
        if (remaining <= 0) continue;
        rows.push({
          poId: po.id,
          poNo: po.poNo,
          status: po.status,
          expectedAt: po.expectedAt,
          supplier: po.supplier,
          branch: po.branchId ? { id: po.branchId, name: branchName.get(po.branchId) || '' } : null,
          productId: item.productId,
          product: item.productId ? { id: item.productId, name: productName.get(item.productId) || '—' } : null,
          remaining,
          unitCost: item.unitCost,
        });
      }
    }
    return rows;
  }

  async transferStock(gymId: string, dto: { productId: string; fromBranchId?: string; toBranchId?: string; qty: number; createdBy: string }) {
    if (dto.fromBranchId === dto.toBranchId) throw new BadRequestException('Same branch');
    const product = await this.prisma.product.findFirst({ where: { id: dto.productId, gymId } });
    if (!product) throw new BadRequestException('Invalid product');
    for (const branchId of [dto.fromBranchId, dto.toBranchId].filter(Boolean) as string[]) {
      const branch = await this.prisma.branch.findFirst({ where: { id: branchId, gymId } });
      if (!branch) throw new BadRequestException('Invalid branch');
    }
    await this.prisma.stockMovement.create({ data: { gymId, productId: dto.productId, branchId: dto.fromBranchId, type: StockMovementType.TRANSFER_OUT, qty: dto.qty, createdBy: dto.createdBy } });
    await this.prisma.stockMovement.create({ data: { gymId, productId: dto.productId, branchId: dto.toBranchId, type: StockMovementType.TRANSFER_IN, qty: dto.qty, reference: 'paired', createdBy: dto.createdBy } });
    return { ok: true };
  }

  async adjustStock(gymId: string, dto: { productId: string; qty: number; reason: string; createdBy: string }) {
    const product = await this.prisma.product.findFirst({ where: { id: dto.productId, gymId } });
    if (!product) throw new BadRequestException('Invalid product');
    await this.prisma.stockMovement.create({ data: { gymId, productId: dto.productId, type: StockMovementType.ADJUSTMENT, qty: dto.qty, reference: dto.reason, createdBy: dto.createdBy } });
    const updated = await this.prisma.product.update({ where: { id: product.id }, data: { qty: { increment: dto.qty } } });
    await this.events?.emitEvent({ type: 'inventory.updated', tenantId: gymId, entityId: product.id, payload: { productId: product.id, qty: updated.qty }, source: 'api' });
    if (updated.qty <= updated.lowStockThreshold) await this.events?.emitEvent({ type: 'inventory.low_stock', tenantId: gymId, entityId: product.id, payload: { productId: product.id, qty: updated.qty }, source: 'api' });
    return { ok: true };
  }

  async lowStockAlerts(gymId: string, branchId?: string) {
    // PHASE 8: a product ASSIGNED to the branch belongs to that branch's
    // inventory even before its first stock movement, so the assignment made
    // on the product form is reflected here immediately.
    const products = await this.prisma.product.findMany({
      where: { gymId, ...(branchId ? { OR: [{ branchId }, { stockMovements: { some: { branchId } } }] } : {}) },
    });
    const branchIds = [...new Set(products.map((p) => (p as { branchId?: string | null }).branchId).filter((x): x is string => !!x))];
    const branches = branchIds.length
      ? await this.prisma.branch.findMany({ where: { id: { in: branchIds } }, select: { id: true, name: true } })
      : [];
    const nameById = new Map(branches.map((b) => [b.id, b.name]));
    return products.filter((p) => p.qty <= p.lowStockThreshold).map((p) => {
      const own = (p as { branchId?: string | null }).branchId || null;
      return {
        id: p.id, name: p.name, qty: p.qty, lowStockThreshold: p.lowStockThreshold,
        branchId: own,
        branch: own ? { id: own, name: nameById.get(own) || '' } : null,
      };
    });
  }

  listMovements(gymId: string, opts: { productId?: string; from?: Date; to?: Date; branchId?: string } = {}) {
    return this.prisma.stockMovement.findMany({
      where: { gymId, ...(opts.productId ? { productId: opts.productId } : {}), ...(opts.branchId ? { branchId: opts.branchId } : {}), ...(opts.from || opts.to ? { occurredAt: { ...(opts.from ? { gte: opts.from } : {}), ...(opts.to ? { lte: opts.to } : {}) } } : {}) },
      orderBy: { occurredAt: 'desc' },
      take: 200,
      include: { product: { select: { name: true } } },
    });
  }

  async findByBarcode(gymId: string, barcode: string) {
    const p = await this.prisma.product.findFirst({ where: { gymId, barcode } });
    if (!p) throw new NotFoundException('Product not found');
    return p;
  }
  async printBarcode(gymId: string, productId: string, qty: number) {
    const p = await this.prisma.product.findFirst({ where: { id: productId, gymId } });
    if (!p) throw new NotFoundException('Product not found');
    return { productId, name: p.name, barcode: p.barcode || `FLX-${productId.slice(0, 10).toUpperCase()}`, price: Number(p.sellingPrice), copies: qty, printedAt: new Date() };
  }
}
