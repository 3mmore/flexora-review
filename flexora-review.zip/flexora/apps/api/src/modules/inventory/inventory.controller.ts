/**
 * FLEXORA Gym OS — Inventory controller (Phase 19)
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Delete, Get, Param, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { IsArray, IsInt, IsNumber, IsOptional, IsString, Min, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { PurchaseOrderStatus } from '@prisma/client';
import { InventoryService } from './inventory.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { RequiresFeature } from '../license/license.module';
import { Audit } from '../../common/decorators/audit.decorator';

class CreateSupplierDto {
  @IsString() name!: string;
  @IsOptional() @IsString() contactName?: string;
  @IsOptional() @IsString() phone?: string;
  @IsOptional() @IsString() email?: string;
  @IsOptional() @IsString() address?: string;
  @IsOptional() @IsString() taxId?: string;
}
class PurchaseOrderLineDto {
  @IsString() productId!: string;
  @IsInt() @Min(1) qty!: number;
  @IsOptional() @IsNumber() @Min(0) unitCost?: number;
  @IsOptional() @IsString() name?: string;
}
class CreatePODto {
  @IsString() supplierId!: string;
  @IsOptional() @IsString() branchId?: string;
  @IsOptional() @IsString() notes?: string;
  @IsOptional() expectedAt?: Date;
  @IsArray() @ValidateNested({ each: true }) @Type(() => PurchaseOrderLineDto) items!: PurchaseOrderLineDto[];
}
class ReceivePODto {
  @IsOptional() @IsString() branchId?: string;
  @IsArray() items!: Array<{ productId: string; qty: number; unitCost?: number }>;
}
class TransferDto {
  @IsString() productId!: string;
  @IsOptional() @IsString() fromBranchId?: string;
  @IsString() toBranchId!: string;
  @IsNumber() qty!: number;
}
class PrintBarcodeDto { @IsOptional() @IsNumber() qty?: number; }

class AdjustDto {
  @IsString() productId!: string;
  @IsNumber() qty!: number;
  @IsString() reason!: string;
}

@ApiTags('inventory')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@RequiresFeature('inventory')
@Controller('inventory')
export class InventoryController {
  constructor(private readonly svc: InventoryService) {}

  @Get() @Permissions('inventory.view')
  inventory(@GymId() g: string) { return this.svc.listInventory(g); }

  @Get('alerts') @Permissions('inventory.manage')
  alerts(@GymId() g: string) { return this.svc.lowStockAlerts(g); }

  @Get('suppliers') @Permissions('inventory.manage')
  listSuppliers(@GymId() g: string) { return this.svc.listSuppliers(g); }

  @Post('suppliers') @Permissions('inventory.manage') @Audit('create', 'Supplier')
  createSupplier(@GymId() g: string, @Body() dto: CreateSupplierDto) { return this.svc.createSupplier(g, dto); }

  @Get('purchase-orders') @Permissions('inventory.manage')
  listPOs(@GymId() g: string, @Query('status') status?: PurchaseOrderStatus, @Query('supplierId') supplierId?: string, @Query('branchId') branchId?: string) {
    return this.svc.listPOs(g, { status, supplierId, branchId });
  }

  // P4-3: pending/incoming stock across open purchase orders.
  @Get('incoming') @Permissions('inventory.view')
  incoming(@GymId() g: string, @Query('branchId') branchId?: string) { return this.svc.incoming(g, branchId); }

  @Post('purchase-orders') @Permissions('inventory.manage') @Audit('create', 'PurchaseOrder')
  createPO(@GymId() g: string, @Body() dto: CreatePODto, @CurrentUser('sub') userId: string) {
    return this.svc.createPO(g, dto, userId);
  }

  @Get('purchase-orders/:id') @Permissions('inventory.manage')
  po(@GymId() g: string, @Param('id') id: string) { return this.svc.getPO(g, id); }

  @Get('purchase-orders/:id/items') @Permissions('inventory.manage')
  poItems(@GymId() g: string, @Param('id') id: string) { return this.svc.getPOItems(g, id); }

  @Post('purchase-orders/:id/send') @Permissions('inventory.manage') @Audit('send', 'PurchaseOrder')
  sendPO(@GymId() g: string, @Param('id') id: string) { return this.svc.sendPO(g, id); }

  @Post('purchase-orders/:id/receive') @Permissions('inventory.view') @Audit('receive', 'PurchaseOrder')
  receivePO(@GymId() g: string, @Param('id') id: string, @Body() dto: ReceivePODto, @CurrentUser('sub') userId: string) {
    return this.svc.receivePO(g, id, { ...dto, receivedBy: userId });
  }

  @Post('transfer') @Permissions('inventory.view') @Audit('transfer', 'StockMovement')
  transfer(@GymId() g: string, @Body() dto: TransferDto, @CurrentUser('sub') userId: string) {
    return this.svc.transferStock(g, { ...dto, createdBy: userId });
  }

  @Post('adjust') @Permissions('inventory.manage') @Audit('adjust', 'StockMovement')
  adjust(@GymId() g: string, @Body() dto: AdjustDto, @CurrentUser('sub') userId: string) {
    return this.svc.adjustStock(g, { ...dto, createdBy: userId });
  }

  @Get('movements') @Permissions('inventory.manage')
  movements(@GymId() g: string, @Query('productId') productId?: string, @Query('from') from?: string, @Query('to') to?: string, @Query('branchId') branchId?: string) {
    return this.svc.listMovements(g, { productId, from: from ? new Date(from) : undefined, to: to ? new Date(to) : undefined, branchId });
  }

  @Get('low-stock') @Permissions('inventory.manage')
  lowStock(@GymId() g: string, @Query('branchId') branchId?: string) { return this.svc.lowStockAlerts(g, branchId); }

  @Get('barcode/:barcode') @Permissions('inventory.view')
  findByBarcode(@GymId() g: string, @Param('barcode') barcode: string) { return this.svc.findByBarcode(g, barcode); }

  @Post('barcode/print/:productId') @Permissions('inventory.manage')
  printBarcode(@GymId() g: string, @Param('productId') productId: string, @Body() dto: PrintBarcodeDto) {
    return this.svc.printBarcode(g, productId, dto.qty || 1);
  }
}
