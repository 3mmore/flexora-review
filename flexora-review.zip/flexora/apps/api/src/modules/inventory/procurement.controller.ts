/**
 * FLEXORA Gym OS — Procurement compatibility API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Controller, Get, Param, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { InventoryService } from './inventory.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { RequiresFeature } from '../license/license.module';

@ApiTags('procurement')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@RequiresFeature('inventory')
@Controller('procurement/po')
export class ProcurementController {
  constructor(private readonly inventory: InventoryService) {}

  @Get(':id/items')
  @Roles('OWNER', 'MANAGER')
  items(@GymId() gymId: string, @Param('id') id: string) {
    return this.inventory.getPOItems(gymId, id);
  }
}
