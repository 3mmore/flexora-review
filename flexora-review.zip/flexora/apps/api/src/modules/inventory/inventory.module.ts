/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { PrismaModule } from '../../config/prisma.module';
import { InventoryService } from './inventory.service';

@Module({ imports: [PrismaModule], providers: [InventoryService], exports: [InventoryService] })
export class InventoryModule {}
