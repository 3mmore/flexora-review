/**
 * PHASE P3 — Redis outage and licence-verification resilience.
 *
 * The bug this phase removes, reproduced: `RedisService` was built with
 * `maxRetriesPerRequest: null` and an offline queue, so when Redis was
 * unreachable an awaited `get`/`set` in a request handler NEVER settled — the
 * request hung (holding a socket, a Prisma connection and a worker slot) until
 * the client or the proxy gave up. A Redis outage became an API outage.
 *
 * And on the licence side, `checkGracePeriod()` caught a Redis error, logged
 * "System continues" and returned TRUE — fail-open: losing Redis silently turned
 * "we could not verify the licence" into "the licence is fine".
 *
 * Every test below fails against the pre-P3 tree:
 *   1  the Redis client is bounded (no offline queue, no per-request retry,
 *      hard command + connect timeouts);
 *   2  a process that never verified has NO grace and fails closed immediately;
 *   3  a process that DID verify keeps serving inside the documented grace
 *      window, then fails closed;
 *   4  an authoritative refusal is sticky — a later transport failure can never
 *      turn a REVOKED licence into an unverified (or valid) one;
 *   5  the global guard refuses every route with 503 + LICENCE_UNVERIFIED except
 *      the two health probes, and refuses non-HTTP contexts too;
 *   6  the filter turns a bounded Redis rejection into 503 + Retry-After, and
 *      re-throws anything it does not recognise (negative control);
 *   7  the per-tenant licence cache: one lookup per tenant, single-flight, a
 *      strict 30 s TTL, no cross-tenant leak, fail-closed on a database error,
 *      and Redis caching resumes on recovery.
 */
import { BadRequestException, ServiceUnavailableException } from '@nestjs/common';
import {
  LicenceStateService,
  LICENCE_GRACE_MS,
} from './licence-state.service';
import { LicenseCheckService, LICENSE_UNVERIFIED_EVENT, LICENSE_EXPIRED_EVENT } from './license-check.service';
import { LicenceAvailabilityGuard } from '../../common/guards/licence-availability.guard';
import {
  DependencyUnavailableFilter,
  LICENCE_UNVERIFIED,
  REDIS_UNAVAILABLE,
  RETRY_AFTER_SECONDS,
  isRedisUnavailableError,
} from '../../common/filters/dependency-unavailable.filter';
import {
  REDIS_COMMAND_TIMEOUT_MS,
  REDIS_CONNECT_TIMEOUT_MS,
  RedisService,
} from '../../config/redis.service';
import { LicenseService, TENANT_LICENCE_CACHE_TTL_MS } from './license.service';
import { LICENSE_REQUIRED_ENV } from './licence-policy';
import { HealthController } from '../health/health.controller';

// PHASE Q2 — the guard identifies the probes by ROUTE METADATA, so the fake
// execution context has to carry the real thing: for the two probe URLs it uses
// the ACTUAL HealthController class and handler functions (which carry
// `@HealthProbe('live'|'ready')`), not a hand-made stand-in. A spec that faked
// the marker would keep passing if the product lost it.
const PROBE_HANDLERS: Record<string, { handler: unknown; klass: unknown }> = {
  '/api/health/live': { handler: HealthController.prototype.liveness, klass: HealthController },
  '/api/health/ready': { handler: HealthController.prototype.readiness, klass: HealthController },
};

function httpContext(url: string | null) {
  const probe = url === null ? undefined : PROBE_HANDLERS[url];
  const handler = probe ? probe.handler : () => undefined;
  const klass = probe ? probe.klass : class {};
  return {
    switchToHttp: () => ({ getRequest: () => (url === null ? undefined : { url, originalUrl: url }) }),
    getHandler: () => handler,
    getClass: () => klass,
    getType: () => 'http' as const,
  } as any;
}

/**
 * PHASE Q3 — global licence enforcement is opt-in. The guard and the verification
 * loop are only active when FLEXORA_LICENSE_REQUIRED is true, so the suites that
 * test that policy turn it on and put the environment back afterwards. Tests that
 * assert the DEFAULT (off) behaviour delete it explicitly.
 */
function enforcementOn() {
  const saved = process.env[LICENSE_REQUIRED_ENV];
  process.env[LICENSE_REQUIRED_ENV] = 'true';
  return () => {
    if (saved === undefined) delete process.env[LICENSE_REQUIRED_ENV];
    else process.env[LICENSE_REQUIRED_ENV] = saved;
  };
}

function responseMock() {
  const headers: Record<string, string> = {};
  const res: any = { headersSent: false, statusCode: 0, body: undefined };
  res.status = jest.fn((code: number) => { res.statusCode = code; return res; });
  res.setHeader = jest.fn((k: string, v: string) => { headers[k] = v; return res; });
  res.json = jest.fn((body: unknown) => { res.body = body; return res; });
  res.headers = headers;
  return res;
}

function argsHost(res: any, url = '/api/members') {
  return {
    switchToHttp: () => ({ getResponse: () => res, getRequest: () => ({ url }) }),
    getType: () => 'http' as const,
  } as any;
}

describe('PHASE P3 — Redis outage never hangs the API', () => {
  it('1. builds the Redis client with bounded commands and no offline queue', () => {
    const svc = new RedisService();
    const options = (svc.client as any).options;
    // the pre-P3 values were maxRetriesPerRequest: null, connectTimeout: 10000
    // and an offline queue, i.e. a command issued while disconnected never
    // settled. All three are asserted here so a future options spread cannot
    // silently drop one of them.
    expect(options.maxRetriesPerRequest).toBe(0);
    expect(options.enableOfflineQueue).toBe(false);
    expect(options.commandTimeout).toBe(REDIS_COMMAND_TIMEOUT_MS);
    expect(options.connectTimeout).toBe(REDIS_CONNECT_TIMEOUT_MS);
    expect(options.commandTimeout).toBeLessThanOrEqual(2000);
    expect(options.connectTimeout).toBeLessThanOrEqual(2000);
    // the connection itself still retries in the background, so recovery needs no
    // restart
    expect(typeof options.retryStrategy).toBe('function');
    expect(options.retryStrategy(1)).toBeGreaterThan(0);
    svc.client.disconnect();
  });

  it('1b. recognises Redis transport errors, and only those', () => {
    expect(isRedisUnavailableError(Object.assign(new Error('connect ECONNREFUSED 127.0.0.1:6379'), { code: 'ECONNREFUSED' }))).toBe(true);
    expect(isRedisUnavailableError(new Error('Connection is closed.'))).toBe(true);
    expect(isRedisUnavailableError(new Error('Command timed out'))).toBe(true);
    // negative control: an ordinary application error is NOT a Redis outage
    expect(isRedisUnavailableError(new Error('Unique constraint failed on the fields: (mobile, gymId)'))).toBe(false);
    expect(isRedisUnavailableError(new Error('license_invalid'))).toBe(false);
    expect(isRedisUnavailableError(null)).toBe(false);
  });
});

describe('PHASE P3 — global licence state fails closed, never open', () => {
  beforeEach(() => jest.useFakeTimers({ doNotFake: ['nextTick', 'setImmediate'] }));
  afterEach(() => jest.useRealTimers());

  it('2. a process that never verified has no grace: it fails closed immediately', () => {
    const s = new LicenceStateService();
    expect(s.getState()).toBe('unknown');
    const expired = s.markUnverified('redis-unavailable:unreachable');
    expect(expired).toBe(true);
    expect(s.isUnverified()).toBe(true);
    expect(s.graceRemainingSeconds()).toBe(0);
  });

  it('3. a process that DID verify serves inside the documented grace, then fails closed', () => {
    const s = new LicenceStateService();
    s.markVerified();
    expect(s.isUnverified()).toBe(false);

    expect(s.markUnverified('unreachable')).toBe(false); // inside the window
    expect(s.isUnverified()).toBe(false);
    expect(s.graceRemainingSeconds()).toBeGreaterThan(0);

    jest.advanceTimersByTime(LICENCE_GRACE_MS + 1000);
    expect(s.markUnverified('unreachable')).toBe(true); // window exhausted
    expect(s.isUnverified()).toBe(true);
    expect(s.graceRemainingSeconds()).toBe(0);

    // recovery clears the state with no restart
    s.markVerified();
    expect(s.isUnverified()).toBe(false);
    expect(s.getState()).toBe('verified');
  });

  it('4. an authoritative refusal is sticky — a later transport failure cannot downgrade it', () => {
    const s = new LicenceStateService();
    s.markRefused('revoked');
    expect(s.isRefused()).toBe(true);
    // the pre-P3 failure mode in reverse: an unreachable server must never be
    // able to make a revoked licence look merely "unverified", let alone valid
    expect(s.markUnverified('unreachable')).toBe(true);
    expect(s.isRefused()).toBe(true);
    expect(s.isUnverified()).toBe(false);
  });

  it('4b. snapshot never carries a key, URL or token', () => {
    const s = new LicenceStateService();
    s.markUnverified('redis-unavailable:unreachable https://license.example/v1/verify FLEX-ABCD');
    const text = JSON.stringify(s.snapshot());
    expect(text).not.toMatch(/FLEX-[A-Z0-9]/);
    expect(text).not.toMatch(/https?:\/\//);
    expect(s.snapshot().reason.length).toBeLessThanOrEqual(80);
  });
});

describe('PHASE P3 — LicenceAvailabilityGuard refuses licensed routes, not the probes', () => {
  // PHASE Q3: this whole suite is the enforcement policy, which only exists when
  // the operator switches it on.
  let restoreFlag: (() => void) | undefined;
  beforeEach(() => { restoreFlag = enforcementOn(); });
  afterEach(() => { restoreFlag?.(); restoreFlag = undefined; });

  function guard(state: LicenceStateService) {
    return new LicenceAvailabilityGuard(state);
  }

  it('5. refuses a licensed route with 503 + LICENCE_UNVERIFIED when unverified', () => {
    const s = new LicenceStateService();
    s.markUnverified('unreachable');
    expect(() => guard(s).canActivate(httpContext('/api/members'))).toThrow(ServiceUnavailableException);
    try {
      guard(s).canActivate(httpContext('/api/members'));
    } catch (e) {
      const body = (e as ServiceUnavailableException).getResponse() as any;
      expect((e as ServiceUnavailableException).getStatus()).toBe(503);
      expect(body.code).toBe(LICENCE_UNVERIFIED);
      expect(body.retryAfterSeconds).toBe(RETRY_AFTER_SECONDS);
      expect(JSON.stringify(body)).not.toMatch(/FLEX-|https?:\/\//);
    }
  });

  it('5b. keeps the two health probes answering, and refuses everything else under /api/health', () => {
    const s = new LicenceStateService();
    s.markUnverified('unreachable');
    expect(guard(s).canActivate(httpContext('/api/health/live'))).toBe(true);
    expect(guard(s).canActivate(httpContext('/api/health/ready'))).toBe(true);
    // NOT exempt: these are licensed/admin work
    expect(() => guard(s).canActivate(httpContext('/api/health'))).toThrow(ServiceUnavailableException);
    expect(() => guard(s).canActivate(httpContext('/api/health/metrics'))).toThrow(ServiceUnavailableException);
    expect(() => guard(s).canActivate(httpContext('/api/health/details'))).toThrow(ServiceUnavailableException);
    expect(() => guard(s).canActivate(httpContext('/api/auth/login'))).toThrow(ServiceUnavailableException);
    expect(() => guard(s).canActivate(httpContext('/api/platform/anything'))).toThrow(ServiceUnavailableException);
  });

  it('5c. refuses a non-HTTP context (no URL to exempt must never mean allowed)', () => {
    const s = new LicenceStateService();
    s.markUnverified('unreachable');
    expect(() => guard(s).canActivate(httpContext(null))).toThrow(ServiceUnavailableException);
  });

  it('5e. PHASE Q3 — with enforcement ON, `unknown` refuses licensed routes (the documented flip, now made)', () => {
    // PHASE P3 shipped this guard refusing only on an EXPLICIT unverified/refused
    // state, because nothing in the tree populated the state: `LicenseCheckService`
    // was registered in no module, so it was never instantiated and its @Cron never
    // ran. Refusing on `unknown` back then would have 503'd the entire API on every
    // deployment. The guard said so in a comment and pinned it with a test.
    //
    // PHASE Q3 supplies the missing switch — FLEXORA_LICENSE_REQUIRED — and with it
    // ON the agreed policy applies in full: only an AUTHORITATIVE verification
    // opens licensed routes, so a process that has just booted (`unknown`) answers
    // 503 LICENCE_UNVERIFIED on every licensed route while the two probes keep
    // answering. Verification retries in the background and clears this with no
    // restart (tested in section 8 and live in work/q3-live-proof.sh).
    const s = new LicenceStateService();
    expect(s.getState()).toBe('unknown');
    expect(s.isServingLicensedRoutes()).toBe(false);
    expect(() => guard(s).canActivate(httpContext('/api/members'))).toThrow(ServiceUnavailableException);
    expect(() => guard(s).canActivate(httpContext('/api/auth/login'))).toThrow(ServiceUnavailableException);
    // the probes still answer — that is what lets an orchestrator see the container
    expect(guard(s).canActivate(httpContext('/api/health/live'))).toBe(true);
    expect(guard(s).canActivate(httpContext('/api/health/ready'))).toBe(true);
    // and the first authoritative verification opens everything, no restart
    s.markVerified();
    expect(guard(s).canActivate(httpContext('/api/members'))).toBe(true);
  });

  it('5e2. PHASE Q3 — with enforcement OFF (the default) the guard is inert: no route is ever refused', () => {
    delete process.env[LICENSE_REQUIRED_ENV];
    const s = new LicenceStateService();
    // even an explicitly unverified state must not produce a 503 when the operator
    // did not ask for enforcement: SaaS behaviour is unchanged by this phase.
    s.markUnverified('unreachable');
    for (const url of ['/api/members', '/api/auth/login', '/api/health', '/api/platform/anything']) {
      expect(guard(s).canActivate(httpContext(url))).toBe(true);
    }
    // and the same with the variable present but false / empty / garbage
    for (const value of ['false', '0', '', 'no', 'off', 'maybe']) {
      process.env[LICENSE_REQUIRED_ENV] = value;
      expect(guard(s).canActivate(httpContext('/api/members'))).toBe(true);
    }
    delete process.env[LICENSE_REQUIRED_ENV];
    restoreFlag = enforcementOn();
  });

  it('5f. PHASE Q3 — license.module registers the verification loop ONLY when enforcement is on', () => {
    // Replaces the PHASE P3 test that pinned "no *.module.ts mentions
    // LicenseCheckService". That invariant was a documentation of a gap, not a
    // requirement; the requirement is that the phone-home loop exists exactly when
    // the operator asked for it. jest.resetModules() gives a fresh module registry,
    // so the comparison is by class NAME — the imported binding and the re-required
    // one are different objects.
    const providerNames = (flag: string | undefined): string[] => {
      jest.resetModules();
      if (flag === undefined) delete process.env[LICENSE_REQUIRED_ENV];
      else process.env[LICENSE_REQUIRED_ENV] = flag;
      // eslint-disable-next-line @typescript-eslint/no-var-requires
      const mod = require('./license.module').LicenseModule;
      const providers = (Reflect.getMetadata('providers', mod) || []) as unknown[];
      return providers.map((entry) => {
        const candidate = entry as { useClass?: { name?: string }; name?: string };
        return (candidate?.useClass?.name || candidate?.name || String(entry));
      });
    };

    const off = providerNames(undefined);
    expect(off).not.toContain('LicenseCheckService');
    // the state service stays: /api/health/ready reports from it and it is inert
    // without anything calling markVerified/markUnverified
    expect(off).toContain('LicenceStateService');
    expect(off).toContain('LicenseService');

    const on = providerNames('true');
    expect(on).toContain('LicenseCheckService');
    expect(on).toContain('LicenceStateService');

    // and a false-ish value behaves exactly like unset
    expect(providerNames('false')).not.toContain('LicenseCheckService');
    expect(providerNames('0')).not.toContain('LicenseCheckService');
    jest.resetModules();
    delete process.env[LICENSE_REQUIRED_ENV];
    restoreFlag = enforcementOn();
  });

  it('5d. negative control: while verified, every route passes through untouched', () => {
    const s = new LicenceStateService();
    s.markVerified();
    for (const url of ['/api/members', '/api/health/live', '/api/auth/login', '/api/health/metrics']) {
      expect(guard(s).canActivate(httpContext(url))).toBe(true);
    }
  });
});

describe('PHASE P3 — DependencyUnavailableFilter answers 503 + Retry-After', () => {
  it('6. maps a bounded Redis rejection to 503 + Retry-After + REDIS_UNAVAILABLE', () => {
    const res = responseMock();
    new DependencyUnavailableFilter().catch(
      Object.assign(new Error('connect ECONNREFUSED 127.0.0.1:6379'), { code: 'ECONNREFUSED' }),
      argsHost(res, '/api/members?limit=1'),
    );
    expect(res.statusCode).toBe(503);
    expect(res.headers['Retry-After']).toBe(String(RETRY_AFTER_SECONDS));
    expect(res.body.code).toBe(REDIS_UNAVAILABLE);
    // the query string must not be echoed back
    expect(res.body.path).toBe('/api/members');
    expect(JSON.stringify(res.body)).not.toMatch(/6379|redis:\/\/|ECONNREFUSED/);
  });

  it('6b. gives the licence 503 its Retry-After header', () => {
    const res = responseMock();
    const ex = new ServiceUnavailableException({ statusCode: 503, code: LICENCE_UNVERIFIED, message: 'x' });
    new DependencyUnavailableFilter().catch(ex, argsHost(res));
    expect(res.statusCode).toBe(503);
    expect(res.headers['Retry-After']).toBe(String(RETRY_AFTER_SECONDS));
    expect(res.body.code).toBe(LICENCE_UNVERIFIED);
  });

  it('6c. negative control: an unrelated error is NOT turned into a 503', () => {
    const res = responseMock();
    const boom = new Error('Unique constraint failed on the fields: (mobile, gymId)');
    new DependencyUnavailableFilter().catch(boom, argsHost(res));
    // the intent of this test is unchanged: a database-level error must never be
    // relabelled as a transient dependency outage with a Retry-After.
    expect(res.statusCode).not.toBe(503);
    expect(res.headers['Retry-After']).toBeUndefined();
    expect(res.body.code).toBeUndefined();
    // PHASE Q4a: it must still be ANSWERED. Re-throwing from a @Catch() filter is
    // not delegation — it escapes to Express's default handler, which replies
    // text/html (measured: 309 bytes, <title>Error</title>) from a JSON-only API.
    expect(res.statusCode).toBe(500);
    expect(res.body.message).toBe('Internal server error');
    // and the error text is never echoed to the client
    expect(JSON.stringify(res.body)).not.toMatch(/mobile|gymId|Unique constraint/);
  });

  it('6d. PHASE Q4a — an HttpException this filter does not own keeps its own status AND payload', () => {
    // flexora-critical-flows asserts body.code === 'WHATSAPP_NOT_CONFIGURED' on a
    // 400 from PortalService. With the old re-throw the client got an HTML page
    // and `code` was undefined.
    const res = responseMock();
    const ex = new BadRequestException({
      statusCode: 400,
      code: 'WHATSAPP_NOT_CONFIGURED',
      translationKey: 'whatsapp_login_not_configured',
      message: 'WhatsApp login is not configured for this gym.',
    });
    new DependencyUnavailableFilter().catch(ex, argsHost(res, '/api/portal/request-otp'));
    expect(res.statusCode).toBe(400);
    expect(res.body.code).toBe('WHATSAPP_NOT_CONFIGURED');
    expect(res.headers['Retry-After']).toBeUndefined();
  });

  it('6e. PHASE Q4a — a Prisma-shaped error is answered as JSON, not as a dependency 503', () => {
    const res = responseMock();
    const p2002 = Object.assign(new Error('Unique constraint failed on the fields: (mobile)'), { code: 'P2002' });
    new DependencyUnavailableFilter().catch(p2002, argsHost(res));
    expect(res.statusCode).toBe(500);
    expect(res.headers['Retry-After']).toBeUndefined();
    expect(res.body).toEqual({ statusCode: 500, message: 'Internal server error' });
  });
});

describe('PHASE P3 — per-tenant licence cache: bounded, isolated, fail-closed', () => {
  beforeEach(() => jest.useFakeTimers({ doNotFake: ['nextTick', 'setImmediate'] }));
  afterEach(() => jest.useRealTimers());

  function harness(opts: { redisUp?: boolean; dbUp?: boolean } = {}) {
    const redisUp = opts.redisUp !== false;
    const dbUp = opts.dbUp !== false;
    const redisCalls: string[] = [];
    const dbCalls: string[] = [];
    const redis = {
      get: jest.fn(async (k: string) => {
        redisCalls.push(`get:${k}`);
        if (!redisUp) throw new Error('Connection is closed.');
        return null;
      }),
      set: jest.fn(async (k: string) => {
        // record only SUCCESSFUL writes: the point of 7f is that caching resumes
        // when Redis does, not that a call was attempted while it was down
        if (!redisUp) throw new Error('Connection is closed.');
        redisCalls.push(`set:${k}`);
        return 'OK';
      }),
      del: jest.fn(async (k: string) => {
        redisCalls.push(`del:${k}`);
        if (!redisUp) throw new Error('Connection is closed.');
        return 1;
      }),
      client: { ping: jest.fn(async () => 'PONG') },
    };
    const prisma = {
      withTenantQuery: jest.fn(async (gymId: string, fn: (tx: any) => Promise<any>) => {
        dbCalls.push(gymId);
        if (!dbUp) throw new Error('Timed out fetching a new connection string');
        const table = (fn as any).table || 'license';
        return fn({
          license: {
            findUnique: async () => ({
              status: 'ACTIVE',
              expiresAt: new Date(Date.now() + 86_400_000),
              gracePeriodDays: 7,
            }),
          },
          subscription: { findUnique: async () => ({ tier: 'PRO' }) },
        } as any);
      }),
    };
    const svc = new LicenseService(prisma as never, redis as never);
    return { svc, redis, prisma, redisCalls, dbCalls };
  }

  it('7. serves a second request from memory and hits the database once per tenant', async () => {
    const h = harness({ redisUp: false });
    const a = await h.svc.getStatus('gym-a');
    const b = await h.svc.getStatus('gym-a');
    expect(a.ok).toBe(true);
    expect(b).toEqual(a);
    // Redis down -> the database is the fallback, but only ONCE inside the TTL
    expect(h.dbCalls.filter((g) => g === 'gym-a').length).toBe(2); // license + subscription
    expect(h.redisCalls.filter((c) => c.startsWith('get:')).length).toBe(1);
  });

  it('7b. expires after the strict 30 s TTL', async () => {
    expect(TENANT_LICENCE_CACHE_TTL_MS).toBe(30_000);
    const h = harness({ redisUp: false });
    await h.svc.getStatus('gym-a');
    const first = h.dbCalls.length;
    await h.svc.getStatus('gym-a');
    expect(h.dbCalls.length).toBe(first); // still cached
    jest.advanceTimersByTime(TENANT_LICENCE_CACHE_TTL_MS + 10);
    await h.svc.getStatus('gym-a');
    expect(h.dbCalls.length).toBeGreaterThan(first); // TTL elapsed -> re-read
  });

  it('7c. never serves one tenant from another tenant entry', async () => {
    const h = harness({ redisUp: false });
    const a = await h.svc.getStatus('gym-a');
    const b = await h.svc.getStatus('gym-b');
    expect(a.ok).toBe(true);
    expect(b.ok).toBe(true);
    expect(h.dbCalls).toContain('gym-a');
    expect(h.dbCalls).toContain('gym-b');
    // two distinct tenants -> two distinct lookups, never a shared entry
    expect(h.dbCalls.filter((g) => g === 'gym-a').length).toBe(2);
    expect(h.dbCalls.filter((g) => g === 'gym-b').length).toBe(2);
  });

  it('7d. single-flight: concurrent misses for one tenant cause ONE lookup', async () => {
    const h = harness({ redisUp: false });
    const results = await Promise.all([
      h.svc.getStatus('gym-a'), h.svc.getStatus('gym-a'), h.svc.getStatus('gym-a'),
      h.svc.getStatus('gym-a'), h.svc.getStatus('gym-a'),
    ]);
    expect(results.every((r) => r.ok)).toBe(true);
    expect(h.dbCalls.filter((g) => g === 'gym-a').length).toBe(2);
  });

  it('7e. FAILS CLOSED when the database is unavailable — never treats it as permission', async () => {
    const h = harness({ redisUp: false, dbUp: false });
    const status = await h.svc.getStatus('gym-a');
    expect(status.ok).toBe(false);
    expect(status.features).toEqual([]);
    await expect(h.svc.assertFeature('gym-a', 'members' as any)).rejects.toThrow(/license_invalid/);
  });

  it('7f. resumes normal Redis caching on recovery', async () => {
    const down = harness({ redisUp: false });
    await down.svc.getStatus('gym-a');
    expect(down.redisCalls.filter((c) => c.startsWith('set:')).length).toBe(0);

    const up = harness({ redisUp: true });
    await up.svc.getStatus('gym-a');
    expect(up.redisCalls.filter((c) => c.startsWith('set:')).length).toBe(1);
    expect(up.redisCalls.some((c) => c.startsWith('set:license:gym-a'))).toBe(true);
  });

  it('7g. invalidateCache clears the in-process layer too', async () => {
    const h = harness({ redisUp: false });
    await h.svc.getStatus('gym-a');
    const before = h.dbCalls.length;
    await h.svc.invalidateCache('gym-a');
    await h.svc.getStatus('gym-a');
    expect(h.dbCalls.length).toBeGreaterThan(before);
  });
});

describe('PHASE P3 — license-check service: unreachable is not a pass, and not a refusal', () => {
  function checkHarness(opts: {
    redisUp: boolean;
    fetchMode: 'ok' | 'unreachable' | 'revoked' | 'expired';
    graceKey: boolean;
  }) {
    const events: string[] = [];
    const emitter = { emit: jest.fn((name: string) => { events.push(name); return true; }) } as any;
    const redis = {
      client: {
        exists: jest.fn(async () => {
          if (!opts.redisUp) throw new Error('Connection is closed.');
          return opts.graceKey ? 1 : 0;
        }),
        ttl: jest.fn(async () => {
          if (!opts.redisUp) throw new Error('Connection is closed.');
          return opts.graceKey ? 3600 : -2;
        }),
        set: jest.fn(async () => {
          if (!opts.redisUp) throw new Error('Connection is closed.');
          return 'OK';
        }),
      },
    } as any;
    const leadership = {
      acquireLock: jest.fn(async () => {
        if (!opts.redisUp) throw new Error('Connection is closed.');
        return true;
      }),
      releaseLock: jest.fn(async () => undefined),
    } as any;
    const state = new LicenceStateService();
    const svc = new LicenseCheckService(redis, emitter, leadership, state);
    const realFetch = global.fetch;
    global.fetch = (async () => {
      if (opts.fetchMode === 'unreachable') throw new Error('fetch failed');
      if (opts.fetchMode === 'revoked') {
        return { ok: false, json: async () => ({ code: 'REVOKED', message: 'revoked' }) } as any;
      }
      if (opts.fetchMode === 'expired') {
        return { ok: false, json: async () => ({ code: 'EXPIRED', message: 'License has expired.' }) } as any;
      }
      return { ok: true, json: async () => ({ gymName: 'Drill Gym', expiresAt: '2030-01-01' }) } as any;
    }) as any;
    return { svc, state, events, emitter, restore: () => { global.fetch = realFetch; } };
  }

  const KEY = 'FLEXORA_LICENSE_KEY';
  // PHASE Q3: the verification loop is inert unless enforcement is switched on.
  let restoreFlag: (() => void) | undefined;
  beforeEach(() => {
    process.env[KEY] = 'test-key-not-a-real-licence';
    process.env.REDIS_URL = 'redis://localhost:6379';
    restoreFlag = enforcementOn();
  });
  afterEach(() => { restoreFlag?.(); restoreFlag = undefined; });

  it('8. Redis down + server unreachable -> fails CLOSED with license.unverified, and the process stays up', async () => {
    const h = checkHarness({ redisUp: false, fetchMode: 'unreachable', graceKey: false });
    try {
      await h.svc.checkLicense();
      expect(h.state.isUnverified()).toBe(true);
      expect(h.events).toContain(LICENSE_UNVERIFIED_EVENT);
      // the pre-P3 behaviour: this situation emitted license.expired, which
      // main.ts answers with process.exit(1)
      expect(h.events).not.toContain(LICENSE_EXPIRED_EVENT);
    } finally { h.restore(); h.svc.onModuleDestroy(); }
  });

  it('8b. an UNREACHABLE server can never produce a refusal verdict', async () => {
    const h = checkHarness({ redisUp: true, fetchMode: 'unreachable', graceKey: true });
    try {
      await h.svc.checkLicense();
      expect(h.state.isRefused()).toBe(false);
      expect(h.events).not.toContain(LICENSE_EXPIRED_EVENT);
    } finally { h.restore(); h.svc.onModuleDestroy(); }
  });

  it('8f. PHASE Q3 — LIVE-REPRODUCED: Redis UP + no grace record + server UNREACHABLE stays up (was a shutdown 0.4 s after boot)', async () => {
    // This is the exact shape of a self-hosted deployment that boots while its
    // licence server is down: Redis is fine, the 48 h grace record does not exist
    // yet because the process has never verified. Before the fix this fell into the
    // authoritative branch and emitted license.expired, which main.ts answers with
    // app.close() + process.exit(1) — measured live in work/q3-evidence:
    //   error [LicenseCheck] License grace period expired or tampered. Shutting down.
    // i.e. a dependency outage crash-looped the container instead of answering 503.
    const h = checkHarness({ redisUp: true, fetchMode: 'unreachable', graceKey: false });
    try {
      await h.svc.checkLicense();
      // never an authoritative refusal, so never a shutdown
      expect(h.events).not.toContain(LICENSE_EXPIRED_EVENT);
      expect(h.state.isRefused()).toBe(false);
      // but never a pass either: licensed routes stay closed until it verifies
      expect(h.events).toContain(LICENSE_UNVERIFIED_EVENT);
      expect(h.state.isServingLicensedRoutes()).toBe(false);
      const guard = new LicenceAvailabilityGuard(h.state);
      let refused: unknown;
      try { guard.canActivate(httpContext('/api/members')); } catch (e) { refused = e; }
      expect(refused).toBeInstanceOf(ServiceUnavailableException);
      expect(((refused as ServiceUnavailableException).getResponse() as any).code).toBe(LICENCE_UNVERIFIED);
      // the liveness probe keeps answering either way
      expect(guard.canActivate(httpContext('/api/health/live'))).toBe(true);
    } finally { h.restore(); h.svc.onModuleDestroy(); }
  });

  it('8g. NEGATIVE CONTROL: an authoritative EXPIRED verdict with no grace record still shuts down', async () => {
    // 8f must not have weakened the refusal path: a real verdict from the licence
    // server keeps the pre-existing behaviour.
    const h = checkHarness({ redisUp: true, fetchMode: 'expired', graceKey: false });
    try {
      await h.svc.checkLicense();
      expect(h.events).toContain(LICENSE_EXPIRED_EVENT);
      expect(h.events).not.toContain(LICENSE_UNVERIFIED_EVENT);
      expect(h.state.isRefused()).toBe(true);
    } finally { h.restore(); h.svc.onModuleDestroy(); }
  });

  it('8h. NEGATIVE CONTROL: an unreachable server WITH a readable grace record keeps the pre-P3 grace and emits nothing', async () => {
    const h = checkHarness({ redisUp: true, fetchMode: 'unreachable', graceKey: true });
    try {
      await h.svc.checkLicense();
      expect(h.events).toEqual([]);
      expect(h.state.isRefused()).toBe(false);
    } finally { h.restore(); h.svc.onModuleDestroy(); }
  });

  it('8c. a REVOKED verdict still refuses and still shuts down (unchanged)', async () => {
    const h = checkHarness({ redisUp: true, fetchMode: 'revoked', graceKey: true });
    try {
      await h.svc.checkLicense();
      expect(h.state.isRefused()).toBe(true);
      expect(h.events).toContain(LICENSE_EXPIRED_EVENT);
      expect(h.events).not.toContain(LICENSE_UNVERIFIED_EVENT);
    } finally { h.restore(); h.svc.onModuleDestroy(); }
  });

  it('8d. a revoked licence followed by an outage stays revoked (never becomes valid)', async () => {
    const revoked = checkHarness({ redisUp: true, fetchMode: 'revoked', graceKey: true });
    try {
      await revoked.svc.checkLicense();
      expect(revoked.state.isRefused()).toBe(true);
    } finally { revoked.restore(); revoked.svc.onModuleDestroy(); }

    const outage = checkHarness({ redisUp: false, fetchMode: 'unreachable', graceKey: false });
    // same in-memory state object an actual process would carry across checks
    const shared = revoked.state;
    outage.state.markRefused('revoked');
    expect(shared.isRefused()).toBe(true);
    const expired = outage.state.markUnverified('redis-unavailable:unreachable');
    expect(expired).toBe(true);
    expect(outage.state.isRefused()).toBe(true);
    expect(outage.state.getState()).not.toBe('verified');
    outage.restore();
  });

  it('8e. recovery: a successful verification clears the unverified state with no restart', async () => {
    const down = checkHarness({ redisUp: false, fetchMode: 'unreachable', graceKey: false });
    try {
      await down.svc.checkLicense();
      expect(down.state.isUnverified()).toBe(true);
    } finally { down.restore(); down.svc.onModuleDestroy(); }

    const up = checkHarness({ redisUp: true, fetchMode: 'ok', graceKey: true });
    // simulate the same process: carry the state over
    up.state.markVerified();
    expect(up.state.isUnverified()).toBe(false);
    try {
      await up.svc.checkLicense();
      expect(up.state.getState()).toBe('verified');
      expect(up.events).not.toContain(LICENSE_UNVERIFIED_EVENT);
    } finally { up.restore(); up.svc.onModuleDestroy(); }
  });
});
