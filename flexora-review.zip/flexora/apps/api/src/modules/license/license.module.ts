/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * License module. The service + feature metadata live in ./license.service to
 * avoid a circular import between license.module and license.guard (the cycle
 * left LicenseService undefined at runtime inside Test.createTestingModule).
 */
import { Global, Module } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { PrismaModule } from '../../config/prisma.module';
import { RedisModule } from '../../config/redis.module';
import { LicenseService } from './license.service';
import { LicenseGuard } from './license.guard';
import { LicenseController } from './license.controller';
import { LicenceStateService } from './licence-state.service';
import { LicenseCheckService } from './license-check.service';
import { LICENSE_REQUIRED_ENV, isLicenceEnforcementRequired } from './licence-policy';

// Backward-compatible re-exports: existing importers do
//   import { RequiresFeature, LicenseService, FEATURE_KEY } from '.../license.module'
export {
  LicenseService,
  FEATURE_KEY,
  RequiresFeature,
} from './license.service';
export type { FeatureKey, LicenseStatus } from './license.service';

/**
 * PHASE Q3 — whether the global licence verification loop is registered AT ALL.
 *
 * EVALUATION TIME, stated plainly because it is the one subtle thing here: this
 * is read while this file is being imported, i.e. when the `@Module` decorator
 * runs. `src/config/load-env.ts` is the first import of `src/main.ts`, so
 * `apps/api/.env` is already in `process.env` by then, and a container/systemd
 * deployment supplies the variable before the process starts. Both are before
 * this line runs.
 *
 * `LicenseCheckService` carries the `@Cron` and the `onModuleInit` phone-home.
 * Not registering it is what makes `FLEXORA_LICENSE_REQUIRED=false` mean "no
 * licence request leaves this process", rather than "a request leaves it and the
 * answer is ignored". The service ALSO re-checks the flag at runtime (see its own
 * `onModuleInit`), so even a future refactor that registers it unconditionally
 * cannot start phoning home by accident.
 *
 * Every dependency `LicenseCheckService` needs is already resolvable here:
 * RedisModule (imported below) provides and exports both RedisService and
 * CronLeadershipService, EventEmitterModule.forRoot() is global, and
 * LicenceStateService is provided in this module.
 */
const LICENCE_ENFORCEMENT_ON = isLicenceEnforcementRequired();

// @Global() so the globally-registered APP_GUARD LicenseGuard can always
// resolve LicenseService — including inside Test.createTestingModule (e2e).
@Global()
@Module({
  imports: [PrismaModule, RedisModule],
  controllers: [LicenseController],
  // LicenceStateService is provided and exported here (this module is @Global)
  // so the PHASE P3 APP_GUARD LicenceAvailabilityGuard, the license-check cron and
  // the health controller all share ONE in-process instance of the state. It is
  // registered even when enforcement is off: it is inert without something calling
  // markVerified/markUnverified, and /api/health/ready reports from it.
  providers: [
    LicenseService,
    LicenseGuard,
    Reflector,
    LicenceStateService,
    // PHASE Q3 — registered ONLY when the operator asked for enforcement.
    ...(LICENCE_ENFORCEMENT_ON ? [LicenseCheckService] : []),
  ],
  exports: [LicenseService, LicenseGuard, LicenceStateService],
})
export class LicenseModule {
  /** Exposed for tests and for the boot log: is the verification loop wired? */
  static get licenceEnforcementEnabled(): boolean {
    return LICENCE_ENFORCEMENT_ON;
  }
  /** The variable that decided it, for logs. Never a value that is a secret. */
  static readonly enforcementSwitch = LICENSE_REQUIRED_ENV;
}
