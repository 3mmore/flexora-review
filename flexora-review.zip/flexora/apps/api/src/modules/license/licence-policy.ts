/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
/**
 * PHASE Q3 — is global licence enforcement switched on for this deployment?
 *
 * FLEXORA ships in two shapes and they need opposite defaults:
 *
 *   - SaaS (flexora.app): tenants are rows in one operator's database. There is
 *     no per-deployment licence to phone home about, and a global licence guard
 *     that fails closed would take the whole platform down when the licence
 *     server — a dependency no tenant ever chose — is unreachable. Enforcement
 *     must be OFF, and OFF must mean OFF: no verification request, no in-memory
 *     grace bookkeeping, no 503 LICENCE_UNVERIFIED, i.e. byte-for-byte the
 *     behaviour the product had before the PHASE P3 guard existed.
 *   - Self-hosted product: the deployment IS the licensed artefact, so the agreed
 *     PHASE P3 policy applies — verify in the background, serve only the two
 *     health probes until a verification succeeds, refuse every licensed route
 *     with 503 + Retry-After and the code LICENCE_UNVERIFIED, never let an
 *     unreachable server turn a REVOKED or EXPIRED licence into a valid one, and
 *     recover automatically (no restart) the moment verification succeeds.
 *
 * PHASE P3 built the second half and deliberately left it unwired, because wiring
 * it unconditionally would have 503'd every licensed route on every deployment
 * with no reachable licence server — including the owner's local run. PHASE Q3
 * adds the switch that makes wiring it safe: `FLEXORA_LICENSE_REQUIRED`,
 * DEFAULT FALSE.
 *
 * Read at call time, never cached at import time, so a test (or an operator
 * reloading config) sees the value that is actually set. The ONE place where it
 * must be read at import time is `license.module.ts`, which decides whether
 * `LicenseCheckService` is registered at all; that is documented there and pinned
 * by licence-required-flag.spec.ts.
 *
 * This file never logs or returns a licence key, a server URL or an expiry.
 */

/** The environment variable that switches global licence enforcement on. */
export const LICENSE_REQUIRED_ENV = 'FLEXORA_LICENSE_REQUIRED';

/** Values that mean "on". Anything else — including unset — means "off". */
const TRUTHY = new Set(['1', 'true', 'yes', 'on']);

/**
 * True only when the operator explicitly asked for enforcement. The default is
 * false, so a deployment that has never heard of this variable behaves exactly as
 * it did before it existed.
 */
export function isLicenceEnforcementRequired(env: NodeJS.ProcessEnv = process.env): boolean {
  return TRUTHY.has(normalise(env[LICENSE_REQUIRED_ENV]));
}

function normalise(raw: unknown): string {
  return String(raw ?? '')
    .trim()
    .toLowerCase();
}

/**
 * A non-empty value that is not a recognised boolean is almost certainly a typo,
 * and in this direction a typo silently DISABLES enforcement on a self-hosted
 * deployment. Returning a warning (rather than throwing) keeps the safe default
 * while making the mistake visible in the boot log. No value is echoed back —
 * only the variable name and the fact that it was not understood.
 */
export function licenceEnforcementWarning(env: NodeJS.ProcessEnv = process.env): string | null {
  const raw = String(env[LICENSE_REQUIRED_ENV] ?? '').trim();
  if (!raw) return null;
  if (TRUTHY.has(raw.toLowerCase())) return null;
  if (['0', 'false', 'no', 'off'].includes(raw.toLowerCase())) return null;
  return (
    `${LICENSE_REQUIRED_ENV} is set to a value that is not one of ` +
    `true/false/1/0/yes/no/on/off. Global licence enforcement is therefore OFF ` +
    `(the default). Set it to "true" to require a verified licence before ` +
    `licensed routes are served.`
  );
}

/** One-line description for boot logs. Contains no licence detail. */
export function describeLicenceEnforcement(env: NodeJS.ProcessEnv = process.env): string {
  return isLicenceEnforcementRequired(env)
    ? `${LICENSE_REQUIRED_ENV}=true — global licence enforcement ON: licensed routes are refused with 503 LICENCE_UNVERIFIED until a verification succeeds`
    : `${LICENSE_REQUIRED_ENV} unset or false — global licence enforcement OFF (SaaS default): no licence phone-home, no LICENCE_UNVERIFIED 503`;
}
