/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
/**
 * PHASE P3 — the global licence verification loop.
 *
 * What changed, and why (all four points were observed, not assumed):
 *
 *  1. FAIL CLOSED WHEN REDIS CANNOT BE READ. `checkGracePeriod()` used to catch a
 *     Redis error, log "System continues — will re-verify on next scheduled
 *     check" and RETURN TRUE. That turned "we cannot read the grace record" into
 *     "the licence is fine": losing Redis silently granted an unverified
 *     deployment a permanent pass. An unavailable check is never a permission, so
 *     it now hands the decision to the in-memory grace window in
 *     LicenceStateService and fails closed when that window is exhausted.
 *
 *  2. UNVERIFIABLE ≠ EXPIRED. When the licence server cannot be reached and the
 *     grace record cannot be read, this used to emit `license.expired`, which
 *     `main.ts` answers with `app.close()` + `process.exit(1)` — a network blip
 *     killed the process, including `/api/health/live`, the very endpoint an
 *     orchestrator uses to decide whether to restart it. That case now emits
 *     `license.unverified`: the process stays up, liveness/readiness keep
 *     answering, and every licensed route is refused with 503 + Retry-After
 *     (code LICENCE_UNVERIFIED) by LicenceAvailabilityGuard.
 *
 *  3. AN AUTHORITATIVE REFUSAL IS UNCHANGED. A missing FLEXORA_LICENSE_KEY, a
 *     REVOKED verdict, or a grace record that is gone/tampered with still emit
 *     `license.expired` and still shut the process down. Crucially, an
 *     UNREACHABLE server can never produce that state — the direction that
 *     matters is that a network failure must not be able to turn a revoked
 *     licence into a valid one, and it cannot: refusal paths are only reached
 *     from an actual HTTP response, or from a grace record that is definitively
 *     absent, never from a transport error.
 *
 *  4. AUTOMATIC RECOVERY, NO RESTART. Verification is retried with bounded
 *     exponential backoff (15 s → 30 s → 60 s → … → 5 min) while it is failing,
 *     in addition to the hourly cron. The first success calls
 *     `licenceState.markVerified()`, which clears the unverified state
 *     immediately, so the guarded routes start answering 200 again without a
 *     restart. The backoff timer is unref'd: it never keeps the process alive.
 *
 * Redis is used exactly as before for the 48 h grace record; nothing here logs a
 * licence key, a server URL or a token.
 */
import { envMode } from '../../config/env-mode';
import { Injectable, Logger, OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { randomBytes } from 'crypto';
import { RedisService } from '../../config/redis.service';
import { CronLeadershipService } from '../../common/services/cron-leadership.service';
import { requestContext } from '../../common/middleware/request-id.middleware';
import { LicenceStateService } from './licence-state.service';
import { isLicenceEnforcementRequired } from './licence-policy';

/** Emitted when the licence cannot be verified and the grace is exhausted. */
export const LICENSE_UNVERIFIED_EVENT = 'license.unverified';
/** Emitted on an authoritative refusal — unchanged pre-P3 behaviour. */
export const LICENSE_EXPIRED_EVENT = 'license.expired';

/**
 * PHASE Q3 — the ONE `checkGracePeriod` reason that is a TRANSPORT failure rather
 * than an authoritative verdict. Named and exported because the difference is the
 * whole policy: a transport failure must never reach the shutdown path, and the
 * spec pins it by this constant rather than by a string literal that could drift.
 */
export const LICENCE_UNREACHABLE = 'unreachable';

// First retry after 5 s: an operator watching licensed routes answer 503 should
// see them recover within seconds of the licence server coming back, not after a
// quarter of a minute.
const BACKOFF_FIRST_MS = 5_000;
/** Hard bound on one verification attempt. */
export const LICENCE_VERIFY_TIMEOUT_MS = Number(process.env.LICENCE_VERIFY_TIMEOUT_MS || 5000);
// Capped at 60 s: the state must clear promptly once the licence server is
// reachable again (the agreed behaviour is "retries with backoff in the
// background and clears the state automatically"), and a 5-minute tail meant an
// operator could watch licensed routes stay down for minutes after the
// dependency had already come back.
const BACKOFF_MAX_MS = 60_000;

@Injectable()
export class LicenseCheckService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger('LicenseCheck');
  private readonly LICENSE_SERVER = (() => {
    const configured = (process.env.LICENSE_SERVER_URL || 'https://license.flexora.app').replace(/\/$/, '');
    return configured.endsWith('/v1/verify') ? configured : `${configured}/v1/verify`;
  })();
  private readonly GRACE_HOURS = 48;
  private recoveryTimer?: NodeJS.Timeout;
  private recoveryAttempts = 0;

  private getLicenseKey(): string {
    return `flexora:${envMode()}:license:${process.env.FLEXORA_LICENSE_KEY || 'default'}:last_valid`;
  }

  constructor(
    private readonly redis: RedisService,
    private readonly eventEmitter: EventEmitter2,
    private readonly cronLeadership: CronLeadershipService,
    private readonly licenceState: LicenceStateService,
  ) {}

  /**
   * PHASE P3 — boot must NOT wait for the licence server.
   *
   * `await this.checkLicense()` here meant a 15 s fetch timeout (and, with Redis
   * also down, a lock error on top) ran BEFORE Nest finished initialising, so the
   * process listened on its port but answered nothing: measured live, every route
   * — including `/api/health/live` — hung for the whole curl timeout instead of
   * answering 200. Verification is now kicked off in the background; until it
   * succeeds the state is `unknown` and LicenceAvailabilityGuard refuses licensed
   * routes with 503 + Retry-After, which is the agreed fail-closed behaviour.
   */
  async onModuleInit() {
    // PHASE Q3 — second line of defence. `license.module.ts` does not register
    // this service at all unless FLEXORA_LICENSE_REQUIRED is true, so reaching
    // this branch means something changed the wiring; either way NO licence
    // request leaves a process whose operator did not ask for enforcement.
    if (!isLicenceEnforcementRequired()) {
      this.logger.log(
        'global licence verification is DISABLED (FLEXORA_LICENSE_REQUIRED is not true): ' +
          'no request will be made to the licence server and no route will be refused with LICENCE_UNVERIFIED',
      );
      return;
    }
    void this.checkLicense()
      .catch((e) => this.logger.warn(`initial licence check failed: ${(e as Error).message.slice(0, 160)}`))
      .then(() => this.scheduleRecoveryCheck());
  }

  onModuleDestroy() {
    if (this.recoveryTimer) clearTimeout(this.recoveryTimer);
    this.recoveryTimer = undefined;
  }

  /**
   * PHASE P3 — bounded retry with exponential backoff while verification is not
   * succeeding, so an operator does not have to restart the process to recover.
   */
  private scheduleRecoveryCheck(): void {
    if (this.recoveryTimer) {
      clearTimeout(this.recoveryTimer);
      this.recoveryTimer = undefined;
    }
    if (this.licenceState.getState() === 'verified') {
      this.recoveryAttempts = 0;
      return;
    }
    const delay = Math.min(BACKOFF_FIRST_MS * 2 ** this.recoveryAttempts, BACKOFF_MAX_MS);
    this.recoveryAttempts += 1;
    this.logger.warn(
      `licence not verified — next verification attempt in ${Math.round(delay / 1000)}s ` +
        `(attempt ${this.recoveryAttempts}; state=${this.licenceState.getState()})`,
    );
    this.recoveryTimer = setTimeout(() => {
      void this.checkLicense()
        .catch((e) => this.logger.warn(`recovery licence check failed: ${(e as Error).message.slice(0, 160)}`))
        .then(() => this.scheduleRecoveryCheck());
    }, delay);
    // never keep the event loop alive just to re-check a licence
    this.recoveryTimer.unref?.();
  }

  @Cron('0 * * * *')
  async checkLicense() {
    // PHASE Q3 — the hourly cron and the recovery retries both come through here.
    // Checked on every call rather than once at construction so that flipping the
    // variable in a test (or in a config reload) is honoured immediately.
    if (!isLicenceEnforcementRequired()) return undefined;
    return requestContext.run({ requestId: 'cron:license-check' }, async () => {
      // The leadership lock only avoids duplicated work across replicas. If Redis
      // is down it cannot be taken at all — and refusing to verify the licence
      // because a *lock* is unavailable would be exactly the fail-open mistake
      // this phase removes, so a lock error means "verify anyway" (the check is
      // idempotent and read-only towards the licence server).
      let proceed = false;
      try {
        proceed = await this.cronLeadership.acquireLock('license-check', 1800_000);
      } catch (lockErr) {
        this.logger.warn(
          `licence leadership lock unavailable (${(lockErr as Error).message.slice(0, 120)}) — verifying anyway`,
        );
        proceed = true;
      }
      if (!proceed) return;
      try {
        const key = process.env.FLEXORA_LICENSE_KEY;
        if (!key) {
          // Authoritative misconfiguration, not a transport failure: unchanged
          // pre-P3 behaviour (refuse and shut down).
          this.logger.error('FLEXORA_LICENSE_KEY not set.');
          this.logger.error('License invalid — initiating graceful shutdown.');
          this.licenceState.markRefused('no-key');
          this.eventEmitter.emit(LICENSE_EXPIRED_EVENT);
          return;
        }

        try {
          const res = await fetch(this.LICENSE_SERVER, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-Flexora-Version': process.env.APP_VERSION || '3.3.3',
            },
            body: JSON.stringify({
              key,
              domain: process.env.APP_DOMAIN || 'unknown',
              ts: Date.now(),
              nonce: randomBytes(16).toString('hex'),
            }),
            // PHASE P3: bounded, and short enough that the first verdict — and so
            // the moment licensed routes either open or answer 503 — arrives
            // quickly after boot instead of after a quarter of a minute.
            signal: AbortSignal.timeout(LICENCE_VERIFY_TIMEOUT_MS),
          });

          if (res.ok) {
            const data = (await res.json()) as { gymName: string; expiresAt: string };
            this.logger.log(`License OK: ${data.gymName} expires ${data.expiresAt}`);
            // PHASE P3 — clears any unverified state IMMEDIATELY, so guarded
            // routes start answering again without a restart.
            this.licenceState.markVerified();
            this.recoveryAttempts = 0;
            try {
              await this.redis.client.set(this.getLicenseKey(), '1', 'EX', this.GRACE_HOURS * 3600);
            } catch (e) {
              // The authoritative verdict is already known-good; failing to record
              // the grace copy is a warning, not a refusal.
              this.logger.warn(`Could not refresh license grace period in Redis: ${(e as Error).message.slice(0, 160)}`);
            }
            return;
          }

          const err = (await res.json().catch(() => ({ code: 'UNKNOWN', message: 'unparseable response' }))) as {
            code: string;
            message: string;
          };
          this.logger.error(`License error: ${err.message}`);
          if (err.code === 'REVOKED') {
            // Authoritative refusal — unchanged: no grace, shut down.
            this.logger.error('License revoked.');
            this.logger.error('License invalid — initiating graceful shutdown.');
            this.licenceState.markRefused('revoked');
            this.eventEmitter.emit(LICENSE_EXPIRED_EVENT);
            return;
          }
          // Any other authoritative verdict (EXPIRED, NOT_FOUND, TAMPERED, …) keeps
          // the pre-P3 path: serve from the recorded grace window, otherwise refuse.
          await this.checkGracePeriod(`verdict:${(err.code || 'unknown').slice(0, 40)}`);
        } catch {
          // Transport failure: the server could not be reached at all. This must
          // NEVER be treated as a refusal (that would let a network outage look
          // like a revoked licence) and never as a pass either.
          this.logger.warn('Cannot reach license server.');
          await this.checkGracePeriod(LICENCE_UNREACHABLE);
        }
      } finally {
        try {
          await this.cronLeadership.releaseLock('license-check');
        } catch {
          /* Redis down — the lock expires on its own TTL */
        }
      }
    });
  }

  /**
   * Decide what happens when the licence could not be verified just now.
   *
   *  - the Redis grace record is present and has a sane TTL -> keep serving,
   *    exactly as before (the pre-P3 48 h grace policy is preserved);
   *  - the record is missing or has no TTL (expired/tampered) AND the reason is an
   *    AUTHORITATIVE verdict (EXPIRED, NOT_FOUND, TAMPERED, …) -> refusal,
   *    unchanged: emit `license.expired` and shut down;
   *  - the record is missing and the reason is a TRANSPORT failure -> PHASE Q3:
   *    emit `license.unverified` and STAY UP. This branch is the bug the live Q3
   *    proof found: with enforcement on, Redis up and no grace record yet (the
   *    normal state of a process that has never verified), an unreachable licence
   *    server fell into the authoritative branch and the process killed itself
   *    0.4 s after boot — measured: `error [LicenseCheck] License grace period
   *    expired or tampered. Shutting down.` followed by exit(1), so the deployment
   *    crash-looped on a dependency outage instead of answering 503 and recovering
   *    by itself. A network failure is not a verdict about the licence;
   *  - Redis itself cannot be read -> PHASE P3: fail CLOSED through the in-memory
   *    grace window instead of the old "System continues" pass. When that window
   *    is exhausted (immediately, for a process that has never verified), emit
   *    `license.unverified`: the process stays up and licensed routes answer
   *    503 + Retry-After until verification succeeds.
   */
  private async checkGracePeriod(reason: string): Promise<boolean> {
    // PHASE Q3 — decided ONCE, here, so no branch below can mistake a transport
    // failure for a verdict.
    const transportFailure = reason === LICENCE_UNREACHABLE;
    try {
      const key = this.getLicenseKey();
      const exists = await this.redis.client.exists(key);
      const ttl = await this.redis.client.ttl(key);
      if (!exists || ttl < 0) {
        if (transportFailure) {
          // Stay up, fail closed on licensed routes, keep retrying. The state is
          // left exactly where LicenceStateService put it (`unknown` for a process
          // that never verified, `unverified` once the in-memory grace window is
          // exhausted) — both refuse licensed routes, and neither shuts the
          // process down, so /api/health/live keeps answering and the orchestrator
          // is not told to restart a container that can still serve.
          this.licenceState.markUnverified(`${LICENCE_UNREACHABLE}:no-grace-record`);
          this.logger.error(
            'Cannot reach the licence server and there is no grace record to serve from. ' +
              'Staying UP and failing CLOSED: /api/health/live and /api/health/ready keep answering, ' +
              'licensed routes answer 503 + Retry-After (LICENCE_UNVERIFIED), and verification is ' +
              'retried with backoff — the first success clears the state with no restart. ' +
              'An unreachable server is never treated as a revoked or expired licence.',
          );
          this.eventEmitter.emit(LICENSE_UNVERIFIED_EVENT);
          return false;
        }
        this.logger.error('License grace period expired or tampered. Shutting down.');
        this.logger.error('License invalid — initiating graceful shutdown.');
        this.licenceState.markRefused('grace-expired');
        this.eventEmitter.emit(LICENSE_EXPIRED_EVENT);
        return false;
      }
      this.logger.warn(`Grace period active: ${Math.round(ttl / 3600)}h remaining (reason: ${reason}).`);
      return true;
    } catch (redisErr) {
      const expired = this.licenceState.markUnverified(
        `redis-unavailable:${reason}`.slice(0, 80),
      );
      if (expired) {
        this.logger.error(
          `Redis unavailable during the licence grace check and the in-memory grace is exhausted ` +
            `(${(redisErr as Error).message.slice(0, 120)}). Failing CLOSED: licensed routes answer ` +
            `503 + Retry-After; the process stays up and keeps retrying with backoff.`,
        );
        this.eventEmitter.emit(LICENSE_UNVERIFIED_EVENT);
        return false;
      }
      this.logger.warn(
        `Redis unavailable during the licence grace check ` +
          `(${(redisErr as Error).message.slice(0, 120)}); serving from the in-memory grace window, ` +
          `${this.licenceState.graceRemainingSeconds()}s left before licensed routes fail closed.`,
      );
      return true;
    }
  }
}
