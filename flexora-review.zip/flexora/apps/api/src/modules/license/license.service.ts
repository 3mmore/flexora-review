/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * License management service (Phase 6).
 *
 * Validates a tenant's license on every request (cached in Redis).
 * Emits offline grace when the validation endpoint is unreachable.
 * Tracks renewals and feature gating.
 */
import {
  Injectable,
  Logger,
  ForbiddenException,
} from '@nestjs/common';
import { SetMetadata } from '@nestjs/common';
import { randomBytes } from 'crypto';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';

export type FeatureKey =
  | 'ai'
  | 'biometric'
  | 'campaigns'
  | 'leads'
  | 'multi_branch'
  | 'contracts'
  | 'staff_attendance'
  | 'webauthn'
  | 'priority_support'
  | 'classes'
  | 'pos'
  | 'inventory'
  | 'reports'
  | 'crm'
  | 'advanced_analytics'
  | 'white_label'
  | 'marketplace'
  | 'payroll'
  | 'enterprise';

const TIER_FEATURES: Record<string, FeatureKey[]> = {
  BASIC: [],
  PRO: ['multi_branch', 'classes', 'pos', 'inventory', 'reports', 'crm', 'leads', 'contracts', 'staff_attendance'],
  ELITE: [
    'multi_branch', 'classes', 'pos', 'inventory', 'reports', 'crm', 'ai', 'advanced_analytics', 'biometric', 'campaigns', 'leads',
    'contracts', 'staff_attendance', 'webauthn', 'priority_support', 'white_label', 'marketplace', 'payroll', 'enterprise',
  ],
};

export const FEATURE_KEY = 'requires_feature';
export const RequiresFeature = (f: FeatureKey) => SetMetadata(FEATURE_KEY, f);

export interface LicenseStatus {
  ok: boolean;
  reason?: 'expired' | 'suspended' | 'missing';
  expiresAt?: Date;
  graceUntil?: Date;
  features: FeatureKey[];
  tier?: string;
}

/**
 * PHASE P3 — strict TTL for the per-tenant, in-process licence cache.
 *
 * Redis stays the shared cache (300 s, as before). This second, in-process layer
 * exists because a Redis outage used to send EVERY request for a licensed route
 * straight to the database: with the cache down, one page load per user became
 * two tenant queries, and a Redis blip turned into a database stampede. 30 s is
 * short enough that a revocation or a plan change is picked up quickly, and long
 * enough that a Redis outage cannot amplify into a database outage.
 */
export const TENANT_LICENCE_CACHE_TTL_MS = Number(process.env.TENANT_LICENCE_CACHE_TTL_MS || 30_000);

@Injectable()
export class LicenseService {
  private readonly logger = new Logger(LicenseService.name);
  /** Per-tenant in-process cache. Keyed by tenant AND by everything the answer
   *  depends on, so no entry can ever be served across tenants or across a
   *  change in the tier/feature table. */
  private readonly localCache = new Map<string, { status: LicenseStatus; expiresAt: number }>();
  /** Single-flight: concurrent misses for the same tenant share ONE lookup. */
  private readonly inFlight = new Map<string, Promise<LicenseStatus>>();
  /** Fingerprint of the tier->feature table, so a code change to it invalidates
   *  every in-process entry instead of serving a stale feature list. */
  private readonly tierFingerprint = Object.keys(TIER_FEATURES)
    .sort()
    .map((tier) => `${tier}:${(TIER_FEATURES as Record<string, unknown>)[tier]}`)
    .join('|')
    .length.toString(36);

  constructor(
    private readonly prisma: PrismaService,
    private readonly redis: RedisService,
  ) {}

  private cacheKey(gymId: string) {
    return `license:${gymId}`;
  }

  private localKey(gymId: string) {
    return `${gymId}|${this.tierFingerprint}`;
  }

  async getStatus(gymId: string): Promise<LicenseStatus> {
    // 1. in-process cache (30 s, per tenant)
    const key = this.localKey(gymId);
    const hit = this.localCache.get(key);
    if (hit) {
      if (hit.expiresAt > Date.now()) return hit.status;
      this.localCache.delete(key);
    }
    // 2. single-flight: one lookup per tenant, however many requests arrive
    const pending = this.inFlight.get(key);
    if (pending) return pending;
    const started = this.loadStatus(gymId, key);
    this.inFlight.set(key, started);
    try {
      return await started;
    } finally {
      this.inFlight.delete(key);
    }
  }

  private remember(key: string, status: LicenseStatus): LicenseStatus {
    this.localCache.set(key, { status, expiresAt: Date.now() + TENANT_LICENCE_CACHE_TTL_MS });
    return status;
  }

  private async loadStatus(gymId: string, key: string): Promise<LicenseStatus> {
    try {
      const cached = await this.redis.get(this.cacheKey(gymId));
      if (cached) return this.remember(key, JSON.parse(cached) as LicenseStatus);
    } catch {
      // PHASE P3: Redis is unavailable -> fall through to the database (the source
      // of truth) instead of failing the request. Recovery is automatic: the next
      // successful call writes the Redis entry again.
    }

    // Use withTenantQuery to ensure app.gym_id is set for RLS-protected tables.
    // PHASE P3: a database error or timeout here is a DENIAL, not a 500 and never
    // a pass — an unavailable licence check must not be treated as permission.
    let license: { status: string; expiresAt: Date; gracePeriodDays: number } | null = null;
    let sub: { tier?: string } | null = null;
    try {
      license = await this.prisma.withTenantQuery(gymId, (tx) => tx.license.findUnique({ where: { gymId } }));
      if (license) {
        sub = await this.prisma.withTenantQuery(gymId, (tx) => tx.subscription.findUnique({ where: { gymId } }));
      }
    } catch (err) {
      this.logger.error(
        `licence lookup failed for a tenant — FAILING CLOSED (denying protected features): ${String(
          (err as Error)?.message || err,
        ).slice(0, 160)}`,
      );
      // cached for the same short TTL so a database outage cannot stampede either
      return this.remember(key, { ok: false, features: [] });
    }

    if (!license) {
      return this.remember(key, { ok: false, reason: 'missing', features: [] });
    }

    const features = TIER_FEATURES[sub?.tier || 'BASIC'] || [];
    const status: LicenseStatus = {
      ok: license.status === 'ACTIVE',
      reason: license.status === 'SUSPENDED' ? 'suspended' : undefined,
      expiresAt: license.expiresAt,
      features,
      tier: sub?.tier,
    };
    if (license.status === 'ACTIVE' && license.expiresAt < new Date()) {
      const graceUntil = new Date(license.expiresAt);
      graceUntil.setDate(graceUntil.getDate() + license.gracePeriodDays);
      status.ok = graceUntil > new Date();
      if (!status.ok) status.reason = 'expired';
      status.graceUntil = graceUntil;
    }
    this.remember(key, status);
    try {
      await this.redis.set(this.cacheKey(gymId), JSON.stringify(status), 300);
    } catch {
      /* Redis down: the in-process entry still serves this tenant for <=30 s */
    }
    return status;
  }

  async assertFeature(gymId: string, feature: FeatureKey): Promise<void> {
    const status = await this.getStatus(gymId);
    if (!status.ok) {
      throw new ForbiddenException(
        status.reason === 'expired' ? 'license_expired' : 
        status.reason === 'suspended' ? 'license_suspended' : 'license_invalid'
      );
    }
    if (!status.features.includes(feature)) {
      throw new ForbiddenException('feature_upgrade_required');
    }
  }

  async invalidateCache(gymId: string) {
    // PHASE P3: the in-process layer must be dropped too, otherwise an explicit
    // invalidation (a plan change, a revocation) would still be served stale for
    // up to the TTL — which is exactly the cross-context leak the cache must not
    // have.
    this.localCache.delete(this.localKey(gymId));
    try {
      await this.redis.del(this.cacheKey(gymId));
    } catch {
      /* Redis down: nothing shared to invalidate; the local entry is already gone */
    }
  }

  async renew(_gymId: string, _durationDays: number, _renewedBy: string, _notes?: string): Promise<never> {
    throw new Error('NOT_IMPLEMENTED');
  }

  async generate(gymId: string, opts: {
    seats?: number; branchesAllowed?: number; durationDays?: number;
    customerName?: string; customerEmail?: string; customerPhone?: string;
  }) {
    const block = () =>
      Array.from({ length: 3 }, () => randomBytes(2).toString('hex').toUpperCase()).join('-');
    const key = `FLEX-${block()}`;
    const expiresAt = new Date(Date.now() + (opts.durationDays || 365) * 86400000);
    return this.prisma.license.upsert({
      where: { gymId },
      update: {
        key,
        status: 'ACTIVE',
        seats: opts.seats || 25,
        branchesAllowed: opts.branchesAllowed || 5,
        expiresAt,
        customerName: opts.customerName,
        customerEmail: opts.customerEmail,
        customerPhone: opts.customerPhone,
        lastValidatedAt: new Date(),
      },
      create: {
        gymId,
        key,
        status: 'ACTIVE',
        seats: opts.seats || 25,
        branchesAllowed: opts.branchesAllowed || 5,
        expiresAt,
        customerName: opts.customerName,
        customerEmail: opts.customerEmail,
        customerPhone: opts.customerPhone,
      },
    });
  }
}
