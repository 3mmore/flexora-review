import { CanActivate, ExecutionContext, ForbiddenException, Injectable } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { FEATURE_KEY, FeatureKey, LicenseService } from './license.service';
import { IS_PUBLIC_KEY } from '../../common/decorators/public.decorator';

@Injectable()
export class LicenseGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly license: LicenseService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const feature = this.reflector.getAllAndOverride<FeatureKey | undefined>(FEATURE_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (!feature) return true;

    // Respect @Public() decorator — if the route handler is marked public,
    // skip the license feature check (same pattern as JwtAuthGuard).
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPublic) return true;

    const req = context.switchToHttp().getRequest();
    const user = req.user;
    if (user?.role === 'SUPER_ADMIN') return true;
    const gymId = req.gymId || user?.gymId;
    // Without a tenant context we cannot evaluate the license. Deny cleanly
    // (4xx) instead of calling assertFeature(undefined), which would hit Prisma
    // with where:{gymId:undefined} and surface as a 500.
    if (!gymId) throw new ForbiddenException('User is not bound to a gym');
    await this.license.assertFeature(gymId, feature);
    return true;
  }
}
