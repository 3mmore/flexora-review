/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Trial lifecycle middleware (Phase 7).
 *
 * On every authenticated request it:
 *   1. Looks at the gym's Subscription row.
 *   2. If TRIALING, computes days remaining.
 *   3. Adds X-Trial-Warning response header with daysLeft.
 *   4. If expired and not paid, redirects in metadata
 *      (the controller decides what to do with 402).
 */
import { Injectable, Logger, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { PrismaService } from '../../config/prisma.service';

@Injectable()
export class TrialMiddleware implements NestMiddleware {
  private readonly logger = new Logger(TrialMiddleware.name);
  constructor(private readonly prisma: PrismaService) {}

  async use(req: Request, res: Response, next: NextFunction) {
    const request = req as Request & { user?: { role: string; gymId: string }; gymId?: string; trialDaysLeft?: number };
    const user = request.user;
    if (!user || user.role === 'SUPER_ADMIN') return next();

    const gymId = request.gymId || user.gymId;
    if (!gymId) return next();

    try {
      const sub = await this.prisma.subscription.findUnique({ where: { gymId } });
      if (!sub) return next();

      // First-time trial activation
      if (sub.status === 'TRIALING' && !sub.trialStartDate) {
        const start = new Date();
        const end = new Date(start);
        end.setDate(end.getDate() + sub.trialDays);
        const activated = await this.prisma.subscription.updateMany({
          where: { gymId, status: 'TRIALING', trialStartDate: null },
          data: {
            trialStartDate: start,
            trialEndDate: end,
            isTrialUsed: true,
          },
        });
        if (activated.count === 1) {
          sub.trialStartDate = start;
          sub.trialEndDate = end;
        }
      }

      if (sub.status === 'TRIALING' && sub.trialEndDate) {
        const daysLeft = Math.max(
          0,
          Math.ceil((sub.trialEndDate.getTime() - Date.now()) / 86400000),
        );
        res.setHeader('X-Trial-Warning', JSON.stringify({ daysLeft, status: sub.status }));
        request.trialDaysLeft = daysLeft;

        if (daysLeft <= 0) {
          // Mark the subscription as past-due; the controller / frontend
          // can decide whether to return 402 Payment Required.
          await this.prisma.subscription.updateMany({
            where: { gymId, status: 'TRIALING' },
            data: { status: 'PAST_DUE' },
          });
        } else if (daysLeft <= 3) {
          this.logger.warn(
            `Trial ending soon for gym=${gymId} — ${daysLeft} day(s) left`,
          );
        }
      }
    } catch (e) {
      this.logger.warn(`Trial middleware error: ${(e as Error).message}`);
    }
    next();
  }
}
