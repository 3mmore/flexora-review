/**
 * PACK 2 · STEP 2a — the QR signing key must never be a guessable constant.
 *
 * The first release signed with `SELF_CHECKIN_SECRET || JWT_ACCESS_SECRET ||
 * 'dev-only'`. On a process with neither variable set, every entrance QR in the
 * world was signed with a string printed in the source tree, and a member who
 * read the repository could mint a token for any gym. These tests pin the fix:
 * empty is still SAFE when JWT_ACCESS_SECRET exists (it is not random, not
 * per-process, and does not die on restart), and it REFUSES when nothing exists.
 */
import { BadRequestException, ServiceUnavailableException } from '@nestjs/common';
import { deriveQrSecret, qrSecretState } from './self-checkin-secret.check';
import { SelfCheckinService } from './self-checkin.service';

function service() {
  // the QR paths under test use only the secret helpers; the constructor deps
  // are never touched
  return new SelfCheckinService(null as never, null as never, null as never, null as never);
}

const saved = { ...process.env };
afterAll(() => {
  process.env = saved;
});

describe('qr signing key — what "empty" actually means', () => {
  beforeEach(() => {
    delete process.env.SELF_CHECKIN_SECRET;
    delete process.env.JWT_ACCESS_SECRET;
  });

  it('a dedicated secret is used when set', () => {
    process.env.SELF_CHECKIN_SECRET = 'dedicated-secret-value';
    process.env.JWT_ACCESS_SECRET = 'access-secret-value';
    expect(qrSecretState().source).toBe('SELF_CHECKIN_SECRET');
    expect(service().qrAvailable()).toBe(true);
  });

  it('empty derives from JWT_ACCESS_SECRET — stable, not per-process, survives restart', () => {
    process.env.JWT_ACCESS_SECRET = 'access-secret-value';
    const a = qrSecretState();
    expect(a.ok).toBe(true);
    expect(a.source).toBe('JWT_ACCESS_SECRET');
    // the warning is informative, never a refusal
    expect(a.warning).toMatch(/SELF_CHECKIN_SECRET is empty/);
    expect(a.warning).not.toContain('access-secret-value');
  });

  it('the derivation is a PURE function of the environment — no per-process randomness', () => {
    process.env.JWT_ACCESS_SECRET = 'access-secret-value';
    // same env, two independent calls: identical key. A per-process random or a
    // time-seeded value would diverge here.
    expect(deriveQrSecret()).toBe(deriveQrSecret());
    // ...and a different access secret yields a different key
    process.env.JWT_ACCESS_SECRET = 'another-access-secret';
    expect(deriveQrSecret()).not.toBe('flexora-self-checkin:access-secret-value');
    // ...and a dedicated secret takes precedence and is domain-separated
    process.env.SELF_CHECKIN_SECRET = 'dedicated';
    expect(deriveQrSecret()).toBe('flexora-self-checkin:dedicated');
  });

  // NOTE: cross-PROCESS behaviour (a token minted before a restart still
  // verifying after it) is proven live in gate 1c — work/item5-smoke.mjs mints,
  // restarts the API, and re-scans — because an in-process test cannot honestly
  // claim to have restarted anything.

  it('with NEITHER variable, minting refuses with Arabic and a stable code', async () => {
    const svc = service();
    expect(svc.qrAvailable()).toBe(false);
    // mintEntranceToken checks the branch first, so this asserts the guard that
    // runs before any signing: the secret accessor itself
    const anySvc = svc as unknown as { secretOrRefuse: () => string };
    let thrown: unknown;
    try {
      anySvc.secretOrRefuse();
    } catch (e) {
      thrown = e;
    }
    expect(thrown).toBeInstanceOf(ServiceUnavailableException);
    const body = (thrown as ServiceUnavailableException).getResponse() as {
      code: string;
      message: string;
    };
    expect(body.code).toBe('SELF_CHECKIN_QR_UNAVAILABLE');
    // Arabic, and it names the variable the operator must set
    expect(body.message).toMatch(/[\u0600-\u06FF]/);
    expect(body.message).toContain('SELF_CHECKIN_SECRET');
  });

  it('with NEITHER variable, scanning refuses with the SAME code before parsing the token', () => {
    const svc = service();
    let thrown: unknown;
    try {
      svc.verifyToken('garbage');
    } catch (e) {
      thrown = e;
    }
    expect(thrown).toBeInstanceOf(ServiceUnavailableException);
    expect((thrown as ServiceUnavailableException).getResponse()).toMatchObject({
      code: 'SELF_CHECKIN_QR_UNAVAILABLE',
    });
    // and NOT the generic "invalid token" refusal, which would hide the cause
    expect(thrown).not.toBeInstanceOf(BadRequestException);
  });

  it('a whitespace-only value counts as empty (no accidental " " secret)', () => {
    process.env.SELF_CHECKIN_SECRET = '   ';
    process.env.JWT_ACCESS_SECRET = 'access-secret-value';
    expect(qrSecretState().source).toBe('JWT_ACCESS_SECRET');
  });

  it('the boot line never contains the secret value', () => {
    process.env.SELF_CHECKIN_SECRET = 'super-secret-do-not-log';
    const state = qrSecretState();
    expect(JSON.stringify(state)).not.toContain('super-secret-do-not-log');
  });
});
