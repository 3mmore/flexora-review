/**
 * PACK 2 · ITEM 5 — the pure part of self check-in, unit-tested without a database.
 *
 * The integration spec (self-checkin.spec.ts) proves the flows; this file pins the
 * arithmetic that is easy to get quietly wrong and impossible to see on screen:
 * CIDR matching, the haversine distance, and the token's signature and expiry.
 */
import { SelfCheckinService } from './self-checkin.service';

// the class only needs these collaborators for the methods used here
const svc = new SelfCheckinService(
  null as never,
  { client: { get: async () => null, set: async () => 'OK' } } as never,
  null as never,
  null as never,
);

const { ipAllowed, distanceMeters } = SelfCheckinService;

describe('ipAllowed — exact addresses and CIDR blocks', () => {
  it('accepts an exact address', () => {
    expect(ipAllowed('41.33.10.7', ['41.33.10.7'])).toBe(true);
    expect(ipAllowed('41.33.10.8', ['41.33.10.7'])).toBe(false);
  });

  it('accepts and rejects inside a /16', () => {
    expect(ipAllowed('41.33.255.255', ['41.33.0.0/16'])).toBe(true);
    expect(ipAllowed('41.34.0.0', ['41.33.0.0/16'])).toBe(false);
  });

  it('handles the edge blocks /32 and /0', () => {
    expect(ipAllowed('10.0.0.1', ['10.0.0.1/32'])).toBe(true);
    expect(ipAllowed('10.0.0.2', ['10.0.0.1/32'])).toBe(false);
    expect(ipAllowed('8.8.8.8', ['0.0.0.0/0'])).toBe(true);
  });

  it('sees through an IPv4-mapped IPv6 address', () => {
    expect(ipAllowed('::ffff:41.33.10.7', ['41.33.10.7'])).toBe(true);
    expect(ipAllowed('::ffff:41.33.10.7', ['41.33.0.0/16'])).toBe(true);
  });

  it('refuses an empty address, an empty list and junk', () => {
    expect(ipAllowed('', ['1.2.3.4'])).toBe(false);
    expect(ipAllowed(null, ['1.2.3.4'])).toBe(false);
    expect(ipAllowed('1.2.3.4', [])).toBe(false);
    expect(ipAllowed('1.2.3.4', ['not-an-ip'])).toBe(false);
    // a bad prefix length is a typo, not an exact match (found by this test)
    expect(ipAllowed('1.2.3.4', ['1.2.3.4/99'])).toBe(false);
    expect(ipAllowed('1.2.3.4', ['1.2.3/8'])).toBe(false);
  });

  it('matches ANY entry in the list, not only the first', () => {
    expect(ipAllowed('5.5.5.5', ['1.1.1.1', '5.5.5.5'])).toBe(true);
  });
});

describe('distanceMeters — haversine', () => {
  it('is zero for the same point', () => {
    expect(distanceMeters({ lat: 30.0444, lng: 31.2357 }, { lat: 30.0444, lng: 31.2357 })).toBeLessThan(0.001);
  });

  it('is ~111 km for one degree of latitude', () => {
    const d = distanceMeters({ lat: 30, lng: 31 }, { lat: 31, lng: 31 });
    expect(d).toBeGreaterThan(111_000);
    expect(d).toBeLessThan(111_300);
  });

  it('shrinks with latitude for a degree of longitude (Cairo vs the equator)', () => {
    const cairo = distanceMeters({ lat: 30.0444, lng: 31 }, { lat: 30.0444, lng: 32 });
    const equator = distanceMeters({ lat: 0, lng: 31 }, { lat: 0, lng: 32 });
    expect(cairo).toBeLessThan(equator);
    expect(equator / cairo).toBeGreaterThan(1.1);   // ~1.15 at Cairo's latitude
  });

  it('is symmetric', () => {
    const a = { lat: 30.1, lng: 31.2 };
    const b = { lat: 30.2, lng: 31.35 };
    expect(distanceMeters(a, b)).toBeCloseTo(distanceMeters(b, a), 6);
  });
});

describe('the entrance token', () => {
  const gym = 'gym_1';
  const branch = 'br_1';

  it('round-trips a freshly minted token', () => {
    const fake = new SelfCheckinService(
      { branch: { findFirst: async () => ({ id: branch }) } } as never,
      { client: { get: async () => null, set: async () => 'OK' } } as never,
      null as never,
      null as never,
    );
    return fake.mintEntranceToken(gym, branch).then(({ token, ttl }) => {
      expect(ttl).toBe(120);
      const payload = fake.verifyToken(token);
      expect(payload.gymId).toBe(gym);
      expect(payload.branchId).toBe(branch);
      expect(payload.exp * 1000).toBeGreaterThan(Date.now());
      expect(payload.exp * 1000).toBeLessThanOrEqual(Date.now() + 121_000);
    });
  });

  it('rejects a tampered, truncated or foreign token', () => {
    expect(() => svc.verifyToken('flx1.a.b.1.c.d')).toThrow();      // bad signature
    expect(() => svc.verifyToken('flx1.a.b')).toThrow();            // wrong shape
    expect(() => svc.verifyToken('')).toThrow();
    expect(() => svc.verifyToken('flx2.a.b.1.c.d')).toThrow();      // wrong scheme
  });
});
