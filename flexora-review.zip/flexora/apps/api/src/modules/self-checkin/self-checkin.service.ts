/**
 * PACK 2 · ITEM 5 — member self check-in: the service.
 *
 * HONEST SCOPE, stated in the code because it is the whole point of this file:
 * a web page cannot detect that a person walked in. Every mode below is a
 * DECLARATION with evidence attached, and the evidence is worth exactly the
 * table in evidence/15-SELFCHECKIN-MEASURE.md says it is:
 *
 *   the entrance QR     proves the caller holds a live token — a photograph of a
 *                       live token is the residual risk, which is why the token
 *                       lives 120 seconds and can be spent once per member
 *   the gym network     proves the request came from the gym's egress IP; a VPN
 *                       or mobile data defeats it
 *   geolocation         proves where the DEVICE says it is; mock locations are a
 *                       developer setting away
 *   plain "I arrived"   proves nothing but that a button was pressed, and the
 *                       product says so
 *
 * NOTHING HERE CHECKS ANYONE IN BY ITSELF. It validates the evidence, derives the
 * source SERVER-SIDE, and then calls the existing AttendanceService.checkin —
 * the SAME core the staff screen and the kiosk use, with the same membership
 * gates. There is deliberately no second copy of the check-in rules.
 */
import { createHmac, timingSafeEqual } from 'node:crypto';
import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  ServiceUnavailableException,
  NotFoundException,
} from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';
import { deriveQrSecret } from './self-checkin-secret.check';
import { RedisService } from '../../config/redis.service';
import { TenantContextService } from '../../common/services/tenant-context.service';
import { AttendanceService } from '../attendance/attendance.service';

/**
 * The allowlist. Mirrored by the DB CHECK ("Attendance_source_check_v2") and the
 * query validator. Adding a value is a MIGRATION, not a type edit: see
 * prisma/migrations/20261117090000_pack2_self_plain_source.
 */
export const ATTENDANCE_SOURCES = [
  'SELF_QR',     // entrance QR, signed + expiring + one-shot
  'SELF_IP',     // gym network allowlist matched
  'SELF_GEO',    // geolocation radius matched
  'SELF_IP_GEO', // both gates matched
  'SELF_PLAIN',  // self check-in with NO verification (owner decision 2026-11-17)
  'STAFF',       // a person at the desk checked the member in
  'KIOSK',       // the gym's self-service kiosk
] as const;
export type AttendanceSource = (typeof ATTENDANCE_SOURCES)[number];

/** GymSettings keys. No row = OFF, so OFF is the default without a migration. */
export const SETTING_ENABLED = 'selfCheckin.enabled';
export const SETTING_IP_LIST = 'selfCheckin.ipList';
export const SETTING_GEO = 'selfCheckin.geo';
export const SETTING_TOKEN = 'selfCheckin.qrToken';

/** How long an entrance token stays valid. Short on purpose: see the header. */
export const TOKEN_TTL_SECONDS = 120;

/** A member who checks in twice inside this window gets the SAME row back. */
export const IDEMPOTENT_WINDOW_MINUTES = 10;

export interface SelfCheckinConfig {
  enabled: boolean;
  hasEntranceQr: boolean;
  modes: { qr: boolean; network: boolean; geolocation: boolean; plain: boolean };
  /** metres, when geolocation is configured */
  radiusMeters: number | null;
  networkConfigured: boolean;
  /**
   * STEP 2a — false when this process has no QR signing key at all (neither
   * SELF_CHECKIN_SECRET nor JWT_ACCESS_SECRET). The settings screen uses it to
   * say so in Arabic instead of showing a QR that would be refused.
   */
  qrAvailable: boolean;
}

export interface EntranceTokenPayload {
  gymId: string;
  branchId: string;
  exp: number; // unix seconds
  nonce: string;
}

const b64url = (buf: Buffer) => buf.toString('base64url');
const sign = (secret: string, body: string) =>
  b64url(createHmac('sha256', secret).update(body).digest());

@Injectable()
export class SelfCheckinService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly redis: RedisService,
    private readonly tenantContext: TenantContextService,
    private readonly attendance: AttendanceService,
  ) {}

  /**
   * The QR signing key, or NULL when the deployment has not given us one.
   *
   * STEP 2a (2026-11-17). The first version read
   *   SELF_CHECKIN_SECRET || JWT_ACCESS_SECRET || 'dev-only'
   * and the last term was the problem: on a process started with NEITHER
   * variable set, every entrance QR on earth would have been signed with a
   * string that is in the source tree. A member who read this file could mint a
   * token for any gym. Nothing logged a word about it.
   *
   * Measured facts about the empty case, before changing anything:
   *   • empty SELF_CHECKIN_SECRET is NOT per-process random and does NOT die on
   *     restart — it falls through to JWT_ACCESS_SECRET, which the production
   *     boot validator REQUIRES (env-validation.REQUIRED_ENV) and which is the
   *     same in every replica;
   *   • so empty is safe as long as JWT_ACCESS_SECRET exists. It is only unsafe
   *     when BOTH are empty, which production refuses at boot and development
   *     silently allowed.
   *
   * The `|| 'dev-only'` term is therefore gone. With no key, minting and
   * verifying REFUSE with an Arabic message and a stable machine code, and the
   * settings screen says QR is unavailable and offers the other two methods.
   * Nothing is signed with a guessable key, ever.
   */
  private secret(): string | null {
    return deriveQrSecret();
  }

  /** Throws the Arabic, machine-coded refusal used by both QR paths. */
  private secretOrRefuse(): string {
    const secret = this.secret();
    if (secret) return secret;
    throw new ServiceUnavailableException({
      code: 'SELF_CHECKIN_QR_UNAVAILABLE',
      // Arabic, and it names the fix without naming a secret
      message:
        'رمز QR غير متاح لأن الخادم لم يُضبط مفتاح التوقيع. استخدم «وصلت» أو شبكة الصالة، أو اطلب من المسؤول ضبط SELF_CHECKIN_SECRET.',
    });
  }

  /** True when this process can sign and verify entrance QR tokens. */
  qrAvailable(): boolean {
    return this.secret() !== null;
  }

  // ── settings ──────────────────────────────────────────────────────────────

  private async raw(gymId: string, key: string): Promise<string | null> {
    return this.tenantContext.run(gymId, async () => {
      const row = await this.prisma.gymSettings.findFirst({ where: { gymId, key }, select: { value: true } });
      return row?.value ?? null;
    }) as Promise<string | null>;
  }

  /**
   * Read the gym's settings.
   *
   * These rows are FORCE-RLS protected like every other tenant table, so this
   * read MUST run inside the gym's tenant context — the member route has no
   * TenantGuard to set one, and without this the member would always be told
   * "not enabled" (found live: the owner switched it on and the member's portal
   * still showed it off).
   */
  async config(gymId: string): Promise<SelfCheckinConfig> {
    return this.tenantContext.run(gymId, () => this.configInTenant(gymId));
  }

  private async configInTenant(gymId: string): Promise<SelfCheckinConfig> {
    const settings = await this.prisma.gymSettings.findMany({
      where: {
        gymId,
        key: { in: [SETTING_ENABLED, SETTING_IP_LIST, SETTING_GEO, SETTING_TOKEN] },
      },
      select: { key: true, value: true },
    });
    const map = new Map(settings.map((s) => [s.key, s.value]));
    const enabled = map.get(SETTING_ENABLED) === 'true';
    const ipList = String(map.get(SETTING_IP_LIST) ?? '')
      .split(/[\s,]+/).filter(Boolean);
    let geo: { lat?: number; lng?: number; radiusMeters?: number } | null = null;
    try {
      const raw = map.get(SETTING_GEO);
      geo = raw ? JSON.parse(raw) : null;
    } catch { geo = null; }
    const radius = typeof geo?.radiusMeters === 'number' ? geo.radiusMeters : null;
    return {
      enabled,
      hasEntranceQr: Boolean(map.get(SETTING_TOKEN)),
      modes: {
        qr: Boolean(map.get(SETTING_TOKEN)),
        network: ipList.length > 0,
        geolocation: radius !== null,
        // the plain button is always offered when the feature is on: it is the
        // mode with the least evidence, and the member is told so
        plain: enabled,
      },
      radiusMeters: radius,
      networkConfigured: ipList.length > 0,
      qrAvailable: this.qrAvailable(),
    };
  }

  /** Owner-only settings write. Everything is validated here, then stored. */
  async updateSettings(
    gymId: string,
    actorId: string,
    input: {
      enabled?: boolean;
      ipList?: string;
      geo?: { lat: number; lng: number; radiusMeters: number } | null;
      regenerateToken?: boolean;
    },
  ) {
    const ipList = input.ipList?.trim();
    if (ipList) {
      const entries = ipList.split(/[\s,]+/).filter(Boolean);
      for (const entry of entries) {
        // IPv4/IPv6 address, or a CIDR block. No hostnames: resolving them at
        // check-in time would make the allowlist depend on DNS.
        if (!/^[0-9a-fA-F:.]+(\/\d{1,3})?$/.test(entry)) {
          throw new BadRequestException({ code: 'INVALID_IP', message: `not an address: ${entry}` });
        }
        // and the prefix length must be possible for that family: /99 on an
        // IPv4 block is a typo that would otherwise silently mean something
        const [base, bitsRaw] = entry.split('/');
        if (bitsRaw !== undefined) {
          const max = base.includes(':') ? 128 : 32;
          const bits = Number(bitsRaw);
          if (!Number.isInteger(bits) || bits < 0 || bits > max) {
            throw new BadRequestException({ code: 'INVALID_IP', message: `bad prefix length: ${entry}` });
          }
        }
      }
    }
    if (input.geo) {
      const { lat, lng, radiusMeters } = input.geo;
      if (!(lat >= -90 && lat <= 90) || !(lng >= -180 && lng <= 180)) {
        throw new BadRequestException({ code: 'INVALID_GEO', message: 'coordinates out of range' });
      }
      if (!(radiusMeters >= 20 && radiusMeters <= 5000)) {
        throw new BadRequestException({ code: 'INVALID_RADIUS', message: 'radius must be 20..5000 m' });
      }
    }

    const writes: Array<[string, string]> = [];
    if (input.enabled !== undefined) writes.push([SETTING_ENABLED, String(input.enabled)]);
    if (ipList !== undefined) writes.push([SETTING_IP_LIST, ipList]);
    if (input.geo !== undefined) {
      writes.push([SETTING_GEO, input.geo ? JSON.stringify(input.geo) : '']);
    }
    if (input.regenerateToken) {
      // a stable value the QR encodes; rotating it invalidates every printed code
      writes.push([SETTING_TOKEN, b64url(createHmac('sha256', this.secretOrRefuse()).update(`${gymId}:${Date.now()}`).digest()).slice(0, 16)]);
    }
    await this.tenantContext.run(gymId, async () => {
    for (const [key, value] of writes) {
      await this.prisma.gymSettings.upsert({
        where: { gymId_key: { gymId, key } },
        create: { gymId, key, value },
        update: { value },
      });
    }
    // who turned it on, and when — this is a security-relevant switch
    await this.prisma.auditLog.create({
      data: {
        gymId, userId: actorId, action: 'self_checkin.settings', entity: 'GymSettings',
        metadata: { changed: writes.map(([k]) => k), enabled: input.enabled ?? null } as never,
      },
    }).catch(() => undefined);
    });
    return this.config(gymId);
  }

  // ── the entrance token ────────────────────────────────────────────────────

  /**
   * Mint the token the entrance QR encodes. Called only by an owner holding
   * settings.manage; the QR is displayed, photographed and scanned by members.
   */
  async mintEntranceToken(gymId: string, branchId: string): Promise<{ token: string; expiresAt: string; ttl: number }> {
    const branch = await this.prisma.branch.findFirst({ where: { id: branchId, gymId }, select: { id: true } });
    if (!branch) throw new NotFoundException('branch not found');
    const exp = Math.floor(Date.now() / 1000) + TOKEN_TTL_SECONDS;
    const secret = this.secretOrRefuse();
    const nonce = b64url(createHmac('sha256', secret).update(`${gymId}${branchId}${exp}${Math.random()}`).digest()).slice(0, 10);
    const body = `flx1.${gymId}.${branchId}.${exp}.${nonce}`;
    const token = `${body}.${sign(secret, body)}`;
    return { token, expiresAt: new Date(exp * 1000).toISOString(), ttl: TOKEN_TTL_SECONDS };
  }

  /**
   * Verify a token from the member's request. Returns the tenant and branch it
   * was minted for, or throws an Arabic-coded refusal. The signature covers
   * gym + branch + expiry + nonce, so a token cannot be edited into another gym.
   */
  verifyToken(token: string): EntranceTokenPayload {
    const secret = this.secretOrRefuse();
    const parts = String(token || '').split('.');
    if (parts.length !== 6 || parts[0] !== 'flx1') {
      throw new BadRequestException({ code: 'QR_INVALID', message: 'الرمز غير صالح' });
    }
    const [scheme, gymId, branchId, expRaw, nonce, sig] = parts;
    const body = `${scheme}.${gymId}.${branchId}.${expRaw}.${nonce}`;
    const expected = sign(secret, body);
    // constant-time compare, and refuse a length mismatch before it
    const a = Buffer.from(sig);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !timingSafeEqual(a, b)) {
      throw new BadRequestException({ code: 'QR_INVALID', message: 'الرمز غير صالح' });
    }
    const exp = Number(expRaw);
    if (!Number.isFinite(exp) || exp * 1000 < Date.now()) {
      throw new BadRequestException({ code: 'QR_EXPIRED', message: 'انتهت صلاحية الرمز، امسح الرمز المعروض الآن' });
    }
    return { gymId, branchId, exp, nonce };
  }

  // ── the network and location gates ────────────────────────────────────────

  /** Does `ip` fall inside any configured entry (exact address or CIDR)? */
  static ipAllowed(ip: string | null | undefined, entries: string[]): boolean {
    if (!ip || entries.length === 0) return false;
    const clean = ip.replace(/^::ffff:/, '');
    const v4 = clean.split('.').map(Number);
    const isV4 = v4.length === 4 && v4.every((n) => Number.isInteger(n) && n >= 0 && n <= 255);
    for (const entry of entries) {
      const [base, bitsRaw] = entry.split('/');
      const baseClean = base.replace(/^::ffff:/, '');
      // The prefix length is validated FIRST. An entry like "1.2.3.4/99" is a
      // typo, not a /32: accepting it as an exact match would let a malformed
      // allowlist silently behave like a different one.
      const maxBits = baseClean.includes(':') ? 128 : 32;
      const bits = bitsRaw === undefined ? maxBits : Number(bitsRaw);
      if (!Number.isInteger(bits) || bits < 0 || bits > maxBits) continue;
      if (baseClean === clean) return true;                   // exact match
      if (!isV4) continue;
      const baseV4 = baseClean.split('.').map(Number);
      if (baseV4.length !== 4 || !baseV4.every((n) => Number.isInteger(n))) continue;
      const toInt = (o: number[]) => ((o[0] << 24) | (o[1] << 16) | (o[2] << 8) | o[3]) >>> 0;
      const mask = bits === 0 ? 0 : (0xffffffff << (32 - bits)) >>> 0;
      if ((toInt(v4) & mask) === (toInt(baseV4) & mask)) return true;
    }
    return false;
  }

  /** Metres between two coordinates (haversine). */
  static distanceMeters(a: { lat: number; lng: number }, b: { lat: number; lng: number }): number {
    const R = 6371000;
    const rad = (d: number) => (d * Math.PI) / 180;
    const dLat = rad(b.lat - a.lat);
    const dLng = rad(b.lng - a.lng);
    const h = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(h));
  }

  // ── the check-in ──────────────────────────────────────────────────────────

  /**
   * A member checks themself in.
   *
   * The source is DERIVED HERE from what actually validated; it is never read
   * from the request body (the DTO whitelist rejects a body-supplied `source`
   * with 400 before this method runs — see the spec).
   */
  async selfCheckin(
    memberId: string,
    gymIdFromToken: string,
    input: { token?: string; lat?: number; lng?: number; idempotencyKey?: string },
    requestIp: string | null,
  ) {
    const cfg = await this.config(gymIdFromToken);
    if (!cfg.enabled) {
      throw new ForbiddenException({ code: 'SELF_CHECKIN_DISABLED', message: 'تسجيل الحضور الذاتي غير مُفعّل في هذا النادي' });
    }

    // 1 — an entrance QR wins when present: it is the strongest signal offered.
    let qr: EntranceTokenPayload | null = null;
    if (input.token) {
      qr = this.verifyToken(input.token);
      if (qr.gymId !== gymIdFromToken) {
        // a token minted for another gym must never open this one
        throw new BadRequestException({ code: 'QR_WRONG_GYM', message: 'الرمز يخص ناديًا آخر' });
      }
      // one member may spend one token once: stops a photo being forwarded to a queue
      const spendKey = `selfcheckin:spend:${qr.nonce}:${memberId}`;
      const already = await this.redis.client.get(spendKey);
      if (already) {
        throw new BadRequestException({ code: 'QR_ALREADY_USED', message: 'تم استخدام هذا الرمز بالفعل، امسح الرمز المعروض الآن' });
      }
      await this.redis.client.set(spendKey, '1', 'EX', Math.max(1, qr.exp - Math.floor(Date.now() / 1000)) + 60);
    }

    // 2 — network evidence, if the gym configured any
    const ipEntries = String(await this.raw(gymIdFromToken, SETTING_IP_LIST) ?? '')
      .split(/[\s,]+/).filter(Boolean);
    const ipOk = ipEntries.length > 0 && SelfCheckinService.ipAllowed(requestIp, ipEntries);

    // 3 — location evidence, if a radius is configured
    const geoRaw = await this.raw(gymIdFromToken, SETTING_GEO);
    let geo: { lat: number; lng: number; radiusMeters: number } | null = null;
    try { geo = geoRaw ? JSON.parse(geoRaw) : null; } catch { geo = null; }
    let geoOk = false;
    if (geo && typeof input.lat === 'number' && typeof input.lng === 'number') {
      geoOk = SelfCheckinService.distanceMeters(geo, { lat: input.lat, lng: input.lng }) <= geo.radiusMeters;
    }

    // 4 — when the gym configured a gate, ONE of the configured gates must pass.
    //     A member cannot simply skip the gate by omitting the fields.
    const gated = Boolean(qr) || ipEntries.length > 0 || Boolean(geo);
    if (!qr && ipEntries.length > 0 && !ipOk && !geo) {
      throw new ForbiddenException({ code: 'NOT_ON_GYM_NETWORK', message: 'لست متصلًا بشبكة النادي. اتصل بالواي فاي أو امسح رمز البوابة' });
    }
    if (!qr && geo && !geoOk && ipEntries.length === 0) {
      throw new ForbiddenException({ code: 'OUTSIDE_RADIUS', message: 'أنت خارج نطاق النادي' });
    }

    /**
     * 5 — the source, derived from EVIDENCE, never from the client.
     *
     * In plain mode (the owner enabled the switch but configured no entrance,
     * network or radius) there is no evidence at all. This used to fall through
     * to 'SELF_IP', which told staff "checked on the gym Wi-Fi" about a
     * check-in nobody verified — the one thing the brief forbids. It is NULL
     * now, which the UI already renders as «غير محدد» and which is TRUE.
     *
     * A dedicated plain value is a one-line CHECK-constraint change and is
     * therefore waiting on the owner, not on me (see evidence/16).
     */
    const source: AttendanceSource = qr
      ? 'SELF_QR'
      : ipOk && geoOk ? 'SELF_IP_GEO'
        : ipOk ? 'SELF_IP'
          : geoOk ? 'SELF_GEO'
            // nothing verified this visit. SELF_PLAIN says exactly that — it is
            // distinct from NULL, which means "unknown" (a row written before the
            // column existed, never backfilled).
            : 'SELF_PLAIN';

    // 6 — the member, from the token's own tenant (never the body)
    return this.tenantContext.run(gymIdFromToken, async () => {
      const member = await this.prisma.member.findFirst({
        where: { id: memberId, gymId: gymIdFromToken },
        select: { id: true, name: true, branchId: true, startDate: true, expiry: true, frozen: true, status: true },
      });
      if (!member) throw new NotFoundException({ code: 'MEMBER_NOT_FOUND', message: 'العضو غير موجود' });

      // branch-aware: the entrance the member scanned must be their gym's branch
      const branchId = qr?.branchId ?? member.branchId;
      if (qr && member.branchId && qr.branchId !== member.branchId) {
        throw new BadRequestException({ code: 'WRONG_BRANCH', message: 'هذا الرمز يخص فرعًا آخر' });
      }

      // idempotent window: a double tap (or a retry after a timeout) returns the
      // row that already exists instead of writing a second visit
      const since = new Date(Date.now() - IDEMPOTENT_WINDOW_MINUTES * 60_000);
      const recent = await this.prisma.attendance.findFirst({
        where: { gymId: gymIdFromToken, memberId, at: { gte: since } },
        orderBy: { at: 'desc' },
      });
      if (recent) {
        return { ok: true, duplicate: true, attendanceId: recent.id, at: recent.at, source: recent.source ?? source, branchId: recent.branchId, memberName: member.name };
      }

      // the ONE check-in core: same gates, same session deduction, same events
      const result = await this.attendance.checkin(
        gymIdFromToken,
        { id: memberId },
        'QR',
        member.name,
        branchId,
        source,
      );

      await this.prisma.auditLog.create({
        data: {
          gymId: gymIdFromToken, userId: null, action: 'attendance.self_checkin',
          entity: 'Attendance', entityId: result.attendance.id,
          ip: requestIp ?? null,
          metadata: { source, branchId, memberId, gated, hasToken: Boolean(qr) } as never,
        },
      }).catch(() => undefined);

      return {
        ok: true,
        duplicate: false,
        attendanceId: result.attendance.id,
        at: result.attendance.at,
        source,
        branchId,
        memberName: member.name,
      };
    });
  }
}
