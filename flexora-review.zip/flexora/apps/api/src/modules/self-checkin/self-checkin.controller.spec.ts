/**
 * PACK 2 · ITEM 5 — which address the network gate is allowed to believe.
 * PACK 2 · STEP 0.2 — extended: the gate must also work BEHIND A PROXY.
 *
 * `trust proxy` is on in this app (TRUST_PROXY_HOPS, default 1), so Express
 * derives `req.ip` from X-Forwarded-For — a header the CALLER writes. The first
 * shipped version avoided that entirely by using the socket peer, which is
 * unspoofable but is the PROXY's address in every real deployment, so the gym
 * Wi-Fi check refused everybody behind nginx.
 *
 * The controller must therefore hand the service a resolved address:
 *   • the socket peer when nothing trustworthy says otherwise,
 *   • the header entry ONLY when the connection came from a configured trusted
 *     proxy and the chain explains TRUST_PROXY_HOPS hops.
 *
 * These tests pin the controller's choice end to end; the full truth table
 * (multi-hop, malformed chains, IPv6 mapping) lives in
 * `src/common/net/client-address.spec.ts`. Without them the controller could
 * regress to plain `req.ip` — or back to plain socket — and every other test in
 * this suite would still pass.
 */
import type { MemberPrincipal } from '../../common/decorators/current-member.decorator';
import { SelfCheckinController } from './self-checkin.controller';
import type { SelfCheckinService } from './self-checkin.service';

function controller() {
  const selfCheckin = jest.fn(async () => ({ ok: true }));
  const svc = { selfCheckin } as unknown as SelfCheckinService;
  return { ctrl: new SelfCheckinController(svc), selfCheckin };
}

const member = { sub: 'm1', gymId: 'g1' } as unknown as MemberPrincipal;

// nginx on the compose bridge (a default trusted proxy) and a member's phone on
// mobile data (not trusted, and not in any private range).
const NGINX = '172.18.0.5';
const CLIENT = '41.33.10.7';

describe('SelfCheckinController — network gate address', () => {
  const savedEnv = { ...process.env };

  beforeEach(() => {
    process.env.TRUST_PROXY_HOPS = '1';
    delete process.env.TRUSTED_PROXY_CIDRS;
  });

  afterAll(() => {
    process.env = savedEnv;
  });

  it('uses the socket peer when the caller is NOT behind a proxy, ignoring a forged header', async () => {
    const { ctrl, selfCheckin } = controller();
    await ctrl.selfCheckin(member, {} as never, {
      // exactly what a spoofing client sends: the gym's own address
      ip: '197.45.20.10',
      socket: { remoteAddress: CLIENT },
      headers: { 'x-forwarded-for': '197.45.20.10' },
    });
    expect(selfCheckin).toHaveBeenCalledWith('m1', 'g1', {}, CLIENT);
  });

  it('uses the address nginx appended when the connection comes from a trusted proxy', async () => {
    const { ctrl, selfCheckin } = controller();
    await ctrl.selfCheckin(member, {} as never, {
      // what Express would compute: with trust proxy = 1 this is the header value
      ip: CLIENT,
      socket: { remoteAddress: NGINX },
      headers: { 'x-forwarded-for': CLIENT },
    });
    expect(selfCheckin).toHaveBeenCalledWith('m1', 'g1', {}, CLIENT);
  });

  it('is not moved by a header entry the member prepended behind nginx', async () => {
    const { ctrl, selfCheckin } = controller();
    await ctrl.selfCheckin(member, {} as never, {
      ip: CLIENT,
      socket: { remoteAddress: NGINX },
      headers: { 'x-forwarded-for': `197.45.20.10, ${CLIENT}` },
    });
    expect(selfCheckin).toHaveBeenCalledWith('m1', 'g1', {}, CLIENT);
  });

  it('ignores the header entirely when TRUST_PROXY_HOPS=0', async () => {
    process.env.TRUST_PROXY_HOPS = '0';
    const { ctrl, selfCheckin } = controller();
    await ctrl.selfCheckin(member, {} as never, {
      ip: '197.45.20.10',
      socket: { remoteAddress: NGINX },
      headers: { 'x-forwarded-for': '197.45.20.10' },
    });
    expect(selfCheckin).toHaveBeenCalledWith('m1', 'g1', {}, NGINX);
  });

  it('passes null rather than a header when the socket address is unknown', async () => {
    const { ctrl, selfCheckin } = controller();
    await ctrl.selfCheckin(member, {} as never, {
      ip: '10.1.2.3',
      headers: { 'x-forwarded-for': '10.1.2.3' },
    });
    expect(selfCheckin).toHaveBeenCalledWith('m1', 'g1', {}, null);
    // and a null address must never satisfy an allowlist — that behaviour lives
    // in the service (ipAllowed('') === false) and is covered there
  });

  it('fails closed when there is nothing at all to go on', async () => {
    const { ctrl, selfCheckin } = controller();
    await ctrl.selfCheckin(member, {} as never, {});
    expect(selfCheckin).toHaveBeenCalledWith('m1', 'g1', {}, null);
  });
});
