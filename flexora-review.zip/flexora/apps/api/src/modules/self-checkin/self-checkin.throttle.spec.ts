/**
 * PACK 2 · ITEM 5 — the self check-in rate limiter, unit tested.
 *
 * Two properties matter and neither is visible from the outside:
 *   1. a queue of members behind ONE gym address is not refused;
 *   2. one member cannot retry without bound, and the counter is keyed by a
 *      HASH of their cookie (no credential is ever written into a Redis key).
 */
import type { ExecutionContext } from '@nestjs/common';
import { SelfCheckinThrottleGuard } from './self-checkin.throttle';
import type { RedisService } from '../../config/redis.service';

/** the guard only needs incr / expire from the client */
function fakeRedis() {
  const keys = new Map<string, number>();
  const expiry = new Map<string, number>();
  const client = {
    incr: async (k: string) => {
      const next = (keys.get(k) ?? 0) + 1;
      keys.set(k, next);
      return next;
    },
    expire: async (k: string, s: number) => {
      expiry.set(k, s);
      return 1;
    },
  };
  return { client, keys, expiry };
}

function ctx(cookie: string | undefined, address: string): ExecutionContext {
  const req = {
    cookies: cookie ? { flx_member_access: cookie } : {},
    socket: { remoteAddress: address },
  };
  return { switchToHttp: () => ({ getRequest: () => req }) } as unknown as ExecutionContext;
}

const guardWith = (fake: ReturnType<typeof fakeRedis>) =>
  new SelfCheckinThrottleGuard({ client: fake.client } as unknown as RedisService);

describe('SelfCheckinThrottleGuard', () => {
  it('lets many different members through from the same gym address', async () => {
    const fake = fakeRedis();
    const guard = guardWith(fake);
    // a morning queue: 30 people, one Wi-Fi address, one attempt each
    let refused = 0;
    for (let i = 0; i < 30; i++) {
      if (!(await guard.canActivate(ctx(`cookie-${i}`, '10.0.0.7')))) refused++;
    }
    expect(refused).toBe(0);
  });

  it('refuses one member after six attempts', async () => {
    const fake = fakeRedis();
    const guard = guardWith(fake);
    const results: boolean[] = [];
    for (let i = 0; i < 7; i++) results.push(await guard.canActivate(ctx('same', '10.0.0.7')));
    expect(results.slice(0, 6).every(Boolean)).toBe(true);
    expect(results[6]).toBe(false);
  });

  it('counts the member in the address bucket too, and caps the address at 60/min', async () => {
    const fake = fakeRedis();
    const guard = guardWith(fake);
    // 61 different members in one minute from one address: the last is refused
    let last = true;
    for (let i = 0; i < 61; i++) last = await guard.canActivate(ctx(`c${i}`, '10.0.0.7'));
    expect(last).toBe(false);
  });

  it('never writes the cookie itself into a key, and sets a TTL', async () => {
    const fake = fakeRedis();
    const guard = guardWith(fake);
    await guard.canActivate(ctx('super-secret-token', '10.0.0.7'));
    const keys = [...fake.keys.keys()];
    expect(keys.every((k) => !k.includes('super-secret-token'))).toBe(true);
    expect(keys.every((k) => fake.expiry.get(k)! > 0)).toBe(true);
    // member window 10 min, address window 1 min
    for (const k of keys) {
      expect(fake.expiry.get(k)).toBe(k.startsWith('selfcheckin:member:') ? 600 : 60);
    }
  });

  it('counts a missing cookie only against the address', async () => {
    const fake = fakeRedis();
    const guard = guardWith(fake);
    for (let i = 0; i < 10; i++) expect(await guard.canActivate(ctx(undefined, '1.2.3.4'))).toBe(true);
    expect([...fake.keys.keys()].some((k) => k.startsWith('selfcheckin:member:'))).toBe(false);
  });

  it('separates two addresses', async () => {
    const fake = fakeRedis();
    const guard = guardWith(fake);
    for (let i = 0; i < 6; i++) await guard.canActivate(ctx('m', '10.0.0.1'));
    expect(await guard.canActivate(ctx('m', '10.0.0.1'))).toBe(false);
    // same member from another address: still the member bucket that refuses
    expect(await guard.canActivate(ctx('m', '10.0.0.2'))).toBe(false);
  });
});
