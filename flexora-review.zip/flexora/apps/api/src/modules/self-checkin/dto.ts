/**
 * PACK 2 · ITEM 5 — DTOs for member self check-in.
 *
 * The important one is `SelfCheckinDto`: it has NO `source` field. The global
 * ValidationPipe runs with `whitelist: true, forbidNonWhitelisted: true`, so a
 * request that tries to choose its own source is a 400 — a member cannot forge
 * provenance even if they read the API docs. The source is derived server-side
 * from what actually validated (token / network / location).
 */
import { Type } from 'class-transformer';
import {
  IsBoolean,
  IsLatitude,
  IsLongitude,
  IsNumber,
  IsObject,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';

export class SelfCheckinDto {
  /** the entrance QR, when the member scanned one */
  @IsOptional()
  @IsString()
  @MaxLength(400)
  token?: string;

  @IsOptional()
  @Type(() => Number)
  @IsLatitude()
  lat?: number;

  @IsOptional()
  @Type(() => Number)
  @IsLongitude()
  lng?: number;
}

export class GeoDto {
  @Type(() => Number) @IsLatitude() lat!: number;
  @Type(() => Number) @IsLongitude() lng!: number;
  @Type(() => Number) @IsNumber() @Min(20) @Max(5000) radiusMeters!: number;
}

export class UpdateSelfCheckinDto {
  @IsOptional() @IsBoolean() enabled?: boolean;
  /** comma or space separated IPv4/IPv6 addresses or CIDR blocks */
  @IsOptional() @IsString() @MaxLength(2000) ipList?: string;
  /** null clears the radius; omit to leave it alone */
  @IsOptional() @IsObject() @ValidateNested() @Type(() => GeoDto) geo?: GeoDto;
  @IsOptional() @IsBoolean() regenerateToken?: boolean;
}

export class MintTokenDto {
  @IsString() @MaxLength(40) branchId!: string;
}
