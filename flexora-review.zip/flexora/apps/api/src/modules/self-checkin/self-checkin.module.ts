/**
 * PACK 2 · ITEM 5 — self check-in.
 *
 * Imports AttendanceModule for the ONE check-in core; nothing in this module
 * re-implements a membership gate.
 */
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { AttendanceModule } from '../attendance/attendance.module';
import { SelfCheckinController } from './self-checkin.controller';
import { SelfCheckinService } from './self-checkin.service';
import { SelfCheckinThrottleGuard } from './self-checkin.throttle';

@Module({
  imports: [AttendanceModule, JwtModule.register({})],
  controllers: [SelfCheckinController],
  providers: [SelfCheckinService, SelfCheckinThrottleGuard],
  exports: [SelfCheckinService],
})
export class SelfCheckinModule {}
