/**
 * PACK 2 · ITEM 5 — rate limiting for member self check-in.
 *
 * WHY NOT THE GLOBAL THROTTLER'S DEFAULT: it keys every bucket by IP address. At
 * a gym, THIRTY MEMBERS ARRIVE ON ONE WI-FI ADDRESS AT THE SAME MINUTE — an
 * IP-keyed limit of ten a minute would refuse the queue on the busiest morning
 * of the week. So this guard keys by the MEMBER (a hash of the member cookie,
 * never the token itself), and keeps a much looser per-address ceiling that only
 * a script could reach.
 *
 * The counters live in Redis with a TTL, so two API instances share them.
 */
import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';
import { createHash } from 'node:crypto';
import { RedisService } from '../../config/redis.service';

/** per member: six attempts in ten minutes is generous for a person */
const MEMBER_LIMIT = 6;
const MEMBER_WINDOW_SECONDS = 600;
/** per address: a queue is fine, a flood is not */
const ADDRESS_LIMIT = 60;
const ADDRESS_WINDOW_SECONDS = 60;

@Injectable()
export class SelfCheckinThrottleGuard implements CanActivate {
  constructor(private readonly redis: RedisService) {}

  private async bump(key: string, windowSeconds: number): Promise<number> {
    const client = this.redis.client;
    const count = await client.incr(key);
    if (count === 1) await client.expire(key, windowSeconds);
    return Number(count);
  }

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const req = context.switchToHttp().getRequest<{
      cookies?: Record<string, string>;
      socket?: { remoteAddress?: string };
      ip?: string;
    }>();

    // the member's own cookie, hashed: the rate limiter must never hold a
    // credential in a key, and a hash is enough to count per person
    const raw = req.cookies?.flx_member_access || '';
    const memberKey = raw
      ? createHash('sha256').update(raw).digest('hex').slice(0, 32)
      : null;

    // the ADDRESS is the socket peer, not a header: X-Forwarded-For is written
    // by the client unless a trusted proxy overwrote it (see the note below)
    const address = req.socket?.remoteAddress || req.ip || 'unknown';

    const addressHits = await this.bump(`selfcheckin:ip:${address}`, ADDRESS_WINDOW_SECONDS);
    if (addressHits > ADDRESS_LIMIT) return false;

    if (memberKey) {
      const memberHits = await this.bump(`selfcheckin:member:${memberKey}`, MEMBER_WINDOW_SECONDS);
      if (memberHits > MEMBER_LIMIT) return false;
    }
    return true;
  }
}
