/**
 * PACK 2 · ITEM 5 — the two faces of self check-in.
 *
 *   /api/portal/self-checkin/*  a MEMBER, holding a member token, on a phone
 *   /api/settings/self-checkin  the OWNER, holding a staff token, configuring it
 *
 * They are deliberately in one controller: the member's route and the owner's
 * setting must never drift apart, because one of them is worthless without the
 * other being honest about what it does.
 */
import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Patch,
  Post,
  Req,
  UseGuards,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';

import { Public } from '../../common/decorators/public.decorator';
import { MemberAuthGuard } from '../../common/guards/member-auth.guard';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { PermissionsGuard } from '../../common/guards/permissions.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { CurrentMember } from '../../common/decorators/current-member.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { resolveClientAddress, trustedProxiesFromEnv } from '../../common/net/client-address';
import { trustProxyHops } from '../../config/trust-proxy.config';
import { SelfCheckinService } from './self-checkin.service';
import { SelfCheckinThrottleGuard } from './self-checkin.throttle';
import { MintTokenDto, SelfCheckinDto, UpdateSelfCheckinDto } from './dto';

interface MemberPrincipal {
  sub: string;      // member id
  gymId: string;
  role: 'MEMBER';
}

interface StaffPrincipal {
  sub: string;
  gymId: string;
  role: string;
}

@ApiTags('self-checkin')
@Controller()
export class SelfCheckinController {
  constructor(private readonly svc: SelfCheckinService) {}

  // ── member side ──────────────────────────────────────────────────────────

  /**
   * What this gym offers, so the portal can show the right thing — and so a
   * member is never shown a button the server would refuse.
   *
   * Class-level @Public(): the member token is a different secret from the
   * staff token, so the global staff guard must stand down; MemberAuthGuard
   * below is what actually authenticates the caller.
   */
  @Public()
  @UseGuards(MemberAuthGuard)
  @Get('portal/self-checkin/config')
  async memberConfig(@CurrentMember() member: MemberPrincipal) {
    const cfg = await this.svc.config(member.gymId);
    // the member never sees the IP list or the coordinates — those are the
    // gym's business, and a leaked allowlist is a hint for a spoofing client
    return {
      enabled: cfg.enabled,
      qr: cfg.modes.qr,
      network: cfg.modes.network,
      geolocation: cfg.modes.geolocation,
      plain: cfg.modes.plain,
      radiusMeters: cfg.radiusMeters,
      // STEP 2a: false when this process has no QR signing key, so the portal
      // does not offer a scan that the server would refuse
      qrAvailable: cfg.qrAvailable,
      // said plainly, in the product, in Arabic: a page cannot detect arrival
      honesty: 'page_cannot_detect_arrival',
    };
  }

  /**
   * The "I arrived" call. Rate-limited well below abuse: ten attempts a minute
   * is more than a person needs and far less than a script wants.
   */
  @Public()
  @UseGuards(MemberAuthGuard, SelfCheckinThrottleGuard)
  // The global buckets are raised for this route because they count by IP, and
  // a gym's morning queue shares one address; the per-MEMBER limit is enforced
  // by SelfCheckinThrottleGuard above (six in ten minutes, keyed by a hash of
  // the member cookie).
  @Throttle({ short: { ttl: 60000, limit: 300 }, global: { ttl: 60000, limit: 600 } })
  @Post('portal/self-checkin')
  @HttpCode(HttpStatus.OK)
  selfCheckin(
    @CurrentMember() member: MemberPrincipal,
    @Body() dto: SelfCheckinDto,
    @Req()
    req: {
      ip?: string;
      socket?: { remoteAddress?: string };
      headers?: Record<string, string | string[] | undefined>;
    },
  ) {
    /**
     * THE ADDRESS THE NETWORK GATE USES — STEP 0.2
     *
     * The socket peer alone is honest but wrong behind nginx (every member looks
     * like the proxy); `req.ip` alone is right behind nginx but spoofable when
     * the API is reachable directly, because `trust proxy` makes Express derive
     * it from a header the caller writes.
     *
     * `resolveClientAddress` combines them under one rule: the header is read
     * ONLY when the connection itself came from a configured trusted proxy and
     * the chain explains the configured number of hops; otherwise the socket
     * peer is the answer, and when even that is unknown the answer is null
     * (which fails an allowlist closed). See common/net/client-address.ts for
     * the full truth table, and docs/SELF-CHECKIN-NETWORK.md for the nginx and
     * Docker setup.
     */
    const decided = resolveClientAddress(req, {
      hops: trustProxyHops(),
      trustedProxies: trustedProxiesFromEnv(),
    });
    return this.svc.selfCheckin(member.sub, member.gymId, dto, decided.address);
  }

  // ── owner side ───────────────────────────────────────────────────────────

  @UseGuards(JwtAuthGuard, TenantGuard, PermissionsGuard)
  @Permissions('settings.manage')
  @Get('settings/self-checkin')
  ownerConfig(@CurrentUser() user: StaffPrincipal) {
    return this.svc.config(user.gymId);
  }

  @UseGuards(JwtAuthGuard, TenantGuard, PermissionsGuard)
  @Permissions('settings.manage')
  @Patch('settings/self-checkin')
  ownerUpdate(@CurrentUser() user: StaffPrincipal, @Body() dto: UpdateSelfCheckinDto) {
    return this.svc.updateSettings(user.gymId, user.sub, dto as never);
  }

  /**
   * Mint the token the entrance QR encodes. Two minutes, one branch, one gym.
   * Not cached and not re-usable: the owner (or the screen) asks again.
   */
  @UseGuards(JwtAuthGuard, TenantGuard, PermissionsGuard)
  @Permissions('settings.manage')
  @Post('settings/self-checkin/token')
  @HttpCode(HttpStatus.OK)
  mintToken(@CurrentUser() user: StaffPrincipal, @Body() dto: MintTokenDto) {
    return this.svc.mintEntranceToken(user.gymId, dto.branchId);
  }
}
