/** @jest-environment node */
/**
 * PACK 2 · ITEM 5 — self check-in, against a REAL database and the REAL app.
 *
 * Rules from the brief, each with its own test:
 *   setting default OFF · enabled per gym · QR token signed, expiring, replay-safe
 *   and wrong-gym/wrong-branch refusals · network allowlist (exact + CIDR)
 *   geolocation radius · idempotent window · the shared membership gates
 *   (frozen / expired / not started) · source derived server-side, never from the
 *   body · staff and kiosk flows unchanged apart from the new column · cross-tenant
 *   and cross-branch negatives · runtime-role run.
 *
 * WHAT IS STUBBED AND WHAT IS NOT: only Redis's two one-token-per-member keys are
 * faked, because a shared dev Redis would otherwise leak a spent nonce between
 * runs. Everything else — Prisma, RLS, the guards, the attendance core, the
 * audit rows — is the real application.
 */
import {
  assertRuntimeRole,
  runtimeRolePassword,
  startTenantHarness,
  TenantHarness,
} from '../../test/support/tenant-app-harness';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { SelfCheckinService } from './self-checkin.service';
import { startRuntimeApp } from '../../test/support/tenant-app-harness';
import { AttendanceService } from '../attendance/attendance.service';
import { ValidationPipe } from '@nestjs/common';
import { SelfCheckinDto } from './dto';

jest.setTimeout(180_000);

const RUN = Date.now().toString(36);
const isIntegration = Boolean(process.env.DATABASE_URL && runtimeRolePassword());
const d = isIntegration ? describe : describe.skip;

d('PACK 2 item 5 — member self check-in', () => {
  let h: TenantHarness;
  let svc: SelfCheckinService;
  let prisma: PrismaService;
  /** a tiny in-process stand-in for the two Redis keys this feature uses */
  const store = new Map<string, string>();

  const future = (days: number) => new Date(Date.now() + days * 86_400_000);
  const past = (days: number) => new Date(Date.now() - days * 86_400_000);

  let gymId: string;
  let branchId: string;
  let otherBranchId: string;
  let activeMember: { id: string; mobile: string };
  let expiringMemberId: string;

  const setEnabled = async (on: boolean) => {
    await prisma.gymSettings.upsert({
      where: { gymId_key: { gymId, key: 'selfCheckin.enabled' } },
      create: { gymId, key: 'selfCheckin.enabled', value: String(on) },
      update: { value: String(on) },
    });
  };
  const setSetting = async (key: string, value: string) => {
    await prisma.gymSettings.upsert({
      where: { gymId_key: { gymId, key } },
      create: { gymId, key, value },
      update: { value },
    });
  };
  const clearSettings = async () => {
    await prisma.gymSettings.deleteMany({
      where: { gymId, key: { in: ['selfCheckin.enabled', 'selfCheckin.ipList', 'selfCheckin.geo'] } },
    });
  };

  /** A brand-new member with a valid membership: isolates each test from the
   *  idempotent window, which (correctly) returns an earlier visit if one exists. */
  let memberSeq = 0;
  const freshMember = async (name = 'عضو اختبار') => {
    const plan = await prisma.plan.findFirst({ where: { gymId } });
    memberSeq += 1;
    return (await prisma.member.create({
      data: {
        gymId, branchId, planId: plan!.id, name,
        mobile: `01${String(Date.now() + memberSeq).slice(-9)}`,
        code: `SCX${RUN}${memberSeq}`,
        startDate: past(5), expiry: future(20), status: 'ACTIVE',
      },
    })).id;
  };

  beforeAll(async () => {
    h = await startTenantHarness(`selfcheckin${RUN}`);
    await assertRuntimeRole(h.runtime);
    prisma = h.app.get(PrismaService);
    svc = h.app.get(SelfCheckinService);
    gymId = h.gymA.gymId;
    branchId = h.gymA.branchId;
    otherBranchId = h.gymA.secondBranchId;

    // replace only the two one-shot Redis keys
    const redis = h.app.get(RedisService);
    (redis as unknown as { client: unknown }).client = {
      get: async (k: string) => store.get(k) ?? null,
      set: async (k: string, v: string) => { store.set(k, v); return 'OK'; },
      del: async (k: string) => (store.delete(k) ? 1 : 0),
      // the app's shutdown hook calls quit(); without it the suite fails in
      // afterAll with "disconnect is not a function" and masks a green run
      quit: async () => 'OK',
      disconnect: () => undefined,
    };

    const plan = await prisma.plan.create({
      data: { gymId, name: `Plan ${RUN}`, type: 'TIME', days: 30, price: 500 },
    });
    let memberSeq = 0;
    const mkMember = async (name: string, mobile: string, startDate: Date, expiry: Date | null) =>
      (await prisma.member.create({
        data: {
          gymId, branchId, planId: plan.id, name, mobile,
          code: `SC${RUN}${++memberSeq}`,
          startDate, expiry, status: 'ACTIVE',
        },
      })).id;
    activeMember = {
      id: await mkMember('سلمى محمود', `010${Date.now().toString().slice(-8)}`, past(10), future(20)),
      mobile: '',
    };
    activeMember.mobile = (await prisma.member.findUnique({ where: { id: activeMember.id } }))!.mobile;
    expiringMemberId = await mkMember('كريم فؤاد', `011${(Date.now() + 7).toString().slice(-8)}`, past(40), future(1));
  });

  afterAll(async () => { if (h) await h.close(); });

  // ── settings ─────────────────────────────────────────────────────────────

  it('reads the setting AS THE RUNTIME ROLE (the bug that shipped: a member was told OFF after the owner turned it ON)', async () => {
    // GymSettings is tenant data. Read without a tenant context, the runtime role
    // sees nothing — which is exactly what a member's portal request did before
    // config() pinned the gym, so an enabled switch looked disabled. This boots
    // the REAL app against the runtime role, because that is the only way the
    // RLS-protected read behaves as it does in production.
    await clearSettings();
    await setEnabled(true);

    // 1. a raw read with no tenant: no rows — that is RLS working, not a bug
    const raw = await h.runtime.gymSettings.findMany({ where: { gymId } });
    expect(raw.length).toBe(0);

    // 2. the same question through the service, on the runtime-role app
    const rt = await startRuntimeApp();
    try {
      const cfg = await rt.app.get(SelfCheckinService).config(gymId);
      expect(cfg.enabled).toBe(true);
    } finally {
      await rt.close();
    }
    await clearSettings();
  });

  it('is OFF by default: no row in GymSettings means no self check-in', async () => {
    await clearSettings();
    expect((await svc.config(gymId)).enabled).toBe(false);
    await expect(
      svc.selfCheckin(activeMember.id, gymId, {}, '203.0.113.10'),
    ).rejects.toMatchObject({ response: { code: 'SELF_CHECKIN_DISABLED' } });
  });

  it('an owner turns it on, and the change is audited', async () => {
    await clearSettings();
    const cfg = await svc.updateSettings(gymId, h.gymA.owner.id, { enabled: true });
    expect(cfg.enabled).toBe(true);
    const audit = await prisma.auditLog.findFirst({
      where: { gymId, action: 'self_checkin.settings' },
      orderBy: { createdAt: 'desc' },
    });
    expect(audit).toBeTruthy();
  });

  // ── the token ────────────────────────────────────────────────────────────

  it('mints a token that verifies, and binds gym + branch', async () => {
    const { token, ttl } = await svc.mintEntranceToken(gymId, branchId);
    expect(ttl).toBe(120);
    const payload = svc.verifyToken(token);
    expect(payload.gymId).toBe(gymId);
    expect(payload.branchId).toBe(branchId);
  });

  it('refuses an edited token (the signature covers gym and branch)', async () => {
    const { token } = await svc.mintEntranceToken(gymId, branchId);
    const parts = token.split('.');
    parts[2] = otherBranchId;           // swap the branch, keep the signature
    expect(() => svc.verifyToken(parts.join('.'))).toThrow();
  });

  it('refuses an expired token', async () => {
    // mint with the clock pushed forward, then verify in the present
    const realNow = Date.now;
    Date.now = () => realNow() - 10 * 60_000;
    let token: string;
    try {
      token = (await svc.mintEntranceToken(gymId, branchId)).token;
    } finally {
      Date.now = realNow;
    }
    expect(() => svc.verifyToken(token!)).toThrow();
    try { svc.verifyToken(token!); } catch (e) {
      expect((e as { response?: { code?: string } }).response?.code).toBe('QR_EXPIRED');
    }
  });

  it('a token minted for another gym opens nothing here', async () => {
    const other = await svc.mintEntranceToken(h.gymB.gymId, h.gymB.branchId);
    await setEnabled(true);
    await expect(
      svc.selfCheckin(activeMember.id, gymId, { token: other.token }, '203.0.113.10'),
    ).rejects.toMatchObject({ response: { code: 'QR_WRONG_GYM' } });
  });

  it('a member cannot spend the same token twice from a photograph', async () => {
    await setEnabled(true);
    store.clear();
    const { token } = await svc.mintEntranceToken(gymId, branchId);
    const first = await svc.selfCheckin(activeMember.id, gymId, { token }, '203.0.113.10');
    expect(first.ok).toBe(true);
    expect(first.source).toBe('SELF_QR');
    // the same member with the same token, inside the idempotent window
    await expect(
      svc.selfCheckin(activeMember.id, gymId, { token }, '203.0.113.10'),
    ).rejects.toMatchObject({ response: { code: 'QR_ALREADY_USED' } });
  });

  it('refuses a token for another branch of the same gym', async () => {
    await setEnabled(true);
    store.clear();
    const { token } = await svc.mintEntranceToken(gymId, otherBranchId);
    await expect(
      svc.selfCheckin(activeMember.id, gymId, { token }, '203.0.113.10'),
    ).rejects.toMatchObject({ response: { code: 'WRONG_BRANCH' } });
  });

  // ── the gates ────────────────────────────────────────────────────────────

  it('the network allowlist accepts an exact address and a CIDR block', () => {
    expect(SelfCheckinService.ipAllowed('41.33.10.7', ['41.33.10.7'])).toBe(true);
    expect(SelfCheckinService.ipAllowed('41.33.10.7', ['41.33.0.0/16'])).toBe(true);
    expect(SelfCheckinService.ipAllowed('41.34.10.7', ['41.33.0.0/16'])).toBe(false);
    expect(SelfCheckinService.ipAllowed('::ffff:41.33.10.7', ['41.33.10.7'])).toBe(true);
    expect(SelfCheckinService.ipAllowed('', ['41.33.10.7'])).toBe(false);
    expect(SelfCheckinService.ipAllowed('41.33.10.7', [])).toBe(false);
  });

  it('refuses an off-network member when the gym configured its network only', async () => {
    await setEnabled(true);
    await setSetting('selfCheckin.ipList', '41.33.0.0/16');
    store.clear();
    const m = await freshMember();
    await expect(
      svc.selfCheckin(m, gymId, {}, '198.51.100.9'),
    ).rejects.toMatchObject({ response: { code: 'NOT_ON_GYM_NETWORK' } });
    const ok = await svc.selfCheckin(m, gymId, {}, '41.33.10.7');
    expect(ok.source).toBe('SELF_IP');
    await clearSettings();
  });

  it('refuses a member outside the geolocation radius, and accepts one inside', async () => {
    await setEnabled(true);
    await setSetting('selfCheckin.geo', JSON.stringify({ lat: 30.0444, lng: 31.2357, radiusMeters: 150 }));
    store.clear();
    const m = await freshMember();
    await expect(
      svc.selfCheckin(m, gymId, { lat: 30.1, lng: 31.3 }, null),
    ).rejects.toMatchObject({ response: { code: 'OUTSIDE_RADIUS' } });
    const ok = await svc.selfCheckin(m, gymId, { lat: 30.0445, lng: 31.2358 }, null);
    expect(ok.source).toBe('SELF_GEO');
    await clearSettings();
  });

  it('measures distance honestly (haversine, metres)', () => {
    const cairo = { lat: 30.0444, lng: 31.2357 };
    expect(SelfCheckinService.distanceMeters(cairo, cairo)).toBeLessThan(1);
    // 1 degree of latitude is ~111 km
    expect(SelfCheckinService.distanceMeters(cairo, { lat: 31.0444, lng: 31.2357 })).toBeGreaterThan(110_000);
    expect(SelfCheckinService.distanceMeters(cairo, { lat: 31.0444, lng: 31.2357 })).toBeLessThan(112_000);
  });

  it('a check-in OUTSIDE the window writes a new visit (the window is 10 minutes, not forever)', async () => {
    // Without this, `since = new Date(0)` would pass the double-tap test above:
    // a member with any earlier visit would be told "already checked in" and no
    // row would ever be written again.
    await clearSettings();
    await setEnabled(true);
    store.clear();
    const m = await freshMember();
    // an earlier visit, three hours ago — well outside the idempotent window
    await prisma.attendance.create({
      data: { gymId, memberId: m, branchId, at: new Date(Date.now() - 3 * 3600_000), method: 'QR', staffName: 'موظف الاستقبال' },
    });
    const before = await prisma.attendance.count({ where: { gymId, memberId: m } });
    const res = await svc.selfCheckin(m, gymId, {}, null);
    const after = await prisma.attendance.count({ where: { gymId, memberId: m } });
    expect(res.duplicate).toBe(false);
    expect(after - before).toBe(1);
    const row = await prisma.attendance.findUnique({ where: { id: res.attendanceId! } });
    expect(row!.at.getTime()).toBeGreaterThan(Date.now() - 60_000);
  });

  it('a double tap inside the window returns the same visit, not a second one', async () => {
    await clearSettings();
    await setEnabled(true);
    store.clear();
    const m = await freshMember();
    const before = await prisma.attendance.count({ where: { gymId, memberId: m } });
    const a = await svc.selfCheckin(m, gymId, {}, null);
    const b = await svc.selfCheckin(m, gymId, {}, null);
    const after = await prisma.attendance.count({ where: { gymId, memberId: m } });
    expect(b.duplicate).toBe(true);
    expect(b.attendanceId).toBe(a.attendanceId);
    expect(after - before).toBe(1);
  });

  // ── the shared membership gates ──────────────────────────────────────────

  it('refuses a frozen member with the shared Arabic message', async () => {
    await setEnabled(true);
    store.clear();
    const plan = await prisma.plan.findFirst({ where: { gymId } });
    const frozen = await prisma.member.create({
      data: {
        gymId, branchId, planId: plan!.id, name: 'عضو مجمد', mobile: `012${Date.now().toString().slice(-8)}`,
        code: `SC${RUN}-${Math.random().toString(36).slice(2, 7)}`,
        startDate: past(10), expiry: future(20), status: 'ACTIVE', frozen: true,
      },
    });
    await expect(svc.selfCheckin(frozen.id, gymId, {}, null)).rejects.toThrow();
  });

  it('refuses an expired member and a member who has not started', async () => {
    await setEnabled(true);
    store.clear();
    const plan = await prisma.plan.findFirst({ where: { gymId } });
    const expired = await prisma.member.create({
      data: {
        gymId, branchId, planId: plan!.id, name: 'عضو منتهي', mobile: `015${Date.now().toString().slice(-8)}`,
        code: `SC${RUN}-${Math.random().toString(36).slice(2, 7)}`,
        startDate: past(60), expiry: past(1), status: 'ACTIVE',
      },
    });
    await expect(svc.selfCheckin(expired.id, gymId, {}, null)).rejects.toThrow();

    const notStarted = await prisma.member.create({
      data: {
        gymId, branchId, planId: plan!.id, name: 'عضو لم يبدأ', mobile: `0101${Date.now().toString().slice(-7)}`,
        code: `SC${RUN}-${Math.random().toString(36).slice(2, 7)}`,
        startDate: future(5), expiry: future(35), status: 'ACTIVE',
      },
    });
    await expect(svc.selfCheckin(notStarted.id, gymId, {}, null)).rejects.toThrow();
  });

  // ── provenance ───────────────────────────────────────────────────────────

  it('plain mode — the switch on, no gate configured — stores SELF_PLAIN, never SELF_IP', async () => {
    // Owner decision 2026-11-17: an unverified self check-in gets its OWN value.
    // It must never claim SELF_IP (it used to, which told staff "checked on the
    // gym Wi-Fi" about a visit nobody verified), and it must be distinguishable
    // from a legacy row written before the column existed (NULL = unknown).
    await clearSettings();
    await setEnabled(true);
    store.clear();
    const m = await freshMember();
    const res = await svc.selfCheckin(m, gymId, {}, null);
    expect(res.source).toBe('SELF_PLAIN');
    const row = await prisma.attendance.findUnique({ where: { id: res.attendanceId! } });
    expect(row!.source).toBe('SELF_PLAIN');
    const audit = await prisma.auditLog.findFirst({
      where: { gymId, action: 'attendance.self_checkin', entityId: row!.id },
    });
    expect(audit).toBeTruthy();
    // the audit record still says plainly that this was an ungated self check-in
    expect((audit!.metadata as Record<string, unknown>).gated).toBe(false);
  });

  it('a legacy row with NULL source stays NULL and is never relabelled', async () => {
    // Rows written before 20261116130000 have no source. They must keep saying
    // "unknown" (the UI shows «غير محدد») — backfilling them would be inventing
    // evidence. This writes one the way those rows were written: no source at all.
    const legacy = await prisma.attendance.create({
      data: { gymId, memberId: activeMember.id, branchId, at: new Date('2026-11-01T09:00:00Z'), method: 'QR', staffName: 'موظف الاستقبال' },
    });
    const again = await prisma.attendance.findUnique({ where: { id: legacy.id } });
    expect(again!.source).toBeNull();
    // and the migration's constraint allows NULL (it is in the allowlist)
    await prisma.attendance.update({ where: { id: legacy.id }, data: { staffName: 'موظف استقبال' } });
    expect((await prisma.attendance.findUnique({ where: { id: legacy.id } }))!.source).toBeNull();
  });

  it('a gated check-in stores the evidence it actually had', async () => {
    await clearSettings();
    await setEnabled(true);
    await setSetting('selfCheckin.ipList', '41.33.0.0/16');
    store.clear();
    const m = await freshMember();
    const res = await svc.selfCheckin(m, gymId, {}, '41.33.10.7');
    const row = await prisma.attendance.findUnique({ where: { id: res.attendanceId! } });
    expect(res.source).toBe('SELF_IP');
    expect(row!.source).toBe('SELF_IP');
    await clearSettings();
  });

  it('staff check-in records STAFF and the kiosk records KIOSK, both unchanged otherwise', async () => {
    const plan = await prisma.plan.findFirst({ where: { gymId } });
    const m = await prisma.member.create({
      data: {
        gymId, branchId, planId: plan!.id, name: 'عضو الاستقبال', mobile: `0155${Date.now().toString().slice(-7)}`,
        code: `SC${RUN}-${Math.random().toString(36).slice(2, 7)}`,
        startDate: past(5), expiry: future(20), status: 'ACTIVE',
      },
    });
    const attendance = h.app.get(
      (await import('../attendance/attendance.service')).AttendanceService,
    );
    const staffRow = await attendance.checkin(gymId, { id: m.id }, 'MANUAL', 'Mona Adel', branchId, 'STAFF');
    expect(staffRow.attendance.source).toBe('STAFF');
    expect(staffRow.attendance.method).toBe('MANUAL');

    const kioskRow = await attendance.kioskCheckin(gymId, { id: m.id }, 'Front desk', branchId);
    expect(kioskRow.attendance.source).toBe('KIOSK');
    // the kiosk's own contract is untouched: method QR, staffName the device label
    expect(kioskRow.attendance.method).toBe('QR');
    expect(kioskRow.attendance.staffName).toBe('Self-service (Front desk)');
  });

  it('every row written before this column existed is still NULL (nothing guessed)', async () => {
    const legacy = await prisma.attendance.findMany({
      where: { gymId, source: null },
      take: 5,
    });
    // the fixture's attendance rows come through paths that predate the column
    expect(legacy.every((r) => r.source === null)).toBe(true);
  });

  // ── cross-tenant ─────────────────────────────────────────────────────────

  it('a member of another gym cannot use this gym\'s settings or members', async () => {
    await clearSettings();
    await setEnabled(true);
    const planB = await prisma.plan.create({
      data: { gymId: h.gymB.gymId, name: `PlanB ${RUN}`, type: 'TIME', days: 30, price: 500 },
    });
    const memberB = await prisma.member.create({
      data: {
        gymId: h.gymB.gymId, branchId: h.gymB.branchId, planId: planB.id,
        name: 'عضو نادٍ آخر', mobile: `0122${Date.now().toString().slice(-7)}`, code: `SCB${RUN}`,
        code: `SC${RUN}-${Math.random().toString(36).slice(2, 7)}`,
        startDate: past(5), expiry: future(20), status: 'ACTIVE',
      },
    });
    // gym B has self check-in OFF, so its own member is refused there
    await expect(svc.selfCheckin(memberB.id, h.gymB.gymId, {}, null))
      .rejects.toMatchObject({ response: { code: 'SELF_CHECKIN_DISABLED' } });
    // and gym A's member id cannot be used from gym B's context
    await expect(svc.selfCheckin(activeMember.id, h.gymB.gymId, {}, null))
      .rejects.toMatchObject({ response: { code: 'SELF_CHECKIN_DISABLED' } });
  });

  it('the unverified-check-in COUNT is per gym: one gym cannot see another\'s', async () => {
    // Cross-tenant negative control for the daily summary the owner reads.
    await clearSettings();
    await setEnabled(true);
    store.clear();
    const mMine = await freshMember();
    await svc.selfCheckin(mMine, gymId, {}, null);   // gym A: one SELF_PLAIN today

    const attendance = h.app.get(AttendanceService);
    const mine = await attendance.dailySummary(gymId);
    const theirs = await attendance.dailySummary(h.gymB.gymId);
    expect(mine.selfPlain).toBeGreaterThanOrEqual(1);
    // gym B has no check-ins at all, and certainly none of gym A's
    expect(theirs.selfPlain).toBe(0);
    expect(theirs.total).toBe(0);
  });

  it('runs under the runtime role, and FORCE RLS hides attendance with no tenant set', async () => {
    // The check-ins above were written through the app role, inside its tenant
    // context. Seen WITHOUT a tenant, the same role must see nothing — that is
    // what makes the self check-in route safe to expose to members.
    const [hidden] = await h.runtime.$queryRaw<Array<{ count: bigint }>>`
      SELECT count(*)::bigint FROM "Attendance" WHERE "gymId" = ${gymId}`;
    expect(Number(hidden.count)).toBe(0);
    // and the role itself is still least-privilege
    await assertRuntimeRole(h.runtime);
    // the owner connection can see them, so the rows really exist
    const seen = await prisma.attendance.count({ where: { gymId } });
    expect(seen).toBeGreaterThan(0);
  });

  // ── the DTO refuses a forged source ──────────────────────────────────────

  it('the check-in schema rejects a body-chosen source (400) — the DTO has no such field', async () => {
    // The live HTTP 400 is proven in work/item5-smoke.mjs ("a forged source is a
    // 400, not a stored value"). This pins the CONTRACT under the same pipe
    // configuration the app boots with, because a source field added to the DTO
    // would keep the live check green for the wrong reason only if the server
    // were rebuilt between runs — this one fails the moment the field appears.
    const pipe = new ValidationPipe({ transform: true, whitelist: true, forbidNonWhitelisted: true });
    await expect(
      pipe.transform({ source: 'STAFF' }, { type: 'body', metatype: SelfCheckinDto }),
    ).rejects.toMatchObject({ status: 400 });
    // the legitimate body still passes
    await expect(pipe.transform({}, { type: 'body', metatype: SelfCheckinDto })).resolves.toBeTruthy();
  });
});
