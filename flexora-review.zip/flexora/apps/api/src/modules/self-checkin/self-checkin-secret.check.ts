/**
 * PACK 2 · STEP 2a — the QR signing key, reported at boot.
 *
 * WHY THIS EXISTS
 * ---------------
 * `SELF_CHECKIN_SECRET` is OPTIONAL and empty by default. Emptiness is NOT a
 * per-process random key and NOT a restart-dependent one: the service derives
 * `flexora-self-checkin:<JWT_ACCESS_SECRET>` instead, so the same QR verifies on
 * every replica and across restarts. That is safe — as long as
 * JWT_ACCESS_SECRET exists, which the production boot validator requires.
 *
 * Before this check the code had a third term, `|| 'dev-only'`: a process with
 * NEITHER variable silently signed entrance QRs with a constant printed in the
 * source tree. Anyone could forge a token for any gym, and nothing said a word.
 * That term is gone (the service now refuses with an Arabic message), and this
 * check makes the state visible at boot instead of at the first scan.
 *
 * It never prints a secret, only which variable was used.
 */
import { Logger } from '@nestjs/common';

export interface QrSecretState {
  ok: boolean;
  /** which variable the key is derived from, for logs and docs */
  source: 'SELF_CHECKIN_SECRET' | 'JWT_ACCESS_SECRET' | 'none';
  warning: string | null;
}

/**
 * The derived key, or null. PURE: same env in => same key out, in any process,
 * before and after a restart. That is the property that makes an empty
 * SELF_CHECKIN_SECRET safe, and it is asserted by the spec.
 */
export function deriveQrSecret(env: NodeJS.ProcessEnv = process.env): string | null {
  const dedicated = (env.SELF_CHECKIN_SECRET || '').trim();
  if (dedicated) return `flexora-self-checkin:${dedicated}`;
  const access = (env.JWT_ACCESS_SECRET || '').trim();
  if (access) return `flexora-self-checkin:${access}`;
  return null;
}

export function qrSecretState(env: NodeJS.ProcessEnv = process.env): QrSecretState {
  const dedicated = (env.SELF_CHECKIN_SECRET || '').trim();
  const access = (env.JWT_ACCESS_SECRET || '').trim();
  if (dedicated) return { ok: true, source: 'SELF_CHECKIN_SECRET', warning: null };
  if (access) {
    return {
      ok: true,
      source: 'JWT_ACCESS_SECRET',
      warning:
        'SELF_CHECKIN_SECRET is empty: entrance QR tokens are signed with a key derived from ' +
        'JWT_ACCESS_SECRET (prefix flexora-self-checkin:). This works across restarts and replicas ' +
        'and is safe while JWT_ACCESS_SECRET is set. Rotating JWT_ACCESS_SECRET invalidates every ' +
        'QR currently on a screen (they live 120 s). Set SELF_CHECKIN_SECRET to rotate the QR key ' +
        'independently of user sessions.',
    };
  }
  return {
    ok: false,
    source: 'none',
    warning:
      'NEITHER SELF_CHECKIN_SECRET NOR JWT_ACCESS_SECRET is set: self check-in QR is DISABLED ' +
      '(minting and scanning both refuse with SELF_CHECKIN_QR_UNAVAILABLE). The "I arrived" button ' +
      'and the gym-network method keep working. Set SELF_CHECKIN_SECRET (openssl rand -hex 32).',
  };
}

export function logQrSecretState(logger: Logger, state: QrSecretState = qrSecretState()): void {
  if (state.ok && state.warning) logger.warn(state.warning);
  else if (!state.ok) logger.error(state.warning);
  else logger.log(`self check-in QR key: ${state.source}`);
}
