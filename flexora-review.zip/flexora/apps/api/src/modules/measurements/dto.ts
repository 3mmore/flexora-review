/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { IsNumber, IsOptional, IsString, Min, IsDateString } from 'class-validator';

export class CreateMeasurementDto {
  @IsOptional() @IsDateString() measuredAt?: string;
  @IsOptional() @IsNumber() @Min(0) weight?: number;
  @IsOptional() @IsNumber() @Min(0) bodyFat?: number;
  @IsOptional() @IsNumber() @Min(0) muscleMass?: number;
  @IsOptional() @IsNumber() @Min(0) chest?: number;
  @IsOptional() @IsNumber() @Min(0) waist?: number;
  @IsOptional() @IsNumber() @Min(0) hips?: number;
  @IsOptional() @IsNumber() @Min(0) arms?: number;
  @IsOptional() @IsString() notes?: string;
}
