/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../config/prisma.service';
import { CreateMeasurementDto } from './dto';
import { Prisma } from '@prisma/client';

@Injectable()
export class MeasurementsService {
  constructor(private readonly prisma: PrismaService) {}

  /** A COACH may only access members they train (have a PT session with). */
  private async assertCoachScope(
    gymId: string, memberId: string, requester: { sub: string; role: string },
  ) {
    if (requester.role !== 'COACH') return; // OWNER/MANAGER unrestricted
    const link = await this.prisma.ptSession.findFirst({
      where: { gymId, memberId, coach: { userId: requester.sub } },
      select: { id: true },
    });
    if (!link) throw new ForbiddenException('Coaches can only access their assigned members');
  }

  async list(gymId: string, requester: { sub: string; role: string }, skip = 0, take = 200) {
    const where: Prisma.BodyMeasurementWhereInput = { gymId };
    if (requester.role === 'COACH') {
      const profile = await this.prisma.coachProfile.findUnique({ where: { userId: requester.sub } });
      const sessions = profile ? await this.prisma.ptSession.findMany({ where: { gymId, coachId: profile.id }, select: { memberId: true } }) : [];
      where.memberId = { in: sessions.map((s) => s.memberId) };
    }
    return this.prisma.bodyMeasurement.findMany({
      where, orderBy: { measuredAt: 'desc' }, skip, take });
  }

  async history(gymId: string, memberId: string, requester: { sub: string; role: string }) {
    const member = await this.prisma.member.findFirst({ where: { id: memberId, gymId } });
    if (!member) throw new NotFoundException('Member not found');
    await this.assertCoachScope(gymId, memberId, requester);
    return this.prisma.bodyMeasurement.findMany({
      where: { gymId, memberId },
      orderBy: { measuredAt: 'asc' },
    });
  }

  async create(
    gymId: string, memberId: string, dto: CreateMeasurementDto,
    requester: { sub: string; role: string; name?: string },
  ) {
    const member = await this.prisma.member.findFirst({ where: { id: memberId, gymId } });
    if (!member) throw new NotFoundException('Member not found');
    await this.assertCoachScope(gymId, memberId, requester);
    return this.prisma.bodyMeasurement.create({
      data: {
        gymId,
        memberId,
        measuredAt: dto.measuredAt ? new Date(dto.measuredAt) : new Date(),
        weight: dto.weight, bodyFat: dto.bodyFat, muscleMass: dto.muscleMass,
        chest: dto.chest, waist: dto.waist, hips: dto.hips, arms: dto.arms,
        notes: dto.notes, recordedBy: requester.name || 'system',
      },
    });
  }

  async remove(gymId: string, id: string) {
    const m = await this.prisma.bodyMeasurement.findFirst({ where: { id, gymId } });
    if (!m) throw new NotFoundException('Measurement not found');
    await this.prisma.bodyMeasurement.delete({ where: { id, gymId } });
    return { ok: true };
  }
}
