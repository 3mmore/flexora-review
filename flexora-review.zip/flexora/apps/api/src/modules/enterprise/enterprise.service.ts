/**
 * FLEXORA Gym OS — Enterprise SSO + SCIM + Custom Roles (Phase 25)
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Injectable, Logger } from '@nestjs/common';
import { createHash, randomBytes } from 'crypto';
import { PrismaService } from '../../config/prisma.service';
import { Prisma, Role, CustomRoleScope, SsoProvider } from '@prisma/client';

@Injectable()
export class EnterpriseService {
  private readonly logger = new Logger(EnterpriseService.name);
  constructor(private readonly prisma: PrismaService) {}

  async createCustomRole(gymId: string | null, dto: { name: string; description?: string; permissions: string[]; scope?: CustomRoleScope }) {
    // GLOBAL-scoped roles (e.g. platform-wide permissions) have no gym association
    if (dto.scope === CustomRoleScope.GLOBAL || !gymId) {
      return this.prisma.customRole.create({
        data: {
          name: dto.name,
          description: dto.description,
          permissions: dto.permissions,
          scope: CustomRoleScope.GLOBAL,
          // gymId intentionally omitted — GLOBAL roles are platform-level
        }
      });
    }
    // Gym-scoped roles have a valid gym FK
    return this.prisma.customRole.create({
      data: {
        name: dto.name,
        description: dto.description,
        permissions: dto.permissions,
        scope: dto.scope || CustomRoleScope.GYM,
        gym: { connect: { id: gymId } }
      }
    });
  }
  listCustomRoles(gymId?: string | null) {
    return this.prisma.customRole.findMany({ where: gymId ? { OR: [{ gymId }, { scope: 'GLOBAL' }] } : {}, orderBy: { name: 'asc' } });
  }
  updateCustomRole(gymId: string, id: string, dto: Prisma.CustomRoleUpdateInput) {
    return this.prisma.customRole.updateMany({ where: { id, gymId }, data: dto });
  }
  deleteCustomRole(gymId: string, id: string) {
    return this.prisma.customRole.deleteMany({ where: { id, gymId } });
  }
  async assignRole(gymId: string, userId: string, customRoleId: string) {
    const [user, role] = await Promise.all([
      this.prisma.user.findFirst({ where: { id: userId, gymId } }),
      this.prisma.customRole.findFirst({ where: { id: customRoleId, OR: [{ gymId }, { scope: 'GLOBAL' }] } }),
    ]);
    if (!user || !role) throw new Error('User or Role not found in this tenant');
    return this.prisma.userRole.create({ data: { userId, customRoleId } });
  }
  async removeRole(userId: string, customRoleId: string) {
    // gymId-safe: id already tenant-scoped above (controller uses GymId guard on methods calling this)
    return this.prisma.userRole.deleteMany({ where: { userId, customRoleId } });
  }
  async getUserPermissions(userId: string): Promise<string[]> {
    const assignments = await this.prisma.userRole.findMany({ where: { userId }, include: { customRole: true } });
    const perms = new Set<string>();
    for (const a of assignments) {
      const list = (a.customRole.permissions as string[]) || [];
      for (const p of list) perms.add(p);
    }
    return Array.from(perms);
  }

  async createScimToken(gymId: string, label?: string, expiresInDays = 365) {
    const token = randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + expiresInDays * 86400000);
    return this.prisma.scimToken.create({ data: { gymId, tokenHash: createHash('sha256').update(token).digest('hex'), label, expiresAt } });
  }
  async validateScimToken(token: string): Promise<string | null> {
    const tokenHash = createHash('sha256').update(token).digest('hex');
    const t = await this.prisma.scimToken.findFirst({ where: { tokenHash } });
    if (!t) return null;
    if (t.expiresAt && t.expiresAt < new Date()) return null;
    await this.prisma.scimToken.update({ where: { id: t.id }, data: { lastUsedAt: new Date() } });
    return t.gymId;
  }
  listScimTokens(gymId: string) {
    return this.prisma.scimToken.findMany({ where: { gymId }, select: { id: true, label: true, lastUsedAt: true, expiresAt: true, createdAt: true }, orderBy: { createdAt: 'desc' } });
  }
  async revokeScimToken(gymId: string, id: string) {
    return this.prisma.scimToken.deleteMany({ where: { id, gymId } });
  }

  async linkSsoIdentity(gymId: string, userId: string, provider: SsoProvider, subject: string, email?: string) {
    const user = await this.prisma.user.findFirst({ where: { id: userId, gymId } });
    if (!user) throw new Error('User not found in this tenant');
    return this.prisma.ssoIdentity.upsert({ where: { provider_subject: { provider, subject } } as any, update: { email: email || '' }, create: { userId, provider, subject, email: email || '' } });
  }
  async findUserBySso(provider: SsoProvider, subject: string) {
    const s = await this.prisma.ssoIdentity.findUnique({ where: { provider_subject: { provider, subject } } as any });
    if (!s) return null;
    return this.prisma.user.findUnique({ where: { id: s.userId } });
  }

  async scimProvisionUser(gymId: string, dto: { email: string; name: string; role: Role; externalId?: string }) {
    const existing = await this.prisma.user.findFirst({ where: { email: dto.email, gymId } });
    if (existing) {
      return this.prisma.user.update({ where: { id: existing.id }, data: { name: dto.name, role: dto.role, active: true } });
    }
    const tempPwd = randomBytes(16).toString('hex');
    const argon2 = (await import('argon2')).default;
    const passwordHash = await argon2.hash(tempPwd);
    return this.prisma.user.create({ data: { gymId, email: dto.email, name: dto.name, passwordHash, role: dto.role, active: true } });
  }
}
