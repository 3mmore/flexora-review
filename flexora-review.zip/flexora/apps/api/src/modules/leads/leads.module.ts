/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { WaBotModule } from '../wa-bot/wa-bot.module';
import { QueueModule } from '../queue/queue.module';
import { PrismaModule } from '../../config/prisma.module';
import { RedisModule } from '../../config/redis.module';
import { LeadsService } from './leads.service';

@Module({
  providers: [LeadsService],
  imports: [WaBotModule, QueueModule, PrismaModule, RedisModule],
  exports: [LeadsService],
})
export class LeadsModule {}
