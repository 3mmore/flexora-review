/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Leads CRM (Phase 10).
 *
 * - CRUD on leads + follow-ups
 * - AI scoring (basic heuristic; AI module can replace)
 * - AI WhatsApp follow-up queue trigger
 * - Convert lead → member
 */
import { ConflictException, Injectable, Logger, NotFoundException, BadRequestException } from '@nestjs/common';
import { EG_PHONE } from '../../common/validators/phone';
import { bustMemberListCaches } from '../../common/cache/member-list-cache';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { TenantContextService } from '../../common/services/tenant-context.service';
import { QueueService } from '../queue/queue.module';
import { Prisma, LeadStatus, LeadPriority, LeadSource, FollowUpType, FollowUpOutcome, MemberStatus } from '@prisma/client';
import { WaBotService } from '../wa-bot/wa-bot.service';
import { randomBytes } from 'crypto';
// ROUND 14 (security review, PHASE K1/K2): the ONE membership-state decision.
import { membershipStatus } from '../members/membership-status';

@Injectable()
export class LeadsService {
  private readonly logger = new Logger(LeadsService.name);
  constructor(
    private readonly prisma: PrismaService,
    private readonly queue: QueueService,
    private readonly redis: RedisService,
    private readonly waBot: WaBotService,
    private readonly tenantContext: TenantContextService,
  ) {}

  async list(gymId: string, opts: { status?: LeadStatus; priority?: LeadPriority; q?: string; page?: number; limit?: number } = {}) {
    const page = Math.max(1, opts.page || 1);
    const limit = Math.min(100, Math.max(1, opts.limit || 25));
    const leads = await this.prisma.lead.findMany({
      where: {
        gymId,
        ...(opts.status ? { status: opts.status } : {}),
        ...(opts.priority ? { priority: opts.priority } : {}),
        ...(opts.q ? {
          OR: [
            { name: { contains: opts.q, mode: 'insensitive' } },
            { mobile: { contains: opts.q } },
          ],
        } : {}),
      },
      orderBy: [{ priority: 'desc' }, { createdAt: 'desc' }],
      skip: (page - 1) * limit,
      take: limit,
    });

    // ROUND 14 (security review, PHASE K2): conversion no longer mints an
    // ACTIVE member, so the leads board must SHOW that the new member is
    // pending payment and offer the "Collect payment" action. There is no
    // Prisma relation from Lead to Member (only a plain column), so the
    // converted members are fetched in one extra tenant-scoped query and
    // attached by hand — one query for the whole page, never N.
    const ids = leads.map((l) => l.convertedMemberId).filter((id): id is string => !!id);
    if (!ids.length) return leads;
    const members = await this.prisma.member.findMany({
      where: { gymId, id: { in: ids } },
      select: {
        id: true, name: true, status: true, expiry: true, sessionsLeft: true,
        activatedAt: true, frozen: true,
        plan: { select: { id: true, name: true, type: true, price: true } },
      },
    });
    const byId = new Map(members.map((m) => [m.id, m]));
    return leads.map((l) => {
      const m = l.convertedMemberId ? byId.get(l.convertedMemberId) : null;
      if (!m) return { ...l, convertedMember: null };
      return {
        ...l,
        convertedMember: {
          id: m.id,
          name: m.name,
          status: m.status,
          expiry: m.expiry,
          sessionsLeft: m.sessionsLeft,
          activatedAt: m.activatedAt,
          // The SHARED, fail-closed verdict (PHASE K1): 'pending' until the
          // desk collects payment, then 'active'/'soon'.
          membershipStatus: membershipStatus(m),
          plan: m.plan ? { id: m.plan.id, name: m.plan.name, type: m.plan.type, price: Number(m.plan.price || 0) } : null,
        },
      };
    });
  }

  /**
   * Phase 4A: cache leads stats for 60s.
   * ROUND 13 (Phase 1): the cache key now includes the caller's forced branch.
   * RECEPTION is branch-pinned, and the Prisma middleware scopes the counts —
   * but the shared `leads:stats:<gymId>` key would hand a Reception user the
   * gym-wide (all-branch) numbers cached by an owner, i.e. a cross-branch
   * leak through the cache. Keying by scope keeps every role's stats correct.
   */
  private statsCacheKey(gymId: string): string {
    const forced = this.tenantContext.getForcedBranchId();
    return `leads:stats:${gymId}:${forced || 'all'}`;
  }

  async stats(gymId: string) {
    const key = this.statsCacheKey(gymId);
    try {
      const hit = await this.redis.get(key);
      if (hit) return JSON.parse(hit);
    } catch { /* redis down */ }
    const [total, newCount, interested, converted, lost] = await this.prisma.$transaction([
      this.prisma.lead.count({ where: { gymId } }),
      this.prisma.lead.count({ where: { gymId, status: LeadStatus.NEW } }),
      this.prisma.lead.count({ where: { gymId, status: LeadStatus.INTERESTED } }),
      this.prisma.lead.count({ where: { gymId, status: LeadStatus.CONVERTED } }),
      this.prisma.lead.count({ where: { gymId, status: LeadStatus.LOST } }),
    ]);
    const out = { total, new: newCount, interested, converted, lost };
    try { await this.redis.set(key, JSON.stringify(out), 60); } catch { /* */ }
    return out;
  }

  /** Invalidate leads stats cache after writes — every branch scope at once. */
  private async invalidateStatsCache(gymId: string) {
    try {
      // Writes can come from any role/branch: drop every scoped variant
      // (gym-wide "all" plus each pinned branch) so no role reads stale stats.
      await this.redis.delByPrefix(`leads:stats:${gymId}:`);
    } catch { /* */ }
  }

  async create(gymId: string, data: {
    name: string; mobile: string; email?: string; source?: LeadSource;
    priority?: LeadPriority; notes?: string; interestedPlanId?: string; assignedTo?: string;
    branchId?: string;
  }) {
    if (!EG_PHONE.test(data.mobile)) {
      throw new BadRequestException('Invalid Egyptian mobile number');
    }
    const aiScore = this.scoreLead(data);
    try {
      const r = await this.prisma.lead.create({
        data: {
          gymId,
          name: data.name,
          mobile: data.mobile,
          email: data.email && data.email !== '' ? data.email : null,
          source: data.source || LeadSource.WALK_IN,
          priority: data.priority || LeadPriority.MEDIUM,
          notes: data.notes,
          interestedPlanId: data.interestedPlanId && data.interestedPlanId !== '' ? data.interestedPlanId : null,
          assignedTo: data.assignedTo && data.assignedTo !== '' ? data.assignedTo : null,
          // Optional explicit branch (owner/manager targeting); for restricted
          // roles TenantGuard pins this to their own branch and the Prisma
          // scope middleware forces it onto the created row regardless.
          branchId: data.branchId || null,
          aiScore,
          aiRecommendation: this.recommend(aiScore),
        },
      });
      await this.invalidateStatsCache(gymId);
      return r;
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new ConflictException({
          code: 'LEAD_ALREADY_EXISTS',
          translationKey: 'error_already_exists',
          message: 'A lead with this phone number already exists.',
        });
      }
      throw error;
    }
  }

  async update(gymId: string, id: string, data: Prisma.LeadUpdateInput) {
    const lead = await this.get(gymId, id);
    const updated = await this.prisma.lead.update({ where: { id, gymId }, data });
    if (data.status === LeadStatus.TRIAL_COMPLETED) {
      await this.waBot.sendTrialCompletedMessage(gymId, updated);
    }
    return updated;
  }


  async get(gymId: string, id: string) {
    const l = await this.prisma.lead.findFirst({ where: { id, gymId } });
    if (!l) throw new NotFoundException('Lead not found');
    return l;
  }

  async addFollowUp(gymId: string, leadId: string, data: {
    type: FollowUpType; message?: string; scheduledAt?: Date; createdBy?: string;
  }) {
    await this.get(gymId, leadId);
    const fu = await this.prisma.leadFollowUp.create({
      data: { gymId, leadId, ...data, message: data.message || '' },
    });
    await this.prisma.lead.update({
      where: { id: leadId },
      data: {
        lastContactAt: new Date(),
        nextFollowUpAt: data.scheduledAt || null,
        status: data.type === FollowUpType.TRIAL ? LeadStatus.TRIAL_BOOKED : LeadStatus.CONTACTED,
      },
    });
    return fu;
  }

  async listFollowUps(gymId: string, leadId: string) {
    await this.get(gymId, leadId);
    return this.prisma.leadFollowUp.findMany({
      where: { gymId, leadId },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
  }

  async triggerAiFollowUp(gymId: string, leadId: string) {
    await this.get(gymId, leadId);
    return this.queue.enqueue('ai-followup', { gymId, leadId });
  }

  async convert(gymId: string, leadId: string, planId?: string, branchId?: string) {
    const lead = await this.get(gymId, leadId);
    if (lead.convertedMemberId) throw new ConflictException('Already converted');
    const finalPlanId = planId || lead.interestedPlanId || null;
    const finalBranchId = branchId || lead.branchId || null;
    if (!finalPlanId) throw new ConflictException('Lead conversion requires a gym-owned plan');
    if (!finalBranchId) throw new ConflictException('Lead conversion requires a gym-owned branch');
    const plan = await this.prisma.plan.findFirst({ where: { id: finalPlanId, gymId } });
    if (!plan) throw new ConflictException('Invalid plan for lead conversion');
    const branch = await this.prisma.branch.findFirst({ where: { id: finalBranchId, gymId } });
    if (!branch) throw new ConflictException('Invalid branch for lead conversion');
    // Atomic: create member, mark converted
    // ROUND 14 (security review, PHASE K2): converting a lead used to create a
    // member with the SCHEMA DEFAULT status (ACTIVE), a plan and NO expiry —
    // so the freshly converted member could walk straight in and train without
    // ever paying (attendance read "no expiry" as "active"). Conversion now
    // behaves exactly like POST /members: the member is REGISTERED as
    // PENDING_PAYMENT with no expiry and no sessions, and only the paid
    // activation path (a manual payment bound to this member, then
    // POST /members/:id/renew) turns it into a live membership.
    const member = await this.prisma.member.create({
      data: {
        gymId,
        branchId: finalBranchId,
        planId: finalPlanId,
        code: 'LEAD-' + randomBytes(3).toString('hex').toUpperCase(),
        name: lead.name,
        mobile: lead.mobile,
        gender: 'MALE',
        startDate: new Date(),
        expiry: null,
        sessionsLeft: plan.type === 'SESSION' ? 0 : undefined,
        status: MemberStatus.PENDING_PAYMENT,
        paymentId: null,
        activatedAt: null,
        invitationSlots: plan.invitations ?? 0,
        maxFreezes: plan.maxFreezes ?? 0,
        freezeDaysLeft: plan.freezeDays ?? 0,
      },
    });
    // The registration gets the same invitation-slot row POST /members creates,
    // so the converted member is complete the moment it is paid for.
    await this.prisma.invitationSlot.upsert({
      where: { gymId_memberId: { gymId, memberId: member.id } },
      update: {},
      create: { gymId, memberId: member.id, totalSlots: plan.invitations ?? 0, usedSlots: 0 },
    }).catch(() => undefined);
    await this.prisma.lead.update({
      where: { id: leadId },
      data: { status: LeadStatus.CONVERTED, convertedAt: new Date(), convertedMemberId: member.id },
    });
    // ROOT FIX (Phase 3, round 11): converting a lead CREATES a member row, but
    // this path only ever cleared nothing at all — the 60 s `members:list:*`
    // Redis cache kept serving the list from before the conversion, so the new
    // member was missing from every list reader (the members table, the POS
    // search, and the manual check-in dropdown on /attendance) until the TTL
    // expired. Same invalidation the members service does on create/update/
    // delete — now shared, so this path can never drift again.
    await bustMemberListCaches(this.redis, gymId);
    // The conversion also moves this lead NEW → CONVERTED, which the cached
    // leads-stats counters count, so those must go too.
    await this.invalidateStatsCache(gymId);
    return member;
  }

  async completeTrial(gymId: string, leadId: string) {
    const lead = await this.get(gymId, leadId);
    const updated = await this.prisma.lead.update({ where: { id: leadId }, data: { status: LeadStatus.TRIAL_COMPLETED } });
    await this.waBot.sendTrialCompletedMessage(gymId, updated);
    return { ok: true };
  }

  // ---- private AI helpers (heuristic baseline) ----
  private scoreLead(d: { source?: LeadSource; priority?: LeadPriority; interestedPlanId?: string; email?: string }): number {
    let score = 50;
    if (d.source === LeadSource.REFERRAL) score += 20;
    if (d.source === LeadSource.SOCIAL_MEDIA) score += 10;
    if (d.source === LeadSource.WALK_IN) score += 15;
    if (d.priority === LeadPriority.HOT) score += 20;
    if (d.interestedPlanId) score += 10;
    if (d.email) score += 5;
    return Math.min(100, Math.max(0, score));
  }

  private recommend(score: number): string {
    if (score >= 80) return 'High priority — call within 1 hour and offer a free trial.';
    if (score >= 60) return 'Medium priority — WhatsApp within 24h, follow up in 3 days.';
    return 'Low priority — drip campaign over 2 weeks.';
  }
}
