/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * ROUND 14 (security review, PHASE K1) — THE ONE decision of membership state.
 *
 * Before this file existed the "is this member allowed to train?" rule was
 * copy-pasted into five places (attendance, members list, the member portal,
 * class booking and the biometric/device check-in). They had already drifted:
 * every copy answered `active` for a member with a TIME plan and a NULL expiry,
 * so a member created outside the paid flow — a converted lead, an imported
 * row, a row touched by hand — could walk in and train for free, forever.
 *
 * The rule is now stated exactly once, and it FAILS CLOSED:
 *
 *   - PENDING_PAYMENT (registered, not paid for)      → pending  (no training)
 *   - frozen                                          → frozen   (no training)
 *   - any stored status other than ACTIVE             → expired  (no training)
 *   - SESSION plan: sessionsLeft > 0                  → active, otherwise expired
 *   - TIME plan with NO expiry                        → expired  (FAIL CLOSED —
 *     an open-ended membership is not a membership; it is a data bug, and it
 *     must never be read as "this member may train")
 *   - PACK 2, item 3: start date is still in the FUTURE → not_started
 *     (paid, valid, and NOT yet allowed to train — «لم يبدأ بعد»)
 *   - TIME plan, expiry in the past                   → expired
 *   - TIME plan, expiry within SOON_DAYS              → soon (may still train)
 *   - otherwise                                       → active
 *
 * Every gate — manual check-in, QR check-in, kiosk check-in, device/WebAuthn
 * check-in, class booking, the member portal, the members list — calls this.
 * A new path cannot drift, because there is nothing left to copy.
 */

import { startOfCairoDay } from './start-date.policy';

export type MembershipStatus = 'active' | 'expired' | 'soon' | 'frozen' | 'pending' | 'not_started';

/** Days of runway below which a live membership is reported as "expiring soon". */
export const SOON_DAYS = 7;

export interface MembershipStatusInput {
  /** The stored Member.status enum (ACTIVE / PENDING_PAYMENT / EXPIRED / …). */
  status?: string | null;
  frozen?: boolean | null;
  expiry?: Date | string | null;
  /** PACK 2, item 3: a future start date means the paid period has not begun. */
  startDate?: Date | string | null;
  sessionsLeft?: number | null;
  plan?: { type?: string | null } | null;
}

/**
 * The single verdict. Never throws, never returns null — an input it cannot
 * make sense of degrades to 'expired', which is the safe answer.
 */
export function membershipStatus(m: MembershipStatusInput | null | undefined): MembershipStatus {
  if (!m) return 'expired';

  // A registered-but-unpaid member is not a member yet. It has no expiry and
  // no sessions by construction, so without this guard every later branch
  // would read it as "active".
  if (String(m.status || '').toUpperCase() === 'PENDING_PAYMENT') return 'pending';

  if (m.frozen) return 'frozen';

  // SUSPENDED / EXPIRED / CANCELLED / anything that is not ACTIVE: no training.
  const stored = String(m.status || '').toUpperCase();
  if (stored && stored !== 'ACTIVE') return 'expired';

  // PACK 2, item 3 — «لم يبدأ بعد». A membership whose start date is still in
  // the future is PAID and VALID, but it has not begun: the member may not
  // train, and the desks are told exactly why instead of "expired".
  // Compared on Cairo calendar days, so "starts tomorrow" is not "today at
  // 00:00 UTC" for a member standing at the door at 23:30.
  if (m.startDate) {
    const start = new Date(m.startDate as any);
    if (!Number.isNaN(+start) && startOfCairoDay(start).getTime() > startOfCairoDay(new Date()).getTime()) {
      return 'not_started';
    }
  }

  if (String(m.plan?.type || '').toUpperCase() === 'SESSION') {
    return (m.sessionsLeft ?? 0) > 0 ? 'active' : 'expired';
  }

  // TIME plan (or a member with no plan at all).
  // PHASE K1 — FAIL CLOSED: no expiry means no proof of a paid period.
  const expiry = m.expiry ? new Date(m.expiry as any) : null;
  if (!expiry || Number.isNaN(+expiry)) return 'expired';

  const daysLeft = Math.round((+expiry - Date.now()) / 86400000);
  if (daysLeft < 0) return 'expired';
  if (daysLeft <= SOON_DAYS) return 'soon';
  return 'active';
}

/**
 * MAY THIS MEMBER TRAIN RIGHT NOW?
 * 'active' and 'soon' (still inside the paid period) may. Everything else —
 * expired, frozen, pending payment — may not.
 */
export function canTrain(m: MembershipStatusInput | null | undefined): boolean {
  const s = membershipStatus(m);
  return s === 'active' || s === 'soon';
}

/** The message a refused gate shows, in one place so every path says the same. */
export function trainingDenialReason(m: MembershipStatusInput | null | undefined): string {
  const s = membershipStatus(m);
  if (s === 'pending') return 'Cannot check in — membership is pending payment';
  if (s === 'frozen') return 'Cannot check in — membership is frozen';
  if (s === 'not_started') return 'Cannot check in — the membership has not started yet';
  return 'Cannot check in — membership expired';
}

/**
 * The Prisma shape every caller already has: a Member row (optionally with its
 * plan included). Adapts it to the plain input above so call sites stay one line.
 */
export function memberCanTrain(member: MembershipStatusInput | null | undefined): boolean {
  return canTrain(member);
}

/**
 * PACK 2, item 3 — the refusal a gate throws, with a STABLE MACHINE CODE and a
 * translation key, not a bare English sentence: the phone shows Arabic, and an
 * integrating device can branch on `code` without parsing prose.
 */
export function trainingDenialError(m: MembershipStatusInput | null | undefined): {
  code: string;
  translationKey: string;
  message: string;
} {
  const s = membershipStatus(m);
  const base = {
    pending: { code: 'MEMBERSHIP_PENDING_PAYMENT', translationKey: 'checkin_denied_pending' },
    frozen: { code: 'MEMBERSHIP_FROZEN', translationKey: 'checkin_denied_frozen' },
    not_started: { code: 'MEMBERSHIP_NOT_STARTED', translationKey: 'checkin_denied_not_started' },
    expired: { code: 'MEMBERSHIP_EXPIRED', translationKey: 'checkin_denied_expired' },
  }[s as 'pending' | 'frozen' | 'not_started' | 'expired'] ?? {
    code: 'MEMBERSHIP_EXPIRED',
    translationKey: 'checkin_denied_expired',
  };
  return { ...base, message: trainingDenialReason(m) };
}
