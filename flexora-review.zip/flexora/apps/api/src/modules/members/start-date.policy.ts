import { BadRequestException, ForbiddenException } from '@nestjs/common';

/**
 * Pack 2, item 3 — the start-date rules, in one place.
 *
 * MEASURED BEFORE (evidence/11-STARTDATE-MEASURE.md): the product already stored
 * `Member.startDate`, but activation and renewal both threw it away and used
 * `new Date()` at the moment the money arrived. So a membership always began
 * when it was paid for, and a renewal REPLACED the remaining days instead of
 * extending them.
 *
 * THE RULES IMPLEMENTED HERE
 *  · a start date may be in the past (the member joined earlier) or the future
 *    (they are joining next week), within +90 / −365 days of today in Cairo;
 *  · expiry is always start + the plan's own duration, measured in CALENDAR
 *    DAYS in the gym's time zone — so a 30-day plan started on 1 January ends on
 *    31 January regardless of DST, and a plan started on 31 January ends on the
 *    last day of February for a month-length plan;
 *  · a past start requires the `members.backdate` permission (OWNER by default,
 *    MANAGER only when granted);
 *  · money is NEVER backdated: the payment is always stamped now. Only the
 *    membership's own dates move.
 */

export const TZ = 'Africa/Cairo';

/** The calendar day (yyyy-mm-dd) of an instant, as seen in Cairo. */
export function cairoDay(d: Date): string {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: TZ,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(d); // en-CA renders ISO order
}

/**
 * The instant at which Cairo's calendar day `y-m-d` begins.
 *
 * Built by formatting the Cairo date and reading it back with the zone's offset,
 * rather than by `setHours(0,0,0,0)`: the server process may run in UTC (a
 * container usually does), where midnight is not the gym's midnight.
 */
function cairoMidnight(y: number, m: number, d: number): Date {
  const target = `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  const guess = Date.UTC(y, m - 1, d, 0, 0, 0, 0);
  let candidate = guess - cairoOffsetMinutes(new Date(guess)) * 60_000;
  // THE DST NIGHT HAS NO MIDNIGHT. Egypt jumps 00:00 → 01:00 on the last
  // Friday of April, so midnight of that date does not exist; the naive
  // conversion lands an hour earlier — on the PREVIOUS day, which would start a
  // membership a day early. Step forward an hour at a time (at most twice) until
  // the instant really is on the requested Cairo day; the autumn's repeated hour
  // can land a day late, so step back in that case.
  for (let i = 0; i < 3 && cairoDay(new Date(candidate)) !== target; i += 1) {
    candidate = cairoDay(new Date(candidate)) < target ? candidate + 3_600_000 : candidate - 3_600_000;
  }
  return new Date(candidate);
}

/** Midnight at the START of the Cairo day that contains `d`, as a real instant. */
export function startOfCairoDay(d: Date): Date {
  const [y, m, day] = cairoDay(d).split('-').map(Number);
  return cairoMidnight(y, m, day);
}

/** The zone's UTC offset in minutes at a given instant (Egypt changes it twice a year). */
function cairoOffsetMinutes(at: Date): number {
  const parts = new Intl.DateTimeFormat('en-US', {
    timeZone: TZ,
    hour12: false,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
  }).formatToParts(at);
  const get = (t: string) => Number(parts.find((p) => p.type === t)?.value);
  const asUtc = Date.UTC(get('year'), get('month') - 1, get('day'), get('hour') % 24, get('minute'), get('second'));
  return (asUtc - at.getTime()) / 60_000;
}

/**
 * Add whole calendar days in Cairo.
 *
 * NOT `new Date(d.getTime() + days*86400000)`: that is 24-hour arithmetic, which
 * lands an hour off across a DST change and can land a day off at midnight. The
 * membership is sold in days of a calendar, so the arithmetic is done on the
 * calendar and then resolved back to an instant.
 */
export function addCalendarDays(d: Date, days: number): Date {
  const [y, m, day] = cairoDay(d).split('-').map(Number);
  // Date.UTC normalises overflow (31 Jan + 30 → 2 Mar) exactly as a calendar does.
  const target = new Date(Date.UTC(y, m - 1, day + days));
  return cairoMidnight(target.getUTCFullYear(), target.getUTCMonth() + 1, target.getUTCDate());
}

/**
 * Add whole calendar MONTHS, clamped to the shorter month's last day: a plan
 * bought on 31 January for one month ends on 28 (or 29) February, not on 3 March.
 */
export function addCalendarMonths(d: Date, months: number): Date {
  const [y, m, day] = cairoDay(d).split('-').map(Number);
  const targetMonth = m - 1 + months;
  const y2 = y + Math.floor(targetMonth / 12);
  const m2 = ((targetMonth % 12) + 12) % 12;
  const lastDay = new Date(Date.UTC(y2, m2 + 1, 0)).getUTCDate();
  return cairoMidnight(y2, m2 + 1, Math.min(day, lastDay));
}

export const MAX_PAST_DAYS = 365;
export const MAX_FUTURE_DAYS = 90;
export const BACKDATE_PERMISSION = 'members.backdate';

export type RenewalMode = 'TODAY' | 'FROM_EXPIRY' | 'CUSTOM';

export type StartDateInput = {
  /** Explicit date chosen by the operator (ISO string), for CUSTOM / a typed date. */
  requested?: string | null;
  /** Renewal only: which of the three choices was made. */
  mode?: RenewalMode | null;
  /** Renewal only: the member's current expiry, for FROM_EXPIRY. */
  currentExpiry?: Date | null;
  now?: Date;
};

export type ResolvedStart = {
  start: Date;
  /** True when the resolved date is in the future — the member has not begun. */
  notStarted: boolean;
  /** True when a past date was used (needs the permission, and is audited). */
  backdated: boolean;
  /** Whole calendar days between today and the start; negative = past. */
  daysFromToday: number;
};

/**
 * Resolve the start date for an add, an activation or a renewal.
 * Throws BadRequestException for anything outside the window.
 */
export function resolveStartDate(input: StartDateInput, hasBackdate: boolean): ResolvedStart {
  const now = input.now ?? new Date();
  const today = startOfCairoDay(now);

  let start: Date;
  if (input.mode === 'FROM_EXPIRY') {
    // Continue from the current expiry itself, at Cairo midnight of that day.
    // `expiry` is the boundary instant at which the old period stops (it is
    // computed as start + N days, i.e. midnight of the day after the last paid
    // day), so starting there makes the two periods TOUCH: no day is lost to a
    // gap, and none is double-counted. If an old row stores an expiry mid-day,
    // the new period starts at that day's midnight and the overlap can only
    // ever favour the member.
    // No current expiry (a SESSION plan, or already lapsed) means "start
    // today", which is the honest reading of "continue".
    start = input.currentExpiry && input.currentExpiry > now
      ? startOfCairoDay(input.currentExpiry)
      : today;
  } else if (input.requested) {
    const parsed = new Date(input.requested);
    if (Number.isNaN(parsed.getTime())) throw new BadRequestException('invalid_start_date');
    start = startOfCairoDay(parsed);
  } else {
    start = today;   // the default: today, exactly as before this change
  }

  const daysFromToday = Math.round((start.getTime() - today.getTime()) / 86_400_000);

  if (daysFromToday < -MAX_PAST_DAYS) throw new BadRequestException('start_date_too_far_past');
  if (daysFromToday > MAX_FUTURE_DAYS) throw new BadRequestException('start_date_too_far_future');

  const backdated = daysFromToday < 0;
  if (backdated && !hasBackdate) throw new ForbiddenException('backdate_not_permitted');

  return { start, notStarted: daysFromToday > 0, backdated, daysFromToday };
}

/**
 * The expiry for a plan, from a start date.
 *
 * TIME plans use their own `days`; when a plan states months instead, the month
 * arithmetic clamps to the shorter month. SESSION plans have no expiry at all —
 * that is not "forever", it is "counted in visits".
 */
export function expiryFor(plan: { type: string; days?: number | null; months?: number | null }, start: Date): Date | null {
  if (plan.type !== 'TIME') return null;
  if (plan.months && !plan.days) return addCalendarMonths(start, plan.months);
  return addCalendarDays(start, plan.days || 0);
}

/** «لم يبدأ بعد» — the member exists, is paid, and has not started yet. */
export function hasNotStarted(startDate: Date | string | null | undefined, now = new Date()): boolean {
  if (!startDate) return false;
  return startOfCairoDay(new Date(startDate)).getTime() > startOfCairoDay(now).getTime();
}
