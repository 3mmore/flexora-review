/**
 * PACK 2, item 3 — the start-date rules, tested against the clock.
 *
 * These are pure functions on purpose: the whole point of the item is that the
 * date a membership begins is decided in ONE place, by rules that can be fed an
 * arbitrary "now" and checked. `Africa/Cairo` is the gym's zone, and it changes
 * its UTC offset twice a year, so a test that only runs "today in UTC" proves
 * nothing.
 */
import {
  cairoDay,
  startOfCairoDay,
  addCalendarDays,
  addCalendarMonths,
  resolveStartDate,
  expiryFor,
  hasNotStarted,
  MAX_PAST_DAYS,
  MAX_FUTURE_DAYS,
} from './start-date.policy';

const iso = (d: Date) => d.toISOString();
/** The Cairo calendar day of an instant — the only thing an operator sees. */
const day = (d: Date) => cairoDay(d);

describe('Cairo calendar arithmetic', () => {
  it('start of a Cairo day is midnight in Cairo, not in UTC', () => {
    // 2026-11-14 10:30 Cairo = 08:30 UTC (EET, UTC+2, no DST in November).
    const at = new Date('2026-11-14T08:30:00.000Z');
    expect(day(startOfCairoDay(at))).toBe('2026-11-14');
    expect(startOfCairoDay(at).toISOString()).toBe('2026-11-13T22:00:00.000Z');
  });

  it('a Cairo day boundary: 23:59 and 00:01 land on different days', () => {
    // 2026-11-14 23:59 Cairo = 21:59 UTC; 00:01 = 22:01 UTC on the 13th.
    expect(day(new Date('2026-11-14T21:59:00.000Z'))).toBe('2026-11-14');
    expect(day(new Date('2026-11-14T22:01:00.000Z'))).toBe('2026-11-15');
  });

  it('survives the spring-forward DST night (Egypt, last Friday of April)', () => {
    // Egypt moves to DST at 00:00 on the last Friday of April (clocks jump to
    // 01:00), so 24 April 2026 has NO midnight. A membership that starts that
    // day must still start on that day.
    const acrossDst = addCalendarDays(new Date('2026-04-23T12:00:00.000Z'), 1);
    expect(day(acrossDst)).toBe('2026-04-24');
    // and the arithmetic is a calendar day, not a 24h block
    const start = new Date('2026-04-20T12:00:00.000Z');
    expect(day(addCalendarDays(start, 30))).toBe('2026-05-20');
  });

  it('every Cairo day of the year resolves back to itself (DST property test)', () => {
    // The two transitions are the only places this can break; walk both
    // windows a whole week either side, hour by hour.
    const bad: string[] = [];
    for (const month of [3, 4, 9, 10]) {
      for (let d = 1; d <= 28; d += 1) {
        const at = new Date(Date.UTC(2026, month, d, 9, 0, 0));
        const want = day(at);
        const got = day(startOfCairoDay(at));
        if (got !== want) bad.push(`${want} -> ${got}`);
      }
    }
    expect(bad).toEqual([]);
  });

  it('survives the autumn-back DST night (last Thursday of October)', () => {
    // Egypt returns to EET at 00:00 on 2026-10-29 (clocks back to 23:00).
    const start = new Date('2026-10-26T09:00:00.000Z');
    expect(day(addCalendarDays(start, 7))).toBe('2026-11-02');
  });

  it('a leap day is a real day: 29 February 2028', () => {
    const feb28 = new Date('2028-02-28T09:00:00.000Z');
    expect(day(addCalendarDays(feb28, 1))).toBe('2028-02-29');
    expect(day(addCalendarDays(feb28, 2))).toBe('2028-03-01');
  });

  it('clamps a month to the shorter month: 31 January + 1 month = 28/29 February', () => {
    expect(day(addCalendarMonths(new Date('2027-01-31T09:00:00.000Z'), 1))).toBe('2027-02-28');
    expect(day(addCalendarMonths(new Date('2028-01-31T09:00:00.000Z'), 1))).toBe('2028-02-29');
    expect(day(addCalendarMonths(new Date('2027-01-31T09:00:00.000Z'), 12))).toBe('2028-01-31');
  });

  it('day-count plans cross a month end as a calendar does (31 Jan + 30 days = 2 Mar)', () => {
    expect(day(addCalendarDays(new Date('2027-01-31T09:00:00.000Z'), 30))).toBe('2027-03-02');
    expect(day(addCalendarDays(new Date('2027-01-31T09:00:00.000Z'), 28))).toBe('2027-02-28');
  });
});

describe('resolveStartDate — the three windows', () => {
  const now = new Date('2026-11-14T08:30:00.000Z');   // 14 Nov 2026, Cairo

  it('no date at all = TODAY (the behaviour before item 3, unchanged)', () => {
    const r = resolveStartDate({ now }, true);
    expect(day(r.start)).toBe('2026-11-14');
    expect(r.daysFromToday).toBe(0);
    expect(r.backdated).toBe(false);
    expect(r.notStarted).toBe(false);
  });

  it('today given explicitly is today', () => {
    const r = resolveStartDate({ requested: '2026-11-14', now }, true);
    expect(day(r.start)).toBe('2026-11-14');
    expect(r.daysFromToday).toBe(0);
  });

  it('a PAST date is allowed with the permission, flagged as backdated', () => {
    const r = resolveStartDate({ requested: '2026-10-01', now }, true);
    expect(day(r.start)).toBe('2026-10-01');
    expect(r.daysFromToday).toBe(-44);
    expect(r.backdated).toBe(true);
  });

  it('a PAST date without the permission is refused', () => {
    expect(() => resolveStartDate({ requested: '2026-10-01', now }, false))
      .toThrow(/backdate_not_permitted/);
  });

  it('a FUTURE date needs no permission — anyone who can add a member may schedule one', () => {
    const r = resolveStartDate({ requested: '2026-12-01', now }, false);
    expect(day(r.start)).toBe('2026-12-01');
    expect(r.notStarted).toBe(true);
    expect(r.daysFromToday).toBe(17);
  });

  it(`past is limited to ${MAX_PAST_DAYS} days`, () => {
    expect(() => resolveStartDate({ requested: '2025-11-13', now }, true))
      .toThrow(/start_date_too_far_past/);
    // exactly on the limit is allowed (the limit is inclusive)
    const edge = resolveStartDate({ requested: '2025-11-14', now }, true);
    expect(edge.daysFromToday).toBe(-365);
  });

  it(`future is limited to ${MAX_FUTURE_DAYS} days`, () => {
    expect(() => resolveStartDate({ requested: '2027-02-13', now }, false))
      .toThrow(/start_date_too_far_future/);
    const edge = resolveStartDate({ requested: '2027-02-12', now }, false);
    expect(edge.daysFromToday).toBe(90);
  });

  it('an unparseable date is a 400, not a NaN membership', () => {
    expect(() => resolveStartDate({ requested: 'not-a-date', now }, true)).toThrow(/invalid_start_date/);
  });

  it('a date at 23:59 Cairo is that day, not the next one in UTC', () => {
    // 14 Nov 23:59 Cairo = 21:59Z
    const r = resolveStartDate({ requested: '2026-11-14T23:59:00+02:00', now }, true);
    expect(day(r.start)).toBe('2026-11-14');
  });

  it('a date at 00:01 Cairo is that day', () => {
    const r = resolveStartDate({ requested: '2026-11-15T00:01:00+02:00', now }, true);
    expect(day(r.start)).toBe('2026-11-15');
    expect(r.notStarted).toBe(true);
  });
});

describe('resolveStartDate — renewal modes', () => {
  const now = new Date('2026-11-14T08:30:00.000Z');

  it('TODAY (the default) is exactly the old behaviour', () => {
    const r = resolveStartDate({ mode: 'TODAY', now }, true);
    expect(day(r.start)).toBe('2026-11-14');
  });

  it('FROM_EXPIRY starts where the old period stopped — the two periods touch, no gap and no lost day', () => {
    // A 30-day plan started 1 Dec 2026 expires at 31 Dec 2026 00:00 Cairo
    // (= 30 Dec 22:00Z): that instant is the first moment of 31 Dec, the day
    // after the last paid day. The new period starts exactly there.
    const expiry = expiryFor({ type: 'TIME', days: 30 }, startOfCairoDay(new Date('2026-12-01T09:00:00.000Z')))!;
    expect(day(expiry)).toBe('2026-12-31');
    const r = resolveStartDate({ mode: 'FROM_EXPIRY', currentExpiry: expiry, now }, true);
    expect(day(r.start)).toBe('2026-12-31');
    // contiguous: the day the old period stops is the day the new one starts
    expect(+r.start).toBe(+expiry);
  });

  it('FROM_EXPIRY on an already-expired membership starts today (nothing to continue)', () => {
    const r = resolveStartDate({ mode: 'FROM_EXPIRY', currentExpiry: new Date('2026-10-01T00:00:00.000Z'), now }, true);
    expect(day(r.start)).toBe('2026-11-14');
  });

  it('FROM_EXPIRY with no expiry (a SESSION plan) starts today', () => {
    const r = resolveStartDate({ mode: 'FROM_EXPIRY', currentExpiry: null, now }, true);
    expect(day(r.start)).toBe('2026-11-14');
  });

  it('CUSTOM carries its date and obeys the same window and permission', () => {
    const r = resolveStartDate({ mode: 'CUSTOM', requested: '2027-01-05', now }, false);
    expect(day(r.start)).toBe('2027-01-05');
    expect(r.notStarted).toBe(true);
  });
});

describe('expiryFor — start + the plan’s own duration', () => {
  it('a 30-day plan from the start date', () => {
    expect(day(expiryFor({ type: 'TIME', days: 30 }, new Date('2026-11-14T08:30:00.000Z'))!)).toBe('2026-12-14');
  });

  it('a 90-day plan started in the past ends in the past (the membership is over on arrival)', () => {
    const start = new Date('2026-07-01T08:30:00.000Z');
    const exp = expiryFor({ type: 'TIME', days: 90 }, start)!;
    expect(day(exp)).toBe('2026-09-29');
    expect(+exp).toBeLessThan(+new Date('2026-11-14T08:30:00.000Z'));
  });

  it('a SESSION plan has no expiry at all (it is counted in visits, not days)', () => {
    expect(expiryFor({ type: 'SESSION', days: 30 }, new Date())).toBeNull();
  });

  it('0-day and missing durations are a same-day membership, never a NaN date', () => {
    expect(day(expiryFor({ type: 'TIME', days: 0 }, new Date('2026-11-14T08:30:00.000Z'))!)).toBe('2026-11-14');
    expect(day(expiryFor({ type: 'TIME' }, new Date('2026-11-14T08:30:00.000Z'))!)).toBe('2026-11-14');
  });
});

describe('hasNotStarted — «لم يبدأ بعد»', () => {
  it('is true for a future start, false for today and for the past', () => {
    const now = new Date('2026-11-14T08:30:00.000Z');
    expect(hasNotStarted(new Date('2026-11-15T00:00:00.000Z'), now)).toBe(true);
    expect(hasNotStarted(new Date('2026-11-14T00:00:00.000Z'), now)).toBe(false);
    expect(hasNotStarted(new Date('2026-10-01T00:00:00.000Z'), now)).toBe(false);
    expect(hasNotStarted(null, now)).toBe(false);
  });

  it('does not call a start later TODAY "not started"', () => {
    const now = new Date('2026-11-14T08:30:00.000Z');   // 10:30 Cairo
    expect(hasNotStarted(new Date('2026-11-14T15:00:00.000Z'), now)).toBe(false);  // 17:00 Cairo today
  });
});
