/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Controller, Post, UseGuards, UseInterceptors, UploadedFile, Body, BadRequestException, HttpException, ServiceUnavailableException } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { randomBytes } from 'crypto';
import { mkdirSync, existsSync } from 'fs';
import { basename, resolve, sep } from 'path';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { MembersImportService, ColumnMapping, PlanMapping } from './members-import.service';

const DEFAULT_IMPORT_DIR = '/var/backups/flexora/imports';

/**
 * PHASE N1 — no environment read and no filesystem side effect at import time.
 *
 * Both used to happen at module scope, which meant (a) the resolved directory
 * depended on whether `.env` had been injected before this file was imported,
 * and (b) an unusable IMPORT_UPLOAD_DIR aborted the whole process *before* the
 * environment validator could report anything (PHASE M4.8 observed exactly
 * that). Resolution and creation now happen on first use, and
 * `validateRuntimeDirs()` in config/env-validation.ts reports an unwritable path
 * up front in production — so the operator still finds out at boot, from the
 * validator, alongside every other misconfiguration.
 */
export function importDir(): string {
  const dir = process.env.IMPORT_UPLOAD_DIR || DEFAULT_IMPORT_DIR;
  try {
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
    return dir;
  } catch (err) {
    const code = (err as NodeJS.ErrnoException)?.code || 'unknown error';
    throw new ServiceUnavailableException(
      `IMPORT_UPLOAD_DIR is not usable: cannot create the member-import ` +
      `directory ${dir} (${code}). Set IMPORT_UPLOAD_DIR to a directory the API ` +
      `process is allowed to create, or pre-create it.`,
    );
  }
}

/**
 * PHASE N1 — multer's `destination` callback, and why it must never throw.
 *
 * `destination` runs inside a busboy stream event (`Multipart._write` ->
 * `HeaderParser.cb` -> `DiskStorage._handleFile`). An exception thrown there is
 * not inside Nest's request pipeline, so nothing catches it: it becomes an
 * uncaught exception and takes the whole process down. Verified live — a single
 * authenticated `POST /api/members/import/preview` with an unusable
 * IMPORT_UPLOAD_DIR killed the API instead of answering 503, i.e. one request
 * from one staff account could deny service to the whole gym.
 *
 * Errors therefore leave through the callback, which multer forwards to
 * `next(err)` and Nest renders as a normal HTTP error response.
 */
export function memberImportDestination(
  req: Express.Request & { gymId?: string },
  _file: Express.Multer.File,
  cb: (error: Error | null, destination: string) => void,
): void {
  if (!req.gymId) {
    cb(new BadRequestException('Tenant context is required'), '');
    return;
  }
  const dir = process.env.IMPORT_UPLOAD_DIR || DEFAULT_IMPORT_DIR;
  try {
    const tenantDir = resolve(importDir(), req.gymId);
    mkdirSync(tenantDir, { recursive: true });
    cb(null, tenantDir);
  } catch (err) {
    const code = (err as NodeJS.ErrnoException)?.code;
    cb(
      err instanceof HttpException
        ? err
        : new ServiceUnavailableException(
            `IMPORT_UPLOAD_DIR is not usable: cannot create the member-import ` +
            `directory under ${dir} (${code || 'unknown error'}). Set ` +
            `IMPORT_UPLOAD_DIR to a directory the API process is allowed to ` +
            `create, or pre-create it.`,
          ),
      '',
    );
  }
}

@Controller('members/import')
@UseGuards(JwtAuthGuard, TenantGuard)
export class MembersImportController {
  constructor(private readonly importSvc: MembersImportService) {}

  @Post('preview')
  @Permissions('members.create')
  @UseInterceptors(FileInterceptor('file', {
    storage: diskStorage({
      // PHASE N1: a named function, so (a) nothing is read or created at import
      // time and (b) the "never throw inside a multer callback" rule above is
      // unit-testable in members-import.controller.spec.ts.
      destination: memberImportDestination,
      filename: (req, file, cb) => {
        const safe = randomBytes(16).toString('hex');
        const ext = file.originalname.split('.').pop() || 'xlsx';
        cb(null, `import-${safe}.${ext}`);
      },
    }),
    fileFilter: (req, file, cb) => {
      const ext = file.originalname.split('.').pop()?.toLowerCase();
      if (!['xlsx', 'csv'].includes(ext || '')) {
        cb(new BadRequestException('Only .xlsx and .csv files allowed'), false);
        return;
      }
      cb(null, true);
    },
    limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  }))
  async preview(
    @UploadedFile() file: Express.Multer.File,
    @GymId() gymId: string,
  ) {
    if (!file) throw new BadRequestException('No file uploaded');
    const result = await this.importSvc.preview(file.path, gymId);
    return { ...result, uploadId: file.filename };
  }

  /**
   * ROUND 13 (Phase 4): the distinct plan names for the mapping the owner
   * CONFIRMED in step 2 — called when advancing to the plan-mapping step,
   * because the column mapping is only final after the owner's edits.
   */
  @Post('plan-names')
  @Permissions('members.create')
  async planNames(
    @GymId() gymId: string,
    @Body() body: { uploadId: string; mapping: ColumnMapping },
  ) {
    const filePath = this.resolveUploadPath(gymId, body.uploadId);
    return this.importSvc.planNames(filePath, body.mapping || {});
  }

  @Post('confirm')
  @Permissions('members.create')
  async confirm(
    @GymId() gymId: string,
    @Body() body: {
      uploadId: string;
      mapping: ColumnMapping;
      options: {
        skipDuplicates?: boolean;
        updateExisting?: boolean;
        defaultPlanId?: string;
        defaultBranchId?: string;
        // ROUND 13 (Phase 4): the owner's per-file-plan-name decisions.
        planMapping?: PlanMapping;
      };
    },
    // ROUND 13 (security review, PHASE B): the acting user — the service
    // requires plans.manage whenever the mapping creates plans.
    @CurrentUser() actor: any,
  ) {
    const filePath = this.resolveUploadPath(gymId, body.uploadId);
    return this.importSvc.confirm(
      filePath,
      gymId,
      body.mapping,
      body.options || {},
      actor,
    );
  }

  /** Validate the upload id (shape + tenant-directory containment) and return
   *  the absolute path of the uploaded file inside this gym's directory. */
  private resolveUploadPath(gymId: string, rawUploadId: string): string {
    const uploadId = basename(String(rawUploadId || ''));
    if (!/^import-[a-f0-9]{32}\.(xlsx|csv)$/.test(uploadId)) {
      throw new BadRequestException('Invalid upload id');
    }
    const tenantDir = resolve(importDir(), gymId);
    const filePath = resolve(tenantDir, uploadId);
    if (!filePath.startsWith(`${tenantDir}${sep}`)) {
      throw new BadRequestException('Invalid upload id');
    }
    return filePath;
  }
}