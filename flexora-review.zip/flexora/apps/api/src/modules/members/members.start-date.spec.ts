/**
 * PACK 2, item 3 — the start date on ADD, ACTIVATE and RENEW, at the service
 * level (money and audit included).
 *
 * What each test is protecting:
 *  · the default is still TODAY, so a plain "renew" or "collect payment" does
 *    exactly what it did before item 3;
 *  · "from current expiry" EXTENDS instead of replacing the remaining days
 *    (renew() used to throw them away — see evidence/11-STARTDATE-MEASURE.md §3);
 *  · a past date is refused without `members.backdate` and allowed with it;
 *  · the MONEY is never backdated: the payment call carries no date at all, so
 *    the payment row is stamped by the database at the moment it is taken;
 *  · every non-today start is written to the tenant AuditLog with who/when/why.
 */
import { MembersService } from './members.service';
import { ForbiddenException, BadRequestException, ConflictException } from '@nestjs/common';
import { cairoDay } from './start-date.policy';

const noopRedis: any = { del: jest.fn(), get: jest.fn(), set: jest.fn() };
const realtime: any = { emitToGym: jest.fn() };

const PLAN = { id: 'plan-1', name: '3 months', type: 'TIME', days: 90, price: 900, invitations: 5 };

function baseService(overrides: { member?: any; memberUpdate?: jest.Mock; prisma?: any } = {}) {
  const member = overrides.member ?? {
    id: 'm1',
    gymId: 'gym1',
    branchId: 'b1',
    name: 'Ahmed Hassan Ali',
    status: 'ACTIVE',
    frozen: false,
    activatedAt: new Date('2026-01-05T09:00:00.000Z'),
    startDate: new Date('2026-01-05T00:00:00.000Z'),
    expiry: new Date('2026-04-05T00:00:00.000Z'),
    sessionsLeft: 0,
    plan: PLAN,
    planId: PLAN.id,
  };
  const tx: any = {
    member: { update: overrides.memberUpdate ?? jest.fn(async ({ data }: any) => ({ ...member, ...data })) },
    invitationSlot: { upsert: jest.fn(async () => ({})) },
  };
  const prisma: any = {
    member: { findFirst: jest.fn(async () => member), update: tx.member.update },
    plan: { findFirst: jest.fn(async () => PLAN) },
    payment: { findFirst: jest.fn(async () => ({ id: 'pay-1', status: 'PAID', amount: 900, purpose: 'MANUAL_MEMBERSHIP' })) },
    invoice: { findFirst: jest.fn(async () => null) },
    auditLog: { create: jest.fn(async (args: any) => args) },
    branch: { findUnique: jest.fn(async () => ({ name: 'Nasr City' })) },
    $transaction: jest.fn(async (cb: any) => cb(tx)),
    withTenant: jest.fn(async (_g: string, cb: any) => cb(tx)),
    outsideTransaction: (fn: any) => fn(),
    ...(overrides.prisma ?? {}),
  };
  const svc = new MembersService(prisma, noopRedis, realtime);
  // The two heavy helpers are exercised by their own suites; here we only care
  // WHERE the dates land and WHAT money call is made.
  (svc as any).createMembershipFinancials = jest.fn(async () => ({}));
  (svc as any).invalidate = jest.fn(async () => undefined);
  (svc as any).payments = () => ({
    createManualPayment: jest.fn(async () => ({ payment: { id: 'pay-new' } })),
  });
  return { svc, prisma, tx, member };
}

const owner = { id: 'u1', name: 'Owner', role: 'OWNER', gymId: 'gym1' };
const reception = { id: 'u2', name: 'Reception', role: 'RECEPTION', gymId: 'gym1' };
const soon = (days: number) => new Date(Date.now() + days * 86_400_000);

describe('renew — the three modes', () => {
  it('DEFAULT (no date, no mode) is still TODAY and start + plan duration', async () => {
    const { svc, tx } = baseService();
    await svc.renew('gym1', 'm1', { paymentId: 'pay-1' } as any, owner);
    const data = tx.member.update.mock.calls[0][0].data;
    expect(cairoDay(data.startDate)).toBe(cairoDay(new Date()));
    expect(cairoDay(data.expiry)).toBe(cairoDay(new Date(Date.now() + 90 * 86_400_000)));
  });

  it('TODAY explicitly is the same as the default', async () => {
    const { svc, tx } = baseService();
    await svc.renew('gym1', 'm1', { paymentId: 'pay-1', mode: 'TODAY' } as any, owner);
    const data = tx.member.update.mock.calls[0][0].data;
    expect(cairoDay(data.startDate)).toBe(cairoDay(new Date()));
  });

  it('FROM_EXPIRY extends the remaining days instead of deleting them', async () => {
    // The member has 40 days left. Renewing for 90 must give 40 + 90, not 90.
    const expiry = new Date(Date.now() + 40 * 86_400_000);
    const { svc, tx } = baseService({
      member: {
        id: 'm1', gymId: 'gym1', branchId: 'b1', name: 'Ahmed', status: 'ACTIVE', frozen: false,
        activatedAt: new Date(), startDate: new Date(Date.now() - 50 * 86_400_000), expiry,
        sessionsLeft: 0, plan: PLAN, planId: PLAN.id,
      },
    });
    await svc.renew('gym1', 'm1', { paymentId: 'pay-1', mode: 'FROM_EXPIRY' } as any, owner);
    const data = tx.member.update.mock.calls[0][0].data;
    expect(cairoDay(data.startDate)).toBe(cairoDay(expiry));          // where the old period stopped
    expect(cairoDay(data.expiry)).toBe(cairoDay(new Date(Date.now() + 130 * 86_400_000)));
  });

  it('FROM_EXPIRY on a lapsed membership starts today (nothing to continue)', async () => {
    const { svc, tx } = baseService({
      member: {
        id: 'm1', gymId: 'gym1', branchId: 'b1', name: 'Ahmed', status: 'EXPIRED', frozen: false,
        activatedAt: new Date('2025-01-01'), startDate: new Date('2025-01-01'),
        expiry: new Date('2025-04-01'), sessionsLeft: 0, plan: PLAN, planId: PLAN.id,
      },
    });
    await svc.renew('gym1', 'm1', { paymentId: 'pay-1', mode: 'FROM_EXPIRY' } as any, owner);
    const data = tx.member.update.mock.calls[0][0].data;
    expect(cairoDay(data.startDate)).toBe(cairoDay(new Date()));
  });

  it('CUSTOM with a FUTURE date schedules the period and needs no extra permission', async () => {
    const { svc, tx } = baseService();
    const future = new Date(Date.now() + 10 * 86_400_000).toISOString().slice(0, 10);
    await svc.renew('gym1', 'm1', { paymentId: 'pay-1', mode: 'CUSTOM', startDate: future } as any, reception);
    const data = tx.member.update.mock.calls[0][0].data;
    expect(cairoDay(data.startDate)).toBe(future);
    expect(cairoDay(data.expiry)).toBe(cairoDay(new Date(new Date(future).getTime() + 90 * 86_400_000)));
  });

  it('CUSTOM with a PAST date is refused for a receptionist without members.backdate', async () => {
    const { svc, prisma } = baseService();
    const past = new Date(Date.now() - 10 * 86_400_000).toISOString().slice(0, 10);
    await expect(
      svc.renew('gym1', 'm1', { paymentId: 'pay-1', mode: 'CUSTOM', startDate: past } as any, reception),
    ).rejects.toBeInstanceOf(ForbiddenException);
    // and nothing was written
    expect(prisma.$transaction).not.toHaveBeenCalled();
  });

  it('CUSTOM with a PAST date is allowed for the OWNER and is audited with the reason', async () => {
    const { svc, tx, prisma } = baseService();
    const past = new Date(Date.now() - 10 * 86_400_000).toISOString().slice(0, 10);
    await svc.renew('gym1', 'm1', {
      paymentId: 'pay-1', mode: 'CUSTOM', startDate: past, startDateReason: 'joined on the 4th',
    } as any, owner);
    expect(cairoDay(tx.member.update.mock.calls[0][0].data.startDate)).toBe(past);
    const audit = prisma.auditLog.create.mock.calls[0][0].data;
    expect(audit.action).toBe('member_start_date_renew');
    expect(audit.actorId).toBe('u1');
    expect(audit.entityId).toBe('m1');
    expect(audit.meta.reason).toBe('joined on the 4th');
    expect(audit.meta.backdated).toBe(true);
  });

  it('a past date beyond the 365-day limit is a 400 even for the owner', async () => {
    const { svc } = baseService();
    const tooOld = new Date(Date.now() - 400 * 86_400_000).toISOString().slice(0, 10);
    await expect(
      svc.renew('gym1', 'm1', { paymentId: 'pay-1', mode: 'CUSTOM', startDate: tooOld } as any, owner),
    ).rejects.toBeInstanceOf(BadRequestException);
  });

  it('a date beyond the 90-day future limit is a 400', async () => {
    const { svc } = baseService();
    const tooFar = new Date(Date.now() + 120 * 86_400_000).toISOString().slice(0, 10);
    await expect(
      svc.renew('gym1', 'm1', { paymentId: 'pay-1', mode: 'CUSTOM', startDate: tooFar } as any, owner),
    ).rejects.toBeInstanceOf(BadRequestException);
  });

  it('the second renewal of the same day is refused (double tap)', async () => {
    const { svc, prisma } = baseService();
    (prisma.invoice.findFirst as jest.Mock).mockResolvedValueOnce({ id: 'inv-1' });
    await expect(
      svc.renew('gym1', 'm1', { paymentId: 'pay-1' } as any, owner),
    ).rejects.toBeInstanceOf(BadRequestException);
  });

  it('a TODAY renew writes no audit row (only exceptions are audited)', async () => {
    const { svc, prisma } = baseService();
    await svc.renew('gym1', 'm1', { paymentId: 'pay-1' } as any, owner);
    expect(prisma.auditLog.create).not.toHaveBeenCalled();
  });
});

describe('renew — money is never backdated', () => {
  it('the payment call carries no date: the payment row is stamped when it is taken', async () => {
    const { svc } = baseService();
    const createManualPayment = jest.fn(async () => ({ payment: { id: 'pay-new' } }));
    (svc as any).payments = () => ({ createManualPayment });
    const past = new Date(Date.now() - 30 * 86_400_000).toISOString().slice(0, 10);
    await svc.renew('gym1', 'm1', { paymentId: 'pay-2', mode: 'CUSTOM', startDate: past } as any, owner);
    // renew() consumes an existing payment; it never creates a dated one. The
    // activation path is the one that creates manual payments — see the test
    // below, and the live DB proof in evidence/12-STARTDATE-MONEY.md.
    expect(createManualPayment).not.toHaveBeenCalled();
  });

  it('activating with a past start date books the payment with NO date argument', async () => {
    const { svc, tx } = baseService({
      member: {
        id: 'm1', gymId: 'gym1', branchId: 'b1', name: 'Ahmed', status: 'PENDING_PAYMENT', frozen: false,
        activatedAt: null, startDate: new Date(), expiry: null, sessionsLeft: 0, plan: PLAN, planId: PLAN.id,
      },
    });
    const createManualPayment = jest.fn(async () => ({ payment: { id: 'pay-new' } }));
    (svc as any).payments = () => ({ createManualPayment });
    const past = new Date(Date.now() - 30 * 86_400_000).toISOString().slice(0, 10);
    await svc.activateWithPayment('gym1', 'm1', { amount: 900, method: 'CASH', startDate: past } as any, owner);
    expect(createManualPayment).toHaveBeenCalledTimes(1);
    const args = createManualPayment.mock.calls[0];
    // (gymId, userId, payload, tx) — the payload has amount/method/member and
    // deliberately NO date field: a payment taken today is a payment taken today.
    expect(Object.keys(args[2]).sort()).toEqual(['amount', 'memberId', 'memberName', 'method']);
    expect(cairoDay(tx.member.update.mock.calls[0][0].data.startDate)).toBe(past);
  });
});

describe('activate — a paid membership that has not started', () => {
  const notStartedMember = {
    id: 'm1', gymId: 'gym1', branchId: 'b1', name: 'Ahmed', status: 'ACTIVE', frozen: false,
    activatedAt: new Date(Date.now() + 5 * 86_400_000),
    startDate: soon(5), expiry: soon(95), sessionsLeft: 0, plan: PLAN, planId: PLAN.id,
  };

  it('refuses a second activation with MEMBER_ALREADY_PAID', async () => {
    const { svc } = baseService({ member: notStartedMember });
    await expect(
      svc.activateWithPayment('gym1', 'm1', { amount: 900, method: 'CASH' } as any, owner),
    ).rejects.toBeInstanceOf(ConflictException);
    try {
      await svc.activateWithPayment('gym1', 'm1', { amount: 900, method: 'CASH' } as any, owner);
    } catch (e: any) {
      expect(e.getResponse().code).toBe('MEMBER_ALREADY_PAID');
    }
  });

  it('reports the member as not_started, not as expired and not as active', () => {
    const { svc } = baseService();
    expect(svc.computeStatus(notStartedMember as any)).toBe('not_started');
  });
});
