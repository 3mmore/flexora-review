/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { forwardRef, Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { SecurityModule } from '../../common/security/security.module';
import { MembersService } from './members.service';
import { MembersController } from './members.controller';
import { MembersImportController } from './members-import.controller';
import { MembersImportService } from './members-import.service';
import { AiModule } from '../ai/ai.module';
import { BillingModule } from '../billing/billing.module';
import { NotificationsModule } from '../notifications/notifications.module';

@Module({
  // ROUND 14 (security review, PHASE K4): MembersService records the payment
  // that activates a membership, so it needs BillingService. BillingModule
  // imports MembersModule (PaymobService confirms renewals through
  // MembersService), hence the forwardRef on this side.
  imports: [JwtModule.register({}), AiModule, NotificationsModule, SecurityModule, forwardRef(() => BillingModule)],
  controllers: [MembersController, MembersImportController],
  providers: [MembersService, MembersImportService],
  exports: [MembersService],
})
export class MembersModule {}