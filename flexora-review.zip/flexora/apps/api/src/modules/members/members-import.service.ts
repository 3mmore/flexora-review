/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Injectable, BadRequestException, ForbiddenException, Optional } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { EncryptionService } from '../../common/security/encryption.service';
import { bustMemberListCaches } from '../../common/cache/member-list-cache';
import { AiBrainService } from '../ai/ai-brain.service';
import { PermissionsService } from '../permissions/permissions.service';
import { parseFlexibleDate } from '../../common/utils/date-parser';
import { normalizeMobile } from '../../common/utils/mobile-normalizer';
import * as ExcelJS from 'exceljs';
import * as Papa from 'papaparse';
import * as fs from 'fs';
import { randomBytes } from 'crypto';

// The Flexora fields members can be mapped to
export const FLEXORA_FIELDS = [
  'name', 'mobile', 'email', 'dob', 'gender',
  'nationalId', 'planName', 'startDate',
  'expiryDate', 'sessionsLeft', 'branch',
  'notes', 'status',
] as const;

export type FlexoraField = typeof FLEXORA_FIELDS[number];

export type ColumnMapping = Record<string, FlexoraField | null>;

interface ParsedRow {
  [key: string]: unknown;
}

/**
 * PHASE 9 — why a row failed, as data instead of prose.
 *
 * The results screen used to show only free-text row reasons, so "the import
 * failed" could mean two very different things: the member already exists
 * (duplicate prevention doing its job) or nothing in the file could be matched
 * to a plan (a real configuration problem). Each failure now carries a code,
 * and `confirm()` returns counts per code so the UI can show the two side by
 * side at the top instead of leaving the user to read every row.
 */
export type ImportErrorCode =
  | 'DUPLICATE'
  | 'NO_PLAN_MATCH'
  | 'NO_BRANCH_MATCH'
  | 'VALIDATION'
  // ROUND 14 (security review, PHASE K3): the row would have created a member
  // who can train with no proof of a paid period (no expiry on a time plan, no
  // sessions on a session plan). Reported separately so the results screen can
  // say "N rows need an expiry date" instead of burying it in "other".
  | 'MISSING_EXPIRY'
  | 'MISSING_SESSIONS'
  | 'OTHER';

/**
 * ROUND 14 (security review, PHASE K3) — how imported rows land:
 *   'paid'    → ACTIVE memberships (requires the members.import permission)
 *   'pending' → PENDING_PAYMENT registrations (cannot train until paid)
 *   'expired' → EXPIRED archive records (cannot train, dates kept as data)
 */
export type ImportActivation = 'paid' | 'pending' | 'expired';

export interface ImportRowError {
  row: number;
  reason: string;
  code: ImportErrorCode;
}

class ImportRowFailure extends Error {
  constructor(message: string, readonly code: ImportErrorCode) {
    super(message);
  }
}

/**
 * ROUND 13 (Phase 4) — the pre-import plan-mapping step.
 *
 * A file's plan names rarely match the gym's plans one-to-one, so rows used to
 * fail with "No plan matched". Before the import runs, the owner now decides
 * per DISTINCT file plan name: use an existing plan, create the plan right
 * now (name/price/duration), or skip it (those rows fail with a clear reason).
 */
export type PlanMappingEntry =
  | { action: 'existing'; planId: string }
  | { action: 'create'; name: string; price: number; days: number; type?: 'SESSION' | 'TIME'; sessions?: number }
  | { action: 'skip' };

export type PlanMapping = Record<string, PlanMappingEntry>;

/** One file plan name is one decision key: trimmed, whitespace-collapsed,
 *  lowercased — so "Gold Annual" and "gold  annual " are the same entry. */
function normalizePlanKey(name: string): string {
  return String(name || '').trim().replace(/\s+/g, ' ').toLowerCase();
}

@Injectable()
export class MembersImportService {
  constructor(
    private prisma: PrismaService,
    private encryption: EncryptionService,
    private aiBrain: AiBrainService,
    // Optional so a Redis-less deployment still imports; when present the
    // caches are dropped so the imported members show up immediately.
    @Optional() private readonly redis?: RedisService,
    // ROUND 13 (security review, PHASE B): creating plans from the plan-mapping
    // step is a plans.manage operation, not a members.create one.
    private readonly permissions?: PermissionsService,
  ) {}

  // ── STEP 1: Parse file and get AI mapping ──────────────────────────────────
  async preview(filePath: string, gymId: string) {
    const { headers, rows } = await this.parseFile(filePath);

    if (!headers.length) {
      throw new BadRequestException('File appears to be empty');
    }

    // Get AI column mapping
    const mapping = await this.aiMapColumns(headers, gymId);

    // Build preview rows (first 5)
    const preview = rows.slice(0, 5).map(row => this.applyMapping(row, mapping));

    const mappedCount = Object.values(mapping).filter(v => v !== null).length;

    // ROUND 13 (Phase 4): every DISTINCT plan name in the file (with its row
    // count) so the owner can decide each one in the plan-mapping step.
    const planNames = this.collectPlanNames(rows, mapping);

    return {
      totalRows: rows.length,
      columns: headers,
      mapping,
      preview,
      warnings: this.buildWarnings(mapping, headers, rows.length),
      aiMappedCount: mappedCount,
      planNames,
    };
  }

  /**
   * ROUND 13 (Phase 4): the plan-mapping step needs the distinct plan names
   * for the mapping the owner CONFIRMED in step 2 — which is only known after
   * they edited the AI proposal, so this re-reads the uploaded file with the
   * final mapping instead of trusting the preview-time AI guess.
   */
  async planNames(filePath: string, mapping: ColumnMapping) {
    const { rows } = await this.parseFile(filePath);
    return { planNames: this.collectPlanNames(rows, mapping) };
  }

  /** Every distinct non-empty value of the column mapped to `planName`. */
  private collectPlanNames(
    rows: ParsedRow[],
    mapping: ColumnMapping,
  ): { name: string; rows: number }[] {
    const planCol = Object.entries(mapping).find(([, f]) => f === 'planName')?.[0];
    const planNames: { name: string; rows: number }[] = [];
    if (!planCol) return planNames;
    const counts = new Map<string, number>();
    for (const row of rows) {
      const v = row[planCol];
      if (v === undefined || v === null) continue;
      const name = String(v).trim();
      if (!name) continue;
      counts.set(name, (counts.get(name) || 0) + 1);
    }
    for (const [name, n] of counts) planNames.push({ name, rows: n });
    return planNames;
  }

  // ── STEP 2: Import with confirmed mapping ──────────────────────────────────
  async confirm(
    filePath: string,
    gymId: string,
    mapping: ColumnMapping,
    options: {
      skipDuplicates?: boolean;
      updateExisting?: boolean;
      defaultPlanId?: string;
      defaultBranchId?: string;
      // ROUND 13 (Phase 4): per-file-plan-name decisions from the mapping step.
      planMapping?: PlanMapping;
      // ROUND 14 (security review, PHASE K3): see ImportActivation. Anything
      // other than 'paid' can only ever produce members that CANNOT train
      // (pending payment or expired), so it needs no extra permission.
      activation?: ImportActivation;
      allowOpenEnded?: boolean;
    },
    // ROUND 13 (security review, PHASE B): the acting user — required to
    // enforce that plan CREATION during import needs plans.manage.
    actor?: { id: string; role: string; gymId: string | null },
  ) {
    const { rows } = await this.parseFile(filePath);
    if (options.defaultPlanId) {
      const plan = await this.prisma.plan.findFirst({ where: { id: options.defaultPlanId, gymId } });
      if (!plan) throw new BadRequestException('Default plan does not belong to this gym');
    }
    if (options.defaultBranchId) {
      const branch = await this.prisma.branch.findFirst({ where: { id: options.defaultBranchId, gymId } });
      if (!branch) throw new BadRequestException('Default branch does not belong to this gym');
    }

    const totalRows = rows.length;
    let imported = 0, updated = 0, skipped = 0, failed = 0;
    const errors: ImportRowError[] = [];

    // Capacity pre-check (import used to bypass the member limit entirely,
    // and single-member creation blocked at the limit with an unexplained
    // error — CSV import was reported the same way). Member capacity is
    // governed by the subscription tier (same table as members.service.ts),
    // never by License.seats. We count the rows that would CREATE a new
    // member (mobile not already in the gym) and reject the whole import
    // with a structured, translatable, numbered error when the limit would
    // be exceeded.
    //
    // BUG FIX (P0 partial-import round): this used to compare the RAW file
    // mobile against the gym's stored mobiles — which are ENCRYPTED
    // (deterministic) — so the comparison never matched and re-imports were
    // miscounted. Normalize + encrypt exactly like importRowFast does, and
    // dedupe mobiles inside the file so duplicates count once.
    const memberCount = await this.prisma.member.count({ where: { gymId } });
    const existing = await this.prisma.member.findMany({ where: { gymId }, select: { mobile: true } });
    const existingMobiles = new Set(existing.map((m) => m.mobile));
    const countedNewMobiles = new Set<string>();
    let newRows = 0;
    for (const row of rows) {
      const mapped = this.applyMapping(row, mapping);
      const rawMobile = normalizeMobile(mapped.mobile);
      if (!rawMobile) continue;
      const encMobile = this.encryption.encryptDeterministic(rawMobile);
      if (existingMobiles.has(encMobile)) continue;   // already a member — update/skip, not new
      if (countedNewMobiles.has(encMobile)) continue; // repeated inside the file — counts once
      countedNewMobiles.add(encMobile);
      newRows += 1;
    }
    if (newRows > 0) {
      const sub = await this.prisma.subscription.findUnique({ where: { gymId } }).catch(() => null);
      const tier = sub?.tier || 'BASIC';
      const planLimit = ({ BASIC: 50, PRO: 500, ELITE: Number.POSITIVE_INFINITY } as Record<string, number>)[tier] ?? 50;
      if (memberCount + newRows > planLimit) {
        throw new BadRequestException({
          code: 'MEMBER_LIMIT_REACHED',
          translationKey: 'error_member_limit',
          message: `Member limit reached: this gym already has ${memberCount} members (limit ${planLimit} for the ${tier} plan) and this import would add ${newRows} new ones. Upgrade the plan or remove members before importing.`,
          current: memberCount,
          limit: planLimit,
          tier,
        });
      }
    }

    // Pre-fetch data for faster processing
    const plans = await this.prisma.plan.findMany({ where: { gymId } });
    const branches = await this.prisma.branch.findMany({ where: { gymId } });

    // ROUND 13 (Phase 4): validate + normalize the owner's plan-mapping
    // decisions. `existing` entries must reference this gym's own plans.
    const resolvedPlans = new Map<string, PlanMappingEntry>();
    for (const [rawName, entry] of Object.entries(options.planMapping || {})) {
      const key = normalizePlanKey(rawName);
      if (!key || !entry || typeof entry !== 'object') continue;
      if (entry.action === 'existing') {
        if (!plans.some((p) => p.id === entry.planId)) {
          throw new BadRequestException(`Plan mapping references a plan that does not belong to this gym: ${entry.planId}`);
        }
        resolvedPlans.set(key, { action: 'existing', planId: entry.planId });
      } else if (entry.action === 'create') {
        const name = String(entry.name || rawName).trim();
        const price = Number(entry.price);
        const days = Number(entry.days);
        if (!name || !Number.isFinite(price) || price < 0 || !Number.isFinite(days) || days < 0) {
          throw new BadRequestException(`Invalid "create plan" mapping for "${rawName}" (need a name, price >= 0 and days >= 0)`);
        }
        resolvedPlans.set(key, {
          action: 'create',
          name,
          price,
          days,
          type: entry.type === 'SESSION' ? 'SESSION' : 'TIME',
          sessions: entry.type === 'SESSION' ? Math.max(0, Number(entry.sessions || 0)) : undefined,
        });
      } else if (entry.action === 'skip') {
        resolvedPlans.set(key, { action: 'skip' });
      }
    }
    // ROUND 13 (security review, PHASE B) + ROUND 14 (security review, PHASE
    // F3 — FAIL CLOSED): the import endpoint is gated by members.create, but a
    // planMapping action 'create' CREATES PLANS — that is a plans.manage
    // operation. A Reception user must not be able to mint arbitrary plans
    // (price 0) and import members onto them. 'existing' and 'skip' stay
    // available to members.create.
    //
    // The gate runs whenever a 'create' action is present — and REJECTS when
    // there is no actor or the actor's permissions cannot be resolved. The
    // old `if (actor && …)` shape let a missing actor skip the check entirely.
    const hasCreateAction = [...resolvedPlans.values()].some((e) => e.action === 'create');
    if (hasCreateAction) {
      let canManagePlans = false;
      if (actor && actor.id && actor.role) {
        if (this.permissions) {
          try {
            canManagePlans = await this.permissions.hasAll(actor, ['plans.manage']);
          } catch {
            canManagePlans = false; // permissions unresolvable → fail closed
          }
        } else {
          // PermissionsService unavailable: only the OWNER — who holds every
          // permission by definition — may still create plans.
          canManagePlans = actor.role === 'OWNER';
        }
      }
      if (!canManagePlans) {
        throw new ForbiddenException({
          code: 'PLANS_MANAGE_REQUIRED',
          message: "Creating plans during a members import requires the plans.manage permission. Map the file plan names to existing plans, or skip them.",
        });
      }
    }
    // ROUND 14 (security review, PHASE K3) — importing members as ALREADY-PAID
    // (ACTIVE) memberships is a privileged operation. A file with no expiry
    // column is the cheapest way to hand out free lifetime memberships, so a
    // members.create user (Reception) may only import rows that cannot train
    // yet — pending payment or expired. 'members.import' is OWNER by default
    // and grantable, and the gate FAILS CLOSED: no actor or unresolvable
    // permissions means no active import.
    const activation: ImportActivation = options.activation || 'pending';
    if (activation === 'paid') {
      let allowed = false;
      if (actor && actor.id && actor.role) {
        if (this.permissions) {
          try {
            allowed = await this.permissions.hasAll(actor, ['members.import']);
          } catch {
            allowed = false; // permissions unresolvable → fail closed
          }
        } else {
          // PermissionsService unavailable: only the OWNER — who holds every
          // permission by definition — may import live memberships.
          allowed = actor.role === 'OWNER';
        }
      }
      if (!allowed) {
        throw new ForbiddenException({
          code: 'MEMBERS_IMPORT_REQUIRED',
          message: 'Importing members as already-paid (active) requires the members.import permission. Import them as pending payment (collect at the desk) or as expired records instead.',
        });
      }
    }

    const createdPlans: { id: string; name: string; price: number; days: number; type: string }[] = [];
    const createdPlanCache = new Map<string, any>();
    const planCtx = { resolved: resolvedPlans, created: createdPlans, cache: createdPlanCache };
    
    // Fetch all existing mobiles to check duplicates in memory (faster than 10k queries)
    const existingMembers = await this.prisma.member.findMany({
      where: { gymId },
      select: { id: true, mobile: true }
    });
    const mobileToIdMap = new Map(existingMembers.map(m => [m.mobile, m.id]));

    // BUG FIX (P0 partial-import round): rows whose mobile already appeared
    // EARLIER in the same file are processed in a second, SEQUENTIAL pass.
    // Previously every row ran in parallel batches and two rows sharing a
    // mobile both called member.create — the loser surfaced a raw Prisma
    // unique-constraint error even with skipDuplicates enabled.
    const firstOccurrence = new Map<string, number>(); // encMobile -> row index
    const firstPass: Array<{ row: ParsedRow; rowIdx: number }> = [];
    const secondPass: Array<{ row: ParsedRow; rowIdx: number }> = [];
    rows.forEach((row, rowIdx) => {
      const mapped = this.applyMapping(row, mapping);
      const rawMobile = normalizeMobile(mapped.mobile);
      const encMobile = rawMobile ? this.encryption.encryptDeterministic(rawMobile) : null;
      if (encMobile && firstOccurrence.has(encMobile)) {
        secondPass.push({ row, rowIdx });
      } else {
        if (encMobile) firstOccurrence.set(encMobile, rowIdx);
        firstPass.push({ row, rowIdx });
      }
    });

    const tally = (res: { success: boolean; result?: string; row?: number; reason?: string; code?: ImportErrorCode }) => {
      if (res.success) {
        if (res.result === 'created') imported++;
        else if (res.result === 'updated') updated++;
        else skipped++;
      } else {
        failed++;
        errors.push({ row: res.row!, reason: res.reason!, code: res.code! });
      }
    };

    const processItem = async ({ row, rowIdx }: { row: ParsedRow; rowIdx: number }) => {
      try {
        const mapped = this.applyMapping(row, mapping);
        const result = await this.importRowFast(mapped, gymId, options, plans, branches, mobileToIdMap, planCtx);
        return { success: true as const, result };
      } catch (e) {
        return { success: false as const, row: rowIdx + 2, reason: this.sanitizeRowError(e), code: this.classifyRowError(e) };
      }
    };

    const batchSize = 25; // Smaller batch to avoid pool exhaustion
    for (let i = 0; i < firstPass.length; i += batchSize) {
      const results = await Promise.all(firstPass.slice(i, i + batchSize).map(processItem));
      results.forEach(tally);
    }
    // Sequential: these rows update/extend members created in the first pass.
    for (const item of secondPass) {
      tally(await processItem(item));
    }

    // Clean up temp file
    try { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch { /* ignore */ }

    // PHASE 9 — an import used to leave the 60s Redis member-list cache (and the
    // dashboard cache) untouched, so right after a successful import the list
    // still showed the OLD rows: "it said 12 imported but I see nothing new".
    // Drop both, exactly like member create/update/delete already do.
    if (imported + updated > 0) {
      await bustMemberListCaches(this.redis, gymId);
    }

    // PHASE 9 — the summary the results screen leads with: "already a member"
    // (duplicate prevention working as intended) is kept separate from
    // "nothing matched" (a real configuration problem).
    const duplicateFailed = errors.filter((e) => e.code === 'DUPLICATE').length;
    const summary = {
      // "already a member" = rows skipped by the duplicate guard PLUS rows that
      // failed on it. Same cause — prevention working — whichever skip/update
      // options the user chose.
      alreadyMember: skipped + duplicateFailed,
      duplicateSkipped: skipped,
      duplicateFailed,
      noPlanMatch: errors.filter((e) => e.code === 'NO_PLAN_MATCH').length,
      noBranchMatch: errors.filter((e) => e.code === 'NO_BRANCH_MATCH').length,
      validation: errors.filter((e) => e.code === 'VALIDATION').length,
      // ROUND 14 (security review, PHASE K3): "these rows would have created
      // members who can train without paying" — called out on its own so the
      // fix is one click (add the date, or import as pending/expired).
      missingExpiry: errors.filter((e) => e.code === 'MISSING_EXPIRY').length,
      missingSessions: errors.filter((e) => e.code === 'MISSING_SESSIONS').length,
      other: errors.filter((e) => e.code === 'OTHER').length,
      totalRows,
      wouldCreateNew: newRows,
    };

    return { imported, updated, skipped, failed, errors, summary, createdPlans };
  }

  private async importRowFast(
    mapped: Record<string, unknown>,
    gymId: string,
    options: {
      skipDuplicates?: boolean;
      updateExisting?: boolean;
      defaultPlanId?: string;
      defaultBranchId?: string;
      // ROUND 14 (security review, PHASE K3):
      //   'paid'    — rows become ACTIVE memberships (needs members.import)
      //   'pending' — rows become PENDING_PAYMENT registrations (default for
      //               members.create; they cannot train until payment + activation)
      //   'expired' — rows become EXPIRED records (archives / historical data)
      activation?: ImportActivation;
      // With 'paid': a TIME row with no expiry (or a SESSION row with no
      // session count) is normally REJECTED. The owner may explicitly choose to
      // import those rows as EXPIRED instead of losing them.
      allowOpenEnded?: boolean;
    },
    plans: any[],
    branches: any[],
    mobileMap: Map<string, string>,
    // ROUND 13 (Phase 4): the owner's per-plan-name decisions.
    planCtx?: {
      resolved: Map<string, PlanMappingEntry>;
      created: { id: string; name: string; price: number; days: number; type: string }[];
      cache: Map<string, any>;
    },
  ): Promise<'created' | 'updated' | 'skipped'> {
    const name = String(mapped.name || '').trim();
    if (!name) throw new ImportRowFailure('Name is required', 'VALIDATION');

    const rawMobile = normalizeMobile(mapped.mobile);
    const encMobile = rawMobile ? this.encryption.encryptDeterministic(rawMobile) : null;

    if (encMobile && mobileMap.has(encMobile)) {
      const existingId = mobileMap.get(encMobile)!;
      if (options.updateExisting) {
        await this.prisma.member.update({
          where: { id: existingId },
          data: this.buildMemberData(mapped, gymId, options, encMobile),
        });
        return 'updated';
      }
      if (options.skipDuplicates) return 'skipped';
      // Without either flag this create would hit the (gymId, mobile) unique
      // constraint — surface a clean row reason instead of a Prisma error.
      throw new ImportRowFailure('Duplicate member: this mobile number already exists', 'DUPLICATE');
    }

    // BUG FIX (P0 partial-import round): plan matching used to be
    // one-directional (plan name had to CONTAIN the cell) and ANY non-empty
    // cell that failed that test threw an error even when the user had
    // selected a default plan — that alone dropped ~half of a real file.
    // Now: bidirectional fuzzy match first, chosen default plan as fallback,
    // and a specific, actionable reason only when neither is available.
    const cellPlan = mapped.planName ? String(mapped.planName).trim() : '';
    let planId: string | undefined;
    let matchedPlan: any = null;
    // ROUND 13 (Phase 4): an explicit plan-mapping decision WINS over the
    // fuzzy match — the owner already decided what this file name means.
    if (cellPlan && planCtx) {
      const entry = planCtx.resolved.get(normalizePlanKey(cellPlan));
      if (entry) {
        if (entry.action === 'skip') {
          throw new ImportRowFailure(
            `Plan "${cellPlan}" was skipped in the plan-mapping step`,
            'NO_PLAN_MATCH',
          );
        }
        if (entry.action === 'existing') {
          planId = entry.planId;
          matchedPlan = plans.find((p) => p.id === planId) || null;
        } else {
          const created = await this.resolveCreatedPlan(entry as Extract<PlanMappingEntry, { action: 'create' }>, gymId, plans, planCtx);
          planId = created.id;
          matchedPlan = created;
        }
      }
    }
    if (!planId && cellPlan) {
      const low = cellPlan.toLowerCase();
      matchedPlan = plans.find(
        (p) => p.name.toLowerCase().includes(low) || low.includes(p.name.toLowerCase()),
      ) || null;
      if (matchedPlan) planId = matchedPlan.id;
    }
    if (!planId) {
      planId = options.defaultPlanId;
      if (planId && !matchedPlan) matchedPlan = plans.find((p) => p.id === planId) || null;
    }

    let branchId = options.defaultBranchId;
    if (mapped.branch && String(mapped.branch).trim()) {
      const cellBranch = String(mapped.branch).trim().toLowerCase();
      const b = branches.find(
        (br) => br.name.toLowerCase().includes(cellBranch) || cellBranch.includes(br.name.toLowerCase()),
      );
      if (b) branchId = b.id;
    }

    if (!planId) throw new ImportRowFailure(
      cellPlan
        ? `No plan matched "${cellPlan}" and no default plan was selected`
        : 'Row has no plan and no default plan was selected',
      'NO_PLAN_MATCH',
    );
    if (!branchId) throw new ImportRowFailure(
      mapped.branch && String(mapped.branch).trim()
        ? `No branch matched "${String(mapped.branch).trim()}" and no default branch was selected`
        : 'Row has no branch and no default branch was selected',
      'NO_BRANCH_MATCH',
    );

    const code = `IMP-${Date.now().toString(36)}-${randomBytes(4).toString('hex').toUpperCase()}`;
    const requestedSessions = mapped.sessionsLeft != null && String(mapped.sessionsLeft).trim() !== ''
      ? Number(mapped.sessionsLeft)
      : null;
    const planIsSession = String(matchedPlan?.type || '').toUpperCase() === 'SESSION';
    const planIsTime = !planIsSession;

    /**
     * ROUND 14 (security review, PHASE K3) — an import may never mint a member
     * who can train without proof of a paid period.
     *
     *   paid    : TIME row needs a real expiry date, SESSION row needs a
     *             session count > 0. Missing → the row is REJECTED with a clear
     *             reason (or imported as EXPIRED when the owner opted in).
     *   pending : registered only — no expiry, no sessions, PENDING_PAYMENT.
     *             The desk collects payment and activates it later.
     *   expired : archived record — keeps the dates as data, never trainable.
     */
    const activation: ImportActivation = options.activation || 'pending';
    let expiry: Date | null = null;
    let sessionsLeft = 0;
    let status: 'ACTIVE' | 'PENDING_PAYMENT' | 'EXPIRED' = 'PENDING_PAYMENT';

    if (activation === 'pending') {
      // Nothing to validate: an unpaid registration has no period and no sessions.
      expiry = null;
      sessionsLeft = 0;
      status = 'PENDING_PAYMENT';
    } else if (activation === 'expired') {
      expiry = parseFlexibleDate(mapped.expiryDate) ?? null;
      sessionsLeft = planIsSession ? Math.max(0, requestedSessions ?? 0) : 0;
      status = 'EXPIRED';
    } else {
      // 'paid' — the row must carry proof of a paid period.
      if (planIsTime) {
        expiry = parseFlexibleDate(mapped.expiryDate) ?? null;
        if (!expiry) {
          if (!options.allowOpenEnded) {
            throw new ImportRowFailure(
              'Expiry date is required for a time-based plan — this row would create an open-ended member who can train forever. Add an expiry date, or import the row as pending payment / expired.',
              'MISSING_EXPIRY',
            );
          }
          // Owner's explicit choice: keep the row, but NOT as a live membership.
          status = 'EXPIRED';
        } else {
          status = 'ACTIVE';
        }
      } else {
        // PHASE K3: the row must carry its OWN session count. Falling back to
        // the plan's default sessions (the old behaviour) meant a file with no
        // Sessions column silently minted members with a full block of sessions
        // — the same "members who never paid" hole, one column over.
        const n = requestedSessions;
        if (n == null || !Number.isFinite(n) || n <= 0) {
          if (!options.allowOpenEnded) {
            throw new ImportRowFailure(
              'Session count is required for a session-based plan — this row would create a member with no sessions. Add a sessions number, or import the row as pending payment / expired.',
              'MISSING_SESSIONS',
            );
          }
          status = 'EXPIRED';
          sessionsLeft = 0;
        } else {
          sessionsLeft = Math.trunc(n as number);
          status = 'ACTIVE';
        }
      }
      if (status === 'ACTIVE' && expiry && expiry < new Date()) {
        // A date in the past is a real, closed period — import it as expired
        // rather than as a live membership (the row is not lost, and it cannot
        // be used to train today).
        status = 'EXPIRED';
      }
    }

    const created = await this.prisma.member.create({
      data: {
        gymId, code, name, 
        mobile: encMobile ?? `imported_${Date.now()}_${randomBytes(4).toString('hex')}`,
        email: mapped.email ? String(mapped.email) : undefined,
        dob: parseFlexibleDate(mapped.dob) ?? undefined,
        gender: mapped.gender ? (String(mapped.gender).toUpperCase().includes('FEMALE') ? 'FEMALE' : 'MALE') : 'MALE',
        nationalId: mapped.nationalId ? this.encryption.encryptDeterministic(String(mapped.nationalId)) : undefined,
        planId: planId!,
        branchId: branchId!,
        startDate: parseFlexibleDate(mapped.startDate) || new Date(),
        // PHASE K3: the state decided above — never an open-ended ACTIVE member.
        expiry: expiry ?? null,
        sessionsLeft,
        notes: mapped.notes ? String(mapped.notes) : undefined,
        status,
      }
    });
    if (encMobile) mobileMap.set(encMobile, created.id);
    return 'created';
  }

  /**
   * ROUND 13 (Phase 4): create the plan an owner asked for in the mapping
   * step — ONCE per distinct name (cached), reusing an identical existing plan
   * (the unique key is gymId+name+type+price) instead of erroring on it.
   */
  private async resolveCreatedPlan(
    spec: { name: string; price: number; days: number; type?: 'SESSION' | 'TIME'; sessions?: number },
    gymId: string,
    plans: any[],
    planCtx: { created: { id: string; name: string; price: number; days: number; type: string }[]; cache: Map<string, any> },
  ) {
    const key = normalizePlanKey(spec.name);
    const type: 'SESSION' | 'TIME' = spec.type === 'SESSION' ? 'SESSION' : 'TIME';
    const cached = planCtx.cache.get(key);
    if (cached) return cached;
    const identical = plans.find(
      (p) => normalizePlanKey(p.name) === key && Number(p.price) === spec.price && p.type === type,
    );
    if (identical) {
      planCtx.cache.set(key, identical);
      return identical;
    }
    try {
      const created = await this.prisma.plan.create({
        data: {
          gymId,
          name: spec.name,
          type,
          price: spec.price,
          days: spec.days,
          sessions: type === 'SESSION' ? (spec.sessions ?? 0) : null,
          active: true,
        },
      });
      plans.push(created);
      planCtx.cache.set(key, created);
      planCtx.created.push({ id: created.id, name: created.name, price: Number(created.price), days: created.days ?? spec.days, type: created.type });
      return created;
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError && e.code === 'P2002') {
        // Same name+type+price created concurrently (or between our check and
        // the insert) — reuse it rather than failing the row.
        const found = await this.prisma.plan.findFirst({
          where: { gymId, name: spec.name, type },
        });
        if (found) {
          plans.push(found);
          planCtx.cache.set(key, found);
          return found;
        }
      }
      throw e;
    }
  }

  // ── Private: AI column mapping ──────────────────────────────────────────────
  private async aiMapColumns(
    headers: string[],
    gymId: string,
  ): Promise<ColumnMapping> {
    const prompt = `
You are a data migration assistant for a gym management system called Flexora.
Here are the column headers from an uploaded file:
Headers: ${JSON.stringify(headers)}
Do not infer from or transmit row values; uploaded member data is private.
Map each column header to ONE of these Flexora fields (or null if no match):
${FLEXORA_FIELDS.join(', ')}

Rules:
- "name" or "الاسم" or "nom" → name
- "mobile" or "phone" or "التليفون" or "رقم" → mobile
- "email" or "البريد" → email
- "dob" or "birth" or "تاريخ الميلاد" → dob
- "plan" or "package" or "الاشتراك" or "الباقة" → planName
- "expiry" or "end date" or "انتهاء" → expiryDate
- "start" or "بداية" → startDate
- "sessions" or "جلسات" → sessionsLeft
- "branch" or "فرع" → branch
- "gender" or "الجنس" → gender
- "notes" or "ملاحظات" → notes
- "status" or "الحالة" → status
- "national" or "رقم قومي" or "id" → nationalId

Return ONLY valid JSON, no explanation:
{ "ColumnHeader": "flexora_field_or_null" }
    `.trim();

    try {
      const response = await this.aiBrain.chat(prompt, gymId, 'analyst');
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (!jsonMatch) return this.emptyMapping(headers);

      const parsed = JSON.parse(jsonMatch[0]);

      // Validate each value is a known field or null
      const validated: ColumnMapping = {};
      for (const [col, field] of Object.entries(parsed)) {
        validated[col] = (FLEXORA_FIELDS as readonly string[]).includes(field as string)
          ? field as FlexoraField
          : null;
      }
      return validated;
    } catch {
      return this.emptyMapping(headers);
    }
  }

  // ── Private: Import one row ─────────────────────────────────────────────────
  // ── Private: File parsing ───────────────────────────────────────────────────
  private async parseFile(filePath: string): Promise<{
    headers: string[];
    rows: ParsedRow[];
  }> {
    const ext = filePath.split('.').pop()?.toLowerCase();

    if (ext === 'csv') {
      const content = fs.readFileSync(filePath, 'utf8');
      const result = Papa.parse<ParsedRow>(content, {
        header: true,
        skipEmptyLines: true,
        transformHeader: h => h.trim(),
      });
      return {
        headers: result.meta.fields || [],
        rows: result.data as ParsedRow[],
      };
    }

    // Excel (.xlsx)
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.readFile(filePath);
    const sheet = workbook.worksheets[0];
    if (!sheet) return { headers: [], rows: [] };

    const headers: string[] = [];
    const headerRow = sheet.getRow(1);
    headerRow.eachCell((cell, col) => {
      headers[col - 1] = String(cell.value || '').trim();
    });

    const rows: ParsedRow[] = [];
    sheet.eachRow((row, rowNum) => {
      if (rowNum === 1) return;
      const obj: ParsedRow = {};
      row.eachCell((cell, col) => {
        const header = headers[col - 1];
        if (header) obj[header] = cell.value;
      });
      if (Object.values(obj).some(v => v !== null)) rows.push(obj);
    });

    return { headers, rows };
  }

  /** Turn raw errors (incl. Prisma constraint violations) into short,
   *  user-readable row-level rejection reasons. */
  /** Category of a failed row, used for the results summary (Phase 9). */
  private classifyRowError(e: unknown): ImportErrorCode {
    if (e instanceof ImportRowFailure) return e.code;
    const msg = e instanceof Error ? e.message : String(e);
    if (msg.includes('Unique constraint failed') || msg.includes('already exists')) return 'DUPLICATE';
    if (/no plan matched|no default plan/i.test(msg)) return 'NO_PLAN_MATCH';
    if (/no branch matched|no default branch/i.test(msg)) return 'NO_BRANCH_MATCH';
    if (/is required|invalid|must be/i.test(msg)) return 'VALIDATION';
    return 'OTHER';
  }

  private sanitizeRowError(e: unknown): string {
    const msg = e instanceof Error ? e.message : String(e);
    if (msg.includes('Unique constraint failed')) {
      return 'Duplicate member: this mobile number already exists in your gym';
    }
    if (msg.includes('Foreign key constraint')) {
      return 'Linked record not found (the plan or branch may have been deleted)';
    }
    return msg.split('\n')[0].slice(0, 220);
  }

  private applyMapping(row: ParsedRow, mapping: ColumnMapping): Record<string, unknown> {
    const result: Record<string, unknown> = {};
    for (const [col, field] of Object.entries(mapping)) {
      if (field && row[col] !== undefined) result[field] = row[col];
    }
    return result;
  }

  private emptyMapping(headers: string[]): ColumnMapping {
    return Object.fromEntries(headers.map(h => [h, null]));
  }

  private buildMemberData(
    mapped: Record<string, unknown>,
    _gymId: string,
    _options: { defaultPlanId?: string; defaultBranchId?: string },
    encMobile: string | null,
  ): Parameters<PrismaService['member']['update']>[0]['data'] {
    return {
      name: String(mapped.name || '').trim(),
      mobile: encMobile ?? undefined,
      email: mapped.email ? String(mapped.email) : undefined,
      gender: mapped.gender ? (String(mapped.gender).toUpperCase().includes('FEMALE') ? 'FEMALE' : 'MALE') : undefined,
      dob: parseFlexibleDate(mapped.dob) ?? undefined,
      expiry: parseFlexibleDate(mapped.expiryDate) ?? undefined,
      sessionsLeft: mapped.sessionsLeft ? Number(mapped.sessionsLeft) : undefined,
      notes: mapped.notes ? String(mapped.notes) : undefined,
    };
  }

  private buildWarnings(
    mapping: ColumnMapping,
    headers: string[],
    totalRows: number,
  ): string[] {
    const warnings: string[] = [];
    const unmapped = headers.filter(h => !mapping[h]);
    if (unmapped.length) warnings.push(`${unmapped.length} columns not mapped: ${unmapped.join(', ')}`);
    if (!Object.values(mapping).includes('name')) warnings.push('WARNING: No "name" column mapped — import will fail');
    if (!Object.values(mapping).includes('mobile')) warnings.push('No "mobile" column mapped — duplicate detection disabled');
    if (totalRows > 5000) warnings.push(`Large file: ${totalRows} rows — import may take several minutes`);
    return warnings;
  }
}