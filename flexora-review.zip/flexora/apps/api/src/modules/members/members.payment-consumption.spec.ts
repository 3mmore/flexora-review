/**
 * ROUND 14 (security review, PHASE H1+H2) — a membership payment must be
 * consumed EXACTLY ONCE, and a confirmed paymentId is the ONLY accepted proof
 * of payment.
 *
 * H1: the transactionId path is gone (it was validated only for existence and
 * amount — never consumed, never member-bound). The DTOs no longer declare it
 * and validateMembershipPayment has no such branch.
 *
 * H2: consumption is an EXPLICIT marker (Payment.consumedAt +
 * consumedByInvoiceId), stamped in the same atomic compare-and-set that links
 * the payment to its membership invoice. validateMembershipPayment rejects any
 * payment where the marker is set, regardless of invoice text. The online
 * webhook path stamps the marker too.
 */
import { BadRequestException } from '@nestjs/common';
import * as fs from 'fs';
import * as path from 'path';
import { MembersService } from './members.service';
import { membershipStatus, canTrain } from './membership-status';

const GYM = 'gym-a';
const MEMBER = 'member-1';
const OTHER = 'member-2';
const PLAN = { id: 'plan-1m', gymId: GYM, name: '1 Month', price: 450, days: 30, type: 'TIME', sessions: null, active: true, invitations: 5, maxFreezes: 0, freezeDays: 0 };

function makeService(over: Record<string, any> = {}) {
  const state: Record<string, any> = { payment: over.payment ?? null, invoice: over.invoice ?? null, ...over };
  const prisma: any = {
    payment: {
      findFirst: jest.fn(async ({ where }: any) =>
        state.payment && (!where?.gymId || state.payment.gymId === where.gymId) ? state.payment : null,
      ),
      updateMany: jest.fn(async ({ where, data }: any) => {
        // PHASE I1: the compare-and-set also requires a MANUAL_MEMBERSHIP
        // purpose; a consumed payment (marker set) matches zero rows
        if (
          state.payment && state.payment.id === where.id &&
          state.payment.consumedAt == null && state.payment.purpose === where.purpose
        ) {
          state.payment = { ...state.payment, ...data };
          return { count: 1 };
        }
        return { count: 0 };
      }),
      create: jest.fn(async ({ data }: any) => ({ id: 'pay-new', ...data })),
    },
    invoice: {
      findFirst: jest.fn(async () => state.invoice),
      create: jest.fn(async ({ data }: any) => ({ id: 'inv-new', ...data })),
    },
    member: { findFirst: jest.fn(async () => state.member ?? null), findUnique: jest.fn(async () => ({ name: 'Test Member' })), update: jest.fn(async ({ data }: any) => ({ id: MEMBER, ...data })) },
    plan: { findFirst: jest.fn(async () => PLAN) },
    invitationSlot: { upsert: jest.fn(async () => ({})) },
    receipt: { findFirst: jest.fn(async () => null), create: jest.fn(async ({ data }: any) => ({ id: 'rcpt-1', ...data })), update: jest.fn() },
    transaction: {
      findUnique: jest.fn(async () => null),
      create: jest.fn(async ({ data }: any) => ({ id: 'tx-1', ...data })),
      update: jest.fn(async () => ({})),
    },
    renewalRequest: {
      findFirst: jest.fn(async () => state.request ?? null),
      update: jest.fn(async ({ data }: any) => ({ id: 'req-1', ...data })),
    },
    $transaction: jest.fn(async (fn: any) => fn(prisma)),
  };
  const svc = new MembersService(prisma, {} as any, {} as any, { emitEvent: jest.fn() } as any, {} as any, {} as any);
  return { svc, prisma, state };
}

const paidPayment = (over: Record<string, any> = {}) => ({
  id: 'pay-1', gymId: GYM, amount: 450, status: 'PAID', invoiceId: 'inv-manual', consumedAt: null, consumedByInvoiceId: null,
  purpose: 'MANUAL_MEMBERSHIP', memberId: null, ...over,
});

describe('ROUND 14 PHASE H1 — transactionId is not an accepted proof of payment', () => {
  it('the create/renew DTOs no longer declare transactionId (forbidNonWhitelisted → 400)', () => {
    const dto = fs.readFileSync(path.join(__dirname, 'dto.ts'), 'utf8');
    expect(dto).not.toContain('transactionId');
  });

  it('validateMembershipPayment rejects a missing paymentId (no transactionId fallback)', async () => {
    const { svc } = makeService({ payment: paidPayment() });
    await expect((svc as any).validateMembershipPayment(GYM, 450, undefined, MEMBER))
      .rejects.toMatchObject({ message: 'Membership activation requires a confirmed paymentId' });
  });
});

describe('ROUND 14 PHASE H2 — validateMembershipPayment rejects a consumed payment by the marker', () => {
  it('an unconsumed paid payment covering the price is accepted', async () => {
    const { svc } = makeService({ payment: paidPayment() });
    const res = await (svc as any).validateMembershipPayment(GYM, 450, 'pay-1', MEMBER);
    expect(res.paymentId).toBe('pay-1');
  });

  it('a payment with the marker set → 400, even when the invoice line is NOT membership text', async () => {
    // the marker is authoritative — invoice text no longer decides (H2)
    const { svc } = makeService({
      payment: paidPayment({ invoiceId: 'inv-m', consumedAt: new Date(), consumedByInvoiceId: 'inv-m' }),
      invoice: { id: 'inv-m', gymId: GYM, memberId: MEMBER, lines: [{ description: '1 Month activation' }] },
    });
    await expect((svc as any).validateMembershipPayment(GYM, 450, 'pay-1', MEMBER))
      .rejects.toMatchObject({ message: 'This payment was already used for a membership — it cannot be reused' });
  });

  it('a consumed payment attributed to ANOTHER member → 400', async () => {
    const { svc } = makeService({
      payment: paidPayment({ invoiceId: 'inv-m', consumedAt: new Date(), consumedByInvoiceId: 'inv-m' }),
      invoice: { id: 'inv-m', gymId: GYM, memberId: OTHER, lines: [{ description: '1 Month activation' }] },
    });
    await expect((svc as any).validateMembershipPayment(GYM, 450, 'pay-1', MEMBER))
      .rejects.toMatchObject({ message: 'This payment is already used by another member' });
  });

  it('a payment tied to THIS member\'s own (non-membership) invoice is accepted', async () => {
    const { svc } = makeService({
      payment: paidPayment({ invoiceId: 'inv-sale' }),
      invoice: { id: 'inv-sale', gymId: GYM, memberId: MEMBER, lines: [{ description: 'Manual payment' }] },
    });
    const res = await (svc as any).validateMembershipPayment(GYM, 450, 'pay-1', MEMBER);
    expect(res.paymentId).toBe('pay-1');
  });

  it('a payment that does not cover the plan price → 400', async () => {
    const { svc } = makeService({ payment: paidPayment({ amount: 100 }) });
    await expect((svc as any).validateMembershipPayment(GYM, 450, 'pay-1', MEMBER))
      .rejects.toBeInstanceOf(BadRequestException);
  });

  it('a payment from ANOTHER gym → 400', async () => {
    const { svc } = makeService({ payment: paidPayment({ gymId: 'gym-b' }) });
    await expect((svc as any).validateMembershipPayment(GYM, 450, 'pay-1', MEMBER))
      .rejects.toMatchObject({ message: 'Payment not found for this gym' });
  });
});

describe('ROUND 14 PHASE I1 — only genuine membership payments are accepted as proof', () => {
  it('a POS_SALE payment → 400 (a sale payment cannot renew a membership)', async () => {
    const { svc } = makeService({ payment: paidPayment({ purpose: 'POS_SALE', invoiceId: 'inv-sale' }) });
    await expect((svc as any).validateMembershipPayment(GYM, 450, 'pay-1', MEMBER))
      .rejects.toMatchObject({ message: 'A POS sale payment cannot be used as membership payment — record a manual payment for the member' });
  });

  it('an OTHER payment → 400', async () => {
    const { svc } = makeService({ payment: paidPayment({ purpose: 'OTHER' }) });
    await expect((svc as any).validateMembershipPayment(GYM, 450, 'pay-1', MEMBER))
      .rejects.toMatchObject({ message: 'Only a manual membership payment recorded for this member can be used as membership payment' });
  });

  it('an ONLINE_RENEWAL payment → 400 (the webhook path owns those)', async () => {
    const { svc } = makeService({ payment: paidPayment({ purpose: 'ONLINE_RENEWAL' }) });
    await expect((svc as any).validateMembershipPayment(GYM, 450, 'pay-1', MEMBER))
      .rejects.toMatchObject({ message: 'Only a manual membership payment recorded for this member can be used as membership payment' });
  });

  it('a MANUAL_MEMBERSHIP payment recorded for member A used for member B → 400', async () => {
    const { svc } = makeService({ payment: paidPayment({ memberId: OTHER }) });
    await expect((svc as any).validateMembershipPayment(GYM, 450, 'pay-1', MEMBER))
      .rejects.toMatchObject({ message: 'This payment was recorded for another member' });
  });

  it('a MANUAL_MEMBERSHIP payment recorded for member A used for member A → accepted', async () => {
    const { svc } = makeService({ payment: paidPayment({ memberId: MEMBER }) });
    const res = await (svc as any).validateMembershipPayment(GYM, 450, 'pay-1', MEMBER);
    expect(res.paymentId).toBe('pay-1');
  });

  it('a legacy MANUAL_MEMBERSHIP payment with NULL memberId is accepted (bound atomically at first use)', async () => {
    const { svc } = makeService({ payment: paidPayment({ memberId: null }) });
    const res = await (svc as any).validateMembershipPayment(GYM, 450, 'pay-1', MEMBER);
    expect(res.paymentId).toBe('pay-1');
  });
});

describe('ROUND 14 PHASE H2 — createMembershipFinancials consumes the payment atomically', () => {
  it('a lost consumption race (the guarded compare-and-set matches zero rows) → 400, the payment is NOT consumed', async () => {
    const { svc, prisma, state } = makeService({ payment: paidPayment() });
    // the payment was already consumed by the concurrent renewal → the
    // guarded update matches zero rows
    prisma.payment.updateMany.mockResolvedValueOnce({ count: 0 });
    await expect((svc as any).createMembershipFinancials(GYM, MEMBER, PLAN, 'membership_renewal', 'pay-1'))
      .rejects.toMatchObject({ message: 'This payment was already consumed by another membership and cannot be reused' });
    // the atomic compare-and-set is guarded by `consumedAt: null` + a
    // MANUAL_MEMBERSHIP purpose, stamps the marker, and binds the member…
    expect(prisma.payment.updateMany).toHaveBeenCalledWith(expect.objectContaining({
      where: expect.objectContaining({ id: 'pay-1', consumedAt: null, purpose: 'MANUAL_MEMBERSHIP' }),
      data: expect.objectContaining({ consumedByInvoiceId: 'inv-new', memberId: MEMBER }),
    }));
    // …and the payment was left untouched (inside the caller's $transaction
    // the invoice created just before the throw rolls back with it)
    expect(state.payment.consumedAt).toBeNull();
  });

  it('a fresh payment is consumed exactly once — marker + member binding stamped atomically', async () => {
    const { svc, state } = makeService({ payment: paidPayment() });
    await (svc as any).createMembershipFinancials(GYM, MEMBER, PLAN, 'membership_renewal', 'pay-1');
    expect(state.payment.invoiceId).toBe('inv-new'); // re-pointed
    expect(state.payment.consumedAt).toBeInstanceOf(Date); // marker stamped
    expect(state.payment.consumedByInvoiceId).toBe('inv-new');
    expect(state.payment.memberId).toBe(MEMBER); // bound to the member
  });
});

describe('ROUND 14 PHASE H2 — the online webhook path stamps the marker too', () => {
  it('applyPaidRenewal creates its payment with consumedAt + consumedByInvoiceId set', async () => {
    const created: any[] = [];
    const prisma: any = {
      plan: { findFirst: jest.fn().mockResolvedValue(PLAN) },
      member: { findFirst: jest.fn().mockResolvedValue({ id: MEMBER, gymId: GYM, expiry: null, sessionsLeft: null }), update: jest.fn(async ({ data }: any) => ({ id: MEMBER, ...data })) },
      invoice: { create: jest.fn(async ({ data }: any) => ({ id: 'inv-online', ...data })) },
      payment: { create: jest.fn(async ({ data }: any) => { created.push(data); return { id: 'pay-online', ...data }; }) },
      receipt: { create: jest.fn(async () => ({})) },
      transaction: { create: jest.fn(async () => ({})) },
      $transaction: jest.fn(async (fn: any) => fn(prisma)),
    };
    const svc = new MembersService(prisma, {} as any, {} as any, {} as any, {} as any);
    await svc.applyPaidRenewal(GYM, MEMBER, PLAN.id, { amount: 450, providerRef: 'tx-1' });
    expect(created[0].consumedAt).toBeInstanceOf(Date);
    expect(created[0].consumedByInvoiceId).toBe('inv-online');
    expect(created[0].purpose).toBe('ONLINE_RENEWAL');
    expect(created[0].memberId).toBe(MEMBER);
  });

  it('applyPaidRenewal rejects a paid amount that does not match the plan price', async () => {
    const prisma: any = {
      plan: { findFirst: jest.fn().mockResolvedValue(PLAN) },
      member: { findFirst: jest.fn().mockResolvedValue({ id: MEMBER, gymId: GYM, expiry: null, sessionsLeft: null }) },
    };
    const svc = new MembersService(prisma, {} as any, {} as any, {} as any, {} as any);
    await expect(svc.applyPaidRenewal(GYM, MEMBER, PLAN.id, { amount: 100 })).rejects.toBeInstanceOf(BadRequestException);
  });
});

describe('ROUND 14 PHASE G2 — confirmRenewalRequest renews onto the REQUESTED plan', () => {
  it('passes request.planId into the renewal flow', async () => {
    const request = {
      id: 'req-1', gymId: GYM, memberId: MEMBER, planId: 'plan-3m', status: 'PENDING', amount: 1100,
      member: { id: MEMBER, gymId: GYM }, plan: { id: 'plan-3m', gymId: GYM, name: '3 Months', price: 1100, days: 90, type: 'TIME' },
    };
    const { svc } = makeService({
      request,
      member: { id: MEMBER, gymId: GYM, planId: 'plan-1m', plan: PLAN, expiry: null, sessionsLeft: null, frozen: false },
    });
    const renewSpy = jest.spyOn(svc as any, 'renew').mockResolvedValue({ id: MEMBER });
    await svc.confirmRenewalRequest(GYM, 'req-1', { paymentId: 'pay-1' }, { id: 'u1', name: 'Staff' });
    expect(renewSpy).toHaveBeenCalledWith(GYM, MEMBER, expect.objectContaining({ paymentId: 'pay-1', planId: 'plan-3m' }), expect.anything());
  });
});

describe('ROUND 14 PHASE J2 — a member is registered, then activated by a payment bound to it', () => {
  it('CreateMemberDto no longer accepts paymentId (an unbound payment can never activate a member)', () => {
    const src = fs.readFileSync(path.join(__dirname, 'dto.ts'), 'utf8');
    // scope the check to CreateMemberDto — RenewMemberDto still takes a paymentId
    const body = src
      .slice(src.indexOf('class CreateMemberDto'), src.indexOf('class RenewMemberDto'))
      .replace(/\/\*[\s\S]*?\*\//g, '')   // block comments
      .replace(/\/\/.*$/gm, '');          // line comments
    expect(body).not.toContain('paymentId');
  });

  it('member creation books NO membership financials — the member is registered as PENDING_PAYMENT', () => {
    const src = fs.readFileSync(path.join(__dirname, 'members.service.ts'), 'utf8');
    const body = src.slice(src.indexOf('async create('), src.indexOf('async update('));
    // the create-time activation path is gone: no validate + no financials
    expect(body).not.toContain('validateMembershipPayment');
    expect(body).not.toContain("createMembershipFinancials(gymId, created.id, plan, 'membership_create'");
    // and the row is written unpaid
    expect(body).toContain('status: MemberStatus.PENDING_PAYMENT');
    expect(body).toContain('activatedAt: null');
    expect(body).toContain('expiry: null');
  });

  const pendingMember = {
    id: MEMBER, gymId: GYM, name: 'Test Member', planId: PLAN.id, plan: PLAN,
    status: 'PENDING_PAYMENT', activatedAt: null, expiry: null, sessionsLeft: 0,
    frozen: false, branchId: null,
  };

  it('the FIRST paid activation of a registered member books a membership_create financial and activates it', async () => {
    const { svc, prisma, state } = makeService({
      payment: paidPayment({ memberId: MEMBER }), // J2: the payment is bound to THIS member
      member: { ...pendingMember },
    });

    const out = await svc.renew(GYM, MEMBER, { paymentId: 'pay-1' }, { id: 'u1', name: 'Staff' });

    // an ACTIVATION, not a renewal
    expect(prisma.transaction.create).toHaveBeenCalledWith(expect.objectContaining({
      data: expect.objectContaining({ category: 'membership_create', paymentId: 'pay-1' }),
    }));
    expect(out.status).toBe('ACTIVE');
    expect(out.expiry).toBeTruthy();
    // the payment stays bound to the member it was recorded for and is consumed
    expect(state.payment.memberId).toBe(MEMBER);
    expect(state.payment.consumedAt).toBeTruthy();
  });

  it('an ALREADY activated member still books a membership_renewal (no regression)', async () => {
    const { svc, prisma } = makeService({
      payment: paidPayment({ memberId: MEMBER }),
      member: { ...pendingMember, status: 'ACTIVE', activatedAt: new Date(), expiry: new Date() },
    });

    await svc.renew(GYM, MEMBER, { paymentId: 'pay-1' }, { id: 'u1', name: 'Staff' });

    expect(prisma.transaction.create).toHaveBeenCalledWith(expect.objectContaining({
      data: expect.objectContaining({ category: 'membership_renewal' }),
    }));
  });

  it('an unpaid (PENDING_PAYMENT) member is never reported as active', () => {
    const { svc } = makeService({});
    expect(svc.computeStatus({ ...pendingMember })).toBe('pending');
    expect(svc.computeStatus({ ...pendingMember, status: 'ACTIVE', activatedAt: new Date(), expiry: new Date(Date.now() + 30 * 86400000) })).toBe('active');
  });

  // ROUND 14 (security review, PHASE K1): attendance no longer carries its own
  // copy of the rule — it calls the shared helper. Asserting on the OLD source
  // text would only prove the text is still there, so this now asserts the
  // behaviour: every gate reads the shared verdict, and that verdict fails
  // closed for a member with no proof of a paid period.
  it('an unpaid member cannot check in (the shared helper refuses any non-ACTIVE member status)', () => {
    const src = fs.readFileSync(path.join(__dirname, '../attendance/attendance.service.ts'), 'utf8');
    expect(src).toMatch(/from '\.\.\/members\/membership-status'/);
    expect(src).toMatch(/canTrain\(/);

    // the helper itself: fail closed on every shape the review found
    expect(membershipStatus({ status: 'PENDING_PAYMENT' })).toBe('pending');
    expect(membershipStatus({ status: 'ACTIVE', plan: { type: 'TIME' }, expiry: null })).toBe('expired');
    expect(membershipStatus({ status: 'ACTIVE', plan: { type: 'TIME' }, expiry: new Date(Date.now() - 86400000) })).toBe('expired');
    expect(membershipStatus({ status: 'ACTIVE', plan: { type: 'SESSION' }, sessionsLeft: 0 })).toBe('expired');
    expect(membershipStatus({ status: 'ACTIVE', plan: { type: 'SESSION' }, sessionsLeft: 5 })).toBe('active');
    expect(membershipStatus({ status: 'ACTIVE', plan: { type: 'TIME' }, expiry: new Date(Date.now() + 30 * 86400000) })).toBe('active');
    expect(membershipStatus(null)).toBe('expired');
    expect(canTrain({ status: 'ACTIVE', plan: { type: 'TIME' }, expiry: null })).toBe(false);
    expect(canTrain({ status: 'ACTIVE', plan: { type: 'TIME' }, expiry: new Date(Date.now() + 30 * 86400000) })).toBe(true);
  });
});
