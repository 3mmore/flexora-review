/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import {
  Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { MembersService } from './members.service';
import { ActivateMemberDto, CreateMemberDto, RegisterAndActivateMemberDto, RenewMemberDto, UpdateMemberDto } from './dto';
import { IsBoolean, IsString } from 'class-validator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { Audit } from '../../common/decorators/audit.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';

class FreezeMemberDto { @IsBoolean() frozen!: boolean; }

// ROUND 14 (security review, PHASE F1): front-desk confirmation of a portal
// renewal request — a confirmed payment id is required.
class ConfirmRenewalDto { @IsString() paymentId!: string; }

@ApiTags('members')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller('members')
export class MembersController {
  constructor(private readonly svc: MembersService) {}

  @Get()
  @Permissions('members.view')
  list(
    @GymId() gymId: string,
    @Query('page') page = 1,
    @Query('limit') limit = 20,
    @Query('q') q?: string,
    @Query('status') status?: string,
    @Query('branchId') branchId?: string,
  ) {
    return this.svc.list(gymId, +page, +limit, q, status, branchId);
  }

  @Get('code/:code')
  @Permissions('members.view')
  byCode(@GymId() gymId: string, @Param('code') code: string) {
    return this.svc.byCode(gymId, code);
  }

  // ROUND 14 (security review, PHASE F1): member renewal REQUESTS — the staff
  // screen behind the portal "Renew" action. Declared before the :id routes so
  // the literal 'renewal-requests' segment is not captured as an id.
  @Get('renewal-requests')
  @Permissions('members.edit')
  renewalRequests(@GymId() gymId: string, @Query('status') status?: string) {
    return this.svc.listRenewalRequests(gymId, status);
  }

  @Post('renewal-requests/:id/confirm')
  @Permissions('members.edit')
  @Audit('confirm_renewal', 'RenewalRequest')
  confirmRenewalRequest(
    @GymId() gymId: string,
    @Param('id') id: string,
    @Body() dto: ConfirmRenewalDto,
    @CurrentUser() user: any,
  ) {
    return this.svc.confirmRenewalRequest(gymId, id, dto, user);
  }

  @Post('renewal-requests/:id/cancel')
  @Permissions('members.edit')
  @Audit('cancel_renewal', 'RenewalRequest')
  cancelRenewalRequest(
    @GymId() gymId: string,
    @Param('id') id: string,
    @CurrentUser() user: any,
  ) {
    return this.svc.cancelRenewalRequest(gymId, id, user);
  }

  // ROUND 14 (security review, PHASE K4): register + pay + activate in ONE
  // call / ONE transaction. Declared before the `:id` routes so the literal
  // segment is never captured as a member id.
  @Post('register-and-activate')
  @Permissions('members.create', 'pos.sell')
  @Audit('member_register_and_activate', 'Member')
  registerAndActivate(
    @GymId() gymId: string,
    @Body() dto: RegisterAndActivateMemberDto,
    @CurrentUser() user: any,
  ) {
    return this.svc.registerAndActivate(gymId, dto, user);
  }

  @Get(':id')
  @Permissions('members.view')
  get(@GymId() gymId: string, @Param('id') id: string) {
    return this.svc.get(gymId, id);
  }

  @Post()
  @Permissions('members.create')
  @Audit('create', 'Member')
  create(@GymId() gymId: string, @Body() dto: CreateMemberDto, @CurrentUser() user: any) {
    return this.svc.create(gymId, dto, user);
  }

  @Patch(':id')
  @Permissions('members.edit')
  @Audit('update', 'Member')
  update(@GymId() gymId: string, @Param('id') id: string, @Body() dto: UpdateMemberDto) {
    return this.svc.update(gymId, id, dto);
  }

  @Post(':id/renew')
  @Permissions('members.edit')
  @Audit('renew', 'Member')
  renew(@GymId() gymId: string, @Param('id') id: string, @Body() dto: RenewMemberDto, @CurrentUser() user: any) {
    return this.svc.renew(gymId, id, dto, user);
  }

  /** ROUND 14 (security review, PHASE K4): take the payment that ACTIVATES an
   *  already-registered member (converted lead, "pay later" registration) in
   *  ONE transaction. Also the "Collect payment" action in the leads UI. */
  @Post(':id/activate')
  @Permissions('members.edit', 'pos.sell')
  @Audit('member_activate_with_payment', 'Member')
  activateWithPayment(
    @GymId() gymId: string,
    @Param('id') id: string,
    @Body() dto: ActivateMemberDto,
    @CurrentUser() user: any,
  ) {
    return this.svc.activateWithPayment(gymId, id, dto, user);
  }

  // ROUND 14 (security review, PHASE E): one-time member access code for the
  // portal fallback login (WhatsApp not configured). members.edit only; the
  // plaintext code is returned exactly once and stored hashed.
  @Post(':id/access-code')
  @Permissions('members.edit')
  @Audit('member_access_code', 'Member')
  accessCode(@GymId() gymId: string, @Param('id') id: string, @CurrentUser() user: any) {
    return this.svc.generateAccessCode(gymId, id, user);
  }

  @Post(':id/freeze')
  @Permissions('members.edit')
  @Audit('freeze', 'Member')
  freeze(@GymId() gymId: string, @Param('id') id: string, @Body() dto: FreezeMemberDto) {
    return this.svc.freeze(gymId, id, dto.frozen);
  }

  @Delete(':id')
  @Permissions('members.delete')
  @Audit('delete', 'Member')
  remove(@GymId() gymId: string, @Param('id') id: string, @CurrentUser() user: any) {
    return this.svc.remove(gymId, id, user);
  }
}
