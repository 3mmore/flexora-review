/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * ROUND 13 (security review, PHASE B) — the members-import confirm endpoint is
 * @Permissions('members.create'), but a planMapping entry with action 'create'
 * creates PLANS — a Reception user could create arbitrary plans (price 0) and
 * import members onto them. MembersImportService.confirm() now requires
 * plans.manage whenever the mapping contains any 'create' action; 'existing'
 * and 'skip' stay available to members.create.
 *
 * These specs pin the gate with a mocked Prisma (no DB needed): the gate fires
 * right after the plan-mapping decisions are resolved, before any row runs.
 */
import { ForbiddenException } from '@nestjs/common';
import * as fs from 'fs';
import * as os from 'os';
import * as path from 'path';
import { MembersImportService } from './members-import.service';

const GYM = 'gym-a';
const PLAN_1M = { id: 'plan-1m', gymId: GYM, name: '1 Month', price: 450, days: 30, type: 'TIME', sessions: null, active: true };
const BRANCH_1 = { id: 'branch-1', gymId: GYM, name: 'Nasr City' };

const CSV = [
  'Name,Mobile,Plan,Branch,Start Date',
  'Spec Probe Member,01012345678,Gold Annual,Nasr City,2026-10-01',
].join('\n');

const MAPPING = {
  Name: 'name',
  Mobile: 'mobile',
  Plan: 'planName',
  Branch: 'branch',
  'Start Date': 'startDate',
} as any;

let tmpFile: string;

beforeEach(() => {
  // confirm() unlinks the uploaded file when it finishes, so every test gets a
  // fresh copy
  tmpFile = path.join(os.tmpdir(), `spec-import-${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2)}.csv`);
  fs.writeFileSync(tmpFile, CSV);
});

afterAll(() => {
  try { fs.unlinkSync(tmpFile); } catch { /* the service unlinks it too */ }
});

function buildPrisma() {
  const prisma: any = {
    member: {
      count: jest.fn().mockResolvedValue(0),
      findMany: jest.fn().mockResolvedValue([]),
      create: jest.fn().mockImplementation(async ({ data }: any) => ({ id: 'member-1', ...data })),
    },
    subscription: { findUnique: jest.fn().mockResolvedValue({ tier: 'ELITE' }) },
    plan: {
      findMany: jest.fn().mockResolvedValue([PLAN_1M]),
      findFirst: jest.fn().mockResolvedValue(PLAN_1M),
      create: jest.fn().mockImplementation(async ({ data }: any) => ({ id: 'plan-new', ...data })),
    },
    branch: { findMany: jest.fn().mockResolvedValue([BRANCH_1]) },
  };
  return prisma;
}

const encryption: any = { encryptDeterministic: (v: string) => `enc:${v}` };
const aiBrain: any = {};

const RECEPTION_ACTOR = { id: 'u-rec', role: 'RECEPTION', gymId: GYM };
const MANAGER_ACTOR = { id: 'u-mgr', role: 'MANAGER', gymId: GYM };
const OWNER_ACTOR = { id: 'u-owner', role: 'OWNER', gymId: GYM };

function buildService(prisma: any, permissions?: { hasAll: jest.Mock }) {
  return new MembersImportService(prisma, encryption, aiBrain, undefined, permissions as any);
}

describe('ROUND 13 PHASE B — import must not bypass plans.manage', () => {
  it('a planMapping with action "create" by a user WITHOUT plans.manage → 403 PLANS_MANAGE_REQUIRED, nothing created', async () => {
    const prisma = buildPrisma();
    const permissions = { hasAll: jest.fn().mockResolvedValue(false) };
    const svc = buildService(prisma, permissions);

    await expect(svc.confirm(tmpFile, GYM, MAPPING, {
      skipDuplicates: true,
      planMapping: { 'Gold Annual': { action: 'create', name: 'Gold Annual', price: 0, days: 30, type: 'TIME' } },
    }, RECEPTION_ACTOR)).rejects.toMatchObject({
      constructor: ForbiddenException,
      response: expect.objectContaining({ code: 'PLANS_MANAGE_REQUIRED' }),
    });

    // the gate fires before any plan/member write
    expect(prisma.plan.create).not.toHaveBeenCalled();
    expect(prisma.member.create).not.toHaveBeenCalled();
    // and it really asked the permission service about plans.manage
    expect(permissions.hasAll).toHaveBeenCalledWith(RECEPTION_ACTOR, ['plans.manage']);
  });

  it('"existing" needs only members.create — no plans.manage check, the import runs', async () => {
    const prisma = buildPrisma();
    const permissions = { hasAll: jest.fn().mockResolvedValue(false) };
    const svc = buildService(prisma, permissions);

    const result = await svc.confirm(tmpFile, GYM, MAPPING, {
      skipDuplicates: true,
      planMapping: { 'Gold Annual': { action: 'existing', planId: PLAN_1M.id } },
    }, RECEPTION_ACTOR);

    expect(result.imported).toBe(1);
    expect(result.failed).toBe(0);
    expect(permissions.hasAll).not.toHaveBeenCalled(); // never asked — no 'create' action
    expect(prisma.member.create).toHaveBeenCalledWith(expect.objectContaining({
      data: expect.objectContaining({ planId: PLAN_1M.id, branchId: BRANCH_1.id }),
    }));
  });

  it('"skip" needs only members.create — the import runs and the row fails with NO_PLAN_MATCH', async () => {
    const prisma = buildPrisma();
    const permissions = { hasAll: jest.fn().mockResolvedValue(false) };
    const svc = buildService(prisma, permissions);

    const result = await svc.confirm(tmpFile, GYM, MAPPING, {
      skipDuplicates: true,
      planMapping: { 'Gold Annual': { action: 'skip' } },
    }, RECEPTION_ACTOR);

    expect(result.imported).toBe(0);
    expect(result.failed).toBe(1);
    expect(result.errors[0].code).toBe('NO_PLAN_MATCH');
    expect(result.summary.noPlanMatch).toBe(1);
    expect(permissions.hasAll).not.toHaveBeenCalled();
    expect(prisma.member.create).not.toHaveBeenCalled();
  });

  it('a user WITH plans.manage may create plans during the import', async () => {
    const prisma = buildPrisma();
    const permissions = { hasAll: jest.fn().mockResolvedValue(true) };
    const svc = buildService(prisma, permissions);

    const result = await svc.confirm(tmpFile, GYM, MAPPING, {
      skipDuplicates: true,
      planMapping: { 'Gold Annual': { action: 'create', name: 'Gold Annual', price: 900, days: 30, type: 'TIME' } },
    }, MANAGER_ACTOR);

    expect(permissions.hasAll).toHaveBeenCalledWith(MANAGER_ACTOR, ['plans.manage']);
    expect(prisma.plan.create).toHaveBeenCalledWith(expect.objectContaining({
      data: expect.objectContaining({ gymId: GYM, name: 'Gold Annual', price: 900, days: 30, type: 'TIME', active: true }),
    }));
    expect(result.createdPlans).toHaveLength(1);
    expect(result.createdPlans[0]).toMatchObject({ name: 'Gold Annual', price: 900 });
    expect(result.imported).toBe(1);
  });

  it('without a PermissionsService the gate falls back to the actor role (OWNER allowed, others 403)', async () => {
    const prisma = buildPrisma();
    const svc = buildService(prisma, undefined);

    // OWNER fallback → allowed
    const ok = await svc.confirm(tmpFile, GYM, MAPPING, {
      skipDuplicates: true,
      planMapping: { 'Gold Annual': { action: 'create', name: 'Gold Annual', price: 900, days: 30, type: 'TIME' } },
    }, OWNER_ACTOR);
    expect(ok.imported).toBe(1);

    // RECEPTION fallback → 403 (fresh file — confirm() unlinks it when done)
    fs.writeFileSync(tmpFile, CSV);
    await expect(svc.confirm(tmpFile, GYM, MAPPING, {
      skipDuplicates: true,
      planMapping: { 'Gold Annual': { action: 'create', name: 'Gold Annual', price: 0, days: 30, type: 'TIME' } },
    }, RECEPTION_ACTOR)).rejects.toMatchObject({
      response: expect.objectContaining({ code: 'PLANS_MANAGE_REQUIRED' }),
    });
  });

  it('ROUND 14 PHASE F3 — FAIL CLOSED: no actor at all → the create action is rejected (403), nothing created', async () => {
    const prisma = buildPrisma();
    const permissions = { hasAll: jest.fn().mockResolvedValue(true) };
    const svc = buildService(prisma, permissions);

    // confirm(..., undefined) — the old `if (actor && …)` shape skipped the
    // check entirely here and let the plan be created
    await expect(svc.confirm(tmpFile, GYM, MAPPING, {
      skipDuplicates: true,
      planMapping: { 'Gold Annual': { action: 'create', name: 'Gold Annual', price: 0, days: 30, type: 'TIME' } },
    }, undefined as any)).rejects.toMatchObject({
      response: expect.objectContaining({ code: 'PLANS_MANAGE_REQUIRED' }),
    });
    expect(permissions.hasAll).not.toHaveBeenCalled(); // never even asked — no actor
    expect(prisma.plan.create).not.toHaveBeenCalled();
    expect(prisma.member.create).not.toHaveBeenCalled();
  });

  it('ROUND 14 PHASE F3 — FAIL CLOSED: permissions that cannot be resolved → the create action is rejected', async () => {
    const prisma = buildPrisma();
    const permissions = { hasAll: jest.fn().mockRejectedValue(new Error('permission store unavailable')) };
    const svc = buildService(prisma, permissions);

    await expect(svc.confirm(tmpFile, GYM, MAPPING, {
      skipDuplicates: true,
      planMapping: { 'Gold Annual': { action: 'create', name: 'Gold Annual', price: 0, days: 30, type: 'TIME' } },
    }, MANAGER_ACTOR)).rejects.toMatchObject({
      response: expect.objectContaining({ code: 'PLANS_MANAGE_REQUIRED' }),
    });
    expect(prisma.plan.create).not.toHaveBeenCalled();
    expect(prisma.member.create).not.toHaveBeenCalled();
  });

  it('an "existing" mapping referencing a foreign gym plan is rejected (tenant isolation)', async () => {
    const prisma = buildPrisma();
    const svc = buildService(prisma, { hasAll: jest.fn().mockResolvedValue(false) });
    await expect(svc.confirm(tmpFile, GYM, MAPPING, {
      skipDuplicates: true,
      planMapping: { 'Gold Annual': { action: 'existing', planId: 'plan-of-another-gym' } },
    }, RECEPTION_ACTOR)).rejects.toMatchObject({ status: 400 });
    expect(prisma.member.create).not.toHaveBeenCalled();
  });
});
