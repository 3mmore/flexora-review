/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { MembersService } from './members.service';

const noop: any = { del: jest.fn(), get: jest.fn(), set: jest.fn() };
const realtime: any = { emitToGym: jest.fn() };

function makeService(prisma: any) {
  return new MembersService(prisma, noop, realtime);
}

const day = 86400000;

describe('MembersService.computeStatus', () => {
  const svc = makeService({});

  it('frozen overrides everything', () => {
    expect(svc.computeStatus({ frozen: true, plan: { type: 'TIME' }, expiry: new Date(Date.now() + day) })).toBe('frozen');
  });
  it('active TIME (expiry in future, >7 days)', () => {
    expect(svc.computeStatus({ frozen: false, plan: { type: 'TIME' }, expiry: new Date(Date.now() + 30 * day) })).toBe('active');
  });
  it('soon TIME (expiry within 7 days)', () => {
    expect(svc.computeStatus({ frozen: false, plan: { type: 'TIME' }, expiry: new Date(Date.now() + 3 * day) })).toBe('soon');
  });
  it('expired TIME (expiry in past)', () => {
    expect(svc.computeStatus({ frozen: false, plan: { type: 'TIME' }, expiry: new Date(Date.now() - day) })).toBe('expired');
  });
  it('active SESSION (sessionsLeft > 0)', () => {
    expect(svc.computeStatus({ frozen: false, plan: { type: 'SESSION' }, sessionsLeft: 4 })).toBe('active');
  });
  it('expired SESSION (sessionsLeft <= 0)', () => {
    expect(svc.computeStatus({ frozen: false, plan: { type: 'SESSION' }, sessionsLeft: 0 })).toBe('expired');
  });
});

describe('MembersService.list status filter (SQL where)', () => {
  it('builds active where with frozen:false + plan OR conditions', async () => {
    const captured: any[] = [];
    const prisma: any = {
      $transaction: (arr: any[]) => Promise.all(arr),
      member: {
        findMany: (args: any) => { captured.push(args.where); return Promise.resolve([]); },
        count: (args: any) => { captured.push(args.where); return Promise.resolve(0); },
      },
    };
    const svc = makeService(prisma);
    await svc.list('gym1', 1, 20, undefined, 'active');
    const where = captured[0];
    // top-level AND with gymId + a status fragment
    const flat = JSON.stringify(where);
    expect(flat).toContain('"gymId":"gym1"');
    expect(flat).toContain('"frozen":false');
    expect(flat).toContain('SESSION');
    expect(flat).toContain('TIME');
  });

  it('frozen status filters frozen:true', async () => {
    const captured: any[] = [];
    const prisma: any = {
      $transaction: (arr: any[]) => Promise.all(arr),
      member: {
        findMany: (args: any) => { captured.push(args.where); return Promise.resolve([]); },
        count: () => Promise.resolve(0),
      },
    };
    const svc = makeService(prisma);
    await svc.list('gym1', 1, 20, undefined, 'frozen');
    expect(JSON.stringify(captured[0])).toContain('"frozen":true');
  });

  it('no status => no frozen/plan fragment, only gymId', async () => {
    const captured: any[] = [];
    const prisma: any = {
      $transaction: (arr: any[]) => Promise.all(arr),
      member: {
        findMany: (args: any) => { captured.push(args.where); return Promise.resolve([]); },
        count: () => Promise.resolve(0),
      },
    };
    const svc = makeService(prisma);
    await svc.list('gym1', 1, 20, undefined, 'all');
    expect(JSON.stringify(captured[0])).not.toContain('frozen');
  });
});
