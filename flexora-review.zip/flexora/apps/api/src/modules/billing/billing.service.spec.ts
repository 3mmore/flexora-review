/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException, NotFoundException } from '@nestjs/common';
import { BillingService } from './billing.service';
import { PrismaService } from '../../config/prisma.service';
import { NotificationsService } from '../notifications/notifications.service';
import { EncryptionService } from '../../common/security/encryption.service';

function build() {
  const prisma: any = {
    $transaction: jest.fn(async (cb, opts) => {
        if (typeof cb === 'function') return cb(prisma);
        return cb;
    }),
    subscription: {
      update: jest.fn().mockResolvedValue({}),
      updateMany: jest.fn().mockResolvedValue({}),
      findFirst: jest.fn().mockResolvedValue({ id: 'sub-local', gymId: 'g1', status: 'ACTIVE' }),
      findMany: jest.fn().mockResolvedValue([]),
      upsert: jest.fn().mockResolvedValue({}),
    },
    sale: { findMany: jest.fn().mockResolvedValue([]), findFirst: jest.fn() },
    invoice: { findFirst: jest.fn(), create: jest.fn(({ data }: any) => Promise.resolve({ id: 'inv1', ...data })) },
    payment: { findMany: jest.fn().mockResolvedValue([]), findFirst: jest.fn(), create: jest.fn(({ data }: any) => Promise.resolve({ id: 'pay1', ...data })) },
    receipt: { findFirst: jest.fn(), create: jest.fn(({ data }: any) => Promise.resolve({ id: 'rcpt1', ...data })) },
    refund: { findMany: jest.fn().mockResolvedValue([]), findFirst: jest.fn() },
    refundAudit: { create: jest.fn().mockResolvedValue({}) },
    financialReconciliation: { upsert: jest.fn().mockResolvedValue({}), findUnique: jest.fn().mockResolvedValue(null), findMany: jest.fn().mockResolvedValue([]) },
    paymentProviderEvent: { findUnique: jest.fn().mockResolvedValue(null), findMany: jest.fn().mockResolvedValue([]), create: jest.fn().mockResolvedValue({}) },
    paymentAttempt: { create: jest.fn().mockResolvedValue({}) },
    billingRecoveryTask: { create: jest.fn().mockResolvedValue({}), findFirst: jest.fn().mockResolvedValue(null), findMany: jest.fn().mockResolvedValue([]), update: jest.fn().mockResolvedValue({}) },
    gym: { update: jest.fn().mockResolvedValue({}), findUnique: jest.fn() },
  };
  const notifications = { whatsapp: jest.fn() } as any as NotificationsService;
  const encryption = { decrypt: jest.fn((v: string) => v), isEncrypted: jest.fn(() => false) } as any as EncryptionService;
  const cronLeadership = { acquireLock: jest.fn().mockResolvedValue(true), releaseLock: jest.fn().mockResolvedValue(true) } as any;
  const svc = new BillingService(prisma as any, notifications, cronLeadership, encryption);
  return { svc, prisma: prisma as any, notifications };
}

describe('BillingService.createCheckout', () => {
  const oldEnv = process.env.NODE_ENV;
  afterEach(() => { process.env.NODE_ENV = oldEnv; });

  it('fails closed in production when Stripe is not configured', async () => {
    process.env.NODE_ENV = 'production';
    delete process.env.STRIPE_SECRET_KEY;
    const { svc } = build();
    // accessing private property for testing
    (svc as any as { stripe: null }).stripe = null;
    await expect(svc.createCheckout('g1', 'PRO')).rejects.toBeInstanceOf(BadRequestException);
  });
});

describe('BillingService.handleWebhook', () => {
  beforeEach(() => { process.env.STRIPE_WEBHOOK_SECRET = 'whsec_test'; });

  it('throws on invalid signature', async () => {
    const { svc } = build();
    // inject a stripe stub whose constructEvent throws (bad signature)
    // accessing private property for testing
    (svc as any as { stripe: any }).stripe = {
      webhooks: { constructEvent: () => { throw new Error('No signatures found'); } },
    };
    await expect(svc.handleWebhook('badsig', Buffer.from('{}')))
      .rejects.toBeInstanceOf(BadRequestException);
  });

  it('checkout.session.completed activates subscription with real period end', async () => {
    const { svc, prisma } = build();
    const periodEndUnix = Math.floor(Date.now() / 1000) + 30 * 86400;
    // accessing private property for testing
    (svc as any as { stripe: any }).stripe = {
      webhooks: {
        constructEvent: () => ({
          id: 'evt_checkout_completed',
          type: 'checkout.session.completed',
          data: { object: { metadata: { gymId: 'g1', tier: 'PRO' }, customer: 'cus_1', subscription: 'sub_1' } },
        }),
      },
      subscriptions: { retrieve: jest.fn().mockResolvedValue({ current_period_end: periodEndUnix }) },
    };
    const res = await svc.handleWebhook('sig', Buffer.from('{}'));
    expect(res).toEqual({ received: true });
    expect(prisma.subscription.upsert).toHaveBeenCalledTimes(1);
    const arg = prisma.subscription.upsert.mock.calls[0][0];
    expect(arg.where).toEqual({ gymId: 'g1' });
    expect(arg.update.tier).toBe('PRO');
    expect(arg.update.status).toBe('ACTIVE');
    expect(arg.update.currentPeriodEnd.getTime()).toBe(periodEndUnix * 1000);
    expect(prisma.gym.update).toHaveBeenCalledWith({ where: { id: 'g1' }, data: { status: 'ACTIVE' } });
  });

  it('customer.subscription.deleted marks CANCELED', async () => {
    const { svc, prisma } = build();
    // accessing private property for testing
    (svc as any as { stripe: any }).stripe = {
      webhooks: {
        constructEvent: () => ({
          id: 'evt_subscription_deleted',
          type: 'customer.subscription.deleted',
          data: { object: { id: 'sub_1' } },
        }),
      },
    };
    await svc.handleWebhook('sig', Buffer.from('{}'));
    expect(prisma.subscription.updateMany).toHaveBeenCalled();
    const call = prisma.subscription.updateMany.mock.calls.find((c: any) => c[0].where.stripeSubscriptionId === 'sub_1');
    expect(call[0].data).toEqual(expect.objectContaining({ status: 'CANCELED', tier: 'BASIC' }));
  });
});

describe('BillingService financial reconciliation', () => {
  it('marks cash sale as reconciled and card sale without reference as missing provider', async () => {
    const { svc, prisma } = build();
    const saleRows = [
      { id: 'cash-sale', invoiceNo: 'INV-CASH', subtotal: 100, total: 100, paymentMethod: 'CASH', memberId: null, userName: 'staff', items: [{ id: 'si1', name: 'Water', qty: 1, price: 100 }] },
      { id: 'card-sale', invoiceNo: 'INV-CARD', subtotal: 200, total: 200, paymentMethod: 'CARD', paymentReference: null, memberId: null, userName: 'staff', items: [{ id: 'si2', name: 'Protein', qty: 1, price: 200 }] },
    ];
    prisma.sale.findMany.mockResolvedValue(saleRows);
    prisma.sale.findFirst.mockImplementation(({ where }: any) => Promise.resolve(saleRows.find((s) => s.id === where.id)));
    const result = await svc.reconcileGym('g1');
    expect(result.reconciled).toBe(2);
    
    const upsertCalls = prisma.financialReconciliation.upsert.mock.calls.map((c: any) => c[0]);
    expect(upsertCalls).toContainEqual(expect.objectContaining({ create: expect.objectContaining({ sourceType: 'SALE', sourceId: 'cash-sale', status: 'RECONCILED' }) }));
    expect(upsertCalls).toContainEqual(expect.objectContaining({ create: expect.objectContaining({ sourceType: 'SALE', sourceId: 'card-sale', status: 'MISSING_PROVIDER' }) }));
  });

  it('creates payment attempt and recovery task for past-due subscriptions', async () => {
    const { svc, prisma } = build();
    // accessing private property for testing
    (svc as any as { stripe: any }).stripe = {
      webhooks: { constructEvent: () => ({ id: 'evt_past_due', type: 'customer.subscription.updated', data: { object: { id: 'sub_1', status: 'past_due', current_period_end: Math.floor(Date.now()/1000), currency: 'usd' } } }) },
    };
    await svc.handleWebhook('sig', Buffer.from('{}'));
    expect(prisma.paymentAttempt.create).toHaveBeenCalled();
    expect(prisma.billingRecoveryTask.create).toHaveBeenCalled();
  });

  it('deduplicates provider webhook events by provider event id', async () => {
    const { svc, prisma } = build();
    prisma.paymentProviderEvent.findUnique.mockResolvedValue({ id: 'already' });
    // accessing private property for testing
    (svc as any as { stripe: any }).stripe = {
      webhooks: { constructEvent: () => ({ id: 'evt_dup', type: 'customer.subscription.deleted', data: { object: { id: 'sub_1' } } }) },
    };
    await expect(svc.handleWebhook('sig', Buffer.from('{}'))).resolves.toEqual({ received: true, duplicate: true });
  });

  it('syncs cash refunds as internally reconciled', async () => {
    const { svc, prisma } = build();
    prisma.refund.findFirst.mockResolvedValue({ id: 'r1', saleId: 's1', amount: 25 });
    prisma.sale.findFirst.mockResolvedValue({ id: 's1', paymentMethod: 'CASH' });
    await svc.syncRefund('g1', 'r1');
    const upsertCalls = prisma.financialReconciliation.upsert.mock.calls.map((c: any) => c[0]);
    expect(upsertCalls).toContainEqual(expect.objectContaining({ create: expect.objectContaining({ sourceType: 'REFUND', sourceId: 'r1', status: 'RECONCILED' }) }));
  });
});

  it('converges from missing provider to reconciled when a late provider event arrives', async () => {
    const { svc, prisma } = build();
    prisma.sale.findFirst.mockResolvedValue({ id: 'card-sale', invoiceNo: 'INV-CARD', subtotal: 100, total: 100, paymentMethod: 'CARD', paymentReference: 'pi_late', memberId: null, userName: 'staff', items: [{ id: 'si1', name: 'Water', qty: 1, price: 100 }] });
    prisma.paymentProviderEvent.findMany = jest.fn().mockResolvedValue([]);
    await svc.reconcileSale('g1', 'card-sale');
    
    let upsertCalls = prisma.financialReconciliation.upsert.mock.calls.map((c: any) => c[0]);
    expect(upsertCalls).toContainEqual(expect.objectContaining({ create: expect.objectContaining({ status: 'MISSING_PROVIDER', sourceId: 'card-sale' }) }));

    prisma.paymentProviderEvent.findMany = jest.fn().mockResolvedValue([{ provider: 'card', eventId: 'evt_late', payload: { data: { object: { id: 'pi_late', amount_received: 10000, currency: 'egp', status: 'succeeded' } } } }]);
    await svc.reconcileSale('g1', 'card-sale');
    
    upsertCalls = prisma.financialReconciliation.upsert.mock.calls.map((c: any) => c[0]);
    expect(upsertCalls).toContainEqual(expect.objectContaining({ create: expect.objectContaining({ status: 'RECONCILED', sourceId: 'card-sale', providerAmount: 100 }) }));
  });

  it('detects provider amount mismatch', async () => {
    const { svc, prisma } = build();
    prisma.sale.findFirst.mockResolvedValue({ id: 'card-sale', invoiceNo: 'INV-CARD', subtotal: 100, total: 100, paymentMethod: 'CARD', paymentReference: 'pi_bad', memberId: null, userName: 'staff', items: [{ id: 'si1', name: 'Water', qty: 1, price: 100 }] });
    prisma.paymentProviderEvent.findMany = jest.fn().mockResolvedValue([{ provider: 'card', eventId: 'evt_bad', payload: { data: { object: { id: 'pi_bad', amount_received: 7000, currency: 'egp', status: 'succeeded' } } } }]);
    await svc.reconcileSale('g1', 'card-sale');
    
    const upsertCalls = prisma.financialReconciliation.upsert.mock.calls.map((c: any) => c[0]);
    expect(upsertCalls).toContainEqual(expect.objectContaining({ create: expect.objectContaining({ status: 'AMOUNT_MISMATCH', sourceId: 'card-sale', providerAmount: 70 }) }));
  });


  it('converges a Stripe provider payment event into existing sale and payment reconciliation without duplicates', async () => {
    const { svc, prisma } = build();
    const sale = { id: 'sale-stripe', invoiceNo: 'INV-STRIPE', subtotal: 100, total: 100, paymentMethod: 'CARD', paymentReference: 'pi_ok', memberId: null, userName: 'staff', items: [{ id: 'si1', name: 'Water', qty: 1, price: 100 }] };
    prisma.sale.findMany.mockResolvedValue([{ id: sale.id }]);
    prisma.sale.findFirst.mockResolvedValue(sale);
    prisma.payment.findMany.mockResolvedValue([]);
    prisma.paymentProviderEvent.findMany.mockResolvedValue([{ provider: 'stripe', eventId: 'evt_pi_ok', payload: { data: { object: { id: 'pi_ok', amount_received: 10000, currency: 'egp', status: 'succeeded', metadata: { gymId: 'g1' } } } } }]);
    // accessing private property for testing
    (svc as any as { stripe: any }).stripe = {
      webhooks: { constructEvent: () => ({ id: 'evt_pi_ok', type: 'payment_intent.succeeded', data: { object: { id: 'pi_ok', amount_received: 10000, currency: 'egp', status: 'succeeded', metadata: { gymId: 'g1' } } } }) },
    };

    await svc.handleWebhook('sig', Buffer.from('{}'));

    expect(prisma.paymentProviderEvent.create).toHaveBeenCalled();
    
    const upsertCalls = prisma.financialReconciliation.upsert.mock.calls.map((c: any) => c[0]);
    expect(upsertCalls).toContainEqual(expect.objectContaining({ create: expect.objectContaining({ sourceType: 'SALE', sourceId: 'sale-stripe', provider: 'stripe', status: 'RECONCILED', providerAmount: 100 }) }));
  });

  it('records unmatched Stripe payment failure as provider failed reconciliation', async () => {
    const { svc, prisma } = build();
    // accessing private property for testing
    (svc as any as { stripe: any }).stripe = {
      webhooks: { constructEvent: () => ({ id: 'evt_fail', type: 'payment_intent.payment_failed', data: { object: { id: 'pi_fail', amount: 9900, currency: 'egp', status: 'failed', metadata: { gymId: 'g1' } } } }) },
    };

    await svc.handleWebhook('sig', Buffer.from('{}'));

    const upsertCalls = prisma.financialReconciliation.upsert.mock.calls.map((c: any) => c[0]);
    expect(upsertCalls).toContainEqual(expect.objectContaining({ create: expect.objectContaining({ sourceType: 'PAYMENT', sourceId: 'pi_fail', provider: 'stripe', providerRef: 'pi_fail', status: 'PROVIDER_FAILED', providerAmount: 99 }) }));
  });
