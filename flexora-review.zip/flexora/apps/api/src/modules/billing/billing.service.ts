/**
 * FLEXORA Gym OS — Billing & Financial Reconciliation
 */
import { BadRequestException, Injectable, Logger, NotFoundException, Optional } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import Stripe from 'stripe';
import { SubscriptionTier, Prisma, SubscriptionStatus, PaymentStatus, InvoiceStatus, RefundStatus, BillingRecoveryStatus, FinancialSourceType, FinancialReconciliationStatus, NotifyChannel, NotifyStatus } from '@prisma/client';
import { randomBytes } from 'crypto';
import { PrismaService } from '../../config/prisma.service';
import { RedisService } from '../../config/redis.service';
import { ProductEventEmitter } from '../../events/PRODUCT_EVENT_EMITTER';
import { NotificationsService } from '../notifications/notifications.service';
import { EncryptionService } from '../../common/security/encryption.service';
import { CronLeadershipService } from '../../common/services/cron-leadership.service';
import { TenantContextService } from '../../common/services/tenant-context.service';

const PRICE_MAP: Record<string, string | undefined> = {
  BASIC: process.env.STRIPE_PRICE_BASIC,
  PRO: process.env.STRIPE_PRICE_PRO,
  ELITE: process.env.STRIPE_PRICE_ELITE,
};

type ProviderSnapshot = {
  provider: string;
  providerRef: string;
  amount?: number;
  currency?: string;
  failed?: boolean;
  eventId?: string;
};

@Injectable()
export class BillingService {
  private readonly logger = new Logger('Billing');
  private stripe: Stripe | null =
    process.env.STRIPE_SECRET_KEY
      ? new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: '2023-10-16' })
      : null;

  constructor(
    private readonly prisma: PrismaService,
    private readonly notifications: NotificationsService,
    private readonly cronLeadership: CronLeadershipService,
    @Optional() private readonly encryption?: EncryptionService,
    @Optional() private readonly events?: ProductEventEmitter,
    @Optional() private readonly redis?: RedisService,
    @Optional() private readonly tenantContext?: TenantContextService,
  ) {}

  private runInTenant<T>(gymId: string, fn: () => T): T {
    return this.tenantContext ? this.tenantContext.run(gymId, fn) : fn();
  }

  async getSubscription(gymId: string) {
    const gymSub = await this.prisma.subscription.findUnique({ where: { gymId } });
    if (gymSub) return gymSub;

    const now = new Date();
    return this.prisma.subscription.create({
      data: {
        gymId,
        tier: SubscriptionTier.PRO,
        status: SubscriptionStatus.TRIALING,
        trialStartDate: now,
        trialEndDate: new Date(now.getTime() + 14 * 86400000),
        currentPeriodEnd: new Date(now.getTime() + 14 * 86400000),
      },
    });
  }



  async createCheckoutSession(gymId: string, tier: 'PRO' | 'ELITE') {
    if (!this.stripe) {
      throw new BadRequestException(
        'Payment system is not configured. Contact your administrator.'
      );
    }
    const price = tier === 'PRO' ? process.env.STRIPE_PRO_PRICE_ID || process.env.STRIPE_PRICE_PRO : process.env.STRIPE_ELITE_PRICE_ID || process.env.STRIPE_PRICE_ELITE;
    if (!price) throw new BadRequestException(`Stripe price is not configured for ${tier}`);
    const gym = await this.prisma.gym.findUniqueOrThrow({ where: { id: gymId } });
    let sub = await this.prisma.subscription.findUnique({ where: { gymId } });
    let customerId = sub?.stripeCustomerId || undefined;
    if (!customerId) {
      const customer = await this.stripe.customers.create({ email: gym.email || undefined, name: gym.name, metadata: { gymId } });
      customerId = customer.id;
      sub = await this.prisma.subscription.upsert({ where: { gymId }, update: { stripeCustomerId: customerId }, create: { gymId, stripeCustomerId: customerId, tier: 'PRO', status: 'TRIALING', trialStartDate: new Date(), trialEndDate: new Date(Date.now() + 14 * 86400000), currentPeriodEnd: new Date(Date.now() + 14 * 86400000) } });
    }
    const frontend = process.env.FRONTEND_URL || process.env.CORS_ORIGIN || 'http://localhost:3000';
    const session = await this.stripe.checkout.sessions.create({
      mode: 'subscription',
      customer: customerId,
      line_items: [{ price, quantity: 1 }],
      success_url: `${frontend}/billing/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${frontend}/billing/cancel`,
      metadata: { gymId, tier },
      subscription_data: { metadata: { gymId, tier } },
      allow_promotion_codes: true,
    });
    return { url: session.url, sessionId: session.id };
  }

  async cancelGymSubscription(gymId: string) {
    const sub = await this.prisma.subscription.findUnique({ where: { gymId } });
    if (!sub) throw new NotFoundException('Subscription not found');
    if (this.stripe && sub.stripeSubscriptionId) {
      await this.stripe.subscriptions.update(sub.stripeSubscriptionId, { cancel_at_period_end: true });
    }
    return this.prisma.subscription.update({ where: { gymId }, data: { cancelAtPeriodEnd: true } });
  }

  async getPortalUrl(gymId: string) {
    const sub = await this.prisma.subscription.findUnique({ where: { gymId } });
    if (!this.stripe || !sub?.stripeCustomerId) throw new BadRequestException('Stripe customer portal is not available');
    const frontend = process.env.FRONTEND_URL || process.env.CORS_ORIGIN || 'http://localhost:3000';
    const session = await this.stripe.billingPortal.sessions.create({ customer: sub.stripeCustomerId, return_url: `${frontend}/billing` });
    return { url: session.url };
  }

  @Cron('0 9 * * *', { name: 'billing-trial-expiry' })
  async checkTrialExpiry() {
    if (!(await this.cronLeadership.acquireLock('trial-expiry', 3600_000))) return;
    try {
      const gyms = await this.prisma.gym.findMany({
        where: { status: { in: ['ACTIVE', 'TRIAL'] } },
        select: { id: true, email: true },
        take: 5000,
      });
      const now = new Date();
      const threeDaysFromNow = new Date(now.getTime() + 3 * 86400000);
      for (const gym of gyms) {
        await this.runInTenant(gym.id, async () => {
          const sub = await this.prisma.subscription.findUnique({ where: { gymId: gym.id } });
          if (!sub || sub.status !== 'TRIALING' || !sub.trialEndDate) return;
          if (sub.trialEndDate <= now) {
            await this.prisma.$transaction([
              this.prisma.subscription.update({ where: { gymId: gym.id }, data: { tier: 'BASIC', status: 'ACTIVE', currentPeriodEnd: now } }),
              this.prisma.notification.create({ data: { gymId: gym.id, channel: 'INAPP', to: gym.email || gym.id, subject: 'Trial ended', body: 'فترة التجربة انتهت وتم تحويل حسابك إلى BASIC. تقدر ترقي في أي وقت.', status: 'PENDING' } }),
            ]);
          } else if (sub.trialEndDate <= threeDaysFromNow) {
            await this.prisma.notification.create({ data: { gymId: gym.id, channel: 'INAPP', to: gym.email || gym.id, subject: 'Trial ending soon', body: 'فترة التجربة هتنتهي خلال 3 أيام. رقّي لباقة PRO عشان تكمل بكل المميزات.', status: 'PENDING' } });
          }
        });
      }
    } finally {
      await this.cronLeadership.releaseLock('trial-expiry');
    }
  }

  async cancelSubscription(gymId: string, actorId: string, reason?: string) {
    if (!gymId || gymId === 'unknown') throw new BadRequestException('Valid gymId is required for cancellation');
    return this.prisma.$transaction(async (tx) => {
      await tx.auditLog.create({ data: { gymId, userId: actorId, action: 'billing.cancel.attempt', entity: 'Subscription', meta: { reason: reason || null } } });
      const subscription = await tx.subscription.findUnique({ where: { gymId } });
      if (!subscription) throw new BadRequestException('Subscription not found for gym');
      const updated = await tx.subscription.update({ where: { gymId }, data: { status: 'CANCELED', cancelledAt: new Date() } });
      await tx.auditLog.create({
      data: {
        gymId,
        userId: actorId,
        action: 'billing.cancel.success',
        entity: 'Subscription',
        entityId: updated.id,
        meta: { reason: reason || null } as Prisma.InputJsonValue
      },
    });
    return updated;
  }, { isolationLevel: Prisma.TransactionIsolationLevel.Serializable });
}

  async createCheckout(gymId: string, tier: 'BASIC' | 'PRO' | 'ELITE') {
    if (tier === 'PRO' || tier === 'ELITE') return this.createCheckoutSession(gymId, tier);
    if (!this.stripe) {
      throw new BadRequestException(
        'Payment system is not configured. Contact your administrator.'
      );
    }
    const price = PRICE_MAP[tier];
    if (!price) throw new BadRequestException('Price not configured for tier');
    const gym = await this.prisma.gym.findUniqueOrThrow({ where: { id: gymId } });
    const session = await this.stripe.checkout.sessions.create({
      mode: 'subscription',
      line_items: [{ price, quantity: 1 }],
      customer_email: gym.email || undefined,
      success_url: `${process.env.CORS_ORIGIN}/billing?status=success`,
      cancel_url: `${process.env.CORS_ORIGIN}/billing?status=cancel`,
      metadata: { gymId, tier },
    });
    return { url: session.url };
  }

  private async recordProviderEvent(gymId: string, provider: string, eventId: string | undefined, eventType: string, payload: unknown, txClient?: Prisma.TransactionClient) {
    const prisma = txClient || this.prisma;
    if (!eventId) throw new BadRequestException('Provider event id is required for idempotency');
    const existing = await prisma.paymentProviderEvent.findUnique({ where: { provider_eventId: { provider, eventId } } });
    if (existing) return { duplicate: true, event: existing };
    try {
      const event = await prisma.paymentProviderEvent.create({
        data: { gymId, provider, eventId, eventType, payload: payload as Prisma.InputJsonValue, status: 'PROCESSED' },
      });
      return { duplicate: false, event };
    } catch (e: unknown) {
      if ((e as Record<string, any>)?.code === 'P2002') return { duplicate: true, event: null };
      throw e;
    }
  }

  private async upsertReconciliation(input: {
    gymId: string;
    sourceType: FinancialSourceType;
    sourceId: string;
    expectedAmount: number;
    provider?: string | null;
    providerRef?: string | null;
    providerAmount?: number | null;
    currency?: string;
    status: FinancialReconciliationStatus;
    reason?: string | null;
  }, txClient?: Prisma.TransactionClient) {
    const prisma = txClient || this.prisma;
    if (!input.gymId) throw new BadRequestException('Reconciliation requires gymId');
    if (!input.sourceId) throw new BadRequestException('Reconciliation requires sourceId');
    return prisma.financialReconciliation.upsert({
      where: { gymId_sourceType_sourceId: { gymId: input.gymId, sourceType: input.sourceType, sourceId: input.sourceId } },
      update: {
        provider: input.provider ?? 'internal',
        providerRef: input.providerRef ?? '',
        expectedAmount: input.expectedAmount,
        providerAmount: input.providerAmount ?? 0,
        currency: input.currency || 'EGP',
        status: input.status,
        reason: input.reason ?? undefined,
      },
      create: {
        gymId: input.gymId,
        sourceType: input.sourceType,
        sourceId: input.sourceId,
        provider: input.provider ?? 'internal',
        providerRef: input.providerRef ?? '',
        expectedAmount: input.expectedAmount,
        providerAmount: input.providerAmount ?? 0,
        currency: input.currency || 'EGP',
        status: input.status,
        reason: input.reason ?? undefined,
      },
    });
  }

  private reconciliationForPayment(method?: string | null, reference?: string | null): { status: FinancialReconciliationStatus; reason: string } {
    const paymentMethod = (method || 'CASH').toUpperCase();
    if (paymentMethod === 'CASH') return { status: FinancialReconciliationStatus.RECONCILED, reason: 'Cash payment is internally reconciled' };
    if (!reference) return { status: FinancialReconciliationStatus.MISSING_INTERNAL, reason: `${paymentMethod} payment missing provider reference` };
    return { status: FinancialReconciliationStatus.PENDING, reason: `${paymentMethod} payment requires provider verification` };
  }

  private providerForPayment(method?: string | null, reference?: string | null): string {
    const paymentMethod = (method || 'CASH').toUpperCase();
    if (paymentMethod === 'CASH') return 'CASH';
    if (paymentMethod === 'STRIPE' || paymentMethod === 'PAYMOB') return paymentMethod.toLowerCase();

    const ref = String(reference || '');
    if (/^(pi|ch|cs|re|sub|in)_/.test(ref)) return 'stripe';
    if (/^(paymob|txn|ord)_/i.test(ref) || /^\d{4,}$/.test(ref)) return 'paymob';

    return paymentMethod;
  }

  private findRefs(payload: unknown): string[] {
    const refs = new Set<string>();
    const keyLooksLikeReference = (key: string) => /(^id$|_id$|reference|ref|transaction|payment|intent|charge|invoice|subscription|order)/i.test(key);
    const visit = (value: unknown, key = '') => {
      if (value == null) return;
      if (typeof value === 'string') {
        if (/^(pi|ch|re|sub|cs|in|ord|txn|paymob)_/.test(value) || (keyLooksLikeReference(key) && value.length >= 4) || /^\d{4,}$/.test(value)) {
          refs.add(value);
        }
        return;
      }
      if (typeof value === 'number') {
        if (Number.isFinite(value) && keyLooksLikeReference(key)) refs.add(String(value));
        return;
      }
      if (Array.isArray(value)) return value.forEach((item) => visit(item, key));
      if (typeof value === 'object') Object.entries(value as Record<string, unknown>).forEach(([childKey, childValue]) => visit(childValue, childKey));
    };
    visit(payload);
    return Array.from(refs);
  }

  private amountFromPayload(provider: string, payload: unknown): number | undefined {
    const data = payload as Record<string, any>;
    const object = data?.data?.object ?? data?.obj ?? data;
    const candidates: Array<[string, any]> = [
      ['amount_paid', object?.amount_paid],
      ['amount_received', object?.amount_received],
      ['amount_total', object?.amount_total],
      ['amount_due', object?.amount_due],
      ['amount_cents', object?.amount_cents],
      ['amount', object?.amount],
    ];
    const hit = candidates.find(([, value]) => value != null);
    if (!hit) return undefined;
    const [key, raw] = hit;
    const n = Number(raw);
    if (!Number.isFinite(n)) return undefined;
    const isMinorUnit = provider.toLowerCase() === 'stripe' || key.includes('cents') || ['amount_received', 'amount_paid', 'amount_total', 'amount_due'].includes(key);
    return isMinorUnit ? n / 100 : n;
  }

  private currencyFromPayload(payload: unknown): string | undefined {
    const data = payload as Record<string, any>;
    const object = data?.data?.object ?? data?.obj ?? data;
    return object?.currency ? String(object.currency).toUpperCase() : undefined;
  }

  private failedFromPayload(payload: unknown): boolean {
    const data = payload as Record<string, any>;
    const object = data?.data?.object ?? data?.obj ?? data;
    const status = String(object?.status ?? object?.success ?? '').toLowerCase();
    return status === 'failed' || status === 'false' || object?.paid === false;
  }

  private async providerSnapshot(provider: string | null | undefined, providerRef: string | null | undefined, txClient?: Prisma.TransactionClient): Promise<ProviderSnapshot | null> {
    const prisma = txClient || this.prisma;
    if (!provider || !providerRef) return null;
    const events = await prisma.paymentProviderEvent.findMany({ where: { provider }, orderBy: { receivedAt: 'desc' }, take: 1000 });
    for (const event of events) {
      const refs = this.findRefs(event.payload);
      if (!refs.includes(providerRef)) continue;
      return {
        provider,
        providerRef,
        amount: this.amountFromPayload(provider, event.payload),
        currency: this.currencyFromPayload(event.payload),
        failed: this.failedFromPayload(event.payload),
        eventId: event.eventId,
      };
    }
    return null;
  }



  private async convergeProviderEvent(gymId: string, provider: string, payload: unknown, txClient?: Prisma.TransactionClient) {
    const refs = this.findRefs(payload).slice(0, 50);
    if (!refs.length) return { matched: 0 };

    // FIX (Task 1 — nested-transaction atomicity bug): this method used to
    // unconditionally call `this.prisma.$transaction(async (tx) => {...})`
    // itself, regardless of whether the CALLER (ingestProviderEvent) was
    // already running inside its own transaction. That meant this method's
    // work always ran on a SEPARATE physical connection/transaction from
    // whatever called it — confirmed for real against Postgres in
    // src/test/integration/billing-nested-app-transaction-diagnostic.spec.ts
    // (different pg_backend_pid() on the outer vs. "nested" transaction; a
    // later failure in the outer transaction did NOT roll back this
    // method's already-committed work).
    //
    // FIX: accept an OPTIONAL existing transaction client. When the caller
    // passes one in (because it's already inside its own transaction),
    // reuse that SAME client directly — no new `$transaction([...])` call,
    // so all statements run on the caller's own connection/transaction and
    // share its atomicity. When no client is passed in (this method is
    // being called standalone, outside of any existing transaction), keep
    // the original behavior: open a brand-new transaction of its own.
    const run = async (tx: Prisma.TransactionClient) => {
      let matched = 0;
      const sales = await tx.sale.findMany({
        where: { gymId, paymentReference: { in: refs } },
        select: { id: true },
      });
      for (const sale of sales) {
        // Pass `tx` through so reconcileSale participates in the SAME
        // transaction instead of opening its own (see reconcileSale's own
        // comment for the same fix pattern).
        await this.reconcileSale(gymId, sale.id, tx);
        matched += 1;
      }

      const payments = await tx.payment.findMany({
        where: { gymId, reference: { in: refs } },
        select: { id: true },
      });
      for (const payment of payments) {
        await this.reconcilePayment(gymId, payment.id, tx);
        matched += 1;
      }

      const refunds = await tx.financialReconciliation.findMany({
        where: { gymId, sourceType: 'REFUND', provider, providerRef: { in: refs } },
        take: 100,
      });
      for (const refund of refunds) {
        await this.reconcileProviderBacked({
          gymId,
          sourceType: 'REFUND',
          sourceId: refund.sourceId,
          expectedAmount: Number(refund.expectedAmount || 0),
          provider,
          providerRef: refund.providerRef,
          currency: refund.currency || 'EGP',
        }, tx);
        matched += 1;
      }

      return { matched };
    };

    if (txClient) return run(txClient);
    return this.prisma.$transaction((tx) => run(tx), { isolationLevel: 'Serializable' as any });
  }

  async ingestProviderEvent(gymId: string, provider: string, eventId: string | undefined, eventType: string, payload: unknown, txClient?: Prisma.TransactionClient) {
    // FIX (Task 1): same optional-tx pattern as convergeProviderEvent /
    // reconcileSale below. This is the entry point paymob.service.ts's
    // handleWebhook calls from INSIDE its own `this.prisma.$transaction(async
    // (tx) => {...})` — passing that same `tx` through here (see
    // paymob.service.ts) means the payment-attempt writes AND the provider
    // event + reconciliation writes now all run on the exact same
    // connection/transaction, so a later failure anywhere in
    // handleWebhook's transaction correctly rolls back everything,
    // including what used to be this method's own separate transaction.
    const run = async (tx: Prisma.TransactionClient) => {
      const providerEvent = await this.recordProviderEvent(gymId, provider, eventId, eventType, payload, tx);
      if (providerEvent.duplicate) return { received: true, duplicate: true, matched: 0 };
      const convergence = await this.convergeProviderEvent(gymId, provider, payload, tx);
      return { received: true, duplicate: false, matched: convergence.matched };
    };

    if (txClient) return run(txClient);
    return this.prisma.$transaction((tx) => run(tx), { isolationLevel: 'Serializable' as any });
  }


  private async reconcileProviderBacked(input: {
    gymId: string;
    sourceType: FinancialSourceType;
    sourceId: string;
    expectedAmount: number;
    provider: string;
    providerRef?: string | null;
    currency?: string;
  }, txClient?: Prisma.TransactionClient) {
    if (input.provider.toUpperCase() === 'CASH') {
      return this.upsertReconciliation({ ...input, status: FinancialReconciliationStatus.RECONCILED, reason: 'Cash is internally reconciled' }, txClient);
    }
    if (!input.providerRef) {
      return this.upsertReconciliation({ ...input, providerRef: null, status: FinancialReconciliationStatus.MISSING_PROVIDER, reason: `${input.provider} record is missing provider reference` }, txClient);
    }
    const snapshot = await this.providerSnapshot(input.provider.toLowerCase(), input.providerRef, txClient);
    if (!snapshot) {
      return this.upsertReconciliation({ ...input, status: FinancialReconciliationStatus.MISSING_PROVIDER, reason: 'No matching provider event found' }, txClient);
    }
    if (snapshot.failed) {
      return this.upsertReconciliation({ ...input, providerAmount: snapshot.amount, currency: input.currency || snapshot.currency || 'EGP', status: FinancialReconciliationStatus.PROVIDER_FAILED, reason: 'Provider event indicates failure' }, txClient);
    }
    const expectedCurrency = (input.currency || 'EGP').toUpperCase();
    if (snapshot.currency && snapshot.currency.toUpperCase() !== expectedCurrency) {
      return this.upsertReconciliation({ ...input, providerAmount: snapshot.amount, currency: expectedCurrency, status: FinancialReconciliationStatus.CURRENCY_MISMATCH, reason: `Provider currency ${snapshot.currency} does not match ${expectedCurrency}` }, txClient);
    }
    if (snapshot.amount != null && Math.abs(snapshot.amount - input.expectedAmount) > 0.01) {
      return this.upsertReconciliation({ ...input, providerAmount: snapshot.amount, currency: expectedCurrency, status: FinancialReconciliationStatus.AMOUNT_MISMATCH, reason: `Provider amount ${snapshot.amount} does not match expected ${input.expectedAmount}` }, txClient);
    }
    if (snapshot.amount == null) {
      return this.upsertReconciliation({ ...input, currency: expectedCurrency, status: FinancialReconciliationStatus.PENDING, reason: 'Provider event found but amount is missing' }, txClient);
    }
    return this.upsertReconciliation({ ...input, providerAmount: snapshot.amount, currency: expectedCurrency, status: FinancialReconciliationStatus.RECONCILED, reason: 'Provider event matches internal record' }, txClient);
  }

  async reconcileSale(gymId: string, saleId: string, txClient?: Prisma.TransactionClient) {
    // FIX (Task 1): same optional-tx pattern — see convergeProviderEvent's
    // comment above for the full root-cause explanation. When called from
    // convergeProviderEvent (itself possibly reusing ingestProviderEvent's
    // / paymob.service.ts's transaction), reuse that SAME client instead of
    // opening a brand-new, disconnected transaction. When called standalone
    // (e.g. sales.service.ts's afterCheckout, or reconcileGym's loop),
    // behavior is unchanged: open its own transaction.
    const run = async (tx: Prisma.TransactionClient) => {
      const sale = await tx.sale.findFirst({ where: { id: saleId, gymId }, include: { items: true } });
      if (!sale) throw new NotFoundException('Sale not found for reconciliation');
      const invoiceNo = `SALE-${sale.invoiceNo}`;
      let invoice = await tx.invoice.findFirst({ where: { gymId, invoiceNo } });
      if (!invoice) {
        // FIX (launch-readiness, same discovery/root-cause as
        // sales.service.ts's identical fix — see that file's comment for
        // the full explanation): `memberId: sale.memberId || ''` coerced a
        // legitimately-absent guest-sale memberId to an invalid empty
        // string, which violates `Invoice`'s real FK to `Member` the
        // moment that FK exists. `Invoice.memberId` is now correctly
        // optional in schema.prisma (matching `Sale.memberId`), so this
        // should omit the field for guest sales instead.
        invoice = await tx.invoice.create({
          data: {
            gymId,
            memberId: sale.memberId || undefined,
            invoiceNo,
            status: 'PAID',
            subtotal: sale.subtotal,
            total: sale.total,
            paid: sale.total,
            lines: {
              create: sale.items.map((item) => ({
                description: item.name,
                qty: item.qty,
                unitPrice: item.price,
                total: Number(item.price) * item.qty,
              })),
            },
          },
        });
      }
      let payment = await tx.payment.findFirst({ where: { gymId, invoiceId: invoice.id } });
      if (!payment) {
        payment = await tx.payment.create({
          data: {
            gymId,
            invoiceId: invoice.id,
            amount: sale.total,
            method: (sale as Record<string, any>).paymentMethod || 'CASH',
            status: 'PAID',
            reference: (sale as Record<string, any>).paymentReference || null,
            createdBy: sale.userName,
          },
        });
      }
      const receiptNo = `SALE-RCPT-${sale.invoiceNo}`;
      const receipt = await tx.receipt.findFirst({ where: { gymId, receiptNo } });
      if (!receipt) await tx.receipt.create({ data: { gymId, invoiceId: invoice.id, paymentId: payment.id, receiptNo } });

      await this.reconcileProviderBacked({
        gymId,
        sourceType: 'PAYMENT',
        sourceId: payment.id,
        expectedAmount: Number(payment.amount || 0),
        provider: this.providerForPayment(payment.method, payment.reference),
        providerRef: payment.reference,
        currency: 'EGP',
      }, tx);

      return this.reconcileProviderBacked({
        gymId,
        sourceType: 'SALE',
        sourceId: sale.id,
        expectedAmount: Number(sale.total || 0),
        provider: this.providerForPayment((sale as Record<string, any>).paymentMethod, (sale as Record<string, any>).paymentReference),
        providerRef: (sale as Record<string, any>).paymentReference || null,
        currency: 'EGP',
      }, tx);
    };

    if (txClient) return run(txClient);
    return this.prisma.$transaction((tx) => run(tx), { isolationLevel: 'Serializable' as any });
  }

  /**
   * Records an in-person/manual payment as a paid invoice, payment, receipt,
   * and income-ledger entry in one tenant-scoped transaction. Manual payments
   * intentionally do not require a provider reference; CASH is reconciled
   * internally, while other methods remain pending provider verification.
   */
  /**
   * ROUND 14 (security review, PHASE K4): `txClient` lets the caller fold this
   * payment into its OWN transaction (same optional-tx pattern as
   * reconcileSale/reconcilePayment above). Register-and-activate needs the
   * payment, the membership financials and the member activation to live in
   * ONE transaction, so a failure cannot leave a member with no payment (or a
   * payment with no member) behind.
   */
  async createManualPayment(
    gymId: string,
    userId: string,
    dto: { amount: number; method: string; memberName?: string; notes?: string; memberId?: string },
    txClient?: Prisma.TransactionClient,
  ) {
    const amount = Number(dto.amount);
    if (!Number.isFinite(amount) || amount <= 0) {
      throw new BadRequestException('Payment amount must be greater than zero');
    }
    const method = String(dto.method || 'CASH').trim().toUpperCase();
    if (!method || method.length > 40) {
      throw new BadRequestException('A valid payment method is required');
    }

    // PHASE J2 — a manual MEMBERSHIP payment is ALWAYS bound to a member.
    // The DTO already rejects a missing memberId with a 400; this is the
    // service-level guard so the invariant holds for every caller (service
    // calls, future transports) and not just for the HTTP body validator.
    // The legacy "NULL memberId, bind it to the first member that uses it"
    // behaviour survives only for payments that predate the Phase-I migration.
    const memberId = String(dto.memberId || '').trim();
    if (!memberId) {
      throw new BadRequestException('A member is required for a manual membership payment');
    }
    // PHASE K4: the check must run on the CALLER's transaction when one is
    // supplied. Reading through `this.prisma` would look at a different
    // connection that cannot see the member the caller created moments ago
    // inside its own not-yet-committed transaction.
    const member = await (txClient ?? this.prisma).member.findFirst({ where: { id: memberId, gymId } });
    if (!member) throw new BadRequestException('Member not found for this gym');

    const run = async (tx: Prisma.TransactionClient) => {
      const suffix = randomBytes(4).toString('hex').toUpperCase();
      const invoiceNo = `MANUAL-${Date.now().toString(36).toUpperCase()}-${suffix}`;
      const receiptNo = `MANUAL-RCPT-${Date.now().toString(36).toUpperCase()}-${suffix}`;
      const description = [
        'Manual payment',
        dto.memberName?.trim() ? `for ${dto.memberName.trim()}` : undefined,
        dto.notes?.trim() ? `— ${dto.notes.trim()}` : undefined,
      ].filter(Boolean).join(' ');

      const invoice = await tx.invoice.create({
        data: {
          gymId,
          invoiceNo,
          status: 'PAID',
          subtotal: amount,
          total: amount,
          paid: amount,
          lines: { create: [{ description, qty: 1, unitPrice: amount, total: amount }] },
        },
      });
      const payment = await tx.payment.create({
        data: {
          gymId,
          invoiceId: invoice.id,
          amount,
          method,
          status: 'PAID',
          createdBy: userId,
          // PHASE I1: a manual front-desk payment is a MANUAL_MEMBERSHIP
          // payment. PHASE J2: it is ALWAYS bound to the member it was taken
          // for (validated above) — never a NULL memberId.
          purpose: 'MANUAL_MEMBERSHIP',
          memberId,
        },
      });
      const receipt = await tx.receipt.create({
        data: { gymId, invoiceId: invoice.id, paymentId: payment.id, receiptNo, channel: 'IN_PERSON' },
      });
      // P4-5: ledger shows the plain description built above (who/what), with
      // the manual invoice number kept as the readable reference.
      // FIX (round 8 review): store paymentId on the transaction so
      // createMembershipFinancials() can find THIS exact transaction by FK
      // instead of a heuristic (reference LIKE 'MANUAL-%', same createdBy).
      const ledgerEntry = await tx.transaction.create({
        data: { gymId, type: 'INCOME', category: 'MANUAL_PAYMENT', reference: invoiceNo, description: description || 'Manual payment', amount, createdBy: userId, paymentId: payment.id },
      });
      await tx.auditLog.create({
        data: { gymId, userId, action: 'billing.manual_payment.created', entity: 'Payment', entityId: payment.id, meta: { amount, method, invoiceNo } },
      });
      const reconciliation = await this.reconcilePayment(gymId, payment.id, tx);
      return { invoice, payment, receipt, ledgerEntry, reconciliation };
    };

    // PHASE K4: join the caller's transaction when there is one, otherwise own one.
    if (txClient) return run(txClient);
    return this.prisma.$transaction((tx) => run(tx), { isolationLevel: 'ReadCommitted' as any });
  }

  async reconcilePayment(gymId: string, paymentId: string, txClient?: Prisma.TransactionClient) {
    // FIX (Task 1): same optional-tx pattern as reconcileSale above.
    const prisma = txClient || this.prisma;
    const payment = await prisma.payment.findFirst({ where: { id: paymentId, gymId } });
    if (!payment) throw new NotFoundException('Payment not found for reconciliation');
    return this.reconcileProviderBacked({
      gymId,
      sourceType: 'PAYMENT',
      sourceId: payment.id,
      expectedAmount: Number(payment.amount || 0),
      provider: this.providerForPayment(payment.method, payment.reference),
      providerRef: payment.reference,
      currency: 'EGP',
    }, txClient);
  }


  async reconcileGym(gymId: string) {
    const sales = await this.prisma.sale.findMany({ where: { gymId }, take: 500 });
    const payments = await this.prisma.payment.findMany({ where: { gymId }, take: 500 });
    const refunds = await this.prisma.refund.findMany({ where: { gymId }, take: 500 });
    const subscriptions = await this.prisma.subscription.findMany({ where: { gymId }, take: 500 });

    const rows: unknown[] = [];
    for (const sale of sales) {
      rows.push(await this.reconcileSale(gymId, sale.id));
    }
    for (const payment of payments) {
      rows.push(await this.reconcilePayment(gymId, payment.id));
    }
    for (const refund of refunds) {
      const sale = await this.prisma.sale.findFirst({ where: { id: refund.saleId, gymId } });
      const method = ((sale as Record<string, any>)?.paymentMethod || 'CASH').toUpperCase();
      const reference = (sale as Record<string, any>)?.paymentReference || null;
      const existingRecon = await this.prisma.financialReconciliation.findUnique({ where: { gymId_sourceType_sourceId: { gymId, sourceType: 'REFUND', sourceId: refund.id } } });
      rows.push(await this.reconcileProviderBacked({
        gymId,
        sourceType: 'REFUND',
        sourceId: refund.id,
        expectedAmount: Number(refund.amount || 0),
        provider: (existingRecon?.provider || this.providerForPayment(method, reference)) as string,
        providerRef: existingRecon?.providerRef || reference,
        currency: 'EGP',
      }));
    }
    for (const subscription of subscriptions) {
      const providerRef = subscription.stripeSubscriptionId;
      rows.push(await this.upsertReconciliation({
        gymId,
        sourceType: 'SUBSCRIPTION',
        sourceId: subscription.id,
        expectedAmount: 0,
        provider: providerRef ? 'stripe' : null,
        providerRef,
        status: subscription.status === 'ACTIVE' ? 'RECONCILED' : 'PENDING',
        reason: `Subscription status ${subscription.status}`,
      }));
    }
    return { gymId, reconciled: rows.length, rows };
  }

  async listReconciliation(gymId: string) {
    await this.reconcileGym(gymId);
    return this.prisma.financialReconciliation.findMany({ where: { gymId }, orderBy: { updatedAt: 'desc' }, take: 500 });
  }

  listRecoveryTasks(gymId: string) {
    return this.prisma.billingRecoveryTask.findMany({ where: { gymId }, orderBy: { dueAt: 'asc' }, take: 100 });
  }

  async retryRecoveryTask(gymId: string, taskId: string) {
    const task = await this.prisma.billingRecoveryTask.findFirst({ where: { id: taskId, gymId } });
    if (!task) throw new NotFoundException('Recovery task not found');
    if (Number(task.stage) >= 3) {
      await this.prisma.subscription.updateMany({ where: { gymId }, data: { status: 'CANCELED' } });
      return this.prisma.billingRecoveryTask.update({ where: { id: taskId }, data: { status: 'EXPIRED', stage: task.stage + 1, dueAt: new Date(), notes: 'Final dunning stage expired; subscription canceled' } });
    }
    return this.prisma.billingRecoveryTask.update({ where: { id: taskId }, data: { status: 'RETRYING', stage: task.stage + 1, dueAt: new Date(Date.now() + 24 * 3600000) } });
  }



  private async paymobAuthToken(): Promise<string> {
    if (!process.env.PAYMOB_API_KEY) throw new BadRequestException('Paymob is not configured');
    const res = await fetch('https://accept.paymob.com/api/auth/tokens', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ api_key: process.env.PAYMOB_API_KEY }),
      signal: AbortSignal.timeout(15000),
    });
    if (!res.ok) throw new BadRequestException(`Paymob auth failed (${res.status})`);
    const data = (await res.json()) as { token: string };
    return data.token;
  }

  private async createPaymobRefund(providerRef: string, amount: number) {
    const token = await this.paymobAuthToken();
    const res = await fetch('https://accept.paymob.com/api/acceptance/void_refund/refund', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        auth_token: token,
        transaction_id: /^\d+$/.test(providerRef) ? Number(providerRef) : providerRef,
        amount_cents: Math.round(amount * 100),
      }),
      signal: AbortSignal.timeout(15000),
    });
    const data = (await res.json().catch(() => ({}))) as Record<string, unknown>;
    if (!res.ok) throw new BadRequestException(`Paymob refund failed (${res.status})`);
    return data;
  }

  async syncRefund(gymId: string, refundId: string) {
    const refund = await this.prisma.refund.findFirst({ where: { id: refundId, gymId } });
    if (!refund) throw new NotFoundException('Refund not found');
    const sale = await this.prisma.sale.findFirst({ where: { id: refund.saleId, gymId } });
    if (!sale) throw new NotFoundException('Refund sale not found');
    const method = ((sale as Record<string, any>).paymentMethod || 'CASH').toUpperCase();
    const providerRef = (sale as Record<string, any>).paymentReference || null;

    const audit = (action: string, reason?: string) => this.prisma.refundAudit.create({ data: { gymId, refundId: refund.id, action, reason } });

    if (method === 'CASH') {
      await audit('REFUND_SYNC_RECONCILED', 'Cash refund reconciled internally');
      return this.upsertReconciliation({ gymId, sourceType: 'REFUND', sourceId: refund.id, expectedAmount: Number(refund.amount), provider: 'CASH', status: 'RECONCILED', reason: 'Cash refund reconciled internally' });
    }
    const refundProvider = this.providerForPayment(method, providerRef);
    if (refundProvider === 'stripe' && providerRef && !this.stripe) {
      await this.prisma.billingRecoveryTask.create({ data: { gymId, status: 'FAILED', stage: 1, dueAt: new Date(Date.now() + 24 * 3600000), notes: 'Refund provider sync failed: Stripe is not configured' } });
      await audit('REFUND_SYNC_FAILED', 'Stripe is not configured');
      return this.upsertReconciliation({ gymId, sourceType: 'REFUND', sourceId: refund.id, expectedAmount: Number(refund.amount), provider: 'stripe', providerRef, status: 'PROVIDER_FAILED', reason: 'Stripe is not configured' });
    }
    if (refundProvider === 'stripe' && this.stripe && providerRef) {
      try {
        const params: Stripe.RefundCreateParams = providerRef.startsWith('pi_')
          ? { payment_intent: providerRef, amount: Math.round(Number(refund.amount) * 100) }
          : { charge: providerRef, amount: Math.round(Number(refund.amount) * 100) };
        const providerRefund = await this.stripe.refunds.create(params);
        await this.recordProviderEvent(gymId, 'stripe', providerRefund.id, 'refund.created', providerRefund);
        await audit('REFUND_SYNC_RECONCILED', 'Stripe refund created');
        return this.upsertReconciliation({ gymId, sourceType: 'REFUND', sourceId: refund.id, expectedAmount: Number(refund.amount), provider: 'stripe', providerRef: providerRefund.id, providerAmount: Number(refund.amount), status: 'RECONCILED', reason: 'Stripe refund created' });
      } catch (e: unknown) {
        await this.prisma.billingRecoveryTask.create({ data: { gymId, status: 'FAILED', stage: 1, dueAt: new Date(Date.now() + 24 * 3600000), notes: `Refund provider sync failed: ${(e as Error).message}` } });
        await audit('REFUND_SYNC_FAILED', (e as Error).message);
        return this.upsertReconciliation({ gymId, sourceType: 'REFUND', sourceId: refund.id, expectedAmount: Number(refund.amount), provider: 'stripe', providerRef, status: 'PROVIDER_FAILED', reason: (e as Error).message });
      }
    }
    if (refundProvider === 'paymob' && providerRef) {
      try {
        const providerRefund = await this.createPaymobRefund(providerRef, Number(refund.amount));
        const paymobRefundRef = String((providerRefund as Record<string, unknown>).id ?? (providerRefund as Record<string, unknown>).transaction_id ?? providerRef);
        await this.recordProviderEvent(gymId, 'paymob', paymobRefundRef, 'refund.created', providerRefund);
        await audit('REFUND_SYNC_RECONCILED', 'Paymob refund created');
        return this.upsertReconciliation({ gymId, sourceType: 'REFUND', sourceId: refund.id, expectedAmount: Number(refund.amount), provider: 'paymob', providerRef: paymobRefundRef, providerAmount: Number(refund.amount), status: 'RECONCILED', reason: 'Paymob refund created' });
      } catch (e: unknown) {
        await this.prisma.billingRecoveryTask.create({ data: { gymId, status: 'FAILED', stage: 1, dueAt: new Date(Date.now() + 24 * 3600000), notes: `Refund provider sync failed: ${(e as Error).message}` } });
        await audit('REFUND_SYNC_FAILED', (e as Error).message);
        return this.upsertReconciliation({ gymId, sourceType: 'REFUND', sourceId: refund.id, expectedAmount: Number(refund.amount), provider: 'paymob', providerRef, status: 'PROVIDER_FAILED', reason: (e as Error).message });
      }
    }
    await audit(providerRef ? 'REFUND_SYNC_PENDING' : 'REFUND_SYNC_MISSING_PROVIDER', providerRef ? 'Provider adapter missing' : 'Provider reference missing');
    return this.upsertReconciliation({ gymId, sourceType: 'REFUND', sourceId: refund.id, expectedAmount: Number(refund.amount), provider: providerRef ? refundProvider : method, providerRef, status: providerRef ? 'PENDING' : 'MISSING_PROVIDER', reason: providerRef ? 'External refund requires provider adapter' : 'Refund missing provider reference' });
  }

  private async createPastDueRecovery(local: { gymId: string }, provider: string, providerRef: string, currency = 'USD', error = 'Payment failed') {
    await this.prisma.paymentAttempt.create({ data: { gymId: local.gymId, provider, providerRef, status: 'FAILED', amount: 0, currency, error } });
    const existing = await this.prisma.billingRecoveryTask.findFirst({ where: { gymId: local.gymId, status: { in: ['FAILED', 'RETRYING'] } } });
    if (!existing) await this.prisma.billingRecoveryTask.create({ data: { gymId: local.gymId, status: 'FAILED', stage: 1, dueAt: new Date(Date.now() + 24 * 3600000), notes: 'Retry payment and contact owner' } });
  }

  async handleWebhook(signature: string, payload: Buffer) {
    if (!this.stripe || !process.env.STRIPE_WEBHOOK_SECRET) throw new BadRequestException('Stripe not configured');
    let event: Stripe.Event;
    try {
      event = this.stripe.webhooks.constructEvent(payload, signature, process.env.STRIPE_WEBHOOK_SECRET);
    } catch (e: unknown) {
      throw new BadRequestException(`Webhook signature failed: ${(e as Error).message}`);
    }

    if (event.type === 'checkout.session.completed') {
      const s = event.data.object as Stripe.Checkout.Session;
      const gymId = s.metadata?.gymId;
      const tier = (s.metadata?.tier as SubscriptionTier) || SubscriptionTier.BASIC;
      if (gymId) {
        const providerEvent = await this.ingestProviderEvent(gymId, 'stripe', event.id, event.type, event as unknown as Prisma.InputJsonValue);
        if (providerEvent.duplicate) return { received: true, duplicate: true };
        let periodEnd = new Date(Date.now() + 30 * 86400000);
        if (s.subscription) {
          const stripeSub = await this.stripe.subscriptions.retrieve(s.subscription as string);
          periodEnd = new Date(stripeSub.current_period_end * 1000);
        }
        await this.prisma.subscription.upsert({ where: { gymId }, update: { tier, status: 'ACTIVE', stripeCustomerId: s.customer as string, stripeSubscriptionId: s.subscription as string, stripePriceId: PRICE_MAP[tier], currentPeriodEnd: periodEnd, cancelAtPeriodEnd: false }, create: { gymId, tier, status: 'ACTIVE', stripeCustomerId: s.customer as string, stripeSubscriptionId: s.subscription as string, stripePriceId: PRICE_MAP[tier], currentPeriodEnd: periodEnd } });
        await this.prisma.gym.update({ where: { id: gymId }, data: { status: 'ACTIVE' } });
        await this.upsertReconciliation({ gymId, sourceType: 'SUBSCRIPTION', sourceId: gymId, expectedAmount: 0, provider: 'stripe', providerRef: s.subscription as string, status: 'RECONCILED', reason: 'Checkout completed' });
        await this.events?.emitEvent({ type: 'billing.updated', tenantId: gymId, entityId: gymId, payload: { gymId, tier, status: 'ACTIVE' }, source: 'api' });
      }
      return { received: true };
    }

    if (event.type === 'customer.subscription.updated') {
      const sub = event.data.object as Stripe.Subscription;
      const local = await this.prisma.subscription.findFirst({ where: { stripeSubscriptionId: sub.id } });
      if (local) {
        const providerEvent = await this.ingestProviderEvent(local.gymId, 'stripe', event.id, event.type, event as unknown as Prisma.InputJsonValue);
        if (providerEvent.duplicate) return { received: true, duplicate: true };
        const status = sub.status === 'active' ? 'ACTIVE' : sub.status === 'past_due' ? 'PAST_DUE' : undefined;
        await this.prisma.subscription.updateMany({ where: { stripeSubscriptionId: sub.id }, data: { currentPeriodEnd: new Date(sub.current_period_end * 1000), cancelAtPeriodEnd: !!sub.cancel_at_period_end, ...(status ? { status } : {}) } });
        if (status === 'PAST_DUE') await this.createPastDueRecovery(local, 'stripe', sub.id, sub.currency?.toUpperCase?.() || 'USD', 'Subscription past due');
        await this.upsertReconciliation({ gymId: local.gymId, sourceType: 'SUBSCRIPTION', sourceId: local.id, expectedAmount: 0, provider: 'stripe', providerRef: sub.id, status: status === 'PAST_DUE' ? 'PENDING' : 'RECONCILED', reason: `Stripe subscription ${sub.status}` });
      }
      return { received: true };
    }

    if (event.type === 'customer.subscription.deleted') {
      const sub = event.data.object as Stripe.Subscription;
      const local = await this.prisma.subscription.findFirst({ where: { stripeSubscriptionId: sub.id } });
      if (local) {
        const providerEvent = await this.ingestProviderEvent(local.gymId, 'stripe', event.id, event.type, event as unknown as Prisma.InputJsonValue);
        if (providerEvent.duplicate) return { received: true, duplicate: true };
        await this.prisma.subscription.updateMany({ where: { stripeSubscriptionId: sub.id }, data: { tier: 'BASIC', status: 'CANCELED', cancelAtPeriodEnd: false } });
        await this.upsertReconciliation({ gymId: local.gymId, sourceType: 'SUBSCRIPTION', sourceId: local.id, expectedAmount: 0, provider: 'stripe', providerRef: sub.id, status: 'PENDING', reason: 'Subscription canceled' });
        await this.events?.emitEvent({ type: 'billing.updated', tenantId: local.gymId, entityId: sub.id, payload: { subscriptionId: sub.id, status: 'CANCELED' }, source: 'api' });
      }
      return { received: true };
    }

    if (event.type === 'invoice.payment_succeeded') {
      const invoice = event.data.object as Stripe.Invoice;
      const gymId = (invoice.metadata?.gymId as string)
        || (invoice.subscription_details?.metadata?.gymId as string);

      if (!gymId) return { received: true };

      // Update subscription status
      await this.prisma.subscription.updateMany({
        where: { gymId },
        data: {
          status: 'ACTIVE',
          lastPaymentAt: new Date(),
          lastPaymentAmount: invoice.amount_paid / 100,
        }
      });

      // Send receipt to OWNER via WhatsApp
      const gym = await this.prisma.gym.findUnique({
        where: { id: gymId },
      });

      if (gym?.phone) {
        await this.notifications.whatsapp(
          gymId, gym.phone,
          `✅ تم استلام دفعة FLEXORA بنجاح.\n` +
          `المبلغ: ${invoice.amount_paid / 100} ` +
          `${invoice.currency.toUpperCase()}\n` +
          `الفترة القادمة حتى: ` +
          `${new Date((invoice as Stripe.Invoice & { period_end: number }).period_end * 1000).toLocaleDateString('ar-EG')}`
        );
      }

      // Audit log
      await this.prisma.auditLog.create({
        data: {
          gymId,
          action: 'BILLING_PAYMENT_SUCCEEDED',
          entity: 'Subscription',
          meta: {
            invoiceId: invoice.id,
            amount: invoice.amount_paid / 100,
            currency: invoice.currency,
          } as Prisma.InputJsonValue,
        }
      });
      return { received: true };
    }

    if (event.type === 'invoice.payment_failed') {
      const invoice = event.data.object as Record<string, any>;
      const subscriptionId = typeof invoice.subscription === 'string' ? invoice.subscription : (invoice.subscription as Record<string, any>)?.id;
      const local = subscriptionId ? await this.prisma.subscription.findFirst({ where: { stripeSubscriptionId: subscriptionId } }) : null;
      const gymId = (invoice.metadata as Record<string, any>)?.gymId || local?.gymId;
      if (gymId) {
        const providerEvent = await this.ingestProviderEvent(gymId, 'stripe', event.id, event.type, event as unknown as Prisma.InputJsonValue);
        if (providerEvent.duplicate) return { received: true, duplicate: true };
        const providerRef = String(subscriptionId || (typeof invoice.payment_intent === 'string' ? invoice.payment_intent : (invoice.payment_intent as Record<string, any>)?.id) || invoice.id);
        const currency = (invoice.currency as string)?.toUpperCase?.() || 'USD';
        const amount = this.amountFromPayload('stripe', event as unknown as Record<string, any>) ?? 0;
        if (local) await this.createPastDueRecovery(local, 'stripe', providerRef, currency, 'Stripe invoice payment failed');
        await this.upsertReconciliation({
          gymId,
          sourceType: 'SUBSCRIPTION',
          sourceId: local?.id || providerRef,
          expectedAmount: amount,
          provider: 'stripe',
          providerRef,
          providerAmount: amount,
          currency,
          status: 'PROVIDER_FAILED',
          reason: 'Stripe invoice payment failed',
        });
      }
      return { received: true };
    }

    if (event.type === 'payment_intent.succeeded' || event.type === 'charge.succeeded' || event.type === 'payment_intent.payment_failed' || event.type === 'charge.failed') {
      const object = event.data.object as Record<string, any>;
      const gymId = (object.metadata as Record<string, any>)?.gymId;
      if (gymId) {
        const providerEvent = await this.ingestProviderEvent(gymId, 'stripe', event.id, event.type, event as unknown as Prisma.InputJsonValue);
        if (providerEvent.duplicate) return { received: true, duplicate: true };
        const providerRef = object.id as string;
        const amount = this.amountFromPayload('stripe', event as unknown as Record<string, any>) ?? 0;
        const currency = (object.currency as string)?.toUpperCase?.() || 'USD';
        const failed = event.type.endsWith('.failed') || this.failedFromPayload(event as unknown as Record<string, any>);
        if (providerEvent.matched === 0) {
          await this.upsertReconciliation({
            gymId,
            sourceType: 'PAYMENT',
            sourceId: (object.metadata as Record<string, any>)?.paymentId || providerRef,
            expectedAmount: amount,
            provider: 'stripe',
            providerRef,
            providerAmount: amount,
            currency,
            status: failed ? 'PROVIDER_FAILED' : 'MISSING_INTERNAL',
            reason: failed ? `Stripe ${event.type}` : 'Provider payment has no matching internal payment',
          });
        }
      }
      return { received: true };
    }

    const object = event.data.object as Record<string, any>;
    const gymId = (object?.metadata as Record<string, any>)?.gymId;
    if (gymId) {
      const providerEvent = await this.ingestProviderEvent(gymId, 'stripe', event.id, event.type, event as unknown as Prisma.InputJsonValue);
      if (providerEvent.duplicate) return { received: true, duplicate: true };
    }
    return { received: true };
  }

}
