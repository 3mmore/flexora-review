/**
 * ROUND 14 (security review, PHASE F1) — member-renewal webhook specs.
 *
 * The portal "Renew" action creates a RenewalRequest and (when the online
 * provider is configured) starts a checkout for the EXACT plan price. The
 * membership extends ONLY after the provider's VERIFIED webhook confirms the
 * payment: the amount is bound to the plan price, the member+plan are bound
 * to the request row, and one payment produces exactly one extension
 * (idempotent — a replayed webhook is a duplicate, never a second extension).
 *
 * These specs pin that contract with a mocked Prisma (no DB, no Paymob
 * credentials needed).
 */
import { BadRequestException } from '@nestjs/common';
import { PaymobService } from './paymob.service';

const GYM = 'gym-a';
const MEMBER = 'member-1';
const PLAN = { id: 'plan-1m', gymId: GYM, name: '1 Month', price: 450, days: 30, type: 'TIME', sessions: null, active: true };

function makeService() {
  const state: Record<string, any> = {};
  const prisma: any = {
    // PHASE J1: the claim and the apply share ONE serializable transaction, so
    // the mock has to behave like one — every write made inside the callback is
    // DISCARDED when the callback throws (ROLLBACK) and kept when it returns
    // normally (COMMIT). Without this, a rejected delivery would appear to keep
    // its claim and J1 could not be tested at all.
    withTenant: jest.fn(async (_gymId: string, fn: (tx: any) => unknown) => {
      const snapshot = JSON.parse(JSON.stringify(state));
      try {
        return await fn(prisma);
      } catch (e) {
        for (const k of Object.keys(state)) delete (state as Record<string, any>)[k];
        Object.assign(state, snapshot);
        throw e;
      }
    }),
    renewalRequest: {
      // honor the where clause like the real tenant-scoped query, including
      // the PHASE I2 fail-closed rules: CHECKOUT status + providerOrderId set
      findFirst: jest.fn(async ({ where }: any) => {
        if (!state.request) return null;
        if (state.request.gymId !== where.gymId) return null;
        if (state.request.memberId !== where.memberId) return null;
        if (state.request.planId !== where.planId) return null;
        if (where.status) {
          const want = Array.isArray(where.status.in) ? where.status.in : [where.status];
          if (!want.includes(state.request.status)) return null;
        }
        if (where.providerOrderId?.not === null && state.request.providerOrderId == null) return null;
        return state.request;
      }),
      updateMany: jest.fn(async ({ where, data }: any) => {
        if (where.id === state.request?.id && ['PENDING', 'CHECKOUT'].includes(state.request.status)) {
          state.request = { ...state.request, ...data };
          return { count: 1 };
        }
        return { count: 0 };
      }),
      update: jest.fn(async ({ where, data }: any) => {
        state.request = { ...state.request, ...data };
        return state.request;
      }),
    },
    paymentAttempt: {
      // PHASE H4: the (provider, providerTransactionId) claim is unique across
      // the WHOLE PLATFORM — the mock keys on (provider, providerTransactionId)
      // with no gymId.
      findFirst: jest.fn(async ({ where }: any) =>
        state.attempts?.[`${where.provider}|${where.providerTransactionId}`] ?? null,
      ),
      create: jest.fn(async ({ data }: any) => {
        const key = `${data.provider}|${data.providerTransactionId}`;
        if (state.attempts?.[key]) {
          const e: any = new Error('Unique constraint failed');
          e.code = 'P2002';
          throw e;
        }
        state.attempts = state.attempts || {};
        state.attempts[key] = { ...data };
        return data;
      }),
      updateMany: jest.fn(async ({ where, data }: any) => {
        const key = `${where.provider}|${where.providerTransactionId}`;
        if (state.attempts?.[key]) state.attempts[key] = { ...state.attempts[key], ...data };
        return { count: 1 };
      }),
    },
  };
  const members: any = {
    applyPaidRenewal: jest.fn(async (_g: string, _m: string, _p: string, opts: any) => {
      state.applied = (state.applied || 0) + 1;
      return { member: { id: MEMBER }, invoice: { id: 'inv-1' }, payment: { id: 'pay-1' } };
    }),
  };
  const svc = new PaymobService(prisma, members, {} as any, {} as any);
  return { svc, prisma, members, state };
}

// deliver the identical signed webhook twice with a FRESH open request created
// between the deliveries — the provider transaction claim must make the
// second delivery a duplicate that applies NOTHING (PHASE G1)
function freshOpenRequest(over: Record<string, any> = {}) {
  return openRequest({ id: 'req-2', ...over });
}

function openRequest(over: Record<string, any> = {}) {
  return {
    id: 'req-1',
    gymId: GYM,
    memberId: MEMBER,
    planId: PLAN.id,
    status: 'CHECKOUT',
    amount: 450,
    providerRef: `RENEWAL::${GYM}::${MEMBER}::${PLAN.id}::123`,
    // PHASE H4: the SIGNED Paymob order id stored at checkout time
    providerOrderId: '987654',
    ...over,
  };
}

describe('ROUND 14 PHASE F1 — the renewal webhook extends the membership exactly once per payment', () => {
  it('a verified success webhook extends the membership once and marks the request PAID', async () => {
    const { svc, members, state } = makeService();
    state.request = openRequest();

    const res = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: true,
      amount_cents: 45000, // 450 EGP — the exact plan price
      id: 'tx-1',
      pending: false,
      order: { id: 987654, merchant_order_id: openRequest().providerRef },
    });

    expect(res.applied).toBe(true);
    // PHASE G1: the webhook passes its tx client so the tenant-scoped lookups
    // run inside the withTenant transaction (RLS-safe)
    expect(members.applyPaidRenewal).toHaveBeenCalledWith(GYM, MEMBER, PLAN.id, expect.objectContaining({ amount: 450 }), expect.anything());
    expect(state.request.status).toBe('PAID');
    expect(state.request.invoiceId).toBe('inv-1');
    expect(state.applied).toBe(1);
  });

  it('a REPLAYED webhook never produces a second extension', async () => {
    const { svc, members, state } = makeService();
    state.request = openRequest();
    const obj = { success: true, amount_cents: 45000, id: 'tx-1', pending: false, order: { id: 987654, merchant_order_id: openRequest().providerRef } };

    const first = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, obj);
    expect(first.applied).toBe(true);

    // sequential replay: the provider-transaction claim short-circuits it as a
    // duplicate (PHASE G1) — and crucially NO second extension
    const replay = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, obj);
    expect(replay.duplicate).toBe(true);
    expect(state.applied).toBe(1); // exactly one extension for one payment
    expect(members.applyPaidRenewal).toHaveBeenCalledTimes(1);
  });

  it('a CONCURRENT double-webhook (both read PENDING, one wins the transition) is a duplicate', async () => {
    const { svc, prisma, members, state } = makeService();
    state.request = openRequest();
    // simulate the race: the status transition loses (another tx already won)
    prisma.renewalRequest.updateMany.mockResolvedValueOnce({ count: 0 });

    const res = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: true,
      amount_cents: 45000,
      id: 'tx-race',
      pending: false,
      order: { id: 987654, merchant_order_id: openRequest().providerRef },
    });

    expect(res.duplicate).toBe(true);
    expect(members.applyPaidRenewal).not.toHaveBeenCalled();
    expect(state.applied).toBeUndefined();
  });

  it('an amount that does not match the plan price is rejected (amount bound)', async () => {
    const { svc, members, state } = makeService();
    state.request = openRequest();

    await expect((svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: true,
      amount_cents: 10000, // 100 EGP — NOT the plan price
      id: 'tx-2',
      pending: false,
      order: { id: 987654, merchant_order_id: openRequest().providerRef },
    })).rejects.toBeInstanceOf(BadRequestException);
    expect(members.applyPaidRenewal).not.toHaveBeenCalled();
    expect(state.request.status).toBe('CHECKOUT'); // untouched
  });

  it('a webhook for a different member/plan finds no open request (member bound)', async () => {
    const { svc, members, state } = makeService();
    state.request = openRequest({ memberId: 'someone-else', planId: 'plan-other' });

    await expect((svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: true,
      amount_cents: 45000,
      id: 'tx-3',
      pending: false,
      order: { id: 987654, merchant_order_id: openRequest().providerRef },
    })).rejects.toBeInstanceOf(BadRequestException);
    expect(members.applyPaidRenewal).not.toHaveBeenCalled();
  });

  it('PHASE G1: the IDENTICAL webhook delivered twice with a FRESH open request between → duplicate, applied once', async () => {
    const { svc, members, state, prisma } = makeService();
    state.request = openRequest();
    const obj = { success: true, amount_cents: 45000, id: 'tx-g1', pending: false, order: { id: 987654, merchant_order_id: openRequest().providerRef } };

    const first = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, obj);
    expect(first.applied).toBe(true);
    expect(state.applied).toBe(1);

    // a NEW open request exists for the same member+plan (e.g. the member
    // asked again) — a replayed signed webhook must NOT extend a second time
    state.request = freshOpenRequest();
    const second = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, obj);

    expect(second.duplicate).toBe(true);
    expect(second.applied).toBeUndefined();
    expect(state.applied).toBe(1); // still exactly one extension
    expect(members.applyPaidRenewal).toHaveBeenCalledTimes(1);
    // the claimed transaction is bound to the request that consumed it
    const claimKey = `paymob|tx-g1`;
    expect(state.attempts[claimKey].status).toBe('SUCCESS');
    expect(state.attempts[claimKey].providerRef).toBe(openRequest().providerRef);
  });

  it('PHASE G1: a webhook whose member/plan does not match the open request row → rejected', async () => {
    const { svc, members, state } = makeService();
    // the open request is for a DIFFERENT plan than the webhook context
    state.request = openRequest({ planId: 'plan-other' });
    await expect((svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: true,
      amount_cents: 45000,
      id: 'tx-g1b',
      pending: false,
      order: { id: 987654, merchant_order_id: openRequest().providerRef },
    })).rejects.toBeInstanceOf(BadRequestException);
    expect(members.applyPaidRenewal).not.toHaveBeenCalled();
  });

  it('PHASE H3: a PENDING webhook is ignored WITHOUT claiming the transaction id', async () => {
    const { svc, prisma, members, state } = makeService();
    state.request = openRequest();

    const res = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: false,
      pending: true, // Paymob sends pending first for wallet/cash methods
      amount_cents: 45000,
      id: 'tx-h3-pending',
      order: { id: 987654, merchant_order_id: openRequest().providerRef },
    });

    expect(res.ignored).toBe(true);
    expect(prisma.paymentAttempt.create).not.toHaveBeenCalled(); // NOT claimed
    expect(members.applyPaidRenewal).not.toHaveBeenCalled();
  });

  it('PHASE H3: pending then success for the same transaction id applies EXACTLY once', async () => {
    const { svc, members, state } = makeService();
    state.request = openRequest();
    const order = { id: 987654, merchant_order_id: openRequest().providerRef };

    const pendingRes = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: false, pending: true, amount_cents: 45000, id: 'tx-h3', order,
    });
    expect(pendingRes.ignored).toBe(true);

    const successRes = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: true, pending: false, amount_cents: 45000, id: 'tx-h3', order,
    });
    expect(successRes.applied).toBe(true);
    expect(state.applied).toBe(1);
    expect(members.applyPaidRenewal).toHaveBeenCalledTimes(1);
  });

  it('PHASE H3: a final failure claims the id — a later replayed success is rejected', async () => {
    const { svc, members, state } = makeService();
    state.request = openRequest();
    const order = { id: 987654, merchant_order_id: openRequest().providerRef };

    const failed = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: false, error_occured: true, pending: false, amount_cents: 45000, id: 'tx-h3-fail', order,
    });
    expect(failed.applied).toBe(false);
    expect(state.attempts['paymob|tx-h3-fail'].status).toBe('FAILED');

    // the replayed success for the same (claimed) transaction id is rejected
    const replayed = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: true, pending: false, amount_cents: 45000, id: 'tx-h3-fail', order,
    });
    expect(replayed.duplicate).toBe(true);
    expect(members.applyPaidRenewal).not.toHaveBeenCalled();
    expect(state.applied).toBeUndefined();
  });

  it('PHASE H3: a duplicate success is a no-op (nothing applied twice)', async () => {
    const { svc, members, state } = makeService();
    state.request = openRequest();
    const obj = {
      success: true, pending: false, amount_cents: 45000, id: 'tx-h3-dup',
      order: { id: 987654, merchant_order_id: openRequest().providerRef },
    };

    const first = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, obj);
    const second = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, obj);

    expect(first.applied).toBe(true);
    expect(second.duplicate).toBe(true);
    expect(state.applied).toBe(1);
    expect(members.applyPaidRenewal).toHaveBeenCalledTimes(1);
  });

  it('PHASE I2 — FAIL CLOSED: a request without a checkout (PENDING, no providerOrderId) → 400, nothing applied', async () => {
    const { svc, members, state } = makeService();
    // a request created through the portal (no checkout) — webhook-renewal
    // must be refused outright
    state.request = openRequest({ status: 'PENDING', providerOrderId: null, providerRef: null });

    await expect((svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: true, pending: false, amount_cents: 45000, id: 'tx-i2-a',
      order: { id: 987654, merchant_order_id: openRequest().providerRef },
    })).rejects.toMatchObject({ message: 'No checkout-bound renewal request for this payment' });
    expect(members.applyPaidRenewal).not.toHaveBeenCalled();
    expect(state.applied).toBeUndefined();
  });

  it('PHASE I2 — FAIL CLOSED: a CHECKOUT request with a NULL providerOrderId → 400, nothing applied', async () => {
    const { svc, members, state } = makeService();
    state.request = openRequest({ status: 'CHECKOUT', providerOrderId: null });

    await expect((svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: true, pending: false, amount_cents: 45000, id: 'tx-i2-b',
      order: { id: 987654, merchant_order_id: openRequest().providerRef },
    })).rejects.toMatchObject({ message: 'No checkout-bound renewal request for this payment' });
    expect(members.applyPaidRenewal).not.toHaveBeenCalled();
  });

  it('PHASE I2 — a CHECKOUT-bound request with a matching signed order id → applied', async () => {
    const { svc, members, state } = makeService();
    state.request = openRequest({ status: 'CHECKOUT', providerOrderId: '987654' });

    const res = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: true, pending: false, amount_cents: 45000, id: 'tx-i2-c',
      order: { id: 987654, merchant_order_id: openRequest().providerRef },
    });
    expect(res.applied).toBe(true);
    expect(members.applyPaidRenewal).toHaveBeenCalledTimes(1);
    expect(state.applied).toBe(1);
  });

  it('PHASE H4: the claim is bound to the SIGNED order id — a mismatched signed order is rejected', async () => {
    const { svc, members, state } = makeService();
    state.request = openRequest({ providerOrderId: '987654' });

    // the signed order.id does not match the request's stored providerOrderId
    await expect((svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: true, pending: false, amount_cents: 45000, id: 'tx-h4',
      order: { id: 111111, merchant_order_id: openRequest().providerRef },
    })).rejects.toBeInstanceOf(BadRequestException);
    expect(members.applyPaidRenewal).not.toHaveBeenCalled();
  });

  it('PHASE H4: a replayed signed webhook with a TAMPERED merchant_order_id (different gym/member) applies nothing', async () => {
    const { svc, members, state } = makeService();
    state.request = openRequest();
    const order = { id: 987654, merchant_order_id: openRequest().providerRef };

    // the legitimate delivery claims the transaction id (platform-wide)
    const legit = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: true, pending: false, amount_cents: 45000, id: 'tx-h4-tamper', order,
    });
    expect(legit.applied).toBe(true);

    // the attacker replays the SAME signed payload but tampers the (unsigned)
    // merchant_order_id to point at a different gym/member — the HMAC stays valid
    // because merchant_order_id is not covered. The platform-wide claim rejects it.
    const tampered = await (svc as any).handleRenewalWebhook('gym-attacker', 'member-attacker', PLAN.id, {
      success: true, pending: false, amount_cents: 45000, id: 'tx-h4-tamper',
      order: { id: 987654, merchant_order_id: `RENEWAL::gym-attacker::member-attacker::${PLAN.id}::999` },
    });
    expect(tampered.duplicate).toBe(true);
    expect(state.applied).toBe(1); // still exactly one extension
    expect(members.applyPaidRenewal).toHaveBeenCalledTimes(1);
  });

  it('a failed transaction marks the attempt FAILED and extends nothing', async () => {
    const { svc, members, state, prisma } = makeService();
    state.request = openRequest();

    const res = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: false,
      amount_cents: 45000,
      id: 'tx-4',
      pending: false,
      order: { id: 987654, merchant_order_id: openRequest().providerRef },
    });

    expect(res.applied).toBe(false);
    expect(prisma.paymentAttempt.updateMany).toHaveBeenCalledWith(expect.objectContaining({
      data: expect.objectContaining({ status: 'FAILED' }),
    }));
    expect(members.applyPaidRenewal).not.toHaveBeenCalled();
  });

  it('PHASE J1 — a REJECTED delivery does NOT consume the transaction id: the corrected re-delivery still applies', async () => {
    const { svc, members, state } = makeService();
    const order = { id: 987654, merchant_order_id: openRequest().providerRef };

    // 1st delivery: no checkout-bound request (the member never opened a
    // checkout) → rejected. The claim must be ROLLED BACK with it — before J1
    // it stayed PENDING forever and this transaction id could never apply.
    state.request = openRequest({ status: 'PENDING', providerOrderId: null, providerRef: null });
    await expect((svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: true, pending: false, amount_cents: 45000, id: 'tx-j1-a', order,
    })).rejects.toBeInstanceOf(BadRequestException);
    expect(state.attempts?.['paymob|tx-j1-a']).toBeUndefined(); // claim rolled back
    expect(members.applyPaidRenewal).not.toHaveBeenCalled();

    // the state is corrected (the checkout is opened) and Paymob re-delivers
    // the SAME transaction id → it applies, exactly once
    state.request = openRequest();
    const second = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: true, pending: false, amount_cents: 45000, id: 'tx-j1-a', order,
    });
    expect(second.applied).toBe(true);
    expect(state.applied).toBe(1);
    expect(members.applyPaidRenewal).toHaveBeenCalledTimes(1);
    expect(state.attempts['paymob|tx-j1-a'].status).toBe('SUCCESS');
  });

  it('PHASE J1 — an AMOUNT MISMATCH rolls the claim back: the corrected delivery applies', async () => {
    const { svc, members, state } = makeService();
    const order = { id: 987654, merchant_order_id: openRequest().providerRef };
    state.request = openRequest();

    await expect((svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: true, pending: false, amount_cents: 10000, id: 'tx-j1-b', order, // 100 EGP ≠ 450
    })).rejects.toBeInstanceOf(BadRequestException);
    expect(state.attempts?.['paymob|tx-j1-b']).toBeUndefined(); // NOT consumed
    expect(state.request.status).toBe('CHECKOUT');

    // the provider re-delivers the same transaction with the correct amount
    const res = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: true, pending: false, amount_cents: 45000, id: 'tx-j1-b', order,
    });
    expect(res.applied).toBe(true);
    expect(state.applied).toBe(1);
  });

  it('PHASE J1 — a tampered merchant_order_id replay for ANOTHER gym leaves the transaction id free for the legitimate delivery', async () => {
    const { svc, members, state } = makeService();
    state.request = openRequest(); // the LEGITIMATE gym's checkout-bound request

    // the attacker delivers the signed payload first, with the (unsigned)
    // merchant_order_id re-pointed at their own gym/member → rejected, and the
    // id is NOT consumed, so it cannot poison the real payment
    await expect((svc as any).handleRenewalWebhook('gym-attacker', 'member-attacker', PLAN.id, {
      success: true, pending: false, amount_cents: 45000, id: 'tx-j1-tamper',
      order: { id: 987654, merchant_order_id: `RENEWAL::gym-attacker::member-attacker::${PLAN.id}::999` },
    })).rejects.toBeInstanceOf(BadRequestException);
    expect(state.attempts?.['paymob|tx-j1-tamper']).toBeUndefined();
    expect(members.applyPaidRenewal).not.toHaveBeenCalled();

    // the legitimate delivery then applies it
    const legit = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: true, pending: false, amount_cents: 45000, id: 'tx-j1-tamper',
      order: { id: 987654, merchant_order_id: openRequest().providerRef },
    });
    expect(legit.applied).toBe(true);
    expect(state.applied).toBe(1);
    expect(members.applyPaidRenewal).toHaveBeenCalledTimes(1);
  });

  it('PHASE J1 — a concurrent UNIQUE VIOLATION on the claim answers duplicate, never a 500', async () => {
    const { svc, prisma, members, state } = makeService();
    state.request = openRequest();
    // a competing delivery committed the claim between our read and our insert
    state.attempts = { 'paymob|tx-j1-race': { status: 'PENDING', providerTransactionId: 'tx-j1-race' } };
    prisma.paymentAttempt.findFirst.mockImplementationOnce(async () => null);

    const res = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: true, pending: false, amount_cents: 45000, id: 'tx-j1-race',
      order: { id: 987654, merchant_order_id: openRequest().providerRef },
    });
    expect(res.duplicate).toBe(true);
    expect(res.applied).toBeUndefined();
    expect(members.applyPaidRenewal).not.toHaveBeenCalled();
    expect(state.applied).toBeUndefined();
  });

  it('PHASE J1 — a serialization/write conflict is retried: the delivery still applies, never a 500', async () => {
    const { svc, prisma, members, state } = makeService();
    state.request = openRequest();
    const conflict: any = new Error('Transaction failed due to a write conflict or a dead lock. Please retry your transaction.');
    conflict.code = 'P2034';
    prisma.paymentAttempt.create.mockImplementationOnce(async () => { throw conflict; });

    const res = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: true, pending: false, amount_cents: 45000, id: 'tx-j1-serial',
      order: { id: 987654, merchant_order_id: openRequest().providerRef },
    });
    expect(res.applied).toBe(true);
    expect(prisma.paymentAttempt.create).toHaveBeenCalledTimes(2); // 1 rolled back + 1 committed
    expect(state.applied).toBe(1);
    expect(members.applyPaidRenewal).toHaveBeenCalledTimes(1);
  });

  it('PHASE J1 — exhausting the retries answers duplicate (2xx) instead of surfacing a 500', async () => {
    const { svc, prisma, members, state } = makeService();
    state.request = openRequest();
    const conflict: any = new Error('could not serialize access due to concurrent update');
    conflict.code = 'P2034';
    prisma.paymentAttempt.create.mockImplementation(async () => { throw conflict; });

    const res = await (svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: true, pending: false, amount_cents: 45000, id: 'tx-j1-exhaust',
      order: { id: 987654, merchant_order_id: openRequest().providerRef },
    });
    expect(res.duplicate).toBe(true);
    expect(prisma.paymentAttempt.create).toHaveBeenCalledTimes(3); // MAX_ATTEMPTS
    expect(members.applyPaidRenewal).not.toHaveBeenCalled();
    expect(state.applied).toBeUndefined();
  });

  it('PHASE J1 — a real error (not a claim conflict) still propagates', async () => {
    const { svc, prisma } = makeService();
    const boom: any = new Error('connection reset');
    prisma.paymentAttempt.findFirst.mockImplementation(async () => { throw boom; });
    await expect((svc as any).handleRenewalWebhook(GYM, MEMBER, PLAN.id, {
      success: true, pending: false, amount_cents: 45000, id: 'tx-j1-real',
      order: { id: 987654, merchant_order_id: openRequest().providerRef },
    })).rejects.toBe(boom);
  });
});

describe('ROUND 14 PHASE F1 — applyPaidRenewal binds the amount to the plan price', () => {
  it('rejects a paid amount that does not match the plan price', async () => {
    const { MembersService } = require('../members/members.service');
    const prisma: any = {
      plan: { findFirst: jest.fn().mockResolvedValue(PLAN) },
      member: { findFirst: jest.fn().mockResolvedValue({ id: MEMBER, gymId: GYM, expiry: null, sessionsLeft: null }) },
      $transaction: jest.fn(async (fn: any) => fn(prisma)),
    };
    const svc = new MembersService(prisma, {} as any, {} as any, {} as any, {} as any);
    await expect(svc.applyPaidRenewal(GYM, MEMBER, PLAN.id, { amount: 100 })).rejects.toBeInstanceOf(BadRequestException);
    expect(prisma.member.update).toBeUndefined(); // never reached
  });
});
