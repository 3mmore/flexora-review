/**
 * ROUND 14 (security review, PHASE J2) — a manual MEMBERSHIP payment must be
 * bound to a member.
 *
 * Before J2 a front-desk payment could be recorded with no member at all
 * (`memberId` was optional). Such a row was a MANUAL_MEMBERSHIP payment that
 * belonged to NOBODY, and the legacy "bind a NULL-memberId payment to the first
 * member that uses it" rule let whoever asked first claim it as their proof of
 * payment. From J2 on:
 *   - `POST /payments/manual` REQUIRES a memberId (400 without one),
 *   - the member must belong to the caller's gym,
 *   - the payment is stored with purpose MANUAL_MEMBERSHIP and that memberId,
 *   - the legacy NULL binding survives ONLY for rows that predate the
 *     Phase-I migration (it is no longer reachable for new rows).
 */
import { BadRequestException } from '@nestjs/common';
import * as fs from 'fs';
import * as path from 'path';
import { BillingService } from './billing.service';

const GYM = 'gym-a';
const MEMBER = 'member-1';
const FOREIGN = 'member-of-another-gym';
const USER = 'user-front-desk';

function build() {
  const written: Record<string, any> = {};
  const prisma: any = {
    member: {
      // only MEMBER exists in GYM; FOREIGN belongs to another tenant
      findFirst: jest.fn(async ({ where }: any) =>
        where.id === MEMBER && where.gymId === GYM ? { id: MEMBER, gymId: GYM, name: 'Test Member' } : null,
      ),
    },
    invoice: { create: jest.fn(async ({ data }: any) => ({ id: 'inv-1', ...data })) },
    payment: {
      create: jest.fn(async ({ data }: any) => { written.payment = { id: 'pay-1', ...data }; return written.payment; }),
      findFirst: jest.fn(async () => written.payment ?? null),
    },
    receipt: { create: jest.fn(async ({ data }: any) => ({ id: 'rcpt-1', ...data })) },
    transaction: { create: jest.fn(async ({ data }: any) => ({ id: 'txn-1', ...data })) },
    auditLog: { create: jest.fn(async () => ({})) },
    financialReconciliation: { upsert: jest.fn(async () => ({})), findUnique: jest.fn(async () => null) },
    $transaction: jest.fn(async (fn: any) => fn(prisma)),
  };
  const svc = new BillingService(
    prisma,
    { whatsapp: jest.fn() } as any,
    { acquireLock: jest.fn(), releaseLock: jest.fn() } as any,
    { encryptDeterministic: (v: string) => v } as any,
  );
  return { svc, prisma, written };
}

describe('ROUND 14 PHASE J2 — a manual membership payment is bound to a member', () => {
  it('recording a manual membership payment WITHOUT a member is rejected (400)', async () => {
    const { svc, prisma } = build();
    await expect(
      svc.createManualPayment(GYM, USER, { amount: 450, method: 'CASH' }),
    ).rejects.toMatchObject({ message: 'A member is required for a manual membership payment' });
    expect(prisma.payment.create).not.toHaveBeenCalled();
  });

  it('an EMPTY-STRING memberId is rejected too (not silently stored as NULL)', async () => {
    const { svc, prisma } = build();
    await expect(
      svc.createManualPayment(GYM, USER, { amount: 450, method: 'CASH', memberId: '   ' }),
    ).rejects.toBeInstanceOf(BadRequestException);
    expect(prisma.payment.create).not.toHaveBeenCalled();
  });

  it('a member that does not belong to this gym is rejected (no cross-tenant binding)', async () => {
    const { svc, prisma } = build();
    await expect(
      svc.createManualPayment(GYM, USER, { amount: 450, method: 'CASH', memberId: FOREIGN }),
    ).rejects.toMatchObject({ message: 'Member not found for this gym' });
    expect(prisma.payment.create).not.toHaveBeenCalled();
  });

  it('a valid memberId records a MANUAL_MEMBERSHIP payment bound to that member', async () => {
    const { svc, written } = build();
    const res = await svc.createManualPayment(GYM, USER, { amount: 450, method: 'CASH', memberId: MEMBER });
    expect(written.payment).toBeTruthy();
    expect(written.payment.purpose).toBe('MANUAL_MEMBERSHIP');
    expect(written.payment.memberId).toBe(MEMBER); // NEVER null — this is the J2 invariant
    expect(written.payment.gymId).toBe(GYM);
    expect(res.payment.memberId).toBe(MEMBER);
  });

  it('the DTO declares memberId as REQUIRED (no @IsOptional) and never sends NULL', () => {
    const src = fs.readFileSync(path.join(__dirname, 'billing.controller.ts'), 'utf8');
    const dto = src.slice(src.indexOf('class ManualPaymentDto'), src.indexOf('@ApiTags'));
    expect(dto).toMatch(/@IsString\(\)\s+memberId!:\s*string;/);
    // the memberId line itself must not be optional
    const memberLine = dto.split('\n').find((l) => l.includes('memberId!:')) || '';
    expect(memberLine).not.toContain('@IsOptional');
  });

  it('the service never writes a NULL memberId for a new manual payment (source guard)', () => {
    const src = fs.readFileSync(path.join(__dirname, 'billing.service.ts'), 'utf8');
    const body = src.slice(src.indexOf('async createManualPayment'), src.indexOf('async reconcilePayment'));
    // the old `memberId: dto.memberId || null` fall-back is gone
    expect(body).not.toContain('memberId: dto.memberId');
    expect(body).toContain("throw new BadRequestException('A member is required for a manual membership payment')");
  });
});
