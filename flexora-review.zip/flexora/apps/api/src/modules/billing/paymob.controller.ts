/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Headers, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';
import { PaymobService, Tier } from './paymob.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { Public } from '../../common/decorators/public.decorator';
import { Audit } from '../../common/decorators/audit.decorator';
import { IsIn } from 'class-validator';

class CheckoutDto {
  @IsIn(['BASIC', 'PRO', 'ELITE']) tier!: Tier;
}

@ApiTags('paymob')
@Controller('paymob')
export class PaymobController {
  constructor(private readonly svc: PaymobService) {}

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
  @Post('checkout')
  @Roles('OWNER')
  @Audit('paymob_checkout', 'Subscription')
  checkout(@GymId() gymId: string, @Body() dto: CheckoutDto) {
    return this.svc.createCheckout(gymId, dto.tier);
  }

  // Paymob posts the HMAC as a query param `hmac` and the txn in the body.
  @Public()
  @Throttle({ default: { limit: 120, ttl: 60000 } })
  @Post('webhook')
  webhook(@Query('hmac') hmac: string, @Body() body: Record<string, any>) {
    return this.svc.handleWebhook(hmac, body);
  }
}
