/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { UsersService } from './users.service';
import { AssignBranchDto, CreateUserDto, UpdateSelfProfileDto, UpdateUserDto } from './dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { TenantGuard } from '../../common/guards/tenant.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Permissions } from '../../common/decorators/permissions.decorator';
import { GymId } from '../../common/decorators/gym-id.decorator';
import { CurrentUser } from '../../common/decorators/current-user.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

@ApiTags('users')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, TenantGuard, RolesGuard)
@Controller('users')
export class UsersController {
  constructor(private readonly svc: UsersService) {}
  @Get() @Permissions('staff.manage') list(@GymId() g: string) { return this.svc.list(g); }
  // ROUND 13 (security review, PHASE A): every staff-management mutation gets
  // the acting user — the service enforces the role RANK rules with it (nobody
  // creates an OWNER, only an OWNER creates a MANAGER, a MANAGER can never
  // touch an OWNER or another MANAGER, nobody deactivates/deletes the OWNER
  // or themselves, nobody changes their own role).
  @Post() @Permissions('staff.manage') @Audit('create','User') create(@GymId() g: string, @Body() d: CreateUserDto, @CurrentUser() actor: any) { return this.svc.create(g, d, actor); }
  /**
   * ROUND 14 (security review, PHASE A): self-service profile endpoint — any
   * staff user (including the OWNER, whose account is otherwise untouchable
   * through staff management) edits their OWN name/phone/password here.
   * Declared BEFORE the :id patch route so the literal 'me' is not captured
   * as an id parameter.
   */
  @Patch('me')
  @Permissions('profile.self')
  @Audit('update', 'User')
  updateSelf(@GymId() g: string, @CurrentUser() actor: any, @Body() d: UpdateSelfProfileDto) {
    return this.svc.updateSelf(g, actor.id, d);
  }

  @Patch(':id') @Permissions('staff.manage') @Audit('update','User') update(@GymId() g: string, @Param('id') id: string, @Body() d: UpdateUserDto, @CurrentUser() actor: any) { return this.svc.update(g, id, d, actor); }
  @Patch(':id/branch') @Permissions('staff.manage') @Audit('assign-branch','User') assignBranch(@GymId() g: string, @Param('id') id: string, @Body() d: AssignBranchDto, @CurrentUser() actor: any) { return this.svc.assignBranch(g, id, d.branchId ?? null, actor); }
  @Patch(':id/toggle') @Permissions('staff.manage') @Audit('toggle','User') toggle(@GymId() g: string, @Param('id') id: string, @CurrentUser() actor: any) { return this.svc.toggle(g, id, actor); }
  @Delete(':id') @Permissions('staff.manage') @Audit('delete','User') remove(@GymId() g: string, @Param('id') id: string, @CurrentUser() actor: any) { return this.svc.remove(g, id, actor); }
}
