/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { PrismaModule } from '../../config/prisma.module';
import { RedisModule } from '../../config/redis.module';
import { UsersService } from './users.service';
import { UsersController } from './users.controller';
@Module({ imports: [JwtModule.register({}), PrismaModule, RedisModule], controllers: [UsersController], providers: [UsersService] })
export class UsersModule {}
