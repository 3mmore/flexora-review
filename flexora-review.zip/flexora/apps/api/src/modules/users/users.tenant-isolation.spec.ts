/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Regression guard for the round-2 review findings:
 *
 *  1. UsersService.create() must validate branchId is tenant-scoped, exactly as
 *     update() and assignBranch() do. Without it, a gym owner could attach a new
 *     employee to a branch belonging to a DIFFERENT gym.
 *  2. Staff phone validation must use the shared EG_PHONE rule.
 */
import { BadRequestException } from '@nestjs/common';
import { validate } from 'class-validator';
import { plainToInstance } from 'class-transformer';
import { UsersService } from './users.service';
import { CreateUserDto } from './dto';
import { EG_PHONE } from '../../common/validators/phone';

describe('UsersService tenant isolation (create)', () => {
  const GYM = 'gym-a';
  const FOREIGN_BRANCH = 'branch-of-gym-b';

  function build(branchFindFirst: jest.Mock) {
    const prisma: any = {
      branch: { findFirst: branchFindFirst },
      license: { findUnique: jest.fn().mockResolvedValue(null) },
      subscription: { findUnique: jest.fn().mockResolvedValue({ tier: 'ELITE' }) },
      user: { count: jest.fn().mockResolvedValue(0), create: jest.fn() },
    };
    return { svc: new UsersService(prisma), prisma };
  }

  const dto = (branchId: string): any => ({
    name: 'Some Staff Person',
    email: 'staff@example.com',
    password: 'Str0ng!Passw0rd',
    role: 'COACH',
    branchId,
  });

  it('rejects a branchId that belongs to another gym', async () => {
    // findFirst is called with { id, gymId } — a foreign branch yields null.
    const findFirst = jest.fn().mockResolvedValue(null);
    const { svc, prisma } = build(findFirst);

    // ROUND 13 (PHASE A): create() now takes the acting user and enforces the
    // rank rules — an OWNER actor creating a COACH is the allowed baseline.
    const OWNER = { id: 'owner-1', role: 'OWNER' };
    await expect(svc.create(GYM, dto(FOREIGN_BRANCH), OWNER)).rejects.toBeInstanceOf(BadRequestException);

    expect(findFirst).toHaveBeenCalledWith({ where: { id: FOREIGN_BRANCH, gymId: GYM } });
    // Critically: no user row may be written.
    expect(prisma.user.create).not.toHaveBeenCalled();
  });

  it('accepts a branchId owned by the caller gym', async () => {
    const findFirst = jest.fn().mockResolvedValue({ id: 'branch-a', gymId: GYM });
    const { svc, prisma } = build(findFirst);
    prisma.user.create.mockResolvedValue({ id: 'u1', branchId: 'branch-a' });

    await svc.create(GYM, dto('branch-a'), { id: 'owner-1', role: 'OWNER' });

    expect(findFirst).toHaveBeenCalledWith({ where: { id: 'branch-a', gymId: GYM } });
    expect(prisma.user.create).toHaveBeenCalled();
  });
});

describe('Staff phone uses the shared EG_PHONE rule', () => {
  const base = {
    name: 'Some Staff Person',
    email: 'staff@example.com',
    password: 'Str0ng!Passw0rd',
    role: 'COACH',
  };

  const phoneErrors = async (phone: string) => {
    const dto = plainToInstance(CreateUserDto, { ...base, phone });
    const errors = await validate(dto);
    return errors.filter((e) => e.property === 'phone');
  };

  it.each(['01012345678', '01112345678', '01212345678', '01512345678'])(
    'accepts valid Egyptian mobile %s',
    async (phone) => {
      expect(await phoneErrors(phone)).toHaveLength(0);
      expect(EG_PHONE.test(phone)).toBe(true);
    },
  );

  it.each([
    '+1 (555) 123-4567', // accepted by the old loose pattern
    '1234567',           // accepted by the old loose pattern
    '0201234567',        // wrong prefix
    '01312345678',       // 013 is not a valid EG prefix
    '0101234567',        // 10 digits
  ])('rejects %s', async (phone) => {
    expect(await phoneErrors(phone)).not.toHaveLength(0);
  });
});
