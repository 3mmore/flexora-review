/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { IsBoolean, IsEmail, IsEnum, IsOptional, IsString, Matches, MinLength } from 'class-validator';
import { PasswordStrength } from '../../common/decorators/password-strength.decorator';
import { EG_PHONE, EG_PHONE_MESSAGE } from '../../common/validators/phone';
import { Role } from '@prisma/client';

// Mirrors members/dto.ts — TODO: extract to a shared validators file so every
// module with a name field enforces the same 3-part-name rule consistently.
const THREE_PART_NAME = /^\S+\s+\S+\s+\S+.*$/;

export class CreateUserDto {
  @IsString() @Matches(THREE_PART_NAME, { message: 'Name must contain at least 3 parts (First Middle Last)' }) name!: string;
  @IsEmail() email!: string;
  @IsString() @MinLength(8) @PasswordStrength() password!: string;
  @IsEnum(Role) role!: Role;
  // Phase 4: discrete labeled staff fields — phone is its own validated field.
  // Uses the shared EG_PHONE rule (same as members/invitations/leads) so staff
  // phone numbers are validated identically to every other phone in the system.
  @IsOptional() @IsString() @Matches(EG_PHONE, { message: EG_PHONE_MESSAGE }) phone?: string;
  @IsOptional() @IsString() branchId?: string;
}
export class UpdateUserDto {
  @IsOptional() @Matches(THREE_PART_NAME, { message: 'Name must contain at least 3 parts (First Middle Last)' }) name?: string;
  @IsOptional() @IsEmail() email?: string;
  @IsOptional() @IsEnum(Role) role?: Role;
  @IsOptional() @IsString() @Matches(EG_PHONE, { message: EG_PHONE_MESSAGE }) phone?: string;
  @IsOptional() @IsString() branchId?: string;
  @IsOptional() @IsBoolean() active?: boolean;
  @IsOptional() @IsString() @MinLength(8) @PasswordStrength() password?: string;
}

/**
 * ROUND 14 (security review, PHASE A): self-service profile payload — the
 * actor's OWN name/phone/password only (PATCH /users/me). A password change
 * requires `currentPassword` (verified against the stored hash, same rule as
 * POST /auth/change-password). No role/email/branch/active fields exist here
 * on purpose: those are staff-management operations, not self-service.
 */
export class UpdateSelfProfileDto {
  @IsOptional() @Matches(THREE_PART_NAME, { message: 'Name must contain at least 3 parts (First Middle Last)' }) name?: string;
  @IsOptional() @IsString() @Matches(EG_PHONE, { message: EG_PHONE_MESSAGE }) phone?: string;
  @IsOptional() @IsString() @MinLength(8) @PasswordStrength() password?: string;
  @IsOptional() @IsString() currentPassword?: string;
}

/**
 * Phase 4 (4.4): dedicated staff-to-branch assignment payload. `branchId: null`
 * means "all branches" (no specific branch).
 */
export class AssignBranchDto {
  @IsOptional() @IsString() branchId?: string | null;
}
