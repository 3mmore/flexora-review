/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { IsInt, IsNumber, IsOptional, IsString, Min } from 'class-validator';
export class CreateProductDto {
  @IsString() name!: string;
  @IsOptional() @IsString() nameAr?: string;
  @IsOptional() @IsString() category?: string;
  @IsOptional() @IsString() icon?: string;
  @IsOptional() @IsString() barcode?: string;
  @IsNumber() @Min(0) price!: number;
  @IsOptional() @IsNumber() @Min(0) cost?: number;
  @IsOptional() @IsInt() @Min(0) qty?: number;
  @IsOptional() @IsInt() @Min(0) lowAlert?: number;
  @IsOptional() @IsString() supplier?: string;
  /// PHASE 8 — branch the product belongs to. Gym owners/managers send it from
  /// the create/edit form; an empty string clears the assignment. Restricted
  /// roles never get to choose: TenantGuard rejects a foreign branch and the
  /// Prisma scope pins their own branch on write.
  @IsOptional() @IsString() branchId?: string;
}
export class UpdateProductDto extends CreateProductDto {}
