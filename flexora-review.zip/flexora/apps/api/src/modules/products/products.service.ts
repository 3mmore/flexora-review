/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 */
import { BadRequestException, Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';
import { RealtimeGateway } from '../realtime/realtime.gateway';
import { CreateProductDto, UpdateProductDto } from './dto';
@Injectable()
export class ProductsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly realtime: RealtimeGateway,
  ) {}
  /**
   * Phase 6.2 (POS shows 0/blank price) — ROOT CAUSE.
   * The Product table stores `sellingPrice` / `costPrice` / `lowStockThreshold`,
   * and this endpoint returned those raw column names. But the POS terminal and
   * the inventory screen read `price` / `cost` / `lowAlert` (the same names the
   * CREATE dto accepts), so `product.price` was `undefined` — every product
   * added to a sale rendered 0 / blank even though a real price was entered at
   * creation. The write side and the read side simply used different names.
   *
   * Every product read now goes through this one mapper, which returns BOTH the
   * raw column names (used by /products management page) and the dto-shaped
   * aliases (used by POS + inventory), so the two can never drift again.
   */
  private toDto<T extends { sellingPrice: unknown; costPrice: unknown; lowStockThreshold: number }>(p: T) {
    return {
      ...p,
      price: Number(p.sellingPrice ?? 0),
      cost: Number(p.costPrice ?? 0),
      lowAlert: p.lowStockThreshold,
    };
  }

  /**
   * PHASE 8 — a product's branch must be a branch OF THIS GYM.
   * Without this check an owner could POST any branch id from another tenant
   * and the row would point outside the gym (the FK alone does not know about
   * tenancy). Returns `undefined` when the caller did not mention the field at
   * all, so PATCH keeps the current value.
   */
  private async resolveBranch(gymId: string, branchId: string | undefined | null) {
    if (branchId === undefined) return undefined;
    const value = String(branchId).trim();
    if (!value) return null; // explicit clear -> "not assigned"
    const branch = await this.prisma.branch.findFirst({ where: { id: value, gymId }, select: { id: true } });
    if (!branch) throw new BadRequestException('Invalid branch');
    return branch.id;
  }

  async list(gymId: string, q?: string, category?: string) {
    const where: Prisma.ProductWhereInput = { gymId };
    if (q) where.OR = [{ name: { contains: q, mode: 'insensitive' } }, { barcode: { contains: q } }];
    if (category && category !== 'all') where.category = category;
    const rows = await this.prisma.product.findMany({ where, orderBy: { name: 'asc' }, take: 100 });
    /**
     * P4-3: every inventory item shows the branch its stock lives at.
     * Products are gym-wide; the branch fact is carried by stock movements
     * (receipts are recorded with the receiving branch). We take each
     * product's MOST RECENT movement's branch, in one pass — no N+1.
     */
    const movements = await this.prisma.stockMovement.findMany({
      where: { gymId, branchId: { not: null } },
      orderBy: { occurredAt: 'desc' },
      take: 500,
      select: { productId: true, branchId: true },
    });
    const branchIds = [...new Set(movements.map((m) => m.branchId as string))];
    const branches = branchIds.length
      ? await this.prisma.branch.findMany({ where: { id: { in: branchIds } }, select: { id: true, name: true } })
      : [];
    const branchName = new Map(branches.map((b) => [b.id, b.name]));
    // PHASE 8: the product's OWN branch field wins; the stock-movement branch
    // is only the fallback for rows created before the field existed.
    const assignedIds = [...new Set(rows.map((r) => (r as { branchId?: string | null }).branchId).filter((x): x is string => !!x))];
    if (assignedIds.length) {
      const assigned = await this.prisma.branch.findMany({ where: { id: { in: assignedIds } }, select: { id: true, name: true } });
      for (const b of assigned) branchName.set(b.id, b.name);
    }
    const branchByProduct = new Map<string, { id: string; name: string }>();
    for (const m of movements) {
      if (!branchByProduct.has(m.productId) && m.branchId) {
        branchByProduct.set(m.productId, { id: m.branchId, name: branchName.get(m.branchId) || '' });
      }
    }
    return rows.map((r) => {
      const own = (r as { branchId?: string | null }).branchId || null;
      const branch = own ? { id: own, name: branchName.get(own) || '' } : (branchByProduct.get(r.id) || null);
      return { ...this.toDto(r), branchId: own, branch, branchAssigned: !!own };
    });
  }
  async create(gymId: string, dto: CreateProductDto) {
    const branchId = await this.resolveBranch(gymId, dto.branchId);
    try {
      const created = await this.prisma.product.create({ 
        data: { 
          gymId, 
          branchId: branchId ?? null,
          name: dto.name, 
          category: dto.category, 
          barcode: dto.barcode, 
          sellingPrice: dto.price, 
          costPrice: dto.cost ?? 0, 
          qty: dto.qty ?? 0, 
          lowStockThreshold: dto.lowAlert ?? 5 
        } 
      });
      return this.toDto(created);
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new ConflictException({
          code: 'PRODUCT_ALREADY_EXISTS',
          translationKey: 'error_already_exists',
          message: 'A product with this barcode already exists.',
        });
      }
      throw error;
    }
  }
  async update(gymId: string, id: string, dto: UpdateProductDto) {
    const p = await this.prisma.product.findFirst({ where: { id, gymId } });
    if (!p) throw new NotFoundException('Product not found');
    // gymId-safe: id already tenant-scoped above
    const branchId = await this.resolveBranch(gymId, dto.branchId);
    const updated = await this.prisma.product.update({ where: { id }, data: { name: dto.name, category: dto.category, barcode: dto.barcode, branchId, sellingPrice: dto.price, costPrice: dto.cost ?? undefined, qty: dto.qty, lowStockThreshold: dto.lowAlert } });
    if (updated.qty <= updated.lowStockThreshold) {
      this.realtime.emitToGym(gymId, 'low_stock', { productName: updated.name, qty: updated.qty });
    }
    return this.toDto(updated);
  }
  async remove(gymId: string, id: string) {
    const p = await this.prisma.product.findFirst({ where: { id, gymId } });
    if (!p) throw new NotFoundException('Product not found');
    await this.prisma.product.deleteMany({ where: { id, gymId } });
    return { ok: true };
  }
  async stats(gymId: string, branchId?: string) {
    const products = (await this.prisma.product.findMany({
      where: { gymId, ...(branchId ? { OR: [{ branchId }, { stockMovements: { some: { branchId } } }] } : {}) },
      take: 50,
    })).map((p) => this.toDto(p));
    const inventoryValue = products.reduce((s, p) => s + Number(p.costPrice ?? 0) * p.qty, 0);
    const lowStock = products.filter((p) => p.qty <= p.lowStockThreshold);
    const best = await this.prisma.saleItem.groupBy({
      by: ['productId', 'name'],
      where: { sale: { gymId, ...(branchId ? { branchId } : {}) } },
      _sum: { qty: true },
      orderBy: { _sum: { qty: 'desc' } },
      take: 6,
    });
    return { inventoryValue, lowStock, bestSellers: best };
  }
}
