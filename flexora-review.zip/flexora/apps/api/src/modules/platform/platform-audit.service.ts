/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R3 — the single writer for the platform audit log.
 *
 * WHY ONE WRITER. Before R3 there were six places that created an audit row, and they
 * disagreed: the console helper recorded `ip`, the auth-side helpers recorded none, and
 * nothing anywhere recorded a user agent, a reason as a first-class field, whether the
 * action was authorised by a fresh TOTP step-up, or what the action changed. Measured in
 * work/r3-evidence/00-before.log (B4): of eight genuine rows, six had no IP at all.
 *
 * THE CHAIN IS NOT COMPUTED HERE. `seq`, `hash` and `prevHash` are NOT NULL in the
 * database and are assigned by the BEFORE INSERT trigger
 * "PlatformAuditLog_chain_assign", under a transaction-scoped advisory lock. That is
 * deliberate (owner decision A2.3): one hash implementation, in SQL, used by the
 * backfill, the trigger and the verifier, so there is no second implementation in
 * TypeScript that could canonicalise a field differently and silently fork the chain.
 * This service therefore must never set those three fields, and the Prisma model declares
 * them optional precisely so that they are omitted from the INSERT and the trigger fills
 * them.
 *
 * WHAT before/after MAY CONTAIN. Identifiers, statuses, tiers, dates and counts. Never a
 * person's name, email, phone number or national id, and never a credential. An audit row
 * legitimately names the ADMINISTRATOR who acted - that stays in `details`, where the R2
 * PII crawl already allows it - but the state transition itself carries no personal data.
 * The crawl walks beforeState and afterState and fails the run on anything member-shaped
 * or credential-shaped.
 */
import { Injectable, Logger } from '@nestjs/common';
import type { Prisma } from '@prisma/client';
import { PrismaService } from '../../config/prisma.service';

/**
 * A user agent is attacker-controlled free text. It is hashed into the chain, so an
 * unbounded value would let one request inflate every later verification. 512 characters
 * is far more than any real browser sends and the normaliser only ever reads the first
 * few tokens.
 */
export const AUDIT_USER_AGENT_MAX_LENGTH = 512;

/** The shape of a state transition recorded in beforeState/afterState. */
export type AuditState = Record<string, string | number | boolean | null | undefined>;

export interface PlatformAuditInput {
  /** The acting administrator's id, or 'system' / 'cli:...' for a non-session actor. */
  adminId: string;
  adminName: string;
  action: string;
  target?: string | null;
  /** Free-form context. May name the administrator; may not carry member PII. */
  details?: unknown;
  /** The human justification a mutation required. First-class as of R3 (R3.6). */
  reason?: string | null;
  ip?: string | null;
  userAgent?: string | null;
  /** Whether a fresh TOTP step-up authorised this action (R3.6). */
  stepUpUsed?: boolean;
  beforeState?: AuditState | null;
  afterState?: AuditState | null;
}

@Injectable()
export class PlatformAuditService {
  private readonly logger = new Logger('PlatformAudit');

  constructor(private readonly prisma: PrismaService) {}

  /**
   * Write one audit row. The database assigns the chain position and the hash.
   *
   * This does NOT catch its own errors. Whether a failed audit write may abort the
   * operation is the caller's decision and it differs by caller (R3.15): a privileged
   * console mutation must not succeed unaudited, so the controller lets this throw and
   * the mutation fails with it; an authentication event must not lock anybody out because
   * the audit insert failed, so the auth path catches, logs and raises an
   * AUDIT_WRITE_FAILED alert instead of swallowing it the way the pre-R3 code did.
   */
  async record(input: PlatformAuditInput) {
    return this.prisma.platformAuditLog.create({
      data: {
        adminId: input.adminId,
        adminName: input.adminName,
        action: input.action,
        target: input.target ?? null,
        details: (input.details ?? undefined) as object | undefined,
        reason: input.reason ?? null,
        ip: input.ip ?? null,
        userAgent: clampUserAgent(input.userAgent ?? null),
        stepUpUsed: input.stepUpUsed === true,
        beforeState: (input.beforeState ?? undefined) as object | undefined,
        afterState: (input.afterState ?? undefined) as object | undefined,
      },
    });
  }

  /**
   * PHASE R4 (R4.11) - the same write, on a caller's transaction client.
   *
   * The grant/extend routes have to hold a transaction open across "has this idempotency key
   * already been used?" and "write the ledger row", because the ledger IS the idempotency store
   * and a check outside the write's transaction is a race. Writing through the root client from
   * inside that transaction would use a different pooled connection, so the advisory lock the
   * caller took would not cover the insert. Hence a transaction-client variant.
   *
   * It sets exactly the same fields as record() and, like record(), never sets seq, hash or
   * prevHash - those belong to the database trigger, and a caller that supplied them would have
   * them overwritten anyway (r3-audit-chain.spec.ts test 3).
   */
  async recordInTransaction(tx: Prisma.TransactionClient, input: PlatformAuditInput) {
    return tx.platformAuditLog.create({
      data: {
        adminId: input.adminId,
        adminName: input.adminName,
        action: input.action,
        target: input.target ?? null,
        details: (input.details ?? undefined) as object | undefined,
        reason: input.reason ?? null,
        ip: input.ip ?? null,
        userAgent: clampUserAgent(input.userAgent ?? null),
        stepUpUsed: input.stepUpUsed === true,
        beforeState: (input.beforeState ?? undefined) as object | undefined,
        afterState: (input.afterState ?? undefined) as object | undefined,
      },
    });
  }

  /**
   * Same, but never throws: for the authentication path, where breaking a login because
   * the audit row could not be written would be a worse failure than the missing row.
   * The failure is logged AND handed to the caller's alert hook, so it is not silent.
   */
  async recordBestEffort(
    input: PlatformAuditInput,
    onAuditFailure?: (action: string, code: string) => void | Promise<void>,
  ) {
    try {
      return await this.record(input);
    } catch (error) {
      const code = classifyAuditWriteFailure(error);
      this.logger.error(`could not write platform audit row for ${input.action}: ${code}`);
      if (onAuditFailure) {
        try {
          await onAuditFailure(input.action, code);
        } catch (hookError) {
          this.logger.error(`the audit-failure hook itself failed: ${(hookError as Error).message}`);
        }
      }
      return null;
    }
  }
}

export function clampUserAgent(value: string | null): string | null {
  if (value === null || value === undefined) return null;
  const trimmed = String(value).trim();
  if (!trimmed) return null;
  return trimmed.length > AUDIT_USER_AGENT_MAX_LENGTH
    ? trimmed.slice(0, AUDIT_USER_AGENT_MAX_LENGTH)
    : trimmed;
}

/**
 * Turn a failure into a short code. Owner decision A3.1 forbids storing raw provider or
 * driver error text, because that text can contain a connection string; the same discipline
 * applies to the audit-failure alert, so only a code from this fixed vocabulary is kept.
 */
export function classifyAuditWriteFailure(error: unknown): string {
  const message = (error as Error)?.message ?? '';
  if (/append-only/i.test(message)) return 'audit_append_only_violation';
  if (/advisory lock|deadlock/i.test(message)) return 'audit_chain_contention';
  if (/unique constraint/i.test(message)) return 'audit_unique_violation';
  if (/ECONNREFUSED|Can't reach database|timed out/i.test(message)) return 'audit_database_unreachable';
  return 'audit_write_failed';
}
