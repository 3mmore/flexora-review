/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R3 — the platform alert outbox (owner decision A3).
 *
 * WHY AN OUTBOX. The existing platform alert path, notifications.whatsapp(null,
 * PLATFORM_OWNER_PHONE, ...), deliberately writes no database row when gymId is null,
 * because there is no gym to hang the tenant Notification row on. So before R3 a platform
 * alert left no trace: if the owner's phone was not configured, or Meta rejected the send,
 * the only record was a line in the api log. A3.4 asks for a VISIBLE warning, which needs
 * somewhere to be visible from.
 *
 * WHAT IS STORED (A3.1, and this is the whole list). Type, severity, target kind, an
 * optional target UUID, an optional audit chain position, channel, status, attempt count,
 * a maximum attempt count, an error CODE, a dedupe key and timestamps. Not stored: the
 * owner's phone number, any token, the rendered message body, or a provider's raw error
 * text. Raw error text can contain a connection string or a phone number, which is why
 * only a code from the fixed vocabulary at the bottom of this file is ever persisted.
 *
 * THE MESSAGE IS REBUILT AT SEND TIME, not stored. An alert references its audit row by
 * chain position (A3.7) and the renderer reads that row when it sends. That is what makes
 * a retry by the cron possible with no message in the table, and it means the alert list
 * cannot become a second copy of the audit log.
 *
 * NOTHING HERE MAY BREAK THE ACTION THAT RAISED IT (A3.3). raise() is fire-and-forget for
 * delivery: it inserts the row and kicks a background send with its own catch, so a slow
 * or failing channel cannot add latency to a login, a gym deletion or a subscription grant.
 * The cron picks up anything the kick did not finish.
 */
import { Injectable, Logger } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { PrismaService } from '../../config/prisma.service';
import { NotificationsService } from '../notifications/notifications.service';
import { CronLeadershipService } from '../../common/services/cron-leadership.service';
import { requestContext } from '../../common/middleware/request-id.middleware';
import { randomUUID } from 'node:crypto';

/** The fixed alert vocabulary. Adding a type means adding a renderer case and a test. */
export const PLATFORM_ALERT_TYPES = [
  'ADMIN_LOGIN_BURST',
  'ADMIN_NEW_DEVICE',
  'ADMIN_CREATED',
  'ADMIN_REMOVED',
  'SUBSCRIPTION_GRANTED',
  'GYM_DELETED',
  'AUDIT_WRITE_FAILED',
  'ALERT_SEND_FAILED',
] as const;
export type PlatformAlertType = (typeof PLATFORM_ALERT_TYPES)[number];

export type PlatformAlertSeverity = 'info' | 'warning' | 'danger';
export type PlatformAlertStatus = 'PENDING' | 'SENT' | 'FAILED' | 'NO_CHANNEL';

/**
 * A3.5: the same type for the same target inside one window collapses into one alert. The
 * window is folded into the unique dedupe key, so collapsing is a plain ON CONFLICT rather
 * than a read-then-write race. The known cost is a boundary effect: two events either side
 * of a window edge produce two alerts. That is accepted in exchange for never racing, and
 * it fails in the direction of telling the owner twice rather than not at all.
 */
export const ALERT_DEDUPE_WINDOW_MS = 15 * 60 * 1000;

/** A3.2: bounded retry. Five attempts, then FAILED and the cron stops touching it. */
export const ALERT_MAX_ATTEMPTS = 5;

/** Increasing backoff, indexed by the attempt that just failed. */
export const ALERT_BACKOFF_MS = [60_000, 120_000, 240_000, 480_000, 960_000] as const;

/**
 * A3.3: a send is bounded. The WhatsApp call has no timeout of its own, and an alert must
 * not be able to hold a request or a cron worker open.
 */
export const ALERT_SEND_TIMEOUT_MS = 8_000;

/** How many alerts one cron pass claims. Bounded so a backlog cannot starve the worker. */
export const ALERT_RETRY_BATCH = 20;

/**
 * A3.1: the only error values that may be persisted. A provider message is never stored.
 */
export const ALERT_ERROR_CODES = [
  'channel_not_configured',
  'channel_rejected',
  'channel_timeout',
  'channel_error',
  'render_failed',
] as const;
export type PlatformAlertErrorCode = (typeof ALERT_ERROR_CODES)[number];

export interface RaiseAlertInput {
  type: PlatformAlertType;
  severity?: PlatformAlertSeverity;
  targetKind: 'admin' | 'gym' | 'subscription' | 'audit' | 'platform';
  /** A UUID only. Never a name, email, phone number or national id. */
  targetId?: string | null;
  /** The audit row this alert is about, by chain position (A3.7). */
  auditSeq?: number | null;
}

export interface RaiseAlertResult {
  id: string;
  status: PlatformAlertStatus;
  deduped: boolean;
}

@Injectable()
export class PlatformAlertService {
  private readonly logger = new Logger('PlatformAlert');

  constructor(
    private readonly prisma: PrismaService,
    private readonly notifications: NotificationsService,
    private readonly cronLeadership: CronLeadershipService,
  ) {}

  // ─── channel state ────────────────────────────────────────────────────────

  /**
   * Read inside the method, never at module scope. The owner phone is the only thing that
   * decides whether the channel exists; the WhatsApp credentials are checked by the send
   * itself, because they are read by the messaging service.
   */
  ownerPhone(): string | null {
    const value = (process.env.PLATFORM_OWNER_PHONE ?? '').trim();
    return value ? value : null;
  }

  /**
   * What the console shows as the visible warning (A3.4). Reports WHICH variable is
   * missing by name only - never a value, and never whether a value is well formed beyond
   * being present.
   */
  channelState(): { configured: boolean; missing: string[] } {
    const missing: string[] = [];
    if (!this.ownerPhone()) missing.push('PLATFORM_OWNER_PHONE');
    if (!(process.env.WHATSAPP_PHONE_ID ?? '').trim()) missing.push('WHATSAPP_PHONE_ID');
    if (!(process.env.WHATSAPP_TOKEN ?? '').trim()) missing.push('WHATSAPP_TOKEN');
    return { configured: missing.length === 0, missing };
  }

  // ─── raising ──────────────────────────────────────────────────────────────

  /**
   * Record an alert. Never throws: an alert that cannot be recorded must not take the
   * action that triggered it down with it (A3.3).
   */
  async raise(input: RaiseAlertInput): Promise<RaiseAlertResult | null> {
    const now = new Date();
    const id = randomUUID();
    const bucket = Math.floor(now.getTime() / ALERT_DEDUPE_WINDOW_MS);
    const dedupeKey = [
      input.type,
      input.targetKind,
      input.targetId ?? '-',
      bucket,
    ].join('|');

    try {
      const inserted = await this.prisma.$queryRaw<Array<{ id: string }>>`
        INSERT INTO public."PlatformAlert"
          ("id", "type", "severity", "targetKind", "targetId", "auditSeq", "channel",
           "status", "attempts", "maxAttempts", "errorCode", "dedupeKey",
           "nextAttemptAt", "createdAt", "updatedAt")
        VALUES
          (${id}::text, ${input.type}::text, ${(input.severity ?? 'info')}::text,
           ${input.targetKind}::text, ${input.targetId ?? null}::text,
           ${input.auditSeq ?? null}::integer, 'WHATSAPP_OWNER'::text,
           'PENDING'::text, 0::integer, ${ALERT_MAX_ATTEMPTS}::integer, NULL::text,
           ${dedupeKey}::text, ${now}::timestamp(3), ${now}::timestamp(3),
           ${now}::timestamp(3))
        ON CONFLICT ("dedupeKey") DO NOTHING
        RETURNING "id"`;

      if (!inserted || inserted.length === 0) {
        const existing = await this.prisma.platformAlert.findUnique({
          where: { dedupeKey },
          select: { id: true, status: true },
        });
        return {
          id: existing?.id ?? dedupeKey,
          status: (existing?.status as PlatformAlertStatus) ?? 'SENT',
          deduped: true,
        };
      }

      // Fire and forget, with its own catch (A3.3): the caller's request must not wait on
      // the channel, and an unhandled rejection here would crash the process.
      void this.deliverSafely(id);

      return { id, status: 'PENDING', deduped: false };
    } catch (error) {
      this.logger.error(`could not record a ${input.type} alert: ${(error as Error).message}`);
      return null;
    }
  }

  private async deliverSafely(alertId: string): Promise<void> {
    try {
      await this.deliver(alertId);
    } catch (error) {
      this.logger.error(`background delivery failed: ${(error as Error).message}`);
    }
  }

  // ─── rendering ────────────────────────────────────────────────────────────

  /**
   * Build the message at send time from the alert and, when it has one, the audit row it
   * references (A3.7). The rendered text is never persisted.
   *
   * A3.14 constrains the content: no member PII, no credential, no phone number - not even
   * the owner's own, which is the recipient and does not need to be told it. The audit row
   * it reads is itself crawl-verified to carry no member PII, so composing from it is safe;
   * the tests assert the composed string, not just its inputs.
   */
  async render(alertId: string): Promise<string | null> {
    const alert = await this.prisma.platformAlert.findUnique({ where: { id: alertId } });
    if (!alert) return null;

    let action: string | null = null;
    let reason: string | null = null;
    let target: string | null = null;
    let seq: number | null = alert.auditSeq;

    if (alert.auditSeq !== null && alert.auditSeq !== undefined) {
      const row = await this.prisma.platformAuditLog.findUnique({
        where: { seq: alert.auditSeq },
        select: { action: true, reason: true, target: true, seq: true },
      });
      if (row) {
        action = row.action;
        reason = row.reason;
        target = row.target;
        seq = row.seq;
      }
    }

    const headline = HEADLINES[alert.type] ?? alert.type;
    const lines: string[] = [headline];
    if (action) lines.push(`action: ${action}`);
    if (seq !== null && seq !== undefined) lines.push(`audit seq: ${seq}`);
    if (target) lines.push(`target: ${target}`);
    if (reason) lines.push(`reason: ${reason}`);
    if (alert.targetKind) lines.push(`kind: ${alert.targetKind}`);
    lines.push(`ref: ${alert.id}`);
    lines.push('');
    lines.push('FLEXORA owner console');
    return lines.join('\n');
  }

  // ─── delivery ─────────────────────────────────────────────────────────────

  /**
   * One bounded send attempt for one alert. Returns the resulting status. Never throws.
   */
  async deliver(alertId: string): Promise<PlatformAlertStatus> {
    const alert = await this.prisma.platformAlert.findUnique({ where: { id: alertId } });
    if (!alert) return 'FAILED';
    if (alert.status === 'SENT') return 'SENT'; // a delivered alert is never re-sent (A3.2)

    // OWNER DECISION (R3.12, 2026-11-07): NO_CHANNEL must mean "this cannot be delivered
    // until an operator configures something", and that is true when ANY of the three
    // requirements is missing - not only the destination phone. This used to check ownerPhone()
    // alone, so with PLATFORM_OWNER_PHONE set and WHATSAPP_PHONE_ID / WHATSAPP_TOKEN unset the
    // send was attempted, failed with 'not-configured', and the alert went back to PENDING for
    // a bounded retry. That burned five attempts against a channel that could never work and
    // ended in FAILED, which reads as "we tried and the provider refused" - the wrong
    // diagnosis, and not what channelState() was already telling the console. Both now consult
    // the same three requirements, so the banner and the row cannot disagree.
    const channel = this.channelState();
    const phone = this.ownerPhone();
    if (!channel.configured || !phone) {
      // A3.4: recorded and shown in the console, not only logged. The log names VARIABLES,
      // never values.
      await this.mark(alertId, 'NO_CHANNEL', 'channel_not_configured', null);
      this.logger.warn(
        `alert ${alert.type} could not be delivered: missing ${channel.missing.join(', ')}`,
      );
      return 'NO_CHANNEL';
    }

    let body: string | null = null;
    try {
      body = await this.render(alertId);
    } catch (error) {
      this.logger.error(`could not render alert ${alert.type}: ${(error as Error).message}`);
    }
    if (!body) {
      await this.mark(alertId, 'FAILED', 'render_failed', null);
      return 'FAILED';
    }

    try {
      await withTimeout(
        this.notifications.whatsapp(null, phone, body),
        ALERT_SEND_TIMEOUT_MS,
        'timeout',
      );
      await this.mark(alertId, 'SENT', null, new Date());
      return 'SENT';
    } catch (error) {
      const code = classifyChannelFailure(error);
      const exhausted = (alert.attempts ?? 0) + 1 >= (alert.maxAttempts ?? ALERT_MAX_ATTEMPTS);
      // A3.2: after the last attempt the alert is FAILED and the cron stops touching it.
      // Before that it stays PENDING with a due time further out each attempt.
      const next = exhausted
        ? null
        : new Date(Date.now() + backoffFor(alert.attempts ?? 0));
      await this.mark(alertId, exhausted ? 'FAILED' : 'PENDING', code, null, next);
      this.logger.warn(`alert ${alert.type} not delivered (${code}), attempt ${alert.attempts + 1}`);
      return exhausted ? 'FAILED' : 'PENDING';
    }
  }

  private async mark(
    alertId: string,
    status: PlatformAlertStatus,
    errorCode: PlatformAlertErrorCode | null,
    sentAt: Date | null,
    nextAttemptAt?: Date | null,
  ): Promise<void> {
    await this.prisma.platformAlert.update({
      where: { id: alertId },
      data: {
        status,
        // Only ever store a code from the fixed vocabulary (A3.1).
        errorCode: errorCode ?? null,
        sentAt: sentAt ?? undefined,
        nextAttemptAt: nextAttemptAt === undefined ? undefined : nextAttemptAt,
        lastAttemptAt: new Date(),
        updatedAt: new Date(),
      },
    });
  }

  // ─── the retry cron (A3.2) ────────────────────────────────────────────────

  /**
   * Claims due alerts with FOR UPDATE SKIP LOCKED, so two cron passes or two api replicas
   * take disjoint sets and cannot both send the same alert. The claim increments the
   * attempt counter inside the same statement, so a crash between claim and result costs
   * one attempt instead of looping forever.
   */
  @Cron('*/2 * * * *')
  async retryDueCron(): Promise<void> {
    return requestContext.run({ requestId: 'cron:platform-alerts' }, async () => {
      if (!(await this.cronLeadership.acquireLock('platform-alert-retry', 120_000))) return;
      try {
        await this.retryDue(ALERT_RETRY_BATCH);
      } finally {
        await this.cronLeadership.releaseLock('platform-alert-retry');
      }
    });
  }

  async retryDue(limit: number = ALERT_RETRY_BATCH): Promise<{
    claimed: number;
    sent: number;
    failed: number;
    noChannel: number;
    pending: number;
  }> {
    const now = new Date();
    const claimed = await this.prisma.$queryRaw<
      Array<{ alert_id: string }>
    >`SELECT * FROM public.platform_claim_alerts_for_retry(${now}::timestamp(3), ${limit}::integer)`;

    const tally = { claimed: claimed.length, sent: 0, failed: 0, noChannel: 0, pending: 0 };
    for (const row of claimed) {
      const status = await this.deliver(row.alert_id);
      if (status === 'SENT') tally.sent += 1;
      else if (status === 'FAILED') tally.failed += 1;
      else if (status === 'NO_CHANNEL') tally.noChannel += 1;
      else tally.pending += 1;
    }
    return tally;
  }

  // ─── console read model ───────────────────────────────────────────────────

  /**
   * What the console's alert list returns. Deliberately the stored columns and nothing
   * more: no message body (there is none), no phone number, no raw error text. The R2 PII
   * crawl walks this route (A3.7).
   */
  async listForConsole(params: {
    page?: number;
    limit?: number;
    type?: string;
    status?: string;
  }) {
    const page = Math.max(1, Number(params.page) || 1);
    const limit = Math.min(100, Math.max(1, Number(params.limit) || 25));
    const where = {
      ...(params.type ? { type: params.type } : {}),
      ...(params.status ? { status: params.status } : {}),
    };
    const [rows, total] = await this.prisma.$transaction([
      this.prisma.platformAlert.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
        select: {
          id: true,
          type: true,
          severity: true,
          targetKind: true,
          targetId: true,
          auditSeq: true,
          status: true,
          attempts: true,
          maxAttempts: true,
          errorCode: true,
          createdAt: true,
          lastAttemptAt: true,
          sentAt: true,
        },
      }),
      this.prisma.platformAlert.count({ where }),
    ]);
    return { rows, total, page, limit, channel: this.channelState() };
  }
}

const HEADLINES: Record<PlatformAlertType, string> = {
  ADMIN_LOGIN_BURST: 'Owner console: repeated failed admin logins',
  ADMIN_NEW_DEVICE: 'Owner console: admin login from a new device',
  ADMIN_CREATED: 'Owner console: an administrator was created',
  ADMIN_REMOVED: 'Owner console: an administrator was removed',
  SUBSCRIPTION_GRANTED: 'Owner console: a subscription was granted or extended',
  GYM_DELETED: 'Owner console: a gym was deleted (restorable for 30 days)',
  AUDIT_WRITE_FAILED: 'Owner console: an audit row could not be written',
  ALERT_SEND_FAILED: 'Owner console: an alert could not be delivered',
};

export function backoffFor(attemptsAlreadyMade: number): number {
  const index = Math.min(Math.max(attemptsAlreadyMade, 0), ALERT_BACKOFF_MS.length - 1);
  return ALERT_BACKOFF_MS[index];
}

export function dedupeBucket(atMs: number): number {
  return Math.floor(atMs / ALERT_DEDUPE_WINDOW_MS);
}

/**
 * Map any channel failure onto the fixed code vocabulary. The provider's own text is read
 * only to choose a code and is never returned, logged in full, or stored (A3.1).
 */
export function classifyChannelFailure(error: unknown): PlatformAlertErrorCode {
  const message = String((error as Error)?.message ?? '');
  if (/timeout/i.test(message)) return 'channel_timeout';
  if (/not-configured|not_configured/i.test(message)) return 'channel_not_configured';
  if (/ECONNREFUSED|ENOTFOUND|EAI_AGAIN|socket hang up|fetch failed/i.test(message)) {
    return 'channel_error';
  }
  // Anything else the provider said: a rejection. The text stays out of the database.
  return 'channel_rejected';
}

function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`${label} after ${ms}ms`)), ms);
    promise.then(
      (value) => {
        clearTimeout(timer);
        resolve(value);
      },
      (error) => {
        clearTimeout(timer);
        reject(error);
      },
    );
  });
}
