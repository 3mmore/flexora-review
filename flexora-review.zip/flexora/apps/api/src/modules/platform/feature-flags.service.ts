import { Injectable } from '@nestjs/common';
import { RedisService } from '../../config/redis.service';

@Injectable()
export class FeatureFlagsService {
  constructor(private redis: RedisService) {}

  async isEnabled(
    flag: string,
    gymId?: string,
  ): Promise<boolean> {
    if (gymId) {
      const gymFlag = await this.redis.client.get(`flag:${gymId}:${flag}`);
      if (gymFlag !== null)
        return gymFlag === 'true';
    }
    const global = await this.redis.client.get(`flag:global:${flag}`);
    return global === 'true';
  }

  async setFlag(
    flag: string,
    value: boolean,
    gymId?: string,
  ): Promise<void> {
    const key = gymId
      ? `flag:${gymId}:${flag}`
      : `flag:global:${flag}`;
    await this.redis.client.set(key, String(value));
  }

  async listFlags(): Promise<Record<string,string>[]> {
    const keys = await this.redis.client.keys('flag:*');
    const result: Record<string,string>[] = [];
    for (const key of keys) {
      const value = await this.redis.client.get(key) || 'false';
      result.push({ key, value });
    }
    return result;
  }
}
