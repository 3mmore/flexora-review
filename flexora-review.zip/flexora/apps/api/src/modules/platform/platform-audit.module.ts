/**
 * FLEXORA Gym OS — Backend API
 * (c) 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R3 — the audit, alert and device services in their own module.
 *
 * WHY NOT JUST ADD THEM TO PlatformModule. PlatformModule imports PlatformAuthModule (it
 * revokes the sessions of an administrator it removes), and the authentication side is
 * exactly where most R3 events happen: the audit rows for login, step-up and TOTP
 * enrolment, the failed-login burst alert, and the device check after a successful login.
 * If the services lived in PlatformModule then PlatformAuthModule would have to import it
 * back and the graph would be a cycle. Putting them in a leaf module that both import is
 * the same shape already used for NotificationsModule and RedisModule.
 *
 * Nest instantiates an imported module once, so the alert retry cron declared on
 * PlatformAlertService is scheduled once even though two modules import this one.
 */
import { Module } from '@nestjs/common';
import { PrismaModule } from '../../config/prisma.module';
import { RedisModule } from '../../config/redis.module';
import { NotificationsModule } from '../notifications/notifications.module';
import { PlatformAuditService } from './platform-audit.service';
import { PlatformAlertService } from './platform-alert.service';
import { PlatformCacheService } from './platform-cache.service';
import { PlatformDeviceService } from './platform-device.service';
// PHASE R4 (R4.7/R4.8). The read cache lives here rather than in PlatformModule for the same
// reason the R3 services do: it needs RedisService, this module already imports RedisModule,
// and it must be reachable from both platform modules without creating a cycle. The module
// name is now slightly narrower than its contents; renaming it would touch every importer for
// no behavioural gain, so the mismatch is recorded here instead of hidden.

@Module({
  imports: [PrismaModule, RedisModule, NotificationsModule],
  providers: [PlatformAuditService, PlatformAlertService, PlatformDeviceService, PlatformCacheService],
  exports: [PlatformAuditService, PlatformAlertService, PlatformDeviceService, PlatformCacheService],
})
export class PlatformAuditModule {}
