/**
 * FLEXORA Gym OS — Backend API
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R4 (R4.7, R4.8) — the owner console's read cache.
 *
 * WHY THIS EXISTS. `GET /platform/overview` runs seven parallel aggregates over Gym, Member,
 * Subscription and Transaction, and the Overview page also asks for two twelve-month series.
 * The owner opens this page on a phone, possibly on mobile data, possibly several times a
 * minute. The brief's answer is a 60-second cache with BOUNDED Redis timeouts.
 *
 * THE BOUND IS THE PART THAT MATTERS, and it is worth being precise about why. PHASE P3 already
 * made every Redis command finite at the client level: `maxRetriesPerRequest: 0`,
 * `enableOfflineQueue: false` (so a command issued while disconnected rejects immediately
 * instead of parking in an offline queue forever), `commandTimeout` 1500 ms and
 * `connectTimeout` 2000 ms. Its own comment states the contract callers owe:
 *
 *     "Callers must treat a rejection as 'Redis is unavailable', not as 'no value': caches
 *      fall back to the database, and the fail-closed paths stay fail-closed.
 *      DependencyUnavailableFilter turns an unhandled rejection on a request path into
 *      503 + Retry-After instead of a hang or a 500."
 *
 * So a naive `await redis.get(key)` in this controller would not hang — P3 already prevented
 * that — but on a Redis outage it would REJECT, the filter would answer **503**, and the
 * Overview page would fail. That is precisely what R4.8 forbids: a slow or dead Redis must
 * neither hang nor fail the page. This service is the caller side of P3's contract.
 *
 * Two bounds, deliberately different:
 *   PLATFORM_CACHE_REDIS_BOUND_MS (250 ms) — how long a cache lookup may cost. Tighter than
 *     P3's 1500 ms commandTimeout on purpose: a cache is an optimisation, and paying 1.5 s to
 *     discover that an optimisation is unavailable is worse than not having it. When this
 *     fires the request proceeds to the database and loses at most 250 ms.
 *   PLATFORM_CACHE_TTL_SECONDS (60) — the staleness the brief specifies.
 *
 * NOTHING HERE THROWS. A read that fails is a miss; a write that fails is skipped. The database
 * is always the source of truth and always reachable without Redis.
 */
import { Injectable, Logger } from '@nestjs/common';
import { RedisService } from '../../config/redis.service';

/** R4.7 — the staleness the brief specifies for the Overview. */
export const PLATFORM_CACHE_TTL_SECONDS = 60;

/** R4.8 — how long one cache lookup may cost before the request proceeds without it. */
export const PLATFORM_CACHE_REDIS_BOUND_MS = 250;

export type PlatformCacheReadOutcome = 'hit' | 'miss' | 'timeout' | 'unavailable';

export interface PlatformCacheRead<T> {
  hit: boolean;
  value: T | null;
  outcome: PlatformCacheReadOutcome;
}

/** Sentinel so a bound can be told apart from a genuine Redis error. */
class CacheBoundExceeded extends Error {
  constructor() {
    super('platform cache bound exceeded');
  }
}

/**
 * Race a Redis command against a wall-clock bound.
 *
 * The loser is not cancelled — JavaScript cannot cancel a promise — so it is given a no-op
 * catch. Without that, a command that rejects AFTER the bound fired would surface as an
 * unhandled rejection, and an unhandled rejection on a request path is exactly what P3's
 * DependencyUnavailableFilter converts into a 503.
 */
async function withBound<T>(promise: Promise<T>, ms: number): Promise<T> {
  let timer: NodeJS.Timeout | undefined;
  const bound = new Promise<never>((_resolve, reject) => {
    timer = setTimeout(() => reject(new CacheBoundExceeded()), ms);
  });
  promise.catch(() => undefined);
  try {
    return await Promise.race([promise, bound]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

@Injectable()
export class PlatformCacheService {
  private readonly logger = new Logger('PlatformCache');

  constructor(private readonly redis: RedisService) {}

  /**
   * Read a cached JSON value. Never throws. A timeout, a rejection and a corrupt payload are
   * all reported as "not a hit", with the reason kept so the route can put it in a response
   * header and an operator can tell "cold cache" from "Redis is down".
   */
  async read<T>(key: string, boundMs = PLATFORM_CACHE_REDIS_BOUND_MS): Promise<PlatformCacheRead<T>> {
    try {
      const raw = await withBound(this.redis.get(key), boundMs);
      if (raw === null || raw === undefined) return { hit: false, value: null, outcome: 'miss' };
      try {
        return { hit: true, value: JSON.parse(raw) as T, outcome: 'hit' };
      } catch {
        // A payload we cannot parse is worse than no payload: serving half-decoded JSON to the
        // console would look like a data bug. Drop it and recompute. The key is not deleted
        // here on purpose - a delete is another Redis call on the request path, and the TTL
        // clears it within 60 s anyway.
        this.logger.warn(`platform cache payload for ${key} was not valid JSON; recomputing`);
        return { hit: false, value: null, outcome: 'unavailable' };
      }
    } catch (error) {
      const outcome: PlatformCacheReadOutcome =
        error instanceof CacheBoundExceeded ? 'timeout' : 'unavailable';
      // Warn, once per failure, naming the outcome and never a value: this is the line that
      // tells an operator the console is serving uncached data because Redis is slow or down.
      this.logger.warn(`platform cache read ${outcome} for ${key}; falling back to the database`);
      return { hit: false, value: null, outcome };
    }
  }

  /**
   * Store a JSON value with a TTL. Never throws and never delays the response beyond the
   * bound: a cache write that cannot complete is simply skipped, and the next request
   * recomputes.
   */
  async write(
    key: string,
    value: unknown,
    ttlSeconds = PLATFORM_CACHE_TTL_SECONDS,
    boundMs = PLATFORM_CACHE_REDIS_BOUND_MS,
  ): Promise<'written' | 'skipped'> {
    try {
      await withBound(this.redis.set(key, JSON.stringify(value), ttlSeconds), boundMs);
      return 'written';
    } catch (error) {
      const outcome = error instanceof CacheBoundExceeded ? 'timeout' : 'unavailable';
      this.logger.warn(`platform cache write ${outcome} for ${key}; response already served`);
      return 'skipped';
    }
  }

  /**
   * Drop a key, for the mutations that make a cached aggregate wrong. Bounded and silent for
   * the same reasons: if the delete does not land, the entry expires within the TTL, and a
   * stale-for-up-to-60-seconds aggregate is a far smaller problem than a failed suspension.
   */
  async invalidate(...keys: string[]): Promise<void> {
    await Promise.all(
      keys.map(async (key) => {
        try {
          await withBound(this.redis.del(key), PLATFORM_CACHE_REDIS_BOUND_MS);
        } catch {
          /* the TTL handles it */
        }
      }),
    );
  }
}

/** Cache key namespace, versioned so a changed response shape cannot be served from an old entry. */
export const PLATFORM_CACHE_KEYS = {
  overview: 'platform:overview:v1',
  revenueChart: (months: number) => `platform:revenue-chart:v1:${months}`,
  gymGrowth: (months: number) => `platform:gym-growth:v1:${months}`,
} as const;
