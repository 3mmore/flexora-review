/**
 * FLEXORA Gym OS — encrypted backup utility
 * © 2024 Ammar Allam. All rights reserved.
 */
import { createDecipheriv, createHash } from 'crypto';
import { createReadStream, createWriteStream } from 'fs';
import { readFile } from 'fs/promises';

function encryptionKey(): Buffer {
  const raw = process.env.BACKUP_ENCRYPTION_KEY;
  if (!raw) throw new Error('BACKUP_ENCRYPTION_KEY is required');
  if (/^[a-f0-9]{64}$/i.test(raw)) return Buffer.from(raw, 'hex');
  const decoded = Buffer.from(raw, 'base64');
  return decoded.length === 32 ? decoded : createHash('sha256').update(raw).digest();
}

async function restore(source: string, target: string) {
  const header = await readFile(source).then((b) => b.subarray(0, 18));
  if (header.subarray(0, 6).toString() !== 'FLXBAK1') throw new Error('Invalid encrypted backup header');
  const decipher = createDecipheriv('aes-256-gcm', encryptionKey(), header.subarray(6, 18));
  decipher.setAuthTag(await readFile(`${source}.tag`));
  await new Promise<void>((resolve, reject) => {
    createReadStream(source, { start: 18 }).pipe(decipher).pipe(createWriteStream(target)).on('finish', resolve).on('error', reject);
    decipher.on('error', reject);
  });
  console.log(`Decrypted backup written to ${target}`);
}

const [, , flag, source, target] = process.argv;
if (flag === '--restore' && source && target) restore(source, target).catch((error) => { console.error(error.message); process.exit(1); });
else {
  console.error('Usage: ts-node scripts/backup.ts --restore <backup.sql.gz.enc> <restore.sql.gz>');
  process.exit(1);
}
