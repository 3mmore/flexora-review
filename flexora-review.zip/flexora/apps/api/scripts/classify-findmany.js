/**
 * Classification script for all .findMany() calls across apps/api/src/modules
 */
const fs = require('fs');
const path = require('path');

const modulesDir = path.resolve(__dirname, '../src/modules');
const results = {
  bounded: [],
  unbounded: [],
  alreadyPaginated: [],
  transactional: [],
};

function walk(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      walk(fullPath);
    } else if (entry.isFile() && fullPath.endsWith('.ts') && !fullPath.endsWith('.spec.ts')) {
      processFile(fullPath);
    }
  }
}

function processFile(filePath) {
  const content = fs.readFileSync(filePath, 'utf8');
  const lines = content.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line.includes('.findMany(')) continue;

    // Extract context (5 lines before and after)
    const start = Math.max(0, i - 5);
    const end = Math.min(lines.length, i + 8);
    const context = lines.slice(start, end).join('\n').trim();

    const hasTake = /take\s*:/.test(context);
    const hasSkip = /skip\s*:/.test(context);
    const hasCursor = /cursor\s*:/.test(context);
    const hasWhereIn = /id\s*:\s*\{\s*in\s*:/.test(context);
    const isInTx = /tx\./.test(line) || context.includes('$transaction');
    const hasTimeFilter = /createdAt\s*:\s*\{\s*gte|expiry\s*:\s*\{\s*gte|startTime\s*:\s*\{\s*gte|checkInAt\s*:\s*\{\s*gte/.test(context);
    const hasEqId = /id\s*:\s*\w+/.test(context) && !/id\s*:\s*\{\s*in/.test(context);
    const isPlatform = /PlatformAdmin|PlatformAuditLog|PlatformLog|gym\.findMany\(\s*\{\s*where\s*:\s*\{\s*status\s*:\s*['"]ACTIVE['"]/.test(context);
    const isConfig = /plan\.findMany\(.*gymId|branch\.findMany\(.*gymId|chartOfAccount\.findMany\(.*gymId|emailTemplate\.findMany\(.*gymId|customDomain\.findMany\(.*gymId/.test(context);
    const isAi = /aiSuggestion\.findMany|aiInsight\.findMany/.test(context);

    const entry = {
      file: path.relative(modulesDir, filePath),
      line: i + 1,
      snippet: line.substring(0, 120),
      context: context.substring(0, 300),
    };

    if (hasTake || hasSkip || hasCursor) {
      results.alreadyPaginated.push(entry);
    } else if (isInTx && hasWhereIn) {
      results.transactional.push(entry);
    } else if (hasWhereIn || hasEqId || isConfig || isAi) {
      results.bounded.push(entry);
    } else if (isPlatform) {
      results.unbounded.push({ ...entry, note: 'platform-level, should paginate' });
    } else if (hasTimeFilter) {
      results.bounded.push({ ...entry, note: 'time-bounded but could still be large' });
    } else {
      results.unbounded.push(entry);
    }
  }
}

walk(modulesDir);

console.log('# Pagination Classification Report\n');
console.log(`## Already Paginated (take/skip/cursor present): ${results.alreadyPaginated.length}\n`);
for (const e of results.alreadyPaginated) {
  console.log(`- **${e.file}:${e.line}** \`${e.snippet}\``);
}

console.log(`\n## Transactional / Bounded by Input IDs: ${results.transactional.length}\n`);
for (const e of results.transactional) {
  console.log(`- **${e.file}:${e.line}** \`${e.snippet}\``);
}

console.log(`\n## Bounded by Nature (config, small lists, single IDs): ${results.bounded.length}\n`);
for (const e of results.bounded) {
  console.log(`- **${e.file}:${e.line}** \`${e.snippet}\` ${e.note || ''}`);
}

console.log(`\n## Genuinely Unbounded (needs pagination): ${results.unbounded.length}\n`);
for (const e of results.unbounded) {
  console.log(`- **${e.file}:${e.line}** \`${e.snippet}\` ${e.note || ''}`);
}

console.log(`\n---`);
console.log(`Total: ${results.alreadyPaginated.length + results.transactional.length + results.bounded.length + results.unbounded.length}`);
