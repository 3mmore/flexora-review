/**
 * FLEXORA Gym OS — Item 5 verification script.
 *
 * Loads apps/api/.env.example, swaps every `CHANGE_ME...` placeholder for a
 * realistic dummy secret (correct length/format, but obviously not a real
 * production value), and runs the REAL `validateEnv()` boot-time check
 * against the result — proving every required var env-validation.ts checks
 * for is present in .env.example, and that a filled-in copy of this file
 * passes validation with NODE_ENV=production (the strictest mode).
 *
 * Usage: npx ts-node scripts/verify-env-example.ts
 */
import * as fs from 'fs';
import * as path from 'path';
import { randomBytes } from 'crypto';

const envExamplePath = path.join(__dirname, '..', '.env.example');
const raw = fs.readFileSync(envExamplePath, 'utf8');

const env: Record<string, string> = {};
for (const line of raw.split('\n')) {
  const trimmed = line.trim();
  if (!trimmed || trimmed.startsWith('#')) continue;
  const eq = trimmed.indexOf('=');
  if (eq === -1) continue;
  const key = trimmed.slice(0, eq).trim();
  let value = trimmed.slice(eq + 1).trim();
  // Strip inline comments (a "  # ..." after the value).
  const commentIdx = value.indexOf(' #');
  if (commentIdx !== -1) value = value.slice(0, commentIdx).trim();
  env[key] = value;
}

function hex64() {
  return randomBytes(32).toString('hex');
}
function strongPassword() {
  return `Aa1${randomBytes(12).toString('hex')}`;
}
function jwtSecret() {
  return `Zz9-${randomBytes(20).toString('hex')}`;
}

// Realistic dummy replacements for every placeholder / weak-by-design value
// in .env.example, keyed by variable name so each gets the correct format.
const REPLACEMENTS: Record<string, () => string> = {
  DATABASE_URL: () => 'postgresql://flexora_app:Aa1' + randomBytes(8).toString('hex') + '@localhost:5432/flexora?schema=public',
  DIRECT_URL: () => 'postgresql://postgres:Aa1' + randomBytes(8).toString('hex') + '@localhost:5432/flexora',
  REDIS_URL: () => 'redis://localhost:6379',
  REDIS_PASSWORD: () => strongPassword(),
  JWT_ACCESS_SECRET: () => jwtSecret(),
  JWT_REFRESH_SECRET: () => jwtSecret(),
  JWT_MEMBER_SECRET: () => jwtSecret(),
  ENCRYPTION_KEY: () => hex64(),
  ENCRYPTION_KEY_V1: () => hex64(),
  ENCRYPTION_KEY_V2: () => hex64(),
  ENCRYPTION_SEARCH_KEY: () => hex64(),
  BACKUP_ENCRYPTION_KEY: () => jwtSecret(),
  OTP_HMAC_SECRET: () => jwtSecret(),
  WHATSAPP_APP_SECRET: () => jwtSecret(),
  FLEXORA_LICENSE_KEY: () => 'FLEX-' + randomBytes(12).toString('hex').toUpperCase(),
  SUPER_ADMIN_PASSWORD: () => strongPassword(),
  PLATFORM_ADMIN_PASSWORD: () => strongPassword(),
  POSTGRES_PASSWORD: () => strongPassword(),
};

for (const [key, value] of Object.entries(env)) {
  if (/CHANGE_ME/i.test(value) && REPLACEMENTS[key]) {
    env[key] = REPLACEMENTS[key]();
  }
}

// Force the strictest validation mode.
env.NODE_ENV = 'production';

// Apply to process.env exactly as dotenv/ConfigModule would.
for (const [k, v] of Object.entries(env)) {
  process.env[k] = v;
}

// eslint-disable-next-line @typescript-eslint/no-var-requires
const { validateEnv } = require('../src/config/env-validation');

const result = validateEnv();

console.log('--- .env.example verification (Item 5) ---');
console.log('Required vars found in .env.example and filled with realistic dummy values.');
console.log('validateEnv() result:', JSON.stringify(result, null, 2));

if (!result.ok) {
  console.error('\nFAILED: .env.example does not satisfy validateEnv() — see errors above.');
  process.exit(1);
}

console.log('\nPASSED: a filled-in copy of .env.example satisfies validateEnv() with NODE_ENV=production.');
process.exit(0);
