/** @type {import('ts-jest').JestConfigWithTsJest} */
module.exports = {
  preset: 'ts-jest',
  testEnvironment: 'jsdom',
  rootDir: 'src',
  // PHASE R4: was '.*\.spec\.ts$', which silently skipped the first .spec.tsx this repo ever
  // had - the chart primitives are JSX, and a test file that never runs reports no failure. The
  // change is additive: every existing .ts spec still matches.
  testRegex: '.*\\.spec\\.tsx?$',
  moduleFileExtensions: ['ts', 'tsx', 'js', 'json'],
  // tsx added for the same reason. jsx: 'react-jsx' was already configured, so .ts specs that
  // never contained JSX are unaffected.
  transform: { '^.+\\.tsx?$': ['ts-jest', { tsconfig: { jsx: 'react-jsx' } }] },
  testEnvironmentOptions: { customExportConditions: [''] },
  setupFiles: ['<rootDir>/../jest.react-shim.js'],
  // PHASE R0: src/middleware.ts imports '@/lib/...' exactly as the app does, so the
  // suite that attacks the middleware needs the same alias resolution (tsconfig
  // "paths": {"@/*": ["./src/*"]}). Additive: a relative import still resolves the
  // same way, so no existing web spec changes behaviour.
  moduleNameMapper: { '^@/(.*)$': '<rootDir>/$1' },
};
