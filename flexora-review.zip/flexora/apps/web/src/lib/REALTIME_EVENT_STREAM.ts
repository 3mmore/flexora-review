import type { ProductModule } from './PRODUCT_RUNTIME_ENGINE';

export type BusinessEventType =
  | 'member.created'
  | 'member.renewed'
  | 'member.risk'
  | 'attendance.checkin'
  | 'attendance.missed'
  | 'sale.created'
  | 'inventory.decremented'
  | 'inventory.low_stock'
  | 'campaign.sent'
  | 'billing.updated'
  | 'class.booked'
  | 'system.feedback';

export interface BusinessEvent<TPayload = Record<string, unknown>> {
  id: string;
  type: BusinessEventType;
  module: ProductModule;
  payload: TPayload;
  at: string;
  severity?: 'info' | 'success' | 'warning' | 'danger';
  tenantId?: string;
}

export interface EventFlowAggregate {
  total: number;
  byModule: Partial<Record<ProductModule, number>>;
  byType: Partial<Record<BusinessEventType, number>>;
  recent: BusinessEvent[];
}

const MAX_EVENTS = 250;
let memoryEvents: BusinessEvent[] = [];
const bus = typeof window !== 'undefined' ? new EventTarget() : null;

export function readBusinessEvents(): BusinessEvent[] { return memoryEvents; }

function writeBusinessEvents(events: BusinessEvent[]) { memoryEvents = events.slice(-MAX_EVENTS); }

export function emitBusinessEvent(event: Omit<BusinessEvent, 'id' | 'at'> & { id?: string; at?: string }): BusinessEvent {
  const full: BusinessEvent = {
    id: event.id || `evt_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    at: event.at || new Date().toISOString(),
    type: event.type,
    module: event.module,
    payload: event.payload,
    severity: event.severity || 'info',
    tenantId: event.tenantId,
  };
  const events = readBusinessEvents();
  writeBusinessEvents([...events, full]);
  bus?.dispatchEvent(new CustomEvent('flexora:business-event', { detail: full }));
  return full;
}

export function subscribeToEventStream(handler: (event: BusinessEvent) => void): () => void {
  if (!bus) return () => undefined;
  const listener = (event: Event) => handler((event as CustomEvent<BusinessEvent>).detail);
  bus.addEventListener('flexora:business-event', listener);
  return () => bus.removeEventListener('flexora:business-event', listener);
}

export function aggregateEventFlow(events: BusinessEvent[] = readBusinessEvents()): EventFlowAggregate {
  return events.reduce<EventFlowAggregate>((acc, event) => {
    acc.total += 1;
    acc.byModule[event.module] = (acc.byModule[event.module] || 0) + 1;
    acc.byType[event.type] = (acc.byType[event.type] || 0) + 1;
    acc.recent = [...acc.recent, event].slice(-20);
    return acc;
  }, { total: 0, byModule: {}, byType: {}, recent: [] });
}

export function detectEventAnomalies(events: BusinessEvent[] = readBusinessEvents()): BusinessEvent[] {
  const cutoff = Date.now() - 15 * 60 * 1000;
  const recent = events.filter((event) => new Date(event.at).getTime() >= cutoff);
  const aggregate = aggregateEventFlow(recent);
  const anomalies: BusinessEvent[] = [];

  if ((aggregate.byType['inventory.low_stock'] || 0) >= 3) {
    anomalies.push(emitBusinessEvent({
      type: 'inventory.low_stock',
      module: 'inventory',
      severity: 'warning',
      payload: { reason: 'rt_lowstock_events', count: aggregate.byType['inventory.low_stock'] },
    }));
  }
  if ((aggregate.byType['attendance.missed'] || 0) >= 5) {
    anomalies.push(emitBusinessEvent({
      type: 'attendance.missed',
      module: 'attendance',
      severity: 'warning',
      payload: { reason: 'rt_attendance_cluster', count: aggregate.byType['attendance.missed'] },
    }));
  }
  return anomalies;
}
