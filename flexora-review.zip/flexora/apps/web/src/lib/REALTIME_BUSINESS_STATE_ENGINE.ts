import type { ProductModule, ProductSignal } from './PRODUCT_RUNTIME_ENGINE';
import type { BusinessEvent } from './REALTIME_EVENT_STREAM';

export type LiveBusinessStateKind =
  | 'LIVE_REVENUE_STATE'
  | 'LIVE_ATTENDANCE_STATE'
  | 'LIVE_CHURN_STATE'
  | 'LIVE_INVENTORY_STATE'
  | 'LIVE_GROWTH_STATE';

export interface LiveBusinessState {
  kind: LiveBusinessStateKind;
  module: ProductModule;
  health: 'stable' | 'watch' | 'risk' | 'critical';
  confidence: number;
  signals: ProductSignal[];
  updatedAt: string;
}

function signal(id: string, kind: ProductSignal['kind'], level: ProductSignal['level'], title: string, detail: string, actionId?: string): ProductSignal {
  return { id, kind, level, title, detail, actionId };
}

export function mergeEventSignals(events: BusinessEvent[]): ProductSignal[] {
  const signals: ProductSignal[] = [];
  const lowStock = events.filter((event) => event.type === 'inventory.low_stock').length;
  const missed = events.filter((event) => event.type === 'attendance.missed').length;
  const memberRisk = events.filter((event) => event.type === 'member.risk').length;
  const sales = events.filter((event) => event.type === 'sale.created').length;

  if (lowStock > 0) signals.push(signal('live_inventory_risk', 'risk', lowStock > 4 ? 'high' : 'medium', 'Live inventory pressure', `${lowStock} low-stock event(s) detected in the live stream.`, 'sales-stock-check'));
  if (missed > 0) signals.push(signal('live_attendance_risk', 'risk', missed > 5 ? 'high' : 'medium', 'Live attendance weakness', `${missed} missed-attendance event(s) may affect engagement.`, 'attendance-retention-review'));
  if (memberRisk > 0) signals.push(signal('live_churn_risk', 'risk', memberRisk > 3 ? 'critical' : 'high', 'Live churn signal', `${memberRisk} member risk event(s) need retention action.`, 'review-retention'));
  if (sales >= 3) signals.push(signal('live_sales_opportunity', 'opportunity', 'medium', 'Sales momentum detected', `${sales} sale event(s) indicate current demand.`, 'open-pos'));

  return signals;
}

export function computeLiveBusinessState(module: ProductModule, events: BusinessEvent[]): LiveBusinessState {
  const signals = mergeEventSignals(events).filter((sig) => sig.id.includes(module) || module === 'dashboard' || module === 'ai');
  const critical = signals.some((sig) => sig.level === 'critical');
  const high = signals.some((sig) => sig.level === 'high');
  const medium = signals.some((sig) => sig.level === 'medium');
  return {
    kind: module === 'inventory' ? 'LIVE_INVENTORY_STATE' : module === 'attendance' ? 'LIVE_ATTENDANCE_STATE' : module === 'members' ? 'LIVE_CHURN_STATE' : module === 'sales' || module === 'pos' ? 'LIVE_REVENUE_STATE' : 'LIVE_GROWTH_STATE',
    module,
    health: critical ? 'critical' : high ? 'risk' : medium ? 'watch' : 'stable',
    confidence: Math.min(0.95, 0.55 + events.length / 100),
    signals,
    updatedAt: new Date().toISOString(),
  };
}

export function detectStateTransitions(previous: LiveBusinessState | null, next: LiveBusinessState): ProductSignal[] {
  if (!previous || previous.health === next.health) return [];
  return [{
    id: `state_transition_${next.module}_${Date.now()}`,
    kind: next.health === 'stable' ? 'success' : 'risk',
    level: next.health === 'critical' ? 'critical' : next.health === 'risk' ? 'high' : 'medium',
    title: `Live state changed to ${next.health}`,
    detail: `${next.module} moved from ${previous.health} to ${next.health}.`,
  }];
}
