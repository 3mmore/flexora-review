/**
 * Brand fallback text used where no i18n hook is available (the logo lockup).
 * Arabic is the product default, so the fallback is Arabic; a gym that sets its
 * own system name in branding overrides it.
 */
export const BRAND_TAGLINE = 'نظام إدارة الصالات';
