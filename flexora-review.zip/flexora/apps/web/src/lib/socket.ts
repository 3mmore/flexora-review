'use client';
import { io, Socket } from 'socket.io-client';
import { isProduction } from './env-mode';

let socket: Socket | null = null;
export function getSocket(): Socket {
  if (!socket) {
    // Empty NEXT_PUBLIC_API_URL → connect to the same origin (proxy mode).
    const configured = (process.env.NEXT_PUBLIC_API_URL || '').replace(/\/$/, '');
    const origin = configured ? (configured.endsWith('/api') ? configured.slice(0, -4) : configured) : '';
    socket = io(origin ? `${origin}/realtime` : '/realtime', {
      transports: ['websocket'],
      withCredentials: true,
    });
    // PHASE M1: dev-only logging, gated the same fail-closed way the API is.
    if (!isProduction()) {
      socket.on('connect', () => console.debug('Socket connected'));
      socket.on('disconnect', () => console.debug('Socket disconnected'));
    }
  }
  return socket;
}
export function closeSocket() { socket?.close(); socket = null; }
