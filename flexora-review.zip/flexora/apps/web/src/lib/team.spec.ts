/**
 * FEATURE B — the web helpers, asserted against literal expected strings.
 * These are the rules a reader of the page depends on: "—" instead of 0 % for an
 * empty denominator, money never re-parsed into a float, and a query string the
 * API will accept.
 */
import {
  TEAM_DEFAULT_FILTERS,
  TEAM_MAX_PAGE_SIZE,
  barWidth,
  buildTeamQuery,
  csvFilename,
  isOverTarget,
  pct,
  personKind,
  rangeLabel,
} from './team';

describe('buildTeamQuery', () => {
  it('sends the preset and nothing else for the default month view', () => {
    expect(buildTeamQuery(TEAM_DEFAULT_FILTERS)).toBe('period=month&page=1&pageSize=25');
  });

  it('only sends from/to for a custom range', () => {
    expect(buildTeamQuery({ ...TEAM_DEFAULT_FILTERS, period: 'custom', from: '2026-11-01', to: '2026-11-14' }))
      .toContain('from=2026-11-01');
    // a preset with a leftover date must NOT send it (the API ignores it, but an
    // ignored parameter is how "the filter does nothing" bugs start)
    const preset = buildTeamQuery({ ...TEAM_DEFAULT_FILTERS, period: 'today', from: '2026-11-01', to: '2026-11-14' });
    expect(preset).not.toContain('from=');
    expect(preset).not.toContain('to=');
  });

  it('omits empty filters and trims the search', () => {
    const q = buildTeamQuery({ ...TEAM_DEFAULT_FILTERS, branchId: '', q: '   ', sort: 'net', includeInactive: false });
    expect(q).not.toContain('branchId');
    expect(q).not.toContain('q=');
    expect(q).not.toContain('sort=');
    expect(q).not.toContain('includeInactive');
    expect(buildTeamQuery({ ...TEAM_DEFAULT_FILTERS, q: '  رانيا  ' })).toContain(`q=${encodeURIComponent('رانيا')}`);
  });

  it('carries branch, sort and the inactive toggle when set', () => {
    const q = buildTeamQuery({ ...TEAM_DEFAULT_FILTERS, branchId: 'br1', sort: 'attendance', includeInactive: true });
    expect(q).toContain('branchId=br1');
    expect(q).toContain('sort=attendance');
    expect(q).toContain('includeInactive=true');
  });

  it('clamps page and pageSize instead of asking for something the API rejects', () => {
    expect(buildTeamQuery({ ...TEAM_DEFAULT_FILTERS, pageSize: 10000 })).toContain(`pageSize=${TEAM_MAX_PAGE_SIZE}`);
    expect(buildTeamQuery({ ...TEAM_DEFAULT_FILTERS, pageSize: 0 })).toContain('pageSize=25');
    expect(buildTeamQuery({ ...TEAM_DEFAULT_FILTERS, page: 0 })).toContain('page=1');
    expect(buildTeamQuery({ ...TEAM_DEFAULT_FILTERS, page: -3 })).toContain('page=1');
    expect(buildTeamQuery({ ...TEAM_DEFAULT_FILTERS, page: 2.7 })).toContain('page=2');
  });
});

describe('pct / bars', () => {
  it('renders an em dash when there is no denominator', () => {
    expect(pct(null)).toBe('—');
    expect(pct(undefined)).toBe('—');
    expect(pct(Number.NaN)).toBe('—');
  });

  it('renders one decimal, including 0 % when the denominator exists', () => {
    expect(pct(0)).toBe('0.0%');
    expect(pct(83.3)).toBe('83.3%');
    expect(pct(100)).toBe('100.0%');
  });

  it('clamps the bar width but never the number', () => {
    expect(barWidth(150)).toBe('100%');
    expect(barWidth(-20)).toBe('0%');
    expect(barWidth(null)).toBe('0%');
    expect(barWidth(42.4)).toBe('42.4%');
    expect(pct(150)).toBe('150.0%'); // over-achievement is displayed truthfully
  });

  it('marks over-target at exactly 100 and above', () => {
    expect(isOverTarget(100)).toBe(true);
    expect(isOverTarget(99.9)).toBe(false);
    expect(isOverTarget(null)).toBe(false);
  });
});

describe('csvFilename', () => {
  it('takes the server filename when it is safe', () => {
    expect(csvFilename('attachment; filename="team-performance-2026-11-01-to-2026-11-14.csv"'))
      .toBe('team-performance-2026-11-01-to-2026-11-14.csv');
  });

  it('falls back to a range-derived name', () => {
    expect(csvFilename(null, { from: '2026-11-01', to: '2026-11-14' })).toBe('team-performance-2026-11-01-to-2026-11-14.csv');
    expect(csvFilename(null)).toBe('team-performance.csv');
  });

  it('strips path separators and control characters from a hostile header', () => {
    expect(csvFilename('attachment; filename="../../etc/passwd"')).toBe('.._.._etc_passwd');
    expect(csvFilename('attachment; filename="a\u0000b.csv"')).toBe('a_b.csv');
  });
});

describe('labels', () => {
  it('picks the right half of the table per role', () => {
    expect(personKind('COACH')).toBe('coach');
    expect(personKind('RECEPTION')).toBe('money');
    expect(personKind('OWNER')).toBe('money');
  });

  // UPDATED IN PACK 2, ITEM 4. The old expectation crowned the string with the
  // raw IANA id — "2026-11-14 · Africa/Cairo" — which is a Latin word on an
  // Arabic screen and a category-1 violation of the owner's item-1 rule. The
  // label now takes a LOCALISED timezone name (or none), and the arrow points
  // the way Arabic reads: from the later date back to the earlier one.
  it('labels a single-day range once and a span with an arrow', () => {
    // no localised zone: the dates speak for themselves, never the zone id
    expect(rangeLabel({ from: '2026-11-14', to: '2026-11-14', tz: 'Africa/Cairo' })).toBe('2026-11-14');
    expect(rangeLabel({ from: '2026-11-01', to: '2026-11-14', tz: 'Africa/Cairo' })).toBe('2026-11-01 ← 2026-11-14');
    // with an Arabic label, appended as its own segment
    expect(rangeLabel({ from: '2026-11-14', to: '2026-11-14', tz: 'Africa/Cairo' }, (d) => d, 'توقيت القاهرة'))
      .toBe('2026-11-14 · توقيت القاهرة');
    // the zone id itself must never be the visible label
    expect(rangeLabel({ from: '2026-11-01', to: '2026-11-14', tz: 'Africa/Cairo' })).not.toContain('Africa');
    expect(rangeLabel({ from: '', to: '', tz: 'x' })).toBe('');
  });
});
