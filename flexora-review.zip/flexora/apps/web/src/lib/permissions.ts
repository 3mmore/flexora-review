/**
 * ROUND 13 (Phase 5) — web mirror of the API permission catalog.
 *
 * The API is the single source of truth (see apps/api
 * modules/permissions/permissions.catalog.ts): /auth/me returns each user's
 * EFFECTIVE permissions, the PermissionsGuard enforces them per request, and
 * the Team page edits them. This file mirrors the catalog so the shell and the
 * edge middleware can drive navigation WITHOUT an API round-trip:
 *
 *   - the sidebar shows exactly the pages the user may open,
 *   - the middleware gates routes by the permissions claim in the access token
 *     (falling back to the role defaults for tokens minted before Phase 5),
 *   - buttons on pages read the same list.
 *
 * Nothing visible is forbidden and nothing allowed is hidden: when the owner
 * grants a permission the page appears, when they revoke it the page vanishes.
 */

export const PERMISSIONS = [
  'members.view',
  'members.create',
  'members.edit',
  'members.delete',
  // PACK 2, item 3: starting a membership in the PAST. OWNER by default; the
  // owner can grant it to a MANAGER from the Team page.
  'members.backdate',
  'plans.view',
  'plans.manage',
  'plans.delete',
  'attendance.manual',
  'pos.sell',
  'sales.refund',
  'inventory.view',
  'inventory.manage',
  'reports.view',
  'accounting.view',
  'accounting.manage',
  'settings.manage',
  'billing.manage',
  'staff.manage',
  'classes.manage',
  'contracts.manage',
  'branches.manage',
  'backups.manage',
  'payroll.manage',
  'team.performance.view',
  'profile.self',
] as const;

export type Permission = (typeof PERMISSIONS)[number];

/** Role defaults — mirror of ROLE_DEFAULTS in the API catalog. The API copy is
 *  authoritative; this fallback only serves pre-Phase-5 access tokens. */
export const ROLE_DEFAULTS: Record<string, Permission[]> = {
  OWNER: [...PERMISSIONS],
  MANAGER: PERMISSIONS.filter(
    (p) =>
      p !== 'billing.manage' &&
      p !== 'backups.manage' &&
      p !== 'payroll.manage' &&
      p !== 'branches.manage' &&
      p !== 'plans.delete' &&
      // FEATURE B: per-person revenue is OWNER by default; a manager gets it
      // only when the owner grants it (mirrors the API catalog).
      p !== 'team.performance.view' &&
      p !== 'members.backdate',
  ),
  RECEPTION: [
    'members.view',
    'members.create',
    'members.edit',
    'plans.view',
    'attendance.manual',
    'pos.sell',
    'inventory.view',
    'classes.manage',
    'profile.self',
  ],
  COACH: ['members.view', 'members.edit', 'attendance.manual', 'classes.manage', 'profile.self'],
  ACCOUNTANT: ['members.view', 'accounting.view', 'accounting.manage', 'profile.self'],
};

export function roleDefaultPermissions(role?: string | null): Permission[] {
  if (!role) return [];
  if (role === 'OWNER' || role === 'SUPER_ADMIN') return [...PERMISSIONS];
  return [...(ROLE_DEFAULTS[role] || [])];
}

/**
 * Route → required permission. Ordered: the FIRST matching prefix wins, so
 * more specific routes come first (/members/import before /members).
 * Routes not listed here stay open to any authenticated staff user.
 */
export const ROUTE_PERMISSIONS: ReadonlyArray<readonly [string, Permission]> = [
  ['/members/import', 'members.create'],
  ['/members', 'members.view'],
  ['/attendance', 'members.view'],
  ['/checkin', 'attendance.manual'],
  ['/biometric', 'members.edit'],
  ['/invitations', 'members.create'],
  ['/leads', 'members.create'],
  ['/crm', 'reports.view'],
  ['/campaigns', 'reports.view'],
  ['/contracts', 'contracts.manage'],
  ['/classes', 'classes.manage'],
  ['/coach', 'classes.manage'],
  ['/users', 'staff.manage'],
  ['/transfers', 'inventory.manage'],
  ['/inventory', 'inventory.view'],
  ['/products', 'inventory.view'],
  ['/sales', 'pos.sell'],
  ['/pos', 'pos.sell'],
  ['/staff-attendance', 'attendance.manual'],
  ['/team/performance', 'team.performance.view'],
  ['/reports', 'reports.view'],
  ['/expenses', 'accounting.view'],
  ['/accounting', 'accounting.view'],
  ['/billing', 'billing.manage'],
  ['/license', 'billing.manage'],
  ['/plans', 'plans.view'],
  ['/branches', 'members.view'],
  ['/settings', 'settings.manage'],
  ['/wa-bot', 'settings.manage'],
  ['/ai-advanced', 'reports.view'],
  ['/ai', 'reports.view'],
  ['/white-label', 'settings.manage'],
  ['/marketplace', 'settings.manage'],
  ['/backups', 'backups.manage'],
  ['/kiosk', 'settings.manage'],
];

export function requiredPermissionFor(pathname: string): Permission | null {
  for (const [prefix, permission] of ROUTE_PERMISSIONS) {
    if (pathname === prefix || pathname.startsWith(prefix + '/')) return permission;
  }
  return null;
}

/** Effective permission list for a user — JWT claim first, role fallback. */
export function effectivePermissionsOf(
  role?: string | null,
  claim?: string[] | null,
): Permission[] {
  if (role === 'OWNER' || role === 'SUPER_ADMIN') return [...PERMISSIONS];
  if (Array.isArray(claim) && claim.length) {
    return claim.filter((p): p is Permission => (PERMISSIONS as readonly string[]).includes(p));
  }
  return roleDefaultPermissions(role);
}

export function hasPermission(
  role: string | null | undefined,
  claim: string[] | null | undefined,
  permission: Permission,
): boolean {
  return effectivePermissionsOf(role, claim).includes(permission);
}
