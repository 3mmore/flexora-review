/**
 * PACK 2 · STEP 2.3 — what a phone may keep between sessions, and what it may not.
 *
 * Two separate problems, deliberately kept in two files:
 *
 *   pwa-cache-policy.ts  — MAY THE SERVICE WORKER STORE THIS RESPONSE?
 *                          (answered here, enforced in public/sw.js, pinned by
 *                           both a unit test and a source test on sw.js)
 *
 *   offline-snapshot.ts  — WHAT MAY THE APP SHOW WHEN IT IS OFFLINE?
 *                          (four numbers, in sessionStorage, per user id,
 *                           cleared on sign-out)
 *
 * The rule for both is the same and is not negotiable: nothing that belongs to a
 * signed-in account may be written to a store that outlives the session or is
 * shared between accounts on the same device. A gym runs on a shared tablet at
 * the desk; the next person to pick it up must never be able to read the
 * previous user's screen out of a cache.
 */

export type FetchDecision =
  | 'network-only'      // never stored, never served from a store
  | 'navigation-network-first' // HTML: network, offline page on failure, never cached
  | 'asset-cache-first'; // static build output: safe to store by URL

export interface FetchContext {
  method: string;
  url: string;
  /** true for a browser navigation (an HTML document) */
  navigation: boolean;
}

/** API prefixes that are always authenticated or tenant-scoped. */
const API_PREFIXES = ['/api/', '/api'];

/** Static output that never contains account data. */
const ASSET_RE = /\.(?:woff2?|png|jpe?g|gif|svg|ico|webp|css|js|webmanifest)$/i;

/**
 * The one function the service worker's rules must agree with.
 *
 * Everything about an account goes to the network. There is deliberately no
 * "cache this API response for offline" branch: a Cache Storage entry is keyed by
 * URL, and every account on the device requests the same URL.
 */
export function decideFetch(ctx: FetchContext): FetchDecision {
  const { method } = ctx;
  if (method !== 'GET') return 'network-only';

  const path = pathOf(ctx.url);
  if (API_PREFIXES.some((p) => path === p || path.startsWith(p.endsWith('/') ? p : `${p}/`))) {
    return 'network-only';
  }
  // the offline page itself and the PWA manifests are public documents; they are
  // still not "cached HTML" in the sense that matters, they carry no account data
  if (ctx.navigation) return 'navigation-network-first';
  if (ASSET_RE.test(path)) return 'asset-cache-first';
  return 'network-only';
}

/** Path of an absolute or relative URL, without query string. */
export function pathOf(url: string): string {
  try {
    const parsed = new URL(url, 'http://placeholder.invalid');
    return parsed.pathname;
  } catch {
    return url.split('?')[0];
  }
}

/**
 * The cache version. Bumping it is the only correct way to evict everything a
 * previous release stored: `activate` deletes every cache that is not this name.
 */
export const CACHE_NAME = 'flexora-static-v3';
