import type { ProductModule, ProductSignal, RuntimeAction } from './PRODUCT_RUNTIME_ENGINE';

export type DecisionEdgeKind = 'causes' | 'amplifies' | 'protects' | 'constrains' | 'monetizes';

export interface DecisionEdge {
  from: ProductModule;
  to: ProductModule;
  kind: DecisionEdgeKind;
  businessMeaning: string;
  defaultAction?: RuntimeAction;
}

export interface DecisionInfluence {
  source: ProductModule;
  affected: ProductModule[];
  edges: DecisionEdge[];
  narrative: string;
}

export const DECISION_GRAPH: DecisionEdge[] = [
  {
    from: 'attendance',
    to: 'members',
    kind: 'amplifies',
    businessMeaning: 'Attendance drops usually precede churn and renewal risk.',
    defaultAction: { id: 'attendance-retention-review', label: 'rt_review_inactive', href: '/ai', intent: { type: 'recover', entity: 'member' }, reason: 'rt_review_inactive_why', source: 'system', tone: 'warning', priority: 82 },
  },
  {
    from: 'attendance',
    to: 'dashboard',
    kind: 'causes',
    businessMeaning: 'Floor traffic is a leading indicator for revenue, retention, and staffing needs.',
  },
  {
    from: 'sales',
    to: 'inventory',
    kind: 'constrains',
    businessMeaning: 'Sales velocity consumes inventory and can create stockout risk.',
    defaultAction: { id: 'sales-stock-check', label: 'rt_check_low_stock', href: '/inventory', intent: { type: 'recover', entity: 'stock' }, reason: 'rt_check_low_stock_why', source: 'system', tone: 'warning', priority: 78 },
  },
  {
    from: 'inventory',
    to: 'sales',
    kind: 'monetizes',
    businessMeaning: 'Inventory readiness protects point-of-sale revenue capture.',
  },
  {
    from: 'campaigns',
    to: 'members',
    kind: 'protects',
    businessMeaning: 'Retention campaigns protect renewals and recover disengaged members.',
  },
  {
    from: 'classes',
    to: 'attendance',
    kind: 'causes',
    businessMeaning: 'Class utilization creates repeat visits and improves engagement.',
  },
  {
    from: 'billing',
    to: 'enterprise',
    kind: 'constrains',
    businessMeaning: 'Subscription and license state controls feature availability and governance.',
  },
  {
    from: 'reports',
    to: 'dashboard',
    kind: 'amplifies',
    businessMeaning: 'Reports explain the operating picture shown in the executive dashboard.',
  },
];

export function getDecisionInfluence(module: ProductModule): DecisionInfluence {
  const edges = DECISION_GRAPH.filter((edge) => edge.from === module || edge.to === module);
  const affected = Array.from(new Set(edges.map((edge) => (edge.from === module ? edge.to : edge.from))));
  const narrative = edges.length
    ? edges.map((edge) => edge.businessMeaning).join(' ')
    : 'This module participates in the FLEXORA operating system through shared context, actions, and feedback.';
  return { source: module, affected, edges, narrative };
}

export function propagateCrossModuleSignals(module: ProductModule, signals: ProductSignal[]): ProductSignal[] {
  const influence = getDecisionInfluence(module);
  const propagated: ProductSignal[] = [];
  for (const signal of signals) {
    if (signal.kind !== 'risk' && signal.kind !== 'opportunity') continue;
    for (const edge of influence.edges.filter((item) => item.from === module)) {
      propagated.push({
        id: `${signal.id}->${edge.to}`,
        kind: signal.kind,
        level: signal.level,
        title: `${edge.to} affected by ${module}`,
        detail: edge.businessMeaning,
        actionId: edge.defaultAction?.id || signal.actionId,
      });
    }
  }
  return propagated;
}

export function graphActionsFor(module: ProductModule): RuntimeAction[] {
  return getDecisionInfluence(module).edges
    .map((edge) => edge.defaultAction)
    .filter((action): action is RuntimeAction => Boolean(action));
}
