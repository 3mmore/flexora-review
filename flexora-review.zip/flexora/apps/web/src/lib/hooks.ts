'use client';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from './api';
export const qk = {
  members: (q?: string, page?: number) => ['members', q, page] as const, member: (id: string) => ['member', id] as const,
  branches: () => ['branches'] as const, plans: () => ['plans'] as const, users: () => ['users'] as const,
  attendance: (date?: string) => ['attendance', date] as const, products: () => ['products'] as const, expenses: () => ['expenses'] as const,
};
export const useMembers = (q?: string, page = 1) => useQuery({ queryKey: qk.members(q, page), queryFn: () => api(`/members?q=${q || ''}&page=${page}`) });
export const useMember = (id: string) => useQuery({ queryKey: qk.member(id), queryFn: () => api(`/members/${id}`), enabled: !!id });
export const useBranches = () => useQuery({ queryKey: qk.branches(), queryFn: () => api('/branches') });
export const usePlans = () => useQuery({ queryKey: qk.plans(), queryFn: () => api('/plans') });
export const useUsers = () => useQuery({ queryKey: qk.users(), queryFn: () => api('/users') });
export const useProducts = () => useQuery({ queryKey: qk.products(), queryFn: () => api('/products') });
export const useExpenses = () => useQuery({ queryKey: qk.expenses(), queryFn: () => api('/expenses') });
export const useCreateMember = () => { const qc = useQueryClient(); return useMutation({ mutationFn: (body: unknown) => api('/members', { method: 'POST', body: JSON.stringify(body) }), onSuccess: () => qc.invalidateQueries({ queryKey: ['members'] }) }); };
export const useCreateBranch = () => { const qc = useQueryClient(); return useMutation({ mutationFn: (body: unknown) => api('/branches', { method: 'POST', body: JSON.stringify(body) }), onSuccess: () => qc.invalidateQueries({ queryKey: qk.branches() }) }); };
export const useUpdateBranch = () => { const qc = useQueryClient(); return useMutation({ mutationFn: ({ id, ...body }: { id: string } & Record<string, unknown>) => api(`/branches/${id}`, { method: 'PATCH', body: JSON.stringify(body) }), onSuccess: () => qc.invalidateQueries({ queryKey: qk.branches() }) }); };
export const useDeleteBranch = () => { const qc = useQueryClient(); return useMutation({ mutationFn: (id: string) => api(`/branches/${id}`, { method: 'DELETE' }), onSuccess: () => qc.invalidateQueries({ queryKey: qk.branches() }) }); };
export const useCreatePlan = () => { const qc = useQueryClient(); return useMutation({ mutationFn: (body: unknown) => api('/plans', { method: 'POST', body: JSON.stringify(body) }), onSuccess: () => qc.invalidateQueries({ queryKey: qk.plans() }) }); };
export const useUpdatePlan = () => { const qc = useQueryClient(); return useMutation({ mutationFn: ({ id, ...body }: { id: string } & Record<string, unknown>) => api(`/plans/${id}`, { method: 'PATCH', body: JSON.stringify(body) }), onSuccess: () => qc.invalidateQueries({ queryKey: qk.plans() }) }); };
export const useDeletePlan = () => { const qc = useQueryClient(); return useMutation({ mutationFn: (id: string) => api(`/plans/${id}`, { method: 'DELETE' }), onSuccess: () => qc.invalidateQueries({ queryKey: qk.plans() }) }); };
export const useCreateUser = () => { const qc = useQueryClient(); return useMutation({ mutationFn: (body: unknown) => api('/users', { method: 'POST', body: JSON.stringify(body) }), onSuccess: () => qc.invalidateQueries({ queryKey: qk.users() }) }); };
export const useUpdateUser = () => { const qc = useQueryClient(); return useMutation({ mutationFn: ({ id, ...body }: { id: string } & Record<string, unknown>) => api(`/users/${id}`, { method: 'PATCH', body: JSON.stringify(body) }), onSuccess: () => qc.invalidateQueries({ queryKey: qk.users() }) }); };
export const useCreateExpense = () => { const qc = useQueryClient(); return useMutation({ mutationFn: (body: unknown) => api('/expenses', { method: 'POST', body: JSON.stringify(body) }), onSuccess: () => qc.invalidateQueries({ queryKey: qk.expenses() }) }); };
import { useEffect, useMemo, useState } from 'react';

export function useTypewriter(text: string, speed = 18) {
  const [shown, setShown] = useState('');
  useEffect(() => {
    setShown('');
    if (!text) return;
    let i = 0;
    const timer = window.setInterval(() => {
      i += 1;
      setShown(text.slice(0, i));
      if (i >= text.length) window.clearInterval(timer);
    }, speed);
    return () => window.clearInterval(timer);
  }, [text, speed]);
  return shown;
}

export function useCountUp(value: number, duration = 600) {
  const [current, setCurrent] = useState(0);
  useEffect(() => {
    const target = Number(value || 0);
    const start = performance.now();
    let frame = 0;
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / Math.max(1, duration));
      setCurrent(target * p);
      if (p < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [value, duration]);
  return current;
}

export function revealStyle(index = 0) {
  return { animationDelay: `${index * 60}ms` };
}
