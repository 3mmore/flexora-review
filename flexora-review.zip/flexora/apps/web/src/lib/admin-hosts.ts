/**
 * FLEXORA Gym OS - Web
 * (c) 2024 Ammar Allam. All rights reserved.
 */
/**
 * PHASE R0 - the owner-console host gate (web side).
 *
 * This is a DELIBERATE MIRROR of apps/api/src/config/admin-hosts.ts. The two
 * cannot share a module: this one runs in Next's edge/middleware runtime (no Node
 * built-ins, no imports from the api workspace) and the api one runs in Node.
 * Keeping them honest is what apps/api/src/config/admin-host-cases.json is for:
 * one table of host/path cases that BOTH test suites evaluate, so a divergence in
 * either implementation fails a test instead of failing the owner's deployment.
 *
 * WHY THE WEB NEEDS ITS OWN GATE (measured, not assumed)
 * The api has a metadata-driven gate, but the console UI is rendered by this app:
 * before PHASE R0, `GET /platform/login` on the public hostname answered 200 with
 * the full 16,754-byte login page, and every other `/platform/*` page answered a
 * 307 redirect to `/platform/login` - an existence leak that no api change can
 * fix. `GET /api/platform/overview` through this app's proxy is gated here too,
 * because the proxy may hand the api a Host header that the api's own gate would
 * accept (defence in depth, owner decision R0: enforce independently in nginx,
 * Next middleware and Nest).
 *
 * ROUTE IDENTITY
 * The api identifies console routes by the @PlatformRoute() decorator. Middleware
 * runs BEFORE routing, so no handler metadata exists yet - the same situation
 * PHASE Q2 documented for Nest middleware. The path is therefore matched here, but
 * defensively: raw, percent-decoded and slash-collapsed variants are all checked,
 * because `/%70latform/login` and `//platform/login` must not become an oracle.
 *
 * NO process.env READ AT MODULE SCOPE. Values are read at request time.
 */

export const ADMIN_HOSTS_VAR = 'ADMIN_HOSTS';
export const TRUST_PROXY_HOPS_VAR = 'TRUST_PROXY_HOPS';

/** Loopback-only development default = trial mode (console on the owner's machine). */
export const ADMIN_HOSTS_DEV_DEFAULT = 'localhost,127.0.0.1';

/** Every path prefix that belongs to the owner console. */
export const CONSOLE_PATH_PREFIXES: readonly string[] = ['/platform', '/api/platform'];

/** Path segments that must never be treated as console paths (a prefix trap). */
const LOOKALIKE_EXAMPLES: readonly string[] = ['/platformer', '/platform-x', '/api/platforms'];

export interface AdminHostEntry {
  readonly hostname: string;
  readonly port?: string;
}

export interface AdminHostsConfig {
  readonly raw: string;
  readonly entries: readonly AdminHostEntry[];
  readonly usingDevDefault: boolean;
  readonly invalid: readonly string[];
}

/**
 * RFC 6761 reserves the `.invalid` top-level domain: a name under it can never
 * resolve, which is exactly why nginx uses `host-gate.denied.invalid` as the Host
 * it hands upstream for a console request that arrived on a public hostname (see
 * nginx/nginx.conf). If that name could be allow-listed through ADMIN_HOSTS, the
 * edge's own denial signal would become an entry ticket, so it is rejected here:
 * a reserved entry is dropped from the allow-list (fail closed, in every NODE_ENV)
 * and reported as a configuration problem.
 */
export const RESERVED_INVALID_HOSTNAME = 'invalid';
export const NGINX_GATE_HOSTNAME = 'host-gate.denied.invalid';

function isReservedInvalidName(hostname: string): boolean {
  const h = hostname.trim().toLowerCase();
  return h === RESERVED_INVALID_HOSTNAME || h.endsWith(`.${RESERVED_INVALID_HOSTNAME}`);
}

function isWildcardToken(token: string): boolean {
  const t = token.trim().toLowerCase();
  return t === '*' || t === '*.*' || t === 'all' || t === 'any' || t.startsWith('*.') || t.endsWith('.*');
}

function isPlainIpv6(value: string): boolean {
  return /^[0-9a-f:]+$/.test(value) && value.includes(':');
}

function isHostname(value: string): boolean {
  if (!value || value.length > 253) return false;
  if (value.includes('*')) return false;
  if (/^[0-9a-f:]+$/.test(value) && value.includes(':')) return true;
  return /^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)(\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*$/.test(value);
}

/** Split/parse the raw value. Never throws; unparsable entries never widen access. */
export function parseAdminHosts(raw: string | undefined): AdminHostsConfig {
  const value = String(raw ?? '').trim();
  const entries: AdminHostEntry[] = [];
  const invalid: string[] = [];
  for (const piece of value.split(',')) {
    const token = piece.trim();
    if (!token) continue;
    if (isWildcardToken(token)) {
      invalid.push(token);
      continue;
    }
    if (/[/?#]/.test(token) || /^[a-z][a-z0-9+.-]*:\/\//i.test(token)) {
      invalid.push(token);
      continue;
    }
    let hostname = token.toLowerCase();
    let port: string | undefined;
    if (hostname.startsWith('[')) {
      const close = hostname.indexOf(']');
      if (close === -1) {
        invalid.push(token);
        continue;
      }
      const literal = hostname.slice(1, close);
      const rest = hostname.slice(close + 1);
      if (rest && !rest.startsWith(':')) {
        invalid.push(token);
        continue;
      }
      if (rest.length > 1) port = rest.slice(1);
      hostname = literal;
      if (!isPlainIpv6(hostname)) {
        invalid.push(token);
        continue;
      }
    } else if ((hostname.match(/:/g) || []).length >= 2) {
      // A bare IPv6 literal (`::1`). Two or more colons can only be IPv6; treating
      // it as host:port would reject the loopback entry an operator is most likely
      // to write. A port with an IPv6 literal MUST be bracketed (`[::1]:8443`).
      if (!isPlainIpv6(hostname)) {
        invalid.push(token);
        continue;
      }
    } else if (hostname.includes(':')) {
      const parts = hostname.split(':');
      if (parts.length !== 2 || !parts[1]) {
        invalid.push(token);
        continue;
      }
      hostname = parts[0];
      port = parts[1];
    }
    hostname = stripRootDot(hostname);
    if (!isHostname(hostname)) {
      invalid.push(token);
      continue;
    }
    // Reserved `.invalid` names are never usable admin hosts (see above); the api
    // implementation applies the identical rule and both are tested against the
    // same shared case table (apps/api/src/config/admin-host-cases.json).
    if (isReservedInvalidName(hostname)) {
      invalid.push(token);
      continue;
    }
    if (port !== undefined && !/^\d{1,5}$/.test(port)) {
      invalid.push(token);
      continue;
    }
    entries.push(port === undefined ? { hostname } : { hostname, port });
  }
  return { raw: value, entries, usingDevDefault: false, invalid };
}

/**
 * The effective configuration at call time. In production an unset value yields an
 * EMPTY allow-list (every host refused) rather than the development default: the
 * boot validator reports it as an error, and failing closed beats failing open.
 */
export function adminHostsConfig(nodeEnv: string = process.env.NODE_ENV || ''): AdminHostsConfig {
  const raw = process.env[ADMIN_HOSTS_VAR];
  const production = String(nodeEnv).toLowerCase() === 'production';
  if (!raw || !raw.trim()) {
    if (production) return { raw: '', entries: [], usingDevDefault: false, invalid: [] };
    const fallback = parseAdminHosts(ADMIN_HOSTS_DEV_DEFAULT);
    return { ...fallback, raw: '', usingDevDefault: true };
  }
  return parseAdminHosts(raw);
}

export function splitHostHeader(value: string | undefined): { hostname: string; port?: string; raw: string } {
  const raw = String(value ?? '').trim().toLowerCase();
  if (!raw) return { hostname: '', raw: '' };
  if (raw.startsWith('[')) {
    const close = raw.indexOf(']');
    if (close === -1) return { hostname: stripRootDot(raw), raw };
    const hostname = raw.slice(1, close);
    const rest = raw.slice(close + 1);
    const port = rest.startsWith(':') && rest.length > 1 ? rest.slice(1) : undefined;
    return { hostname: stripRootDot(hostname), port, raw };
  }
  const idx = raw.lastIndexOf(':');
  if (idx === -1) return { hostname: stripRootDot(raw), raw };
  const maybePort = raw.slice(idx + 1);
  if (!/^\d{1,5}$/.test(maybePort)) return { hostname: stripRootDot(raw), raw };
  return { hostname: stripRootDot(raw.slice(0, idx)), port: maybePort, raw };
}

/**
 * A single trailing dot is the DNS root label: `admin.example.com.` IS
 * `admin.example.com`. Stripped from both the configured entries and the request,
 * so no dotted spelling becomes an oracle and an operator whose client sends the
 * fully-qualified form is not locked out of their own console.
 */
export function stripRootDot(hostname: string): string {
  return hostname.length > 1 && hostname.endsWith('.') ? hostname.slice(0, -1) : hostname;
}

export type AdminHostVerdict =
  | { readonly allowed: true; readonly matched: string }
  | { readonly allowed: false; readonly reason: 'unset' | 'host-mismatch' | 'forwarded-host-disagrees' | 'missing-host' };

/** The effective hop count, mirroring apps/api/src/config/trust-proxy.config.ts. */
export function trustProxyHops(env: NodeJS.ProcessEnv = process.env): number {
  const raw = (env[TRUST_PROXY_HOPS_VAR] ?? '').trim();
  if (!raw || !/^\d+$/.test(raw)) return 1; // documented default = the shipped nginx
  const n = Number(raw);
  return n >= 0 && n <= 3 ? n : 1;
}

/**
 * Decide whether a request may reach the owner console. X-Forwarded-Host is only
 * consulted when TRUST_PROXY_HOPS > 0, and even then it must AGREE with Host:
 * a forwarded header can never widen access, so a disagreement refuses the request
 * in both directions (including "Host allowed, forwarded not").
 */
export function adminHostVerdict(
  hostHeader: string | undefined,
  forwardedHost: string | undefined,
  config: AdminHostsConfig = adminHostsConfig(),
  hops: number = trustProxyHops(),
): AdminHostVerdict {
  const host = String(hostHeader ?? '').trim();
  if (!host) return { allowed: false, reason: 'missing-host' };
  const { hostname, port, raw } = splitHostHeader(host);

  // The agreement check compares HOSTNAMES, not host:port. A port in a forwarded
  // header is usually the port the client dialed (443) while Host carries the port
  // this server listens on, so requiring the ports to match would refuse legitimate
  // proxy chains and lock the owner out of their own console. The security property
  // the check exists for - a forwarded header must never smuggle a different
  // hostname past the gate - is fully covered by the hostname comparison, and the
  // allow-list match on the Host header still honours a pinned port entry.
  const forwarded = String(forwardedHost ?? '').trim().toLowerCase();
  if (forwarded && hops > 0) {
    const parts = forwarded.split(',').map((p) => p.trim()).filter(Boolean);
    const idx = Math.max(0, parts.length - hops);
    const trusted = splitHostHeader(parts[idx]).hostname;
    if (trusted !== hostname) return { allowed: false, reason: 'forwarded-host-disagrees' };
  }

  if (config.entries.length === 0) return { allowed: false, reason: 'unset' };
  for (const entry of config.entries) {
    if (entry.port) {
      if (entry.hostname === hostname && entry.port === port) return { allowed: true, matched: raw };
      continue;
    }
    if (entry.hostname === hostname) return { allowed: true, matched: raw };
  }
  return { allowed: false, reason: 'host-mismatch' };
}

/**
 * Path variants a router might resolve to the console. Middleware has no handler
 * metadata yet, so every representation Express/Next could normalise to is checked.
 */
/**
 * PHASE R1 / review item 2 - how many percent-decode rounds are applied before
 * classifying. Decoding runs to a FIXED POINT and stops there, so a path that
 * stops changing is not decoded again; the cap exists so a hostile input cannot
 * make this loop unbounded. Three rounds covers the double-encoded case
 * (/%2570latform -> /%70latform -> /platform) with one round in hand.
 */
export const MAX_CONSOLE_PATH_DECODE_ROUNDS = 3;

/**
 * True when a request target contains a NUL byte, in either spelling: a literal
 * one, or a percent-encoded %00 that appears before or after decoding.
 *
 * A NUL in a path is never legitimate, and refusing it must NOT depend on which
 * path it arrived on. Measured before R1 (work/r1-evidence/00c S1): `/platform%00`
 * reached directly at Next answered 307 -> /platform/login while an unknown path
 * answered 404, which tells a scanner the console exists. One path-independent 400
 * removes the difference instead of special-casing the console.
 */
export function containsNulByte(value: string | undefined | null): boolean {
  const raw = String(value ?? '');
  if (raw.indexOf('\0') !== -1 || /%00/i.test(raw)) return true;
  let decoded = raw;
  for (let round = 0; round < MAX_CONSOLE_PATH_DECODE_ROUNDS; round++) {
    let next: string;
    try {
      next = decodeURIComponent(decoded);
    } catch {
      return false; // a malformed escape cannot decode further; nothing more to find
    }
    if (next === decoded) return false;
    decoded = next;
    if (decoded.indexOf('\0') !== -1 || /%00/i.test(decoded)) return true;
  }
  return false;
}

/**
 * Strip RFC 3986 path parameters (";params") from every segment:
 * `/platform;x=1/login` -> `/platform/login`.
 *
 * Next's router discarded them before matching, so a request for the semicolon
 * spelling reached the console while the gate, which looked at the raw path, did
 * not recognise it. Measured: 307 -> /platform/login on a public hostname.
 */
export function stripPathParameters(value: string): string {
  return value
    .split('/')
    .map((segment) => {
      const semicolon = segment.indexOf(';');
      return semicolon >= 0 ? segment.slice(0, semicolon) : segment;
    })
    .join('/');
}

/**
 * The structural rewrites a router or proxy may apply before matching, so that the
 * gate classifies the path the way the router will see it:
 *   - backslash to slash   (`/\platform/login` -> `/platform/login`; measured 308)
 *   - path parameters removed
 *   - duplicate slashes collapsed
 *   - trailing slashes removed
 *   - dot segments resolved
 * Each step is added as its own variant as well as being fed into the next one, so
 * a path that needs two of them is still caught.
 */
export function structuralPathVariants(value: string): string[] {
  const out: string[] = [];
  // A NUL terminates the path for anything that treats it as a C string, which is
  // exactly why `/platform%00` is an attack spelling. Truncating there yields the
  // path such a router would match. The middleware and the api both refuse a NUL with
  // a path-independent 400 before this ever decides anything; classifying it
  // correctly too means the shared case table tells the truth about both layers.
  const withoutNul = value.indexOf('\0') >= 0 ? value.slice(0, value.indexOf('\0')) : value;
  if (withoutNul !== value) out.push(withoutNul);
  const slashed = withoutNul.replace(/\\/g, '/');
  out.push(slashed);
  const withoutParams = stripPathParameters(slashed);
  out.push(withoutParams);
  const collapsed = withoutParams.replace(/\/{2,}/g, '/');
  out.push(collapsed);
  const trimmed = collapsed.replace(/\/+$/, '') || '/';
  out.push(trimmed);
  out.push(resolveDotSegments(trimmed));
  return out;
}

export function consolePathVariants(pathname: string): string[] {
  const raw = String(pathname ?? '');
  const variants = new Set<string>();
  const push = (value: string) => {
    if (value) variants.add(value);
  };

  push(raw);
  push(raw.toLowerCase());

  // Percent-decode to a fixed point, at most MAX_CONSOLE_PATH_DECODE_ROUNDS times.
  // Before R1 this decoded exactly twice, which handled the double-encoded case by
  // luck rather than by rule and would have missed a triple encoding.
  let decoded = raw;
  for (let round = 0; round < MAX_CONSOLE_PATH_DECODE_ROUNDS; round++) {
    let next: string;
    try {
      next = decodeURIComponent(decoded);
    } catch {
      break; // a malformed escape sequence cannot decode; the raw form is still checked
    }
    if (next === decoded) break; // fixed point reached
    decoded = next;
    push(decoded);
    push(decoded.toLowerCase());
  }

  // Structural rewrites, applied to every spelling found so far.
  for (const value of Array.from(variants)) {
    for (const structural of structuralPathVariants(value)) {
      push(structural);
      push(structural.toLowerCase());
    }
  }

  return Array.from(variants);
}

/** Resolve `.` and `..` segments the way a URL parser does. */
export function resolveDotSegments(pathname: string): string {
  if (!pathname.includes('/.')) return pathname;
  const out: string[] = [];
  for (const segment of pathname.split('/')) {
    if (segment === '.') continue;
    if (segment === '..') {
      // never pop above the root, and never pop the leading empty segment
      if (out.length > 1) out.pop();
      continue;
    }
    out.push(segment);
  }
  const joined = out.join('/');
  return joined.startsWith('/') ? joined : `/${joined}`;
}

/**
 * Which family a console path belongs to, or null when it is not a console path.
 *
 * The family decides HOW the gate refuses, because the two families have different
 * "unknown route" shapes and a refusal must match its own family:
 *   'page' - rendered by this app. Refused by rewriting to a path that does not
 *            exist HERE, so Next renders its own not-found page (measured: the same
 *            14,415 bytes, content type and header set as any other unknown path).
 *   'api'  - proxied to the Nest api by next.config's rewrite. Refused by rewriting
 *            to an unknown path UNDER /api/, so the answer is the api's own JSON 404
 *            with the api's own security headers. Answering an /api request with
 *            Next's HTML 404 instead would itself be the fingerprint (measured: a
 *            genuinely unknown /api path through this proxy returns
 *            application/json, not text/html).
 */
export type ConsoleFamily = 'api' | 'page';

export function consoleFamily(pathname: string): ConsoleFamily | null {
  for (const variant of consolePathVariants(pathname)) {
    const v = variant.toLowerCase();
    if (v === '/api/platform' || v.startsWith('/api/platform/')) return 'api';
    if (v === '/platform' || v.startsWith('/platform/')) return 'page';
  }
  return null;
}

/** True when the request path belongs to the owner console, in ANY spelling. */
export function isConsolePath(pathname: string): boolean {
  return consoleFamily(pathname) !== null;
}

/**
 * True for paths that merely START WITH a console prefix but are not console
 * routes (`/platformer`). Used by the parity tests to prove the gate does not
 * over-block the tenant app.
 */
export function isLookalikePath(pathname: string): boolean {
  return LOOKALIKE_EXAMPLES.some((p) => pathname === p || pathname.startsWith(`${p}/`));
}
