import type { DecisionInfluence } from './PRODUCT_DECISION_GRAPH';
import { predictedNextModule, type ProductMemoryGraph } from './PRODUCT_MEMORY_GRAPH';
import type { ProductContext, ProductSignal, RuntimeAction } from './PRODUCT_RUNTIME_ENGINE';
import type { BusinessEvent } from './REALTIME_EVENT_STREAM';
import type { LiveBusinessState } from './REALTIME_BUSINESS_STATE_ENGINE';
import type { EarlyWarning } from './EARLY_WARNING_SYSTEM';

export interface AIOrchestrationOutput {
  signals: ProductSignal[];
  actions: RuntimeAction[];
  explanation: string;
}

export function orchestrateAIDecision(
  context: ProductContext,
  signals: ProductSignal[],
  memory: ProductMemoryGraph,
  influence: DecisionInfluence,
  realtime?: { liveEvents: BusinessEvent[]; liveState: LiveBusinessState; earlyWarnings: EarlyWarning[] },
): AIOrchestrationOutput {
  const riskSignals = signals.filter((s) => s.kind === 'risk');
  const opportunitySignals = signals.filter((s) => s.kind === 'opportunity');
  const nextModule = predictedNextModule(memory);
  const aiSignals: ProductSignal[] = [];
  const actions: RuntimeAction[] = [];

  if (riskSignals.length) {
    aiSignals.push({
      id: `${context.module}:ai-risk-orchestration`,
      kind: 'ai',
      level: riskSignals.some((s) => s.level === 'critical') ? 'critical' : 'high',
      title: 'rt_ai_risk_orch',
      detail: `The system found ${riskSignals.length} risk signal(s). ${influence.narrative}`,
      actionId: 'ai-risk-review',
    });
    actions.push({
      id: 'ai-risk-review',
      label: 'rt_review_recovery',
      href: '/ai',
      intent: { type: 'recover', entity: context.module, urgency: 'high' },
      reason: 'rt_ai_risk_orch_detail',
      source: 'ai',
      tone: 'warning',
      priority: 120,
    });
  }

  if (opportunitySignals.length) {
    aiSignals.push({
      id: `${context.module}:ai-opportunity-orchestration`,
      kind: 'ai',
      level: 'medium',
      title: 'rt_ai_opp_orch',
      detail: `The system found ${opportunitySignals.length} opportunity signal(s) that can be converted into action.`,
      actionId: 'ai-opportunity-review',
    });
    actions.push({
      id: 'ai-opportunity-review',
      label: 'rt_review_growth',
      href: '/ai',
      intent: { type: 'optimize', entity: context.module, urgency: 'medium' },
      reason: 'rt_ai_opp_orch_detail',
      source: 'ai',
      tone: 'good',
      priority: 92,
    });
  }

  if (nextModule) {
    actions.push({
      id: `memory-next-${nextModule}`,
      label: `Continue in ${nextModule}`,
      href: `/${nextModule}`,
      intent: { type: 'navigate', entity: nextModule },
      reason: 'rt_memory_next',
      source: 'memory',
      priority: 62,
    });
  }

  return {
    signals: aiSignals,
    actions,
    explanation: riskSignals.length
      ? 'AI is prioritizing recovery because risk signals are active.'
      : opportunitySignals.length
        ? 'AI is prioritizing growth because opportunity signals are active.'
        : 'AI found no urgent orchestration change.',
  };
}
