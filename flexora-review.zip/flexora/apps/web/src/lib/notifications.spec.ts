/**
 * PHASE A — the notification-inbox helpers the page actually calls.
 *
 * These are hard-coded expectations, not echoes of the implementation: the
 * query string, the link policy and the store behaviour are asserted against
 * literal values, so a change that silently loosens one of them fails here.
 */
import {
  EMPTY_FILTERS,
  MAX_PAGE_SIZE,
  __resetUnreadForTests,
  buildFeedQuery,
  formatWhen,
  getUnreadCount,
  isSafeLink,
  isoDay,
  previewText,
  refreshUnreadCount,
  setUnreadCount,
  severityKey,
  subscribeUnread,
  typeKey,
} from './notifications';

jest.mock('./api', () => ({
  api: jest.fn(),
}));
// eslint-disable-next-line @typescript-eslint/no-var-requires
const { api } = require('./api') as { api: jest.Mock };

beforeEach(() => {
  __resetUnreadForTests();
  api.mockReset();
});

describe('buildFeedQuery', () => {
  it('emits only what was set — an empty filter means the default page', () => {
    expect(buildFeedQuery()).toBe('page=1&pageSize=20');
    expect(buildFeedQuery({})).toBe('page=1&pageSize=20');
  });

  it('never emits an empty severity/type/from/to (the API rejects them)', () => {
    const q = buildFeedQuery({ ...EMPTY_FILTERS, status: 'all', severity: '', type: '', from: '', to: '', q: '   ' });
    expect(q).toBe('page=1&pageSize=20');
  });

  it('carries every filter, encoded', () => {
    const q = buildFeedQuery({
      status: 'unread',
      severity: 'danger',
      type: 'sale_alert',
      from: '2026-03-01',
      to: '2026-03-31',
      q: 'خصم 100%',
      page: 3,
      pageSize: 50,
    });
    expect(q).toContain('status=unread');
    expect(q).toContain('severity=danger');
    expect(q).toContain('type=SALE_ALERT'); // upper-snake is what the DTO accepts
    expect(q).toContain('from=2026-03-01');
    expect(q).toContain('to=2026-03-31');
    expect(q).toContain(`q=${encodeURIComponent('خصم 100%')}`);
    expect(q).toContain('page=3');
    expect(q).toContain('pageSize=50');
  });

  it('clamps page and pageSize instead of asking for more than the API allows', () => {
    expect(buildFeedQuery({ page: 0 })).toContain('page=1');
    expect(buildFeedQuery({ page: -5 })).toContain('page=1');
    expect(buildFeedQuery({ pageSize: 5000 })).toContain(`pageSize=${MAX_PAGE_SIZE}`);
    expect(buildFeedQuery({ pageSize: 0 })).toContain('pageSize=20');
    expect(buildFeedQuery({ sort: 'oldest' })).toContain('sort=oldest');
    expect(buildFeedQuery({ sort: 'newest' })).not.toContain('sort=');
  });
});

describe('isSafeLink', () => {
  it.each([
    'https://flexora.app/pay/1',
    'http://localhost:3000/x',
    'HTTPS://FLEXORA.APP',
  ])('accepts %s', (url) => {
    expect(isSafeLink(url)).toBe(true);
  });

  it.each([
    'javascript:alert(1)',
    '  javascript:alert(1)',
    'JaVaScRiPt:alert(1)',
    'data:text/html,<script>alert(1)</script>',
    'vbscript:msgbox(1)',
    'file:///etc/passwd',
    '//evil.example.com/x',
    '/relative/path',
    'not a url',
    '',
    'https://',
  ])('refuses %s', (url) => {
    expect(isSafeLink(url)).toBe(false);
  });

  it('refuses an absurdly long value instead of parsing it', () => {
    expect(isSafeLink(`https://flexora.app/${'a'.repeat(3000)}`)).toBe(false);
  });
});

describe('labels and previews', () => {
  it('maps every severity to a key that exists in BOTH dictionaries', () => {
    expect(severityKey('danger')).toBe('severity_danger');
    expect(severityKey('warning')).toBe('severity_warning');
    expect(severityKey('success')).toBe('severity_success');
    expect(severityKey('info')).toBe('severity_info');
    expect(severityKey('something-else')).toBe('severity_info');
  });

  it('maps known notification types and humanises unknown ones', () => {
    expect(typeKey('SALE_ALERT')).toBe('notification_type_sale_alert');
    expect(typeKey('RENEWAL')).toBe('notification_type_renewal');
    expect(typeKey('SOMETHING_NEW')).toBeNull();
  });

  it('collapses whitespace and clips a long body', () => {
    expect(previewText('a   b\n\nc')).toBe('a b c');
    const clipped = previewText('x'.repeat(500), 20);
    expect(clipped.length).toBe(20);
    expect(clipped.endsWith('…')).toBe(true);
  });
});

describe('dates', () => {
  it('formats an ISO instant in the requested language', () => {
    const ar = formatWhen('2026-03-10T21:59:00.000Z', 'ar');
    const en = formatWhen('2026-03-10T21:59:00.000Z', 'en');
    expect(ar).not.toBe('—');
    expect(en).toContain('2026');
    expect(ar).not.toBe(en);
  });

  it('returns an em dash for an unparseable date instead of "Invalid Date"', () => {
    expect(formatWhen('not-a-date', 'en')).toBe('—');
    expect(isoDay('not-a-date')).toBe('');
  });

  it('gives the export a machine-readable day', () => {
    expect(isoDay('2026-03-10T21:59:00.000Z')).toBe('2026-03-10');
  });
});

describe('unread store', () => {
  it('notifies every subscriber and never reports a negative count', () => {
    const seen: number[] = [];
    const unsubscribe = subscribeUnread((n) => seen.push(n));
    setUnreadCount(-4);
    setUnreadCount(7);
    expect(seen).toEqual([0, 0, 7]);
    expect(getUnreadCount()).toBe(7);
    unsubscribe();
    setUnreadCount(9);
    expect(seen).toEqual([0, 0, 7]);
  });

  it('keeps the last value when the request fails (never 0 by accident)', async () => {
    setUnreadCount(5);
    api.mockRejectedValueOnce(new Error('network down'));
    await expect(refreshUnreadCount()).resolves.toBe(5);
    expect(getUnreadCount()).toBe(5);
  });

  it('takes the server number when the request succeeds', async () => {
    api.mockResolvedValueOnce({ count: 12 });
    await expect(refreshUnreadCount()).resolves.toBe(12);
    expect(api).toHaveBeenCalledWith('/owner/notifications/unread-count');
  });

  it('coalesces concurrent refreshes into one request', async () => {
    api.mockResolvedValue({ count: 3 });
    await Promise.all([refreshUnreadCount(), refreshUnreadCount(), refreshUnreadCount()]);
    expect(api).toHaveBeenCalledTimes(1);
  });
});
