import { ar } from './i18n/ar';
import { en } from './i18n/en';

/**
 * Localized resolution for structured API errors.
 *
 * Backend errors that carry a `translationKey` (plus optional real numbers —
 * `current`, `limit`, `tier`) are rendered from the AR/EN dictionaries with
 * the numbers interpolated. This is how limit/capacity errors (member limit,
 * staff limit, license seats) reach the user as a CLEAR, TRANSLATED,
 * SPECIFIC message instead of raw English like "License member capacity
 * reached".
 */
type Params = Record<string, string | number>;

function currentLang(): 'ar' | 'en' {
  if (typeof localStorage === 'undefined') return 'ar';
  const saved = localStorage.getItem('flexora-lang');
  return saved === 'en' ? 'en' : 'ar';
}

function interpolate(template: string, params: Params): string {
  return template.replace(/\{(\w+)\}/g, (match, key) =>
    params[key] !== undefined ? String(params[key]) : match,
  );
}

export function localizeStructuredError(err: any): string | null {
  if (!err || typeof err !== 'object') return null;
  const key = err.translationKey;
  if (typeof key !== 'string' || !key) return null;
  const lang = currentLang();
  const dict: Record<string, string> = lang === 'ar' ? ar : en;
  const template = dict[key];
  if (!template) return null;
  const params: Params = {};
  if (typeof err.current === 'number') params.current = err.current;
  if (typeof err.limit === 'number') params.limit = err.limit;
  if (typeof err.tier === 'string') params.tier = err.tier;
  return interpolate(template, params);
}

/**
 * DTO field → i18n label, so a rejected field is named in the user's language
 * ("الاسم الكامل: ...") instead of the raw property path.
 */
const FIELD_LABELS: Record<string, string> = {
  name: 'full_name',
  email: 'email',
  password: 'password',
  phone: 'phone',
  role: 'role',
  branchId: 'branch',
  '': '',
};

/**
 * Renders a validation rejection (400) as a specific, readable sentence.
 * Returns null when the error is not a validation failure.
 */
export function localizeValidationError(err: any): string | null {
  if (!err || typeof err !== 'object') return null;
  const issues: Array<{ field?: string; message?: string; translationKey?: string }> =
    Array.isArray(err.errors) && err.errors.length
      ? err.errors
      : err.code === 'VALIDATION_FAILED' && Array.isArray(err.messages)
        ? err.messages.map((message: string) => ({ message }))
        : [];
  if (!issues.length) return null;

  const lang = currentLang();
  const dict: Record<string, string> = lang === 'ar' ? ar : en;

  return issues
    .map((issue) => {
      const label = FIELD_LABELS[String(issue.field || '')];
      const labelText = label ? dict[label] : '';
      const text = issue.translationKey && dict[issue.translationKey]
        ? dict[issue.translationKey]
        : issue.message || '';
      if (!text) return '';
      return labelText ? `${labelText}: ${text}` : text;
    })
    .filter(Boolean)
    .join(' · ');
}

export function safeErrorMessage(err: unknown): string {
  // Validation rejections name the exact field and reason.
  const validation = localizeValidationError(err as any);
  if (validation) return validation;

  // Structured, translatable errors first (code/translationKey + numbers).
  const localized = localizeStructuredError(err as any);
  if (localized) return localized;

  if (!err) return 'unknown_error';
  
  // Handle specific translation-friendly error shapes from the backend
  if (typeof err === 'object') {
    const e = err as any;
    if (e.translationKey) return e.translationKey;
    if (e.message && typeof e.message === 'string') {
      const msg = e.message;
      
      // Map common error patterns to specific translation keys
      if (msg.includes('unique_constraint_violation') || msg.includes('Conflict')) return 'error_already_exists';
      if (msg.includes('unauthorized') || msg.includes('401')) return 'unauthorized';
      if (msg.includes('forbidden') || msg.includes('403')) return 'insufficient_permissions';
      if (msg.includes('not_found') || msg.includes('404')) return 'not_found';
      
      // Cleanup raw internal details but keep the message if it looks like a clean application error
      if (!/Prisma|SQL|\/app\/|stack|trace|database|constraint/i.test(msg)) {
        return msg;
      }
    }
  }

  if (typeof err === 'string') {
    if (!/Prisma|SQL|\/app\/|stack|trace|database|constraint/i.test(err)) return err;
  }

  return 'server_error';
}
