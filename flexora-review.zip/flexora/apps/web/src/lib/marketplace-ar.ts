/**
 * PACK 2 / ITEM 1 — Arabic names for the modules the product ships.
 *
 * The marketplace catalogue lives in the `MarketplaceModule` table with English
 * name/description/category. Translating it in the database would mean a schema
 * change, which the owner explicitly reserved for a decision — so the mapping
 * lives here instead, keyed by the STABLE slug (the slug remains the identity in
 * the payload, the filters and the install endpoint).
 *
 * A slug that is not in this map is a module somebody added in their own
 * deployment: its name is operator-authored data, so it is shown as typed.
 */
export type ModuleLabel = { name: string; description: string; category: string };

export const MARKETPLACE_AR: Record<string, ModuleLabel> = {
  'ai-assistant': {
    name: 'المساعد التجاري الذكي',
    description: 'تنبؤ بالإيراد، وتوقّع انسحاب الأعضاء والتجديدات',
    category: 'الذكاء الاصطناعي',
  },
  'whatsapp-business': {
    name: 'واتساب للأعمال',
    description: 'رسائل جماعية وردود آلية',
    category: 'التسويق',
  },
  'biometric-pro': {
    name: 'البصمة المتقدمة (WebAuthn)',
    description: 'تسجيل حضور بالبصمة أو الوجه',
    category: 'التشغيل',
  },
  'sms-bulk': {
    name: 'رسائل SMS جماعية',
    description: 'إرسال آلاف الرسائل شهريًا',
    category: 'التسويق',
  },
  'advanced-reports': {
    name: 'تقارير متقدمة',
    description: 'الأرباح والخسائر، الميزانية العمومية، التدفقات النقدية',
    category: 'التقارير',
  },
  'multi-branch-pro': {
    name: 'إدارة فروع متقدمة',
    description: 'التحويلات والتوزيع ومقارنة الفروع',
    category: 'التشغيل',
  },
  'custom-domain': {
    name: 'نطاق مخصص',
    description: 'بوابة العضو بعلامتك على نطاقك الخاص',
    category: 'الهوية',
  },
  sso: {
    name: 'الدخول الموحّد SSO + SCIM',
    description: 'جوجل / مايكروسوفت / SAML',
    category: 'المؤسسات',
  },
};

/** Arabic label for a catalogue module, or the operator's own text. */
export function moduleLabel(slug: string, fallback: ModuleLabel): ModuleLabel {
  return MARKETPLACE_AR[slug] ?? fallback;
}
