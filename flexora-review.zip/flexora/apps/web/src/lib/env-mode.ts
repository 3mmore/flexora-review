/**
 * FLEXORA Gym OS — Web app
 * © 2024 Ammar Allam. All rights reserved.
 *
 * ROUND 17 (PHASE M1) — the browser bundle's counterpart to the API's
 * config/env-mode.ts, so both halves agree on what "production" means.
 *
 * Same rule, same reason: development is OPT-IN. The environment is production
 * unless NODE_ENV is exactly "development" or "test" after trimming and
 * lower-casing. An unset NODE_ENV, or "Production" with a capital P, is
 * production — not an accidental bypass of every production safeguard.
 *
 * Next.js inlines `process.env.NODE_ENV` at build time, so these collapse to
 * constants in the bundle; there is no runtime cost.
 */
export type EnvMode = 'development' | 'test' | 'production';

export function rawNodeEnv(): string {
  return (process.env.NODE_ENV || '').trim().toLowerCase();
}

export function envMode(): EnvMode {
  const raw = rawNodeEnv();
  if (raw === 'development') return 'development';
  if (raw === 'test') return 'test';
  return 'production';
}

export function isTest(): boolean {
  return envMode() === 'test';
}

export function isDevelopment(): boolean {
  return envMode() === 'development';
}

export function isProduction(): boolean {
  return !isDevelopment() && !isTest();
}
