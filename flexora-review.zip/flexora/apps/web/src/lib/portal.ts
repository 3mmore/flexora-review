'use client';
// Empty NEXT_PUBLIC_API_URL → same-origin proxy mode (BASE = '').
const configuredApi = (process.env.NEXT_PUBLIC_API_URL || '').replace(/\/$/, '');
const BASE = configuredApi ? (configuredApi.endsWith('/api') ? configuredApi.slice(0, -4) : configuredApi) : '';
function csrfToken() { if (typeof document === 'undefined') return null; return document.cookie.split(';').map((v) => v.trim()).find((v) => v.startsWith('_csrf='))?.slice(6) || null; }

// ROUND 14 (security review, PHASE F2): the member token is an HttpOnly,
// SameSite=Strict cookie set by the server with path=/ — JavaScript can
// neither read it (no token theft via XSS) nor is it needed in the request
// (the browser sends it to /api/portal/* because of the path). The client
// only keeps a NON-secret session INDICATOR cookie so pages can tell "logged
// in" from "logged out" without ever seeing the token.
export const MEMBER_SESSION_COOKIE = 'flx_member_session';
export function getMemberSession(): boolean {
  if (typeof document === 'undefined') return false;
  return document.cookie.split(';').map((v) => v.trim()).some((v) => v === MEMBER_SESSION_COOKIE + '=1');
}
/** Backwards-compatible alias — the token itself is never readable by JS. */
export function getMemberToken(): boolean { return getMemberSession(); }
export function setMemberSession(on: boolean) {
  if (typeof document !== 'undefined') {
    document.cookie = on
      ? `${MEMBER_SESSION_COOKIE}=1; path=/; SameSite=Strict`
      : `${MEMBER_SESSION_COOKIE}=; path=/; max-age=0; SameSite=Strict`;
  }
}
/** @deprecated the token is no longer returned to the client — kept as a no-op
 *  alias so old call sites compile; the server cookie is the only store. */
export function setMemberToken(_t: string | null) { setMemberSession(true); }
export function clearMemberSession() {
  setMemberSession(false);
  if (typeof document !== 'undefined') document.cookie = 'flx_member_access=; path=/; max-age=0; SameSite=Strict';
  if ('serviceWorker' in navigator && navigator.serviceWorker.controller) navigator.serviceWorker.controller.postMessage({ type: 'CLEAR_CACHE' });
}
export async function portalApi<T = unknown>(path: string, opts: RequestInit = {}): Promise<T> {
  // ROUND 14 (security review, PHASE F2): the member token travels ONLY in the
  // HttpOnly, SameSite=Strict cookie (path=/ — it reaches /api/portal/*), never
  // as a JS-readable value or a Bearer header. CSRF protection stays on for
  // state-changing portal routes (SameSite=Strict + the X-CSRF-Token header).
  const res = await fetch(`${BASE}/api${path}`, { ...opts, credentials: 'include', headers: { 'Content-Type': 'application/json', ...(csrfToken() && !['GET','HEAD'].includes(String(opts.method || 'GET').toUpperCase()) ? { 'X-CSRF-Token': csrfToken() as string } : {}), ...(opts.headers as Record<string, string>) } });
  if (res.status === 401 && typeof window !== 'undefined') { clearMemberSession(); window.location.href = '/portal/login'; }
  if (!res.ok) {
    const e = await res.json().catch(() => ({ message: res.statusText })) as { message?: string; code?: string; translationKey?: string };
    // ROUND 14 (Phase E): keep the structured body on the error so callers can
    // render translated messages (e.g. WHATSAPP_NOT_CONFIGURED on the login page).
    const err = new Error(e.message || `HTTP ${res.status}`) as Error & { body?: unknown };
    err.body = e;
    throw err;
  }
  return (res.status === 204 ? undefined as T : res.json()) as Promise<T>;
}
