const ALLOWED_REDIRECT_DOMAINS = ['checkout.stripe.com', 'billing.stripe.com', 'flexora.app', 'localhost'];

export function isAllowedRedirect(url: string): boolean {
  try {
    const parsed = new URL(url);
    if (parsed.hostname === 'localhost') return ['http:', 'https:'].includes(parsed.protocol);
    return parsed.protocol === 'https:' && ALLOWED_REDIRECT_DOMAINS.some((domain) => parsed.hostname === domain || parsed.hostname.endsWith(`.${domain}`));
  } catch {
    return false;
  }
}
