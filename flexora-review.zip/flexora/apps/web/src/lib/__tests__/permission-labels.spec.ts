import { readFileSync } from 'fs';
import { join } from 'path';
import { ar } from '../i18n/ar';
import { en } from '../i18n/en';

/**
 * PACK 2, item 1 — the permissions dialog must never paint English.
 *
 * The dialog used to render the API catalogue's own `label` field, which is an
 * English sentence ("Add members & leads"). It sits behind a click, so the
 * route crawl in check-arabic-ui.mjs never saw it and the Latin counter stayed
 * at 0 while the screen was in fact English. This test closes that hole from
 * the other side: it reads the API's permission catalogue from disk and fails
 * if any permission — current or future — has no non-empty Arabic label, or if
 * the two dictionaries disagree about a label key.
 */

const CATALOG = join(__dirname, '../../../../api/src/modules/permissions/permissions.catalog.ts');

function apiPermissions(): string[] {
  const src = readFileSync(CATALOG, 'utf8');
  const block = src.slice(src.indexOf('export const PERMISSIONS = ['), src.indexOf('];', src.indexOf('export const PERMISSIONS = [')));
  const keys = Array.from(block.matchAll(/'([a-z]+\.[a-z.\-]+)'/g)).map((m) => m[1]);
  return Array.from(new Set(keys));
}

function apiGroups(): string[] {
  const src = readFileSync(CATALOG, 'utf8');
  const start = src.indexOf('export const PERMISSION_GROUPS');
  const block = src.slice(start, src.indexOf('];', start));
  return Array.from(new Set(Array.from(block.matchAll(/key:\s*'([a-z]+)'/g)).map((m) => m[1])));
}

const AR = ar as Record<string, string>;
const EN = en as Record<string, string>;
const LATIN = /[A-Za-z]/;

describe('permission labels are translated, never English', () => {
  const perms = apiPermissions();
  const groups = apiGroups();

  it('reads a sane catalogue (guards the parser itself)', () => {
    expect(perms.length).toBeGreaterThan(20);
    expect(perms).toContain('members.backdate');
    expect(perms).toContain('members.view');
    expect(groups.length).toBeGreaterThan(10);
  });

  it('every permission has a non-empty Arabic label', () => {
    const missing = perms.filter((p) => {
      const k = `perm_${p.replace(/\./g, '_')}`;
      return !AR[k] || !AR[k].trim();
    });
    expect(missing).toEqual([]);
  });

  it('the Arabic permission label contains no Latin letters', () => {
    // Names of the permission KEYS are not shown; the visible label is Arabic.
    // Digits and punctuation are allowed (item 1 decision: Western digits).
    const latin = perms
      .map((p) => `perm_${p.replace(/\./g, '_')}`)
      .filter((k) => AR[k] && LATIN.test(AR[k]));
    expect(latin).toEqual([]);
  });

  it('every permission group has an Arabic label with no Latin letters', () => {
    const bad = groups.filter((g) => {
      const k = `permgroup_${g}`;
      return !AR[k] || !AR[k].trim() || LATIN.test(AR[k]);
    });
    expect(bad).toEqual([]);
  });

  it('ar and en carry exactly the same perm_* keys (no one-sided entry)', () => {
    const arKeys = Object.keys(AR).filter((k) => /^perm(group)?_/.test(k)).sort();
    const enKeys = Object.keys(EN).filter((k) => /^perm(group)?_/.test(k)).sort();
    expect(arKeys).toEqual(enKeys);
  });
});
