/**
 * PACK 2 · STEP 2.3 — the offline snapshot must be numbers, per account, and
 * gone after sign-out. Each test below is a leak that would otherwise reach a
 * shared desk tablet.
 */
import {
  clearSnapshot,
  pickSnapshot,
  readSnapshot,
  saveSnapshot,
  snapshotKey,
} from '../offline-snapshot';

describe('offline snapshot', () => {
  beforeEach(() => window.sessionStorage.clear());

  it('drops every field that is not one of the four numbers', () => {
    const snapshot = pickSnapshot(
      {
        checkinsToday: 12,
        activeMembers: 300,
        totalMembers: 420,
        expiringMembers: 7,
        // the rest of a dashboard payload — names, phones, ids, a token
        members: [{ name: 'أحمد', mobile: '01012345678' }],
        token: 'eyJhbGciOi...',
        gymName: 'صالة النخبة',
      },
      1_700_000_000_000,
    );
    expect(snapshot).toEqual({
      checkinsToday: 12,
      activeMembers: 300,
      totalMembers: 420,
      expiringMembers: 7,
      at: 1_700_000_000_000,
    });
    expect(JSON.stringify(snapshot)).not.toContain('أحمد');
    expect(JSON.stringify(snapshot)).not.toContain('01012345678');
  });

  it('stores nothing at all when there is not a single usable number', () => {
    expect(saveSnapshot('g1', 'u1', { members: [{ name: 'x' }] })).toBeNull();
    expect(window.sessionStorage.getItem(snapshotKey('g1', 'u1'))).toBeNull();
  });

  it('is scoped per gym AND per user — one account cannot read another', () => {
    saveSnapshot('g1', 'u1', { checkinsToday: 5 });
    expect(readSnapshot('g1', 'u2')).toBeNull();
    expect(readSnapshot('g2', 'u1')).toBeNull();
    expect(readSnapshot('g1', 'u1')?.checkinsToday).toBe(5);
  });

  it('survives a corrupt entry by returning null, not a broken object', () => {
    window.sessionStorage.setItem(snapshotKey('g1', 'u1'), '{not json');
    expect(readSnapshot('g1', 'u1')).toBeNull();
  });

  it('a saved object with a bogus "at" is repaired rather than trusted', () => {
    window.sessionStorage.setItem(
      snapshotKey('g1', 'u1'),
      JSON.stringify({ checkinsToday: 3, at: 'yesterday' }),
    );
    expect(readSnapshot('g1', 'u1')).toEqual({
      checkinsToday: 3,
      activeMembers: 0,
      totalMembers: 0,
      expiringMembers: 0,
      at: 0,
    });
  });

  it('sign-out removes this account’s snapshot', () => {
    saveSnapshot('g1', 'u1', { checkinsToday: 5 });
    clearSnapshot('g1', 'u1');
    expect(readSnapshot('g1', 'u1')).toBeNull();
  });

  it('sign-out with no ids known removes every snapshot this app wrote', () => {
    saveSnapshot('g1', 'u1', { checkinsToday: 5 });
    saveSnapshot('g1', 'u2', { checkinsToday: 9 });
    window.sessionStorage.setItem('unrelated', 'keep me');
    clearSnapshot();
    expect(readSnapshot('g1', 'u1')).toBeNull();
    expect(readSnapshot('g1', 'u2')).toBeNull();
    expect(window.sessionStorage.getItem('unrelated')).toBe('keep me');
  });

  it('uses sessionStorage, not localStorage — it dies with the tab', () => {
    saveSnapshot('g1', 'u1', { checkinsToday: 5 });
    expect(window.localStorage.getItem(snapshotKey('g1', 'u1'))).toBeNull();
  });
});
