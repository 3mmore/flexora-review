import { readFileSync, readdirSync, statSync } from 'fs';
import { join } from 'path';

/**
 * PACK 2, item 1/3 — ONE date format everywhere.
 *
 * The agreed format is dd/mm/yyyy with Western digits 0-9 (the owner's decision
 * for Pack 2). `toLocaleDateString()` alone breaks that twice over:
 *  · with no argument it uses the RUNTIME locale, so the same build paints
 *    "12/25/2026" on a US-English phone and "25/12/2026" on an Egyptian one;
 *  · with 'ar-EG' it paints Arabic-Indic digits (٢٥/١٢/٢٠٢٦), contradicting the
 *    Western-digits decision that the money, phone numbers and lists follow.
 *
 * `lib/dates.formatDate()` is the one place that renders dd/mm/yyyy in Western
 * digits, in the gym's time zone. This test keeps every screen on it: a new
 * `toLocaleDateString()` call without an explicit, digit-pinned locale fails.
 */

const ROOT = join(__dirname, '../../..');

function walk(dir: string, out: string[] = []): string[] {
  for (const entry of readdirSync(dir)) {
    if (entry === 'node_modules' || entry === '.next' || entry === 'dist') continue;
    const full = join(dir, entry);
    const st = statSync(full);
    if (st.isDirectory()) walk(full, out);
    else if (/\.(ts|tsx)$/.test(entry) && !/\.spec\.tsx?$/.test(entry)) out.push(full);
  }
  return out;
}

/** Files under src/ that render dates. */
const sources = walk(join(ROOT, 'src'));

describe('dates are rendered one way, in one format', () => {
  it('no bare toLocaleDateString() without a digit-pinned locale', () => {
    const offenders: string[] = [];
    for (const file of sources) {
      // doc comments discuss the very call this test bans; strip them first
      const src = readFileSync(file, 'utf8')
        .replace(/\/\*[\s\S]*?\*\//g, '')
        .replace(/^\s*\/\/.*$/gm, '');
      for (const m of src.matchAll(/toLocaleDateString\(([^)]*)/g)) {
        const args = m[1] || '';
        const pinned = /u-nu-latn/.test(args) || /'en-GB'/.test(args) || /'en-CA'/.test(args);
        if (!pinned) offenders.push(`${file.replace(ROOT, '')}: toLocaleDateString(${args.trim().slice(0, 40)}`);
      }
    }
    expect(offenders).toEqual([]);
  });

  it('no toLocaleDateString at all inside the tenant app shell screens', () => {
    // The members/money/attendance screens are the ones the owner sees on a
    // phone every day; they must use formatDate() so the format is dd/mm/yyyy.
    const shellScreens = [
      'src/app/members/page.tsx',
      'src/app/pos/page.tsx',
      'src/app/expenses/page.tsx',
      'src/app/inventory/page.tsx',
      'src/app/accounting/page.tsx',
      'src/app/classes/page.tsx',
      'src/app/backups/page.tsx',
      'src/app/license/page.tsx',
      'src/app/leads/page.tsx',
      'src/app/transfers/page.tsx',
    ];
    const offenders = shellScreens.filter((rel) => readFileSync(join(ROOT, rel), 'utf8').includes('toLocaleDateString'));
    expect(offenders).toEqual([]);
  });

  it('formatDate renders dd/mm/yyyy in Western digits for a known instant', () => {
    // 25 Dec 2026 10:00 Cairo (EET, UTC+2) = 08:00Z
    const { formatDate } = require('../../lib/dates');
    expect(formatDate(new Date('2026-12-25T08:00:00.000Z'))).toBe('25/12/2026');
    // and it does not drift at 23:59 Cairo (21:59Z) — the day is Cairo's
    expect(formatDate(new Date('2026-12-25T21:59:00.000Z'))).toBe('25/12/2026');
    expect(formatDate(new Date('2026-12-25T22:00:00.000Z'))).toBe('26/12/2026');
    expect(formatDate(null)).toBe('—');
  });
});
