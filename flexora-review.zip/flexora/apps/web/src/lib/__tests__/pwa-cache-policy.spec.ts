/**
 * PACK 2 · STEP 2.3 — the cache policy, and the proof that the service worker
 * obeys it.
 *
 * The unit tests pin `decideFetch`. The source tests open `public/sw.js` and
 * assert the invariants that would leak data between accounts on a shared
 * device. Those two together are why the earlier behaviour — caching any
 * navigation HTML stale-while-revalidate — is gone: a source test cannot be
 * satisfied by a comment, and a unit test cannot be satisfied by a service
 * worker that ignores it.
 */
import fs from 'fs';
import path from 'path';
import { CACHE_NAME, decideFetch, pathOf } from '../pwa-cache-policy';

describe('decideFetch — what a service worker may store', () => {
  it('never caches any API response, of any shape', () => {
    for (const url of [
      '/api/portal/me',
      '/api/members?page=1',
      'http://localhost:3000/api/attendance/daily-summary',
      '/api',
      '/api/',
    ]) {
      expect(decideFetch({ method: 'GET', url, navigation: false })).toBe('network-only');
    }
  });

  it('never caches a non-GET request', () => {
    expect(decideFetch({ method: 'POST', url: '/members', navigation: false })).toBe('network-only');
  });

  it('never stores navigation HTML — it falls back to the offline page instead', () => {
    for (const url of ['/dashboard', '/members', '/portal/dashboard', '/more']) {
      expect(decideFetch({ method: 'GET', url, navigation: true })).toBe('navigation-network-first');
    }
  });

  it('caches build output, which contains no account data', () => {
    for (const url of ['/_next/static/chunk.js', '/icon-192.png', '/globals.css', '/manifest-staff.webmanifest']) {
      expect(decideFetch({ method: 'GET', url, navigation: false })).toBe('asset-cache-first');
    }
  });

  it('treats an unknown GET as network-only rather than guessing', () => {
    expect(decideFetch({ method: 'GET', url: '/something/opaque', navigation: false })).toBe('network-only');
  });

  it('does not confuse /apiary with /api', () => {
    expect(decideFetch({ method: 'GET', url: '/apiary.css', navigation: false })).toBe('asset-cache-first');
  });

  it('strips query strings before deciding', () => {
    expect(pathOf('/api/members?x=1')).toBe('/api/members');
    expect(pathOf('https://gym.example/api/x?a=1')).toBe('/api/x');
  });
});

describe('public/sw.js obeys the policy in source', () => {
  const sw = fs.readFileSync(path.join(process.cwd(), 'public', 'sw.js'), 'utf8');
  const code = sw.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');

  it('is on the current cache version (old caches are deleted on activate)', () => {
    expect(code).toContain(`const CACHE_VERSION = '${CACHE_NAME}'`);
  });

  it('never puts a navigation/HTML response into a cache', () => {
    // Slice out the navigation branch itself (from its guard to its `return;`)
    // and assert the whole branch contains no write to Cache Storage. A looser
    // window would match the ASSET branch that follows it — the first version of
    // this test did exactly that and failed on correct code.
    const start = code.indexOf("request.mode === 'navigate'");
    expect(start).toBeGreaterThan(-1);
    const end = code.indexOf('return;', start);
    expect(end).toBeGreaterThan(start);
    const branch = code.slice(start, end);
    expect(branch).not.toContain('.put(');
    expect(branch).not.toContain('caches.open');
    expect(branch).toContain('OFFLINE_URL');
  });

  it('short-circuits every /api request before any caching branch', () => {
    const apiBranch = code.indexOf("startsWith('/api/')");
    expect(apiBranch).toBeGreaterThan(-1);
    const firstPut = code.indexOf('.put(');
    expect(apiBranch).toBeLessThan(firstPut === -1 ? code.length : firstPut);
  });

  it('keeps the logout purge', () => {
    expect(code).toContain("type === 'CLEAR_CACHE'");
    expect(code).toContain('caches.delete');
  });

  it('serves the offline page for a failed navigation instead of stale HTML', () => {
    expect(code).toMatch(/caches\.match\('\/offline'\)|OFFLINE_URL/);
  });
});
