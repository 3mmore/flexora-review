/**
 * PACK 2 · ITEM 5 — the attendance CSV download, as pure functions.
 *
 * The page keeps the click handler; the two things that can silently go wrong
 * live here so they can be tested without a browser:
 *   1. the download must carry the SAME branch filter the table shows — a file
 *      that disagrees with the screen is a support ticket in both directions;
 *   2. an empty filter must send NO branchId at all rather than `branchId=`,
 *      which the API would read as "a branch whose id is the empty string" and
 *      answer with nothing.
 */
export function buildAttendanceCsvUrl(
  baseUrl: string,
  branchId: string | null | undefined,
  source?: string | null,
): string {
  const qs = new URLSearchParams({ format: 'csv' });
  const id = (branchId ?? '').trim();
  if (id) qs.set('branchId', id);
  // PACK 2 item 5: the file must contain the rows the screen is filtered to
  const src = (source ?? '').trim();
  if (src) qs.set('source', src);
  return `${baseUrl.replace(/\/+$/, '')}/attendance?${qs.toString()}`;
}

/** the server names the file; fall back only if it does not */
export function attendanceCsvFilename(contentDisposition: string | null): string {
  if (!contentDisposition) return 'attendance.csv';
  const star = /filename\*=UTF-8''([^;]+)/i.exec(contentDisposition);
  if (star?.[1]) {
    try {
      return decodeURIComponent(star[1].trim().replace(/^"|"$/g, ''));
    } catch {
      /* fall through */
    }
  }
  const plain = /filename="?([^";]+)"?/i.exec(contentDisposition);
  const name = plain?.[1]?.trim();
  // never let a header choose a path: keep the last segment only
  return name ? name.split(/[\\/]/).pop() || 'attendance.csv' : 'attendance.csv';
}
