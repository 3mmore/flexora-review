import type { ProductModule, RuntimeAction, ProductSignal } from './PRODUCT_RUNTIME_ENGINE';

export interface BusinessTrace {
  id: string;
  module: ProductModule;
  action?: RuntimeAction;
  signals: ProductSignal[];
  reasoning: string;
  at: string;
  result?: 'planned' | 'executed' | 'failed';
}

let traceMemory: BusinessTrace[] = [];

export function readBusinessTraces(): BusinessTrace[] { return traceMemory; }

export function traceBusinessDecision(trace: Omit<BusinessTrace, 'id' | 'at'>): BusinessTrace {
  const full: BusinessTrace = { id: `trace_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`, at: new Date().toISOString(), result: 'planned', ...trace };
  traceMemory = [full, ...readBusinessTraces()].slice(0, 100);
  return full;
}

export function auditActionChain(module: ProductModule): BusinessTrace[] {
  return readBusinessTraces().filter((trace) => trace.module === module);
}

export function visualizeSystemFlow(): Array<{ module: ProductModule; count: number; latest?: string }> {
  const map = new Map<ProductModule, { module: ProductModule; count: number; latest?: string }>();
  for (const trace of readBusinessTraces()) {
    const cur = map.get(trace.module) || { module: trace.module, count: 0 };
    cur.count += 1;
    cur.latest ||= trace.at;
    map.set(trace.module, cur);
  }
  return Array.from(map.values()).sort((a, b) => b.count - a.count);
}
