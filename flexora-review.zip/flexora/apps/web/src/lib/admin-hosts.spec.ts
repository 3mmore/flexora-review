/**
 * FLEXORA Gym OS - Web
 * (c) 2024 Ammar Allam. All rights reserved.
 */
/**
 * PHASE R0 - the web mirror of the ADMIN_HOSTS gate.
 *
 * The host cases are read from the API's admin-host-cases.json: ONE table, TWO
 * implementations (Node/Nest and edge/middleware cannot share a module). If either
 * side drifts, one of the two suites fails on the same case name - the same parity
 * mechanism the repo already uses for en.ts/ar.ts.
 */
import { readFileSync } from 'fs';
import { join } from 'path';

import {
  ADMIN_HOSTS_DEV_DEFAULT,
  ADMIN_HOSTS_VAR,
  adminHostVerdict,
  adminHostsConfig,
  consoleFamily,
  consolePathVariants,
  isConsolePath,
  isLookalikePath,
  parseAdminHosts,
  resolveDotSegments,
  splitHostHeader,
  stripRootDot,
  trustProxyHops,
} from './admin-hosts';

interface HostCase {
  name: string;
  adminHosts: string | null;
  nodeEnv: string;
  hops: number | null;
  host: string | null;
  xfh: string | null;
  allowed: boolean;
  reason?: string;
}
interface PathCase {
  name: string;
  path: string;
  console: boolean;
}

// lib -> src -> web -> apps -> repo root, then into the api workspace
const TABLE = join(__dirname, '..', '..', '..', '..', 'apps', 'api', 'src', 'config', 'admin-host-cases.json');
const CASES = JSON.parse(readFileSync(TABLE, 'utf8')) as { hostCases: HostCase[]; pathCases: PathCase[] };

/** Next's ambient types mark env.NODE_ENV readonly; tests need to change it. */
const env = process.env as Record<string, string | undefined>;

const ENV_KEYS = [ADMIN_HOSTS_VAR, 'TRUST_PROXY_HOPS', 'NODE_ENV'] as const;
let saved: Record<string, string | undefined> = {};

beforeEach(() => {
  saved = {};
  for (const key of ENV_KEYS) saved[key] = env[key];
});
afterEach(() => {
  for (const key of ENV_KEYS) {
    if (saved[key] === undefined) delete env[key];
    else env[key] = saved[key];
  }
});

function setEnv(adminHosts: string | null, nodeEnv: string, hops: number | null) {
  if (adminHosts === null) delete env[ADMIN_HOSTS_VAR];
  else env[ADMIN_HOSTS_VAR] = adminHosts;
  env.NODE_ENV = nodeEnv;
  if (hops === null) delete env.TRUST_PROXY_HOPS;
  else env.TRUST_PROXY_HOPS = String(hops);
}

describe('PHASE R0 - shared host-case table (parity with the api implementation)', () => {
  it('1. the table is loaded from the api workspace and is not empty', () => {
    expect(CASES.hostCases.length).toBeGreaterThanOrEqual(35);
    expect(CASES.pathCases.length).toBeGreaterThanOrEqual(20);
  });

  it.each(CASES.hostCases)(
    '2. $name',
    ({ adminHosts: hosts, nodeEnv, hops, host, xfh, allowed, reason }) => {
      setEnv(hosts, nodeEnv, hops);
      const verdict = adminHostVerdict(host ?? undefined, xfh ?? undefined);
      expect(verdict.allowed).toBe(allowed);
      if (!allowed && reason) expect((verdict as { reason: string }).reason).toBe(reason);
    },
  );
});

describe('PHASE R0 - console path recognition (middleware runs before routing, so it must be conservative)', () => {
  it.each(CASES.pathCases)('3. $name', ({ path, console: expected }) => {
    expect(isConsolePath(path)).toBe(expected);
  });

  it('4. the family decides how the gate refuses: /api paths must be refused with an API-shaped 404', () => {
    expect(consoleFamily('/platform/login')).toBe('page');
    expect(consoleFamily('/platform')).toBe('page');
    expect(consoleFamily('/api/platform/overview')).toBe('api');
    expect(consoleFamily('/api/platform/auth/login')).toBe('api');
    expect(consoleFamily('/%61pi/platform/gyms')).toBe('api');
    expect(consoleFamily('/dashboard')).toBeNull();
    expect(consoleFamily('/platformer')).toBeNull();
  });

  it('5. decorated spellings are still recognised (a URL can be decorated; the gate must not be)', () => {
    const variants = consolePathVariants('/%70latform/login');
    expect(variants).toContain('/platform/login');
    expect(consolePathVariants('//platform/login')).toContain('/platform/login');
    expect(consolePathVariants('/dashboard/../platform/gyms')).toContain('/platform/gyms');
    expect(resolveDotSegments('/a/./b/../platform')).toBe('/a/platform');
    expect(resolveDotSegments('/../../platform')).toBe('/platform');
  });

  it('6. a malformed escape sequence cannot make the gate throw (it just is not a console path)', () => {
    expect(() => consolePathVariants('/%zz/platform')).not.toThrow();
    expect(isConsolePath('/%zz/platform')).toBe(false);
  });

  it('7. lookalike paths are not console paths, so the tenant app is never over-blocked', () => {
    for (const path of ['/platformer', '/platform-x', '/api/platforms']) {
      expect(isLookalikePath(path)).toBe(true);
      expect(isConsolePath(path)).toBe(false);
    }
  });
});

describe('PHASE R0 - configuration semantics on the web side', () => {
  it('8. outside production an unset value falls back to the loopback-only default (trial mode)', () => {
    delete env[ADMIN_HOSTS_VAR];
    const config = adminHostsConfig('development');
    expect(config.usingDevDefault).toBe(true);
    expect(config.entries.map((e) => e.hostname)).toEqual(['localhost', '127.0.0.1']);
    expect(ADMIN_HOSTS_DEV_DEFAULT).toBe('localhost,127.0.0.1');
  });

  it('9. in production an unset value refuses every host, including localhost (fail closed)', () => {
    delete env[ADMIN_HOSTS_VAR];
    expect(adminHostsConfig('production').entries).toEqual([]);
    expect(adminHostVerdict('localhost', undefined, adminHostsConfig('production')).allowed).toBe(false);
  });

  it('10. reads the environment at CALL time, never at module scope', () => {
    env.NODE_ENV = 'production';
    env[ADMIN_HOSTS_VAR] = 'first.test';
    expect(adminHostVerdict('first.test', undefined).allowed).toBe(true);
    env[ADMIN_HOSTS_VAR] = 'second.test';
    expect(adminHostVerdict('first.test', undefined).allowed).toBe(false);
    expect(adminHostVerdict('second.test', undefined).allowed).toBe(true);
  });

  it('11. the default hop count is the documented 1, matching the api and the shipped nginx', () => {
    delete env.TRUST_PROXY_HOPS;
    expect(trustProxyHops()).toBe(1);
    env.TRUST_PROXY_HOPS = '0';
    expect(trustProxyHops()).toBe(0);
    env.TRUST_PROXY_HOPS = 'not-a-number';
    expect(trustProxyHops()).toBe(1);
    env.TRUST_PROXY_HOPS = '99';
    expect(trustProxyHops()).toBe(1);
  });

  it('12. parsing rules match the api: no wildcard, no scheme, no path, ports and IPv6 supported', () => {
    expect(parseAdminHosts('*').entries).toEqual([]);
    expect(parseAdminHosts('https://admin.test').entries).toEqual([]);
    expect(parseAdminHosts('admin.test/platform').entries).toEqual([]);
    expect(parseAdminHosts('admin.test:8443').entries).toEqual([{ hostname: 'admin.test', port: '8443' }]);
    expect(parseAdminHosts('::1').entries).toEqual([{ hostname: '::1' }]);
    expect(parseAdminHosts('[::1]:8443').entries).toEqual([{ hostname: '::1', port: '8443' }]);
    expect(stripRootDot('admin.test.')).toBe('admin.test');
    expect(splitHostHeader('ADMIN.test:443')).toEqual({ hostname: 'admin.test', port: '443', raw: 'admin.test:443' });
  });
});
