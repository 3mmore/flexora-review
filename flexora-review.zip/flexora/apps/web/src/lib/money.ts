/**
 * Locale-aware money formatting (P4-6).
 * Never hard-codes "EGP" inside Arabic text — uses ج.م in Arabic mode.
 * Reads the persisted lang directly from localStorage so it can be used by
 * module-level helpers outside React hooks.
 */

export const currencyLabel = (): string =>
  typeof window !== 'undefined' && localStorage.getItem('flexora-lang') === 'ar'
    ? 'ج.م'
    : 'EGP';

export const fmtMoney = (value?: number | string): string =>
  `${Math.round(Number(value || 0)).toLocaleString()} ${currencyLabel()}`;
