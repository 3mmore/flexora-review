/**
 * FLEXORA Gym OS - Web
 * (c) 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1.8 / owner decision D1 - the owner console's Content-Security-Policy.
 *
 * Applied by src/middleware.ts to console PAGES only, and only when the request's
 * hostname is in ADMIN_HOSTS. Tenant pages never reach it and keep the policy from
 * next.config.mjs byte for byte (asserted in src/middleware.console-csp.spec.ts).
 *
 * The nonce is generated per request in the middleware with crypto.getRandomValues
 * (128 bits, base64), passed to the app in the x-csp-nonce REQUEST header so Next
 * can put it on the scripts it injects, and set on the RESPONSE inside the policy.
 * It is never reused and never persisted.
 *
 * TWO MEASURED CONSTRAINTS, both reported rather than papered over:
 *
 * 1. 'strict-dynamic' is OFF. With it, CSP3 says host-source expressions including
 *    'self' are IGNORED for script-src, so only nonce'd scripts (and what they
 *    create) may run. The console's brand pre-paint script - moved out of the root
 *    layout to a static same-origin file in PHASE R0 - is rendered by app/layout.tsx
 *    WITHOUT a nonce, and the root layout cannot read one: calling headers() there
 *    makes every page in the tenant app dynamic, which is exactly what R0 rejected.
 *    Turning 'strict-dynamic' on would therefore block the pre-paint script and undo
 *    an R0 decision. Everything D1 asked for is kept - no 'unsafe-inline', no
 *    'unsafe-eval', a per-request nonce - and this one keyword is off for a stated,
 *    measured reason. Flip CONSOLE_CSP_USE_STRICT_DYNAMIC to see it fail.
 *
 * 2. 'upgrade-insecure-requests' is omitted. The trial/local posture serves the
 *    console over plain http on localhost (ADMIN_HOSTS defaults to
 *    localhost,127.0.0.1), and that directive would rewrite every subresource to
 *    https and break it. In production nginx terminates TLS, 301s http to https and
 *    sends Strict-Transport-Security, which is the layer that belongs to this job.
 *
 * What style-src and font-src need was determined by measurement, not guesswork:
 * the Playwright proof in work/r1-console-csp.spec.js collects every CSP violation
 * the console actually produces at 375px and the run must show zero. The first run
 * showed four, all from the Google Fonts stylesheet the root layout loads, which is
 * why those two origins appear below and nowhere else in the policy.
 */

/** 128 bits of nonce, base64 encoded. */
export const CONSOLE_CSP_NONCE_BYTES = 16;

/** The console-only sink for violation reports (behind the R0 host gate). */
export const CONSOLE_CSP_REPORT_PATH = '/api/platform/auth/csp-report';

/** See constraint 1 above. Off on purpose; flipping it breaks the pre-paint script. */
export const CONSOLE_CSP_USE_STRICT_DYNAMIC = false;

/**
 * A fresh nonce. crypto.getRandomValues is available in both the edge runtime and
 * Node, and is the CSPRNG D1 named. The base64 alphabet is CSP-safe as long as the
 * value is quoted, which consoleContentSecurityPolicy does.
 */
export function newCspNonce(): string {
  const bytes = new Uint8Array(CONSOLE_CSP_NONCE_BYTES);
  crypto.getRandomValues(bytes);
  let binary = '';
  for (let index = 0; index < bytes.length; index++) binary += String.fromCharCode(bytes[index]);
  return btoa(binary);
}

/**
 * The policy for one console document. Built from the directives D1 specified, in
 * a fixed order so the string is stable enough to assert on in a test.
 */
export function consoleContentSecurityPolicy(nonce: string): string {
  const quotedNonce = `'nonce-${nonce}'`;
  const scriptSources = [`'self'`, quotedNonce];
  if (CONSOLE_CSP_USE_STRICT_DYNAMIC) scriptSources.push(`'strict-dynamic'`);
  const directives: string[] = [
    `default-src 'none'`,
    `script-src ${scriptSources.join(' ')}`,
    // MEASURED, not guessed (work/r1-evidence, r1-console-csp.spec.js): the root
    // layout loads Inter and Cairo from fonts.googleapis.com, and the Arabic-first
    // console needs Cairo. With only 'self' and the nonce, Chromium reported four
    // violations per console page load and posted four reports to the sink. These
    // two origins are stylesheet and font sources only - no script - and the tenant
    // policy already allows exactly them.
    `style-src 'self' ${quotedNonce} https://fonts.googleapis.com`,
    `img-src 'self' data:`,
    `font-src 'self' data: https://fonts.gstatic.com`,
    `connect-src 'self'`,
    `form-action 'self'`,
    `base-uri 'none'`,
    `object-src 'none'`,
    `frame-ancestors 'none'`,
    `report-uri ${CONSOLE_CSP_REPORT_PATH}`,
  ];
  return directives.join('; ');
}

/**
 * The rest of the console page header set (R1.8). nginx applies the same values at
 * the edge for the whole /platform location, including responses a guard produces;
 * these are what a directly-exposed Next server sends.
 */
export function consoleResponseHeaders(): ReadonlyArray<readonly [string, string]> {
  return [
    ['Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0'],
    ['Pragma', 'no-cache'],
    ['Expires', '0'],
    ['Referrer-Policy', 'no-referrer'],
    ['X-Robots-Tag', 'noindex, nofollow, noarchive'],
    ['X-Frame-Options', 'DENY'],
    ['X-Content-Type-Options', 'nosniff'],
  ];
}
