/**
 * PACK 2 · STEP 2.3 — "last seen" when the phone has no signal.
 *
 * The honest scope: a web app cannot fetch anything offline. What it CAN do is
 * remember the four numbers it last showed on Home, so the owner standing in the
 * basement does not face a blank screen when someone asks "how many came in
 * today?".
 *
 * The rules this file enforces (and its spec proves):
 *   1. ONLY a fixed whitelist of NUMBERS is stored. No names, no phones, no ids
 *      of members, no tokens — `pickSnapshot` drops anything else, so a future
 *      caller cannot leak a record by passing the whole dashboard payload.
 *   2. sessionStorage, not localStorage: it dies with the tab, so a tablet left
 *      at the desk does not keep yesterday's numbers for the next shift.
 *   3. The key is scoped by gym + user, and `clearSnapshot()` is called on sign
 *      out, so two accounts on one device never read each other's snapshot.
 *   4. Every read is defensive: corrupt or foreign JSON returns null, never a
 *      half-parsed object.
 */

export interface LastSeen {
  checkinsToday: number;
  activeMembers: number;
  totalMembers: number;
  expiringMembers: number;
  /** epoch ms when it was captured */
  at: number;
}

const FIELDS = ['checkinsToday', 'activeMembers', 'totalMembers', 'expiringMembers'] as const;
const KEY_PREFIX = 'flexora:last-seen';

/** Only numbers survive. Anything else in the input is discarded by design. */
export function pickSnapshot(input: unknown, at: number = Date.now()): LastSeen | null {
  if (!input || typeof input !== 'object') return null;
  const source = input as Record<string, unknown>;
  const out: Partial<LastSeen> = {};
  let any = false;
  for (const field of FIELDS) {
    const value = source[field];
    if (typeof value === 'number' && Number.isFinite(value)) {
      out[field] = value;
      any = true;
    }
  }
  if (!any) return null;
  return {
    checkinsToday: out.checkinsToday ?? 0,
    activeMembers: out.activeMembers ?? 0,
    totalMembers: out.totalMembers ?? 0,
    expiringMembers: out.expiringMembers ?? 0,
    at,
  };
}

/** The storage key for one account on one device. */
export function snapshotKey(gymId: string, userId: string): string {
  return `${KEY_PREFIX}:${gymId}:${userId}`;
}

function storage(): Storage | null {
  try {
    if (typeof window === 'undefined' || !window.sessionStorage) return null;
    return window.sessionStorage;
  } catch {
    // Safari private mode, disabled storage, iframe sandbox — never throw
    return null;
  }
}

export function saveSnapshot(gymId: string, userId: string, input: unknown): LastSeen | null {
  const snapshot = pickSnapshot(input);
  const store = storage();
  if (!snapshot || !store) return snapshot;
  try {
    store.setItem(snapshotKey(gymId, userId), JSON.stringify(snapshot));
  } catch {
    /* quota or disabled — the app keeps working, just without the snapshot */
  }
  return snapshot;
}

export function readSnapshot(gymId: string, userId: string): LastSeen | null {
  const store = storage();
  if (!store) return null;
  try {
    const raw = store.getItem(snapshotKey(gymId, userId));
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Record<string, unknown>;
    const snapshot = pickSnapshot(parsed, typeof parsed?.at === 'number' ? parsed.at : 0);
    return snapshot;
  } catch {
    return null;
  }
}

/** Sign-out and account switch must not leave a readable snapshot behind. */
export function clearSnapshot(gymId?: string, userId?: string): void {
  const store = storage();
  if (!store) return;
  try {
    if (gymId && userId) {
      store.removeItem(snapshotKey(gymId, userId));
      return;
    }
    // no ids known (e.g. a failed sign-in): drop every snapshot this app wrote
    const doomed: string[] = [];
    for (let i = 0; i < store.length; i += 1) {
      const key = store.key(i);
      if (key && key.startsWith(KEY_PREFIX)) doomed.push(key);
    }
    doomed.forEach((key) => store.removeItem(key));
  } catch {
    /* ignore */
  }
}
