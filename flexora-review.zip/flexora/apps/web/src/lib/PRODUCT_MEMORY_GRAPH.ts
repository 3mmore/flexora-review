import type { ProductModule, ProductSignal, RuntimeAction, RuntimeEvent } from './PRODUCT_RUNTIME_ENGINE';

export interface ProductMemoryGraph {
  last_actions_by_module: Partial<Record<ProductModule, RuntimeEvent>>;
  unresolved_risks: ProductSignal[];
  repeated_business_patterns: Array<{ id: string; module: ProductModule; count: number; lastSeenAt: string }>;
  user_decision_history: RuntimeEvent[];
  module_interaction_sequence: ProductModule[];
  time_series_behavior: Array<{ module: ProductModule; signalId: string; at: string }>;
  seasonal_business_behavior: Array<{ key: string; month: number; count: number }>;
}

let memoryGraph: ProductMemoryGraph | null = null;

export function defaultProductMemoryGraph(): ProductMemoryGraph {
  return {
    last_actions_by_module: {},
    unresolved_risks: [],
    repeated_business_patterns: [],
    user_decision_history: [],
    module_interaction_sequence: [],
    time_series_behavior: [],
    seasonal_business_behavior: [],
  };
}

export function readProductMemoryGraph(): ProductMemoryGraph { return memoryGraph ? { ...defaultProductMemoryGraph(), ...memoryGraph } : defaultProductMemoryGraph(); }

export function writeProductMemoryGraph(memory: ProductMemoryGraph) { memoryGraph = memory; }

export function rememberRuntimeDecision(module: ProductModule, action: RuntimeAction, entityId?: string) {
  const memory = readProductMemoryGraph();
  const event: RuntimeEvent = { module, actionId: action.id, label: action.label, entityId, at: new Date().toISOString() };
  memory.last_actions_by_module[module] = event;
  memory.user_decision_history = [event, ...memory.user_decision_history].slice(0, 50);
  memory.module_interaction_sequence = [module, ...memory.module_interaction_sequence.filter((m) => m !== module)].slice(0, 12);
  writeProductMemoryGraph(memory);
}

export function rememberSignals(module: ProductModule, signals: ProductSignal[]) {
  const memory = readProductMemoryGraph();
  const risks = signals.filter((s) => s.kind === 'risk');
  memory.unresolved_risks = [...risks, ...memory.unresolved_risks]
    .filter((risk, index, arr) => arr.findIndex((item) => item.id === risk.id) === index)
    .slice(0, 30);
  for (const risk of risks) {
    const existing = memory.repeated_business_patterns.find((p) => p.id === risk.id);
    if (existing) {
      existing.count += 1;
      existing.lastSeenAt = new Date().toISOString();
    } else {
      memory.repeated_business_patterns.push({ id: risk.id, module, count: 1, lastSeenAt: new Date().toISOString() });
    }
  }
  memory.time_series_behavior = [
    ...risks.map((risk) => ({ module, signalId: risk.id, at: new Date().toISOString() })),
    ...memory.time_series_behavior,
  ].slice(0, 500);
  const month = new Date().getMonth() + 1;
  for (const risk of risks) {
    const key = `${module}:${risk.id}:${month}`;
    const seasonal = memory.seasonal_business_behavior.find((item) => item.key === key);
    if (seasonal) seasonal.count += 1;
    else memory.seasonal_business_behavior.push({ key, month, count: 1 });
  }
  memory.repeated_business_patterns = memory.repeated_business_patterns.slice(-50);
  memory.seasonal_business_behavior = memory.seasonal_business_behavior.slice(-100);
  writeProductMemoryGraph(memory);
}

export function predictedNextModule(memory = readProductMemoryGraph()): ProductModule | undefined {
  const [current, previous] = memory.module_interaction_sequence;
  if (current === 'members' && previous === 'attendance') return 'campaigns';
  if (current === 'sales' && previous === 'inventory') return 'pos';
  if (current === 'reports') return 'ai';
  return memory.module_interaction_sequence[1];
}

export function detectRecurringBusinessCycles(memory = readProductMemoryGraph()) {
  return memory.repeated_business_patterns
    .filter((pattern) => pattern.count >= 3)
    .map((pattern) => ({
      ...pattern,
      recommendation: 'Recurring pattern detected. Review the linked module before the next cycle repeats.',
    }));
}
