/**
 * PACK 2 / ITEM 1 — Arabic dates, weekdays and money.
 *
 * The owner's decision (accepted): Arabic month and weekday NAMES, Western
 * digits 0-9, Arabic currency wording, dd/mm/yyyy. `toLocaleDateString('ar-EG')`
 * in this runtime does not follow that: it returns Arabic-Indic digits and, for
 * `weekday: 'short'`, sometimes Latin abbreviations. So the names live here as
 * constants and every screen formats through these helpers instead of calling
 * toLocaleDateString with the ambient locale.
 */

export const AR_WEEKDAYS_SHORT = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'] as const;
export const AR_WEEKDAYS_LONG = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'] as const;
export const AR_MONTHS_SHORT = [
  'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
  'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
] as const;
export const EN_WEEKDAYS_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'] as const;
export const EN_MONTHS_SHORT = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'] as const;

/** Day-of-week name in the given language. 0 = Sunday, matching Date#getDay. */
export function weekdayName(date: Date | string | number, lang: 'ar' | 'en' = 'ar', short = true): string {
  const d = date instanceof Date ? date : new Date(date);
  const i = d.getDay();
  if (lang === 'en') return (short ? EN_WEEKDAYS_SHORT : EN_WEEKDAYS_SHORT)[i];
  return short ? AR_WEEKDAYS_SHORT[i] : AR_WEEKDAYS_LONG[i];
}

/** Month name (0-based like Date#getMonth). */
export function monthName(monthIndex: number, lang: 'ar' | 'en' = 'ar'): string {
  const i = ((monthIndex % 12) + 12) % 12;
  return lang === 'en' ? EN_MONTHS_SHORT[i] : AR_MONTHS_SHORT[i];
}

const two = (n: number) => String(n).padStart(2, '0');

/**
 * dd/mm/yyyy in Western digits, the agreed date format.
 * `tz` is an IANA zone (Africa/Cairo by default) so a 23:59 Cairo sale stays on
 * its own day regardless of where the server runs.
 */
export function formatDate(value: Date | string | number | null | undefined, tz = 'Africa/Cairo'): string {
  if (value === null || value === undefined || value === '') return '—';
  const d = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(+d)) return '—';
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit',
  }).formatToParts(d);
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? '';
  return `${get('day')}/${get('month')}/${get('year')}`;
}

/** A calendar day + Arabic weekday, e.g. «الأحد 14/11/2026». */
export function formatDayWithWeekday(value: Date | string | number | null | undefined, lang: 'ar' | 'en' = 'ar'): string {
  if (value === null || value === undefined || value === '') return '—';
  return `${weekdayName(value, lang)} ${formatDate(value)}`;
}

/**
 * Money with Western digits and Arabic currency wording (ج.م) for Arabic.
 * Never uses toLocaleString with an Arabic locale: that switches the digits.
 */
export function formatMoney(value: number | string | null | undefined, lang: 'ar' | 'en' = 'ar', currency = 'EGP'): string {
  const n = Number(value ?? 0);
  const safe = Number.isFinite(n) ? n : 0;
  const digits = safe.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
  const unit = currency === 'EGP' ? (lang === 'ar' ? 'ج.م' : 'EGP') : currency;
  return `${digits} ${unit}`;
}

/** Western-digit integer with thousands separators. */
export function formatNumber(value: number | string | null | undefined): string {
  const n = Number(value ?? 0);
  return (Number.isFinite(n) ? n : 0).toLocaleString('en-US');
}
