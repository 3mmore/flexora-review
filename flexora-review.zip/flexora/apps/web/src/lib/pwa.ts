'use client';
/**
 * FLEXORA Gym OS — PWA helpers (service worker, push, cache purge)
 * © 2024 Ammar Allam. All rights reserved.
 */
import { portalApi } from './portal';

/** Registers the portal service worker. Safe to call repeatedly. */
export async function registerServiceWorker(): Promise<ServiceWorkerRegistration | null> {
  if (typeof window === 'undefined' || !('serviceWorker' in navigator)) return null;
  try {
    const reg = await navigator.serviceWorker.register('/sw.js', { scope: '/' });
    return reg;
  } catch {
    return null;
  }
}

/**
 * Logout cache purge. Tells the SW to delete every cache so the next member
 * on this device cannot read the previous account's cached pages. Also clears
 * Cache Storage directly as a fallback if the SW is not yet controlling.
 */
export async function clearMemberCaches(): Promise<void> {
  if (typeof window === 'undefined') return;
  // 1) Ask the active SW to purge (it owns the caches it created).
  try {
    const sw = navigator.serviceWorker?.controller;
    if (sw) {
      await new Promise<void>((resolve) => {
        const channel = new MessageChannel();
        channel.port1.onmessage = () => resolve();
        sw.postMessage({ type: 'CLEAR_CACHE' }, [channel.port2]);
        // Don't hang logout if the SW never replies.
        setTimeout(resolve, 1000);
      });
    }
  } catch {
    /* ignore */
  }
  // 2) Fallback: purge Cache Storage directly.
  try {
    if ('caches' in window) {
      const keys = await caches.keys();
      await Promise.all(keys.map((k) => caches.delete(k)));
    }
  } catch {
    /* ignore */
  }
}

function urlBase64ToUint8Array(base64String: string): BufferSource {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const raw = atob(base64);
  // Allocate a dedicated ArrayBuffer so the type is BufferSource (not
  // ArrayBufferLike which may be a SharedArrayBuffer under newer DOM libs).
  const buffer = new ArrayBuffer(raw.length);
  const view = new Uint8Array(buffer);
  for (let i = 0; i < raw.length; i++) view[i] = raw.charCodeAt(i);
  return view;
}

const VAPID_PUBLIC_KEY = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY || '';

export type PushPermission = 'granted' | 'denied' | 'default' | 'unsupported';

export function pushSupported(): boolean {
  return (
    typeof window !== 'undefined' &&
    'serviceWorker' in navigator &&
    'PushManager' in window &&
    'Notification' in window
  );
}

/**
 * Requests notification permission, subscribes via PushManager, and registers
 * the subscription with the backend. Returns the subscription endpoint, or
 * null if unsupported / denied.
 */
export async function subscribeToPush(): Promise<string | null> {
  if (!pushSupported()) return null;
  const permission = await Notification.requestPermission();
  if (permission !== 'granted') return null;

  const reg = (await navigator.serviceWorker.ready) as ServiceWorkerRegistration;
  let sub = await reg.pushManager.getSubscription();
  if (!sub) {
    const opts: PushSubscriptionOptionsInit = { userVisibleOnly: true };
    if (VAPID_PUBLIC_KEY) opts.applicationServerKey = urlBase64ToUint8Array(VAPID_PUBLIC_KEY);
    sub = await reg.pushManager.subscribe(opts);
  }

  const json = sub.toJSON() as { endpoint?: string; keys?: { p256dh?: string; auth?: string } };
  await portalApi('/portal/push/register', {
    method: 'POST',
    body: JSON.stringify({
      endpoint: json.endpoint,
      keys: { p256dh: json.keys?.p256dh, auth: json.keys?.auth },
    }),
  });
  return json.endpoint ?? null;
}

/** Unsubscribes from push and removes the subscription from the backend. */
export async function unsubscribeFromPush(): Promise<boolean> {
  if (!pushSupported()) return false;
  const reg = await navigator.serviceWorker.ready;
  const sub = await reg.pushManager.getSubscription();
  if (!sub) return false;
  const endpoint = sub.endpoint;
  try {
    await portalApi('/portal/push/unregister', {
      method: 'POST',
      body: JSON.stringify({ endpoint }),
    });
  } catch {
    /* still unsubscribe locally */
  }
  await sub.unsubscribe();
  return true;
}

export function currentPushPermission(): PushPermission {
  if (!pushSupported()) return 'unsupported';
  return Notification.permission as PushPermission;
}
