import type { ProductModule, ProductSignal } from './PRODUCT_RUNTIME_ENGINE';

export interface BusinessMetrics {
  revenueToday?: number;
  revenueMonth?: number;
  previousRevenueMonth?: number;
  activeMembers?: number;
  totalMembers?: number;
  expiringMembers?: number;
  checkinsToday?: number;
  previousCheckinsToday?: number;
  lowStockCount?: number;
  churnRiskCount?: number;
  branchCount?: number;
  staffOnShift?: number;
}

function pctDrop(current = 0, previous = 0) {
  if (previous <= 0) return 0;
  return ((previous - current) / previous) * 100;
}

export function generateBusinessSignals(module: ProductModule, metrics: BusinessMetrics = {}): ProductSignal[] {
  const signals: ProductSignal[] = [];
  const revenueDrop = pctDrop(metrics.revenueMonth, metrics.previousRevenueMonth);
  const attendanceDrop = pctDrop(metrics.checkinsToday, metrics.previousCheckinsToday);
  const retentionRatio = (metrics.activeMembers || 0) / Math.max(metrics.totalMembers || 1, 1);

  if ((metrics.churnRiskCount || 0) > 0 || (metrics.expiringMembers || 0) > 10 || retentionRatio < 0.72) {
    signals.push({
      id: 'churn_risk_signal',
      kind: 'risk',
      level: (metrics.expiringMembers || 0) > 25 ? 'critical' : 'high',
      title: 'rt_retention_rising',
      detail: 'rt_retention_rising_detail',
      metric: metrics.expiringMembers,
      actionId: 'review-retention',
    });
  }

  if (revenueDrop >= 10) {
    signals.push({
      id: 'revenue_drop_signal',
      kind: 'risk',
      level: revenueDrop >= 25 ? 'critical' : 'high',
      title: 'rt_revenue_recovery',
      detail: `Revenue is down ${Math.round(revenueDrop)}% versus the comparison period.`,
      metric: `${Math.round(revenueDrop)}%`,
      actionId: 'revenue-recovery',
    });
  }

  if (attendanceDrop >= 12) {
    signals.push({
      id: 'engagement_drop_signal',
      kind: 'risk',
      level: attendanceDrop >= 30 ? 'critical' : 'high',
      title: 'rt_engagement_weak',
      detail: `Check-ins are down ${Math.round(attendanceDrop)}%, which can increase churn risk.`,
      metric: `${Math.round(attendanceDrop)}%`,
      actionId: 'attendance-retention-review',
    });
  }

  if ((metrics.lowStockCount || 0) > 0) {
    signals.push({
      id: 'inventory_risk_signal',
      kind: 'risk',
      level: (metrics.lowStockCount || 0) > 5 ? 'high' : 'medium',
      title: 'rt_inventory_blocks',
      detail: 'rt_inventory_blocks_detail',
      metric: metrics.lowStockCount,
      actionId: 'sales-stock-check',
    });
  }

  if ((metrics.activeMembers || 0) > 100 && (metrics.revenueMonth || 0) > 0) {
    signals.push({
      id: 'pricing_opportunity_signal',
      kind: 'opportunity',
      level: 'medium',
      title: 'rt_pricing_opp',
      detail: 'rt_pricing_opp_detail',
      actionId: 'review-pricing',
    });
  }

  if ((metrics.branchCount || 0) > 1 && (metrics.staffOnShift || 0) > 0) {
    signals.push({
      id: 'expansion_signal',
      kind: 'opportunity',
      level: 'medium',
      title: 'rt_branch_leverage',
      detail: 'rt_branch_leverage_detail',
      actionId: 'branch-performance-review',
    });
  }

  return signals.map((signal) => ({ ...signal, id: `${module}:${signal.id}` }));
}
