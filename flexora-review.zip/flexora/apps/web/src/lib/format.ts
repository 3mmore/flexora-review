/**
 * FLEXORA Gym OS — Currency / Timezone / Date formatting (Phase 24)
 * © 2024 Ammar Allam. All rights reserved.
 */

export type Currency = 'EGP' | 'SAR' | 'AED' | 'USD' | 'EUR';

export const CURRENCY_SYMBOLS: Record<Currency, string> = {
  EGP: 'EGP',
  SAR: 'SAR',
  AED: 'AED',
  USD: '$',
  EUR: '€',
};

export const CURRENCY_RATES_TO_USD: Record<Currency, number> = {
  EGP: 0.020,  // 1 EGP ≈ $0.020
  SAR: 0.267,
  AED: 0.272,
  USD: 1,
  EUR: 1.085,
};

export const SUPPORTED_TIMEZONES = [
  'Africa/Cairo',
  'Asia/Riyadh',
  'Asia/Dubai',
  'Europe/Paris',
  'America/New_York',
  'UTC',
] as const;

export type Timezone = typeof SUPPORTED_TIMEZONES[number];

/**
 * Convert an amount from one currency to another.
 * Uses fixed conversion rates (for display only; use real FX rates in production).
 */
export function convertCurrency(amount: number, from: Currency, to: Currency): number {
  const usd = amount * (CURRENCY_RATES_TO_USD[from] ?? 1);
  return usd / (CURRENCY_RATES_TO_USD[to] ?? 1);
}

/** Format a number in a given currency. */
export function formatCurrency(amount: number, currency: Currency = 'USD', locale = 'en'): string {
  const symbol = CURRENCY_SYMBOLS[currency] ?? currency;
  const value = new Intl.NumberFormat(locale, { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(amount);
  // EGP/SAR/AED: prefix with code (e.g. "EGP 1,200"); USD/EUR: prefix with symbol
  return currency === 'USD' || currency === 'EUR' ? `${symbol}${value}` : `${symbol} ${value}`;
}

/** Format a date in the gym's timezone + locale. */
export function formatDate(date: Date | string | number, tz: Timezone = 'Africa/Cairo', locale = 'en'): string {
  const d = date instanceof Date ? date : new Date(date);
  return new Intl.DateTimeFormat(locale, {
    timeZone: tz,
    year: 'numeric', month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit',
  }).format(d);
}

/** Localized date only (no time). */
export function formatDateShort(date: Date | string | number, locale = 'en'): string {
  const d = date instanceof Date ? date : new Date(date);
  return new Intl.DateTimeFormat(locale, { year: 'numeric', month: 'short', day: 'numeric' }).format(d);
}

/** Get the user's preferred currency from localStorage (with fallback). */
export function getUserCurrency(): Currency {
  if (typeof window === 'undefined') return 'USD';
  const stored = localStorage.getItem('flx_currency');
  return (stored as Currency) || 'USD';
}

export function setUserCurrency(c: Currency) {
  if (typeof window !== 'undefined') localStorage.setItem('flx_currency', c);
}

export function getUserTimezone(): Timezone {
  if (typeof window === 'undefined') return 'Africa/Cairo';
  const stored = localStorage.getItem('flx_timezone');
  if (stored && (SUPPORTED_TIMEZONES as readonly string[]).includes(stored)) return stored as Timezone;
  return 'Africa/Cairo';
}

export function setUserTimezone(tz: Timezone) {
  if (typeof window !== 'undefined') localStorage.setItem('flx_timezone', tz);
}
