'use client';
/**
 * FLEXORA Gym OS — role-based branch scope (Phase 4)
 *
 * ONE source of truth for the web app's answer to "which branches may the
 * person looking at this screen touch?".
 *
 *   • OWNER / MANAGER (general manager) / SUPER_ADMIN → `unrestricted: true`.
 *     Every branch filter and branch picker keeps working exactly as before.
 *   • EVERY other staff role (RECEPTION, COACH, ACCOUNTANT, custom roles…) →
 *     `unrestricted: false` and `branchId` pinned to their own branch. Pages
 *     use this to HIDE the branch picker entirely and to stop sending any
 *     `branchId` parameter.
 *
 * The UI half is only cosmetics — the API refuses cross-branch reads/writes on
 * its own (TenantGuard + the Prisma branch scope), so hiding a picker is never
 * the thing that keeps the data safe.
 *
 * The `/auth/me` lookup is cached at module level so rendering five components
 * that all need the scope still costs one request.
 */
import { useEffect, useState } from 'react';
import { api } from './api';

export const BRANCH_UNRESTRICTED_ROLES = ['OWNER', 'MANAGER', 'SUPER_ADMIN'] as const;

export interface BranchScopeInfo {
  /** True until the identity has been resolved — render nothing branch-y yet. */
  loading: boolean;
  /**
   * True once the identity was actually READ (not guessed). When false the
   * lookup failed (network/429) and the scope is deliberately fail-open:
   * `unrestricted` stays true so no owner-only control disappears because of a
   * transient error. The API still refuses cross-branch calls, so this can
   * never leak data — it only decides what is drawn.
   */
  ok: boolean;
  /** Upper-cased role of the signed-in staff member ('' when unknown). */
  role: string;
  /** May this user see / filter across every branch? */
  unrestricted: boolean;
  /** The single branch a restricted user is pinned to (null when unrestricted). */
  branchId: string | null;
  /** Name of that branch, resolved from /branches when available. */
  branchName: string | null;
}

export function isUnrestrictedRole(role?: string | null): boolean {
  return (BRANCH_UNRESTRICTED_ROLES as readonly string[]).includes(String(role || '').toUpperCase());
}

type MeUser = { role?: string; branchId?: string | null } | null;

/**
 * Identity cache.
 *
 * Two layers, because a Next.js app reloads its JS modules on every full page
 * navigation while the browser keeps its session:
 *   • in-memory promise — several components on ONE page share a single call;
 *   • sessionStorage, 60s TTL — page-to-page navigation does not re-ask at all.
 *
 * This matters for real deployments: `/auth/me` is a rate-limited endpoint and
 * three components per page load made ordinary clicking look like a burst.
 */
const CACHE_KEY = 'flx.branchScope.v1';
const CACHE_TTL_MS = 60_000;

let cachedMe: Promise<MeUser> | null = null;

function readCache(): MeUser | undefined {
  if (typeof window === 'undefined') return undefined;
  try {
    const raw = window.sessionStorage.getItem(CACHE_KEY);
    if (!raw) return undefined;
    const parsed = JSON.parse(raw) as { user: MeUser; exp: number };
    if (!parsed?.exp || parsed.exp < Date.now()) return undefined;
    return parsed.user;
  } catch { return undefined; }
}

function writeCache(user: MeUser) {
  if (typeof window === 'undefined') return;
  try {
    window.sessionStorage.setItem(CACHE_KEY, JSON.stringify({ user, exp: Date.now() + CACHE_TTL_MS }));
  } catch { /* private mode — the in-memory cache still works */ }
}

export function loadMe(): Promise<MeUser> {
  if (!cachedMe) {
    const cached = readCache();
    if (cached !== undefined) {
      cachedMe = Promise.resolve(cached);
    } else {
      cachedMe = api<{ user: MeUser }>('/auth/me')
        .then((r) => {
          const user = r?.user ?? null;
          if (user) writeCache(user);
          return user;
        })
        .catch(() => null);
    }
  }
  return cachedMe;
}

/** Drop both caches after login/logout so the next page load re-reads identity. */
export function resetBranchScopeCache() {
  cachedMe = null;
  if (typeof window !== 'undefined') {
    try { window.sessionStorage.removeItem(CACHE_KEY); } catch { /* ignore */ }
  }
}

export function useBranchScope(): BranchScopeInfo {
  const [state, setState] = useState<BranchScopeInfo>({
    loading: true,
    ok: false,
    role: '',
    unrestricted: true, // assume the least-surprising thing until we know
    branchId: null,
    branchName: null,
  });

  useEffect(() => {
    let alive = true;
    (async () => {
      let me = await loadMe();
      if (alive && !me) {
        // One retry: a single failed identity read must not reshape the UI.
        await new Promise((r) => setTimeout(r, 1200));
        resetBranchScopeCache();
        me = await loadMe();
      }
      if (!alive) return;
      if (!me) {
        // Fail open — an unknown identity keeps today's (unrestricted) UI and
        // the API continues to be the thing that enforces the branch rule.
        setState({ loading: false, ok: false, role: '', unrestricted: true, branchId: null, branchName: null });
        return;
      }
      const role = String(me?.role || '').toUpperCase();
      const unrestricted = isUnrestrictedRole(role);
      const branchId = unrestricted ? null : (me?.branchId ?? null);
      let branchName: string | null = null;
      if (branchId) {
        // Resolve the branch NAME for the locked labels. Two attempts, because
        // a single throttled/failed read used to leave every page showing "—"
        // instead of telling the user which branch they are pinned to.
        for (let attempt = 0; attempt < 2 && !branchName; attempt++) {
          try {
            const raw = await api<any>('/branches');
            const list = Array.isArray(raw) ? raw : raw?.items || [];
            branchName = list.find((b: any) => b.id === branchId)?.name ?? null;
          } catch {
            await new Promise((r) => setTimeout(r, 700));
          }
        }
        // Still no name → leave it null; the badge renders its neutral "—"
        // placeholder rather than an unreadable internal id.
      }
      if (!alive) return;
      setState({ loading: false, ok: true, role, unrestricted, branchId, branchName });
    })();
    return () => { alive = false; };
  }, []);

  return state;
}
