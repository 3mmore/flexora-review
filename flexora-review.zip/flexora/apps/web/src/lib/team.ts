/**
 * FEATURE B — the web side's small, testable half.
 *
 * Everything that can be WRONG ABOUT A NUMBER lives here (formatting, the
 * "—" rule, the query string), so the page stays a view and these rules can be
 * unit-tested without a browser.
 *
 * The two display rules that matter:
 *   * a rate with no denominator is "—", never 0 % and never NaN;
 *   * money is displayed exactly as the API sent it (a 2-decimal string made
 *     from a Decimal). The client never re-parses money into a float.
 */

export type TeamPeriod = 'today' | 'week' | 'month' | 'custom';
export type TeamSort = 'name' | 'net' | 'newSubs' | 'attendance';

export interface TeamFilters {
  period: TeamPeriod;
  from: string;
  to: string;
  branchId: string;
  q: string;
  sort: TeamSort;
  includeInactive: boolean;
  page: number;
  pageSize: number;
}

export const TEAM_DEFAULT_FILTERS: TeamFilters = {
  period: 'month',
  from: '',
  to: '',
  branchId: '',
  q: '',
  sort: 'net',
  includeInactive: false,
  page: 1,
  pageSize: 25,
};

export const TEAM_MAX_PAGE_SIZE = 100;

export interface TargetProgress {
  target: string;
  progressPct: number | null;
  remaining: string;
  daysLeft: number;
}

export interface TeamRow {
  userId: string;
  name: string;
  role: string;
  active: boolean;
  branchId: string | null;
  branchName: string | null;
  newSubscriptions: number;
  renewals: number;
  membershipGross: string;
  posGross: string;
  refunds: string;
  net: string;
  average: string;
  newSubsTarget: TargetProgress | null;
  salesTarget: TargetProgress | null;
  sessionsHeld: number;
  membersAttended: number;
  booked: number;
  attendanceRate: number | null;
  attendanceLowSample: boolean;
  attendanceTarget: TargetProgress | null;
  rank: number | null;
  rankMetric: string | null;
}

export interface TeamFeed {
  items: TeamRow[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
  range: { from: string; to: string; tz: string; days: number };
  period: string;
  daysLeft: number;
  totals: {
    staffCount: number;
    newSubscriptions: number;
    renewals: number;
    net: string;
    sessionsHeld: number;
    membersAttended: number;
  };
  notAttributable: {
    membershipGross: string;
    membershipCount: number;
    posGross: string;
    posCount: number;
    refunds: string;
    refundCount: number;
    sessionsWithoutCoach: number;
  };
  definitions: Record<string, string>;
}

/**
 * Query string for every team route.
 *
 * Empty values are omitted (the API rejects an empty `from=`), presets never
 * send from/to, and pageSize is clamped — a browser tab that asks for 10 000
 * rows gets 100, not a 400 and not 10 000.
 */
export function buildTeamQuery(f: Partial<TeamFilters>): string {
  const q = new URLSearchParams();
  const period = f.period ?? 'month';
  q.set('period', period);
  if (period === 'custom') {
    if (f.from) q.set('from', f.from);
    if (f.to) q.set('to', f.to);
  }
  if (f.branchId) q.set('branchId', f.branchId);
  if (f.q && f.q.trim()) q.set('q', f.q.trim());
  if (f.sort && f.sort !== 'net') q.set('sort', f.sort);
  if (f.includeInactive) q.set('includeInactive', 'true');
  const page = Math.max(1, Math.floor(Number(f.page) || 1));
  q.set('page', String(page));
  const size = Math.min(TEAM_MAX_PAGE_SIZE, Math.max(1, Math.floor(Number(f.pageSize) || 25)));
  q.set('pageSize', String(size));
  return q.toString();
}

/** A percentage for display: one decimal, or "—" when there is no denominator. */
export function pct(value: number | null | undefined): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return '—';
  return `${value.toFixed(1)}%`;
}

/** Progress bar width, clamped to 0–100 for the BAR only (the number is honest). */
export function barWidth(value: number | null | undefined): string {
  if (value === null || value === undefined || !Number.isFinite(value)) return '0%';
  return `${Math.max(0, Math.min(100, value))}%`;
}

export function isOverTarget(value: number | null | undefined): boolean {
  return typeof value === 'number' && Number.isFinite(value) && value >= 100;
}

/** Which half of the table a person needs: money or attendance. */
export function personKind(role: string): 'coach' | 'money' {
  return role === 'COACH' ? 'coach' : 'money';
}

/**
 * Filename the browser should use for the CSV, taken from the server's
 * Content-Disposition when present (single source of truth), else a safe
 * fallback built from the range. Never trusts a path from the header.
 */
export function csvFilename(disposition: string | null, range?: { from: string; to: string }): string {
  const m = /filename="([^"]{1,120})"/.exec(disposition || '');
  const raw = m?.[1] || (range ? `team-performance-${range.from}-to-${range.to}.csv` : 'team-performance.csv');
  // strip any path separators or control characters a hostile header could carry
  return raw.replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_');
}

/**
 * Short, human label for the range the report used.
 *
 * The dates are rendered dd/mm/yyyy (the agreed format) instead of the raw ISO
 * dates the API sends, and the IANA zone is kept because it is a technical
 * identifier, not prose. `dateLabel` is injectable so a caller that has the
 * translations can pass its own formatter.
 */
/**
 * The IANA id ("Africa/Cairo") is a machine identifier: it must never be the
 * thing a receptionist reads. Callers pass `tzLabel(tz)` — Arabic, or null
 * when the zone is unknown, in which case the dates speak for themselves.
 */
export function rangeLabel(
  range: { from: string; to: string; tz: string },
  dateLabel: (iso: string) => string = (iso) => iso,
  tzLabel?: string | null,
): string {
  if (!range?.from || !range?.to) return '';
  const from = dateLabel(range.from);
  const to = dateLabel(range.to);
  const dates = from === to ? from : `${from} ← ${to}`;
  return tzLabel ? `${dates} · ${tzLabel}` : dates;
}


/** zone id → dictionary key; unknown zones return null and are not shown. */
export function tzLabelKey(tz: string | null | undefined): string | null {
  switch (tz) {
    case 'Africa/Cairo': return 'tz_cairo';
    case 'Asia/Riyadh': return 'tz_riyadh';
    case 'Asia/Dubai': return 'tz_dubai';
    case 'Africa/Casablanca': return 'tz_casablanca';
    case 'Asia/Amman': return 'tz_amman';
    case 'Asia/Kuwait': return 'tz_kuwait';
    default: return null;
  }
}
