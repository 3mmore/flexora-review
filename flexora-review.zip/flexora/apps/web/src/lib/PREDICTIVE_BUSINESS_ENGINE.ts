import type { ProductSignal } from './PRODUCT_RUNTIME_ENGINE';

export interface TimePoint { at: string; value: number }
export interface Forecast { horizonDays: 7 | 30 | 90; expected: number; lower: number; upper: number; confidence: number }

function avg(values: number[]) {
  return values.length ? values.reduce((sum, v) => sum + v, 0) / values.length : 0;
}

function slope(points: TimePoint[]) {
  if (points.length < 2) return 0;
  return (points[points.length - 1].value - points[0].value) / Math.max(points.length - 1, 1);
}

export function predictChurnRisk(member: { visits?: number; daysSinceLastVisit?: number; sessionsLeft?: number; daysToExpiry?: number }): number {
  let score = 0.15;
  if ((member.daysSinceLastVisit || 0) > 14) score += 0.35;
  if ((member.sessionsLeft ?? 99) <= 2) score += 0.20;
  if ((member.daysToExpiry ?? 99) <= 7) score += 0.25;
  if ((member.visits || 0) < 4) score += 0.10;
  return Math.min(0.95, Math.max(0.02, score));
}

export function forecastRevenue(points: TimePoint[], horizonDays: 7 | 30 | 90 = 30): Forecast {
  const values = points.map((p) => p.value);
  const daily = avg(values.slice(-14));
  const trend = slope(points.slice(-14));
  const expected = Math.max(0, (daily + trend) * horizonDays);
  const variance = Math.max(expected * 0.18, daily * 2);
  return { horizonDays, expected, lower: Math.max(0, expected - variance), upper: expected + variance, confidence: Math.min(0.9, 0.45 + values.length / 90) };
}

export function predictAttendanceTrend(points: TimePoint[]): 'up' | 'stable' | 'down' {
  const s = slope(points.slice(-14));
  if (s > 0.5) return 'up';
  if (s < -0.5) return 'down';
  return 'stable';
}

export function predictInventoryRunout(currentQty: number, dailyVelocity: number): number | null {
  if (dailyVelocity <= 0) return null;
  return Math.max(0, Math.floor(currentQty / dailyVelocity));
}

export function predictCampaignEffectiveness(input: { sent?: number; converted?: number; opened?: number }): number {
  const sent = Math.max(input.sent || 0, 1);
  const conversion = (input.converted || 0) / sent;
  const engagement = (input.opened || 0) / sent;
  return Math.min(1, conversion * 0.75 + engagement * 0.25);
}

export function predictionSignals(input: { revenue?: TimePoint[]; attendance?: TimePoint[]; stock?: Array<{ id: string; name: string; qty: number; velocity: number }> }): ProductSignal[] {
  const signals: ProductSignal[] = [];
  if (input.revenue?.length) {
    const f = forecastRevenue(input.revenue, 30);
    if (f.confidence >= 0.55) signals.push({ id: 'predictive_revenue_forecast', kind: 'opportunity', level: 'medium', title: 'rt_forecast_title', detail: `30-day expected revenue: ${Math.round(f.expected).toLocaleString()}.`, metric: Math.round(f.expected), actionId: 'explain-report' });
  }
  if (input.attendance?.length && predictAttendanceTrend(input.attendance) === 'down') {
    signals.push({ id: 'predictive_attendance_drop', kind: 'risk', level: 'high', title: 'rt_attendance_decline_title', detail: 'rt_attendance_decline_detail', actionId: 'attendance-retention-review' });
  }
  for (const item of input.stock || []) {
    const days = predictInventoryRunout(item.qty, item.velocity);
    if (days !== null && days <= 7) signals.push({ id: `predictive_stockout_${item.id}`, kind: 'risk', level: days <= 2 ? 'critical' : 'high', title: `${item.name} may stock out`, detail: `Estimated runout in ${days} day(s).`, actionId: 'sales-stock-check' });
  }
  return signals;
}
