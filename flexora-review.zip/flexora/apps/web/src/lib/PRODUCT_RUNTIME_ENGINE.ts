import { generateBusinessSignals, type BusinessMetrics } from './BUSINESS_SIGNAL_ENGINE';
import { getDecisionInfluence, graphActionsFor, propagateCrossModuleSignals } from './PRODUCT_DECISION_GRAPH';
import { readProductMemoryGraph, rememberSignals } from './PRODUCT_MEMORY_GRAPH';
import { orchestrateAIDecision } from './AI_ORCHESTRATION_ENGINE';
import { readBusinessEvents } from './REALTIME_EVENT_STREAM';
import { computeLiveBusinessState, mergeEventSignals } from './REALTIME_BUSINESS_STATE_ENGINE';
import { predictionSignals } from './PREDICTIVE_BUSINESS_ENGINE';
import { detectEarlyRiskSignals } from './EARLY_WARNING_SYSTEM';
import { traceBusinessDecision } from './BUSINESS_OBSERVABILITY_LAYER';

export type ProductModule =
  | 'dashboard'
  | 'ai'
  | 'members'
  | 'attendance'
  | 'classes'
  | 'pos'
  | 'sales'
  | 'inventory'
  | 'products'
  | 'staff'
  | 'branches'
  | 'reports'
  | 'billing'
  | 'settings'
  | 'campaigns'
  | 'contracts'
  | 'crm'
  | 'marketplace'
  | 'enterprise'
  | 'portal'
  | 'unknown';

export type ProductRole = 'SUPER_ADMIN' | 'OWNER' | 'MANAGER' | 'RECEPTION' | 'COACH' | 'MEMBER' | 'GUEST';
export type TechnicalState = 'idle' | 'loading' | 'partial' | 'empty' | 'error' | 'success';
export type BusinessState = 'business-idle' | 'business-active' | 'risk-state' | 'opportunity-state' | 'recovery-state' | 'decision-needed-state';
export type SignalLevel = 'none' | 'low' | 'medium' | 'high' | 'critical';
export type SignalKind = 'risk' | 'opportunity' | 'recovery' | 'success' | 'info' | 'ai';

export interface ProductSignal {
  id: string;
  kind: SignalKind;
  level: Exclude<SignalLevel, 'none'>;
  title: string;
  detail: string;
  metric?: number | string;
  actionId?: string;
}

export interface ProductContext {
  module: ProductModule;
  role: ProductRole;
  previousAction?: RuntimeEvent;
  businessState: BusinessState;
  riskLevel: SignalLevel;
  opportunityLevel: SignalLevel;
  timestamp: string;
  recovered: boolean;
}

export interface RuntimeIntent {
  type: 'observe' | 'create' | 'recover' | 'optimize' | 'explain' | 'navigate' | 'export' | 'configure';
  entity?: string;
  urgency?: SignalLevel;
}

export interface RuntimeAction {
  id: string;
  label: string;
  intent: RuntimeIntent;
  href?: string;
  reason: string;
  source: 'system' | 'ai' | 'module' | 'memory';
  tone?: 'neutral' | 'good' | 'warning' | 'danger';
  priority?: number;
  revenueImpact?: number;
  timeSensitivity?: SignalLevel;
  hidden?: boolean;
}

export interface RuntimeFeedback {
  type: 'info' | 'success' | 'warning' | 'danger';
  title: string;
  detail: string;
  recovery?: RuntimeAction;
}

export interface RuntimeEvent {
  module: ProductModule;
  actionId: string;
  label: string;
  at: string;
  entityId?: string;
}

export interface RuntimeMemory {
  lastActions: Partial<Record<ProductModule, RuntimeEvent>>;
  lastEntities: Partial<Record<ProductModule, string>>;
  unresolvedRisks: ProductSignal[];
  pendingActions: RuntimeAction[];
  visits: Partial<Record<ProductModule, number>>;
}

export interface RuntimeInput {
  module?: ProductModule;
  role?: ProductRole;
  technicalState?: TechnicalState;
  recordCount?: number;
  error?: string | null;
  signals?: ProductSignal[];
  metrics?: BusinessMetrics;
  candidateActions?: RuntimeAction[];
  intent?: RuntimeIntent;
}

export interface RuntimeOutput {
  context: ProductContext;
  state: BusinessState;
  insights: ProductSignal[];
  actions: RuntimeAction[];
  feedback: RuntimeFeedback;
  composition: {
    showInsightLayer: boolean;
    showActionLayer: boolean;
    showFeedbackLayer: boolean;
    showSmartTable: boolean;
    commandHints: string[];
  };
  memory: RuntimeMemory;
}

export const PRODUCT_MODULES: ProductModule[] = [
  'dashboard', 'ai', 'members', 'attendance', 'classes', 'pos', 'sales', 'inventory', 'products',
  'staff', 'branches', 'reports', 'billing', 'settings', 'campaigns', 'contracts', 'crm',
  'marketplace', 'enterprise', 'portal',
];

let runtimeMemory: RuntimeMemory | null = null;

function now() {
  return new Date().toISOString();
}

export function defaultRuntimeMemory(): RuntimeMemory {
  return { lastActions: {}, lastEntities: {}, unresolvedRisks: [], pendingActions: [], visits: {} };
}

export function readRuntimeMemory(): RuntimeMemory { return runtimeMemory ? { ...defaultRuntimeMemory(), ...runtimeMemory } : defaultRuntimeMemory(); }

export function writeRuntimeMemory(memory: RuntimeMemory) { runtimeMemory = memory; }

export function recordRuntimeEvent(event: Omit<RuntimeEvent, 'at'>) {
  const memory = readRuntimeMemory();
  const next = { ...event, at: now() };
  memory.lastActions[event.module] = next;
  memory.visits[event.module] = (memory.visits[event.module] || 0) + 1;
  writeRuntimeMemory(memory);
}

function roleFromStorage(): ProductRole { return 'GUEST'; }

function severityRank(level: SignalLevel): number {
  return ({ none: 0, low: 1, medium: 2, high: 3, critical: 4 } as const)[level];
}

function highest(signals: ProductSignal[], kind: SignalKind): SignalLevel {
  const levels = signals.filter((s) => s.kind === kind).map((s) => s.level);
  return levels.sort((a, b) => severityRank(b) - severityRank(a))[0] || 'none';
}

export function inferBusinessState(input: RuntimeInput): BusinessState {
  if (input.error) return 'recovery-state';
  if (input.technicalState === 'loading' || input.technicalState === 'partial') return 'decision-needed-state';
  const signals = input.signals || [];
  if (severityRank(highest(signals, 'risk')) >= 3) return 'risk-state';
  if (severityRank(highest(signals, 'opportunity')) >= 2) return 'opportunity-state';
  if (input.technicalState === 'empty' || input.recordCount === 0) return 'business-idle';
  return 'business-active';
}

export function detectProductContext(input: RuntimeInput): ProductContext {
  const memory = readRuntimeMemory();
  const module = input.module || 'unknown';
  const businessState = inferBusinessState(input);
  return {
    module,
    role: input.role || roleFromStorage(),
    previousAction: module !== 'unknown' ? memory.lastActions[module] : undefined,
    businessState,
    riskLevel: highest(input.signals || [], 'risk'),
    opportunityLevel: highest(input.signals || [], 'opportunity'),
    timestamp: now(),
    recovered: !input.module || input.module === 'unknown',
  };
}

export function aiDecisionLayer(context: ProductContext, signals: ProductSignal[]): ProductSignal[] {
  const derived: ProductSignal[] = [];
  if (context.businessState === 'risk-state') {
    derived.push({ id: `${context.module}-ai-risk`, kind: 'ai', level: 'high', title: 'rt_ai_risk_title', detail: 'rt_ai_risk_detail', actionId: 'ai-risk-review' });
  }
  if (context.businessState === 'opportunity-state') {
    derived.push({ id: `${context.module}-ai-opportunity`, kind: 'ai', level: 'medium', title: 'rt_ai_opp_title', detail: 'rt_ai_opp_detail', actionId: 'ai-opportunity-review' });
  }
  if (!signals.length && context.businessState === 'business-active') {
    derived.push({ id: `${context.module}-ai-normal`, kind: 'ai', level: 'low', title: 'rt_ai_note_title', detail: 'rt_ai_note_detail' });
  }
  return derived;
}

function baseActions(module: ProductModule): RuntimeAction[] {
  const map: Partial<Record<ProductModule, RuntimeAction[]>> = {
    members: [
      { id: 'add-member', label: 'rt_add_member', href: '/members?action=new', intent: { type: 'create', entity: 'member' }, reason: 'rt_add_member_why', source: 'module' },
      { id: 'review-retention', label: 'rt_review_retention', href: '/ai', intent: { type: 'recover', entity: 'member' }, reason: 'rt_review_retention_why', source: 'ai', tone: 'warning' },
    ],
    sales: [{ id: 'open-pos', label: 'rt_open_pos', href: '/pos', intent: { type: 'create', entity: 'sale' }, reason: 'rt_open_pos_why', source: 'module' }],
    pos: [{ id: 'open-pos', label: 'rt_start_checkout', href: '/pos', intent: { type: 'create', entity: 'invoice' }, reason: 'rt_start_checkout_why', source: 'module' }],
    inventory: [{ id: 'review-stock', label: 'rt_review_stock', href: '/inventory', intent: { type: 'recover', entity: 'stock' }, reason: 'rt_review_stock_why', source: 'module', tone: 'warning' }],
    reports: [{ id: 'explain-report', label: 'rt_ask_ai', href: '/ai', intent: { type: 'explain', entity: 'report' }, reason: 'rt_ask_ai_why', source: 'ai' }],
    dashboard: [{ id: 'next-best-action', label: 'rt_open_action_center', href: '/dashboard', intent: { type: 'observe' }, reason: 'rt_open_action_center_why', source: 'system' }],
  };
  return map[module] || [{ id: `${module}-observe`, label: 'rt_review_workspace', href: module === 'unknown' ? '/dashboard' : `/${module}`, intent: { type: 'observe' }, reason: 'rt_review_workspace_why', source: 'system' }];
}

export function resolveRuntimeActions(context: ProductContext, signals: ProductSignal[], candidates: RuntimeAction[] = []): RuntimeAction[] {
  const actions = [...baseActions(context.module), ...candidates];
  const risk = severityRank(context.riskLevel);
  const opportunity = severityRank(context.opportunityLevel);
  return actions
    .map((action) => {
      let priority = action.priority ?? 50;
      if (risk >= 3 && action.intent.type === 'recover') priority += 45;
      if (opportunity >= 2 && action.intent.type === 'optimize') priority += 35;
      if ((action.revenueImpact || 0) > 0) priority += Math.min(30, action.revenueImpact || 0);
      if (severityRank(action.timeSensitivity || 'none') >= 3) priority += 24;
      if (['OWNER', 'MANAGER', 'SUPER_ADMIN'].includes(context.role) && action.source === 'ai') priority += 10;
      if (context.previousAction?.actionId === action.id) priority -= 12;
      if (signals.some((s) => s.actionId === action.id)) priority += 25;
      return { ...action, priority };
    })
    .filter((a) => !a.hidden)
    .sort((a, b) => (b.priority || 0) - (a.priority || 0))
    .slice(0, 5);
}

export function composeProductRuntime(input: RuntimeInput): RuntimeOutput {
  const memory = readRuntimeMemory();
  const productMemory = readProductMemoryGraph();
  const liveEvents = readBusinessEvents();
  const liveState = computeLiveBusinessState(input.module || 'unknown', liveEvents);
  const metricSignals = generateBusinessSignals(input.module || 'unknown', input.metrics || {});
  const liveSignals = mergeEventSignals(liveEvents);
  const predictiveSignals = predictionSignals({});
  const directSignals = [...(input.signals || []), ...metricSignals, ...liveSignals, ...liveState.signals, ...predictiveSignals];
  const earlyWarnings = detectEarlyRiskSignals(directSignals);
  const context = detectProductContext({ ...input, signals: [...directSignals, ...earlyWarnings.map((w) => w.signal)] });
  const influence = getDecisionInfluence(context.module);
  const crossModuleSignals = propagateCrossModuleSignals(context.module, directSignals);
  const warningSignals = earlyWarnings.map((warning) => warning.signal);
  const warningActions = earlyWarnings.map((warning) => warning.preventiveAction);
  const aiSignals = aiDecisionLayer(context, [...directSignals, ...warningSignals, ...crossModuleSignals]);
  const orchestration = orchestrateAIDecision(context, [...directSignals, ...warningSignals, ...crossModuleSignals, ...aiSignals], productMemory, influence, { liveEvents, liveState, earlyWarnings });
  const insights = [...directSignals, ...warningSignals, ...crossModuleSignals, ...aiSignals, ...orchestration.signals];
  rememberSignals(context.module, insights);
  const actions = resolveRuntimeActions(context, insights, [
    ...graphActionsFor(context.module),
    ...warningActions,
    ...orchestration.actions,
    ...(input.candidateActions || []),
  ]);
  traceBusinessDecision({
    module: context.module,
    action: actions[0],
    signals: insights,
    reasoning: orchestration.explanation,
  });

  const feedback: RuntimeFeedback = input.error
    ? { type: 'danger', title: 'rt_fb_recovery', detail: input.error, recovery: actions[0] }
    : context.businessState === 'risk-state'
      ? { type: 'warning', title: 'rt_fb_risk', detail: 'rt_fb_risk_detail', recovery: actions[0] }
      : context.businessState === 'opportunity-state'
        ? { type: 'success', title: 'rt_fb_opportunity', detail: 'rt_fb_opportunity_detail', recovery: actions[0] }
        : { type: 'info', title: 'rt_fb_ready', detail: 'rt_fb_ready_detail' };

  return {
    context,
    state: context.businessState,
    insights,
    actions,
    feedback,
    memory,
    composition: {
      showInsightLayer: true,
      showActionLayer: actions.length > 0,
      showFeedbackLayer: context.businessState === 'risk-state' || context.businessState === 'recovery-state',
      showSmartTable: input.technicalState !== 'loading',
      commandHints: actions.map((a) => a.label),
    },
  };
}
