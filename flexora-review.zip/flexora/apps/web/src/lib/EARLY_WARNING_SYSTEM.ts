import type { ProductSignal, RuntimeAction } from './PRODUCT_RUNTIME_ENGINE';

export type EarlyWarningKind =
  | 'early_churn_warning'
  | 'revenue_decline_warning'
  | 'engagement_drop_warning'
  | 'inventory_stockout_warning'
  | 'class_underperformance_warning';

export interface EarlyWarning {
  id: string;
  kind: EarlyWarningKind;
  signal: ProductSignal;
  preventiveAction: RuntimeAction;
}

export function escalateRiskLevel(level: ProductSignal['level'], repeatCount = 0): ProductSignal['level'] {
  if (level === 'critical') return 'critical';
  if (repeatCount >= 3 && level === 'high') return 'critical';
  if (repeatCount >= 2 && level === 'medium') return 'high';
  return level;
}

export function triggerPreventiveActions(signal: ProductSignal): RuntimeAction {
  const recover = signal.kind === 'risk';
  return {
    id: signal.actionId || `prevent-${signal.id}`,
    label: recover ? 'rtw_prevent' : 'rtw_capture',
    href: recover ? '/ai' : '/reports',
    intent: { type: recover ? 'recover' : 'optimize', urgency: signal.level },
    reason: signal.detail,
    source: 'system',
    tone: signal.level === 'critical' || signal.level === 'high' ? 'warning' : 'good',
    priority: signal.level === 'critical' ? 130 : signal.level === 'high' ? 110 : 80,
    timeSensitivity: signal.level,
  };
}

export function detectEarlyRiskSignals(signals: ProductSignal[]): EarlyWarning[] {
  return signals
    .filter((signal) => signal.kind === 'risk' || signal.id.includes('predictive'))
    .map((signal) => ({
      id: `warning_${signal.id}`,
      kind: signal.id.includes('inventory') || signal.id.includes('stock') ? 'inventory_stockout_warning'
        : signal.id.includes('revenue') ? 'revenue_decline_warning'
          : signal.id.includes('attendance') || signal.id.includes('engagement') ? 'engagement_drop_warning'
            : signal.id.includes('class') ? 'class_underperformance_warning'
              : 'early_churn_warning',
      signal: { ...signal, level: escalateRiskLevel(signal.level) },
      preventiveAction: triggerPreventiveActions(signal),
    }));
}
