import { existsSync } from 'fs';
import { join } from 'path';
import { NAV_GROUPS, NAV_HREFS } from './nav-structure';
import { MobileTabHrefs } from './nav-structure';

/**
 * The navigation structure test (Pack 2, item 2).
 *
 * It replaces the previous situation, in which the only description of the
 * navigation was the JSX inside `components/Shell.tsx` and nothing checked it.
 * The rules it locks:
 *
 *  1. every destination in the navigation resolves to a real page file — no
 *     dead links on either surface;
 *  2. no destination that existed before Pack 2 disappeared (the frozen list
 *     below is the pre-change sidebar, item by item);
 *  3. the phone's tab bar has at most five entries, and every one of them is a
 *     real destination;
 *  4. the sidebar and the phone index render the same structure, so a route
 *     cannot exist on one and not the other;
 *  5. each label key exists in both dictionaries (the dictionary spec already
 *     enforces ar/en parity, but not that a nav key exists at all).
 */

const APP_DIR = join(__dirname, '..', 'app');

/** The sidebar exactly as it was before Pack 2, frozen so nothing is lost. */
const FROZEN_HREFS = [
  '/dashboard',
  '/members',
  '/attendance',
  '/checkin',
  '/biometric',
  '/invitations',
  '/leads',
  '/crm',
  '/campaigns',
  '/contracts',
  '/classes',
  '/coach',
  '/users',
  '/transfers',
  '/inventory',
  '/pos',
  '/staff-attendance',
  '/reports',
  '/accounting',
  '/billing',
  '/license',
  '/ai',
  '/ai-advanced',
  '/white-label',
  '/marketplace',
  '/backups',
  '/settings',
  '/wa-bot',
  '/notifications',
  '/team/performance',
  '/support',
];

const pageExists = (href: string) => {
  const clean = href.split('?')[0].replace(/^\//, '');
  return existsSync(join(APP_DIR, clean, 'page.tsx'));
};

describe('navigation structure', () => {
  it('every destination in the navigation resolves to a page that exists', () => {
    const missing = NAV_HREFS.filter((h) => !pageExists(h));
    expect(missing).toEqual([]);
  });

  it('loses no destination that existed before Pack 2', () => {
    const now = new Set(NAV_HREFS);
    const gone = FROZEN_HREFS.filter((h) => !now.has(h));
    expect(gone).toEqual([]);
  });

  it('declares no destination twice', () => {
    const seen = NAV_HREFS.filter((h, i) => NAV_HREFS.indexOf(h) !== i);
    expect(seen).toEqual([]);
  });

  it('keeps the phone tab bar at five entries or fewer, all of them real destinations', () => {
    expect(MobileTabHrefs.length).toBeLessThanOrEqual(5);
    expect(MobileTabHrefs.filter((h) => !pageExists(h))).toEqual([]);
  });

  it('is one structure: the desktop sidebar and the phone index read the same list', () => {
    // Both surfaces import NAV_GROUPS; this asserts the export is not a copy
    // that could drift.
    expect(NAV_GROUPS.length).toBeGreaterThan(0);
    const flat = NAV_GROUPS.flatMap((g) => g.items.map((i) => i.href));
    expect(flat).toEqual(NAV_HREFS);
  });

  it('labels every destination and every group in both dictionaries', () => {
    /* eslint-disable @typescript-eslint/no-var-requires */
    const ar = require('../lib/i18n/ar').default ?? require('../lib/i18n/ar');
    const en = require('../lib/i18n/en').default ?? require('../lib/i18n/en');
    const arDict = ar.ar ?? ar;
    const enDict = en.en ?? en;
    const keys = [
      ...NAV_GROUPS.map((g) => g.label),
      ...NAV_GROUPS.flatMap((g) => g.items.map((i) => i.key)),
    ];
    const missing = keys.filter((k) => !(k in arDict) || !(k in enDict));
    expect(missing).toEqual([]);
  });
});
