'use client';
// Empty NEXT_PUBLIC_API_URL → same-origin proxy mode: the browser calls
// /api/* and the web server proxies it to the API (next.config.mjs rewrites).
// Required behind reverse proxies / sandboxed previews where the API port is
// not directly reachable from the browser.
const API_ORIGIN = (process.env.NEXT_PUBLIC_API_URL || '').replace(/\/$/, '');
const API_URL = API_ORIGIN
  ? (API_ORIGIN.endsWith('/api') ? API_ORIGIN : `${API_ORIGIN}/api`)
  : '/api';
export { API_URL as API_BASE_URL };
function csrfToken() { if (typeof document === 'undefined') return null; return document.cookie.split(';').map((v) => v.trim()).find((v) => v.startsWith('_csrf='))?.slice(6) || null; }

class ApiClient {
  private static instance: ApiClient;
  // FIX (P1: session logout when clicking into dashboard): concurrent 401s
  // from multiple simultaneous requests would each trigger a refresh. With
  // refresh-token rotation, the first refresh consumes the old token and
  // issues a new one; the second refresh then fails (old token already
  // consumed) and the server revokes the entire token family — logging the
  // user out. This mutex ensures only ONE refresh runs at a time; other
  // callers wait for it and then retry with the fresh cookies.
  private refreshPromise: Promise<boolean> | null = null;

  static getInstance(): ApiClient {
    if (!ApiClient.instance) ApiClient.instance = new ApiClient();
    return ApiClient.instance;
  }

  private async doRefresh(): Promise<boolean> {
    if (this.refreshPromise) return this.refreshPromise;
    this.refreshPromise = (async () => {
      try {
        const r = await fetch(`${API_URL}/auth/refresh`, { method: 'POST', credentials: 'include' });
        return r.ok;
      } catch {
        return false;
      } finally {
        this.refreshPromise = null;
      }
    })();
    return this.refreshPromise;
  }

  public async fetchWithAuth<T = unknown>(url: string, options: RequestInit = {}, retried = false): Promise<T> {
    // FIX (P3: backup restore fails with JSON parse error): when the body is
    // FormData (file upload), do NOT set Content-Type: application/json — the
    // browser must set it to multipart/form-data with the correct boundary.
    const isFormData = typeof FormData !== 'undefined' && options.body instanceof FormData;
    const headers: Record<string, string> = {};
    if (!isFormData) {
      headers['Content-Type'] = 'application/json';
    }
    if (csrfToken() && !['GET','HEAD'].includes(String(options.method || 'GET').toUpperCase())) {
      headers['X-CSRF-Token'] = csrfToken() as string;
    }
    // Merge caller-provided headers (they override defaults)
    if (options.headers && typeof options.headers === 'object') {
      const extra = options.headers as Record<string, string>;
      for (const [k, v] of Object.entries(extra)) {
        if (v != null) headers[k] = v;
      }
    }

    const response = await fetch(`${API_URL}${url}`, {
      ...options,
      credentials: 'include',
      headers,
    });

    if (response.status === 401) {
      if (retried) {
        throw new Error('Session expired');
      }
      const refreshed = await this.doRefresh();
      if (refreshed) {
        return this.fetchWithAuth<T>(url, options, true);
      }
      throw new Error('Session expired');
    }

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ message: 'Request failed' })) as {
        message?: string | string[];
        messages?: string[];
        errors?: Array<{ field: string; message: string; translationKey?: string }>;
        code?: string;
        translationKey?: string;
        current?: number;
        limit?: number;
        tier?: string;
      };
      /**
       * Nest returns `message` as an ARRAY for DTO validation failures. Reading
       * it as a string only is what turned every 400 into a bare "HTTP 400" and
       * hid the real reason (e.g. "Name must contain at least 3 parts") from the
       * user. Join the parts so the explanation always survives.
       */
      const parts = Array.isArray(errorData.message)
        ? errorData.message.filter((m): m is string => typeof m === 'string' && m.length > 0)
        : typeof errorData.message === 'string' && errorData.message
          ? [errorData.message]
          : [];
      const error: any = new Error(parts.length ? parts.join(' · ') : `HTTP ${response.status}`);
      error.status = response.status;
      // Keep the structured list so the UI can translate and point at fields.
      if (parts.length) error.messages = parts;
      if (Array.isArray(errorData.errors) && errorData.errors.length) error.errors = errorData.errors;
      // Preserve structured backend error metadata (code/translationKey +
      // real numbers such as current/limit/tier). safe-error.ts turns these
      // into translated, specific UI messages instead of raw English text.
      if (errorData.code) error.code = errorData.code;
      if (errorData.translationKey) error.translationKey = errorData.translationKey;
      if (typeof errorData.current === 'number') error.current = errorData.current;
      if (typeof errorData.limit === 'number') error.limit = errorData.limit;
      if (errorData.tier) error.tier = errorData.tier;
      throw error;
    }
    return (response.status === 204 ? undefined : response.json()) as Promise<T>;
  }

  async get<T = unknown>(url: string): Promise<T> { return this.fetchWithAuth<T>(url); }
  async post<T = unknown>(url: string, body?: unknown): Promise<T> { return this.fetchWithAuth<T>(url, { method: 'POST', body: body ? JSON.stringify(body) : undefined }); }
  async patch<T = unknown>(url: string, body?: unknown): Promise<T> { return this.fetchWithAuth<T>(url, { method: 'PATCH', body: body ? JSON.stringify(body) : undefined }); }
  async del<T = unknown>(url: string): Promise<T> { return this.fetchWithAuth<T>(url, { method: 'DELETE' }); }
}

export const apiClient = ApiClient.getInstance();
export async function api<T = unknown>(path: string, opts: RequestInit = {}): Promise<T> {
  return apiClient.fetchWithAuth<T>(path, opts);
}
/**
 * The shape the shell and the navigation read off /auth/me. Declared here so a
 * component asking for `role` or `permissions` gets a real type instead of
 * `unknown`, which is what made three files fail to compile.
 */
export type SessionUser = { id?: string; name?: string; email?: string; role?: string; gymId?: string; permissions?: string[] } | null;
let sessionUser: SessionUser = null;
export const auth = {
  async login(email: string, password: string, gymSlug?: string) {
    const response = await fetch(`${API_URL}/auth/login`, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, gymSlug }),
    });
    if (!response.ok) {
      const error = await response.json().catch(() => ({ message: 'Invalid credentials' })) as { message?: string };
      throw new Error(error.message || 'Invalid credentials');
    }
    const data = (await response.json()) as any;
    sessionUser = data.user || null;
    return data; // Changed from sessionUser to return full data (including tempToken)
  },
  async register(gymName: string, ownerName: string, email: string, password: string) {
    const response = await fetch(`${API_URL}/auth/register`, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ gymName, ownerName, email, password }),
    });
    if (!response.ok) {
      const error = await response.json().catch(() => ({ message: 'Registration failed' })) as { message?: string };
      throw new Error(error.message || 'Registration failed');
    }
    return response.json();
  },
  async logout() { await api('/auth/logout', { method: 'POST' }).catch(() => undefined); sessionUser = null; },
  async me() { const data = await api<{ user: SessionUser }>('/auth/me'); sessionUser = data.user || null; return sessionUser; },
  user() { return sessionUser; },
};
