'use client';

import {
  createContext, useContext, useState,
  useEffect, ReactNode
} from 'react';
import { ar } from './ar';
import { en } from './en';

type Lang = 'ar' | 'en';

interface I18nCtx {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (key: string) => string;
  dir: 'rtl' | 'ltr';
}

/**
 * Translate one key outside React (event handlers that only have the current
 * language from storage). Used for structured API errors that carry a
 * translationKey rather than a sentence.
 */
export function translateKey(key: string, lang: Lang = currentStoredLang()): string {
  const dict: Record<string, string> = lang === 'ar' ? ar : en;
  return dict[key] || key;
}

export function currentStoredLang(): Lang {
  if (typeof localStorage === 'undefined') return 'ar';
  return localStorage.getItem('flexora-lang') === 'en' ? 'en' : 'ar';
}

const I18nContext = createContext<I18nCtx>({
  lang: 'ar',
  setLang: () => {},
  t: (k) => k,
  dir: 'rtl',
});

export function I18nProvider({ children }: {
  children: ReactNode
}) {
  const [lang, setLangState] = useState<Lang>('ar');

  useEffect(() => {
    const saved = localStorage.getItem('flexora-lang');
    if (saved === 'ar' || saved === 'en') {
      setLangState(saved as Lang);
    }
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir =
      lang === 'ar' ? 'rtl' : 'ltr';
    localStorage.setItem('flexora-lang', lang);
  }, [lang]);

  const setLang = (l: Lang) => setLangState(l);
  const dir = lang === 'ar' ? 'rtl' : 'ltr';
  const translations = lang === 'ar' ? ar : en;

  const t = (key: string): string =>
    translations[key] ?? key;

  return (
    <I18nContext.Provider value={{
      lang, setLang, t, dir
    }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useTranslation() {
  return useContext(I18nContext);
}
