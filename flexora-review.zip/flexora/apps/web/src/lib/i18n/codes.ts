/**
 * PACK 2 / ITEM 1 — codes are data, labels are words.
 *
 * Every status, plan, tier, role and audit action in this product is a stable
 * machine code in the API (`BASIC`, `PENDING_APPROVAL`, `admin:totp-enrolled`).
 * The owner's rule is that a user never reads the code: the screen shows an
 * Arabic label, and the code stays in the data layer (payloads, filters, CSV,
 * logs). This module is the single place that turns one into the other, so a
 * screen cannot invent its own English fallback.
 *
 * Missing labels are a BUG, not a runtime condition to paper over:
 *   - in a test build (`NODE_ENV=test`) `label()` throws, which makes
 *     dictionary.spec.ts enumerate every code the API can emit and fail when one
 *     has no Arabic label;
 *   - in production it renders the neutral Arabic placeholder instead of showing
 *     `PENDING_APPROVAL` to a gym owner.
 */
import { ar } from './ar';
import { en } from './en';

export type Dictionary = Record<string, string>;

/** Codes the API can return today, taken from apps/api/prisma/schema.prisma. */
export const PLAN_CODES = ['BASIC', 'PRO', 'ELITE'] as const;
export const GYM_STATUS_CODES = ['ACTIVE', 'SUSPENDED', 'TRIAL', 'DELETED'] as const;
export const SUBSCRIPTION_STATUS_CODES = ['ACTIVE', 'PAST_DUE', 'CANCELED', 'TRIALING', 'SUSPENDED', 'EXPIRED'] as const;
export const ADMIN_ROLE_CODES = ['PLATFORM_ADMIN', 'PLATFORM_OWNER', 'PLATFORM_SUPPORT'] as const;
export const ADMIN_STATUS_CODES = ['ACTIVE', 'PENDING_APPROVAL', 'SUSPENDED'] as const;
export const LICENSE_STATUS_CODES = ['ACTIVE', 'SUSPENDED', 'EXPIRED'] as const;
/** How a check-in was recorded — the API stores a code, staff see a word. */
export const CHECKIN_METHOD_CODES = ['STAFF', 'QR', 'SELF', 'KIOSK', 'BIOMETRIC', 'GEOLOCATION', 'WIFI', 'MANUAL'] as const;

/** Payment methods a cashier can pick. */
export const PAYMENT_METHOD_CODES = ['CASH', 'CARD', 'WALLET', 'BANK', 'OTHER'] as const;

export const MEMBER_STATUS_CODES = ['ACTIVE', 'EXPIRED', 'FROZEN', 'PENDING_PAYMENT', 'SUSPENDED', 'CANCELLED'] as const;

/** Audit actions the console can display, as `<scope>:<verb>` strings. */
export const AUDIT_ACTION_CODES = [
  'admin:login',
  'admin:logout',
  'admin:totp-enrolled',
  'admin:totp-enrolment-started',
  'admin:create',
  'admin:approve',
  'admin:suspend',
  'flag:set',
  'gym:suspend',
  'gym:resume',
  'gym:delete',
  'subscription:change',
  'revenue:export',
] as const;

const PREFIX = {
  plan: 'code_plan_',
  gymStatus: 'code_gym_status_',
  subscriptionStatus: 'code_subscription_status_',
  adminRole: 'code_admin_role_',
  adminStatus: 'code_admin_status_',
  licenseStatus: 'code_license_status_',
  memberStatus: 'code_member_status_',
  auditAction: 'code_audit_action_',
  checkinMethod: 'checkin_method_',
  paymentMethod: 'code_payment_method_',
} as const;

export type CodeDomain = keyof typeof PREFIX;

/** `admin:totp-enrolled` → `code_audit_action_admin_totp_enrolled`. */
export function codeKey(domain: CodeDomain, code: string): string {
  const normalised = String(code ?? '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
  return `${PREFIX[domain]}${normalised}`;
}

/**
 * The Arabic (or English) label for one code.
 * `lang` defaults to Arabic because the product's default language is Arabic.
 */
export function label(code: string, domain: CodeDomain, lang: 'ar' | 'en' = 'ar'): string {
  const dict: Dictionary = lang === 'en' ? en : ar;
  const key = codeKey(domain, code);
  const value = dict[key];
  if (value) return value;
  if (process.env.NODE_ENV === 'test') {
    throw new Error(`i18n: no ${lang} label for ${domain} code "${code}" (expected key ${key})`);
  }
  return dict.code_unknown ?? '—';
}
