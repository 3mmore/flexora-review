/**
 * PACK 2 / ITEM 1 — dictionary integrity.
 *
 * These two dictionaries are the only source of user-visible text, so they are
 * also the fastest place to catch an English word or a raw key reaching a
 * screen. The browser crawl (scripts/check-arabic-ui.mjs) proves what a user
 * actually sees; this spec proves the SOURCE cannot silently ship a missing key.
 *
 * What it enforces:
 *   1. ar and en have exactly the same keys — a key added to one and forgotten
 *      in the other is how "English shows up in the Arabic app" starts;
 *   2. no empty or whitespace-only value (an empty string renders as a blank
 *      button, which is worse than a wrong word);
 *   3. no duplicate keys inside a file (the last one wins silently today);
 *   4. every literal t('…') / translateKey('…') in the app's source exists in
 *      both dictionaries. This is the check that would have caught
 *      `multi_branch` and `advanced_analytics` rendering as raw keys on the
 *      billing and license screens.
 */
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative, resolve } from 'node:path';
import { ar } from './ar';
import { en } from './en';
import {
  PLAN_CODES, GYM_STATUS_CODES, SUBSCRIPTION_STATUS_CODES, ADMIN_ROLE_CODES,
  ADMIN_STATUS_CODES, LICENSE_STATUS_CODES, MEMBER_STATUS_CODES, AUDIT_ACTION_CODES,
  CHECKIN_METHOD_CODES, PAYMENT_METHOD_CODES, label, type CodeDomain,
} from './codes';
import { FIELD_KEYS, FIELD_VALUES, fieldLabel, valueLabel } from './fields';
import { FEATURE_CODES, featureLabel } from './features';

const ROOT = resolve(__dirname, '../..');
const SRC = resolve(__dirname, '../..');

function walk(dir: string, out: string[] = []): string[] {
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    if (statSync(full).isDirectory()) {
      if (['node_modules', '.next', 'coverage'].includes(entry)) continue;
      walk(full, out);
    } else if (/\.(ts|tsx)$/.test(entry)) {
      out.push(full);
    }
  }
  return out;
}

const DICT_FILES = ['ar.ts', 'en.ts'];

// Keys assembled as `t(prefix + dataValue)`. Listed so a NEW dynamic key has to
// be acknowledged here (and then verified by the browser crawl).
const DYNAMIC_PREFIXES = [
  'cat_', 'mv_', 'platform_sub_plan_', 'platform_sub_status_', 'priority_', 'source_', 'st_', 'sub_',
  // runtime prefixes for a licence reason and an accounting account type —
  // each concatenated with a data value.
  // (PACK 2 item 5: 'method_' was removed from this list because the attendance
  // screen now shows the check-in SOURCE through `source_<SOURCE>` and no longer
  // builds a `method_<METHOD>` key. The assertion is unchanged and just as
  // strict: a dynamic prefix that is not declared here still fails the build.)
  'license_', 'account_type_help_',
  // PACK 2, item 3: the permissions dialog builds its labels from the API
  // catalogue (`perm_<members.create>` and `permgroup_<members>`). The set is
  // finite and is verified in permission-labels.spec.ts, which fails the build
  // if any permission or group in the API catalogue has no Arabic label.
  // (`perm_` is built inside a helper, not as a literal `t('perm_' + …)`.)
  'permgroup_',
];

/** Every `key: 'value'` pair in one dictionary file, in order, with duplicates. */
function parseDictionary(file: string): Array<{ key: string; value: string }> {
  const src = readFileSync(join(__dirname, file), 'utf8');
  const rows: Array<{ key: string; value: string }> = [];
  const re = /^ {2}([A-Za-z0-9_]+):\s*(['"])((?:\\.|(?!\2).)*)\2,\s*$/gm;
  let m: RegExpExecArray | null;
  while ((m = re.exec(src))) rows.push({ key: m[1], value: m[3] });
  return rows;
}

const arRows = parseDictionary('ar.ts');
const enRows = parseDictionary('en.ts');
const arKeys = new Set(Object.keys(ar));
const enKeys = new Set(Object.keys(en));

describe('i18n dictionaries', () => {
  it('ar and en declare exactly the same keys', () => {
    const onlyAr = [...arKeys].filter((k) => !enKeys.has(k)).sort();
    const onlyEn = [...enKeys].filter((k) => !arKeys.has(k)).sort();
    expect({ onlyAr, onlyEn }).toEqual({ onlyAr: [], onlyEn: [] });
  });

  it('has no empty values in either dictionary', () => {
    const blank = (dict: Record<string, string>) =>
      Object.entries(dict).filter(([, v]) => typeof v !== 'string' || v.trim() === '').map(([k]) => k);
    expect({ ar: blank(ar), en: blank(en) }).toEqual({ ar: [], en: [] });
  });

  it('declares no key twice inside a file (a later entry silently wins)', () => {
    const dupes = (rows: Array<{ key: string }>) => {
      const counts = new Map<string, number>();
      for (const { key } of rows) counts.set(key, (counts.get(key) || 0) + 1);
      return [...counts.entries()].filter(([, n]) => n > 1).map(([k]) => k).sort();
    };
    expect({ ar: dupes(arRows), en: dupes(enRows) }).toEqual({ ar: [], en: [] });
  });

  it('every literal t(…) key in the source exists in both dictionaries', () => {
    const files = walk(SRC).filter(
      (f) => !DICT_FILES.some((d) => f.endsWith(`/i18n/${d}`)) && !f.endsWith('.spec.ts') && !f.endsWith('.spec.tsx'),
    );
    // Literals only. Keys built at runtime are out of reach here and are covered
    // by the browser crawl instead; a key that ends with "_" or is followed by
    // "+" is a PREFIX for such a lookup (t('cat_' + value)), not a whole key, so
    // it is collected separately and must be declared in DYNAMIC_PREFIXES — a new
    // one then fails the build until someone looks at it.
    const callRe = /\b(?:t|translateKey)\(\s*['"]([A-Za-z0-9_]+)['"](\s*\+)?/g;
    const missing = new Map<string, string[]>();
    const dynamicPrefixes = new Set<string>();
    for (const file of files) {
      const src = readFileSync(file, 'utf8');
      let m: RegExpExecArray | null;
      while ((m = callRe.exec(src))) {
        const key = m[1];
        if (m[2] || key.endsWith('_')) { dynamicPrefixes.add(key); continue; }
        if (!ar[`${key}`] || !en[`${key}`]) {
          const list = missing.get(key) || [];
          if (list.length < 3) list.push(relative(ROOT, file));
          missing.set(key, list);
        }
      }
    }
    const report = [...missing.entries()].map(([k, where]) => `${k} (${where.join(', ')})`).sort();
    expect(report).toEqual([]);
    // Declared on purpose: these are prefixes concatenated with a data value.
    expect([...dynamicPrefixes].sort()).toEqual([...DYNAMIC_PREFIXES].sort());
  });
});

/**
 * The code tables are the other half of "no English in the UI": a status, tier,
 * plan, role, audit action or check-in method that reaches a screen must have a
 * label in BOTH dictionaries, and `label()` throws in a test build when it does
 * not. Removing one entry from ar.ts or en.ts turns this red.
 */
describe('code tables', () => {
  const domains: Array<[CodeDomain, readonly string[]]> = [
    ['plan', PLAN_CODES],
    ['gymStatus', GYM_STATUS_CODES],
    ['subscriptionStatus', SUBSCRIPTION_STATUS_CODES],
    ['adminRole', ADMIN_ROLE_CODES],
    ['adminStatus', ADMIN_STATUS_CODES],
    ['licenseStatus', LICENSE_STATUS_CODES],
    ['memberStatus', MEMBER_STATUS_CODES],
    ['auditAction', AUDIT_ACTION_CODES],
    ['checkinMethod', CHECKIN_METHOD_CODES],
    ['paymentMethod', PAYMENT_METHOD_CODES],
  ];

  it.each(domains)('every %s code has an Arabic and an English label', (domain, codes) => {
    for (const code of codes) {
      const arLabel = label(code, domain, 'ar');
      const enLabel = label(code, domain, 'en');
      expect(arLabel.length).toBeGreaterThan(0);
      expect(enLabel.length).toBeGreaterThan(0);
      // the label must not be the code itself (that is what "raw code on screen" means)
      expect(arLabel).not.toBe(code);
    }
  });

  it('every plan/licence feature code has a label in both languages', () => {
    for (const code of FEATURE_CODES) {
      expect(featureLabel(code, 'ar')).not.toBe(ar.feature_generic);
      expect(featureLabel(code, 'en')).not.toBe(en.feature_generic);
    }
  });

  it('every field and field value on the generic resource pages is labelled', () => {
    for (const field of FIELD_KEYS) {
      expect(fieldLabel(field, 'ar').length).toBeGreaterThan(0);
      expect(fieldLabel(field, 'en').length).toBeGreaterThan(0);
    }
    for (const [field, values] of Object.entries(FIELD_VALUES)) {
      for (const value of values) {
        expect(valueLabel(field, value, 'ar')).not.toBe(ar.value_generic);
        expect(valueLabel(field, value, 'en')).not.toBe(en.value_generic);
      }
    }
  });
});
