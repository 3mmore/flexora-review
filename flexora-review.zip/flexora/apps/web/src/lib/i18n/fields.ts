/**
 * PACK 2 / ITEM 1 — field and value labels for the generic resource pages.
 *
 * `OperationalResourcePage` renders whatever keys an endpoint returns, which is
 * how `status`, `timestamp`, `confidence`, `source` and the values `ready`,
 * `high`, `heuristic` reached a user's screen as-is. Two lookups fix that
 * without hand-writing a page per endpoint:
 *
 *   fieldLabel('confidence')  →  «الثقة»        (dictionary key field_confidence)
 *   valueLabel('confidence', 'high') → «مرتفعة» (dictionary key value_confidence_high)
 *
 * A missing key falls back to the generic Arabic word for "field"/"value"
 * instead of the raw identifier, and dictionary.spec.ts enumerates every field
 * and value the API can emit so a gap fails the build instead of leaking.
 */
import { ar } from './ar';
import { en } from './en';

export type Lang = 'ar' | 'en';

/** Fields the operational endpoints return. Keep in sync with the API DTOs. */
export const FIELD_KEYS = [
  'status', 'timestamp', 'ready', 'answer', 'confidence', 'source', 'name', 'slug',
  'category', 'logo', 'accentColor', 'plan', 'tier', 'price', 'active', 'count',
  'message', 'code', 'level', 'severity', 'channel', 'target', 'createdAt',
] as const;

/** Values that appear in those fields, as `field:value` pairs. */
export const FIELD_VALUES: Record<string, readonly string[]> = {
  status: ['ACTIVE', 'SUSPENDED', 'DELETED', 'TRIAL', 'ERROR', 'OK'],
  ready: ['ready', 'degraded', 'down'],
  confidence: ['high', 'medium', 'low'],
  source: ['heuristic', 'model', 'rule', 'cache', 'live'],
  level: ['info', 'warning', 'critical'],
  severity: ['low', 'medium', 'high'],
  active: ['true', 'false'],
  category: ['operations', 'marketing', 'finance', 'ai', 'growth'],
};

function dict(lang: Lang): Record<string, string> {
  return lang === 'en' ? en : ar;
}

/** Column header for a field key. */
export function fieldLabel(key: string, lang: Lang = 'ar'): string {
  const d = dict(lang);
  return d[`field_${key}`] ?? d.field_generic ?? '—';
}

/** Human label for a value inside a known field. */
export function valueLabel(field: string, value: string, lang: Lang = 'ar'): string {
  const d = dict(lang);
  const key = `value_${field}_${String(value ?? '').trim().toLowerCase()}`;
  return d[key] ?? d.value_generic ?? '—';
}
