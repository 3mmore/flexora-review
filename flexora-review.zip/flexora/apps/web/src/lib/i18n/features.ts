/**
 * PACK 2 / ITEM 1 — feature/entitlement codes as words.
 *
 * `Plan.features` and `License.features` are arrays of stable codes
 * (`multi_branch`, `advanced_analytics`, `webauthn`). The billing page used
 * `t(code) || code`, so a code with no entry printed itself — the two raw keys
 * measured on /billing and /license were exactly that. A missing label is now a
 * neutral Arabic word instead of a Latin identifier, and dictionary.spec.ts
 * enumerates every code so the gap cannot come back silently.
 */
import { ar } from './ar';
import { en } from './en';

export const FEATURE_CODES = [
  'basic_reports', 'members_attendance', 'smart_ai', 'messaging_landing',
  'advanced_reports', 'api_access', 'all_pro_features', 'white_label',
  'multi_branch', 'dedicated_support', 'advanced_analytics', 'webauthn',
  'payroll', 'pos', 'accounting', 'classes', 'crm', 'wa_bot',
] as const;

export function featureLabel(code: string, lang: 'ar' | 'en' = 'ar'): string {
  const d: Record<string, string> = lang === 'en' ? en : ar;
  return d[`feature_${code}`] ?? d.feature_generic ?? '—';
}

/** Button variants shown on the design-system reference page. */
const BUTTON_VARIANTS: Record<string, { ar: string; en: string }> = {
  primary: { ar: 'أساسي', en: 'Primary' },
  secondary: { ar: 'ثانوي', en: 'Secondary' },
  danger: { ar: 'خطر', en: 'Danger' },
  ghost: { ar: 'شفاف', en: 'Ghost' },
};

export function buttonVariantLabel(variant: string, lang: 'ar' | 'en' = 'ar'): string {
  return BUTTON_VARIANTS[variant]?.[lang] ?? variant;
}
