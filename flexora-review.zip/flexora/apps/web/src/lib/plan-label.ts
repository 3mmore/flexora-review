/**
 * FLEXORA Gym OS — Plan label localisation (Phase 5)
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Phase 5 fix: plan-selection dropdowns rendered raw English fragments
 * ("1 Month", "3 Months", "15 Sessions", "EGP") in the middle of an otherwise
 * Arabic UI. Plan names are free text typed by the gym owner, so they cannot
 * simply be added to the translation dictionary. Instead we recognise the
 * common English duration/session patterns (including the legacy seeded demo
 * names) and render them in the active language, leaving any genuinely custom
 * Arabic name untouched.
 */

type T = (key: string) => string;

const AR_UNITS = {
  day: ['يوم', 'يومان', 'أيام'],
  month: ['شهر', 'شهران', 'أشهر'],
  year: ['سنة', 'سنتان', 'سنوات'],
  session: ['حصة', 'حصتان', 'حصص'],
} as const;

type UnitKey = keyof typeof AR_UNITS;

/** Arabic dual/plural rules: 1 → singular, 2 → dual, 3-10 → plural, 11+ → singular. */
function arabicCount(n: number, unit: UnitKey): string {
  const [one, two, many] = AR_UNITS[unit];
  if (n === 1) return one;
  if (n === 2) return two;
  if (n >= 3 && n <= 10) return `${n} ${many}`;
  return `${n} ${one}`;
}

function englishCount(n: number, unit: UnitKey): string {
  const word = unit.charAt(0).toUpperCase() + unit.slice(1);
  return `${n} ${word}${n === 1 ? '' : 's'}`;
}

const PATTERNS: Array<{ re: RegExp; unit: UnitKey }> = [
  { re: /^(\d+)\s*-?\s*months?$/i, unit: 'month' },
  { re: /^(\d+)\s*-?\s*years?$/i, unit: 'year' },
  { re: /^(\d+)\s*-?\s*days?$/i, unit: 'day' },
  { re: /^(\d+)\s*-?\s*sessions?$/i, unit: 'session' },
];

/**
 * Localise a plan NAME. Returns the original string when it is not one of the
 * recognised English duration/session patterns (e.g. a custom "باقة الحديد").
 */
export function localizePlanName(name: string, lang: string): string {
  const raw = (name || '').trim();
  if (!raw) return raw;
  for (const { re, unit } of PATTERNS) {
    const m = raw.match(re);
    if (m) {
      const n = Number(m[1]);
      if (!Number.isFinite(n)) break;
      return lang === 'ar' ? arabicCount(n, unit) : englishCount(n, unit);
    }
  }
  return raw;
}

/**
 * Full dropdown option label: localised plan name + price in the active
 * language's currency wording (never a hard-coded "EGP" inside Arabic text).
 */
export function planOptionLabel(
  plan: { name: string; price: number | string },
  lang: string,
  t: T,
): string {
  // Always Western digits: Egyptian gym UIs use them everywhere else in the
  // app (prices, tables, reports), and mixing Arabic-Indic numerals into one
  // dropdown while the rest of the screen uses Western digits reads badly.
  const price = Number(plan.price || 0).toLocaleString('en-US');
  return `${localizePlanName(plan.name, lang)} — ${price} ${t('currency')}`;
}
