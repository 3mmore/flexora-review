import { attendanceCsvFilename, buildAttendanceCsvUrl } from './attendance-csv';

describe('buildAttendanceCsvUrl', () => {
  it('asks the API for the CSV format', () => {
    expect(buildAttendanceCsvUrl('http://api:4000/api', '')).toBe('http://api:4000/api/attendance?format=csv');
  });

  it('carries the branch the table is showing', () => {
    expect(buildAttendanceCsvUrl('http://api:4000/api', 'br_1')).toBe(
      'http://api:4000/api/attendance?format=csv&branchId=br_1',
    );
  });

  it('encodes an id that needs it, and never trims it into something else', () => {
    const url = buildAttendanceCsvUrl('http://api:4000/api', 'a b&c');
    expect(url).toContain('branchId=a+b%26c');
  });

  it('sends no branchId for an empty / whitespace / null filter', () => {
    for (const v of ['', '   ', null, undefined]) {
      expect(buildAttendanceCsvUrl('http://api:4000/api', v)).toBe('http://api:4000/api/attendance?format=csv');
    }
  });

  it('carries the source filter, and omits it when empty', () => {
    expect(buildAttendanceCsvUrl('http://api:4000/api', '', 'SELF_PLAIN')).toBe(
      'http://api:4000/api/attendance?format=csv&source=SELF_PLAIN',
    );
    expect(buildAttendanceCsvUrl('http://api:4000/api', 'b1', 'SELF_PLAIN')).toBe(
      'http://api:4000/api/attendance?format=csv&branchId=b1&source=SELF_PLAIN',
    );
    for (const v of ['', '  ', null, undefined]) {
      expect(buildAttendanceCsvUrl('http://api:4000/api', '', v)).toBe(
        'http://api:4000/api/attendance?format=csv',
      );
    }
  });

  it('does not double the slash when the base ends with one', () => {
    expect(buildAttendanceCsvUrl('http://api:4000/api/', '')).toBe('http://api:4000/api/attendance?format=csv');
  });
});

describe('attendanceCsvFilename', () => {
  it('uses the server name when present', () => {
    expect(attendanceCsvFilename('attachment; filename="attendance.csv"')).toBe('attendance.csv');
    expect(attendanceCsvFilename('attachment; filename="حضور-اليوم.csv"')).toBe('حضور-اليوم.csv');
  });

  it('prefers an RFC 5987 encoded name', () => {
    expect(attendanceCsvFilename("attachment; filename*=UTF-8''%D8%AD%D8%B6%D9%88%D8%B1.csv")).toBe('حضور.csv');
  });

  it('falls back to a fixed name rather than inventing one', () => {
    expect(attendanceCsvFilename(null)).toBe('attendance.csv');
    expect(attendanceCsvFilename('attachment')).toBe('attendance.csv');
    expect(attendanceCsvFilename('')).toBe('attendance.csv');
  });

  it('never lets a header choose a path', () => {
    expect(attendanceCsvFilename('attachment; filename="../../etc/passwd"')).toBe('passwd');
    expect(attendanceCsvFilename('attachment; filename="C:\\\\windows\\\\x.csv"')).toBe('x.csv');
  });
});
