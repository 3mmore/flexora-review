import type { Permission } from './permissions';
import type { IconName } from '@/components/brand/Icon';

/**
 * The one navigation structure (Pack 2, item 2).
 *
 * It used to live inside `components/Shell.tsx`, which meant the phone's "More"
 * index could only be kept in step by hand-copying it. It lives here instead, and
 * both surfaces — the desktop sidebar and the mobile index — render this list.
 * Adding or removing a destination is one edit, and a destination cannot exist on
 * desktop without existing on the phone.
 *
 * Gating is unchanged from the sidebar this was extracted from: `perms` items
 * require every listed permission (the same list the API guard enforces), `roles`
 * items require one of the listed roles, and an item with neither is open to any
 * signed-in user of the tenant app.
 */

export type NavItem = {
  href: string;
  key: string;
  icon: IconName;
  perms?: Permission[];
  roles?: string[];
  badge?: 'unread';
};

export type NavGroup = { label: string; items: NavItem[] };

export const NAV_GROUPS: NavGroup[] = [
  { label: 'overview', items: [{ href: '/dashboard', key: 'dashboard', icon: 'home' }] },
  {
    label: 'members',
    items: [
      { href: '/members', key: 'members', icon: 'users', perms: ['members.view'] },
      { href: '/attendance', key: 'attendance', icon: 'home', perms: ['members.view'] },
      { href: '/checkin', key: 'checkin', icon: 'qr-scan', perms: ['attendance.manual'] },
      { href: '/biometric', key: 'biometric', icon: 'bio', perms: ['members.edit'] },
      { href: '/invitations', key: 'invitations', icon: 'send', perms: ['members.create'] },
    ],
  },
  {
    label: 'sales',
    items: [
      { href: '/leads', key: 'leads', icon: 'lightning', perms: ['members.create'] },
      { href: '/crm', key: 'crm', icon: 'chart', perms: ['reports.view'] },
      { href: '/campaigns', key: 'campaigns', icon: 'send', perms: ['reports.view'] },
      { href: '/contracts', key: 'contracts', icon: 'image', perms: ['contracts.manage'] },
    ],
  },
  {
    label: 'operations',
    items: [
      { href: '/classes', key: 'classes', icon: 'calendar', perms: ['classes.manage'] },
      { href: '/coach', key: 'coach', icon: 'dumbbell', perms: ['classes.manage'] },
      { href: '/users', key: 'staff', icon: 'users', perms: ['staff.manage'] },
      { href: '/transfers', key: 'transfers', icon: 'send', perms: ['inventory.manage'] },
      { href: '/inventory', key: 'inventory', icon: 'menu-grid', perms: ['inventory.view'] },
      { href: '/pos', key: 'pos', icon: 'coins', perms: ['pos.sell'] },
      { href: '/staff-attendance', key: 'staff_attendance', icon: 'users', perms: ['attendance.manual'] },
    ],
  },
  {
    label: 'accounting',
    items: [
      { href: '/reports', key: 'reports', icon: 'chart', perms: ['reports.view'] },
      { href: '/accounting', key: 'accounting', icon: 'coins', perms: ['accounting.view'] },
      { href: '/billing', key: 'subscription', icon: 'coins', perms: ['billing.manage'] },
      { href: '/license', key: 'license', icon: 'shield', perms: ['billing.manage'] },
    ],
  },
  {
    label: 'intelligence',
    items: [
      { href: '/ai', key: 'ai_insights', icon: 'sparkle', perms: ['reports.view'] },
      { href: '/ai-advanced', key: 'ai_advanced', icon: 'lightning', perms: ['reports.view'] },
    ],
  },
  {
    label: 'enterprise_label',
    items: [
      // P3: /enterprise (custom roles / SCIM / SSO admin) is ELITE-gated and
      // the web surface is only a read-only list — unfinished scaffolding, so
      // it is hidden from the nav. The route itself stays reachable for
      // entitled gyms.
      { href: '/white-label', key: 'white_label', icon: 'image', perms: ['settings.manage'] },
      { href: '/marketplace', key: 'marketplace', icon: 'menu-grid', perms: ['settings.manage'] },
      { href: '/backups', key: 'backups', icon: 'shield', perms: ['backups.manage'] },
    ],
  },
  {
    label: 'system_health',
    items: [
      { href: '/settings', key: 'settings', icon: 'cog', perms: ['settings.manage'] },
      { href: '/wa-bot', key: 'wa_bot', icon: 'send', perms: ['settings.manage'] },
      { href: '/notifications', key: 'notifications', icon: 'bell', roles: ['OWNER', 'MANAGER'], badge: 'unread' },
      { href: '/team/performance', key: 'team_performance', icon: 'chart', perms: ['team.performance.view'] },
      { href: '/support', key: 'support', icon: 'bell' },
    ],
  },
];

/** The mobile index reuses the same groups; a route can never exist on one only. */
export const MORE_GROUPS: NavGroup[] = NAV_GROUPS;

/** Every destination reachable from the navigation, for the structure tests. */
export const NAV_HREFS: string[] = NAV_GROUPS.flatMap((g) => g.items.map((i) => i.href));

/**
 * The phone tab bar's destinations, exported here so the structure test can
 * assert them without importing a React component. `MobileTabBar` builds its
 * tabs from the same five routes; a sixth tab would fail the test above.
 */
export const MobileTabHrefs: string[] = ['/dashboard', '/members', '/checkin', '/money', '/more'];
