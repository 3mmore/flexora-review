/**
 * FLEXORA Gym OS — owner notification inbox helpers.
 *
 * Everything here is pure and testable without a DOM, because the web app has
 * no component-testing dependency and this pack adds none. The page imports
 * exactly these functions, so a bug in the query string, the link policy or the
 * date formatting is caught by `notifications.spec.ts` rather than by a user.
 */
import { api } from './api';

export type NotificationSeverity = 'info' | 'warning' | 'danger' | 'success';
export type NotificationStatus = 'all' | 'unread' | 'read';

export interface NotificationListItem {
  id: string;
  type: string;
  title: string;
  body: string;
  icon: string;
  severity: NotificationSeverity | string;
  isRead: boolean;
  createdAt: string;
  hasMetadata: boolean;
}

export interface NotificationMetaEntry {
  label: string;
  value: string;
  kind: 'text' | 'number' | 'bool' | 'link' | 'summary';
}

export interface NotificationDetail extends NotificationListItem {
  metadata: NotificationMetaEntry[] | null;
  metadataUnreadable: boolean;
  metadataTruncated: boolean;
}

export interface NotificationFeed {
  items: NotificationListItem[];
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
  unread: number;
  unreadInRange: number;
  range: { from: string; to: string; tz: string };
}

export interface NotificationFilters {
  status: NotificationStatus;
  severity: '' | NotificationSeverity;
  type: string;
  from: string;
  to: string;
  q: string;
  sort: 'newest' | 'oldest';
  page: number;
  pageSize: number;
}

export const EMPTY_FILTERS: NotificationFilters = {
  status: 'all',
  severity: '',
  type: '',
  from: '',
  to: '',
  q: '',
  sort: 'newest',
  page: 1,
  pageSize: 20,
};

/** Hard ceilings that mirror the API DTO — the client never asks for more. */
export const MAX_PAGE_SIZE = 100;
export const MAX_RANGE_DAYS = 366;

/**
 * Build the `/owner/notifications/feed` query string.
 *
 * Only non-empty values are emitted: an empty `severity=` would be rejected by
 * the API's DTO (`@IsIn`), turning "no filter" into a 400.
 */
export function buildFeedQuery(filters: Partial<NotificationFilters> = {}): string {
  const f: NotificationFilters = { ...EMPTY_FILTERS, ...filters };
  const params: string[] = [];
  const add = (k: string, v: string | number) => params.push(`${k}=${encodeURIComponent(String(v))}`);

  if (f.status && f.status !== 'all') add('status', f.status);
  if (f.severity) add('severity', f.severity);
  if (f.type) add('type', f.type.trim().toUpperCase());
  if (f.from) add('from', f.from);
  if (f.to) add('to', f.to);
  const q = f.q.trim();
  if (q) add('q', q);
  if (f.sort === 'oldest') add('sort', 'oldest');
  add('page', Math.max(1, Math.floor(f.page) || 1));
  add('pageSize', Math.min(MAX_PAGE_SIZE, Math.max(1, Math.floor(f.pageSize) || 20)));
  return params.join('&');
}

/**
 * Which URLs may be turned into a link inside notification metadata.
 *
 * Metadata can carry text a member typed. Only absolute http(s) URLs pass;
 * `javascript:`, `data:`, `vbscript:`, protocol-relative `//host` and anything
 * that fails to parse are rendered as plain text. The API applies the same
 * rule when it marks an entry as `kind: 'link'` — this is the second check, in
 * the place that actually creates the anchor.
 */
export function isSafeLink(value: string): boolean {
  if (typeof value !== 'string' || value.length === 0 || value.length > 2048) return false;
  if (/^\s*(javascript|data|vbscript|file):/i.test(value)) return false;
  try {
    const url = new URL(value);
    if (url.protocol !== 'http:' && url.protocol !== 'https:') return false;
    if (!url.hostname || url.hostname.includes(' ')) return false;
    return true;
  } catch {
    return false;
  }
}

/** Severity → the CSS variable the design system already uses. */
export function severityColor(severity: string): string {
  switch (severity) {
    case 'danger': return 'var(--danger)';
    case 'warning': return 'var(--warning)';
    case 'success': return 'var(--success, #00e5a0)';
    default: return 'var(--cyan)';
  }
}

/** i18n key per severity — no raw key ever reaches the screen (both files define all five). */
export function severityKey(severity: string): string {
  switch (severity) {
    case 'danger': return 'severity_danger';
    case 'warning': return 'severity_warning';
    case 'success': return 'severity_success';
    default: return 'severity_info';
  }
}

/**
 * Notification TYPE as a human phrase. Types are stored codes (SALE,
 * MEMBER_NEW…). Unknown codes are humanised ("STAFF_FLAG" → "STAFF FLAG")
 * rather than shown raw with underscores, and never dropped.
 */
export function typeKey(type: string): string | null {
  const known = ['SALE', 'SALE_ALERT', 'MEMBER_NEW', 'MEMBER_DELETED', 'REFUND', 'RENEWAL', 'SUSPICIOUS'];
  return known.includes(type) ? `notification_type_${type.toLowerCase()}` : null;
}

/** Trim/limit the preview text a list row shows. */
export function previewText(body: string, max = 140): string {
  const text = String(body ?? '').replace(/\s+/g, ' ').trim();
  return text.length <= max ? text : `${text.slice(0, max - 1)}…`;
}

/**
 * Format an instant for display in the user's language.
 * `ar-EG` renders Arabic names/digits; `en-GB` a 24h date. The API always
 * returns UTC ISO strings, so the browser's own zone is the last hop — the
 * gym-zone day boundaries are computed server-side and echoed in `range`.
 */
export function formatWhen(iso: string, lang: 'ar' | 'en'): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  try {
    return new Intl.DateTimeFormat(lang === 'ar' ? 'ar-EG' : 'en-GB', {
      year: 'numeric', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit', hour12: false,
    }).format(d);
  } catch {
    return d.toISOString().slice(0, 16).replace('T', ' ');
  }
}

/** The machine-readable date used in exports (never localised digits). */
export function isoDay(iso: string): string {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? '' : d.toISOString().slice(0, 10);
}

// ── unread badge store ──────────────────────────────────────────────────────
//
// One polling loop for the whole shell. The bell and the sidebar badge read the
// same number, so the header cannot say 3 while the nav says 1, and the browser
// makes one request per interval instead of two.

type Listener = (count: number) => void;
let unreadCount = 0;
let inFlight: Promise<number> | null = null;
const listeners = new Set<Listener>();

export function getUnreadCount(): number {
  return unreadCount;
}

export function setUnreadCount(next: number): void {
  unreadCount = Number.isFinite(next) ? Math.max(0, Math.floor(next)) : 0;
  listeners.forEach((l) => { try { l(unreadCount); } catch { /* a listener must not break the others */ } });
}

export function subscribeUnread(fn: Listener): () => void {
  listeners.add(fn);
  fn(unreadCount);
  return () => { listeners.delete(fn); };
}

/** Fetch the server's count; failures keep the last known value (never 0-by-accident). */
export async function refreshUnreadCount(): Promise<number> {
  if (inFlight) return inFlight;
  inFlight = api<{ count: number }>('/owner/notifications/unread-count')
    .then((r) => { setUnreadCount(Number(r?.count ?? 0)); return unreadCount; })
    .catch(() => unreadCount)
    .finally(() => { inFlight = null; });
  return inFlight;
}

/** Test-only reset so one spec cannot leak state into the next. */
export function __resetUnreadForTests(): void {
  unreadCount = 0;
  inFlight = null;
  listeners.clear();
}
