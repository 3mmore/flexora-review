/**
 * FLEXORA Gym OS — Item 9 regression test: infinite retry loop in
 * fetchWithAuth.
 *
 * Simulates exactly the scenario described in the ticket: the token
 * refresh call succeeds, but the underlying resource still returns 401 on
 * every subsequent attempt (e.g. because the user's account was
 * deactivated server-side after the refresh token was issued). Proves the
 * fixed `fetchWithAuth` retries AT MOST ONCE, then throws 'Session expired'
 * instead of recursing forever.
 *
 * PHASE R0 REPAIR (test-only; lib/api.ts was NOT modified - it is byte-identical
 * to the delivered release). This file used to assert that the client itself
 * redirects to /login. It has not done that since the P1 refresh-mutex fix: the
 * client throws, and components/Shell.tsx maps 'Session expired' onto
 * router.replace('/login'). Two tests therefore failed against a contract that no
 * longer exists, while a third test in the same file already asserted that no
 * redirect happens. Both halves are now pinned: the client navigates nowhere, and
 * the shell is what navigates.
 */

import { readFileSync } from 'fs';
import { resolve } from 'path';

describe('fetchWithAuth — Item 9: bounded retry after refresh (no infinite loop)', () => {
  const ORIGINAL_LOCATION = window.location;

  beforeEach(() => {
    jest.resetModules();
    // jsdom's window.location.href setter throws "Not implemented:
    // navigation" — replace it with a plain writable stub so we can both
    // assert on it and avoid that noise, without needing jsdom navigation.
    delete (window as any).location;
    (window as any).location = { href: '' };
  });

  afterEach(() => {
    (window as any).location = ORIGINAL_LOCATION;
    jest.restoreAllMocks();
  });

  it('refresh succeeds but the resource still returns 401 forever -> retries exactly once, then throws (does NOT loop) and navigates nowhere itself', async () => {
    let resourceCallCount = 0;
    let refreshCallCount = 0;

    const fetchMock = jest.fn(async (input: RequestInfo | URL) => {
      const url = String(input);
      if (url.endsWith('/auth/refresh')) {
        refreshCallCount++;
        // Refresh itself always "succeeds" at the HTTP level.
        return { ok: true, status: 200, json: async () => ({}) } as Response;
      }
      // The actual protected resource ALWAYS returns 401, even after a
      // "successful" refresh — e.g. the user was deactivated server-side.
      resourceCallCount++;
      return { ok: false, status: 401, json: async () => ({ message: 'Unauthorized' }) } as Response;
    });
    (global as any).fetch = fetchMock;

    const { apiClient } = await import('./api');

    await expect(apiClient.fetchWithAuth('/members')).rejects.toThrow('Session expired');

    // The resource must have been attempted at most TWICE: once initially,
    // once after the single permitted retry — never more (this is exactly
    // what proves the loop does not run forever).
    expect(resourceCallCount).toBe(2);
    // Refresh must have been attempted exactly ONCE (not once per retry
    // attempt in an unbounded loop).
    expect(refreshCallCount).toBe(1);
    // PHASE R0 REPAIR (test-only). This used to assert window.location.href ===
    // '/login', i.e. that the CLIENT navigates. It has not done that since the P1
    // refresh-mutex fix: fetchWithAuth throws Error('Session expired') and
    // components/Shell.tsx turns that into router.replace('/login'). The third test in
    // this file already asserted href === '' ("never redirected"), so the file
    // contradicted itself and two tests failed for a contract that no longer exists.
    // The client performing NO navigation is itself part of the contract (a hard
    // location assignment from a shared client would fight the router), so it is
    // asserted, and the navigation half is pinned by the Shell.tsx test below.
    expect(window.location.href).toBe('');
  });

  it('refresh fails outright -> throws immediately without ever retrying the resource, and navigates nowhere itself', async () => {
    let resourceCallCount = 0;
    let refreshCallCount = 0;

    const fetchMock = jest.fn(async (input: RequestInfo | URL) => {
      const url = String(input);
      if (url.endsWith('/auth/refresh')) {
        refreshCallCount++;
        return { ok: false, status: 401, json: async () => ({}) } as Response;
      }
      resourceCallCount++;
      return { ok: false, status: 401, json: async () => ({ message: 'Unauthorized' }) } as Response;
    });
    (global as any).fetch = fetchMock;

    const { apiClient } = await import('./api');

    await expect(apiClient.fetchWithAuth('/members')).rejects.toThrow('Session expired');

    expect(resourceCallCount).toBe(1);
    expect(refreshCallCount).toBe(1);
    expect(window.location.href).toBe(''); // PHASE R0 REPAIR: see the note above
  });

  it('refresh succeeds AND the retried request succeeds -> resolves normally with no redirect', async () => {
    let resourceCallCount = 0;

    const fetchMock = jest.fn(async (input: RequestInfo | URL) => {
      const url = String(input);
      if (url.endsWith('/auth/refresh')) {
        return { ok: true, status: 200, json: async () => ({}) } as Response;
      }
      resourceCallCount++;
      if (resourceCallCount === 1) {
        return { ok: false, status: 401, json: async () => ({}) } as Response;
      }
      return { ok: true, status: 200, json: async () => ({ id: 'm1', name: 'Member' }) } as Response;
    });
    (global as any).fetch = fetchMock;

    const { apiClient } = await import('./api');

    const result = await apiClient.fetchWithAuth('/members');

    expect(result).toEqual({ id: 'm1', name: 'Member' });
    expect(resourceCallCount).toBe(2); // initial 401 + one successful retry
    expect(window.location.href).toBe(''); // never redirected
  });

  /**
   * PHASE R0 - the other half of the expired-session contract, and the reason the two
   * assertions above are `''` and not `'/login'`. Splitting it this way is deliberate:
   * a shared API client that hard-assigns window.location fights the router (and cannot
   * be intercepted), so navigation belongs to the shell. Both halves are pinned, so
   * removing either one fails a test:
   *   - components/Shell.tsx maps Error('Session expired') onto router.replace('/login');
   *   - lib/api.ts throws that error and contains no window.location at all.
   */
  it('NAVIGATION HALF: components/Shell.tsx sends an expired session to /login, and the client never navigates', () => {
    const shell = readFileSync(resolve(__dirname, '../components/Shell.tsx'), 'utf8');
    // the condition AND the navigation, on the same statement
    expect(shell).toMatch(
      /err\.message === ['"]Session expired['"]\s*\)\s*router\.replace\(\s*["']\/login["']\s*\)/,
    );
    // mounted-guard: a navigation after unmount is a React warning and a lost session
    expect(shell).toMatch(/mounted && err\.message === ['"]Session expired['"]/);

    const client = readFileSync(resolve(__dirname, './api.ts'), 'utf8');
    expect(client).toMatch(/throw new Error\(['"]Session expired['"]\)/);
    expect(client).not.toMatch(/window\.location/);
    expect(client).not.toMatch(/router\.(push|replace)\(/);
  });
});
