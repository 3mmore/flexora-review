'use client';
/**
 * 404 — Arabic, like every other screen (PACK 2, item 1).
 *
 * Before this file existed, an unknown URL fell through to Next's built-in
 * not-found page, which is hardcoded English ("404 — This page could not be
 * found") and LTR. The owner saw exactly that on a phone.
 *
 * It is a client component only so it can follow the user's language setting
 * (Arabic by default) through the same `useTranslation` hook the rest of the app
 * uses — a server component could not read that setting, and a second, static
 * copy of the strings would drift from the dictionary.
 */
import Link from 'next/link';
import { useTranslation } from '@/lib/i18n';

export default function NotFound() {
  const { t } = useTranslation();
  return (
    <main
      dir="rtl"
      className="min-h-screen bg-base text-white flex items-center justify-center px-5 py-16"
      style={{ minHeight: '100dvh' }}
    >
      <div className="w-full max-w-md text-center space-y-6">
        <div className="text-6xl font-display font-bold text-primary">404</div>
        <h1 className="text-2xl font-bold">{t('not_found_title')}</h1>
        <p className="text-silver-dim leading-relaxed">{t('not_found_desc')}</p>
        <div className="flex flex-col gap-3 pt-2">
          <Link
            href="/dashboard"
            className="w-full min-h-[48px] inline-flex items-center justify-center rounded-xl bg-primary text-black font-bold px-6"
          >
            {t('not_found_home')}
          </Link>
          <Link
            href="/members"
            className="w-full min-h-[48px] inline-flex items-center justify-center rounded-xl border border-titanium text-white px-6"
          >
            {t('members')}
          </Link>
        </div>
      </div>
    </main>
  );
}
