'use client';
/**
 * Route error boundary — Arabic (PACK 2, item 1).
 *
 * Without this file a thrown error in any page fell through to Next's default
 * error screen, which is English. This one renders INSIDE the root layout, so it
 * keeps the app's styles, RTL direction and language setting.
 */
import { useEffect } from 'react';
import { useTranslation } from '@/lib/i18n';

export default function ErrorPage({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  const { t } = useTranslation();

  useEffect(() => {
    // Keep the technical detail in the console for whoever debugs it, never on
    // the screen: a digest or a stack trace in the UI is both English and noise.
    console.error('[page error]', error?.message, error?.digest);
  }, [error]);

  return (
    <main
      dir="rtl"
      className="min-h-screen bg-base text-white flex items-center justify-center px-5 py-16"
      style={{ minHeight: '100dvh' }}
    >
      <div className="w-full max-w-md text-center space-y-6">
        <div className="mx-auto w-14 h-14 rounded-2xl bg-danger/15 border border-danger/40 flex items-center justify-center text-2xl">
          !
        </div>
        <h1 className="text-2xl font-bold">{t('error_title')}</h1>
        <p className="text-silver-dim leading-relaxed">{t('error_desc')}</p>
        <div className="flex flex-col gap-3 pt-2">
          <button
            type="button"
            onClick={reset}
            className="w-full min-h-[48px] rounded-xl bg-primary text-black font-bold px-6"
          >
            {t('error_retry')}
          </button>
          <a
            href="/dashboard"
            className="w-full min-h-[48px] inline-flex items-center justify-center rounded-xl border border-titanium text-white px-6"
          >
            {t('not_found_home')}
          </a>
        </div>
        {error?.digest ? (
          <p className="text-[11px] text-silver-muted pt-2">
            {t('error_reference')} <span dir="ltr">{error.digest}</span>
          </p>
        ) : null}
      </div>
    </main>
  );
}
