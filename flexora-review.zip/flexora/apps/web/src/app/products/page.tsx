'use client';
import { useCallback, useEffect, useState } from 'react';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { useTranslation } from '@/lib/i18n';
import { Card } from '@/components/ui/Card';
import { FeedbackLayer, InsightCard, InsightLayer, ProductPage, SmartTable } from '@/components/ProductOS';
import { Skeleton } from '@/components/ui/States';
import { safeErrorMessage } from '@/lib/safe-error';
import { ModalPortal } from '@/components/ModalPortal';
import { useBranchScope } from '@/lib/branch-scope';

interface Product {
  id?: string; name: string; nameAr?: string; category: string; sellingPrice: number; costPrice: number;
  qty: number; barcode?: string; icon?: string; supplier?: string; lowStockThreshold?: number; lowAlert?: number;
  branch?: { id: string; name: string } | null;
  /** PHASE 8 — the branch stored on the product itself. */
  branchId?: string | null;
  branchAssigned?: boolean;
}
interface BranchOption { id: string; name: string }

export default function Products() {
  const { t } = useTranslation();
  const [items, setItems] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<Partial<Product> | null>(null);
  const [branches, setBranches] = useState<BranchOption[]>([]);
  const [err, setErr] = useState('');
  // Unrestricted roles (owner / general manager) choose the branch on the
  // form; every other role is pinned to their own branch by the API and sees
  // a locked label instead of a picker (Phase 4 rule).
  const scope = useBranchScope();
  const ownsBranchChoice = !scope.ok || scope.unrestricted;
  // Only OWNER/MANAGER may create, edit or delete products (the API says so on
  // every write route); every other role gets a read-only catalogue instead of
  // buttons that could only ever return 403.
  const canManage = !scope.ok || ['OWNER', 'MANAGER'].includes(scope.role);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api<any>('/products');
      setItems(Array.isArray(data) ? data : (data.items || []));
    } catch (e: unknown) { setErr(safeErrorMessage(e)); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { api<BranchOption[]>('/branches').then((list) => setBranches(Array.isArray(list) ? list : [])).catch(() => setBranches([])); }, []);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!form) return; setErr('');
    const payload = {
      name: form.name,
      nameAr: form.nameAr || undefined,
      category: form.category || undefined,
      icon: form.icon || undefined,
      barcode: form.barcode || undefined,
      supplier: form.supplier || undefined,
      price: Number(form.sellingPrice || 0),
      cost: Number(form.costPrice || 0),
      qty: Number(form.qty || 0),
      lowAlert: Number(form.lowAlert || 5),
      // PHASE 8 — the branch the product belongs to. '' = unassigned (gym-wide
      // catalogue). Restricted roles never send it: the API pins their branch.
      ...(ownsBranchChoice ? { branchId: form.branchId || '' } : {}),
    };
    try {
      if (form.id) await api(`/products/${form.id}`, { method: 'PATCH', body: JSON.stringify(payload) });
      else await api('/products', { method: 'POST', body: JSON.stringify(payload) });
      setForm(null); load();
    } catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }

  async function del(id: string) {
    if (!confirm(t('confirm_delete'))) return;
    try { await api(`/products/${id}`, { method: 'DELETE' }); load(); }
    catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }

  const totalValue = items.reduce((s, p) => s + (Number(p.qty)||0) * (Number(p.costPrice)||0), 0);
  const lowStock = items.filter((p) => (p.qty||0) <= 5);
  const outOfStock = items.filter((p) => (p.qty||0) <= 0);

  return (
    <Shell>
      <ProductPage
        eyebrow={t('inventory')}
        title={t('products')}
        narrative={t('products_description')}
        primaryAction={canManage ? { label: t('add_product'), icon: 'plus', testId: 'add-product', onClick: () => setForm({ name: '', category: '', sellingPrice: 0, costPrice: 0, qty: 0, branchId: scope.branchId || '' }) } : undefined}
      >
        <InsightLayer>
          <InsightCard label={t('products')} value={items.length} detail={t('total')} icon="coins" />
          <InsightCard label={t('inventory_value')} value={`${totalValue.toLocaleString()} ${t('currency')}`} detail={t('cost')} icon="chart" />
          <InsightCard label={t('low_stock')} value={lowStock.length} detail={t('need_reorder')} icon="bell" tone="warning" />
          <InsightCard label={t('out_of_stock')} value={outOfStock.length} detail={t('unavailable')} icon="shield" tone="danger" />
        </InsightLayer>
        {err && <FeedbackLayer type="danger" title={t('operation_failed')} detail={err} />}
        {!canManage && (
          <Card padding="lg" className="mb-6" data-testid="products-readonly">
            <div className="product-section-head">
              <div>
                <h2>{t('products_readonly_title') || 'Product catalogue'}</h2>
                <p>{t('products_readonly_desc') || 'You can browse the products and their stock levels. Adding, editing and deleting products is reserved for the owner and the general manager.'}</p>
              </div>
            </div>
          </Card>
        )}
        {loading ? <Skeleton lines={5} /> : (
          <SmartTable
            columns={[t('name'), t('category'), t('branch'), t('in_stock'), t('selling_price'), t('cost_price'), t('actions')]}
            rows={items}
            emptyTitle={t('no_products')}
            emptyDescription={t('create_first_product')}
            renderRow={(p) => (
              <tr key={p.id}>
                <td>{p.name}{p.barcode && <span className="text-xs text-[var(--silver-muted)] ml-2">{p.barcode}</span>}</td>
                <td>{p.category || '—'}</td>
                {/* P4-3: the branch this item's stock lives at (from its most
                    recent stock movement). Stock is gym-wide, so an item with
                    no movements yet shows the all-branches label. */}
                <td>
                  {p.branch?.name ? <span data-testid="product-branch-cell">{p.branch.name}</span>
                    : <span className="text-[var(--silver-dim)]" data-testid="product-branch-cell">{t('branch_unassigned') || 'Not assigned'}</span>}
                </td>
                <td><span className={(p.qty||0) <= 0 ? 'badge badge-expired' : (p.qty||0) <= 5 ? 'badge badge-soon' : 'badge badge-active'}>{p.qty || 0}</span></td>
                <td>{Number(p.sellingPrice).toLocaleString()} {t('currency')}</td>
                <td>{Number(p.costPrice).toLocaleString()} {t('currency')}</td>
                <td><span className="row-actions inline-flex gap-2">{canManage ? (<><button className="btn-ghost btn-sm" onClick={() => setForm(p)}>{t('edit')}</button><button className="btn-danger btn-sm" onClick={() => p.id && del(p.id)}>{t('delete')}</button></>) : <span className="text-[var(--silver-dim)]">—</span>}</span></td>
              </tr>
            )}
          />
        )}
      </ProductPage>

      {form && (
        <ModalPortal>
        <div className="fixed inset-0 bg-black/70 grid place-items-center p-5 z-50" onClick={() => setForm(null)}>
          <form onClick={(e) => e.stopPropagation()} onSubmit={save} className="card card-static glass w-full max-w-lg">
            <h3 className="text-title text-white mb-4">{form.id ? t('edit') : t('add_product')}</h3>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <label className="text-[10px] uppercase font-bold text-silver-dim mb-1 block">{t('product_name')}</label>
                <input className="input w-full" placeholder={t('product_name')} value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
              </div>
              <div>
                <label className="text-[10px] uppercase font-bold text-silver-dim mb-1 block">{t('category')}</label>
                <input className="input w-full" placeholder={t('category')} value={form.category || ''} onChange={(e) => setForm({ ...form, category: e.target.value })} />
              </div>
              <div>
                <label className="text-[10px] uppercase font-bold text-silver-dim mb-1 block">{t('barcode')}</label>
                <input className="input w-full" placeholder={t('barcode')} value={form.barcode || ''} onChange={(e) => setForm({ ...form, barcode: e.target.value })} />
              </div>
              <div>
                <label className="text-[10px] uppercase font-bold text-silver-dim mb-1 block">{t('selling_price')}</label>
                <input className="input w-full" type="number" placeholder={t('selling_price')} value={form.sellingPrice || ''} onChange={(e) => setForm({ ...form, sellingPrice: Number(e.target.value) })} required />
              </div>
              <div>
                <label className="text-[10px] uppercase font-bold text-silver-dim mb-1 block">{t('cost_price')}</label>
                <input className="input w-full" type="number" placeholder={t('cost_price')} value={form.costPrice || ''} onChange={(e) => setForm({ ...form, costPrice: Number(e.target.value) })} required />
              </div>
              <div>
                <label className="text-[10px] uppercase font-bold text-silver-dim mb-1 block">{t('current_stock')}</label>
                <input className="input w-full" type="number" placeholder={t('current_stock')} value={form.qty || ''} onChange={(e) => setForm({ ...form, qty: Number(e.target.value) })} />
              </div>
            </div>
            {/* PHASE 8 — which branch this product belongs to. */}
            <div className="mt-3">
              <label className="text-[10px] uppercase font-bold text-silver-dim mb-1 block">{t('branch')}</label>
              {ownsBranchChoice ? (
                <select
                  className="input w-full"
                  data-testid="product-branch-select"
                  value={form.branchId || ''}
                  onChange={(e) => setForm({ ...form, branchId: e.target.value })}
                >
                  <option value="">{t('branch_unassigned') || 'Not assigned'}</option>
                  {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
                </select>
              ) : (
                <div className="text-sm text-[var(--silver-dim)]" data-testid="product-branch-locked">
                  {t('branch')}: {scope.branchName || '—'}
                </div>
              )}
            </div>
            <div className="flex gap-2 justify-end mt-4">
              <button type="button" className="btn-ghost" onClick={() => setForm(null)}>{t('cancel')}</button>
              <button className="btn-primary">{t('save')}</button>
            </div>
          </form>
        </div>
        </ModalPortal>
      )}
    </Shell>
  );
}
