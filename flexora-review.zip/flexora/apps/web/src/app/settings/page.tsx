"use client";
import { useEffect, useMemo, useState } from "react";
import Shell from "@/components/Shell";
import { ProductPage, InsightLayer, InsightCard, SmartTable, ActionCenter, SmartAction, FeedbackLayer } from "@/components/ProductOS";
import { Skeleton, EmptyState } from "@/components/ui/States";
import { Button } from "@/components/ui/Button";
import { api, auth } from "@/lib/api";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useTranslation } from "@/lib/i18n";
import { safeErrorMessage } from "@/lib/safe-error";
import { localizePlanName } from "@/lib/plan-label";
import { dispatchBrandRefresh } from "@/context/BrandContext";
import { QrCode } from "@/components/QrCode";
import { z } from "zod";

const formSchema = z.object({ name: z.string().optional(), title: z.string().optional(), description: z.string().optional() });

function MessagingSettings() {
  const { t } = useTranslation();
  const qc = useQueryClient();
  const [testResult, setTestResult] = useState<string>("");
  const configQuery = useQuery({ queryKey: ["messaging-config"], queryFn: () => api<Record<string, any>>("/messaging/config").catch(() => ({ configured: false })) });
  const statusQuery = useQuery({ queryKey: ["messaging-status"], queryFn: () => api<Record<string, any>>("/messaging/status").catch(() => ({})) });
  const saveMutation = useMutation({
    mutationFn: (payload: Record<string, unknown>) => api("/messaging/config", { method: "PUT", body: JSON.stringify(payload) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["messaging-config"] }); qc.invalidateQueries({ queryKey: ["messaging-status"] }); },
  });
  const disconnectMutation = useMutation({
    mutationFn: () => api("/messaging/config", { method: "DELETE" }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["messaging-config"] }); qc.invalidateQueries({ queryKey: ["messaging-status"] }); },
  });

  const cfg = (configQuery.data || {}) as Record<string, any>;
  const status = (statusQuery.data || {}) as Record<string, any>;
  const field = "input w-full";

  function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const payload: Record<string, unknown> = {
      whatsappEnabled: form.get("whatsappEnabled") === "on",
      whatsappPhoneId: form.get("whatsappPhoneId") || undefined,
      whatsappToken: form.get("whatsappToken") || undefined,
      whatsappUrl: form.get("whatsappUrl") || undefined,
      aiAutoReply: form.get("aiAutoReply") === "on",
      aiAutoReplyHours: form.get("aiAutoReplyHours") || undefined,
      smsEnabled: form.get("smsEnabled") === "on",
      smsProvider: form.get("smsProvider") || undefined,
      smsApiKey: form.get("smsApiKey") || undefined,
      smsApiSecret: form.get("smsApiSecret") || undefined,
      smsFrom: form.get("smsFrom") || undefined,
      smtpEnabled: form.get("smtpEnabled") === "on",
      smtpHost: form.get("smtpHost") || undefined,
      smtpPort: form.get("smtpPort") ? Number(form.get("smtpPort")) : undefined,
      smtpUser: form.get("smtpUser") || undefined,
      smtpPass: form.get("smtpPass") || undefined,
      smtpFrom: form.get("smtpFrom") || undefined,
    };
    saveMutation.mutate(payload);
  }

  async function test(channel: "whatsapp" | "sms" | "email") {
    const to = window.prompt(channel === "email" ? t('test_email_prompt') : t('test_phone_prompt'));
    if (!to) return;
    const result = await api<{ success: boolean; error?: string }>(`/messaging/test/${channel}`, { method: "POST", body: JSON.stringify({ to }) }).catch((e) => ({ success: false, error: (e as Error).message }));
    setTestResult(`${t(channel)}: ${result.success ? `✅ ${t('connected')}` : `❌ ${result.error || t('failed')}`}`);
  }

  return <section className="rounded-2xl border border-white/10 bg-black/20 p-5 space-y-5">
    <div className="flex items-center justify-between gap-4">
      <div>
        <h2 className="text-xl font-bold text-white">{t('messaging_config')}</h2>
        <p className="text-sm text-[var(--silver-dim)]">{t('connect_gym_credentials')}</p>
      </div>
      {testResult && <span className="text-xs text-[var(--silver-dim)]">{testResult}</span>}
    </div>
    <form onSubmit={submit} className="grid grid-cols-1 xl:grid-cols-3 gap-4">
      <div className="rounded-xl bg-white/5 p-4 space-y-3">
        <div className="flex items-center justify-between"><h3 className="font-bold text-white">{t('whatsapp')}</h3><span className="text-xs">{status.whatsapp?.connected ? `✅ ${t('connected')}` : `❌ ${t('not_connected')}`}</span></div>
        <label className="text-sm text-[var(--silver-dim)] flex gap-2"><input name="whatsappEnabled" type="checkbox" defaultChecked={cfg.whatsappEnabled} /> {t('enable_whatsapp')}</label>
        <input className={field} name="whatsappPhoneId" placeholder={t('phone_number_id')} defaultValue={cfg.whatsappPhoneId || ""} />
        <input className={field} name="whatsappToken" type="password" placeholder={cfg.whatsappToken || t('access_token')} />
        <input className={field} name="whatsappUrl" placeholder="https://graph.facebook.com/v17.0" defaultValue={cfg.whatsappUrl || "https://graph.facebook.com/v17.0"} />
        <label className="text-sm text-[var(--silver-dim)] flex gap-2"><input name="aiAutoReply" type="checkbox" defaultChecked={cfg.aiAutoReply} /> {t('aiAutoReply')}</label>
        <input className={field} name="aiAutoReplyHours" placeholder="08:00-22:00" defaultValue={cfg.aiAutoReplyHours || "08:00-22:00"} />
        <Button type="button" variant="ghost" onClick={() => test("whatsapp")}>{t('test_connection')}</Button>
      </div>
      <div className="rounded-xl bg-white/5 p-4 space-y-3">
        <div className="flex items-center justify-between"><h3 className="font-bold text-white">{t('sms')}</h3><span className="text-xs">{status.sms?.connected ? `✅ ${t('connected')}` : `❌ ${t('not_connected')}`}</span></div>
        <label className="text-sm text-[var(--silver-dim)] flex gap-2"><input name="smsEnabled" type="checkbox" defaultChecked={cfg.smsEnabled} /> {t('enable_sms')}</label>
        <select className={field} name="smsProvider" defaultValue={cfg.smsProvider || "vonage"}><option value="vonage">Vonage</option><option value="twilio">Twilio</option></select>
        <input className={field} name="smsApiKey" placeholder={cfg.smsApiKey || t('ph_api_key_sid')} />
        <input className={field} name="smsApiSecret" type="password" placeholder={t('ph_api_secret_token')} />
        <input className={field} name="smsFrom" placeholder={t('sender_id_phone')} defaultValue={cfg.smsFrom || ""} />
        <Button type="button" variant="ghost" onClick={() => test("sms")}>{t('test_connection')}</Button>
      </div>
      <div className="rounded-xl bg-white/5 p-4 space-y-3">
        <div className="flex items-center justify-between"><h3 className="font-bold text-white">{t('email')}</h3><span className="text-xs">{status.email?.connected ? `✅ ${t('connected')}` : `❌ ${t('not_connected')}`}</span></div>
        <label className="text-sm text-[var(--silver-dim)] flex gap-2"><input name="smtpEnabled" type="checkbox" defaultChecked={cfg.smtpEnabled} /> {t('enable_email')}</label>
        <input className={field} name="smtpHost" placeholder={t('smtp_host')} defaultValue={cfg.smtpHost || ""} />
        <input className={field} name="smtpPort" placeholder={t('smtp_port')} defaultValue={cfg.smtpPort || "587"} />
        <input className={field} name="smtpUser" placeholder={t('username')} defaultValue={cfg.smtpUser || ""} />
        <input className={field} name="smtpPass" type="password" placeholder={t('password')} />
        <input className={field} name="smtpFrom" placeholder={t('from_address')} defaultValue={cfg.smtpFrom || ""} />
        <Button type="button" variant="ghost" onClick={() => test("email")}>{t('test_connection')}</Button>
      </div>
      <div className="xl:col-span-3 flex gap-3 justify-end">
        <Button type="button" variant="danger" onClick={() => disconnectMutation.mutate()}>{t('disconnect')}</Button>
        <Button type="submit" loading={saveMutation.isPending}>{t('save_messaging_settings')}</Button>
      </div>
    </form>
  </section>;
}

/**
 * ROUND 14 (security review, PHASE E): visible warning for OWNER/MANAGER when
 * the gym has no WhatsApp channel — members cannot log in to the member app
 * until it is configured (they can only use front-desk access codes).
 */
function WhatsappLoginWarning() {
  const { t } = useTranslation();
  const [status, setStatus] = useState<{ whatsapp?: { connected?: boolean } } | null>(null);
  useEffect(() => {
    api<any>("/messaging/status").then(setStatus).catch(() => setStatus(null));
  }, []);
  if (!status || status.whatsapp?.connected) return null;
  return (
    <section className="card glass p-5 mb-6 border-[var(--warning)]/40 bg-[var(--warning)]/10" data-testid="whatsapp-login-warning" role="alert">
      <h2 className="text-title text-[var(--warning)] mb-1">⚠ {t('whatsapp_login_warning')}</h2>
      <p className="text-xs text-[var(--silver-dim)]">{t('whatsapp_login_warning_desc')}</p>
    </section>
  );
}

/**
 * ROUND 14 (security review, PHASE F4): the owner-level switch — "Managers may
 * change integrations and branding" (default OFF). When OFF, the integrations
 * & branding endpoints (domains, WhatsApp bot, notification settings,
 * branding, AI action approvals) require the OWNER even for MANAGERs holding
 * settings.manage. Only the OWNER can change the switch.
 */
function IntegrationsSwitchSettings() {
  const { t } = useTranslation();
  const qc = useQueryClient();
  const gym = useQuery({ queryKey: ["gym-profile"], queryFn: () => api<any>("/gyms/me") });
  const me = useQuery({ queryKey: ["me-role"], queryFn: () => api<any>("/auth/me") });
  const isOwner = me.data?.user?.role === 'OWNER';
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const on = !!gym.data?.managersMayChangeIntegrations;
  const toggle = async () => {
    setErr(""); setBusy(true);
    try {
      await api("/gyms/me", { method: "PATCH", body: JSON.stringify({ managersMayChangeIntegrations: !on }) });
      qc.invalidateQueries({ queryKey: ["gym-profile"] });
    } catch (e: unknown) { setErr(safeErrorMessage(e)); } finally { setBusy(false); }
  };
  return (
    <section className="card glass p-5 mb-6" data-testid="integrations-switch-card">
      <h2 className="text-title text-white mb-1">{t('integrations_branding') || 'Integrations & branding'}</h2>
      <p className="text-xs text-[var(--silver-dim)] mb-4">{t('integrations_branding_desc') || 'Domains, the WhatsApp bot, notification settings, branding and AI action approvals are owner-only unless you allow managers to change them.'}</p>
      <label className="flex items-center gap-3 cursor-pointer">
        <input
          type="checkbox"
          data-testid="managers-may-change-integrations"
          checked={on}
          disabled={busy || !isOwner}
          onChange={toggle}
        />
        <span className="text-sm">{t('managers_may_change_integrations')}</span>
        {!isOwner && <span className="text-[10px] text-[var(--silver-dim)]">({t('owner_only')})</span>}
      </label>
      {err && <div role="alert" className="mt-3 text-xs text-[var(--danger)]">{err}</div>}
    </section>
  );
}

/**
 * ROUND 14 (security review, PHASE E): "Member app" card — the exact member
 * portal link (with the gym code), the gym code, a scannable QR of the link, a
 * copy button, and a "send the link to a member via WhatsApp" action.
 */
function MemberAppSettings() {
  const { t, lang } = useTranslation();
  const gym = useQuery({ queryKey: ["gym-profile"], queryFn: () => api<any>("/gyms/me") });
  const [copied, setCopied] = useState(false);
  const [memberMobile, setMemberMobile] = useState("");
  const slug = gym.data?.slug || "";
  const link = typeof window !== "undefined" && slug
    ? `${window.location.origin}/portal/login?gym=${encodeURIComponent(slug)}`
    : "";
  const copy = async () => {
    try { await navigator.clipboard.writeText(link); setCopied(true); setTimeout(() => setCopied(false), 2000); } catch { /* clipboard unavailable */ }
  };
  const sendWhatsapp = () => {
    const mobile = memberMobile.replace(/\D/g, "");
    if (!mobile || !link) return;
    const text = encodeURIComponent(link);
    window.open(`https://wa.me/${mobile}?text=${text}`, "_blank");
  };
  return (
    <section className="card glass p-5 mb-6" data-testid="member-app-card">
      <h2 className="text-title text-white mb-1">{t('member_app')}</h2>
      <p className="text-xs text-[var(--silver-dim)] mb-4">{t('member_app_desc')}</p>
      <div className="grid grid-cols-1 md:grid-cols-[auto,1fr] gap-5 items-start">
        <div className="flex flex-col items-center gap-2">
          {link && <QrCode payload={link} size={168} testId="member-app-qr" />}
          <span className="text-[10px] text-[var(--silver-dim)]">{t('gym_code_label')}: <b className="font-mono" data-testid="member-app-gym-code">{slug || '—'}</b></span>
        </div>
        <div className="grid gap-3">
          <div>
            <label className="text-label text-[var(--silver-dim)] mb-1 block">{t('portal_link_label')}</label>
            <div className="flex gap-2">
              <input className="input w-full font-mono text-xs" readOnly value={link} data-testid="member-app-link" onFocus={(e) => e.target.select()} />
              <button className="btn-ghost btn-sm shrink-0" onClick={copy} data-testid="member-app-copy">{copied ? (t('copied') || 'Copied') : (t('copy_link') || 'Copy link')}</button>
            </div>
          </div>
          <div>
            <label className="text-label text-[var(--silver-dim)] mb-1 block">{t('send_link_whatsapp')}</label>
            <div className="flex gap-2">
              <input className="input w-full" dir="ltr" inputMode="numeric" placeholder={t('member_phone_placeholder')} value={memberMobile} onChange={(e) => setMemberMobile(e.target.value)} data-testid="member-app-phone" />
              <button className="btn-primary btn-sm shrink-0" onClick={sendWhatsapp} disabled={!memberMobile.replace(/\D/g, '') || !link} data-testid="member-app-whatsapp">💬</button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}


/**
 * PACK 2 · ITEM 5 — member self check-in, per gym, OFF until the owner says so.
 *
 * The card is deliberately honest about what each mode proves: a web page cannot
 * detect that somebody walked in, so every mode here is a declaration with
 * evidence attached, and the copy says which evidence is worth how much.
 */
function SelfCheckinSettings() {
  const { t } = useTranslation();
  const qc = useQueryClient();
  const cfgQ = useQuery({
    queryKey: ["self-checkin-config"],
    queryFn: () => api<any>("/settings/self-checkin"),
  });
  const branchesQ = useQuery({
    queryKey: ["branches-min"],
    queryFn: () => api<any>("/branches"),
  });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [ipList, setIpList] = useState("");
  const [focus, setFocus] = useState(false);
  const [qr, setQr] = useState<{ token: string; expiresAt: string } | null>(null);
  const [branchId, setBranchId] = useState("");

  const cfg = cfgQ.data;
  const branches = (branchesQ.data?.items || branchesQ.data || []) as Array<{ id: string; name: string }>;

  const save = async (patch: Record<string, unknown>) => {
    setBusy(true); setErr("");
    try {
      await api("/settings/self-checkin", { method: "PATCH", body: JSON.stringify(patch) });
      await qc.invalidateQueries({ queryKey: ["self-checkin-config"] });
    } catch (e) { setErr(safeErrorMessage(e)); } finally { setBusy(false); }
  };

  // The entrance code lives 120 seconds on purpose: a photograph of it is
  // useless by the time it is forwarded. So the screen re-mints it on a timer
  // while it is on display, and stops the moment it is hidden.
  useEffect(() => {
    if (!qr || !branchId) return;
    const id = setInterval(async () => {
      try {
        const next = await api<any>("/settings/self-checkin/token", {
          method: "POST", body: JSON.stringify({ branchId }),
        });
        setQr(next);
      } catch { /* keep the old one; it will simply expire */ }
    }, 60_000);
    return () => clearInterval(id);
  }, [qr, branchId]);

  const mint = async () => {
    if (!branchId) return;
    setErr("");
    try {
      const next = await api<any>("/settings/self-checkin/token", {
        method: "POST", body: JSON.stringify({ branchId }),
      });
      setQr(next);
    } catch (e) { setErr(safeErrorMessage(e)); }
  };

  return (
    <section className="card glass p-5 mb-6" data-testid="self-checkin-card">
      <h2 className="text-title text-white mb-1">{t("self_checkin_title")}</h2>
      <p className="text-xs text-[var(--silver-dim)] mb-4">{t("self_checkin_desc")}</p>

      {/* A 13px checkbox fails the 44px touch rule the owner set for phones.
          The whole label is the target (min-height 44) and the box itself is
          22px, which is what people actually aim at. */}
      <label
        className="flex items-center gap-3 cursor-pointer mb-4"
        style={{ minHeight: 44, paddingBlock: 4 }}
      >
        <input
          type="checkbox"
          data-testid="self-checkin-enabled"
          style={{ width: 22, height: 22, minWidth: 22 }}
          checked={Boolean(cfg?.enabled)}
          disabled={busy || cfgQ.isLoading}
          onChange={(e) => save({ enabled: e.target.checked })}
        />
        <span className="text-sm">{t("self_checkin_enable")}</span>
        <span className="text-[10px] text-[var(--silver-dim)]">({t("default_off")})</span>
      </label>

      {cfg?.enabled && (
        <div className="grid gap-4">
          {/* honesty first: this is the limit of the whole feature */}
          <p className="text-xs rounded-xl border border-[var(--warning)]/40 bg-[var(--warning)]/10 p-3" data-testid="self-checkin-honesty">
            {t("self_checkin_honesty")}
          </p>

          {/* OWNER DECISION 2026-11-17: ON with no QR, no network and no radius is
              allowed, but it must be impossible to miss what that means — any
              logged-in member can check in from anywhere. Warning only: the
              setting is never blocked. */}
          {cfg?.enabled && !cfg.hasEntranceQr && !cfg.modes?.network && !cfg.modes?.geolocation && (
            <p
              className="text-xs rounded-xl p-3"
              role="alert"
              data-testid="self-checkin-plain-warning"
              style={{ border: '1px solid var(--warning, #b45309)', color: 'var(--warning, #b45309)' }}
            >
              {t("self_checkin_plain_warning")}
            </p>
          )}

          <div>
            <label className="text-label text-[var(--silver-dim)] mb-1 block">{t("self_checkin_network")}</label>
            <div className="flex gap-2 flex-wrap">
              <input
                className="input w-full md:w-80 font-mono text-xs" dir="ltr"
                placeholder={t("self_checkin_network_placeholder")}
                value={focus ? ipList : (cfg.networkConfigured ? t("configured") : "")}
                onFocus={() => { setFocus(true); setIpList(""); }}
                onBlur={() => setFocus(false)}
                onChange={(e) => setIpList(e.target.value)}
                data-testid="self-checkin-ip"
                style={{ minHeight: 44 }}
              />
              <button className="btn-ghost btn-sm" style={{ minHeight: 44, minWidth: 64 }} disabled={!focus} onClick={() => save({ ipList })} data-testid="self-checkin-ip-save">
                {t("save")}
              </button>
            </div>
            <p className="text-[10px] text-[var(--silver-dim)] mt-1">{t("self_checkin_network_note")}</p>
          </div>

          <div>
            {/* STEP 2a — when the server has no QR signing key, say so in Arabic
                instead of offering a scan the API would refuse with 503. */}
            {cfg?.qrAvailable === false && (
              <p
                className="text-xs rounded-xl border border-[var(--danger)]/40 bg-[var(--danger)]/10 p-3 mb-3"
                role="alert"
                data-testid="self-checkin-qr-unavailable"
              >
                {t("self_checkin_qr_unavailable")}
              </p>
            )}
            <label className="text-label text-[var(--silver-dim)] mb-1 block">{t("self_checkin_qr")}</label>
            <div className="flex gap-2 flex-wrap items-center">
              <select className="input" value={branchId} onChange={(e) => { setBranchId(e.target.value); setQr(null); }} data-testid="self-checkin-branch">
                <option value="">{t("choose_branch")}</option>
                {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
              <button className="btn-primary btn-sm" style={{ minHeight: 44 }} disabled={!branchId || cfg?.qrAvailable === false} onClick={mint} data-testid="self-checkin-mint">
                {t("self_checkin_show_qr")}
              </button>
            </div>
            {qr && (
              <div className="mt-3 flex flex-col items-center gap-2" data-testid="self-checkin-qr-box">
                <QrCode payload={`${window.location.origin}/portal/checkin?t=${encodeURIComponent(qr.token)}`} size={180} testId="self-checkin-qr" />
                <span className="text-[10px] text-[var(--silver-dim)]">{t("self_checkin_qr_expires")}</span>
              </div>
            )}
            <p className="text-[10px] text-[var(--silver-dim)] mt-2">{t("self_checkin_secret_note")}</p>
          </div>
        </div>
      )}

      {err && <div role="alert" className="mt-3 text-xs text-[var(--danger)]">{err}</div>}
    </section>
  );
}

/**
 * ROUND 14 (security review, PHASE A): self-service "My profile" card. The
 * OWNER account cannot be edited through the staff page (OWNER_PROTECTED),
 * so name/phone/password self-edits live here, on PATCH /users/me. A password
 * change requires the current password (same rule as /auth/change-password).
 */
function MyProfileSettings() {
  const { t } = useTranslation();
  const qc = useQueryClient();
  const [success, setSuccess] = useState("");
  const [err, setErr] = useState("");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [currentPassword, setCurrentPassword] = useState("");
  const me = useQuery({ queryKey: ["me-profile"], queryFn: () => api<any>("/auth/me") });
  useEffect(() => {
    if (me.data?.user) { setName(me.data.user.name || ""); setPhone(me.data.user.phone || ""); }
  }, [me.data]);
  const mutation = useMutation({
    mutationFn: (payload: any) => api("/users/me", { method: "PATCH", body: JSON.stringify(payload) }),
    onSuccess: () => {
      setSuccess(t('profile_saved') || 'Profile saved');
      setErr(""); setPassword(""); setCurrentPassword("");
      qc.invalidateQueries({ queryKey: ["me-profile"] });
      qc.invalidateQueries({ queryKey: ["me"] });
    },
    onError: (e: any) => { setSuccess(""); setErr(safeErrorMessage(e)); },
  });
  const save = () => {
    const payload: any = {};
    if (name.trim() && name.trim() !== (me.data?.user?.name || "")) payload.name = name.trim();
    if (phone.trim() !== (me.data?.user?.phone || "")) payload.phone = phone.trim() || null;
    if (password) { payload.password = password; payload.currentPassword = currentPassword; }
    if (!Object.keys(payload).length) { setErr(t('nothing_to_update') || 'Nothing to update'); return; }
    mutation.mutate(payload);
  };
  return (
    <section className="card glass p-5 mb-6" data-testid="my-profile-card">
      <h2 className="text-title text-white mb-1">{t('my_profile') || 'My profile'}</h2>
      <p className="text-xs text-[var(--silver-dim)] mb-4">{t('my_profile_desc') || 'Update your own name, phone and password. Staff management of other accounts stays on the Team page.'}</p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="text-label text-[var(--silver-dim)] mb-1 block">{t('full_name') || 'Full name'}</label>
          <input className="input w-full" data-testid="my-profile-name" value={name} onChange={(e) => setName(e.target.value)} />
        </div>
        <div>
          <label className="text-label text-[var(--silver-dim)] mb-1 block">{t('phone') || 'Phone'}</label>
          <input className="input w-full" data-testid="my-profile-phone" value={phone} onChange={(e) => setPhone(e.target.value)} />
        </div>
        <div>
          <label className="text-label text-[var(--silver-dim)] mb-1 block">{t('new_password') || 'New password'}</label>
          <input className="input w-full" type="password" data-testid="my-profile-password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
        </div>
        <div>
          <label className="text-label text-[var(--silver-dim)] mb-1 block">{t('current_password') || 'Current password'}</label>
          <input className="input w-full" type="password" data-testid="my-profile-current-password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} placeholder="••••••••" />
        </div>
      </div>
      <div className="flex items-center gap-3 mt-4">
        <Button onClick={save} disabled={mutation.isPending} data-testid="my-profile-save">{t('save') || 'Save'}</Button>
        {success && <span className="text-[var(--good)] text-sm" role="status">{success}</span>}
        {err && <span className="text-[var(--danger)] text-sm" role="alert">{err}</span>}
      </div>
    </section>
  );
}

function GymProfileSettings() {
  const { t } = useTranslation();
  const qc = useQueryClient();
  const [success, setSuccess] = useState("");
  const [err, setErr] = useState("");
  // ROUND 12 (P1: "the settings page has no logo or color editing"):
  // the gym identity — logo + brand color — could only be chosen once, inside
  // the onboarding wizard {step 1 logo / step 2 color}; afterwards there was no
  // way back. Both controls now live here, saved through the same
  // PATCH /gyms/me endpoint and re-published through the same
  // dispatchBrandRefresh() the wizard uses, so changing them takes effect in
  // the shell immediately — the owner can change them any time after onboarding.
  const [logoError, setLogoError] = useState("");
  const [logo, setLogo] = useState("");
  const [primaryColor, setPrimaryColor] = useState("#c5a059");
  const [brandLoaded, setBrandLoaded] = useState(false);

  const query = useQuery({ queryKey: ["gym-profile"], queryFn: () => api<any>("/gyms/me") });
  const mutation = useMutation({
    mutationFn: (payload: any) => api("/gyms/me", { method: "PATCH", body: JSON.stringify(payload) }),
    onSuccess: () => {
      setSuccess(t('settings_saved'));
      setTimeout(() => setSuccess(""), 3000);
      qc.invalidateQueries({ queryKey: ["gym-profile"] });
      // P0 reactivity fix: gym identity (name/logo/color) feeds the shell's
      // brand — re-read it so the header updates without a page reload.
      dispatchBrandRefresh();
    },
    onError: (e) => setErr(safeErrorMessage(e))
  });

  // Seed the local logo/color once, from the server values. Guarded by
  // brandLoaded so a background refetch (query invalidation after save) can
  // never overwrite what the user is currently editing.
  const gym = query.data || {};
  useEffect(() => {
    if (query.data && !brandLoaded) {
      setLogo(query.data.logo || "");
      setPrimaryColor(query.data.accentColor || "#c5a059");
      setBrandLoaded(true);
    }
  }, [query.data, brandLoaded]);

  // Same guards as the onboarding wizard: images only, up to 1MB, stored as a
  // data: URI (the DTO accepts http(s):// or data:image/ URLs).
  function handleLogoFile(file?: File | null) {
    setLogoError("");
    if (!file) return;
    if (file.size > 1024 * 1024) { setLogoError(t('logo_too_large') || 'Image is too large — please use one under 1MB.'); return; }
    if (!file.type.startsWith('image/')) { setLogoError(t('logo_bad_type') || 'Please choose an image file (PNG/JPG/WebP/SVG).'); return; }
    const reader = new FileReader();
    reader.onload = () => setLogo(String(reader.result || ''));
    reader.onerror = () => setLogoError(t('logo_read_error') || 'Could not read that image — try another one.');
    reader.readAsDataURL(file);
  }

  if (query.isLoading) return <Skeleton lines={5} />;

  function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const phone = String(fd.get("phone") || "").trim();
    // P1: gym phone follows the Egyptian-mobile rule (same as onboarding).
    if (phone && !/^(010|011|012|015)\d{8}$/.test(phone)) {
      setErr(t('eg_phone_hint') || 'Mobile number must be 11 digits and start with 010, 011, 012 or 015');
      return;
    }
    mutation.mutate({
      name: fd.get("name"),
      phone,
      address: fd.get("address"),
      email: fd.get("email"),
      // null clears the logo (the DTO allows an explicit null, undefined means
      // "leave it alone"); a data: URI replaces it.
      logo: logo ? logo : null,
      primaryColor,
    });
  }

  return (
    <section className="rounded-2xl border border-white/10 bg-black/20 p-5 space-y-5 mb-6">
      <h2 className="text-xl font-bold text-white">{t('gym_profile') || 'Gym Profile'}</h2>
      {success && <div className="text-green-400 text-sm">{success}</div>}
      {err && <div className="text-red-400 text-sm">{err}</div>}
      <form onSubmit={onSubmit} className="grid grid-cols-2 gap-4">
        <div>
          <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('name')}</label>
          <input className="input w-full" name="name" defaultValue={gym.name} required />
        </div>
        <div>
          <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('phone')}</label>
          <input className="input w-full" dir="ltr" type="tel" inputMode="numeric" maxLength={11} pattern="01[0125][0-9]{8}" title={t('eg_phone_hint') || 'Mobile number must be 11 digits and start with 010, 011, 012 or 015'} name="phone" defaultValue={gym.phone} required />
        </div>
        <div className="col-span-2">
          <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('address')}</label>
          <input className="input w-full" name="address" defaultValue={gym.address} />
        </div>
        <div className="col-span-2">
          <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('email')}</label>
          <input className="input w-full" name="email" defaultValue={gym.email} type="email" required />
        </div>

        {/* ---- Round 12: gym logo (was onboarding-only until now) ---- */}
        <div className="col-span-2">
          <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('gym_logo') || 'Gym logo'}</label>
          <p className="text-xs text-white/50 mb-3">{t('logo_upload_help') || 'Upload a square image (PNG/JPG, max ~1MB). You can remove it and pick another one anytime.'}</p>
          <div className="grid gap-4 md:grid-cols-[minmax(0,240px)_1fr]">
            {logo ? (
              <div className="rounded-2xl border border-white/10 p-4 bg-black/30" data-testid="settings-logo-preview">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={logo} alt="Logo preview" className="h-32 w-32 object-contain rounded-xl bg-white/10 p-2" />
                <div className="flex gap-2 mt-3 flex-wrap">
                  <button type="button" data-testid="settings-remove-logo" className="btn btn-ghost text-xs px-3 py-1.5" onClick={() => { setLogo(''); setLogoError(''); }}>
                    {t('remove_logo') || '✕ Remove logo'}
                  </button>
                  <label className="btn btn-ghost text-xs px-3 py-1.5 cursor-pointer">
                    {t('choose_different_logo') || 'Choose a different image'}
                    <input type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" className="hidden" data-testid="settings-logo-input"
                      onChange={(e) => handleLogoFile(e.target.files?.[0])} />
                  </label>
                </div>
              </div>
            ) : (
              <label className="flex flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-white/20 p-8 cursor-pointer hover:border-[var(--primary)] transition-colors min-h-[190px]">
                <span className="text-3xl" aria-hidden>📷</span>
                <span className="text-sm text-white/70 font-semibold">{t('upload_logo') || 'Upload logo'}</span>
                <span className="text-[11px] text-white/40 text-center">{t('upload_logo_hint')}</span>
                <input type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" className="hidden" data-testid="settings-logo-input"
                  onChange={(e) => handleLogoFile(e.target.files?.[0])} />
              </label>
            )}
            {/* Live preview of the app header, exactly like the onboarding step. */}
            <div className="rounded-2xl border border-white/10 p-4 bg-black/20">
              <p className="text-[11px] uppercase tracking-wide text-white/40 mb-3">{t('logo_preview_header') || 'How it will look'}</p>
              <div className="flex items-center gap-3 rounded-xl border border-white/10 bg-[var(--bg-base,#000)] px-4 py-3">
                {logo ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={logo} alt="" className="h-10 w-10 object-contain rounded-md" />
                ) : (
                  <svg width="40" height="40" viewBox="0 0 100 100" fill="none" aria-hidden style={{ color: primaryColor || '#c5a059' }}>
                    <path d="M35 15V85M35 15H75M35 48H65" stroke="currentColor" strokeWidth="8" strokeLinecap="round" />
                  </svg>
                )}
                <div className="leading-tight">
                  <div className="font-display text-lg text-white">{gym.name || t('gymName') || 'Gym name'}</div>
                  <div className="text-[10px] tracking-widest text-white/40">{t('brand_tagline')}</div>
                </div>
                <span className="ml-auto rounded-lg px-3 py-1 text-xs font-bold text-black" style={{ background: primaryColor || '#c5a059' }}>
                  {t('brand_colors') || 'Brand colors'}
                </span>
              </div>
            </div>
          </div>
          {logoError && <p className="text-xs text-red-400 mt-2">{logoError}</p>}
        </div>

        {/* ---- Round 12: brand color (was onboarding-only until now) ---- */}
        <div className="col-span-2">
          <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('brand_colors') || 'Brand colors'}</label>
          <p className="text-xs text-white/50 mb-3">
            {t('brand_color_help') || 'Pick the color used across the dashboard, buttons and charts. It applies everywhere as soon as you save.'}
          </p>
          <div className="flex items-center gap-3 flex-wrap">
            <input
              type="color"
              data-testid="settings-brand-color"
              aria-label={t('brand_colors') || 'Brand colors'}
              className="h-12 w-20 rounded-lg border border-white/15 bg-transparent cursor-pointer"
              value={primaryColor || '#c5a059'}
              onChange={(e) => setPrimaryColor(e.target.value)}
            />
            <input
              className="input w-32"
              dir="ltr"
              value={primaryColor}
              onChange={(e) => setPrimaryColor(e.target.value)}
              aria-label={t('brand_colors') || 'Brand colors'}
            />
            <span className="flex gap-2">
              {['#c5a059', '#6366F1', '#0EA5E9', '#10B981', '#EF4444'].map((c) => (
                <button
                  key={c}
                  type="button"
                  title={c}
                  aria-label={c}
                  onClick={() => setPrimaryColor(c)}
                  className={`h-8 w-8 rounded-full border ${primaryColor?.toLowerCase() === c.toLowerCase() ? 'border-white' : 'border-white/20'}`}
                  style={{ background: c }}
                />
              ))}
            </span>
          </div>
        </div>

        <div className="col-span-2 flex justify-end">
          <Button type="submit" loading={mutation.isPending} data-testid="settings-brand-save">{t('save')}</Button>
        </div>
      </form>
    </section>
  );
}

function NotificationSettings() {
  const { t } = useTranslation();
  const qc = useQueryClient();
  const [success, setSuccess] = useState("");
  const [err, setErr] = useState("");

  const query = useQuery({ queryKey: ["notification-settings"], queryFn: () => api<any>("/gyms/notification-settings") });
  const mutation = useMutation({
    mutationFn: (payload: any) => api("/gyms/notification-settings", { method: "PATCH", body: JSON.stringify(payload) }),
    onSuccess: () => {
      setSuccess(t('settings_saved'));
      setTimeout(() => setSuccess(""), 3000);
      qc.invalidateQueries({ queryKey: ["notification-settings"] });
    },
    onError: (e) => setErr(safeErrorMessage(e))
  });

  if (query.isLoading) return <Skeleton lines={5} />;
  const settings = query.data || {};

  function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    mutation.mutate({
      ownerPersonalMobile: fd.get("ownerPersonalMobile"),
      notifyOnSale: fd.get("notifyOnSale") === "on",
      notifyOnMemberAdd: fd.get("notifyOnMemberAdd") === "on",
      notifyOnMemberDelete: fd.get("notifyOnMemberDelete") === "on",
      notifyOnRefund: fd.get("notifyOnRefund") === "on",
      antiTheftEnabled: fd.get("antiTheftEnabled") === "on",
      maxDiscountAlert: Number(fd.get("maxDiscountAlert")),
      maxCashAlert: Number(fd.get("maxCashAlert")),
    });
  }

  return (
    <section className="rounded-2xl border border-white/10 bg-black/20 p-5 space-y-5 mb-6">
      <h2 className="text-xl font-bold text-white">{t('notification_settings')}</h2>
      {success && <div className="text-green-400 text-sm">{success}</div>}
      {err && <div className="text-red-400 text-sm">{err}</div>}
      <form onSubmit={onSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('owner_whatsapp_personal')}</label>
            <input className="input w-full" name="ownerPersonalMobile" defaultValue={settings.ownerPersonalMobile} placeholder={t('phone_mask')} />
          </div>
          <div className="grid grid-cols-1 gap-2">
            <label className="flex gap-2 text-sm"><input name="notifyOnSale" type="checkbox" defaultChecked={settings.notifyOnSale} /> {t('every_sale')}</label>
            <label className="flex gap-2 text-sm"><input name="notifyOnMemberAdd" type="checkbox" defaultChecked={settings.notifyOnMemberAdd} /> {t('new_member_added')}</label>
            <label className="flex gap-2 text-sm"><input name="notifyOnMemberDelete" type="checkbox" defaultChecked={settings.notifyOnMemberDelete} /> {t('member_deleted_label')}</label>
            <label className="flex gap-2 text-sm"><input name="notifyOnRefund" type="checkbox" defaultChecked={settings.notifyOnRefund} /> {t('refund_invoice_cancelled')}</label>
          </div>
        </div>
        <div className="space-y-4 border-l border-white/5 pl-6">
          <label className="flex gap-2 text-sm font-bold"><input name="antiTheftEnabled" type="checkbox" defaultChecked={settings.antiTheftEnabled} /> {t('anti_theft_system')}</label>
          <div>
            <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('max_discount_pct')}</label>
            <input className="input w-full" name="maxDiscountAlert" type="number" defaultValue={settings.maxDiscountAlert} />
          </div>
          <div>
            <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('max_cash_egp')}</label>
            <input className="input w-full" name="maxCashAlert" type="number" defaultValue={settings.maxCashAlert} />
          </div>
        </div>
        <div className="md:col-span-2 flex justify-end">
          <Button type="submit" loading={mutation.isPending}>{t('save')}</Button>
        </div>
      </form>
    </section>
  );
}


/**
 * Phase 6.4 — real, functional PLAN EDITING inside Settings.
 * Previously the settings page had no way to manage membership plans at all;
 * the owner had to leave for a separate page. Full create / edit / activate /
 * delete now lives here and hits the same /plans API as the Plans page.
 */
function PlanSettings() {
  const { t, lang } = useTranslation();
  const qc = useQueryClient();
  const [form, setForm] = useState<any | null>(null);
  const [err, setErr] = useState("");
  const [success, setSuccess] = useState("");
  // ROUND 13 (Phase 1): plan management (create/edit/delete) is OWNER/MANAGER
  // work. RECEPTION can now READ /plans (needed by the members page), so without
  // this guard a Reception user would see an "Add plan" button and edit/delete
  // controls that the API rejects with 403.
  const [canManage, setCanManage] = useState<boolean | null>(null);
  useEffect(() => {
    auth.me().then((u: any) => setCanManage(['OWNER', 'MANAGER'].includes(u?.role))).catch(() => setCanManage(false));
  }, []);

  const query = useQuery({ queryKey: ["settings-plans"], queryFn: () => api<any>("/plans").then((r) => (Array.isArray(r) ? r : r.items || [])) });
  const plans: any[] = query.data || [];

  const mutation = useMutation({
    mutationFn: (p: any) => p.id
      ? api(`/plans/${p.id}`, { method: "PATCH", body: JSON.stringify(p.body) })
      : api("/plans", { method: "POST", body: JSON.stringify(p.body) }),
    onSuccess: () => {
      setForm(null); setErr("");
      setSuccess(t('settings_saved')); setTimeout(() => setSuccess(""), 3000);
      qc.invalidateQueries({ queryKey: ["settings-plans"] });
    },
    onError: (e) => setErr(safeErrorMessage(e)),
  });
  const delMutation = useMutation({
    mutationFn: (id: string) => api(`/plans/${id}`, { method: "DELETE" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["settings-plans"] }),
    onError: (e) => setErr(safeErrorMessage(e)),
  });

  // Early return AFTER every hook — plan management is hidden entirely for
  // roles that cannot manage plans (the API would 403 every write).
  if (canManage === false) return null;

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!form) return;
    const body = {
      name: form.name,
      type: form.type || 'TIME',
      price: Number(form.price || 0),
      days: Number(form.days || 30),
      sessions: (form.type === 'SESSION') ? Number(form.sessions || 0) : undefined,
      active: form.active !== false,
    };
    mutation.mutate({ id: form.id, body });
  }

  return (
    <section className="rounded-2xl border border-white/10 bg-black/20 p-5 space-y-5 mb-6">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white">{t('plans')}</h2>
          <p className="text-sm text-[var(--silver-dim)]">{t('plans_owner_control')}</p>
        </div>
        <Button type="button" onClick={() => setForm({ type: 'TIME', days: 30, price: 0, active: true })}>{t('add_plan')}</Button>
      </div>
      {success && <div className="text-green-400 text-sm">{success}</div>}
      {err && <div className="text-red-400 text-sm">{err}</div>}
      {query.isLoading ? <Skeleton lines={3} /> : plans.length === 0 ? (
        <EmptyState icon="coins" title={t('no_plans')} description={t('plans_owner_control')} />
      ) : (
        <div className="overflow-auto">
          <table className="w-full text-sm">
            <thead><tr className="text-[var(--silver-dim)] text-xs uppercase">
              <th className="text-start py-2">{t('name')}</th><th className="text-start">{t('type')}</th>
              <th className="text-start">{t('price')}</th><th className="text-start">{t('days_duration')}</th>
              <th className="text-start">{t('status')}</th><th className="text-start">{t('actions')}</th>
            </tr></thead>
            <tbody>
              {plans.map((p) => (
                <tr key={p.id} className="border-t border-white/5">
                  <td className="py-2 font-bold">{localizePlanName(p.name, lang)}</td>
                  <td>{p.type === 'SESSION' ? t('session_based') : t('time_based')}</td>
                  <td>{Number(p.price).toLocaleString()} {t('currency')}</td>
                  <td>{p.days}</td>
                  <td>{p.active ? t('active') : t('inactive')}</td>
                  <td>
                    <span className="inline-flex gap-2">
                      <button type="button" className="btn-ghost btn-sm" onClick={() => setForm(p)}>{t('edit')}</button>
                      <button type="button" className="btn-danger btn-sm" onClick={() => p.id && delMutation.mutate(p.id)}>{t('delete')}</button>
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {form && (
        <form onSubmit={submit} className="rounded-xl bg-white/5 p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="md:col-span-2">
            <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('name')}</label>
            <input className="input w-full" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
          </div>
          <div>
            <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('type')}</label>
            <select className="input w-full" value={form.type || 'TIME'} onChange={(e) => setForm({ ...form, type: e.target.value })}>
              <option value="TIME">{t('time_based')}</option>
              <option value="SESSION">{t('session_based')}</option>
            </select>
          </div>
          <div>
            <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('status')}</label>
            <select className="input w-full" value={form.active === false ? 'false' : 'true'} onChange={(e) => setForm({ ...form, active: e.target.value === 'true' })}>
              <option value="true">{t('active')}</option>
              <option value="false">{t('inactive')}</option>
            </select>
          </div>
          <div>
            <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('price')} ({t('currency')})</label>
            <input className="input w-full" type="number" value={form.price ?? 0} onChange={(e) => setForm({ ...form, price: Number(e.target.value) })} required />
          </div>
          <div>
            <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('days_duration')}</label>
            <input className="input w-full" type="number" value={form.days ?? 30} onChange={(e) => setForm({ ...form, days: Number(e.target.value) })} required />
          </div>
          {form.type === 'SESSION' && (
            <div className="md:col-span-2">
              <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('sessions')}</label>
              <input className="input w-full" type="number" value={form.sessions ?? 0} onChange={(e) => setForm({ ...form, sessions: Number(e.target.value) })} required />
            </div>
          )}
          <div className="md:col-span-2 flex gap-3 justify-end">
            <Button type="button" variant="ghost" onClick={() => setForm(null)}>{t('cancel')}</Button>
            <Button type="submit" loading={mutation.isPending}>{t('save')}</Button>
          </div>
        </form>
      )}
    </section>
  );
}

/**
 * Phase 6.3 / 6.4 — real AI assistant configuration.
 * The owner enters THEIR OWN provider API key here; it is sent once, encrypted
 * server-side (AES-256-GCM) into GymSettings and never sent back to the
 * browser — the UI only ever shows a masked hint like "••••ab12".
 */
function AiAssistantSettings() {
  const { t } = useTranslation();
  const qc = useQueryClient();
  const [apiKey, setApiKey] = useState("");
  const [err, setErr] = useState("");
  const [success, setSuccess] = useState("");

  const query = useQuery({ queryKey: ["ai-config"], queryFn: () => api<any>("/ai/config") });
  const cfg = query.data || {};
  const [provider, setProvider] = useState<string>("");
  const [enabled, setEnabled] = useState<boolean | null>(null);
  const activeProvider = provider || cfg.provider || 'gemini';
  const activeEnabled = enabled === null ? !!cfg.enabled : enabled;
  const meta = (cfg.providers || []).find((p: any) => p.id === activeProvider);

  const mutation = useMutation({
    mutationFn: (payload: any) => api("/ai/config", { method: "POST", body: JSON.stringify(payload) }),
    onSuccess: () => {
      setApiKey(""); setErr("");
      setSuccess(t('settings_saved')); setTimeout(() => setSuccess(""), 3000);
      qc.invalidateQueries({ queryKey: ["ai-config"] });
    },
    onError: (e) => setErr(safeErrorMessage(e)),
  });

  if (query.isLoading) return <Skeleton lines={4} />;

  function submit(e: React.FormEvent) {
    e.preventDefault();
    mutation.mutate({ enabled: activeEnabled, provider: activeProvider, ...(apiKey ? { apiKey } : {}) });
  }

  return (
    <section className="rounded-2xl border border-white/10 bg-black/20 p-5 space-y-5 mb-6">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white">{t('ai_assistant_config')}</h2>
          <p className="text-sm text-[var(--silver-dim)]">{t('ai_key_help')}</p>
        </div>
        <span className="text-xs">{cfg.active ? `✅ ${t('connected')}` : `❌ ${t('not_connected')}`}</span>
      </div>
      {success && <div className="text-green-400 text-sm">{success}</div>}
      {err && <div className="text-red-400 text-sm">{err}</div>}
      <form onSubmit={submit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <label className="flex gap-2 text-sm md:col-span-2">
          <input type="checkbox" checked={activeEnabled} onChange={(e) => setEnabled(e.target.checked)} /> {t('enable_ai')}
        </label>
        <div>
          <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('ai_provider')}</label>
          <select className="input w-full" value={activeProvider} onChange={(e) => { setProvider(e.target.value); }}>
            {(cfg.providers || []).map((p: any) => (
              <option key={p.id} value={p.id}>{p.label}{p.freeTier ? ` — ${t('free')}` : ''}</option>
            ))}
          </select>
          <p className="text-[11px] text-[var(--silver-dim)] mt-1">
            {meta?.freeTier ? t('ai_free_tier_note') : t('ai_paid_tier_note')}
          </p>
        </div>
        <div>
          <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('ai_api_key')}</label>
          <input className="input w-full" dir="ltr" type="password" autoComplete="off"
            placeholder={cfg.hasOwnKey ? cfg.keyHint : t('ai_api_key_placeholder')}
            value={apiKey} onChange={(e) => setApiKey(e.target.value)} />
          <p className="text-[11px] text-[var(--silver-dim)] mt-1">
            {cfg.hasOwnKey ? t('ai_key_saved_note') : t('ai_key_missing_note')}
          </p>
        </div>
        <div className="md:col-span-2 flex gap-3 justify-end">
          {cfg.hasOwnKey && <Button type="button" variant="danger" onClick={() => mutation.mutate({ apiKey: "" })}>{t('ai_remove_key')}</Button>}
          <Button type="submit" loading={mutation.isPending}>{t('save')}</Button>
        </div>
      </form>
    </section>
  );
}

export default function Page() {
  const { t } = useTranslation();
  
  return <Shell>
    <ProductPage eyebrow="FLEXORA" title={t('settings')} narrative={t('settings_description')}>
      <MyProfileSettings />
      <WhatsappLoginWarning />
      <MemberAppSettings />
      <SelfCheckinSettings />
      <IntegrationsSwitchSettings />
      <GymProfileSettings />
      <PlanSettings />
      <AiAssistantSettings />
      <NotificationSettings />
      <MessagingSettings />
    </ProductPage>
  </Shell>;
}
