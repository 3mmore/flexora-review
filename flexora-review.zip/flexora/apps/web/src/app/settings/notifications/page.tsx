'use client';

import { useState, useEffect } from 'react';
import { useTranslation } from '@/lib/i18n';
import { api } from '@/lib/api';

interface NotifSettings {
  ownerPersonalMobile: string;
  notifyOnSale: boolean;
  notifyOnMemberAdd: boolean;
  notifyOnMemberDelete: boolean;
  notifyOnDiscount: boolean;
  notifyOnRefund: boolean;
  antiTheftEnabled: boolean;
  maxDiscountAlert: number;
  maxCashAlert: number;
}

export default function NotificationSettingsPage(){
  const { t } = useTranslation();
  const [s, setS] = useState<NotifSettings>({
    ownerPersonalMobile: '',
    notifyOnSale: true,
    notifyOnMemberAdd: true,
    notifyOnMemberDelete: true,
    notifyOnDiscount: true,
    notifyOnRefund: true,
    antiTheftEnabled: true,
    maxDiscountAlert: 30,
    maxCashAlert: 500,
  });

  const [saving, setSaving] = useState(false);
  const [saved, setSaved]   = useState(false);

  useEffect(() => {
    api<any>('/gyms/notification-settings')
      .then(d => { if (d) setS(prev => ({ ...prev, ...d })) })
      .catch(() => {});
  }, []);

  const save = async () => {
    setSaving(true);
    try {
      await api('/gyms/notification-settings', {
        method: 'PATCH',
        body: JSON.stringify(s),
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } finally { setSaving(false); }
  };

  const toggle = (key: keyof NotifSettings) =>
    setS(prev => ({
      ...prev,
      [key]: !prev[key as keyof NotifSettings],
    }));

  const toggleStyle = (active: boolean) => ({
    width: '44px', height: '24px',
    borderRadius: '12px',
    background: active ? 'var(--brand)' : '#333',
    border: 'none', cursor: 'pointer',
    position: 'relative' as const,
    transition: 'background 0.2s',
    flexShrink: 0,
  });

  return (
    <div style={{
      padding: '2rem', color: 'white',
      background: '#0A0A0F', minHeight: '100vh',
      maxWidth: '600px', margin: '0 auto'
    }}>
      <h1 style={{
        fontSize: '1.5rem', fontWeight: 900,
        marginBottom: '0.5rem', color: 'var(--brand)',
      }}>
        {t('notification_settings')}
      </h1>
      <p style={{
        color: 'rgba(255,255,255,0.4)',
        marginBottom: '2rem', fontSize: '0.9rem',
      }}>
        {t('control_notifications_desc')}
      </p>

      {/* Personal WhatsApp */}
      <div style={{
        background: 'rgba(255,255,255,0.03)',
        borderRadius: '12px', padding: '1.25rem',
        marginBottom: '1rem',
        border: '1px solid rgba(255,255,255,0.07)',
      }}>
        <h3 style={{ marginBottom: '0.75rem',
          fontSize: '0.95rem' }}>
          {t('owner_whatsapp_personal')}
        </h3>
        <input
          type="tel"
          value={s.ownerPersonalMobile}
          onChange={e => setS(prev => ({
            ...prev,
            ownerPersonalMobile: e.target.value,
          }))}
          placeholder={t('phone_mask_intl')}
          style={{
            width: '100%', padding: '0.6rem 1rem',
            background: 'rgba(255,255,255,0.05)',
            border: '1px solid rgba(255,255,255,0.1)',
            borderRadius: '8px', color: 'white',
            fontSize: '0.95rem',
            boxSizing: 'border-box' as const,
          }}
        />
        <p style={{
          color: 'rgba(255,255,255,0.3)',
          fontSize: '0.8rem', marginTop: '0.5rem',
        }}>
          {t('important_alerts_sent')}
        </p>
      </div>

      {/* Anti-theft master switch */}
      <div style={{
        background: 'rgba(255,68,68,0.05)',
        borderRadius: '12px', padding: '1.25rem',
        marginBottom: '1rem',
        border: '1px solid rgba(255,68,68,0.15)',
      }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '0.75rem',
        }}>
          <h3 style={{ fontSize: '0.95rem' }}>
            {t('anti_theft_system')}
          </h3>
          <button
            onClick={() =>
              toggle('antiTheftEnabled')}
            style={toggleStyle(
              s.antiTheftEnabled)} />
        </div>

        {/* Thresholds */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: '1rem',
          opacity: s.antiTheftEnabled ? 1 : 0.4,
        }}>
          <div>
            <label style={{
              fontSize: '0.8rem',
              color: 'rgba(255,255,255,0.5)',
              display: 'block',
              marginBottom: '0.4rem',
            }}>
              {t('max_discount_pct')}
            </label>
            <input
              type="number"
              value={s.maxDiscountAlert}
              min={5} max={100}
              onChange={e => setS(prev => ({
                ...prev,
                maxDiscountAlert:
                  Number(e.target.value),
              }))}
              disabled={!s.antiTheftEnabled}
              style={{
                width: '100%',
                padding: '0.5rem',
                background:
                  'rgba(255,255,255,0.05)',
                border:
                  '1px solid rgba(255,255,255,0.1)',
                borderRadius: '8px',
                color: 'white',
                fontSize: '0.9rem',
              }}
            />
          </div>
          <div>
            <label style={{
              fontSize: '0.8rem',
              color: 'rgba(255,255,255,0.5)',
              display: 'block',
              marginBottom: '0.4rem',
            }}>
              {t('max_cash_egp')}
            </label>
            <input
              type="number"
              value={s.maxCashAlert}
              min={100}
              onChange={e => setS(prev => ({
                ...prev,
                maxCashAlert:
                  Number(e.target.value),
              }))}
              disabled={!s.antiTheftEnabled}
              style={{
                width: '100%',
                padding: '0.5rem',
                background:
                  'rgba(255,255,255,0.05)',
                border:
                  '1px solid rgba(255,255,255,0.1)',
                borderRadius: '8px',
                color: 'white',
                fontSize: '0.9rem',
              }}
            />
          </div>
        </div>
      </div>

      {/* Event toggles */}
      <div style={{
        background: 'rgba(255,255,255,0.03)',
        borderRadius: '12px', padding: '1.25rem',
        marginBottom: '1.5rem',
        border: '1px solid rgba(255,255,255,0.07)',
      }}>
        <h3 style={{
          marginBottom: '1rem',
          fontSize: '0.95rem',
        }}>
          {t('whatsapp_notifications_on')}
        </h3>
        {([
          ['notifyOnSale', t('every_sale')],
          ['notifyOnMemberAdd', t('new_member_added')],
          ['notifyOnMemberDelete', t('member_deleted_label')],
          ['notifyOnRefund', t('refund_invoice_cancelled')],
        ] as [keyof NotifSettings, string][])
          .map(([key, label]) => (
          <div key={key} style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            padding: '0.6rem 0',
            borderBottom:
              '1px solid rgba(255,255,255,0.05)',
          }}>
            <span style={{ fontSize: '0.9rem' }}>
              {label}
            </span>
            <button
              onClick={() => toggle(key)}
              style={toggleStyle(
                s[key] as boolean)} />
          </div>
        ))}
      </div>

      <button
        onClick={save}
        disabled={saving}
        style={{
          width: '100%', padding: '0.85rem',
          background: saving
            ? 'rgba(var(--brand-rgb),0.4)' : 'var(--brand)',
          border: 'none', borderRadius: '10px',
          color: 'white', fontWeight: 700,
          fontSize: '1rem',
          cursor: saving
            ? 'not-allowed' : 'pointer',
        }}>
        {saving ? t('saving_settings')
          : saved ? `✅ ${t('settings_saved')}`
          : t('save_settings')}
      </button>
    </div>
  );
}
