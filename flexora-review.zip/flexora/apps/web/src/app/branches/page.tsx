/**
 * FLEXORA Gym OS
 * © 2024 Ammar Allam. All rights reserved.
 */
'use client';
import { useCallback, useEffect, useState } from 'react';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { useTranslation } from '@/lib/i18n';
import { ActionCenter, FeedbackLayer, InsightCard, InsightLayer, ProductPage, SmartAction, SmartTable } from '@/components/ProductOS';
import { Skeleton } from '@/components/ui/States';
import { safeErrorMessage } from '@/lib/safe-error';
import { ModalPortal } from '@/components/ModalPortal';
import { useBranchScope } from '@/lib/branch-scope';

interface Branch {
  id?: string;
  name: string;
  address?: string;
  phone?: string;
  manager?: string;
}

export default function Branches() {
  const { t } = useTranslation();
  // PHASE 4: only OWNER/MANAGER may manage branches. Restricted staff see just
  // their own branch (the API returns only that one) and no management actions.
  const scope = useBranchScope();
  // ROUND 14 (security review, PHASE B): deleting a branch is branches.manage —
  // OWNER-only by default (the API enforces it too).
  const [perms, setPerms] = useState<string[] | null>(null);
  useEffect(() => { api<any>('/auth/me').then((r) => setPerms(r?.user?.permissions || [])).catch(() => setPerms([])); }, []);
  const canDeleteBranches = perms === null || (perms || []).includes('branches.manage');
  const [items, setItems] = useState<Branch[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<Partial<Branch> | null>(null);
  const [err, setErr] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api<any>('/branches');
      setItems(Array.isArray(data) ? data : (data.items || []));
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!form) return;
    setErr('');
    try {
      if (form.id) {
        await api(`/branches/${form.id}`, { method: 'PATCH', body: JSON.stringify({ name: form.name, address: form.address, phone: form.phone, manager: form.manager }) });
      } else {
        await api('/branches', { method: 'POST', body: JSON.stringify({ name: form.name, address: form.address, phone: form.phone, manager: form.manager }) });
      }
      setForm(null);
      load();
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    }
  }

  async function del(id: string) {
    if (!confirm(t('delete_branch_confirm'))) return;
    try {
      await api(`/branches/${id}`, { method: 'DELETE' });
      load();
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    }
  }

  return (
    <Shell>
      <ProductPage
        eyebrow={t('operations')}
        title={t('branches')}
        narrative={t('branches_description')}
        primaryAction={scope.unrestricted ? { label: t('add_branch'), icon: 'plus', onClick: () => setForm({}) } : undefined}
      >
        <InsightLayer>
          <InsightCard label={t('total_branches')} value={items.length} icon="home" detail={t('managed_locations')} />
        </InsightLayer>

        {err && <FeedbackLayer type="danger" title={t('error')} detail={err} />}

        {loading ? <Skeleton lines={5} /> : (
          <SmartTable
            columns={[t('name'), t('address'), t('phone'), t('manager'), t('actions')]}
            rows={items}
            emptyTitle={t('no_branches')}
            emptyDescription={t('create_first_branch')}
            renderRow={(b) => (
              <tr key={b.id}>
                <td>{b.name}</td>
                <td>{b.address || '—'}</td>
                <td>{b.phone || '—'}</td>
                <td>{b.manager || '—'}</td>
                <td>
                  {scope.unrestricted ? (
                    <span className="row-actions inline-flex gap-2">
                      <button className="btn-ghost btn-sm" onClick={() => setForm(b)}>{t('edit')}</button>
                      {canDeleteBranches ? (
                      <button className="btn-danger btn-sm" onClick={() => b.id && del(b.id)}>{t('delete')}</button>
                    ) : (
                      <span className="text-[11px] text-[var(--silver-dim)]" data-testid="branches-delete-locked" title={t('branches_manage_required') || 'requires branches.manage'}>{t('branches_manage_required') || 'requires branches.manage'}</span>
                    )}
                    </span>
                  ) : (
                    <span className="badge badge-active" data-testid="branch-readonly">{t('your_branch') || 'Your branch'}</span>
                  )}
                </td>
              </tr>
            )}
          />
        )}
      </ProductPage>

      {form && (
        <ModalPortal>
        <div className="fixed inset-0 bg-black/70 grid place-items-center p-5 z-50" onClick={() => setForm(null)}>
          <form onClick={(e) => e.stopPropagation()} onSubmit={save} className="card card-static glass w-full max-w-lg">
            <h3 className="text-title text-white mb-4">{form.id ? t('edit') : t('add_branch')}</h3>
            <div className="grid grid-cols-1 gap-3">
              <input className="input" placeholder={t('branch_name')} value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
              <input className="input" placeholder={t('branch_address')} value={form.address || ''} onChange={(e) => setForm({ ...form, address: e.target.value })} />
              <input className="input" placeholder={t('phone')} value={form.phone || ''} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
              <input className="input" placeholder={t('branch_manager')} value={form.manager || ''} onChange={(e) => setForm({ ...form, manager: e.target.value })} />
            </div>
            <div className="flex gap-2 justify-end mt-4">
              <button type="button" className="btn-ghost" onClick={() => setForm(null)}>{t('cancel')}</button>
              <button className="btn-primary">{t('save')}</button>
            </div>
          </form>
        </div>
        </ModalPortal>
      )}
    </Shell>
  );
}
