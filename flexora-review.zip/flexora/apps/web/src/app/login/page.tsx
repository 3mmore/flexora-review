/**
 * FLEXORA Gym OS — Premium Login (Phase 5 — UI/UX)
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Stripe / Linear / Apple Business style:
 *   - Centered card with logo
 *   - Animated background circuit pattern
 *   - Premium input fields
 *   - Single CTA with loading state
 *   - Demo accounts listed inline
 */
'use client';
import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Logo } from '@/components/brand/Logo';
import { Icon } from '@/components/brand/Icon';
import { Button } from '@/components/ui/Button';
import { auth } from '@/lib/api';
import { loginSchema } from '@/lib/schemas';
import { safeErrorMessage } from '@/lib/safe-error';
import { useTranslation } from '@/lib/i18n';
import { resetBranchScopeCache } from '@/lib/branch-scope';


export default function LoginPage() {
  const { t } = useTranslation();
  const router = useRouter();
  const search = useSearchParams();
  const gymSlug = search.get('gymSlug') || search.get('gym') || undefined;
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  const submit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    setBusy(true); setErr('');
    try {
      const parsed = loginSchema.safeParse({ email, password, gymSlug });
      if (!parsed.success) { setErr(parsed.error.issues[0]?.message || t('invalid_form')); return; }
      const user = await auth.login(email, password, gymSlug) as { requiresTwoFa?: boolean; tempToken: string };
      // Signal BrandProvider (mounted pre-login in the root layout) that a
      // session now exists so it loads the gym logo/accent color.
      try { sessionStorage.setItem('flexora-brand-refresh', '1'); } catch { /* noop */ }
      // PHASE 4: a different person may be signing in — never reuse the
      // previous session's cached role/branch scope.
      resetBranchScopeCache();
      if (user?.requiresTwoFa) {
        sessionStorage.setItem('flx_2fa_token', user.tempToken);
        router.push('/login/2fa');
        return;
      }
      router.replace('/dashboard');
    } catch (e: unknown) {
      setErr(safeErrorMessage(e) || t('invalid_credentials'));
    } finally { setBusy(false); }
  };

  return (
    <div className="login-shell">
      {/* Animated background circuit pattern */}
      <div className="login-bg-circuit" aria-hidden="true" />

      <div className="login-card">
        <div className="login-logo">
          <Logo variant="full" size={180} tone="dark" />
        </div>
        <p className="login-tagline">{t('login_tagline')}</p>

        <form onSubmit={submit} className="login-form">
          <label className="login-field">
            <span className="login-label">{t('email')}</span>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoFocus
              required
              className="login-input"
              autoComplete="email"
            />
          </label>

          <label className="login-field">
            <span className="login-label">{t('password')}</span>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="login-input"
              autoComplete="current-password"
            />
          </label>

          {err && (
            <div className="login-error" role="alert">
              <Icon name="shield" size={14} />
              <span>{err}</span>
            </div>
          )}

          <Button type="submit" loading={busy} variant="primary" size="lg" className="w-full mt-2">
            {busy ? t('signing_in') : t('sign_in')}
          </Button>
        </form>

        {/* ROUND 13 (Phase 3): the login page was the only entry point with no
            way to reach /register — users could only ever land in the
            pre-onboarded demo account and never saw onboarding. A clear
            "create a new gym account" link opens the registration flow. */}
        <div className="login-register">
          <span className="login-register-text">{t('new_to_flexora')}</span>
          <Link href="/register" className="login-register-link" data-testid="login-register-link">
            {t('create_gym_account')}
          </Link>
        </div>

        <div className="login-footer">
          <span>© 2024 Ammar Allam</span>
          <span>·</span>
          <a href={process.env.NEXT_PUBLIC_SUPPORT_URL || "#contact"} className="login-footer-link" target="_blank" rel="noopener noreferrer">
            <Icon name="send" size={11} /> {t('support')}
          </a>
        </div>
      </div>
    </div>
  );
}
