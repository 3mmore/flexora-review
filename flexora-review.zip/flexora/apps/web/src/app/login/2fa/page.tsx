'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { api } from '@/lib/api';
import { safeErrorMessage } from '@/lib/safe-error';
import { useTranslation } from '@/lib/i18n';

export default function TwoFactorLoginPage() {
  const { t } = useTranslation();
  const router = useRouter();
  const [code, setCode] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const token = sessionStorage.getItem('flx_2fa_token');
    if (!token) router.replace('/login');
    else setReady(true);
  }, [router]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true); setErr('');
    try {
      const tempToken = sessionStorage.getItem('flx_2fa_token');
      await api('/auth/2fa/login', { method: 'POST', body: JSON.stringify({ tempToken, code }) });
      sessionStorage.removeItem('flx_2fa_token');
      try { sessionStorage.setItem('flexora-brand-refresh', '1'); } catch { /* noop */ }
      router.replace('/dashboard');
    } catch (error) {
      setErr(safeErrorMessage(error));
    } finally {
      setBusy(false);
    }
  }

  if (!ready) return null;
  return <main className="login-shell"><form onSubmit={submit} className="login-card"><h1 className="text-2xl font-extrabold text-white">{t('two_factor_auth')}</h1><p className="mt-2 text-sm text-[var(--muted)]">{t('enter_authenticator_code')}</p><input className="login-input mt-5" value={code} onChange={(e) => setCode(e.target.value)} inputMode="numeric" autoFocus />{err && <div className="login-error mt-3">{err}</div>}<button className="btn btn-primary mt-5 w-full" disabled={busy}>{busy ? t('verifying') : t('verify')}</button></form></main>;
}
