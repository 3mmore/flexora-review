/**
 * FLEXORA Gym OS — Owner notification inbox (/notifications).
 *
 * Replaces "the 30 most recent rows in a dropdown" with a real screen:
 * server-side pagination, read/unread + severity + type + date-range filters,
 * search, and a readable detail panel that shows metadata as labelled rows
 * (never as JSON). The dropdown stays and gains a link back to here.
 *
 * Every value on this page comes from the API; nothing is inferred client-side,
 * so an empty list always means "the server said zero rows for these filters"
 * and never "a request failed" — failures render an explicit error block.
 */
'use client';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Link from 'next/link';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { EmptyState, ErrorState, Skeleton } from '@/components/ui/States';
import { Icon } from '@/components/brand/Icon';
import { ModalPortal } from '@/components/ModalPortal';
import { useTranslation } from '@/lib/i18n';
import { formatDate } from '@/lib/dates';
import { tzLabelKey } from '@/lib/team';
import { safeErrorMessage } from '@/lib/safe-error';
import {
  EMPTY_FILTERS,
  NotificationDetail,
  NotificationFeed,
  NotificationFilters,
  buildFeedQuery,
  formatWhen,
  isSafeLink,
  previewText,
  refreshUnreadCount,
  severityColor,
  severityKey,
  typeKey,
} from '@/lib/notifications';

const SEVERITIES = ['info', 'warning', 'danger', 'success'] as const;

export default function NotificationsInbox() {
  const { t, lang } = useTranslation();
  const [filters, setFilters] = useState<NotificationFilters>(EMPTY_FILTERS);
  const [feed, setFeed] = useState<NotificationFeed | null>(null);
  const [types, setTypes] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [detail, setDetail] = useState<NotificationDetail | null>(null);
  const [detailBusy, setDetailBusy] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const requestId = useRef(0);

  const load = useCallback(async (next: NotificationFilters) => {
    const id = ++requestId.current;
    setLoading(true);
    setError('');
    try {
      const data = await api<NotificationFeed>(`/owner/notifications/feed?${buildFeedQuery(next)}`);
      if (id !== requestId.current) return; // a newer request already answered
      setFeed(data);
      refreshUnreadCount();
    } catch (e) {
      if (id !== requestId.current) return;
      setFeed(null);
      setError(safeErrorMessage(e) || 'notifications_load_failed');
    } finally {
      if (id === requestId.current) setLoading(false);
    }
  }, [t]);

  // Debounced: typing in the search box must not fire a request per keystroke.
  useEffect(() => {
    const handle = setTimeout(() => { load(filters); }, 250);
    return () => clearTimeout(handle);
  }, [filters, load]);

  useEffect(() => {
    api<{ types: string[] }>('/owner/notifications/types')
      .then((r) => setTypes(Array.isArray(r?.types) ? r.types : []))
      .catch(() => setTypes([]));
  }, []);

  const patch = (p: Partial<NotificationFilters>) => setFilters((f) => ({ ...f, page: 1, ...p }));

  const openDetail = async (id: string) => {
    setDetailBusy(true);
    try {
      const row = await api<NotificationDetail>(`/owner/notifications/${encodeURIComponent(id)}`);
      setDetail(row);
      if (!row.isRead) {
        await api(`/owner/notifications/${encodeURIComponent(id)}`, { method: 'PATCH' }).catch(() => undefined);
        setFeed((f) => f ? { ...f, items: f.items.map((n) => n.id === id ? { ...n, isRead: true } : n), unread: Math.max(0, f.unread - 1) } : f);
        refreshUnreadCount();
      }
    } catch (e) {
      setError(safeErrorMessage(e) || 'notifications_load_failed');
    } finally {
      setDetailBusy(false);
    }
  };

  const toggleRead = async (item: { id: string; isRead: boolean }) => {
    setBusyId(item.id);
    try {
      if (item.isRead) await api(`/owner/notifications/${encodeURIComponent(item.id)}/unread`, { method: 'PATCH' });
      else await api(`/owner/notifications/${encodeURIComponent(item.id)}`, { method: 'PATCH' });
      setFeed((f) => f ? {
        ...f,
        items: f.items.map((n) => n.id === item.id ? { ...n, isRead: !item.isRead } : n),
        unread: Math.max(0, f.unread + (item.isRead ? 1 : -1)),
      } : f);
      setDetail((d) => d && d.id === item.id ? { ...d, isRead: !item.isRead } : d);
      refreshUnreadCount();
    } catch (e) {
      setError(safeErrorMessage(e) || 'notifications_action_failed');
    } finally {
      setBusyId(null);
    }
  };

  const markAll = async () => {
    setLoading(true);
    try {
      await api('/owner/notifications/read-all', { method: 'PATCH' });
      await load(filters);
    } catch (e) {
      setError(safeErrorMessage(e) || 'notifications_action_failed');
      setLoading(false);
    }
  };

  const remove = async (id: string) => {
    setBusyId(id);
    try {
      await api(`/owner/notifications/${encodeURIComponent(id)}`, { method: 'DELETE' });
      setDetail((d) => (d && d.id === id ? null : d));
      setFeed((f) => f ? { ...f, items: f.items.filter((n) => n.id !== id), total: Math.max(0, f.total - 1) } : f);
      refreshUnreadCount();
    } catch (e) {
      setError(safeErrorMessage(e) || 'notifications_action_failed');
    } finally {
      setBusyId(null);
    }
  };

  const activeFilters = useMemo(() => {
    let n = 0;
    if (filters.status !== 'all') n++;
    if (filters.severity) n++;
    if (filters.type) n++;
    if (filters.from || filters.to) n++;
    if (filters.q.trim()) n++;
    return n;
  }, [filters]);

  const items = feed?.items ?? [];
  const totalPages = feed?.totalPages ?? 0;

  return (
    <Shell>
      <div className="ntf-page" data-testid="notifications-page">
        <header className="ntf-head">
          <div>
            <h1 className="ntf-title">{t('notifications') || 'الإشعارات'}</h1>
            <p className="ntf-sub">
              {feed
                ? `${feed.total} ${t('notifications_total_label')} · ${feed.unread} ${t('notifications_unread_label')}`
                : t('notifications_loading_hint')}
            </p>
          </div>
          <div className="ntf-head-actions">
            <button type="button" className="btn btn-secondary ntf-tap" onClick={markAll} disabled={loading || !feed || feed.unread === 0}>
              <Icon name="check" size={14} /> {t('mark_all_read')}
            </button>
          </div>
        </header>

        <section className="ntf-filters" aria-label={t('filters') || 'Filters'}>
          <div className="ntf-segment" role="group" aria-label={t('notification_status') || 'Read state'}>
            {(['all', 'unread', 'read'] as const).map((s) => (
              <button
                key={s}
                type="button"
                className={`ntf-seg ntf-tap ${filters.status === s ? 'is-active' : ''}`}
                aria-pressed={filters.status === s}
                onClick={() => patch({ status: s })}
              >
                {t(`notification_status_${s}`)}
              </button>
            ))}
          </div>

          <label className="ntf-field">
            <span>{t('search')}</span>
            <input
              className="input"
              type="search"
              inputMode="search"
              maxLength={100}
              value={filters.q}
              placeholder={t('notifications_search_placeholder')}
              onChange={(e) => patch({ q: e.target.value })}
            />
          </label>

          <label className="ntf-field">
            <span>{t('severity')}</span>
            <select className="input" value={filters.severity} onChange={(e) => patch({ severity: e.target.value as NotificationFilters['severity'] })}>
              <option value="">{t('all')}</option>
              {SEVERITIES.map((s) => <option key={s} value={s}>{t(severityKey(s))}</option>)}
            </select>
          </label>

          <label className="ntf-field">
            <span>{t('notification_type')}</span>
            <select className="input" value={filters.type} onChange={(e) => patch({ type: e.target.value })}>
              <option value="">{t('all')}</option>
              {types.map((ty) => <option key={ty} value={ty}>{typeKey(ty) ? t(typeKey(ty) as string) : ty.replace(/_/g, ' ')}</option>)}
            </select>
          </label>

          <label className="ntf-field">
            <span>{t('from_date')}</span>
            <input className="input" type="date" value={filters.from} max={filters.to || undefined} onChange={(e) => patch({ from: e.target.value })} />
          </label>

          <label className="ntf-field">
            <span>{t('to_date')}</span>
            <input className="input" type="date" value={filters.to} min={filters.from || undefined} onChange={(e) => patch({ to: e.target.value })} />
          </label>

          {activeFilters > 0 && (
            <button type="button" className="btn btn-ghost ntf-tap ntf-clear" onClick={() => setFilters(EMPTY_FILTERS)}>
              <Icon name="x" size={14} /> {t('clear_filters')}
            </button>
          )}
        </section>

        {feed && (
          <p className="ntf-range" data-testid="notification-range">
            {formatDate(feed.range.from)} ← {formatDate(feed.range.to)}{tzLabelKey(feed.range.tz) ? ` · ${t(tzLabelKey(feed.range.tz)!)}` : ''}
          </p>
        )}

        {error && (
          <ErrorState
            title={t('something_went_wrong')}
            description={t(error)}
            onRetry={() => load(filters)}
          />
        )}

        {!error && loading && (
          <div className="ntf-list" aria-busy="true" data-testid="notifications-loading">
            {[0, 1, 2, 3].map((i) => <Skeleton key={i} lines={2} />)}
          </div>
        )}

        {!error && !loading && items.length === 0 && (
          <EmptyState
            icon="bell"
            title={t('notifications_empty_title')}
            description={activeFilters > 0 ? t('notifications_empty_filtered') : t('notifications_empty_all')}
          />
        )}

        {!error && !loading && items.length > 0 && (
          <ul className="ntf-list" aria-live="polite">
            {items.map((n) => (
              <li key={n.id} className={`ntf-row ${n.isRead ? '' : 'is-unread'}`} data-unread={n.isRead ? '0' : '1'}>
                <button type="button" className="ntf-open" onClick={() => openDetail(n.id)} aria-label={`${t('open')} ${n.title}`}>
                  <span className="ntf-dot" style={{ background: severityColor(n.severity) }} aria-hidden="true" />
                  <span className="ntf-row-main">
                    <span className="ntf-row-top">
                      <strong>{n.title}</strong>
                      <time dateTime={n.createdAt}>{formatWhen(n.createdAt, lang)}</time>
                    </span>
                    <span className="ntf-row-body">{previewText(n.body)}</span>
                    <span className="ntf-row-tags">
                      <span className="ntf-tag" style={{ color: severityColor(n.severity) }}>{t(severityKey(n.severity))}</span>
                      <span className="ntf-tag ntf-tag-muted">{typeKey(n.type) ? t(typeKey(n.type) as string) : n.type.replace(/_/g, ' ')}</span>
                      {n.hasMetadata && <span className="ntf-tag ntf-tag-muted">+ {t('notification_details_count')}</span>}
                    </span>
                  </span>
                </button>
                <span className="ntf-row-actions">
                  <button
                    type="button"
                    className="ntf-icon-btn"
                    title={n.isRead ? t('mark_unread') : t('mark_read')}
                    aria-label={n.isRead ? t('mark_unread') : t('mark_read')}
                    disabled={busyId === n.id}
                    onClick={() => toggleRead(n)}
                  >
                    <Icon name={n.isRead ? 'bell' : 'check'} size={16} />
                  </button>
                  <button
                    type="button"
                    className="ntf-icon-btn ntf-icon-danger"
                    title={t('delete')}
                    aria-label={t('delete')}
                    disabled={busyId === n.id}
                    onClick={() => remove(n.id)}
                  >
                    <Icon name="x" size={16} />
                  </button>
                </span>
              </li>
            ))}
          </ul>
        )}

        {!error && totalPages > 1 && (
          <nav className="ntf-pager" aria-label={t('pagination') || 'Pagination'}>
            <button type="button" className="btn btn-ghost ntf-tap" disabled={filters.page <= 1 || loading} onClick={() => setFilters((f) => ({ ...f, page: f.page - 1 }))}>
              <Icon name={lang === 'ar' ? 'arrow-right' : 'arrow-left'} size={14} /> {t('previous')}
            </button>
            <span data-testid="notification-page-indicator">{filters.page} / {totalPages}</span>
            <button type="button" className="btn btn-ghost ntf-tap" disabled={filters.page >= totalPages || loading} onClick={() => setFilters((f) => ({ ...f, page: f.page + 1 }))}>
              {t('next')} <Icon name={lang === 'ar' ? 'arrow-left' : 'arrow-right'} size={14} />
            </button>
          </nav>
        )}

        <p className="ntf-footnote">{t('notifications_model_note')}</p>
      </div>

      {(detail || detailBusy) && (
        <ModalPortal>
          <div className="ntf-modal-backdrop" onClick={() => setDetail(null)}>
            <div
              className="ntf-modal"
              role="dialog"
              aria-modal="true"
              aria-label={t('notification_detail')}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="ntf-modal-head">
                <span className="ntf-tag" style={{ color: severityColor(detail?.severity || 'info') }}>
                  {t(severityKey(detail?.severity || 'info'))}
                </span>
                <button type="button" className="ntf-icon-btn" aria-label={t('close')} onClick={() => setDetail(null)}>
                  <Icon name="x" size={16} />
                </button>
              </div>

              {detailBusy && !detail && <Skeleton lines={4} />}

              {detail && (
                <>
                  <h2 className="ntf-modal-title">{detail.title}</h2>
                  <p className="ntf-modal-meta">
                    <time dateTime={detail.createdAt}>{formatWhen(detail.createdAt, lang)}</time>
                    {' · '}
                    {typeKey(detail.type) ? t(typeKey(detail.type) as string) : detail.type.replace(/_/g, ' ')}
                  </p>
                  <div className="ntf-modal-body">{detail.body}</div>

                  {detail.metadata && detail.metadata.length > 0 && (
                    <dl className="ntf-meta" data-testid="notification-metadata">
                      {detail.metadata.map((entry, i) => (
                        <div key={`${entry.label}-${i}`} className="ntf-meta-row">
                          <dt>{entry.label}</dt>
                          <dd>
                            {entry.kind === 'link' && isSafeLink(entry.value) ? (
                              <a href={entry.value} target="_blank" rel="noopener noreferrer nofollow">{entry.value}</a>
                            ) : (
                              entry.value
                            )}
                          </dd>
                        </div>
                      ))}
                    </dl>
                  )}
                  {detail.metadataUnreadable && <p className="ntf-note">{t('notification_meta_unreadable')}</p>}
                  {detail.metadataTruncated && <p className="ntf-note">{t('notification_meta_truncated')}</p>}

                  <div className="ntf-modal-actions">
                    <button type="button" className="btn btn-secondary ntf-tap" onClick={() => toggleRead(detail)}>
                      <Icon name={detail.isRead ? 'bell' : 'check'} size={14} />
                      {detail.isRead ? t('mark_unread') : t('mark_read')}
                    </button>
                    <button type="button" className="btn btn-danger ntf-tap" onClick={() => remove(detail.id)}>
                      <Icon name="x" size={14} /> {t('delete')}
                    </button>
                    <Link href="/notifications" className="btn btn-ghost ntf-tap" onClick={() => setDetail(null)}>
                      {t('close')}
                    </Link>
                  </div>
                </>
              )}
            </div>
          </div>
        </ModalPortal>
      )}
    </Shell>
  );
}
