/**
 * FLEXORA AI — Executive Assistant Workspace
 * Product redesign: AI is positioned as an operating partner, not a chatbot.
 */
'use client';
import { useEffect, useState } from 'react';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { Card } from '@/components/ui/Card';
import { EmptyState, Skeleton } from '@/components/ui/States';
import { Icon } from '@/components/brand/Icon';
import { useTypewriter } from '@/lib/hooks';
import { useTranslation } from '@/lib/i18n';
import { fmtMoney } from '@/lib/money';
import { valueLabel } from '@/lib/i18n/fields';

type WorkspaceState = {
  providerStatus: Record<string, any> | null;
  briefing: Record<string, any> | null;
  churn: Record<string, any> | null;
  forecast: Record<string, any> | null;
  pricing: Record<string, any> | null;
  retention: Record<string, any> | null;
};

function TypedText({ text, dir = 'auto', className = '' }: { text: string; dir?: 'auto' | 'rtl'; className?: string }) {
  const shown = useTypewriter(text, 14);
  return <p dir={dir} className={className}>{shown}</p>;
}

function SignalCard({ title, value, detail, icon, tone = 'neutral' }: { title: string; value: string; detail: string; icon: 'sparkle' | 'chart' | 'users' | 'coins' | 'shield'; tone?: 'neutral' | 'risk' | 'good' | 'warn' }) {
  const toneClass = tone === 'risk' ? 'text-[var(--danger)]' : tone === 'good' ? 'text-[var(--success)]' : tone === 'warn' ? 'text-[var(--warning)]' : 'text-[var(--cyan)]';
  return (
    <Card hoverable padding="md">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="text-xs uppercase tracking-[0.16em] text-[var(--silver-dim)] font-bold">{title}</div>
          <div className="mt-3 text-3xl font-extrabold text-white">{value}</div>
          <div className="mt-2 text-sm text-[var(--silver-dim)]">{detail}</div>
        </div>
        <div className={`h-10 w-10 rounded-xl bg-white/5 flex items-center justify-center ${toneClass}`}><Icon name={icon} size={18} /></div>
      </div>
    </Card>
  );
}

function SuggestedActions({ data }: { data: WorkspaceState }) {
  const { t, lang } = useTranslation();
  const actions = [
    { title: t('recover_at_risk_members'), detail: `${data.churn?.summary?.high || 0} ${t('high_risk_identified')}`, href: '/ai-advanced', icon: 'users' as const, tone: 'risk' },
    { title: t('launch_renewal_campaign'), detail: t('target_expiring_members_whatsapp'), href: '/campaigns', icon: 'send' as const, tone: 'warn' },
    { title: t('review_pricing'), detail: data.pricing?.recommendation || t('use_seasonality_distribution'), href: '/ai-advanced', icon: 'coins' as const, tone: 'neutral' },
    { title: t('open_growth_dashboard'), detail: t('forecast_revenue_upsell'), href: '/reports', icon: 'chart' as const, tone: 'good' },
  ];
  return (
    <div className="space-y-3">
      {actions.map((a) => (
        <a key={a.title} href={a.href} className="flex items-center gap-3 rounded-xl bg-black/20 p-3 hover:bg-white/5 transition-colors">
          <div className="h-9 w-9 rounded-lg bg-[var(--cyan)]/10 text-[var(--cyan)] flex items-center justify-center"><Icon name={a.icon} size={15} /></div>
          <div className="flex-1 min-w-0"><div className="font-semibold text-sm text-white">{a.title}</div><div className="text-xs text-[var(--silver-dim)] truncate">{a.detail}</div></div>
          <Icon name="arrow-right" size={12} />
        </a>
      ))}
    </div>
  );
}

function AskExecutive() {
  const { t, lang } = useTranslation();
  const [q, setQ] = useState('');
  const [ctx, setCtx] = useState('members');
  const [ans, setAns] = useState<Record<string, any> | null>(null);
  const [loading, setLoading] = useState(false);
  async function ask(prompt?: string) {
    const question = prompt || q;
    if (!question.trim()) return;
    setQ(question);
    setLoading(true); setAns(null);
    try {
      const r = await api<Record<string, any>>('/ai/chat', { method: 'POST', body: JSON.stringify({ message: question, context: ctx }) });
      setAns(r);
    } catch (e: unknown) { setAns({ answer: (e as Error).message }); } finally { setLoading(false); }
  }
  return (
    <Card variant="glow" padding="lg">
      <div className="flex items-center gap-2 text-[var(--cyan)]"><Icon name="sparkle" size={18} /><span className="text-xs font-bold uppercase tracking-[0.16em]">{t('ask_flexora_ai')}</span></div>
      <h2 className="mt-3 text-2xl font-bold text-white">{t('executive_questions_answered')}</h2>
      <div className="mt-5 flex flex-col md:flex-row gap-2">
        <select className="input md:max-w-[180px]" value={ctx} onChange={(e) => setCtx(e.target.value)}>
          <option value="members">{t('members')}</option><option value="revenue">{t('revenue')}</option><option value="products">{t('products')}</option><option value="attendance">{t('attendance')}</option><option value="classes">{t('classes')}</option><option value="pt">PT</option><option value="invitations">{t('tab_slots')}</option>
        </select>
        <input className="input" placeholder={t('ask_fix_week')} value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && ask()} />
        <button className="btn btn-primary px-5" onClick={() => ask()} disabled={loading}>{loading ? t('thinking') : t('ask')}</button>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        {([t('ai_prompt_churn'), t('ai_prompt_grow'), t('ai_prompt_focus')]).map((p) => <button key={p} onClick={() => ask(p)} className="btn btn-ghost px-3 py-1.5 text-xs">{p}</button>)}
      </div>
      {loading && <div className="mt-5 flex items-center gap-3 text-sm text-[var(--silver-dim)]"><span className="circuit-loader"><span /><span /><span /><span /><span /></span> {t('generating_executive_answer')}</div>}
      {ans?.answer && <><TypedText text={ans.answer} dir="auto" className="mt-5 rounded-2xl bg-black/25 p-5 text-sm leading-7 whitespace-pre-wrap" />{ans?.source && <p className="mt-2 text-xs text-[var(--silver-dim)]">{t('source')}: {valueLabel('source', String(ans.source), lang === 'en' ? 'en' : 'ar')} · {t('confidence')}: {valueLabel('confidence', String(ans.confidence || 'medium'), lang === 'en' ? 'en' : 'ar')}</p>}</>}
    </Card>
  );
}

export default function AiPage() {
  const { t, lang } = useTranslation();
  const [data, setData] = useState<WorkspaceState>({ providerStatus: null, briefing: null, churn: null, forecast: null, pricing: null, retention: null });
  const [busy, setBusy] = useState(true);

  useEffect(() => {
    async function load() {
      setBusy(true);
      try {
        const [providerStatus, briefing, churn, forecast, pricing, retention] = await Promise.all([
          api<Record<string, any>>('/ai/provider-status').catch(() => ({})),
          api<Record<string, any>>('/ai/daily-briefing').catch(() => ({})),
          api<Record<string, any>>('/ai/churn-risk').catch(() => ({})),
          api<Record<string, any>>('/ai/revenue-forecast').catch(() => ({})),
          api<Record<string, any>>('/ai/smart-pricing').catch(() => ({})),
          api<Record<string, any>>('/ai/retention-score').catch(() => ({})),
        ]);
        setData({ providerStatus, briefing, churn, forecast, pricing, retention });
      } finally { setBusy(false); }
    }
    load();
  }, []);

  const forecast = data.forecast?.forecast;
  const expected = forecast ? fmtMoney((forecast.expectedMin + forecast.expectedMax) / 2) : t('loading');

  return (
    <Shell>
      <div className="px-8 py-8 space-y-6">
        <section className="grid grid-cols-1 xl:grid-cols-[1.1fr_0.9fr] gap-5">
          <Card variant="glow" padding="lg" className="grid-bg">
            <div className="relative z-10">
              <p className="text-xs uppercase tracking-[0.22em] font-bold text-[var(--cyan)]">{t('ai_executive_workspace')}</p>
              <h1 className="mt-3 text-4xl md:text-5xl font-extrabold text-white tracking-tight">{t('gym_operating_intelligence')}</h1>
              <p className="mt-3 max-w-2xl text-[var(--silver-dim)] leading-7">{t('flexora_ai_connects')}</p>
            <div className="mt-5 rounded-2xl bg-black/25 border border-white/10 p-4">
              <div className="text-xs uppercase tracking-[0.16em] text-[var(--silver-dim)] font-bold">{t('ai_provider')}</div>
              <div className="mt-2 flex flex-wrap gap-2 text-xs">
                {(data.providerStatus?.providers as Record<string, any>[] || []).map((p) => (
                  <span key={p.id} className={`rounded-full px-3 py-1 border ${data.providerStatus?.selected === p.id ? 'border-[var(--cyan)] text-[var(--cyan)]' : 'border-white/10 text-[var(--silver-dim)]'}`}>
                    {p.label}: {p.configured ? t('configured') : t('missing_key')}
                  </span>
                ))}
              </div>
              <p className="mt-2 text-xs text-[var(--silver-dim)]">{t('status')}: {data.providerStatus?.active ? t('active') : t('disabled')}</p>
            </div>
            </div>
          </Card>
          <Card padding="lg">
            <h2 className="text-xl font-bold text-white mb-2">{t('todays_brief')}</h2>
            {busy ? <Skeleton lines={7} /> : data.briefing?.aiBriefing ? <TypedText text={data.briefing.aiBriefing} dir="rtl" className="text-sm leading-7 whitespace-pre-line" /> : <EmptyState icon="sparkle" title={t('briefing_appear_here')} description={t('connect_activity_ai')} />}
          </Card>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
          {busy ? <><Skeleton /><Skeleton /><Skeleton /><Skeleton /></> : <>
            <SignalCard title={t('churn_risk')} value={`${data.churn?.summary?.high || 0}`} detail={t('high_risk_members')} icon="users" tone={(data.churn?.summary?.high || 0) ? 'risk' : 'good'} />
            <SignalCard title={t('revenue_forecast')} value={expected} detail={forecast?.confidence ? `${valueLabel('confidence', String(forecast.confidence), lang === 'en' ? 'en' : 'ar')} ${t('confidence')}` : t('needs_more_data')} icon="chart" />
            <SignalCard title={t('retention_score')} value={`${data.retention?.averageScore ?? 0}/100`} detail={t('member_health_average')} icon="shield" tone={(data.retention?.averageScore || 0) > 70 ? 'good' : 'warn'} />
            <SignalCard title={t('pricing_urgency')} value={valueLabel('severity', String(data.pricing?.urgency || 'low'), lang === 'en' ? 'en' : 'ar')} detail={t('ai_pricing_recommendation')} icon="coins" />
          </>}
        </section>

        <section className="grid grid-cols-1 xl:grid-cols-[0.9fr_1.1fr] gap-5">
          <Card padding="lg">
            <h2 className="text-xl font-bold text-white mb-1">{t('suggested_actions')}</h2>
            <p className="text-sm text-[var(--silver-dim)] mb-5">{t('turn_insight_execution')}</p>
            {busy ? <Skeleton lines={8} /> : <SuggestedActions data={data} />}
          </Card>
          <AskExecutive />
        </section>
      </div>
    </Shell>
  );
}
