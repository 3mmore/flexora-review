'use client';
/**
 * Last-resort error boundary — Arabic (PACK 2, item 1).
 *
 * This component REPLACES the root layout, so it cannot rely on it: no globals.css,
 * no Providers, no theme tokens. Everything here is inline, RTL from the first
 * byte, and the text is Arabic — an English "Application error: a client-side
 * exception has occurred" is exactly what the owner must never see.
 *
 * translateKey() is a plain function (not a hook), so it works here where there is
 * no React context; it falls back to Arabic when storage is unavailable.
 */
import { translateKey } from '@/lib/i18n';

export default function GlobalError({
  error,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  const title = translateKey('global_error_title');
  const desc = translateKey('global_error_desc');
  const action = translateKey('error_reload');

  return (
    <html lang="ar" dir="rtl">
      <body
        style={{
          margin: 0,
          minHeight: '100vh',
          background: '#0a0a0b',
          color: '#f5f5f6',
          fontFamily: 'Cairo, system-ui, sans-serif',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '24px',
        }}
      >
        <main style={{ maxWidth: '420px', width: '100%', textAlign: 'center' }}>
          <div
            style={{
              margin: '0 auto 20px',
              width: 56,
              height: 56,
              borderRadius: 18,
              background: 'rgba(197,160,89,0.15)',
              border: '1px solid rgba(197,160,89,0.45)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: 26,
              color: '#c5a059',
            }}
          >
            !
          </div>
          <h1 style={{ fontSize: 22, fontWeight: 700, margin: '0 0 12px' }}>{title}</h1>
          <p style={{ color: '#a1a1aa', lineHeight: 1.9, margin: '0 0 24px' }}>{desc}</p>
          <button
            type="button"
            onClick={() => window.location.reload()}
            style={{
              width: '100%',
              minHeight: 48,
              borderRadius: 12,
              border: 'none',
              background: '#c5a059',
              color: '#0a0a0b',
              fontSize: 16,
              fontWeight: 700,
              fontFamily: 'inherit',
              cursor: 'pointer',
            }}
          >
            {action}
          </button>
          {error?.digest ? (
            <p style={{ fontSize: 11, color: '#71717a', marginTop: 16 }}>
              {translateKey('error_reference')}{' '}
              <span dir="ltr">{error.digest}</span>
            </p>
          ) : null}
        </main>
      </body>
    </html>
  );
}
