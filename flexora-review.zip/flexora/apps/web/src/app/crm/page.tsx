/**
 * FLEXORA Gym OS
 * © 2024 Ammar Allam. All rights reserved.
 */
'use client';
import { useCallback, useEffect, useState } from 'react';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { useTranslation } from '@/lib/i18n';
import { FeedbackLayer, InsightCard, InsightLayer, ProductPage, SmartTable } from '@/components/ProductOS';
import { Skeleton } from '@/components/ui/States';
import { safeErrorMessage } from '@/lib/safe-error';
import { ModalPortal } from '@/components/ModalPortal';

interface Lead {
  id: string;
  name: string;
  mobile?: string;
  phone?: string;
  source?: string;
  status: string;
  email?: string;
  notes?: string;
}

export default function CRM() {
  const { t } = useTranslation();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<Partial<Lead> | null>(null);
  const [err, setErr] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api<any>('/crm/leads');
      setLeads(Array.isArray(data) ? data : (data.items || []));
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!form) return;
    setErr('');
    // FIX (lead creation 400ed with "source must be one of … / status must be
    // one of …"): the form sent a free-text source (empty string by default)
    // and offered status options (FOLLOW_UP, TRIAL) that are NOT valid
    // LeadStatus enum values. Build a payload with only valid enum values and
    // omit empty fields instead of sending ''.
    const leadSource = (form.source || 'WALK_IN').toUpperCase();
    const leadStatus = (form.status || 'NEW').toUpperCase();
    const VALID_SOURCES = ['WALK_IN', 'REFERRAL', 'SOCIAL_MEDIA', 'WEBSITE', 'WHATSAPP', 'INVITATION', 'OTHER'];
    const VALID_STATUSES = ['NEW', 'CONTACTED', 'INTERESTED', 'TRIAL_BOOKED', 'TRIAL_REQUESTED', 'TRIAL_COMPLETED', 'FOLLOWED_UP', 'CONVERTED', 'LOST'];
    if (!VALID_SOURCES.includes(leadSource)) { setErr(t('invalid_source') || 'Please choose a valid source'); return; }
    if (!VALID_STATUSES.includes(leadStatus)) { setErr(t('invalid_status') || 'Please choose a valid status'); return; }
    const mobile = (form.mobile || form.phone || '').trim();
    if (!mobile) { setErr(t('mobile_required') || 'Mobile number is required'); return; }
    const payload: Record<string, unknown> = {
      name: form.name?.trim(),
      mobile,
      source: leadSource,
      status: leadStatus,
    };
    const email = (form.email || '').trim();
    if (email) payload.email = email;
    if (form.notes) payload.notes = form.notes;
    try {
      if (form.id) {
        await api(`/crm/leads/${form.id}`, { method: 'PATCH', body: JSON.stringify(payload) });
      } else {
        await api('/crm/leads', { method: 'POST', body: JSON.stringify(payload) });
      }
      setForm(null);
      load();
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    }
  }

  return (
    <Shell>
      <ProductPage
        eyebrow={t('sales')}
        title={t('crm_leads')}
        narrative={t('convert_interest_desc')}
        primaryAction={{ label: t('add_lead'), icon: 'plus', onClick: () => setForm({ status: 'NEW' }) }}
      >
        <InsightLayer>
          <InsightCard label={t('total_members')} value={leads.length} detail={t('prospects_funnel')} icon="users" />
          <InsightCard label={t('new')} value={leads.filter(l => l.status === 'NEW').length} detail={t('need_followup')} icon="bell" tone="warning" />
          <InsightCard label={t('converted')} value={leads.filter(l => l.status === 'CONVERTED').length} detail={t('leads_became_members')} icon="shield" tone="good" />
        </InsightLayer>

        {err && <FeedbackLayer type="danger" title={t('operation_failed')} detail={err} />}

        {loading ? <Skeleton lines={5} /> : (
          <SmartTable
            columns={[t('name'), t('mobile'), t('source'), t('status'), t('actions')]}
            rows={leads}
            emptyTitle={t('no_leads_found')}
            emptyDescription={t('track_journey_desc')}
            renderRow={(l) => (
              <tr key={l.id}>
                <td>{l.name}</td>
                <td>{l.mobile || l.phone || '—'}</td>
                <td>{t('source_' + (l.source || '').toLowerCase()) || l.source || '—'}</td>
                <td><span className={`badge ${l.status === 'CONVERTED' ? 'badge-active' : 'badge-soon'}`}>{t(l.status.toLowerCase()) || l.status}</span></td>
                <td>
                  <span className="row-actions inline-flex gap-2">
                    <button className="btn-ghost btn-sm" onClick={() => setForm(l)}>{t('edit')}</button>
                  </span>
                </td>
              </tr>
            )}
          />
        )}
      </ProductPage>

      {form && (
        <ModalPortal>
        <div className="fixed inset-0 bg-black/70 grid place-items-center p-5 z-50" onClick={() => setForm(null)}>
          <form onClick={(e) => e.stopPropagation()} onSubmit={save} className="card card-static glass w-full max-w-lg">
            <h3 className="text-title text-white mb-4">{form.id ? t('edit_lead') : t('new_lead')}</h3>
            <div className="grid grid-cols-2 gap-3">
              <input className="input" placeholder={t('name')} value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
              <input className="input" placeholder={t('mobile')} value={form.mobile || form.phone || ''} onChange={(e) => setForm({ ...form, mobile: e.target.value })} />
              <input className="input" placeholder={t('email')} value={form.email || ''} onChange={(e) => setForm({ ...form, email: e.target.value })} />
              <select className="input" value={(form.source || 'WALK_IN').toUpperCase()} onChange={(e) => setForm({ ...form, source: e.target.value })}>
                {['WALK_IN', 'REFERRAL', 'SOCIAL_MEDIA', 'WEBSITE', 'WHATSAPP', 'INVITATION', 'OTHER'].map((s) => (
                  <option key={s} value={s}>{t('source_' + s.toLowerCase()) || s}</option>
                ))}
              </select>
              <select className="input" value={(form.status || 'NEW').toUpperCase()} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                <option value="NEW">{t('new')}</option>
                <option value="CONTACTED">{t('contacted') || 'Contacted'}</option>
                <option value="INTERESTED">{t('interested')}</option>
                <option value="TRIAL_BOOKED">{t('trial_booked') || 'Trial booked'}</option>
                <option value="TRIAL_COMPLETED">{t('trial_completed') || 'Trial completed'}</option>
                <option value="CONVERTED">{t('converted')}</option>
                <option value="LOST">{t('lost')}</option>
              </select>
              <textarea className="input col-span-2" placeholder={t('notes')} value={form.notes || ''} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
            </div>
            <div className="flex gap-2 justify-end mt-4">
              <button type="button" className="btn-ghost" onClick={() => setForm(null)}>{t('cancel')}</button>
              <button className="btn-primary">{t('save')}</button>
            </div>
          </form>
        </div>
        </ModalPortal>
      )}
    </Shell>
  );
}
