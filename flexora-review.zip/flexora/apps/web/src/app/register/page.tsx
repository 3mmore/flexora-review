'use client';
/**
 * FLEXORA Gym OS
 * © 2024 Ammar Allam. All rights reserved.
 * Unauthorized copying, distribution, or modification of this software
 * is strictly prohibited without written permission from the owner.
 * Contact: FLEXORA support
 */
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { auth } from '@/lib/api';
import { registerSchema } from '@/lib/schemas';
import { safeErrorMessage } from '@/lib/safe-error';
import { useTranslation } from '@/lib/i18n';

export default function Register() {
  const { t } = useTranslation();
  const router = useRouter();
  const [f, setF] = useState({ gymName: '', ownerName: '', email: '', password: '' });
  const [err, setErr] = useState('');
  const [loading, setLoading] = useState(false);
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr(''); setLoading(true);
    try { 
      const parsed = registerSchema.safeParse(f); 
      if (!parsed.success) { setErr(parsed.error.issues[0]?.message || t('invalid_form')); return; } 
      await auth.register(f.gymName, f.ownerName, f.email, f.password);
      try { sessionStorage.setItem('flexora-brand-refresh', '1'); } catch { /* noop */ }
      // REGRESSION FIX (P0 demo-data leak): a fresh signup must NEVER inherit
      // a previous session's onboarding draft (which in older builds contained
      // the seeded demo branches/plans). Wipe it before the wizard starts.
      try { localStorage.removeItem('flexora_onboarding_progress'); } catch { /* noop */ }
      router.replace('/onboarding');
    }
    catch (e: unknown) { setErr(safeErrorMessage(e)); } finally { setLoading(false); }
  }
  return (
    <div className="min-h-screen grid place-items-center p-5">
      <form onSubmit={submit} className="card w-full max-w-md">
        <h1 className="text-center text-2xl font-extrabold mb-1">{t('create_your_gym')}</h1>
        <p className="text-center text-[var(--muted)] text-sm mb-5">{t('trial_14_days')}</p>
        {err && <div className="text-red-400 text-sm mb-3">{err}</div>}
        <input className="input mb-3" placeholder={t('gym_name_placeholder')} value={f.gymName} onChange={set('gymName')} />
        <input className="input mb-3" placeholder={t('your_name_placeholder')} value={f.ownerName} onChange={set('ownerName')} />
        <input className="input mb-3" placeholder={t('email')} type="email" value={f.email} onChange={set('email')} />
        <input className="input mb-4" placeholder={t('password_min_8')} type="password" value={f.password} onChange={set('password')} />
        <button className="btn w-full" disabled={loading}>{loading ? '...' : t('create_gym')}</button>
        <p className="text-center text-sm text-[var(--muted)] mt-4">{t('have_account')} <Link className="text-accent" href="/login">{t('sign_in')}</Link></p>
      </form>
    </div>
  );
}
