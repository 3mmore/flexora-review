'use client';
/**
 * FLEXORA Gym OS — Self-service check-in kiosk screen (P2)
 *
 * PUBLIC page (no login). The tablet opens:
 *   /checkin/kiosk?token=kio_…
 * The token identifies the registered device; every scanned/typed member code
 * is checked into the branch that device belongs to. Works with USB/Bluetooth
 * QR scanners (they type the code + Enter) or manual entry.
 */
import { Suspense, useCallback, useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'next/navigation';
// PACK 2, item 1/3: a refused check-in must SPEAK ARABIC at the door. The API
// sends a stable `translationKey` next to its English `message`; the dictionary
// turns it into «لا يمكن تسجيل الحضور — الاشتراك لم يبدأ بعد» instead of the
// English sentence the kiosk used to paint.
import { translateKey } from '@/lib/i18n';

const TOKEN_KEY = 'flexora_kiosk_token';

interface DeviceInfo { deviceName: string; gymName: string; branchId: string; branchName: string }
type Result =
  | { kind: 'ok'; name: string; status: string; planName?: string | null; branchName: string; at: string }
  | { kind: 'error'; message: string };

async function kioskFetch(path: string, token: string, init?: RequestInit) {
  const res = await fetch(`/api${path}`, {
    ...init,
    headers: { 'x-device-token': token, 'Content-Type': 'application/json', ...(init?.headers || {}) },
    credentials: 'same-origin',
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    const msg = Array.isArray(body.message) ? body.message.join(', ') : (body.message || `HTTP ${res.status}`);
    const err = new Error(String(msg)) as Error & { translationKey?: string; code?: string };
    // The API's structured refusal: the kiosk shows the Arabic sentence and
    // keeps the machine code for the device log / support call.
    if (typeof body.translationKey === 'string') err.translationKey = body.translationKey;
    if (typeof body.code === 'string') err.code = body.code;
    throw err;
  }
  return body;
}

function KioskScreen() {
  const params = useSearchParams();
  const [token, setToken] = useState<string>(() => params.get('token') || (typeof window !== 'undefined' ? localStorage.getItem(TOKEN_KEY) || '' : ''));
  const [device, setDevice] = useState<DeviceInfo | null>(null);
  const [fatal, setFatal] = useState('');
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const clearTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Persist token on this tablet so a refresh keeps it signed in.
  useEffect(() => {
    const t = params.get('token');
    if (t) { setToken(t); try { localStorage.setItem(TOKEN_KEY, t); } catch { /* ignore */ } }
  }, [params]);

  const connect = useCallback(async () => {
    if (!token) return;
    setFatal('');
    try {
      const info = await kioskFetch('/kiosk/device', token);
      setDevice(info);
    } catch (e: unknown) {
      setDevice(null);
      setFatal(e instanceof Error ? e.message : 'Connection failed');
    }
  }, [token]);

  useEffect(() => { connect(); }, [connect]);
  useEffect(() => { inputRef.current?.focus(); }, [device, result]);

  async function submit(nextCode?: string) {
    const value = (nextCode ?? code).trim();
    if (!value || busy || !device) return;
    setBusy(true);
    setResult(null);
    try {
      const res = await kioskFetch('/kiosk/checkin', token, { method: 'POST', body: JSON.stringify({ code: value }) });
      setResult({ kind: 'ok', name: res.member?.name || value, status: res.member?.status || 'active', planName: res.member?.planName, branchName: res.branchName, at: res.at });
    } catch (e: unknown) {
      const key = (e as { translationKey?: string })?.translationKey;
      const arabic = key ? translateKey(key) : '';
      setResult({
        kind: 'error',
        // translateKey returns the key itself when it is unknown, so an
        // untranslated refusal degrades to the server sentence, never to a
        // raw key on screen.
        message: arabic && arabic !== key ? arabic : (e instanceof Error ? e.message : 'تعذّر تسجيل الحضور'),
      });
    } finally {
      setBusy(false);
      setCode('');
      if (clearTimer.current) clearTimeout(clearTimer.current);
      clearTimer.current = setTimeout(() => setResult(null), 6000);
      inputRef.current?.focus();
    }
  }

  if (!token) {
    return (
      <main dir="rtl" className="min-h-screen bg-[#0b0d12] text-white grid place-items-center p-6">
        <div className="text-center max-w-md">
          <h1 className="text-2xl font-black mb-2">جهاز تسجيل الحضور الذاتي</h1>
          <p className="text-white/60 text-sm">لا يوجد رمز جهاز. افتح هذه الشاشة من رابط الجهاز الذي يظهر في صفحة «تسجيل الحضور».</p>
        </div>
      </main>
    );
  }

  return (
    <main dir="rtl" className="min-h-screen bg-[#0b0d12] text-white flex flex-col">
      {/* Header: gym + branch of THIS device */}
      <header className="flex items-center justify-between px-6 py-4 border-b border-white/10">
        <div>
          <div className="text-xl font-black text-[var(--brand)]">{device?.gymName || '…'}</div>
          <div className="text-sm text-white/60">{device ? `${device.branchName} • ${device.deviceName}` : 'جارٍ الاتصال…'}</div>
        </div>
        <div className={`w-3 h-3 rounded-full ${device ? 'bg-green-400' : fatal ? 'bg-red-500' : 'bg-amber-400'}`} />
      </header>

      <section className="flex-1 grid place-items-center p-6">
        {fatal ? (
          <div className="text-center max-w-md">
            <div className="text-6xl mb-4">⛔</div>
            <h2 className="text-2xl font-bold mb-2">تعذّر الاتصال</h2>
            <p className="text-white/60 mb-4">{fatal}</p>
            <button className="px-6 py-3 rounded-xl bg-[var(--brand)] text-black font-bold" onClick={connect}>إعادة المحاولة</button>
          </div>
        ) : (
          <div className="w-full max-w-lg text-center">
            <div className="text-7xl mb-6">📷</div>
            <h1 className="text-3xl font-black mb-2">امسح كود العضو</h1>
            <p className="text-white/60 mb-6">وجّه كاميرا الماسح نحو كود QR الخاص بالعضو، أو اكتب الكود يدوياً ثم اضغط Enter.</p>
            <form onSubmit={(e) => { e.preventDefault(); submit(); }} className="flex gap-2">
              <input
                ref={inputRef}
                autoFocus
                dir="ltr"
                className="flex-1 rounded-xl bg-black/50 border border-white/20 px-4 py-4 text-xl font-mono focus:border-[var(--brand)] outline-none"
                placeholder="MEMBER CODE"
                value={code}
                onChange={(e) => setCode(e.target.value)}
              />
              <button type="submit" disabled={busy || !code.trim()} className="px-6 py-4 rounded-xl bg-[var(--brand)] text-black font-bold disabled:opacity-40">
                {busy ? '…' : 'تسجيل'}
              </button>
            </form>
          </div>
        )}
      </section>

      {/* Result overlay */}
      {result && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/80 p-6">
          {result.kind === 'ok' ? (
            <div className="text-center max-w-md">
              <div className="text-8xl mb-4">✅</div>
              <h2 className="text-4xl font-black mb-2">{result.name}</h2>
              <p className="text-xl text-green-300 mb-1">تم تسجيل الحضور</p>
              <p className="text-white/60">{result.branchName}{result.planName ? ` • ${result.planName}` : ''}</p>
              <p className="text-white/40 text-sm mt-2">{new Date(result.at).toLocaleTimeString()}</p>
            </div>
          ) : (
            <div className="text-center max-w-md">
              <div className="text-8xl mb-4">⛔</div>
              <h2 className="text-3xl font-black mb-2 text-red-300">غير مسموح</h2>
              <p className="text-white/70">{result.message}</p>
            </div>
          )}
        </div>
      )}
    </main>
  );
}

export default function KioskPage() {
  return (
    <Suspense fallback={<main className="min-h-screen bg-[#0b0d12] grid place-items-center text-white/60">…</main>}>
      <KioskScreen />
    </Suspense>
  );
}
