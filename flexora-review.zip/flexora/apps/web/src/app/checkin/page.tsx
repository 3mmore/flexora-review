'use client';
/**
 * FLEXORA Gym OS — Check-in
 *
 * Real self-service QR check-in (P2): gym staff register kiosk DEVICES here —
 * each device belongs to ONE branch, authenticates with its own secret token
 * (sent as the x-device-token header by the kiosk screen), and every scan is
 * recorded as attendance at that branch. The kiosk itself runs at
 * /checkin/kiosk?token=<token> — open that URL on the branch's tablet.
 */
import { useCallback, useEffect, useState } from 'react';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { useTranslation } from '@/lib/i18n';
import { FeedbackLayer, ProductPage, SmartTable } from '@/components/ProductOS';
import { Card } from '@/components/ui/Card';
import { Skeleton } from '@/components/ui/States';
import { safeErrorMessage } from '@/lib/safe-error';
import { useBranchScope } from '@/lib/branch-scope';

interface KioskDevice {
  id: string;
  name: string;
  branchId: string;
  token: string; // masked in list responses
  active: boolean;
  lastSeenAt?: string | null;
  branch?: { id: string; name: string };
}

export default function CheckinPage() {
  const { t } = useTranslation();
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');
  const [success, setSuccess] = useState('');

  const [devices, setDevices] = useState<KioskDevice[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [devicesLoading, setDevicesLoading] = useState(true);
  const [form, setForm] = useState<{ name: string; branchId: string } | null>(null);
  const [newToken, setNewToken] = useState<{ deviceName: string; token: string } | null>(null);
  const [copied, setCopied] = useState('');

  /**
   * PHASE 4: kiosk DEVICES are an OWNER/MANAGER capability. `/kiosk/devices*` is
   * guarded by @Roles('OWNER','MANAGER') — a Reception or Coach account gets a
   * hard 403 from the API, so the page must not even ask. Restricted staff keep
   * the recent-check-ins feed (their own branch only, scoped by the API) and see
   * which branch they are looking at instead of a device manager.
   */
  const scope = useBranchScope();

  const flash = (msg: string) => { setSuccess(msg); setTimeout(() => setSuccess(''), 3500); };

  const load = useCallback(async () => {
    setLoading(true); setErr('');
    try {
      const data = await api<any>('/attendance?limit=50');
      setRows(Array.isArray(data) ? data : (data.items || []));
    } catch (e: unknown) { setErr(safeErrorMessage(e)); }
    finally { setLoading(false); }
  }, []);

  const loadDevices = useCallback(async () => {
    if (scope.loading) return;
    // Restricted roles: never call the OWNER/MANAGER-only endpoint.
    if (!scope.unrestricted) {
      setDevices([]);
      setDevicesLoading(false);
      return;
    }
    setDevicesLoading(true);
    try {
      const [d, b] = await Promise.all([
        api<KioskDevice[]>('/kiosk/devices'),
        api<any>('/branches').then((res) => (Array.isArray(res) ? res : (res.items || []))).catch(() => []),
      ]);
      setDevices(d); setBranches(b);
    } catch (e: unknown) { setErr(safeErrorMessage(e)); }
    finally { setDevicesLoading(false); }
  }, [scope.loading, scope.unrestricted]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { loadDevices(); }, [loadDevices]);

  async function createDevice(e: React.FormEvent) {
    e.preventDefault();
    if (!form) return;
    setErr('');
    try {
      const created = await api<KioskDevice & { token: string }>('/kiosk/devices', {
        method: 'POST', body: JSON.stringify(form),
      });
      setForm(null);
      setNewToken({ deviceName: created.name, token: created.token });
      await loadDevices();
    } catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }

  async function toggleActive(d: KioskDevice) {
    setErr('');
    try {
      await api(`/kiosk/devices/${d.id}`, { method: 'PATCH', body: JSON.stringify({ active: !d.active }) });
      flash(t('saved') || 'Saved');
      await loadDevices();
    } catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }

  async function removeDevice(d: KioskDevice) {
    if (!confirm(t('confirm_delete') || 'Delete?')) return;
    setErr('');
    try {
      await api(`/kiosk/devices/${d.id}`, { method: 'DELETE' });
      await loadDevices();
    } catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }

  async function rotate(d: KioskDevice) {
    if (!confirm(t('rotate_token_confirm') || 'Replace this device token? The old token stops working immediately.')) return;
    setErr('');
    try {
      const res = await api<{ token: string }>(`/kiosk/devices/${d.id}/rotate-token`, { method: 'POST' });
      setNewToken({ deviceName: d.name, token: res.token });
      await loadDevices();
    } catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }

  const kioskUrl = (token: string) => `${typeof window !== 'undefined' ? window.location.origin : ''}/checkin/kiosk?token=${token}`;

  async function copy(text: string, which: string) {
    try { await navigator.clipboard.writeText(text); setCopied(which); setTimeout(() => setCopied(''), 2000); } catch { /* ignore */ }
  }

  return (
    <Shell>
      <ProductPage eyebrow={t('qr_checkin')} title={t('qr_checkin')} narrative={t('kiosk_narrative') || 'Self-service check-in devices: each tablet is bound to one branch and signs every scan into that branch automatically.'}>
        {err && <FeedbackLayer type="danger" title={t('operation_failed')} detail={err} />}
        {success && <div className="text-green-400 text-sm mb-3">{success}</div>}

        {/* Freshly created/rotated token — shown ONCE */}
        {newToken && (
          <Card padding="lg" className="mb-6 border-amber-400/40">
            <h2 className="font-bold mb-1">{t('device_created_title') || `Device "${newToken.deviceName}" — token`}</h2>
            <p className="text-xs text-amber-400/90 mb-3">⚠️ {t('device_token_once')}</p>
            <code dir="ltr" className="block rounded-lg border border-[var(--border)] bg-black/40 px-3 py-2 text-xs font-mono break-all">{newToken.token}</code>
            <div className="flex flex-wrap gap-2 mt-3">
              <button className="btn btn-secondary px-3 py-2 text-sm" onClick={() => copy(newToken.token, 'new-token')}>{copied === 'new-token' ? (t('copied') || '✓ Copied') : (t('copy') || 'Copy')}</button>
              <button className="btn btn-secondary px-3 py-2 text-sm" onClick={() => copy(kioskUrl(newToken.token), 'new-url')}>{copied === 'new-url' ? (t('copied') || '✓ Copied') : (t('copy_kiosk_url') || 'Copy kiosk URL')}</button>
              <button className="btn btn-ghost px-3 py-2 text-sm" onClick={() => setNewToken(null)}>{t('close') || 'Close'}</button>
            </div>
          </Card>
        )}

        {/* Devices — OWNER/MANAGER only (Phase 4) */}
        {!scope.loading && !scope.unrestricted && (
          <Card padding="lg" className="mb-6" data-testid="kiosk-branch-locked">
            <div className="product-section-head"><div><h2>{t('kiosk_devices') || 'Check-in devices'}</h2><p>{t('kiosk_devices_desc') || 'Each device checks members into the branch it is registered to.'}</p></div></div>
            <div className="badge badge-active mt-3" data-testid="kiosk-branch-locked-badge">
              {t('branch') || 'Branch'}: {scope.branchName || scope.branchId || '—'}
            </div>
            <p className="text-sm text-[var(--silver-dim)] mt-3">{t('kiosk_devices_owner_only') || 'Adding or managing check-in tablets is limited to owners and managers.'}</p>
          </Card>
        )}
        {scope.unrestricted && (
        <Card padding="lg" className="mb-6">
          <div className="product-section-head"><div><h2>{t('kiosk_devices') || 'Check-in devices'}</h2><p>{t('kiosk_devices_desc') || 'Each device checks members into the branch it is registered to.'}</p></div></div>
          {devicesLoading ? <Skeleton lines={3} /> : devices.length === 0 ? (
            <p className="text-sm text-[var(--silver-dim)] mt-3">{t('no_devices') || 'No devices yet — add the tablet at your entrance.'}</p>
          ) : (
            <div className="overflow-x-auto mt-3">
              <table className="table w-full text-sm">
                <thead><tr className="text-left text-xs uppercase text-[var(--silver-dim)]">
                  <th className="py-2">{t('name')}</th><th>{t('branch')}</th><th>{t('status')}</th><th>{t('token') || 'Token'}</th><th>{t('last_seen') || 'Last seen'}</th><th>{t('actions')}</th>
                </tr></thead>
                <tbody>
                  {devices.map((d) => (
                    <tr key={d.id} className="border-t border-[var(--border)]">
                      <td className="py-2 font-medium">{d.name}</td>
                      <td>{d.branch?.name || '—'}</td>
                      <td>{d.active ? <span className="text-green-400">{t('active')}</span> : <span className="text-red-400">{t('inactive') || 'Inactive'}</span>}</td>
                      <td dir="ltr"><code className="text-xs font-mono">{d.token}</code></td>
                      <td className="text-xs text-[var(--silver-dim)]">{d.lastSeenAt ? new Date(d.lastSeenAt).toLocaleString() : (t('never') || 'Never')}</td>
                      <td>
                        <div className="flex flex-wrap gap-1">
                          <button className="btn btn-ghost px-2 py-1 text-xs" onClick={() => toggleActive(d)}>{d.active ? (t('deactivate') || 'Deactivate') : (t('activate') || 'Activate')}</button>
                          <button className="btn btn-ghost px-2 py-1 text-xs" onClick={() => rotate(d)}>{t('rotate_token') || 'Rotate token'}</button>
                          <button className="btn btn-ghost px-2 py-1 text-xs text-red-400" onClick={() => removeDevice(d)}>{t('delete')}</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {!form ? (
            <button className="btn btn-primary px-4 py-2 mt-4" onClick={() => setForm({ name: '', branchId: branches[0]?.id || '' })}>{t('add_device') || 'Add device'}</button>
          ) : (
            <form onSubmit={createDevice} className="mt-4 flex flex-wrap items-end gap-3">
              <label className="text-xs text-[var(--silver-dim)]">
                {t('device_name') || 'Device name'}
                <input className="input block mt-1" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder={t('device_name_ph') || 'Entrance tablet'} required minLength={2} />
              </label>
              <label className="text-xs text-[var(--silver-dim)]">
                {t('branch')}
                <select className="input block mt-1" value={form.branchId} onChange={(e) => setForm({ ...form, branchId: e.target.value })} required>
                  {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
                </select>
              </label>
              <button type="submit" className="btn btn-primary px-4 py-2">{t('create') || 'Create'}</button>
              <button type="button" className="btn btn-ghost px-4 py-2" onClick={() => setForm(null)}>{t('cancel')}</button>
            </form>
          )}
        </Card>
        )}

        {/* Recent check-ins */}
        <h2 className="text-lg font-bold mb-3">{t('recent_traffic')}</h2>
        {loading ? <Skeleton lines={6} /> : (
          <SmartTable
            columns={[t('member'), t('branch'), t('date'), t('method'), t('by') || 'By']}
            rows={rows}
            emptyTitle={t('no_checkins_yet') || 'No check-ins yet'}
            emptyDescription={t('checkins_will_appear') || 'Member check-ins will appear here.'}
            renderRow={(r) => (
              <tr key={r.id}>
                <td>{r.member?.name || r.memberId?.slice(0, 8) || '—'}</td>
                <td>{r.branch?.name || '—'}</td>
                <td>{r.at ? new Date(r.at).toLocaleString() : '—'}</td>
                <td>{r.method || '—'}</td>
                <td className="text-xs">{r.staffName || '—'}</td>
              </tr>
            )}
          />
        )}
      </ProductPage>
    </Shell>
  );
}
