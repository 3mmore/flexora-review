/**
 * FLEXORA Gym OS — Executive Insights Center
 * Reports redesigned from chart collection into management decision intelligence.
 */
'use client';
import { useEffect, useMemo, useState } from 'react';
import { formatDate } from '@/lib/dates';
import Link from 'next/link';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { ActionCenter, FeedbackLayer, InsightCard, InsightLayer, ProductPage, SmartAction } from '@/components/ProductOS';
import { Card } from '@/components/ui/Card';
import { EmptyState, Skeleton } from '@/components/ui/States';
import { Icon } from '@/components/brand/Icon';
import { useTranslation } from '@/lib/i18n';
import { fmtMoney } from '@/lib/money';
import { useBranchScope } from '@/lib/branch-scope';

type Dashboard = {
  revenueToday: number;
  revenueMonth: number;
  expensesToday: number;
  netProfit: number;
  activeMembers: number;
  expiringMembers: number;
  checkinsToday: number;
  totalMembers: number;
};

type Membership = { active: number; expired: number; total: number; renewalRate: number };
type RevenuePoint = { month: string; value: number };
type PeakHour = { hour: number; count: number };
type Branch = { id: string; name: string; stats?: { members?: number; staff?: number; revenue?: number } };
type LowStock = { id: string; name: string; qty: number; lowAlert: number };
type ProductStats = { inventoryValue?: number; lowStock?: LowStock[]; bestSellers?: Array<{ name: string; _sum?: { qty?: number } }> };
type Sale = { id: string; invoiceNo?: string; total?: number | string; createdAt?: string; userName?: string };

const money = (value?: number | string) => fmtMoney(value);
const pct = (current = 0, previous = 0) => previous <= 0 ? (current > 0 ? 100 : 0) : Math.round(((current - previous) / previous) * 100);
const hour = (h: number) => `${String(h).padStart(2, '0')}:00`;

function MiniBars({ data, valueKey = 'value' }: { data: Record<string, any>[]; valueKey?: string }) {
  const { t } = useTranslation();
  const max = Math.max(1, ...data.map((d) => Number(d[valueKey] || 0)));
  if (!data.length) return <EmptyState icon="chart" title={t('no_trend_data')} description={t('reports_richer_desc')} />;
  return (
    <div className="report-bars" role="img" aria-label={t('chart_trend_bars')}>
      {data.map((d, i) => <div key={d.month ?? d.hour ?? i}><i style={{ height: `${Math.max(5, (Number(d[valueKey] || 0) / max) * 100)}%` }} /><span>{d.month?.slice(5) ?? (i % 3 === 0 ? d.hour : '')}</span></div>)}
    </div>
  );
}

function StoryCard({ title, state, trend, risk, opportunity, action, href }: { title: string; state: string; trend: string; risk: string; opportunity: string; action: string; href: string }) {
  const { t } = useTranslation();
  return (
    <Card padding="lg" className="report-story-card">
      <div className="product-section-head"><div><h2>{title}</h2><p>{state}</p></div><Icon name="sparkle" size={17} className="text-[var(--primary)]" /></div>
      <div className="report-story-grid">
        <div><span>{t('trend')}</span><b>{trend}</b></div>
        <div><span>{t('risk')}</span><b>{risk}</b></div>
        <div><span>{t('opportunity')}</span><b>{opportunity}</b></div>
      </div>
      <Link href={href} className="btn btn-secondary mt-4 w-full justify-center px-4 py-2 text-sm">{action}<Icon name="arrow-right" size={12} /></Link>
    </Card>
  );
}

function BranchPerformance({ branches }: { branches: Branch[] }) {
  const { t } = useTranslation();
  if (!branches.length) return <EmptyState icon="home" title={t('no_branch_perf')} description={t('add_branches_compare')} />;
  const sorted = [...branches].sort((a, b) => Number(b.stats?.revenue || 0) - Number(a.stats?.revenue || 0));
  const best = sorted[0];
  const attention = sorted[sorted.length - 1];
  const max = Math.max(1, ...sorted.map((b) => Number(b.stats?.revenue || 0)));
  return (
    <div className="branch-performance">
      <div className="branch-performance-summary">
        <span className="opportunity-signal">{t('best')}: {best?.name}</span>
        <span className="risk-indicator" data-level="medium">{t('need_attention')}: {attention?.name}</span>
      </div>
      {sorted.slice(0, 6).map((b) => (
        <div key={b.id} className="branch-performance-row">
          <div><b>{b.name}</b><span>{b.stats?.members || 0} {t('members')} · {b.stats?.staff || 0} {t('staff')}</span></div>
          <div className="branch-performance-meter"><i style={{ width: `${Math.max(6, (Number(b.stats?.revenue || 0) / max) * 100)}%` }} /></div>
          <strong>{money(b.stats?.revenue || 0)}</strong>
        </div>
      ))}
    </div>
  );
}

/** Local {name} interpolation — the i18n t() in this codebase takes no placeholders. */
function fill(template: string, vars: Record<string, string>): string {
  return template.replace(/\{(\w+)\}/g, (_, k) => vars[k] ?? '');
}

export default function ExecutiveInsightsCenter() {
  const { t, lang } = useTranslation();
  const [dashboard, setDashboard] = useState<Dashboard | null>(null);
  const [revenue, setRevenue] = useState<RevenuePoint[]>([]);
  const [membership, setMembership] = useState<Membership | null>(null);
  const [peak, setPeak] = useState<PeakHour[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [lowStock, setLowStock] = useState<LowStock[]>([]);
  const [productStats, setProductStats] = useState<ProductStats | null>(null);
  const [sales, setSales] = useState<Sale[]>([]);
  const [busy, setBusy] = useState(true);

  /** PHASE 4: restricted roles get their own branch back from /branches. */
  const scope = useBranchScope();
  const [err, setErr] = useState('');

  async function load() {
    setBusy(true);
    setErr('');
    try {
      const [d, r, m, p, b, low, ps, s] = await Promise.all([
        api<Dashboard>('/reports/dashboard').catch(() => null),
        api<RevenuePoint[]>('/reports/revenue-by-month').catch(() => []),
        api<Membership>('/reports/membership-analytics').catch(() => null),
        api<PeakHour[]>('/reports/peak-hours').catch(() => []),
        api<Branch[]>('/branches').catch(() => []),
        api<LowStock[]>('/inventory/low-stock').catch(() => []),
        api<ProductStats>('/products/stats').catch(() => null),
        api<{ items: Sale[] }>('/sales?limit=20').then((res) => res.items || []),
      ]);
      setDashboard(d); setRevenue(r); setMembership(m); setPeak(p); setBranches(b); setLowStock(low); setProductStats(ps); setSales(s);
    } catch (e: unknown) {
      setErr((e as Error).message || t('operation_failed'));
    } finally {
      setBusy(false);
    }
  }
  useEffect(() => { load(); }, []);

  const currentRevenue = revenue.at(-1)?.value || dashboard?.revenueMonth || 0;
  const previousRevenue = revenue.at(-2)?.value || 0;
  const growthRate = pct(currentRevenue, previousRevenue);
  const trendText = growthRate > 8 ? t('growing') : growthRate < -8 ? t('declining') : t('stable');
  const revenueVelocity = revenue.length ? Math.round(revenue.slice(-3).reduce((s, p) => s + p.value, 0) / Math.min(3, revenue.length)) : 0;
  const forecast = Math.max(0, Math.round(currentRevenue * (1 + growthRate / 100)));
  const retentionHealth = membership ? Math.round((membership.active / Math.max(membership.total, 1)) * 100) : 0;
  const churnRisk = (dashboard?.expiringMembers || 0) + (membership?.expired || 0);
  const peakHour = peak.length ? peak.slice().sort((a, b) => b.count - a.count)[0] : null;
  const quietHour = peak.length ? peak.slice().sort((a, b) => a.count - b.count)[0] : null;
  const avgSale = sales.length ? sales.reduce((sum, sale) => sum + Number(sale.total || 0), 0) / sales.length : 0;
  const ltvProxy = membership?.total ? Math.round((dashboard?.revenueMonth || 0) / Math.max(membership.total, 1)) : 0;
  const inventoryRisk = lowStock.length || productStats?.lowStock?.length || 0;
  const bestBranch = [...branches].sort((a, b) => Number(b.stats?.revenue || 0) - Number(a.stats?.revenue || 0))[0];
  const attentionBranch = [...branches].sort((a, b) => Number(a.stats?.revenue || 0) - Number(b.stats?.revenue || 0))[0];

  const aiBrief = useMemo(() => {
    const biggestRisk = churnRisk > 0 ? `${churnRisk} ${t('need_attention')}` : inventoryRisk > 0 ? `${inventoryRisk} ${t('low_stock')}` : t('no_risk');
    const biggestOpportunity = growthRate > 8 ? t('revenue_momentum') : retentionHealth > 80 ? t('strong_retention') : t('focus_recovery');
    return {
      // Before: the sentence was three English fragments glued with the grammar
      // connector key, which cannot produce correct Arabic word order.
      // One key,
      // filled locally (t() takes no placeholders in this codebase).
      keyInsight: fill(t('reports_insight_sentence'), { trend: trendText, rate: String(retentionHealth) }),
      biggestRisk,
      biggestOpportunity,
    };
  }, [trendText, retentionHealth, churnRisk, inventoryRisk, growthRate, t]);

  const timeline = [
    ...sales.slice(0, 8).map((sale) => ({ id: `sale-${sale.id}`, type: t('revenue_label'), title: sale.invoiceNo || t('invoice'), detail: money(sale.total), at: sale.createdAt || new Date().toISOString() })),
  ].sort((a, b) => +new Date(b.at) - +new Date(a.at));

  return (
    <Shell>
      <ProductPage
        eyebrow={t('executive_insights')}
        title={t('business_truth_title')}
        narrative={t('reports_description')}
        primaryAction={{ label: t('risk_risks'), href: churnRisk ? '/members?status=expired' : '/inventory', icon: 'bell' }}
        secondaryAction={{ label: t('pos'), href: '/pos', icon: 'coins' }}
      >
        {err && <FeedbackLayer type="danger" title={t('operation_failed')} detail={err} action={<button className="btn btn-ghost px-3 py-1.5 text-xs" onClick={load}>{t('retry')}</button>} />}

        <Card variant="glow" padding="lg" className="reports-briefing-card">
          <div className="product-section-head"><div><span className="product-eyebrow">{t('executive_summary')}</span><h2>{t('what_changed_why')}</h2><p>{aiBrief.keyInsight}</p></div><Icon name="sparkle" className="text-[var(--primary)]" size={20} /></div>
          {busy ? <Skeleton lines={7} /> : <div className="reports-briefing-grid">
            <div><span>{t('revenue_trajectory')}</span><b>{fill(t('reports_revenue_trend'), { trend: trendText })}</b></div>
            <div><span>{t('retention')}</span><b>{retentionHealth}% {t('active')}</b></div>
            <div><span>{t('inventory_health')}</span><b>{inventoryRisk ? `${inventoryRisk} ${t('risk')}` : t('stable')}</b></div>
            <div><span>{t('branch_performance')}</span><b>{bestBranch?.name || t('none')}</b></div>
          </div>}
        </Card>

        <InsightLayer>
          {busy ? <><Skeleton /><Skeleton /><Skeleton /><Skeleton /></> : <>
            <InsightCard label={t('revenue')} value={money(currentRevenue)} detail={`${t('forecast')} ${money(forecast)}`} icon="coins" />
            <InsightCard label={t('renewals')} value={dashboard?.expiringMembers || 0} detail={t('need_attention')} icon="bell" />
            <InsightCard label={t('attendance')} value={dashboard?.checkinsToday || 0} detail={peakHour ? `${t('peak_hour')} ${hour(peakHour.hour)}` : ''} icon="users" />
            <InsightCard label={t('retention')} value={`${retentionHealth}%`} detail={`${t('st_expired')}: ${membership?.expired || 0}`} icon="shield" />
          </>}
        </InsightLayer>

        <ActionCenter title={t('actions_column')}>
          <SmartAction title={t('risk_risks')} detail={aiBrief.biggestRisk} href={churnRisk ? '/members?status=expired' : '/inventory'} icon="bell" />
          <SmartAction title={t('pos')} detail={t('move_fast_stock')} href="/pos" icon="coins" />
          <SmartAction title={t('members')} detail={t('search_members')} href="/members" icon="users" />
          <SmartAction title={t('attendance')} detail={t('review_attendance')} href="/attendance" icon="home" />
        </ActionCenter>

        <section className="reports-story-grid">
          <StoryCard title={t('revenue_label')} state={`${fill(t('reports_revenue_trend'), { trend: trendText })}.`} trend={`${growthRate}%`} risk={growthRate < 0 ? t('revenue_decline') : t('none')} opportunity={aiBrief.biggestOpportunity} action={t('pos')} href="/pos" />
          <StoryCard title={t('retention')} state={`${retentionHealth}% ${t('active')}.`} trend={`${dashboard?.expiringMembers || 0} ${t('expiring_soon')}`} risk={churnRisk ? `${churnRisk} ${t('risk')}` : t('none')} opportunity={t('recover_renewals')} action={t('review_renewals')} href="/members?status=expired" />
        </section>

        <section className="reports-intelligence-grid">
          <Card padding="lg">
            <div className="product-section-head"><div><h2>{t('revenue_intelligence')}</h2></div></div>
            {busy ? <Skeleton lines={7} /> : <><MiniBars data={revenue} /><div className="reports-narrative"><b>{fill(t('reports_revenue_trend'), { trend: trendText })}.</b></div></>}
          </Card>

          <Card padding="lg">
            <div className="product-section-head"><div><h2>{t('retention_intelligence')}</h2></div></div>
            {busy || !membership ? <Skeleton lines={7} /> : <div className="reports-facts"><div><span>{t('active')}</span><b>{membership.active}</b></div><div><span>{t('st_expired')}</span><b>{membership.expired}</b></div><div><span>{t('renewal_rate')}</span><b>{membership.renewalRate}%</b></div></div>}
          </Card>

          <Card padding="lg">
            <div className="product-section-head"><div><h2>{t('attendance_intelligence')}</h2></div></div>
            {busy ? <Skeleton lines={7} /> : <><MiniBars data={peak} valueKey="count" /><div className="reports-narrative"><b>{peakHour ? `${t('most_popular')} ${hour(peakHour.hour)}.` : ''}</b></div></>}
          </Card>
        </section>

        <Card padding="lg">
          <div className="product-section-head"><div><h2>{t('branch_performance_center')}</h2></div></div>
          {!scope.unrestricted && !scope.loading && (
            <div className="badge badge-active mb-4" data-testid="reports-branch-locked">
              {t('branch') || 'Branch'}: {scope.branchName || branches[0]?.name || '—'}
            </div>
          )}
          {busy ? <Skeleton lines={8} /> : <BranchPerformance branches={branches} />}
        </Card>

        <Card padding="lg">
          <div className="product-section-head"><div><h2>{t('executive_timeline')}</h2></div></div>
          {busy ? <Skeleton lines={8} /> : timeline.length ? <div className="reports-timeline">{timeline.map((item) => <div key={item.id}><div><span>{item.type}</span><b>{item.title}</b></div><time>{formatDate(item.at)}</time></div>)}</div> : <EmptyState icon="bell" title={t('no_timeline_yet')} description={t('activity_real_time')} />}
        </Card>
      </ProductPage>
    </Shell>
  );
}
