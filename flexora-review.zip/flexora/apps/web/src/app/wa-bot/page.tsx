"use client";
/**
 * FLEXORA Gym OS — WhatsApp AI Bot Settings
 * © 2024 Ammar Allam. All rights reserved.
 * WhatsApp Support: FLEXORA support
 */
import { useEffect, useMemo, useState } from "react";
import Shell from "@/components/Shell";
import { api, auth } from "@/lib/api";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { EmptyState, Skeleton } from "@/components/ui/States";
import { safeErrorMessage } from '@/lib/safe-error';
import { useTranslation } from "@/lib/i18n";

type Settings = {
  waBotEnabled?: boolean;
  waBotPhoneId?: string | null;
  waBotToken?: string | null;
  waBotGreeting?: string | null;
  waBotLanguage?: string;
};

type Stats = {
  totalConversations: number;
  totalMessages: number;
  todayMessages: number;
  membersContacted?: number;
  responseRate?: string;
  recentConversations: Array<{
    id: string;
    memberPhone: string;
    lastMessageAt: string;
    member?: { name?: string } | null;
    messages: Array<{
      id: string;
      direction: "INBOUND" | "OUTBOUND";
      content: string;
      createdAt: string;
    }>;
  }>;
};

export default function WaBotPage() {
  const { t, lang } = useTranslation();
  const [settings, setSettings] = useState<Settings>({ waBotLanguage: "ar" });
  const [stats, setStats] = useState<Stats | null>(null);
  const [verifyToken, setVerifyToken] = useState("");
  const [expanded, setExpanded] = useState<string | null>(null);
  const [testPhone, setTestPhone] = useState("");
  const [testMessage, setTestMessage] = useState("كام جلسة باقيلي؟");
  const [testReply, setTestReply] = useState("");
  const [busy, setBusy] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [err, setErr] = useState("");

  const gymId = useMemo(() => (auth.user() as { gymId?: string })?.gymId || "", []);

  async function load() {
    setBusy(true);
    setErr("");
    try {
      const [s, st] = await Promise.all([
        api<Settings>("/wa-bot/settings"),
        api<Stats>("/wa-bot/stats").catch(() => null),
      ]);
      setSettings({ waBotLanguage: "ar", ...s });
      if (st) setStats(st);
      if (gymId) {
        const token = await api<{ verifyToken: string }>(
          `/wa-bot/verify-token/${gymId}`,
        ).catch(() => null);
        if (token && (token as { verifyToken: string }).verifyToken) setVerifyToken((token as { verifyToken: string }).verifyToken);
      }
    } catch (e: unknown) {
      setErr((e as Error).message || t('operation_failed'));
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function save() {
    setSaving(true);
    setErr("");
    try {
      await api("/wa-bot/settings", {
        method: "PATCH",
        body: JSON.stringify({
          enabled: !!settings.waBotEnabled,
          phoneId: settings.waBotPhoneId || "",
          token:
            settings.waBotToken && settings.waBotToken !== "••••••"
              ? settings.waBotToken
              : undefined,
          greeting: settings.waBotGreeting || "",
          language: settings.waBotLanguage || "ar",
        }),
      });
      await load();
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    } finally {
      setSaving(false);
    }
  }

  async function sendTest() {
    setTesting(true);
    setTestReply("");
    setErr("");
    try {
      const res = await api<{ reply: string }>("/wa-bot/test", {
        method: "POST",
        body: JSON.stringify({ phone: testPhone, message: testMessage }),
      });
      setTestReply(res.reply);
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    } finally {
      setTesting(false);
    }
  }

  const webhookUrl = `https://yourdomain.com/api/wa-bot/webhook/${gymId || "{gymId}"}`;

  return (
    <Shell>
      <div className="space-y-6">
        <section className="product-hero">
          <div>
            <div className="product-eyebrow">{t('whatsapp')}</div>
            <h1>{t('wa_bot_title')}</h1>
            <p>{t('bot_desc')}</p>
          </div>
        </section>

        {err && (
          <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-200">
            {err}
          </div>
        )}
        {busy ? (
          <Skeleton lines={10} />
        ) : (
          <>
            <Card padding="lg" variant="elevated">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <h2 className="text-xl font-extrabold text-white">
                    {t('bot_settings')}
                  </h2>
                  <p className="text-sm text-[var(--silver-dim)]">
                    {t('bot_config_desc')}
                  </p>
                </div>
                <label className="flex items-center gap-2 text-sm text-white">
                  <input
                    type="checkbox"
                    checked={!!settings.waBotEnabled}
                    onChange={(e) =>
                      setSettings((s) => ({
                        ...s,
                        waBotEnabled: e.target.checked,
                      }))
                    }
                  />{" "}
                  {t('enable')}
                </label>
              </div>

              {settings.waBotEnabled && (
                <div className="mt-6 grid gap-4 md:grid-cols-2">
                  <label className="space-y-2">
                    <span className="text-sm text-[var(--silver)]">
                      WhatsApp Phone Number ID
                    </span>
                    <input
                      className="input"
                      value={settings.waBotPhoneId || ""}
                      onChange={(e) =>
                        setSettings((s) => ({
                          ...s,
                          waBotPhoneId: e.target.value,
                        }))
                      }
                    />
                  </label>
                  <label className="space-y-2">
                    <span className="text-sm text-[var(--silver)]">
                      WhatsApp API Token
                    </span>
                    <input
                      className="input"
                      type="password"
                      placeholder="••••••"
                      onChange={(e) =>
                        setSettings((s) => ({
                          ...s,
                          waBotToken: e.target.value,
                        }))
                      }
                    />
                  </label>
                  <div className="space-y-2">
                    <span className="text-sm text-[var(--silver)]">
                      {t('bot_language')}
                    </span>
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant={
                          settings.waBotLanguage === "ar"
                            ? "primary"
                            : "secondary"
                        }
                        onClick={() =>
                          setSettings((s) => ({ ...s, waBotLanguage: "ar" }))
                        }
                      >
                        Arabic ✓
                      </Button>
                      <Button
                        type="button"
                        variant={
                          settings.waBotLanguage === "en"
                            ? "primary"
                            : "secondary"
                        }
                        onClick={() =>
                          setSettings((s) => ({ ...s, waBotLanguage: "en" }))
                        }
                      >
                        English
                      </Button>
                    </div>
                  </div>
                  <label className="space-y-2 md:col-span-2">
                    <span className="text-sm text-[var(--silver)]">
                      {t('custom_greeting')}
                    </span>
                    <textarea
                      className="input min-h-24"
                      value={settings.waBotGreeting || ""}
                      onChange={(e) =>
                        setSettings((s) => ({
                          ...s,
                          waBotGreeting: e.target.value,
                        }))
                      }
                    />
                  </label>
                </div>
              )}

              <div className="mt-6 rounded-2xl border border-cyan-400/25 bg-cyan-400/10 p-5 text-sm text-cyan-50">
                <b>📋 {t('setup_steps')}:</b>
                <ol className="mt-3 list-decimal space-y-1 pr-5">
                  <li>{t('step_facebook')}</li>
                  <li>{t('step_app')}</li>
                  <li>{t('step_copy')}</li>
                  <li>
                    {t('wa_webhook_url')}: <code dir="ltr">{webhookUrl}</code>
                  </li>
                  <li>
                    {t('wa_verify_token')}:{" "}
                    <code>
                      {verifyToken || `flexora_${gymId || "{gymId}"}_verify`}
                    </code>
                  </li>
                  <li>{t('wa_subscribe_to')}</li>
                </ol>
              </div>
              <Button className="mt-6" loading={saving} onClick={save}>
                {t('save')}
              </Button>
            </Card>

            {settings.waBotEnabled && stats && (
              <>
                <div className="grid gap-4 md:grid-cols-4">
                  <Mini
                    title={t('total_convs')}
                    value={stats.totalConversations}
                  />
                  <Mini title={t('today_msgs')} value={stats.todayMessages} />
                  <Mini
                    title={t('members_contacted')}
                    value={stats.membersContacted || 0}
                  />
                  <Mini
                    title={t('response_rate')}
                    value={stats.responseRate || "فوري ⚡"}
                  />
                </div>

                <Card padding="lg" title={t('recent_convs')}>
                  {stats.recentConversations.length ? (
                    <div className="space-y-3">
                      {stats.recentConversations.map((c) => (
                        <div key={c.id} className="rounded-xl bg-black/20 p-4">
                          <button
                            className="grid w-full grid-cols-4 text-sm"
                            onClick={() =>
                              setExpanded(expanded === c.id ? null : c.id)
                            }
                          >
                            <span className="font-bold">{c.member?.name || c.memberPhone}</span>
                            <span className="truncate">{c.messages[0]?.content || "—"}</span>
                            <span>
                              {new Date(c.lastMessageAt).toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-US')}
                            </span>
                            <span>{c.messages.length} {t('items')}</span>
                          </button>
                          {expanded === c.id && (
                            <div className="mt-4 space-y-2">
                              {c.messages
                                .slice()
                                .reverse()
                                .map((m) => (
                                  <div
                                    key={m.id}
                                    className={`flex ${m.direction === "INBOUND" ? "justify-end" : "justify-start"}`}
                                  >
                                    <div
                                      className={`max-w-[75%] rounded-2xl px-4 py-2 text-sm ${m.direction === "INBOUND" ? "bg-zinc-800 text-white" : "bg-cyan-500/20 text-cyan-50"}`}
                                    >
                                      {m.direction === "OUTBOUND" && "🤖 "}
                                      {m.content}
                                    </div>
                                  </div>
                                ))}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <EmptyState
                      icon="bell"
                      title={t('no_convs')}
                      description={t('incoming_msgs_desc')}
                    />
                  )}
                </Card>
              </>
            )}

            <Card padding="lg" title={t('test_bot')}>
              <div className="grid gap-3 md:grid-cols-2">
                <input
                  className="input"
                  placeholder={t('phone')}
                  value={testPhone}
                  onChange={(e) => setTestPhone(e.target.value)}
                />
                <input
                  className="input"
                  placeholder={t('memo')}
                  value={testMessage}
                  onChange={(e) => setTestMessage(e.target.value)}
                />
              </div>
              <Button className="mt-4" loading={testing} onClick={sendTest}>
                {t('send_test')}
              </Button>
              {testReply && (
                <div className="mt-4 rounded-2xl bg-cyan-500/20 p-4 text-cyan-50">
                  🤖 {testReply}
                </div>
              )}
            </Card>
          </>
        )}
      </div>
    </Shell>
  );
}

function Mini({ title, value }: { title: string; value: string | number }) {
  return (
    <Card padding="md">
      <div className="text-xs text-[var(--silver-dim)]">{title}</div>
      <div className="mt-2 text-2xl font-extrabold text-white">{value}</div>
    </Card>
  );
}
