'use client';
/**
 * FLEXORA Gym OS — Digital Contracts
 *
 * A contract record is a signed agreement between the gym and ONE member.
 * This page can create contracts (member + title + terms), list them,
 * send them to the member over WhatsApp for signature, and delete them.
 * The member signs digitally from the member portal; the signed copy (PDF)
 * is stored with the record.
 */
import { useCallback, useEffect, useRef, useState } from 'react';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { useTranslation } from '@/lib/i18n';
import { FeedbackLayer, ProductPage, SmartTable } from '@/components/ProductOS';
import { Card } from '@/components/ui/Card';
import { Skeleton } from '@/components/ui/States';
import { safeErrorMessage } from '@/lib/safe-error';
import { useBranchScope } from '@/lib/branch-scope';

interface Contract {
  id: string;
  contractNo: string;
  title: string;
  memberId: string;
  status?: string;
  signedAt?: string | null;
  createdAt: string;
  whatsappSent?: boolean;
  member?: { name: string };
}
interface Member { id: string; name: string }

export default function ContractsPage() {
  const { t } = useTranslation();
  const [items, setItems] = useState<Contract[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');
  const [feedback, setFeedback] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ memberId: '', title: '', bodyMd: '' });
  const formRef = useRef<HTMLDivElement | null>(null);
  const selectRef = useRef<HTMLSelectElement | null>(null);
  const tableRef = useRef<HTMLDivElement | null>(null);

  // Only OWNER and MANAGER may read or write contracts (the API enforces it —
  // `@Roles('OWNER','MANAGER')` on every route in contracts.controller.ts).
  // Asking anyway painted a raw "Insufficient permissions" banner on a page
  // that then offered a button whose dropdown was empty. Identity is read
  // once and cached; until it resolves we keep the old behaviour (fail-open,
  // the API is still the thing that decides).
  const scope = useBranchScope();
  const canManage = !scope.ok || ['OWNER', 'MANAGER'].includes(scope.role);

  const load = useCallback(async () => {
    if (!canManage) { setLoading(false); return; }
    setLoading(true);
    setErr('');
    try {
      const [rows, memberRows] = await Promise.all([
        api<Contract[]>('/contracts'),
        api<{ items: Member[] }>('/members?limit=200').then((r) => r.items || []).catch(() => []),
      ]);
      setItems(Array.isArray(rows) ? rows : (rows as { items?: Contract[] })?.items || []);
      setMembers(memberRows);
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    } finally {
      setLoading(false);
    }
  }, [canManage]);

  useEffect(() => { if (!scope.loading) load(); }, [load, scope.loading]);

  /** Open the form and bring it into view.
   *  The form renders below the hero + explainer cards, i.e. usually below the
   *  fold: without scrolling to it, pressing "New contract" looked like a dead
   *  button (nothing on screen changed) and the second press toggled it shut. */
  function openForm() {
    setErr(''); setFeedback('');
    setShowForm(true);
    requestAnimationFrame(() => {
      formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      selectRef.current?.focus();
    });
  }

  function closeForm() {
    setShowForm(false);
    setForm({ memberId: '', title: '', bodyMd: '' });
  }

  async function create() {
    if (!form.memberId || form.title.trim().length < 3 || form.bodyMd.trim().length < 10) {
      setErr(t('contract_form_hint') || 'Pick a member, write a title (3+ chars) and the agreement terms (10+ chars).');
      return;
    }
    setBusy(true); setErr(''); setFeedback('');
    try {
      await api('/contracts', { method: 'POST', body: JSON.stringify({ memberId: form.memberId, title: form.title.trim(), bodyMd: form.bodyMd.trim() }) });
      setShowForm(false);
      setForm({ memberId: '', title: '', bodyMd: '' });
      setFeedback(t('contract_created') || 'Contract created — you can now send it for signature.');
      await load();
      // Show the row that was just created instead of leaving the user at the
      // top of the page wondering whether anything happened.
      requestAnimationFrame(() => tableRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    } finally { setBusy(false); }
  }

  async function sendWhatsApp(id: string) {
    setErr(''); setFeedback('');
    try {
      await api(`/contracts/${id}/send-whatsapp`, { method: 'POST' });
      setFeedback(t('contract_sent') || 'Signature request queued to the member\'s WhatsApp.');
      load();
    } catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }

  async function del(id: string) {
    if (!confirm(t('confirm_delete'))) return;
    try {
      await api(`/contracts/${id}`, { method: 'DELETE' });
      load();
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    }
  }

  return (
    <Shell>
      <ProductPage
        eyebrow={t('digital_contracts')}
        title={t('digital_contracts')}
        narrative={t('contracts_narrative')}
        primaryAction={canManage ? { label: t('new_contract') || 'عقد جديد', icon: 'plus', onClick: () => (showForm ? closeForm() : openForm()), testId: 'new-contract' } : undefined}
      >
        {err && <FeedbackLayer type="danger" title={t('operation_failed')} detail={err} />}
        {feedback && <FeedbackLayer type="success" title={t('saved') || 'Done'} detail={feedback} />}

        {!canManage && (
          <Card padding="lg" className="mb-6" data-testid="contracts-restricted">
            <div className="product-section-head">
              <div>
                <h2>{t('contracts_manager_only') || 'Contracts are managed by the owner or the general manager'}</h2>
                <p>{t('contracts_manager_only_desc') || 'Your role does not have access to contract records. Ask the gym owner or the general manager — contracts hold legally binding terms, so they are restricted on purpose.'}</p>
              </div>
            </div>
          </Card>
        )}

        {canManage && (<>
        {/* What a contract record is + example workflow */}
        <Card padding="lg" className="mb-6">
          <div className="product-section-head"><div><h2>{t('contracts_explained_title') || 'What is a contract record here?'}</h2><p>{t('contracts_explained_desc') || 'A contract record is a signed agreement between your gym and one member — for example a PT package, a yearly membership with special terms, or a liability waiver. One contract = one member = one agreement.'}</p></div></div>
          <div className="grid md:grid-cols-3 gap-4 mt-4">
            <div className="rounded-2xl border border-[var(--border)] p-4 bg-black/20">
              <div className="text-2xl">1️⃣</div>
              <b className="block mt-2">{t('contract_step1_title') || 'Create the contract'}</b>
              <p className="text-xs text-[var(--silver-dim)] mt-1 leading-5">{t('contract_step1_desc') || 'Pick the member and write what you agreed — e.g. "12 PT sessions, 2 per week, valid 90 days, non-refundable after the first session."'}</p>
            </div>
            <div className="rounded-2xl border border-[var(--border)] p-4 bg-black/20">
              <div className="text-2xl">2️⃣</div>
              <b className="block mt-2">{t('contract_step2_title') || 'Send it & get the signature'}</b>
              <p className="text-xs text-[var(--silver-dim)] mt-1 leading-5">{t('contract_step2_desc') || 'Send the contract to the member by WhatsApp. They review it in the member app and sign digitally. The signed copy is stored here forever.'}</p>
            </div>
            <div className="rounded-2xl border border-[var(--border)] p-4 bg-black/20">
              <div className="text-2xl">3️⃣</div>
              <b className="block mt-2">{t('contract_step3_title') || 'Keep it as proof'}</b>
              <p className="text-xs text-[var(--silver-dim)] mt-1 leading-5">{t('contract_step3_desc') || 'If a dispute ever comes up ("I did not agree to this"), you open the member\'s contract and show exactly what they signed and when.'}</p>
            </div>
          </div>
        </Card>

        {showForm && (
          <Card padding="lg" className="mb-6" ref={formRef} data-testid="new-contract-form">
            <h2 className="text-lg font-bold mb-3">{t('new_contract') || 'عقد جديد'}</h2>
            <div className="grid gap-3">
              <select ref={selectRef} className="input" data-testid="contract-member-select" value={form.memberId} onChange={(e) => setForm({ ...form, memberId: e.target.value })}>
                <option value="">{t('select_member') || 'اختر العضو…'}</option>
                {members.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
              </select>
              {!members.length && (
                <p className="text-xs text-[var(--warning)]" data-testid="contract-no-members">
                  {t('contracts_need_member') || 'There is no member to attach a contract to yet — add a member first.'}{' '}
                  <a className="underline" href="/members">{t('members') || 'Members'}</a>
                </p>
              )}
              <input className="input" placeholder={t('contract_title_ph') || 'عنوان العقد — مثال: اشتراك 6 شهور مع تجميد'} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
              <textarea className="input min-h-32" placeholder={t('contract_body_ph') || 'بنود الاتفاق — مثال: 12 جلسة تدريب شخصي، جلستان أسبوعياً، صالحة 90 يوماً…'} value={form.bodyMd} onChange={(e) => setForm({ ...form, bodyMd: e.target.value })} />
              <div className="flex gap-2">
                <button className="btn btn-primary" data-testid="contract-submit" disabled={busy || !members.length} onClick={create}>{busy ? '…' : (t('create') || 'إنشاء')}</button>
                <button className="btn btn-ghost" onClick={closeForm}>{t('cancel') || 'إلغاء'}</button>
              </div>
            </div>
          </Card>
        )}

        <div ref={tableRef}>
        <h2 className="text-lg font-bold mb-3">{t('contracts') || 'Contracts'}</h2>
        {loading ? <Skeleton lines={6} /> : (
          <SmartTable
            columns={[t('contract_no') || 'Contract no.', t('title'), t('member'), t('status'), t('actions')]}
            rows={items}
            emptyTitle={t('no_contracts') || 'No contracts yet'}
            emptyDescription={t('contracts_empty_desc') || 'Create your first contract with the button above — pick a member, write the agreement, then send it for signature.'}
            renderRow={(c) => (
              <tr key={c.id}>
                <td className="text-mono">{c.contractNo}</td>
                <td>{c.title}</td>
                <td>{c.member?.name || c.memberId?.slice(0, 8) || '—'}</td>
                <td>
                  <span className={`badge ${c.signedAt ? 'badge-active' : 'badge-soon'}`}>
                    {c.signedAt ? t('signed') || 'Signed' : (c.whatsappSent ? (t('awaiting_signature_sent') || 'Sent — awaiting signature') : t('pending_signature') || 'Awaiting signature')}
                  </span>
                </td>
                <td className="flex gap-2">
                  {!c.signedAt && <button className="btn btn-ghost btn-sm" onClick={() => sendWhatsApp(c.id)}>{t('send_whatsapp') || 'إرسال واتساب'}</button>}
                  <button className="btn-danger btn-sm" onClick={() => del(c.id)}>{t('delete')}</button>
                </td>
              </tr>
            )}
          />
        )}
        </div>
        </>)}
      </ProductPage>
    </Shell>
  );
}
