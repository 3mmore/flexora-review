/**
 * FLEXORA Gym OS
 * © 2024 Ammar Allam. All rights reserved.
 * Unauthorized copying, distribution, or modification of this software
 * is strictly prohibited without written permission from the owner.
 * Contact: FLEXORA support
 */
import "./globals.css";
import type { Metadata, Viewport } from "next";
import { Providers } from "./Providers";

// PACK 2 / ITEM 1: the document title is part of the UI a customer reads on a
// phone (browser tab, share sheet, "add to home screen"). It was "FLEXORA Gym
// OS" — English in an Arabic product. The brand logotype stays Latin on the
// logo itself; the TITLE is Arabic, like everything else.
export const metadata: Metadata = {
  title: "فليكسورا — نظام إدارة الصالات",
  description: "نظام متكامل لإدارة الصالات الرياضية: أعضاء، اشتراكات، حضور، ومبيعات — © 2024 عمار علام",
  // PACK 2 / STEP 2.3 — the STAFF app manifest. The portal declares its own
  // (scope /portal) in app/portal/layout.tsx, so a member who installs from the
  // portal gets the member app and a receptionist who installs from /dashboard
  // gets the gym app. Before this, BOTH installed the portal manifest, so the
  // "app" on the owner's phone opened the member portal.
  manifest: "/manifest-staff.webmanifest",
  applicationName: "فليكسورا",
  appleWebApp: {
    capable: true,
    title: "فليكسورا",
    statusBarStyle: "black-translucent",
  },
  formatDetection: { telephone: false },
  icons: { icon: "/logo.png", apple: "/icon-192.png" },
};

export const viewport: Viewport = {
  themeColor: "#c5a059",
  // phone-first: the layout may paint under the notch/gesture bar, and safe-area
  // insets (env(safe-area-inset-*)) are used by the shell and the tab bar
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl" >
      <head>
        {/*
          ── BRAND PRE-PAINT (root cause of the recurring "still gold" report) ──
          The gym's accent is stored in the database and served by /api/gyms/me,
          which can only answer AFTER the document has loaded. Until this script
          existed, the stylesheet's default gold was painted first and the accent
          arrived a moment later (or not at all when the request was slow/failed)
          — so the app looked like the old default theme.

          This runs synchronously in <head>, before first paint, and applies the
          accent cached by BrandContext on the previous load. /api/gyms/me still
          decides the truth: BrandContext re-applies (or clears) it on every load.
          Only the tenant app is branded — login/register/marketing/platform keep
          the default so a cached color can't leak across gyms.

          PHASE R0.5 (owner decision): the script itself moved to
          /brand-prepaint.js. It used to be inlined here, which put its skip-list —
          including the owner-console prefix — into EVERY HTML document served on
          EVERY hostname (measured: two occurrences of the console path in the home
          page, the login page and the 404 page alike). Serving it as a same-origin
          file removes that string, and all inline script, from the document.
          The tag is deliberately a plain blocking <script src>: NOT async, NOT
          defer, NOT next/script — it must execute before first paint, exactly as
          the inlined version did. Behaviour is unchanged and is asserted by
          work/r0-brand-prepaint.spec.js (accent applied on a tenant page, not
          applied on a console page, at 375px).
        */}
        <script src="/brand-prepaint.js" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Cairo:wght@400;600;700;900&display=swap"
          rel="stylesheet"
        />
        <link rel="icon" href="/logo.png" type="image/png" />
        <link rel="apple-touch-icon" href="/icon-192.png" />
      </head>
      <body className="font-cairo bg-gray-950 text-white">
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
