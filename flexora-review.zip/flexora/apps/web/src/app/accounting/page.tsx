'use client';
/**
 * FLEXORA Gym OS — Accounting, made practical for the owner.
 *
 * Plain-language money overview + a prominent daily cash check (shift
 * reconciliation), with the accountant-oriented chart-of-accounts & journal
 * tools kept in a clearly-labelled "Advanced" section at the bottom.
 */
import { useCallback, useEffect, useMemo, useState } from 'react';
import { formatDate } from '@/lib/dates';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { useTranslation } from '@/lib/i18n';
import { FeedbackLayer, InsightCard, InsightLayer, ProductPage, SmartTable } from '@/components/ProductOS';
import { Card } from '@/components/ui/Card';
import { Skeleton } from '@/components/ui/States';
import { safeErrorMessage } from '@/lib/safe-error';
import { fmtMoney } from '@/lib/money';
import { ModalPortal } from '@/components/ModalPortal';

interface Account {
  id: string;
  code: string;
  name: string;
  type: string;
  parentId?: string;
}

interface Journal {
  id: string;
  date: string;
  entryNo: string;
  memo?: string;
  lines: { id: string; debit: number; credit: number; memo?: string; account: { name: string } }[];
}

interface Dashboard {
  revenueToday: number;
  revenueMonth: number;
  expensesToday: number;
  expensesMonth: number;
  netProfit: number;
  checkinsToday: number;
  totalMembers: number;
  activeMembers: number;
  expiringMembers: number;
}

interface SaleRow {
  id: string;
  invoiceNo: string;
  total: number | string;
  paymentMethod?: string;
  createdAt: string;
}

interface LedgerRow {
  id: string;
  type: string;
  category?: string;
  description?: string;
  reference?: string;
  amount: number | string;
  createdAt: string;
  member?: { id: string; name: string } | null;
}

const money = (v: number | string | undefined) => fmtMoney(v);

function todayStart() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
}

export default function Accounting() {
  const { t } = useTranslation();
  // ROUND 14 (security review, PHASE B): posting journals, creating
  // accounts and seeding the chart are accounting.manage operations
  // (the API enforces it too) — read-only accounting.view is not enough.
  const [perms, setPerms] = useState<string[] | null>(null);
  useEffect(() => { api<any>('/auth/me').then((r) => setPerms(r?.user?.permissions || [])).catch(() => setPerms([])); }, []);
  const canManageAccounting = perms === null || (perms || []).includes('accounting.manage');
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [journals, setJournals] = useState<Journal[]>([]);
  const [dash, setDash] = useState<Dashboard | null>(null);
  const [sales, setSales] = useState<SaleRow[]>([]);
  const [ledger, setLedger] = useState<LedgerRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'accounts' | 'journals'>('accounts');
  const [form, setForm] = useState<Partial<Account> | null>(null);
  const [journalForm, setJournalForm] = useState<any>(null);
  const [err, setErr] = useState('');
  const [cashCounted, setCashCounted] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [d, a, j, s, l] = await Promise.all([
        api<Dashboard>('/reports/dashboard').catch(() => null),
        api<Account[]>('/accounting/accounts').catch(() => []),
        api<Journal[]>('/accounting/journals').catch(() => []),
        api<{ items: SaleRow[] }>('/sales?limit=300').then((r) => r.items || []).catch(() => []),
        api<{ items: LedgerRow[] }>('/reports/ledger?limit=15').then((r) => r.items || []).catch(() => []),
      ]);
      setDash(d);
      setAccounts(a);
      setJournals(j);
      setSales(s);
      setLedger(l);
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  // Today's cash POS sales — the money that should physically be in the drawer.
  const cashSalesToday = useMemo(() => {
    const start = todayStart().getTime();
    return sales
      .filter((s) => (s.paymentMethod || '').toUpperCase() === 'CASH' && +new Date(s.createdAt) >= start)
      .reduce((sum, s) => sum + Number(s.total || 0), 0);
  }, [sales]);

  const counted = Number(cashCounted || 0);
  const difference = cashCounted === '' ? null : counted - cashSalesToday;
  const diffLabel = difference === null ? null : difference > 0.009 ? t('cash_over') || 'Over by' : difference < -0.009 ? t('cash_short') || 'Short by' : t('cash_matched') || 'Cash matches ✓';

  async function saveAccount(e: React.FormEvent) {
    e.preventDefault();
    if (!form) return;
    setErr('');
    try {
      await api('/accounting/accounts', { method: 'POST', body: JSON.stringify(form) });
      setForm(null);
      load();
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    }
  }

  async function saveJournal(e: React.FormEvent) {
    e.preventDefault();
    if (!journalForm) return;
    setErr('');
    try {
      await api('/accounting/journals', { method: 'POST', body: JSON.stringify(journalForm) });
      setJournalForm(null);
      load();
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    }
  }

  async function seed() {
    if (!confirm(t('seed_defaults_confirm'))) return;
    try {
      await api('/accounting/accounts/seed', { method: 'POST' });
      load();
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    }
  }

  const profitTone = (dash?.netProfit ?? 0) >= 0 ? 'good' : 'danger';

  return (
    <Shell>
      <ProductPage
        eyebrow={t("accounting")}
        title={t("accounting")}
        narrative={t("accounting_description")}
        primaryAction={canManageAccounting ? { label: t('new_account'), icon: 'plus', onClick: () => setForm({ type: 'ASSET' }) } : undefined}
        secondaryAction={canManageAccounting ? { label: t('seed_defaults'), icon: 'lightning', onClick: seed } : undefined}
      >
        {err && <FeedbackLayer type="danger" title={t("operation_failed")} detail={err} />}

        {/* ── Plain-language money overview ─────────────────────────────── */}
        <InsightLayer>
          {loading ? <><Skeleton /><Skeleton /><Skeleton /><Skeleton /></> : (
            <>
              <InsightCard label={t('money_in') || 'Money in (this month)'} value={money(dash?.revenueMonth)} detail={`${t('today')}: ${money(dash?.revenueToday)}`} icon="coins" tone="good" />
              <InsightCard label={t('money_out') || 'Money out (this month)'} value={money(dash?.expensesMonth)} detail={`${t('today')}: ${money(dash?.expensesToday)}`} icon="coins" tone="warning" />
              <InsightCard label={t('net_profit') || 'What is left (net profit)'} value={money(dash?.netProfit)} detail={t('money_in_minus_out') || 'Money in minus money out'} icon="shield" tone={profitTone} />
              <InsightCard label={t('members')} value={dash?.totalMembers ?? 0} detail={`${dash?.activeMembers ?? 0} ${t('active')} · ${dash?.expiringMembers ?? 0} ${t('need_attention')}`} icon="users" />
            </>
          )}
        </InsightLayer>

        {/* ── Daily cash check (shift reconciliation) ───────────────────── */}
        <Card padding="lg" className="mt-6">
          <div className="product-section-head"><div><h2>{t('daily_cash_check') || 'Daily cash check'}</h2><p>{t('daily_cash_check_desc') || 'Every shift: count the cash in the drawer and compare it with what the system recorded. This catches mistakes before they grow.'}</p></div></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
            <div className="rounded-2xl border border-[var(--border)] p-4 bg-black/20">
              <div className="text-xs text-[var(--silver-dim)]">{t('expected_cash_today') || 'Expected cash from POS sales today'}</div>
              <div className="text-2xl font-black text-[var(--cyan)] mt-1">{money(cashSalesToday)}</div>
              <div className="text-[10px] text-[var(--silver-muted)] mt-1">{t('cash_expected_help') || 'CASH payments only — card/transfer payments are not drawer cash.'}</div>
            </div>
            <div className="rounded-2xl border border-[var(--border)] p-4 bg-black/20">
              <div className="text-xs text-[var(--silver-dim)]">{t('cash_counted') || 'Cash counted in drawer'}</div>
              <input className="input w-full mt-1" type="number" min={0} placeholder="0" value={cashCounted} onChange={(e) => setCashCounted(e.target.value)} />
              <div className="text-[10px] text-[var(--silver-muted)] mt-2">{t('cash_counted_help') || 'Count every note and coin at the end of the shift and enter the total here.'}</div>
            </div>
            <div className="rounded-2xl border border-[var(--border)] p-4 bg-black/20">
              <div className="text-xs text-[var(--silver-dim)]">{t('cash_difference') || 'Difference'}</div>
              {difference === null ? (
                <div className="text-2xl font-black text-[var(--silver-muted)] mt-1">—</div>
              ) : (
                <>
                  <div className={`text-2xl font-black mt-1 ${difference === 0 ? 'text-[var(--success)]' : difference > 0 ? 'text-[var(--warning)]' : 'text-[var(--danger)]'}`}>
                    {difference > 0 ? '+' : ''}{money(Math.abs(difference))}
                  </div>
                  <div className="text-xs mt-1">{diffLabel}</div>
                  <div className="text-[10px] text-[var(--silver-muted)] mt-1">
                    {difference === 0 ? t('cash_ok_help') || 'The drawer matches the system. Record the shift as closed.' : difference > 0 ? t('cash_over_help') || 'More cash than expected — remove the surplus and record it (e.g. a float top-up).' : t('cash_short_help') || 'Less cash than expected — check for unrecorded sales or refunds before closing the shift.'}
                  </div>
                </>
              )}
            </div>
          </div>
        </Card>

        {/* ── Recent money movements (plain ledger) ─────────────────────── */}
        <Card padding="lg" className="mt-6">
          <div className="product-section-head"><div><h2>{t('recent_money_movements') || 'Recent money movements'}</h2><p>{t('recent_money_movements_desc') || 'Every payment in and every expense out, newest first — no accounting knowledge needed.'}</p></div></div>
          {loading ? <Skeleton lines={5} /> : ledger.length ? (
            <div className="divide-y divide-[var(--border)]">
              {ledger.map((row) => {
                // P4-5: human-readable row. The plain description is primary;
                // the reference (invoice/receipt no) and the paying member are
                // shown as supporting context instead of a raw internal code.
                const catKey = `txn_${(row.category || '').toLowerCase()}`;
                const catLabel = t(catKey) !== catKey ? t(catKey) : (row.category || row.type);
                const title = row.description && !/^MEM-(NEW|REN)-|^INV-|^MANUAL-|^RCPT-/.test(row.description)
                  ? row.description
                  : catLabel;
                return (
                  <div key={row.id} className="flex items-center justify-between py-2.5 text-sm">
                    <div className="min-w-0">
                      <b className="block truncate">{title}</b>
                      <div className="text-[10px] text-[var(--silver-muted)] truncate">
                        {[
                          row.member?.name,
                          row.reference ? `${t('reference_label') || 'Ref'} ${row.reference}` : null,
                          new Date(row.createdAt).toLocaleString(),
                        ].filter(Boolean).join(' · ')}
                      </div>
                    </div>
                    <span className={`font-mono font-bold shrink-0 ${row.type === 'INCOME' ? 'text-[var(--success)]' : 'text-[var(--danger)]'}`}>
                      {row.type === 'INCOME' ? '+' : '−'}{money(row.amount)}
                    </span>
                  </div>
                );
              })}
            </div>
          ) : <div className="text-sm text-[var(--silver-dim)]">{t('journal_empty')}</div>}
        </Card>

        {/* ── Advanced (accountant tools) ───────────────────────────────── */}
        <div className="mt-8 mb-3">
          <h2 className="text-lg font-bold">{t('advanced_accounting') || 'Advanced — for your accountant'}</h2>
          <p className="text-xs text-[var(--silver-dim)]">{t('advanced_accounting_desc') || 'Chart of accounts and journal entries. Most owners never need to touch these.'}</p>
        </div>
        <div className="flex gap-4 border-b border-[var(--border)] mb-6">
          <button className={`pb-2 px-1 ${tab === 'accounts' ? 'border-b-2 border-[var(--primary)] text-white' : 'text-[var(--muted)]'}`} onClick={() => setTab('accounts')}>{t("accounts_list")}</button>
          <button className={`pb-2 px-1 ${tab === 'journals' ? 'border-b-2 border-[var(--primary)] text-white' : 'text-[var(--muted)]'}`} onClick={() => setTab('journals')}>{t("journals_list")}</button>
        </div>

        {loading ? <Skeleton lines={5} /> : (
          tab === 'accounts' ? (
            <SmartTable
              columns={[t('code'), t('name'), t('type'), t('parent')]}
              rows={accounts}
              emptyTitle={t('no_accounts')}
              emptyDescription={t("accounting_empty")}
              renderRow={(a) => (
                <tr key={a.id}>
                  <td className="text-mono">{a.code}</td>
                  <td>{a.name}</td>
                  <td>{t(a.type.toLowerCase()) || a.type}</td>
                  <td>{a.parentId || '—'}</td>
                </tr>
              )}
            />
          ) : (
            <SmartTable
              columns={[t('date'), t('number'), t('memo'), t('lines'), t('actions')]}
              rows={journals}
              emptyTitle={t('no_journals')}
              emptyDescription={t("journal_empty")}
              renderRow={(j) => (
                <tr key={j.id}>
                  <td>{formatDate(j.date)}</td>
                  <td>{j.entryNo}</td>
                  <td>{j.memo || '—'}</td>
                  <td>{j.lines?.length || 0} {t('lines')}</td>
                  <td>—</td>
                </tr>
              )}
            />
          )
        )}
      </ProductPage>

      {form && (
        <ModalPortal>
        <div className="fixed inset-0 bg-black/70 grid place-items-center p-5 z-50" onClick={() => setForm(null)}>
          <form onClick={(e) => e.stopPropagation()} onSubmit={saveAccount} className="card card-static glass w-full max-w-lg">
            <h3 className="text-title text-white mb-4">{t('new_account')}</h3>
            <div className="grid grid-cols-2 gap-3">
              <input className="input" placeholder={t('account_code_placeholder')} value={form.code || ''} onChange={(e) => setForm({ ...form, code: e.target.value })} required />
              <input className="input" placeholder={t('account_name_placeholder')} value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
              <div className="col-span-2">
                <select className="input w-full" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} aria-label={t('new_account')}>
                  <option value="ASSET">{t('asset')}</option>
                  <option value="LIABILITY">{t('liability')}</option>
                  <option value="EQUITY">{t('equity')}</option>
                  <option value="REVENUE">{t('revenue')}</option>
                  <option value="EXPENSE">{t('expense')}</option>
                </select>
                {/* P4-4: plain-language explanation for the selected category */}
                <p className="text-[11px] leading-relaxed text-[var(--silver-muted)] mt-1.5">
                  {t('account_type_help_' + (form.type || 'asset').toLowerCase())}
                </p>
              </div>
            </div>
            <div className="flex gap-2 justify-end mt-4">
              <button type="button" className="btn-ghost" onClick={() => setForm(null)}>{t('cancel')}</button>
              <button className="btn-primary">{t('save')}</button>
            </div>
          </form>
        </div>
        </ModalPortal>
      )}
    </Shell>
  );
}
