'use client';

/**
 * المال — the phone's money tab (Pack 2, item 2).
 *
 * A hub, not a new feature: every destination it links to already existed and is
 * still reachable from the sidebar on desktop. On a phone the owner wants one
 * screen that answers "how much came in today, and what do I do next", so this
 * page shows today's income, today's expenses and the net, then the four things
 * that touch money, then links to the detailed routes.
 */

import Link from 'next/link';
import { useEffect, useState } from 'react';
import Shell from '@/components/Shell';
import { useTranslation } from '@/lib/i18n';
import { api } from '@/lib/api';
import { Icon, type IconName } from '@/components/brand/Icon';
import { fmtMoney as money } from '@/lib/money';

type Today = {
  revenueToday: number;
  expensesToday: number;
  netProfit: number;
};

export default function MoneyPage() {
  const { t } = useTranslation();
  const [today, setToday] = useState<Today | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    api<Today>('/reports/dashboard')
      .then(setToday)
      .catch(() => setFailed(true));
  }, []);

  const actions: { href: string; key: string; icon: IconName; primary?: boolean }[] = [
    { href: '/pos', key: 'collect_payment', icon: 'coins', primary: true },
    { href: '/members?action=new', key: 'add_member', icon: 'users' },
    { href: '/expenses', key: 'expenses', icon: 'chart' },
    { href: '/accounting', key: 'accounting', icon: 'menu-grid' },
  ];

  const links = [
    { href: '/sales', key: 'sales' },
    { href: '/reports', key: 'reports' },
    { href: '/team/performance', key: 'team_performance' },
    { href: '/billing', key: 'subscription' },
    { href: '/plans', key: 'plans' },
    { href: '/inventory', key: 'inventory' },
  ];

  return (
    <Shell>
      <div className="page-stack">
        <div className="mobile-page-title">
          <h1>{t('nav_money')}</h1>
        </div>

        {failed && (
          <div className="state-error" role="alert">
            <strong>{t('could_not_load')}</strong>
            <span>{t('pull_to_retry')}</span>
          </div>
        )}

        <section className="money-today" aria-label={t('revenue_today')}>
          <div className="money-today-main">
            <span>{t('revenue_today')}</span>
            <strong>{today ? money(today.revenueToday) : '—'}</strong>
          </div>
          <div className="money-today-split">
            <div>
              <span>{t('expenses_today')}</span>
              <b>{today ? money(today.expensesToday) : '—'}</b>
            </div>
            <div>
              <span>{t('net_profit')}</span>
              <b data-negative={today && today.netProfit < 0 ? 'true' : undefined}>
                {today ? money(today.netProfit) : '—'}
              </b>
            </div>
          </div>
        </section>

        <section className="quick-actions" aria-label={t('quick_actions')}>
          {actions.map((a) => (
            <Link key={a.href} href={a.href} className={`quick-action ${a.primary ? 'primary' : ''}`}>
              <Icon name={a.icon} size={18} />
              <span>{t(a.key)}</span>
            </Link>
          ))}
        </section>

        <section className="link-list" aria-label={t('nav_money')}>
          {links.map((l) => (
            <Link key={l.href} href={l.href} className="link-row">
              <span>{t(l.key)}</span>
              <Icon name="arrow-left" size={14} />
            </Link>
          ))}
        </section>
      </div>
    </Shell>
  );
}
