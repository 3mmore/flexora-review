'use client';
/**
 * FLEXORA Class Performance Center
 */
import { useCallback, useEffect, useMemo, useState, useRef } from 'react';
import { formatDate } from '@/lib/dates';
import Shell from '@/components/Shell';
import { api, auth } from '@/lib/api';
import { useTranslation } from '@/lib/i18n';
import { ActionCenter, FeedbackLayer, InsightCard, InsightLayer, ProductPage, SmartAction, SmartTable } from '@/components/ProductOS';
import { Card } from '@/components/ui/Card';
import { EmptyState, Skeleton } from '@/components/ui/States';
import { Icon } from '@/components/brand/Icon';
import { safeErrorMessage } from '@/lib/safe-error';
import { useBranchScope } from '@/lib/branch-scope';
import { fmtMoney } from '@/lib/money';
import { ModalPortal } from '@/components/ModalPortal';

function weekStart(d: Date) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  x.setDate(x.getDate() - x.getDay());
  return x;
}

type ClassSession = {
  id: string;
  startsAt: string;
  endsAt?: string;
  capacity: number;
  booked?: number;
  full?: boolean;
  status?: string;
  coachId?: string;
  coach?: { id: string; name: string };
  templateId: string;
  template?: { name?: string; nameAr?: string; color?: string; durationMin?: number };
};
type ClassTemplate = { 
  id: string; name: string; nameAr?: string; capacity: number; 
  coachId?: string; coach?: { name: string }; durationMin: number; color: string;
  branchId?: string | null; branch?: { id: string; name: string } | null;
};
type Member = { id: string; name: string; mobile?: string };
type Coach = { id: string; name: string };
type RosterRow = { id: string; status: string; member?: { id: string; name: string; mobile?: string } };

type Health = 'Healthy' | 'Watch' | 'At Risk';
const utilization = (s: ClassSession) => Math.round(((s.booked || 0) / Math.max(s.capacity || 1, 1)) * 100);
const healthFor = (s: ClassSession): Health => utilization(s) >= 70 ? 'Healthy' : utilization(s) >= 35 ? 'Watch' : 'At Risk';
const money = (n: number) => fmtMoney(n);

const toLocalISO = (d: any) => {
  if (!d) return '';
  const date = new Date(d);
  if (isNaN(date.getTime())) return '';
  return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
};

export default function ClassPerformanceCenter() {
  const { t, lang } = useTranslation();
  const [anchor, setAnchor] = useState(() => weekStart(new Date()));
  const [sessions, setSessions] = useState<ClassSession[]>([]);
  const [templates, setTemplates] = useState<ClassTemplate[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [coaches, setCoaches] = useState<Coach[]>([]);
  const [user, setUser] = useState<any>(null);
  const [picked, setPicked] = useState<ClassSession | null>(null);
  const [roster, setRoster] = useState<RosterRow[]>([]);
  const [newForm, setNewForm] = useState<any | null>(null);
  const [newTemplate, setNewTemplate] = useState<any | null>(null);
  // P4-1: per-branch filter for the templates table ('' = all branches)
  const [tplBranchFilter, setTplBranchFilter] = useState('');
  const [busy, setBusy] = useState(true);
  const hasLoadedOnce = useRef(false);
  const [success, setSuccess] = useState('');
  const [err, setErr] = useState('');
  const [deleteConfirm, setDeleteConfirm] = useState<{ id: string; count: number; isTemplate: boolean } | null>(null);
  // Phase 6.1: coach assignment is edited INLINE in the sessions row, not via
  // the separate edit popup. Tracks which row is currently saving.
  const [savingCoach, setSavingCoach] = useState<string | null>(null);

  /** PHASE 4: restricted staff see only their own branch — no branch picker. */
  const scope = useBranchScope();

  const load = useCallback(async () => {
    const from = anchor;
    const to = new Date(anchor);
    to.setDate(to.getDate() + 7);
    
    if (!hasLoadedOnce.current) setBusy(true);
    setErr('');
    try {
      const [sessionRows, templateRows, memberRows, userRows, branchRows, me] = await Promise.all([
        api<ClassSession[]>(`/classes/sessions?from=${from.toISOString()}&to=${to.toISOString()}`),
        api<ClassTemplate[]>('/classes/templates'),
        api<{ items: Member[] }>('/members?limit=200').then((r) => r.items || []),
        // NOTE (Phase 4): /users is OWNER/MANAGER-only. A COACH or RECEPTION
        // account still needs this page, so a denied list degrades to "no
        // coaches to choose from" instead of failing the whole Promise.all.
        api<Array<{ id: string; name: string; role: string }>>('/users')
          .then(users => users.filter(u => u.role === 'COACH' || u.role === 'OWNER' || u.role === 'MANAGER'))
          .catch(() => []),
        api<any>('/branches').then(res => Array.isArray(res) ? res : (res.items || [])),
        auth.me(),
      ]);
      setSessions(sessionRows);
      setTemplates(templateRows);
      setMembers(memberRows);
      setCoaches(userRows);
      setBranches(branchRows);
      setUser(me);
      hasLoadedOnce.current = true;
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    } finally {
      setBusy(false);
    }
  }, [anchor]);

  useEffect(() => { load(); }, [load]);

  const totalBookings = sessions.reduce((sum, s) => sum + (s.booked || 0), 0);
  const totalCapacity = sessions.reduce((sum, s) => sum + (s.capacity || 0), 0);
  const capacityUtilization = totalCapacity ? Math.round((totalBookings / totalCapacity) * 100) : 0;
  const atRisk = sessions.filter((s) => healthFor(s) === 'At Risk');
  // P4-1: the full `templates` list still feeds the session-create dropdown;
  // the templates TABLE shows the branch-filtered subset only.
  const filteredTemplates = tplBranchFilter
    ? templates.filter((tpl) => tpl.branchId === tplBranchFilter)
    : templates;

  /**
   * Phase 6.1: assign/change the coach of a session straight from its table
   * row. Saves via PATCH /classes/sessions/:id, then reloads so the row shows
   * what the API actually stored.
   */
  async function assignCoach(sessionId: string, coachId: string) {
    setErr(''); setSavingCoach(sessionId);
    // Optimistic paint so the dropdown does not visually snap back while saving.
    setSessions((rows) => rows.map((r) => r.id === sessionId
      ? { ...r, coachId: coachId || undefined, coach: coaches.find((c) => c.id === coachId) }
      : r));
    try {
      await api(`/classes/sessions/${sessionId}`, { method: 'PATCH', body: JSON.stringify({ coachId: coachId || null }) });
      setSuccess(t('coach_updated'));
      setTimeout(() => setSuccess(''), 3000);
      await load();
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
      await load();
    } finally { setSavingCoach(null); }
  }

  async function openRoster(s: ClassSession) {
    setPicked(s);
    try {
      const r = await api<RosterRow[]>(`/classes/sessions/${s.id}/roster`);
      setRoster(r);
    } catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }

  async function book(memberId: string) {
    if (!picked) return;
    try {
      await api(`/classes/sessions/${picked.id}/book`, { method: 'POST', body: JSON.stringify({ memberId }) });
      setSuccess(t('success') || 'Member booked');
      setTimeout(() => setSuccess(''), 3000);
      await openRoster(picked);
      await load();
    } catch (e: unknown) { alert(safeErrorMessage(e)); }
  }

  async function removeSession(id: string, force = false) {
    try {
      await api(`/classes/sessions/${id}${force ? '?force=true' : ''}`, { method: 'DELETE' });
      setDeleteConfirm(null);
      setSuccess(t('success') || 'Session deleted');
      setTimeout(() => setSuccess(''), 3000);
      load();
    } catch (e: any) {
      if (e.message?.includes('AFFECTED_BOOKINGS')) {
        const errorData = await (async () => { try { return JSON.parse(e.message); } catch { return null; } })();
        setDeleteConfirm({ id, count: errorData?.count || 0, isTemplate: false });
      } else {
        setErr(safeErrorMessage(e));
      }
    }
  }

  async function removeTemplate(id: string, force = false) {
    try {
      await api(`/classes/templates/${id}${force ? '?force=true' : ''}`, { method: 'DELETE' });
      setDeleteConfirm(null);
      setSuccess(t('success') || 'Template deleted');
      setTimeout(() => setSuccess(''), 3000);
      load();
    } catch (e: any) {
      if (e.message?.includes('AFFECTED_BOOKINGS')) {
        const errorData = await (async () => { try { return JSON.parse(e.message); } catch { return null; } })();
        setDeleteConfirm({ id, count: errorData?.count || 0, isTemplate: true });
      } else {
        setErr(safeErrorMessage(e));
      }
    }
  }

  async function complete() {
    if (!picked) return;
    try {
      await api(`/classes/sessions/${picked.id}/complete`, { method: 'POST' });
      setSuccess(t('success') || 'Session completed');
      setTimeout(() => setSuccess(''), 3000);
      setPicked(null);
      await load();
    } catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }

  async function saveSession(e: React.FormEvent) {
    e.preventDefault(); setErr('');
    try {
      const body = {
        templateId: newForm.templateId,
        startsAt: newForm.startsAt,
        // PHASE 4: a restricted user can only ever create in their own branch.
        branchId: scope.unrestricted ? (newForm.branchId || undefined) : (scope.branchId || undefined),
        coachId: newForm.coachId || undefined,
        capacity: Number(newForm.capacity || 20),
        durationMin: Number(newForm.durationMin || 60),
      };
      if (newForm.id) {
        await api(`/classes/sessions/${newForm.id}`, { method: 'PATCH', body: JSON.stringify(body) });
        setSuccess(t('success') || 'Session updated');
      } else {
        await api('/classes/sessions', { method: 'POST', body: JSON.stringify(body) });
        setSuccess(t('success') || 'Session created');
      }
      setNewForm(null);
      setTimeout(() => setSuccess(''), 3000);
      load();
    } catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }

  async function saveTemplate(e: React.FormEvent) {
    e.preventDefault(); setErr('');
    try {
      const body = {
        name: newTemplate.name,
        nameAr: newTemplate.nameAr || undefined,
        // PHASE 4: restricted staff do not get to choose a branch.
        branchId: scope.unrestricted ? (newTemplate.branchId || undefined) : (scope.branchId || undefined),
        coachId: newTemplate.coachId || undefined,
        durationMin: Number(newTemplate.durationMin || 60),
        capacity: Number(newTemplate.capacity || 20),
        color: newTemplate.color || undefined,
      };
      if (newTemplate.id) {
        await api(`/classes/templates/${newTemplate.id}`, { method: 'PATCH', body: JSON.stringify(body) });
        setSuccess(t('success') || 'Template updated');
      } else {
        await api('/classes/templates', { method: 'POST', body: JSON.stringify(body) });
        setSuccess(t('success') || 'Template created');
      }
      setNewTemplate(null);
      setTimeout(() => setSuccess(''), 3000);
      load();
    } catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }

  return (
    <Shell>
      <ProductPage
        eyebrow={t("class_schedule")}
        title={t("classes")}
        narrative={`${sessions.length} ${t('sessions_this_week')} ${capacityUtilization}% ${t('occupancy_rate')}. ${atRisk.length ? `${atRisk.length} ${t('need_attention')}` : t('class_demand_stable')}`}
        primaryAction={{ label: t('add_class'), icon: 'plus', onClick: () => setNewForm({ templateId: templates[0]?.id || '', startsAt: '', capacity: 20 }) }}
        secondaryAction={{ label: t('create_template'), icon: 'plus', onClick: () => setNewTemplate({ name: '', capacity: 20, durationMin: 60, color: '#6366F1' }) }}
      >
        {err && <FeedbackLayer type="danger" title={t('class_performance_unavailable')} detail={t(err) || err} action={<button className="btn btn-ghost px-3 py-1.5 text-xs" onClick={load}>{t('retry')}</button>} />}
        {success && <FeedbackLayer type="success" title={t('success')} detail={success} />}

        <InsightLayer>
          {busy ? <><Skeleton /><Skeleton /><Skeleton /><Skeleton /></> : <>
            <InsightCard label={t('active_classes')} value={sessions.length} detail={`${templates.length} ${t('templates_available')}`} icon="calendar" />
            <InsightCard label={t('total_bookings')} value={totalBookings} icon="users" tone={totalBookings ? 'good' : 'warning'} detail={t('bookings_count')} />
            <InsightCard label={t('occupancy_rate')} value={`${capacityUtilization}%`} icon="chart" tone={capacityUtilization > 75 ? 'good' : capacityUtilization < 35 ? 'warning' : 'neutral'} detail={t('occupancy_rate')} />
            <InsightCard label={t('classes_at_risk')} value={atRisk.length} detail={t('underbooked_action')} icon="bell" tone={atRisk.length ? 'warning' : 'good'} />
          </>}
        </InsightLayer>

        <section className="mt-8">
          <Card padding="lg">
            <div className="flex flex-wrap justify-between items-center gap-3 mb-6">
              <h2 className="text-xl font-bold">{t('class_templates')}</h2>
              {/* P4-1: branch filter for templates (Phase 4: owners/managers only) */}
              {scope.unrestricted ? (
                <select
                  className="input py-1.5 text-sm min-w-[180px]"
                  aria-label={t('filter_by_branch')}
                  value={tplBranchFilter}
                  onChange={(e) => setTplBranchFilter(e.target.value)}
                >
                  <option value="">{t('all_branches')}</option>
                  {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
                </select>
              ) : (
                <span className="badge badge-active" data-testid="classes-branch-locked">
                  {t('branch') || 'Branch'}: {scope.branchName || branches[0]?.name || '—'}
                </span>
              )}
            </div>
            <SmartTable 
              columns={[t('name'), t('coach'), t('branch'), t('capacity'), t('duration'), t('actions')]} 
              rows={filteredTemplates} 
              loading={busy}
              emptyTitle={t('no_data')}
              emptyDescription={t('create_session_intelligence')}
              renderRow={(tpl) => (
                <tr key={tpl.id}>
                  <td className="font-bold">
                    <div className="flex items-center gap-2">
                      <span className="w-3 h-3 rounded-full" style={{ backgroundColor: tpl.color }} />
                      {lang === 'ar' ? (tpl.nameAr || tpl.name) : tpl.name}
                    </div>
                  </td>
                  <td>{tpl.coach?.name || t('unassigned')}</td>
                  <td>{tpl.branch?.name || t('all_branches')}</td>
                  <td>{tpl.capacity}</td>
                  <td>{tpl.durationMin} {t('time')}</td>
                  <td>
                    <div className="flex gap-2">
                      <button className="btn-ghost btn-sm" onClick={() => setNewTemplate(tpl)}>{t('edit')}</button>
                      <button className="btn-danger btn-sm" onClick={() => removeTemplate(tpl.id)}>{t('delete')}</button>
                    </div>
                  </td>
                </tr>
              )}
            />
          </Card>
        </section>

        <section className="mt-8">
          <Card padding="lg">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold">{t('class_schedule')}</h2>
              <div className="flex gap-2">
                <button className="btn btn-ghost btn-sm" onClick={() => { const a = new Date(anchor); a.setDate(a.getDate() - 7); setAnchor(a); }}>‹ {t('previous')}</button>
                <span className="text-sm font-bold self-center">{formatDate(anchor)} – {formatDate(anchor.getTime() + 7 * 86400000 - 1)}</span>
                <button className="btn btn-ghost btn-sm" onClick={() => { const a = new Date(anchor); a.setDate(a.getDate() + 7); setAnchor(a); }}>{t('next')} ›</button>
              </div>
            </div>
            <SmartTable 
              columns={[t('class'), t('coach'), t('start_time'), t('bookings_count'), t('status'), t('actions')]} 
              rows={sessions} 
              loading={busy}
              emptyTitle={t('no_classes')}
              emptyDescription={t('create_session_intelligence')}
              renderRow={(s) => (
                <tr key={s.id}>
                  <td className="font-bold">{(lang === 'ar' ? s.template?.nameAr : s.template?.name) || s.template?.name}</td>
                  <td>
                    <select
                      className="input py-1 text-xs min-w-[150px]"
                      aria-label={t('coach')}
                      disabled={savingCoach === s.id}
                      value={s.coachId || ''}
                      onChange={(e) => assignCoach(s.id, e.target.value)}
                    >
                      <option value="">{t('unassigned')}</option>
                      {coaches.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                  </td>
                  <td>{new Date(s.startsAt).toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-US')}</td>
                  <td>{s.booked} / {s.capacity}</td>
                  <td><span className={`badge ${s.status === 'CANCELLED' ? 'badge-expired' : 'badge-active'}`}>{t(s.status?.toLowerCase() + '_label') || s.status}</span></td>
                  <td>
                    <div className="flex gap-2">
                      <button className="btn-ghost btn-sm" onClick={() => openRoster(s)}>{t('bookings')}</button>
                      <button className="btn-ghost btn-sm" onClick={() => setNewForm(s)}>{t('edit')}</button>
                      <button className="btn-danger btn-sm" onClick={() => removeSession(s.id)}>{t('delete')}</button>
                    </div>
                  </td>
                </tr>
              )}
            />
          </Card>
        </section>

        {picked && (
          <ModalPortal>
        <div className="fixed inset-0 bg-black/60 grid place-items-center p-5 z-50" onClick={() => setPicked(null)}>
            <div className="card w-full max-w-md" onClick={(e) => e.stopPropagation()}>
              <div className="flex items-center gap-2"><h3 className="font-extrabold text-lg flex-1">{(lang === 'ar' ? picked.template?.nameAr : picked.template?.name) || picked.template?.name}</h3><span className="text-sm text-[var(--muted)]">{roster.length}/{picked.capacity}</span></div>
              <div className="text-xs text-[var(--muted)] mb-3">{new Date(picked.startsAt).toLocaleString()}</div>
              <div className="max-h-48 overflow-auto mb-3">{roster.length ? roster.map((b) => <div key={b.id} className="flex justify-between py-1 text-sm border-t border-[var(--border)]"><span>{b.member?.name}</span><span className="text-[var(--muted)]">{b.status}</span></div>) : <EmptyState icon="users" title={t('no_bookings')} description={t('book_members_promote')} />}</div>
              <div className="flex gap-2"><select className="input" id="bookMember" defaultValue=""><option value="" disabled>{t('member')}…</option>{members.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}</select><button className="btn" onClick={() => { const el = document.getElementById('bookMember') as HTMLSelectElement; if (el.value) book(el.value); }}>＋</button></div>
              <button className="btn-ghost w-full mt-3" onClick={complete}>✓ {t('complete')}</button>
            </div>
          </div>
        </ModalPortal>
        )}

        {newForm && (
          <ModalPortal>
        <div className="fixed inset-0 bg-black/60 grid place-items-center p-5 z-50" onClick={() => setNewForm(null)}>
            <form className="card w-full max-w-md" onClick={(e) => e.stopPropagation()} onSubmit={saveSession}>
              <h3 className="font-extrabold text-lg mb-4">{newForm.id ? t('edit') : t('add_class')}</h3>
              <div className="space-y-4">
                <label className="block">
                  <span className="text-xs font-bold text-[var(--silver-dim)] uppercase">{t('template')}</span>
                  <select className="input w-full mt-1" value={newForm.templateId || ''} onChange={(e) => setNewForm({ ...newForm, templateId: e.target.value })} required>
                    <option value="" disabled>{t('select_template')}</option>
                    {templates.map((tpl) => <option key={tpl.id} value={tpl.id}>{(lang === 'ar' ? tpl.nameAr : tpl.name) || tpl.name}</option>)}
                  </select>
                </label>
                <label className="block">
                  <span className="text-xs font-bold text-[var(--silver-dim)] uppercase">{t('coach')}</span>
                  <select className="input w-full mt-1" value={newForm.coachId || ''} onChange={(e) => setNewForm({ ...newForm, coachId: e.target.value })}>
                    <option value="">{t('select_coach')}</option>
                    {coaches.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </label>
                <label className="block">
                  <span className="text-xs font-bold text-[var(--silver-dim)] uppercase">{t('starts_at')}</span>
                  <input 
                    className="input w-full mt-1" 
                    type="datetime-local" 
                    value={toLocalISO(newForm.startsAt)} 
                    onChange={(e) => setNewForm({ ...newForm, startsAt: e.target.value })} 
                    required 
                  />
                </label>
                <label className="block">
                  <span className="text-xs font-bold text-[var(--silver-dim)] uppercase">{t('capacity')}</span>
                  <input className="input w-full mt-1" type="number" value={newForm.capacity || 20} onChange={(e) => setNewForm({ ...newForm, capacity: e.target.value })} required />
                </label>
                {(user?.role === 'OWNER' || user?.role === 'MANAGER') && (
                  <label className="block">
                    <span className="text-xs font-bold text-[var(--silver-dim)] uppercase">{t('branch')}</span>
                    <select className="input w-full mt-1" value={newForm.branchId || ''} onChange={(e) => setNewForm({ ...newForm, branchId: e.target.value })} required>
                      <option value="" disabled>{t('select_branch')}</option>
                      {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
                    </select>
                  </label>
                )}
              </div>
              <div className="flex gap-2 justify-end mt-6">
                <button type="button" className="btn-ghost" onClick={() => setNewForm(null)}>{t('cancel')}</button>
                <button className="btn-primary">{t('save')}</button>
              </div>
            </form>
          </div>
        </ModalPortal>
        )}

        {newTemplate && (
          <ModalPortal>
        <div className="fixed inset-0 bg-black/60 grid place-items-center p-5 z-50" onClick={() => setNewTemplate(null)}>
            <form className="card w-full max-w-md" onClick={(e) => e.stopPropagation()} onSubmit={saveTemplate}>
              <h3 className="font-extrabold text-lg mb-4">{newTemplate.id ? t('edit') : t('create_template')}</h3>
              <div className="space-y-4">
                <label className="block">
                  <span className="text-xs font-bold text-[var(--silver-dim)] uppercase">{t('name')} (EN)</span>
                  <input className="input w-full mt-1" placeholder="Zumba" value={newTemplate.name || ''} onChange={(e) => setNewTemplate({ ...newTemplate, name: e.target.value })} required />
                </label>
                <label className="block">
                  <span className="text-xs font-bold text-[var(--silver-dim)] uppercase">{t('name')} (AR)</span>
                  <input className="input w-full mt-1" placeholder="زومبا" value={newTemplate.nameAr || ''} onChange={(e) => setNewTemplate({ ...newTemplate, nameAr: e.target.value })} />
                </label>
                <label className="block">
                  <span className="text-xs font-bold text-[var(--silver-dim)] uppercase">{t('coach')}</span>
                  <select className="input w-full mt-1" value={newTemplate.coachId || ''} onChange={(e) => setNewTemplate({ ...newTemplate, coachId: e.target.value })}>
                    <option value="">{t('select_coach')}</option>
                    {coaches.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </label>
                {/* P4-1: assign the template to a branch (optional) */}
                <label className="block">
                  <span className="text-xs font-bold text-[var(--silver-dim)] uppercase">{t('branch')}</span>
                  {scope.unrestricted ? (
                    <select className="input w-full mt-1" value={newTemplate.branchId || ''} onChange={(e) => setNewTemplate({ ...newTemplate, branchId: e.target.value })}>
                      <option value="">{t('all_branches')}</option>
                      {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
                    </select>
                  ) : (
                    <div className="badge badge-active mt-1" data-testid="template-branch-locked">
                      {scope.branchName || branches[0]?.name || '—'}
                    </div>
                  )}
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <label className="block">
                    <span className="text-xs font-bold text-[var(--silver-dim)] uppercase">{t('capacity')}</span>
                    <input className="input w-full mt-1" type="number" value={newTemplate.capacity || 20} onChange={(e) => setNewTemplate({ ...newTemplate, capacity: e.target.value })} required />
                  </label>
                  <label className="block">
                    <span className="text-xs font-bold text-[var(--silver-dim)] uppercase">{t('duration')} (min)</span>
                    <input className="input w-full mt-1" type="number" value={newTemplate.durationMin || 60} onChange={(e) => setNewTemplate({ ...newTemplate, durationMin: e.target.value })} required />
                  </label>
                </div>
                <label className="block">
                  <span className="text-xs font-bold text-[var(--silver-dim)] uppercase">{t('class_color')}</span>
                  <input className="input w-full mt-1 h-10 p-1" type="color" value={newTemplate.color || '#6366F1'} onChange={(e) => setNewTemplate({ ...newTemplate, color: e.target.value })} />
                </label>
              </div>
              <div className="flex gap-2 justify-end mt-6">
                <button type="button" className="btn-ghost" onClick={() => setNewTemplate(null)}>{t('cancel')}</button>
                <button className="btn-primary">{t('save')}</button>
              </div>
            </form>
          </div>
        </ModalPortal>
        )}

        {deleteConfirm && (
          <ModalPortal>
        <div className="fixed inset-0 bg-black/80 grid place-items-center p-5 z-[60]" onClick={() => setDeleteConfirm(null)}>
            <div className="card w-full max-w-md border-red-900/50 border shadow-2xl" onClick={(e) => e.stopPropagation()}>
              <h3 className="text-xl font-bold text-red-500 mb-2">{t('delete')} {deleteConfirm.isTemplate ? t('class_template') : t('session')}?</h3>
              <p className="text-sm text-[var(--muted)] mb-6">
                {t('confirm_cancel_bookings')} <b>{deleteConfirm.count} {t('affected_bookings')}</b>.
              </p>
              <div className="flex gap-3 justify-end">
                <button className="btn-ghost" onClick={() => setDeleteConfirm(null)}>{t('cancel')}</button>
                <button className="btn-danger px-4" onClick={() => deleteConfirm.isTemplate ? removeTemplate(deleteConfirm.id, true) : removeSession(deleteConfirm.id, true)}>
                  {t('confirm')}
                </button>
              </div>
            </div>
          </div>
        </ModalPortal>
        )}
      </ProductPage>
    </Shell>
  );
}
