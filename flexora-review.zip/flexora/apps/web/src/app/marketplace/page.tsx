'use client';
import { OperationalResourcePage } from '@/components/OperationalResourcePage';
import { useTranslation } from '@/lib/i18n';
import { moduleLabel } from '@/lib/marketplace-ar';

export default function Page() {
  const { t, lang } = useTranslation();
  return <OperationalResourcePage config={{ queryKey: 'marketplace', endpoint: '/marketplace/catalog', title: t('marketplace_label'), narrative: t('marketplace_narrative'), columns: [{ key: 'name' }, { key: 'slug' }, { key: 'category' }],
    // slugs are the stable identity; the Arabic label is a presentation concern
    decorateRow: (row) => {
      if (lang === 'en') return row;
      const label = moduleLabel(String(row.slug ?? ''), {
        name: String(row.name ?? ''),
        description: String(row.description ?? ''),
        category: String(row.category ?? ''),
      });
      return { ...row, name: label.name, category: label.category };
    } }} />;
}
