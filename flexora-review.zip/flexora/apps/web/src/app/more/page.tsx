'use client';

/**
 * المزيد — the index behind the fifth tab (Pack 2, item 2).
 *
 * Every group that was in the desktop sidebar, with the same icons and the same
 * permission gating, so nothing is hidden and nothing is duplicated by hand: if a
 * destination is removed from the sidebar it disappears here too. Signed-out and
 * restricted users see only what they may open.
 */

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import Shell from '@/components/Shell';
import { useTranslation } from '@/lib/i18n';
import { auth } from '@/lib/api';
import { effectivePermissionsOf } from '@/lib/permissions';
import { Icon } from '@/components/brand/Icon';
import { MORE_GROUPS } from '@/lib/nav-structure';

export default function MorePage() {
  const { t } = useTranslation();
  const [held, setHeld] = useState<string[] | null>(null);
  const [role, setRole] = useState<string | null>(null);

  useEffect(() => {
    let live = true;
    auth
      .me()
      .then((u) => {
        if (!live) return;
        setRole(u?.role ?? null);
        setHeld(effectivePermissionsOf(u?.role, u?.permissions));
      })
      .catch(() => live && setHeld([]));
    return () => {
      live = false;
    };
  }, []);

  const groups = useMemo(
    () =>
      MORE_GROUPS.map((g) => ({
        ...g,
        items: g.items.filter((i) => {
          if (held === null) return false;
          if (i.perms) return i.perms.every((p) => held.includes(p));
          if (i.roles) return !!role && i.roles.includes(role);
          return true;
        }),
      })).filter((g) => g.items.length > 0),
    [held, role],
  );

  return (
    <Shell>
      <div className="page-stack">
        <div className="mobile-page-title">
          <h1>{t('nav_more')}</h1>
        </div>

        {held === null && <div className="skeleton-block" aria-busy="true" />}

        {held !== null &&
          groups.map((g) => (
            <section key={g.label} className="more-group" aria-label={t(g.label)}>
              <h2>{t(g.label)}</h2>
              <div className="more-grid">
                {g.items.map((i) => (
                  <Link key={i.href} href={i.href} className="more-item">
                    <Icon name={i.icon} size={22} />
                    <span>{t(i.key)}</span>
                  </Link>
                ))}
              </div>
            </section>
          ))}

        <section className="more-group">
          <h2>{t('account')}</h2>
          <div className="link-list">
            <Link href="/settings" className="link-row">
              <span>{t('settings')}</span>
              <Icon name="arrow-left" size={14} />
            </Link>
            <Link href="/support" className="link-row">
              <span>{t('support')}</span>
              <Icon name="arrow-left" size={14} />
            </Link>
          </div>
        </section>
      </div>
    </Shell>
  );
}
