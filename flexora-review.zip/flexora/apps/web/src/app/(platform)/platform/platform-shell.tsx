'use client';
/**
 * FLEXORA Gym OS - Web
 * (c) 2024 Ammar Allam. All rights reserved.
 */
/**
 * PHASE R0 - the owner-console shell, extracted verbatim from the client layout.
 *
 * Why it moved: `layout.tsx` in this directory is now a SERVER component so that it
 * can read the request's Host header and call `notFound()` when the hostname is not
 * in ADMIN_HOSTS (owner decision: enforce the gate in nginx, Next middleware, the
 * Next app itself and Nest - four independent layers). A client component cannot do
 * that: it has no request headers, and `notFound()` in a client component does not
 * produce a 404 status.
 *
 * Nothing here changed behaviour: same links, same i18n, same RTL/LTR handling, same
 * `/platform/login` bypass of the shell, same logout button, same PlatformGuard.
 */
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { PlatformGuard, platformApi } from './platform-guard';
import { StepUpProvider } from './platform-step-up';
import { useTranslation } from '@/lib/i18n';

function Shell({ children }: { children: React.ReactNode }) { 
  const { t, lang } = useTranslation();
  const pathname = usePathname();
  const links = [
    ['/platform/dashboard', t('dashboard')],
    ['/platform/gyms', t('platform_gyms')],
    ['/platform/subscriptions', t('platform_subscriptions')],
    ['/platform/revenue', t('platform_revenue')],
    ['/platform/audit-log', t('platform_audit_log')],
    // PHASE R3 (R3.10) - the alert outbox, so a NO_CHANNEL warning has a home.
    ['/platform/alerts', t('platform_alerts_label')],
    // PHASE R4 (R4.14, R4.15) - flags and the security center. Both were api-only before:
    // the routes existed and the console had no surface for them, so a flag could be flipped
    // or an IP block lifted only by hand-crafting a request.
    ['/platform/flags', t('platform_flags_title')],
    ['/platform/security', t('platform_security_title')],
    ['/platform/health', t('platform_health')],
    ['/platform/admins', t('platform_admins_label')]
  ];

  return (
    <div className="min-h-screen bg-[var(--bg-base)] text-white" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
      <aside className={`fixed ${lang === 'ar' ? 'right-0' : 'left-0'} top-0 hidden h-full w-64 border-l border-white/10 bg-black/50 p-5 lg:block`}>
        <div className="text-2xl font-black text-[#c5a059]">FLEXORA</div>
        <nav className="mt-8 space-y-2">
          {links.map(([href,label]) => (
            <Link key={href} className="block rounded-xl px-4 py-3 text-white/70 hover:bg-white/10" href={href}>
              {label}
            </Link>
          ))}
        </nav>
      </aside>
      <main className={lang === 'ar' ? 'lg:mr-64' : 'lg:ml-64'}>
        <header className="flex items-center justify-between border-b border-white/10 bg-black/30 px-6 py-4">
          <b>{t('platform_admin')}</b>
          <button
            onClick={async () => {
              // PHASE R1.4 - deleting the cookie client-side was not a logout: the
              // session row stayed live until it expired, so a copied cookie kept
              // working. This revokes it server-side first, and clears the cookie
              // even if the call fails, so the owner is never stuck signed-in.
              try {
                await platformApi('/platform/auth/logout', { method: 'POST' });
              } catch {
                /* the session may already be gone; the redirect below still happens */
              }
              document.cookie = 'flx_platform_token=; path=/; max-age=0; SameSite=Strict';
              document.cookie = 'flx_platform_csrf=; path=/; max-age=0; SameSite=Strict';
              location.href = '/platform/login';
            }}
          >
            {t('logout')}
          </button>
        </header>
        {/*
          PHASE R3 - mobile navigation. The sidebar above is `hidden ... lg:block`, so on a
          phone there was previously NO way to move between console pages: the header offered
          a title and a logout button and nothing else. Measured, not assumed - this file had
          exactly one links.map and it lived inside the lg-only aside. The owner mostly uses a
          phone, so this is not cosmetic. A horizontally scrollable strip of the same links is
          the lightest fix: no drawer, no state, no extra JavaScript, and it reuses the same
          array so the two navigations cannot drift apart.
        */}
        <nav
          aria-label={t('platform')}
          className="flex gap-2 overflow-x-auto border-b border-white/10 bg-black/30 px-4 py-2 lg:hidden"
        >
          {links.map(([href, label]) => (
            <Link
              // PHASE R4 (RULE 3): py-2 made these 32px tall, under the 40px minimum touch target that
              // both Apple's HIG and Material specify. The R3 mobile nav existed and was
              // reachable, but a 32px target on a phone is a mis-tap generator, and the R4
              // browser proof measured it at exactly 32,32,32,32,32,32,32,32. py-3 plus an
              // explicit min-height and centred content makes it 40px and keeps it that way if
              // the text size ever changes.
              className={`flex min-h-[40px] shrink-0 items-center whitespace-nowrap rounded-xl px-3 py-3 text-xs ${
                pathname === href
                  ? 'bg-[#c5a059]/20 font-bold text-[#c5a059]'
                  : 'text-white/60 hover:bg-white/10'
              }`}
              href={href}
              key={href}
            >
              {label}
            </Link>
          ))}
        </nav>
        {children}
      </main>
    </div>
  );
}

export function PlatformShell({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  if (path === '/platform/login') return <>{children}</>;
  // PHASE R1.5 - StepUpProvider owns the single step-up dialog, so any console page
  // can ask for a fresh authenticator assertion through useStepUp() instead of
  // building its own.
  return (
    <StepUpProvider>
      <PlatformGuard>
        <Shell>{children}</Shell>
      </PlatformGuard>
    </StepUpProvider>
  );
}
