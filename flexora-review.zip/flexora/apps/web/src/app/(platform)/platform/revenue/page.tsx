'use client';
/**
 * FLEXORA Gym OS — Owner Console
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R4 (R4.12) — revenue, and its CSV export.
 *
 * BEFORE: 24 lines that fetched /platform/revenue/chart and printed the JSON into a <pre>. There
 * was no way to get the numbers out of the console at all, and the api had no revenue CSV - the
 * only CSV in the platform module was the audit export R3 added.
 *
 * The export carries NO member data, and that is structural rather than a filter: its source is
 * public.platform_list_subscriptions, the R2 SECURITY DEFINER function that by construction
 * returns gym identity, subscription timing and payment aggregates and nothing else. There is no
 * member column in it to leak. The column list is a fixed allowlist in the api, and the PII crawl
 * parses the downloaded file back into rows and runs every cell through the same crawler it uses
 * for JSON - which is the check R3 added for the audit export, extended here.
 */
import { useCallback, useEffect, useState } from 'react';
import { platformApi, platformDownload } from '../platform-guard';
import { AreaSeries, type SeriesPoint } from '../platform-charts';
import { useTranslation } from '@/lib/i18n';
import { PLAN_CODES, SUBSCRIPTION_STATUS_CODES, label } from '@/lib/i18n/codes';

type RevenueRow = Record<string, unknown> & {
  gymId?: string;
  gymName?: string;
  // /platform/subscriptions nests the gym under `gym` (R2 decision Q2: only id, name, slug and
  // status, never a whole Gym row), while the revenue CSV flattens it. The page accepts both.
  gym?: { id?: string; name?: string; slug?: string; status?: string };
  tier?: string | null;
  subscriptionStatus?: string | null;
  totalRevenue?: number | null;
  lastPaymentAt?: string | null;
  lastPaymentAmount?: number | null;
};

export default function PlatformRevenuePage() {
  const { t, lang } = useTranslation();
  const rtl = lang === 'ar';
  const locale = rtl ? 'ar-EG' : 'en-GB';

  const [series, setSeries] = useState<SeriesPoint[]>([]);
  const [rows, setRows] = useState<RevenueRow[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState('');
  const [plan, setPlan] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams();
      if (status) params.set('status', status);
      if (plan) params.set('plan', plan);
      const suffix = params.toString() ? `?${params.toString()}` : '';
      const [chart, list] = await Promise.all([
        platformApi('/platform/revenue/chart?months=12'),
        platformApi(`/platform/subscriptions?limit=100${suffix}`),
      ]);
      setSeries(Array.isArray(chart) ? (chart as SeriesPoint[]) : []);
      setRows(Array.isArray(list?.items) ? (list.items as RevenueRow[]) : []);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [status, plan]);

  useEffect(() => {
    void load();
  }, [load]);

  const money = (value: unknown) =>
    `${Math.round(Number(value) || 0).toLocaleString(locale)} ${rtl ? 'ج.م' : 'EGP'}`;

  const exportCsv = async () => {
    setNote(null);
    try {
      const params = new URLSearchParams();
      if (status) params.set('status', status);
      if (plan) params.set('plan', plan);
      const suffix = params.toString() ? `?${params.toString()}` : '';
      const result = await platformDownload(`/platform/revenue/export${suffix}`, 'flexora-platform-revenue.csv');
      setNote(
        result.truncated
          ? t('platform_revenue_export_truncated').replace('{rows}', result.rows ?? '?')
          : t('platform_revenue_export_done').replace('{rows}', result.rows ?? '?'),
      );
    } catch (e) {
      setNote((e as Error).message);
    }
  };

  return (
    <div className="p-4 sm:p-6">
      <h1 className="text-2xl font-black sm:text-3xl">{t('platform_revenue')}</h1>
      <p className="mt-1 text-sm text-white/60">{t('platform_revenue_intro')}</p>

      <div className="mt-4 flex flex-col gap-2 sm:flex-row">
        <button
          className="min-h-[44px] rounded-2xl border border-[#c5a059]/40 bg-[#c5a059]/10 px-4 text-sm font-bold text-[#c5a059]"
          onClick={() => void exportCsv()}
          type="button"
        >
          {t('platform_revenue_export_csv')}
        </button>
        <select
          aria-label={t('platform_gyms_status')}
          className="min-h-[44px] rounded-2xl border border-white/10 bg-black/50 px-3 text-sm"
          onChange={(event) => setStatus(event.target.value)}
          value={status}
        >
          <option value="">{t('platform_gyms_all_statuses')}</option>
          {SUBSCRIPTION_STATUS_CODES.map((value) => (
            <option key={value} value={value}>
              {label(value, 'subscriptionStatus', lang === 'en' ? 'en' : 'ar')}
            </option>
          ))}
        </select>
        <select
          aria-label={t('platform_grant_plan')}
          className="min-h-[44px] rounded-2xl border border-white/10 bg-black/50 px-3 text-sm"
          onChange={(event) => setPlan(event.target.value)}
          value={plan}
        >
          <option value="">{t('platform_gyms_all_plans')}</option>
          {PLAN_CODES.map((value) => (
            <option key={value} value={value}>
              {label(value, 'plan', lang === 'en' ? 'en' : 'ar')}
            </option>
          ))}
        </select>
      </div>

      {note && (
        <div className="mt-3 rounded-2xl border border-white/10 bg-white/5 p-3 text-xs text-white/70">{note}</div>
      )}
      {error && (
        <div className="mt-3 rounded-2xl border border-red-400/40 bg-red-500/10 p-3 text-sm text-red-200">{error}</div>
      )}

      <section className="mt-4 rounded-2xl border border-white/10 bg-black/40 p-4">
        <h2 className="text-sm font-bold text-white/70">{t('platform_overview_revenue_chart')}</h2>
        <div className="mt-3">
          {series.length ? (
            <AreaSeries label={t('platform_overview_revenue_chart')} locale={locale} points={series} rtl={rtl} valueFormat={money} />
          ) : (
            <div className="py-6 text-center text-xs text-white/40">{t('platform_overview_no_series')}</div>
          )}
        </div>
      </section>

      <div className="mt-4 space-y-2">
        {loading && <div className="p-4 text-sm text-white/50">{t('platform_loading')}</div>}
        {!loading && rows.length === 0 && (
          <div className="rounded-2xl border border-white/10 bg-black/30 p-6 text-center text-sm text-white/50">
            {t('platform_revenue_empty')}
          </div>
        )}
        {!loading &&
          rows.map((row) => (
            <article className="rounded-2xl border border-white/10 bg-black/40 p-4" key={String(row.gymId)}>
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="truncate font-bold">{String(row.gym?.name ?? row.gymName ?? row.gymId)}</div>
                  <div className="mt-0.5 truncate font-mono text-[11px] text-white/45">
                    {/* codes stay in the payload; the screen shows Arabic labels */}
                    {label(String(row.tier ?? ''), 'plan', lang === 'en' ? 'en' : 'ar')} ·{' '}
                    {label(String(row.subscriptionStatus ?? row.status ?? ''), 'subscriptionStatus', lang === 'en' ? 'en' : 'ar')}
                  </div>
                </div>
                <div className="shrink-0 text-end">
                  <div className="font-mono text-sm font-bold text-[#c5a059]">{money(row.totalRevenue)}</div>
                  <div className="text-[11px] text-white/40">{t('platform_revenue_total')}</div>
                </div>
              </div>
              <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-white/50">
                <span>
                  {t('platform_revenue_last_payment')}:{' '}
                  {row.lastPaymentAt ? new Date(String(row.lastPaymentAt)).toLocaleDateString(`${locale}-u-nu-latn`) : '—'}
                </span>
                <span>{money(row.lastPaymentAmount)}</span>
              </div>
            </article>
          ))}
      </div>
    </div>
  );
}
