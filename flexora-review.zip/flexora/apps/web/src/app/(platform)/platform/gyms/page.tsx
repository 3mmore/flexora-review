'use client';
/**
 * FLEXORA Gym OS — Owner Console
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R4 (R4.9) — the gyms list.
 *
 * BEFORE: 32 lines. It fetched /platform/gyms and printed the JSON into a <pre>. There was no
 * search box, no filter, no sort control and no pagination control, and tapping a gym did nothing
 * because there was no gym detail page to go to.
 *
 * All filtering, sorting and paging is SERVER-side. That is not a stylistic choice: with 25 rows
 * per page, sorting in the browser would sort the page the owner happens to be looking at and
 * leave every other page in the old order, which is not sorting. The api echoes the sort it
 * applied so what is rendered as "active" is what the database actually did.
 *
 * Mobile first: the controls are a collapsible panel of full-width inputs, gyms are cards rather
 * than a table, and the whole card is a link to the detail page so the tap target is the card and
 * not a small "view" button.
 */
import { useCallback, useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { platformApi } from '../platform-guard';
import { useTranslation } from '@/lib/i18n';
import { label } from '@/lib/i18n/codes';

type GymRow = {
  id: string;
  name?: string;
  slug?: string;
  status?: string;
  email?: string;
  phone?: string;
  memberCount?: number;
  ownerName?: string;
  tier?: string | null;
  subscriptionStatus?: string | null;
  currentPeriodEnd?: string | null;
  trialEndDate?: string | null;
  deletedAt?: string | null;
};

const STATUSES = ['ACTIVE', 'SUSPENDED', 'TRIALING', 'PENDING', 'DELETED'];
const PLANS = ['BASIC', 'PRO', 'ELITE'];

const STATUS_STYLE: Record<string, string> = {
  ACTIVE: 'bg-emerald-400/15 text-emerald-200',
  SUSPENDED: 'bg-amber-400/15 text-amber-200',
  TRIALING: 'bg-sky-400/15 text-sky-200',
  PENDING: 'bg-white/10 text-white/70',
  DELETED: 'bg-red-500/15 text-red-200',
};

export default function PlatformGymsPage() {
  const { t, lang } = useTranslation();
  const locale = lang === 'ar' ? 'ar-EG' : 'en-GB';

  const [draft, setDraft] = useState({ search: '', status: '', plan: '' });
  const [applied, setApplied] = useState({ search: '', status: '', plan: '' });
  const [sort, setSort] = useState('createdAt');
  const [dir, setDir] = useState<'asc' | 'desc'>('desc');
  const [sortColumns, setSortColumns] = useState<string[]>(['createdAt', 'name', 'status']);
  const [page, setPage] = useState(1);
  const [limit] = useState(25);
  const [rows, setRows] = useState<GymRow[]>([]);
  const [total, setTotal] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [showFilters, setShowFilters] = useState(false);

  const query = useMemo(() => {
    const params = new URLSearchParams();
    if (applied.search) params.set('search', applied.search);
    if (applied.status) params.set('status', applied.status);
    if (applied.plan) params.set('plan', applied.plan);
    params.set('sort', sort);
    params.set('dir', dir);
    params.set('page', String(page));
    params.set('limit', String(limit));
    return params.toString();
  }, [applied, sort, dir, page, limit]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await platformApi(`/platform/gyms?${query}`);
      setRows(Array.isArray(data?.items) ? (data.items as GymRow[]) : []);
      setTotal(Number(data?.total ?? 0));
      if (Array.isArray(data?.sortColumns) && data.sortColumns.length) {
        setSortColumns(data.sortColumns as string[]);
      }
    } catch (e) {
      setError((e as Error).message);
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [query]);

  useEffect(() => {
    void load();
  }, [load]);

  const totalPages = Math.max(1, Math.ceil(total / limit));
  const activeFilters = Object.values(applied).filter(Boolean).length;

  const dateLabel = (value?: string | null) => {
    if (!value) return '—';
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? String(value) : parsed.toLocaleDateString(`${locale}-u-nu-latn`);
  };

  return (
    <div className="p-4 sm:p-6">
      <h1 className="text-2xl font-black sm:text-3xl">{t('platform_gyms')}</h1>
      <p className="mt-1 text-sm text-white/60">
        {t('platform_gyms_intro').replace('{total}', String(total))}
      </p>

      <div className="mt-4 flex flex-col gap-2 sm:flex-row">
        {/* Search is always visible rather than hidden behind the filter toggle: it is the one
            control the owner reaches for first, and on a phone a buried search box means two
            taps before typing. */}
        <input
          aria-label={t('platform_gyms_search')}
          className="min-h-[44px] flex-1 rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-sm"
          onChange={(event) => setDraft((current) => ({ ...current, search: event.target.value }))}
          onKeyDown={(event) => {
            if (event.key === 'Enter') {
              setApplied({ ...draft });
              setPage(1);
            }
          }}
          placeholder={t('platform_gyms_search')}
          type="search"
          value={draft.search}
        />
        <button
          className="min-h-[44px] rounded-xl bg-[#c5a059] px-4 text-sm font-bold text-black"
          onClick={() => {
            setApplied({ ...draft });
            setPage(1);
          }}
          type="button"
        >
          {t('platform_gyms_search_action')}
        </button>
        <button
          className="min-h-[44px] rounded-xl border border-white/10 bg-white/5 px-4 text-sm text-white/80"
          onClick={() => setShowFilters((value) => !value)}
          type="button"
        >
          {t('platform_audit_filters')}
          {activeFilters > 0 ? ` (${activeFilters})` : ''}
        </button>
      </div>

      {showFilters && (
        <div className="mt-3 space-y-3 rounded-2xl border border-white/10 bg-black/40 p-4">
          <label className="block">
            <span className="block text-[11px] uppercase tracking-wide text-white/50">{t('platform_gyms_status')}</span>
            <select
              className="mt-1 min-h-[40px] w-full rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-sm"
              onChange={(event) => setDraft((current) => ({ ...current, status: event.target.value }))}
              value={draft.status}
            >
              <option value="">{t('platform_gyms_all_statuses')}</option>
              {STATUSES.map((status) => (
                <option key={status} value={status}>
                  {label(status, 'gymStatus', lang === 'en' ? 'en' : 'ar')}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="block text-[11px] uppercase tracking-wide text-white/50">{t('platform_grant_plan')}</span>
            <select
              className="mt-1 min-h-[40px] w-full rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-sm"
              onChange={(event) => setDraft((current) => ({ ...current, plan: event.target.value }))}
              value={draft.plan}
            >
              <option value="">{t('platform_gyms_all_plans')}</option>
              {PLANS.map((plan) => (
                <option key={plan} value={plan}>
                  {plan}
                </option>
              ))}
            </select>
          </label>
          {/* Sort is in the filter panel and ALSO as a one-tap control below, because changing
              the order is frequent enough that burying it entirely costs a tap every time. */}
          <label className="block">
            <span className="block text-[11px] uppercase tracking-wide text-white/50">{t('platform_gyms_sort')}</span>
            <select
              className="mt-1 min-h-[40px] w-full rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-sm"
              onChange={(event) => {
                setSort(event.target.value);
                setPage(1);
              }}
              value={sort}
            >
              {sortColumns.map((column) => (
                <option key={column} value={column}>
                  {t(`platform_gyms_sort_${column}`)}
                </option>
              ))}
            </select>
          </label>
          <div className="flex gap-2">
            <button
              className="min-h-[40px] flex-1 rounded-xl bg-[#c5a059] px-4 text-sm font-bold text-black"
              onClick={() => {
                setApplied({ ...draft });
                setPage(1);
              }}
              type="button"
            >
              {t('platform_apply')}
            </button>
            <button
              className="min-h-[40px] flex-1 rounded-xl border border-white/10 px-4 text-sm text-white/70"
              onClick={() => {
                const cleared = { search: '', status: '', plan: '' };
                setDraft(cleared);
                setApplied(cleared);
                setPage(1);
              }}
              type="button"
            >
              {t('platform_gyms_clear')}
            </button>
          </div>
        </div>
      )}

      <div className="mt-3 flex items-center justify-between gap-2 text-xs">
        <span className="text-white/45">
          {t('platform_gyms_sorted_by')} {t(`platform_gyms_sort_${sort}`)}
        </span>
        <button
          className="min-h-[40px] rounded-xl border border-white/10 bg-white/5 px-3 text-white/75"
          onClick={() => {
            setDir((current) => (current === 'asc' ? 'desc' : 'asc'));
            setPage(1);
          }}
          type="button"
        >
          {dir === 'asc' ? `↑ ${t('platform_gyms_ascending')}` : `↓ ${t('platform_gyms_descending')}`}
        </button>
      </div>

      {error && (
        <div className="mt-3 rounded-2xl border border-red-400/40 bg-red-500/10 p-3 text-sm text-red-200">
          {error}
        </div>
      )}

      <div className="mt-3 space-y-2">
        {loading && <div className="p-4 text-sm text-white/50">{t('platform_loading')}</div>}
        {!loading && rows.length === 0 && (
          <div className="rounded-2xl border border-white/10 bg-black/30 p-6 text-center text-sm text-white/50">
            {t('platform_gyms_empty')}
          </div>
        )}
        {!loading &&
          rows.map((gym) => (
            <Link
              className="block rounded-2xl border border-white/10 bg-black/40 p-4 active:bg-white/5"
              href={`/platform/gyms/${gym.id}`}
              key={gym.id}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="truncate font-bold">{gym.name ?? gym.id}</div>
                  <div className="mt-0.5 truncate font-mono text-[11px] text-white/45">{gym.slug}</div>
                </div>
                <span
                  className={`shrink-0 rounded-lg px-2 py-1 font-mono text-[11px] ${
                    STATUS_STYLE[String(gym.status)] ?? STATUS_STYLE.PENDING
                  }`}
                >
                  {label(String(gym.status ?? ''), 'gymStatus', lang === 'en' ? 'en' : 'ar')}
                </span>
              </div>
              <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-[11px] text-white/55">
                <span>
                  {t('platform_gyms_members')}: {(gym.memberCount ?? 0).toLocaleString(locale)}
                </span>
                <span>
                  {t('platform_grant_plan')}: {gym.tier ?? '—'}
                </span>
                <span className="truncate">
                  {t('platform_gyms_owner')}: {gym.ownerName ?? '—'}
                </span>
                <span className="truncate">
                  {gym.status === 'TRIALING'
                    ? `${t('platform_gyms_trial_ends')}: ${dateLabel(gym.trialEndDate)}`
                    : `${t('platform_gyms_period_ends')}: ${dateLabel(gym.currentPeriodEnd)}`}
                </span>
              </div>
            </Link>
          ))}
      </div>

      {total > 0 && (
        <div className="mt-4 flex items-center justify-between gap-3 text-sm">
          <button
            className="min-h-[44px] rounded-xl border border-white/10 px-4 text-white/70 disabled:opacity-40"
            disabled={page <= 1}
            onClick={() => setPage((value) => Math.max(1, value - 1))}
            type="button"
          >
            {t('platform_prev')}
          </button>
          <span className="text-center text-white/50">
            {t('platform_page_of')} {page} / {totalPages}
            <span className="block text-[11px] text-white/35">{total}</span>
          </span>
          <button
            className="min-h-[44px] rounded-xl border border-white/10 px-4 text-white/70 disabled:opacity-40"
            disabled={page >= totalPages}
            onClick={() => setPage((value) => Math.min(totalPages, value + 1))}
            type="button"
          >
            {t('platform_next')}
          </button>
        </div>
      )}
    </div>
  );
}
