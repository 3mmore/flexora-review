'use client';
/**
 * FLEXORA Gym OS — Owner Console
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R4 (R4.11) — the grant / extend-trial dialog.
 *
 * The three things the brief asks for, and how each is actually delivered:
 *
 * 1. A REASON is required. Enforced here (the Confirm button stays disabled) and on the server,
 *    which returns 400 without one. Client-side only would be a courtesy; server-side only would
 *    let the owner type a paragraph and lose it to a 400.
 *
 * 2. The RESULTING END DATE is shown BEFORE confirming. It is fetched from
 *    GET /platform/gyms/:id/grant-quote and displayed verbatim — not recomputed in the browser.
 *    Recomputing here would be a second implementation of "months from now" that could drift from
 *    the server's, and the whole point is that the date the owner reads is the date that gets
 *    written. The quote is re-fetched whenever the plan or the number of months changes, and the
 *    quoted value is sent back with the POST, which the server honours after checking it is still
 *    within tolerance. If the dialog sat open long enough for the quote to go stale, the server
 *    refuses and this component says so and re-quotes — it does not silently pick a new date.
 *
 * 3. AN IDEMPOTENCY KEY, generated ONCE PER INTENT. This is the part that is easy to get wrong.
 *    Generated per click, a double tap sends two different keys and the server correctly grants
 *    twice. Generated per dialog opening and kept for every retry of that same submission, a
 *    double tap — or a retry after a network hiccup — sends the same key and the server grants
 *    once. So the key is minted when the dialog opens for a given gym+plan+months intent, and it
 *    is REGENERATED only when the owner changes what they are granting or opens the dialog again.
 *    The button is also disabled while a request is in flight, which is belt and braces: the
 *    server's guarantee does not depend on the browser behaving.
 *
 * Mobile first: this is a bottom-anchored sheet at 375 px, not a centred modal, because a centred
 * modal on a phone puts the confirm button under the keyboard. Every control is full width and at
 * least 40 px tall.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { platformAction, platformApi, PlatformApiError } from './platform-guard';
import { useStepUp } from './platform-step-up';
import { subscriptionDate } from './subscription-display';
import { useTranslation } from '@/lib/i18n';

export type GrantMode = 'subscription' | 'trial';

export interface GrantDialogProps {
  gymId: string;
  gymName: string;
  mode: GrantMode;
  open: boolean;
  onClose: () => void;
  /** Called with the ledger row after a successful grant, applied or replayed. */
  onGranted: (result: { seq: number | null; idempotent: string }) => void;
}

const PLANS = ['BASIC', 'PRO', 'ELITE'];
const MONTH_CHOICES = [1, 2, 3, 6, 12];
const DAY_CHOICES = [7, 14, 30, 60, 90];
const REASON_MIN = 8;

/** A key per intent. crypto.randomUUID in a secure context, with a fallback that is still unique. */
function mintKey(prefix: string): string {
  const cryptoRef = typeof crypto !== 'undefined' ? crypto : undefined;
  if (cryptoRef && typeof cryptoRef.randomUUID === 'function') return `${prefix}-${cryptoRef.randomUUID()}`;
  const random = Array.from({ length: 16 }, () => Math.floor(Math.random() * 36).toString(36)).join('');
  return `${prefix}-${Date.now().toString(36)}-${random}`;
}

export function GrantDialog({ gymId, gymName, mode, open, onClose, onGranted }: GrantDialogProps) {
  const { t, lang } = useTranslation();
  const stepUp = useStepUp();
  const inFlight = useRef(false);
  const rtl = lang === 'ar';
  const locale = rtl ? 'ar-EG' : 'en-GB';

  const [plan, setPlan] = useState('PRO');
  const [months, setMonths] = useState(3);
  const [days, setDays] = useState(14);
  const [reason, setReason] = useState('');
  const [quote, setQuote] = useState<{ endDate: string; raw: any } | null>(null);
  const quoteRequest = useRef(0);
  const [quoting, setQuoting] = useState(false);
  const [quoteError, setQuoteError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [done, setDone] = useState<{ seq: number | null; idempotent: string } | null>(null);

  /**
   * The key for the CURRENT intent. Held in a ref rather than state because it must not change
   * when the component re-renders, and it must change only when the intent changes.
   */
  const keyRef = useRef<string>('');
  const intent = `${mode}:${gymId}:${plan}:${months}:${days}`;
  const lastIntent = useRef<string>('');

  const quotePath = useMemo(() => {
    if (mode === 'trial') return `/platform/gyms/${gymId}/trial-quote?days=${days}`;
    return `/platform/gyms/${gymId}/grant-quote?plan=${encodeURIComponent(plan)}&months=${months}`;
  }, [mode, gymId, plan, months, days]);

  // A new intent gets a new key; a retry of the same intent keeps the one it had.
  useEffect(() => {
    if (!open) { lastIntent.current = ''; return; }
    if (lastIntent.current !== intent) {
      lastIntent.current = intent;
      keyRef.current = mintKey(mode === 'trial' ? 'r4-trial' : 'r4-grant');
      setDone(null);
      setSubmitError(null);
    }
  }, [open, intent, mode]);

  // Reset the transient parts when the dialog is opened for a different gym.
  useEffect(() => {
    if (open) {
      setReason('');
      setQuote(null);
      setQuoteError(null);
      setDone(null);
      setSubmitError(null);
    }
  }, [open, gymId]);

  const fetchQuote = useCallback(async () => {
    const request = ++quoteRequest.current;
    setQuoting(true);
    setQuoteError(null);
    setQuote(null);
    try {
      const data = await platformApi(quotePath);
      const endDate = mode === 'trial' ? data?.trialEndDate : data?.currentPeriodEnd;
      if (typeof endDate !== 'string') throw new Error('the quote did not include an end date');
      if (request === quoteRequest.current) setQuote({ endDate, raw: data });
    } catch (error) {
      if (request === quoteRequest.current) setQuoteError((error as Error).message || 'quote failed');
    } finally {
      if (request === quoteRequest.current) setQuoting(false);
    }
  }, [quotePath, mode]);

  useEffect(() => {
    if (open) void fetchQuote();
    return () => { quoteRequest.current++; };
  }, [open, fetchQuote]);

  const endDateLabel = useMemo(() => {
    if (!quote) return '—';
    return subscriptionDate(quote.endDate, lang);
  }, [quote, lang]);

  const reasonOk = reason.trim().length >= REASON_MIN;
  const canSubmit = open && !!quote && !quoting && reasonOk && !submitting && !done;

  const submit = async () => {
    if (!canSubmit || !quote || inFlight.current) return;
    inFlight.current = true;
    setSubmitting(true);
    setSubmitError(null);
    const path =
      mode === 'trial'
        ? `/platform/gyms/${gymId}/extend-trial`
        : `/platform/gyms/${gymId}/grant-subscription`;
    const body =
      mode === 'trial'
        ? { days, reason: reason.trim(), idempotencyKey: keyRef.current, quotedTrialEndDate: quote.endDate }
        : {
            plan,
            months,
            reason: reason.trim(),
            idempotencyKey: keyRef.current,
            quotedPeriodEnd: quote.endDate,
          };
    try {
      const result = await platformAction(path, { method: 'POST', body: JSON.stringify(body) }, stepUp);
      const idempotent = String(result?.idempotent ?? 'applied');
      setDone({ seq: result?.seq ?? null, idempotent });
      onGranted({ seq: result?.seq ?? null, idempotent });
    } catch (error) {
      const response = error instanceof PlatformApiError && error.body && typeof error.body === 'object' ? error.body as { message?: unknown } : null;
      const message = typeof response?.message === 'string' ? response.message : (error as Error).message || 'request failed';
      setSubmitError(message);
      // A stale quote is recoverable without closing the dialog: re-quote and let the owner
      // confirm the NEW date, rather than silently writing a date nobody looked at.
      if (/quote/i.test(message) || /stale/i.test(message)) void fetchQuote();
    } finally {
      inFlight.current = false;
      setSubmitting(false);
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 sm:items-center" role="presentation" onClick={onClose}>
      <div
        aria-label={mode === 'trial' ? t('platform_grant_trial_title') : t('platform_grant_title')}
        className="max-h-[92vh] w-full overflow-y-auto rounded-t-3xl border border-white/10 bg-[var(--bg-base)] p-4 sm:max-w-md sm:rounded-3xl"
        onClick={(event) => event.stopPropagation()}
        role="dialog"
      >
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <h2 className="truncate text-lg font-black">
              {mode === 'trial' ? t('platform_grant_trial_title') : t('platform_grant_title')}
            </h2>
            <p className="mt-0.5 truncate text-xs text-white/55">{gymName}</p>
          </div>
          <button
            aria-label={t('platform_cancel')}
            className="min-h-[40px] min-w-[40px] shrink-0 rounded-xl border border-white/10 text-white/60"
            onClick={onClose}
            type="button"
          >
            ✕
          </button>
        </div>

        {mode === 'subscription' && (
          <>
            <label className="mt-4 block">
              <span className="block text-[11px] uppercase tracking-wide text-white/50">{t('platform_grant_plan')}</span>
              <select
                className="mt-1 min-h-[40px] w-full rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-sm"
                onChange={(event) => setPlan(event.target.value)}
                value={plan}
              >
                {PLANS.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </label>
            <div className="mt-3">
              <span className="block text-[11px] uppercase tracking-wide text-white/50">{t('platform_grant_months')}</span>
              <div className="mt-1 flex flex-wrap gap-2">
                {MONTH_CHOICES.map((choice) => (
                  <button
                    className={`min-h-[40px] min-w-[52px] rounded-xl border px-3 text-sm ${
                      months === choice
                        ? 'border-[#c5a059] bg-[#c5a059]/20 font-bold text-[#c5a059]'
                        : 'border-white/10 text-white/70'
                    }`}
                    key={choice}
                    onClick={() => setMonths(choice)}
                    type="button"
                  >
                    {choice}
                  </button>
                ))}
              </div>
            </div>
          </>
        )}

        {mode === 'trial' && (
          <div className="mt-4">
            <span className="block text-[11px] uppercase tracking-wide text-white/50">{t('platform_grant_days')}</span>
            <div className="mt-1 flex flex-wrap gap-2">
              {DAY_CHOICES.map((choice) => (
                <button
                  className={`min-h-[40px] min-w-[52px] rounded-xl border px-3 text-sm ${
                    days === choice
                      ? 'border-[#c5a059] bg-[#c5a059]/20 font-bold text-[#c5a059]'
                      : 'border-white/10 text-white/70'
                  }`}
                  key={choice}
                  onClick={() => setDays(choice)}
                  type="button"
                >
                  {choice}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* THE DATE. This block is the reason the dialog exists: the owner reads the exact end
            date the server will write, before committing to it. */}
        <div className="mt-4 rounded-2xl border border-[#c5a059]/40 bg-[#c5a059]/10 p-3">
          <div className="text-[11px] uppercase tracking-wide text-[#c5a059]/80">
            {mode === 'trial' ? t('platform_grant_trial_ends') : t('platform_grant_ends')}
          </div>
          {quoting && <div className="mt-1 text-sm text-white/60">{t('platform_loading')}</div>}
          {quoteError && (
            <div className="mt-1 text-sm text-red-200">
              {quoteError}
              <button className="ms-2 underline" onClick={() => void fetchQuote()} type="button">
                {t('platform_overview_retry')}
              </button>
            </div>
          )}
          {!quoting && !quoteError && (
            <div className="mt-1 break-words text-base font-black text-[#c5a059]">{endDateLabel}</div>
          )}
          {quote?.raw?.currentTier && (
            <div className="mt-1 text-[11px] text-white/50">
              {t('platform_grant_currently')}: {String(quote.raw.currentTier)}
              {quote.raw.previousPeriodEnd
                ? ` · ${new Date(String(quote.raw.previousPeriodEnd)).toLocaleDateString(`${locale}-u-nu-latn`)}`
                : ''}
            </div>
          )}
        </div>

        <label className="mt-4 block">
          <span className="block text-[11px] uppercase tracking-wide text-white/50">
            {t('platform_grant_reason')} <span className="text-[#c5a059]">*</span>
          </span>
          <textarea
            className="mt-1 min-h-[80px] w-full rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-sm"
            onChange={(event) => setReason(event.target.value)}
            placeholder={t('platform_grant_reason_hint')}
            value={reason}
          />
          <span className={`mt-1 block text-[11px] ${reasonOk ? 'text-white/40' : 'text-amber-200'}`}>
            {t('platform_grant_reason_count')
              .replace('{n}', String(reason.trim().length))
              .replace('{min}', String(REASON_MIN))}
          </span>
        </label>

        {submitError && (
          <div className="mt-3 rounded-xl border border-red-400/40 bg-red-500/10 p-3 text-xs text-red-200">
            {submitError}
          </div>
        )}

        {done && (
          <div className="mt-3 rounded-xl border border-emerald-400/30 bg-emerald-400/10 p-3 text-xs text-emerald-200">
            {done.idempotent === 'replayed'
              ? t('platform_grant_replayed')
              : t('platform_grant_applied').replace('{date}', endDateLabel)}
            {done.seq !== null ? ` · ${t('platform_alerts_audit_seq')} #${done.seq}` : ''}
          </div>
        )}

        <div className="mt-4 flex gap-2 pb-2">
          <button
            className="min-h-[44px] flex-1 rounded-xl border border-white/10 px-4 text-sm text-white/70"
            onClick={onClose}
            type="button"
          >
            {done ? t('platform_continue') : t('platform_cancel')}
          </button>
          <button
            className="min-h-[44px] flex-1 rounded-xl bg-[#c5a059] px-4 text-sm font-bold text-black disabled:opacity-40"
            disabled={!canSubmit}
            onClick={() => void submit()}
            type="button"
          >
            {submitting ? t('platform_grant_submitting') : t('platform_grant_confirm')}
          </button>
        </div>

        {/* Stated on screen rather than left implicit: this writes a permanent, append-only
            ledger row that names the administrator. */}
        <p className="pb-1 text-[11px] leading-relaxed text-white/35">{t('platform_grant_audit_note')}</p>
      </div>
    </div>
  );
}
