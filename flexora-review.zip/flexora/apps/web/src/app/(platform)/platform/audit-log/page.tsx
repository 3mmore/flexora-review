'use client';
/**
 * FLEXORA Gym OS — Owner Console
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R3 (R3.8) — the platform audit log.
 *
 * BEFORE this page (work/r3-evidence/00-before.log, B7) the file was 24 lines: it fetched
 * /platform/audit-log and printed the JSON into a <pre>. There was no filter, no search, no
 * date range, no pagination control, no CSV export and no way to verify the hash chain, and
 * grep for those six words in it returned 0 for every one of them.
 *
 * Mobile first, because the owner mostly uses a phone: the filter panel is a collapsible
 * block of full-width inputs, rows are cards rather than a table (a 14-column table at
 * 375 px is unreadable), and the two actions that matter - verify the chain and export -
 * are always visible above the list rather than buried in a menu.
 *
 * No chart library, no new dependency, no client-side state library. The list is
 * server-paginated and the filters are applied server-side by the same builder the CSV
 * export uses, so what is on screen and what is in the download cannot disagree.
 */
import { useCallback, useEffect, useMemo, useState } from 'react';
import { platformApi, platformDownload } from '../platform-guard';
import { useTranslation } from '@/lib/i18n';
import { label } from '@/lib/i18n/codes';

type AuditRow = {
  id: string;
  seq: number | null;
  createdAt: string;
  adminId: string;
  adminName: string;
  action: string;
  target: string | null;
  details: unknown;
  reason: string | null;
  ip: string | null;
  userAgent: string | null;
  stepUpUsed: boolean;
  beforeState: Record<string, unknown> | null;
  afterState: Record<string, unknown> | null;
  hash: string | null;
  prevHash: string | null;
};

type VerifyResult = {
  valid: boolean;
  rowsChecked: number;
  brokenRows: number;
  firstBrokenSeq: number | null;
  firstBrokenReason: string | null;
  headSeq: number | null;
  headHash: string | null;
  genesisHash: string;
  maxAlertedSeq: number | null;
  tailTruncated: boolean;
  checkedAt: string;
};

const EMPTY_FILTERS = { search: '', action: '', adminId: '', target: '', from: '', to: '' };

export default function PlatformAuditLogPage() {
  const { t, lang } = useTranslation();
  const [draft, setDraft] = useState(EMPTY_FILTERS);
  const [applied, setApplied] = useState(EMPTY_FILTERS);
  const [page, setPage] = useState(1);
  const [limit] = useState(25);
  const [data, setData] = useState<{ rows: AuditRow[]; total: number } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [openRow, setOpenRow] = useState<string | null>(null);
  const [verify, setVerify] = useState<VerifyResult | null>(null);
  const [verifying, setVerifying] = useState(false);
  const [verifyError, setVerifyError] = useState<string | null>(null);
  const [exportNote, setExportNote] = useState<string | null>(null);

  const query = useMemo(() => {
    const params = new URLSearchParams();
    for (const [key, value] of Object.entries(applied)) {
      if (value) params.set(key, value);
    }
    params.set('page', String(page));
    params.set('limit', String(limit));
    return params.toString();
  }, [applied, page, limit]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await platformApi(`/platform/audit-log?${query}`);
      setData({ rows: result?.rows ?? [], total: Number(result?.total ?? 0) });
    } catch (e) {
      setError((e as Error).message);
      setData(null);
    } finally {
      setLoading(false);
    }
  }, [query]);

  useEffect(() => {
    void load();
  }, [load]);

  const applyFilters = () => {
    setApplied({ ...draft });
    setPage(1);
  };

  const runVerify = async () => {
    setVerifying(true);
    setVerifyError(null);
    try {
      setVerify(await platformApi('/platform/audit-log/verify'));
    } catch (e) {
      setVerifyError((e as Error).message);
    } finally {
      setVerifying(false);
    }
  };

  const runExport = async () => {
    setExportNote(null);
    try {
      const params = new URLSearchParams();
      for (const [key, value] of Object.entries(applied)) {
        if (value) params.set(key, value);
      }
      const suffix = params.toString() ? `?${params.toString()}` : '';
      const result = await platformDownload(
        `/platform/audit-log/export${suffix}`,
        'flexora-platform-audit.csv',
      );
      setExportNote(
        result.truncated
          ? t('platform_audit_export_truncated')
              .replace('{rows}', result.rows ?? '?')
              .replace('{matching}', result.matching ?? '?')
          : t('platform_audit_export_done').replace('{rows}', result.rows ?? '?'),
      );
    } catch (e) {
      setExportNote((e as Error).message);
    }
  };

  const totalPages = data ? Math.max(1, Math.ceil(data.total / limit)) : 1;
  const activeFilterCount = Object.values(applied).filter(Boolean).length;

  return (
    <div className="p-4 sm:p-6">
      <h1 className="text-2xl font-black sm:text-3xl">{t('platform_audit_log')}</h1>
      <p className="mt-1 text-sm text-white/60">{t('platform_audit_intro')}</p>

      {/* The two actions that matter are always on screen, full width at 375 px. */}
      <div className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-3">
        <button
          className="rounded-2xl border border-[#c5a059]/40 bg-[#c5a059]/10 px-4 py-3 text-sm font-bold text-[#c5a059] active:scale-[0.99]"
          disabled={verifying}
          onClick={() => void runVerify()}
          type="button"
        >
          {verifying ? t('platform_audit_verifying') : t('platform_audit_verify_chain')}
        </button>
        <button
          className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-bold text-white/80 active:scale-[0.99]"
          onClick={() => void runExport()}
          type="button"
        >
          {t('platform_audit_export_csv')}
        </button>
        <button
          className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm font-bold text-white/80 active:scale-[0.99]"
          onClick={() => setShowFilters((value) => !value)}
          type="button"
        >
          {t('platform_audit_filters')}
          {activeFilterCount > 0 ? ` (${activeFilterCount})` : ''}
        </button>
      </div>

      {verify && (
        <div
          className={`mt-3 rounded-2xl border p-4 text-sm ${
            verify.valid && !verify.tailTruncated
              ? 'border-emerald-400/30 bg-emerald-400/10 text-emerald-200'
              : 'border-red-400/40 bg-red-500/10 text-red-200'
          }`}
        >
          <div className="font-black">
            {verify.valid && !verify.tailTruncated
              ? t('platform_audit_chain_valid')
              : t('platform_audit_chain_broken')}
          </div>
          <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-white/70 sm:grid-cols-3">
            <dt>{t('platform_audit_rows_checked')}</dt>
            <dd className="font-mono">{verify.rowsChecked}</dd>
            <dt>{t('platform_audit_broken_rows')}</dt>
            <dd className="font-mono">{verify.brokenRows}</dd>
            {verify.firstBrokenSeq !== null && (
              <>
                <dt>{t('platform_audit_first_broken')}</dt>
                <dd className="font-mono">
                  #{verify.firstBrokenSeq} ({verify.firstBrokenReason ?? '?'})
                </dd>
              </>
            )}
            <dt>{t('platform_audit_head')}</dt>
            <dd className="font-mono">#{verify.headSeq ?? '-'}</dd>
          </dl>
          {/* The head digest is shown so an operator can record it. A chain that later
              reports a LOWER head with valid=true has had rows removed from the end, which
              is the one thing a hash chain alone cannot see. */}
          <div className="mt-2 break-all font-mono text-[11px] text-white/50">
            head {verify.headHash ?? '-'}
          </div>
          {verify.tailTruncated && (
            <div className="mt-2 font-bold">
              {t('platform_audit_tail_truncated').replace('{seq}', String(verify.maxAlertedSeq ?? '?'))}
            </div>
          )}
          <div className="mt-1 text-[11px] text-white/40">
            {t('platform_audit_checked_at')} {verify.checkedAt}
          </div>
        </div>
      )}
      {verifyError && (
        <div className="mt-3 rounded-2xl border border-red-400/40 bg-red-500/10 p-3 text-sm text-red-200">
          {verifyError}
        </div>
      )}
      {exportNote && (
        <div className="mt-3 rounded-2xl border border-white/10 bg-white/5 p-3 text-sm text-white/70">
          {exportNote}
        </div>
      )}

      {showFilters && (
        <div className="mt-3 space-y-2 rounded-2xl border border-white/10 bg-black/40 p-4">
          {(
            [
              ['search', t('platform_audit_search'), 'text'],
              ['action', t('platform_audit_action'), 'text'],
              ['adminId', t('platform_audit_admin'), 'text'],
              ['target', t('platform_audit_target'), 'text'],
              ['from', t('platform_audit_from'), 'datetime-local'],
              ['to', t('platform_audit_to'), 'datetime-local'],
            ] as const
          ).map(([key, label, type]) => (
            <label className="block" key={key}>
              <span className="block text-[11px] uppercase tracking-wide text-white/50">{label}</span>
              <input
                className="mt-1 w-full rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-sm text-white outline-none focus:border-[#c5a059]/60"
                onChange={(event) => setDraft((current) => ({ ...current, [key]: event.target.value }))}
                type={type}
                value={draft[key]}
              />
            </label>
          ))}
          <div className="flex gap-2 pt-1">
            <button
              className="flex-1 rounded-xl bg-[#c5a059] px-4 py-2 text-sm font-bold text-black"
              onClick={applyFilters}
              type="button"
            >
              {t('platform_apply')}
            </button>
            <button
              className="flex-1 rounded-xl border border-white/10 px-4 py-2 text-sm text-white/70"
              onClick={() => {
                setDraft(EMPTY_FILTERS);
                setApplied(EMPTY_FILTERS);
                setPage(1);
              }}
              type="button"
            >
              {t('platform_cancel')}
            </button>
          </div>
        </div>
      )}

      {error && (
        <div className="mt-4 rounded-2xl border border-red-400/40 bg-red-500/10 p-4 text-sm text-red-200">
          {error}
        </div>
      )}

      <div className="mt-4 space-y-2">
        {loading && <div className="p-4 text-sm text-white/50">{t('platform_loading')}</div>}
        {!loading && data?.rows.length === 0 && (
          <div className="rounded-2xl border border-white/10 bg-black/30 p-6 text-center text-sm text-white/50">
            {t('platform_audit_empty')}
          </div>
        )}
        {!loading &&
          data?.rows.map((row) => {
            const open = openRow === row.id;
            return (
              <article className="rounded-2xl border border-white/10 bg-black/40 p-4" key={row.id}>
                <button
                  className="flex w-full items-start justify-between gap-3 text-left"
                  onClick={() => setOpenRow(open ? null : row.id)}
                  type="button"
                >
                  <span className="min-w-0">
                    <span className="block truncate font-mono text-sm font-bold text-[#c5a059]">
                      #{row.seq ?? '-'} {label(String(row.action ?? ''), 'auditAction', lang === 'en' ? 'en' : 'ar')}
                    </span>
                    <span className="mt-1 block truncate text-xs text-white/60">
                      {row.adminName} · {new Date(row.createdAt).toLocaleString()}
                    </span>
                  </span>
                  <span className="shrink-0 text-xs text-white/40">{open ? '−' : '+'}</span>
                </button>
                {open && (
                  <div className="mt-3 space-y-2 border-t border-white/10 pt-3 text-xs">
                    <Field label={t('platform_audit_target')} value={row.target} />
                    <Field label={t('platform_audit_reason')} value={row.reason} />
                    <Field label="IP" value={row.ip} />
                    <Field label={t('platform_audit_user_agent')} value={row.userAgent} />
                    <Field
                      label={t('platform_audit_step_up')}
                      value={row.stepUpUsed ? t('platform_yes') : t('platform_no')}
                    />
                    {row.beforeState && <Json label={t('platform_audit_before')} value={row.beforeState} />}
                    {row.afterState && <Json label={t('platform_audit_after')} value={row.afterState} />}
                    {row.details !== null && row.details !== undefined && (
                      <Json label={t('platform_audit_details')} value={row.details} />
                    )}
                    <Field label="hash" value={row.hash} mono />
                    <Field label="prevHash" value={row.prevHash} mono />
                  </div>
                )}
              </article>
            );
          })}
      </div>

      {data && data.total > 0 && (
        <div className="mt-4 flex items-center justify-between gap-3 text-sm">
          <button
            className="rounded-xl border border-white/10 px-4 py-2 text-white/70 disabled:opacity-40"
            disabled={page <= 1}
            onClick={() => setPage((value) => Math.max(1, value - 1))}
            type="button"
          >
            {t('platform_prev')}
          </button>
          <span className="text-white/50">
            {t('platform_page_of')} {page} / {totalPages} · {data.total}
          </span>
          <button
            className="rounded-xl border border-white/10 px-4 py-2 text-white/70 disabled:opacity-40"
            disabled={page >= totalPages}
            onClick={() => setPage((value) => Math.min(totalPages, value + 1))}
            type="button"
          >
            {t('platform_next')}
          </button>
        </div>
      )}
    </div>
  );
}

function Field({ label, value, mono }: { label: string; value: string | null; mono?: boolean }) {
  return (
    <div className="flex flex-wrap gap-x-2">
      <span className="text-white/40">{label}:</span>
      <span className={`min-w-0 break-all text-white/75 ${mono ? 'font-mono' : ''}`}>{value ?? '—'}</span>
    </div>
  );
}

function Json({ label, value }: { label: string; value: unknown }) {
  return (
    <div>
      <div className="text-white/40">{label}:</div>
      <pre className="mt-1 overflow-auto rounded-xl bg-black/50 p-2 font-mono text-[11px] text-white/70">
        {JSON.stringify(value, null, 2)}
      </pre>
    </div>
  );
}
