/**
 * FLEXORA Gym OS — Owner Console
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R4 (R4.1, R4.2, R4.6) — the inline SVG chart primitives.
 *
 * Rendered with react-dom/server rather than a DOM testing library on purpose: no new
 * dependency, and these components are pure (props in, SVG out), so static markup is the whole
 * of their observable behaviour. If they ever grow state or effects this file should move to a
 * DOM environment, and that change should be visible.
 *
 * The invariant that matters most is asserted across every render below: NOTHING may produce
 * "NaN" or "Infinity" in the markup. A chart dividing by a zero value-range is how a dashboard
 * silently goes blank, and the owner reads this page on a phone where a missing chart looks
 * identical to a platform with no data.
 */
import { renderToStaticMarkup } from 'react-dom/server';
import { AreaSeries, BarSeries, DeltaBadge, SegmentBar, type SeriesPoint } from './platform-charts';

const twelveMonths = (values: number[]): SeriesPoint[] =>
  values.map((value, index) => ({ month: `2026-${String(index + 1).padStart(2, '0')}`, value }));

function assertFiniteMarkup(markup: string, what: string): void {
  expect({ what, hasNaN: markup.includes('NaN') }).toEqual({ what, hasNaN: false });
  expect({ what, hasInfinity: /Infinity/.test(markup) }).toEqual({ what, hasInfinity: false });
  expect({ what, hasUndefined: markup.includes('undefined') }).toEqual({ what, hasUndefined: false });
}

describe('R4.6 — the console charts are inline SVG', () => {
  it('renders an <svg> with a path, and no chart library is involved', () => {
    const markup = renderToStaticMarkup(
      <AreaSeries label="Revenue by month" points={twelveMonths([10, 20, 15, 40, 35, 60, 55, 70, 65, 80, 90, 100])} valueFormat={(v) => `${v}`} />,
    );
    expect(markup).toContain('<svg');
    expect(markup).toContain('<path');
    expect(markup).toContain('aria-label="Revenue by month"');
    // accessible: a screen reader gets a title, not just a shape
    expect(markup).toContain('<title>Revenue by month</title>');
    assertFiniteMarkup(markup, 'AreaSeries, twelve rising values');
  });

  it('R4.2 — rtl mirrors the geometry, and the month labels move with it', () => {
    const points = twelveMonths([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]);
    const ltr = renderToStaticMarkup(<AreaSeries label="s" locale="en" points={points} rtl={false} valueFormat={(v) => `${v}`} />);
    const rtl = renderToStaticMarkup(<AreaSeries label="s" locale="ar-EG" points={points} rtl valueFormat={(v) => `${v}`} />);

    expect(ltr).not.toBe(rtl);
    // In LTR the first (oldest) point sits at the left edge; in RTL it must sit at the right.
    const firstX = (markup: string) => Number(/<path d="M([0-9.]+)/.exec(markup)?.[1] ?? -1);
    expect(firstX(ltr)).toBeLessThan(20);
    expect(firstX(rtl)).toBeGreaterThan(300);
    assertFiniteMarkup(rtl, 'AreaSeries, rtl');
  });

  it('an EMPTY series renders its axis instead of vanishing', () => {
    const markup = renderToStaticMarkup(<AreaSeries label="Revenue by month" points={[]} valueFormat={(v) => `${v}`} />);
    expect(markup).toContain('<svg');
    expect(markup).toContain('<line');
    expect(markup).not.toContain('<path');
    assertFiniteMarkup(markup, 'AreaSeries, empty');
  });

  it('a FLAT series (zero value range) does not divide by zero', () => {
    const markup = renderToStaticMarkup(
      <AreaSeries label="s" points={twelveMonths([5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5])} valueFormat={(v) => `${v}`} />,
    );
    expect(markup).toContain('<path');
    assertFiniteMarkup(markup, 'AreaSeries, flat');
  });

  it('an ALL-ZERO series still draws, and a single point does not produce a broken path', () => {
    const zeros = renderToStaticMarkup(<AreaSeries label="s" points={twelveMonths([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])} valueFormat={(v) => `${v}`} />);
    assertFiniteMarkup(zeros, 'AreaSeries, all zero');
    expect(zeros).toContain('<path');

    const single = renderToStaticMarkup(<AreaSeries label="s" points={[{ month: '2026-11', value: 42 }]} valueFormat={(v) => `${v}`} />);
    assertFiniteMarkup(single, 'AreaSeries, one point');
    expect(single).toContain('<circle');
  });

  it('a negative or non-numeric value is clamped, not plotted below the axis', () => {
    const markup = renderToStaticMarkup(
      <AreaSeries label="s" points={[{ month: '2026-01', value: -50 }, { month: '2026-02', value: Number.NaN }, { month: '2026-03', value: 30 }]} valueFormat={(v) => `${v}`} />,
    );
    assertFiniteMarkup(markup, 'AreaSeries, negative and NaN inputs');
    // every plotted y must be inside the viewBox height (132 by default)
    const ys = [...markup.matchAll(/<circle cx="[0-9.]+" cy="([0-9.]+)"/g)].map((match) => Number(match[1]));
    expect(ys.length).toBe(3);
    for (const y of ys) {
      expect(y).toBeGreaterThanOrEqual(0);
      expect(y).toBeLessThanOrEqual(132);
    }
  });

  it('BarSeries draws one bar per month and mirrors for rtl', () => {
    const points = twelveMonths([0, 1, 0, 2, 3, 0, 1, 4, 0, 2, 1, 5]);
    const ltr = renderToStaticMarkup(<BarSeries label="New gyms per month" locale="en" points={points} rtl={false} />);
    const rtl = renderToStaticMarkup(<BarSeries label="New gyms per month" locale="ar-EG" points={points} rtl />);
    expect((ltr.match(/<rect/g) ?? []).length).toBe(12);
    expect((rtl.match(/<rect/g) ?? []).length).toBe(12);
    expect(ltr).not.toBe(rtl);
    assertFiniteMarkup(ltr, 'BarSeries, ltr');
    assertFiniteMarkup(rtl, 'BarSeries, rtl');
  });

  it('BarSeries with no data at all renders the axis and no bars', () => {
    const markup = renderToStaticMarkup(<BarSeries label="s" points={[]} />);
    expect(markup).toContain('<line');
    expect(markup).not.toContain('<rect');
    assertFiniteMarkup(markup, 'BarSeries, empty');
  });

  it('SegmentBar omits an empty tier, labels the others, and degrades when the total is zero', () => {
    const markup = renderToStaticMarkup(
      <SegmentBar label="Plans in use" segments={[{ key: 'BASIC', label: 'BASIC', value: 3 }, { key: 'PRO', label: 'PRO', value: 0 }, { key: 'ELITE', label: 'ELITE', value: 1 }]} />,
    );
    // two non-zero segments -> two rects; the zero tier contributes nothing rather than a
    // zero-width sliver that a screen reader would still announce
    expect((markup.match(/<rect/g) ?? []).length).toBe(2);
    expect(markup).toContain('BASIC: 3');
    expect(markup).toContain('ELITE: 1');
    expect(markup).not.toContain('PRO: 0');
    assertFiniteMarkup(markup, 'SegmentBar, one empty tier');

    const empty = renderToStaticMarkup(
      <SegmentBar label="Plans in use" segments={[{ key: 'BASIC', label: 'BASIC', value: 0 }, { key: 'PRO', label: 'PRO', value: 0 }]} />,
    );
    expect((empty.match(/<rect/g) ?? []).length).toBe(1);
    assertFiniteMarkup(empty, 'SegmentBar, all zero');
  });

  it('DeltaBadge never renders a percentage against zero', () => {
    const noPrevious = renderToStaticMarkup(
      <DeltaBadge current={500} downLabel="down" flatLabel="No previous month to compare" previous={0} upLabel="up" />,
    );
    expect(noPrevious).toContain('No previous month to compare');
    expect(noPrevious).not.toContain('Infinity');
    expect(noPrevious).not.toContain('%');

    const rising = renderToStaticMarkup(<DeltaBadge current={150} downLabel="vs last month" flatLabel="flat" previous={100} upLabel="vs last month" />);
    expect(rising).toContain('▲');
    expect(rising).toContain('50%');

    const falling = renderToStaticMarkup(<DeltaBadge current={50} downLabel="vs last month" flatLabel="flat" previous={100} upLabel="vs last month" />);
    expect(falling).toContain('▼');
    expect(falling).toContain('50%');

    const unchanged = renderToStaticMarkup(<DeltaBadge current={100} downLabel="d" flatLabel="flat" previous={100} upLabel="u" />);
    expect(unchanged).toContain('flat');
    expect(unchanged).not.toContain('▲');
  });

  it('a negative previous month is handled by magnitude, so the sign of the change stays right', () => {
    // A refund month can make the previous figure negative. Dividing by the raw value would
    // flip the arrow, which would tell the owner revenue fell when it rose.
    const markup = renderToStaticMarkup(<DeltaBadge current={100} downLabel="down" flatLabel="flat" previous={-50} upLabel="up" />);
    expect(markup).toContain('▲');
    assertFiniteMarkup(markup, 'DeltaBadge, negative previous');
  });

  it('R4.1 — no chart library is a dependency of the web app', () => {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const pkg = require('../../../../../../package.json') as { dependencies?: Record<string, string>; devDependencies?: Record<string, string> };
    const all = { ...(pkg.dependencies ?? {}), ...(pkg.devDependencies ?? {}) };
    const offenders = Object.keys(all).filter((name) => /chart|recharts|d3|victory|nivo|visx|plotly|highcharts|apexcharts|echarts/i.test(name));
    expect(offenders).toEqual([]);
  });
});
