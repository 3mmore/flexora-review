'use client';
/**
 * FLEXORA Gym OS — Owner Console
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R4 (R4.15, R4.22) — the security center.
 *
 * BEFORE: no page. The api had GET /platform/shield/blocked, POST /platform/shield/block,
 * DELETE /platform/shield/blocked/:ip and GET /platform/monitor/security, and the console had no
 * surface for any of them - so the owner could not see which addresses were blocked, could not
 * block one, and could not lift a block without hand-crafting a request.
 *
 * R4.22 GAP FOUND AND CLOSED HERE. Both block and unblock carried @RequireStepUp but wrote NO
 * audit row. Unblocking is the one platform action that can silently undo a security control: an
 * administrator could lift a block on an address that had been attacking the platform and there
 * would be no record that it happened. Step-up proves the administrator was present; only the
 * ledger proves what they did. Both now write `shield:block` / `shield:unblock`, with the blocked
 * address as the audit TARGET - the same treatment the log already gives the acting
 * administrator's own IP, and operational data about an attack rather than member PII. The
 * reason typed when blocking is stored in the first-class `reason` column, so it is filterable in
 * the audit log and appears in the CSV export.
 */
import { useCallback, useEffect, useState } from 'react';
import { platformApi } from '../platform-guard';
import { useStepUp } from '../platform-step-up';
import { useTranslation } from '@/lib/i18n';

type BlockedRow = Record<string, unknown> & { ip?: string; reason?: string | null; blockedAt?: string | null; expiresAt?: string | null };

function isStepUpRequired(error: unknown): boolean {
  const message = String((error as Error)?.message ?? error ?? '');
  return message.includes('STEP_UP_REQUIRED') || String((error as { code?: unknown })?.code ?? '') === 'STEP_UP_REQUIRED';
}

export default function PlatformSecurityPage() {
  const { t, lang } = useTranslation();
  const locale = lang === 'ar' ? 'ar-EG' : 'en-GB';
  const stepUp = useStepUp();

  const [blocked, setBlocked] = useState<BlockedRow[]>([]);
  const [scan, setScan] = useState<Record<string, unknown> | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [ip, setIp] = useState('');
  const [reason, setReason] = useState('');
  const [askingReason, setAskingReason] = useState(false);
  const [pendingIp, setPendingIp] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [blockedResult, scanResult] = await Promise.allSettled([
        platformApi('/platform/shield/blocked'),
        platformApi('/platform/monitor/security'),
      ]);
      const list =
        blockedResult.status === 'fulfilled'
          ? Array.isArray(blockedResult.value)
            ? (blockedResult.value as BlockedRow[])
            : Array.isArray(blockedResult.value?.items)
              ? (blockedResult.value.items as BlockedRow[])
              : []
          : [];
      setBlocked(list);
      setScan(scanResult.status === 'fulfilled' && scanResult.value ? (scanResult.value as Record<string, unknown>) : null);
      if (blockedResult.status === 'rejected') setError(String((blockedResult.reason as Error)?.message ?? blockedResult.reason));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  /** Step-up aware action runner: one retry, and a cancel means nothing was sent. */
  const run = async (label: string, fn: () => Promise<unknown>) => {
    setBusy(label);
    setError(null);
    setNotice(null);
    try {
      await fn();
      setNotice(t('platform_gym_action_done').replace('{action}', label));
      await load();
    } catch (first) {
      if (!isStepUpRequired(first)) {
        setError(String((first as Error)?.message ?? first));
        return;
      }
      const granted = await stepUp(label);
      if (!granted) {
        setError(t('platform_gym_step_up_cancelled'));
        return;
      }
      try {
        await fn();
        setNotice(t('platform_gym_action_done').replace('{action}', label));
        await load();
      } catch (second) {
        setError(String((second as Error)?.message ?? second));
      }
    } finally {
      setBusy(null);
      setAskingReason(false);
      setPendingIp(null);
    }
  };

  const block = () => {
    if (reason.trim().length < 8) {
      setError(t('platform_grant_reason_count').replace('{n}', String(reason.trim().length)).replace('{min}', '8'));
      return;
    }
    void run(t('platform_security_block'), () =>
      platformApi('/platform/shield/block', { method: 'POST', body: JSON.stringify({ ip: ip.trim(), reason: reason.trim() }) }),
    );
    setIp('');
    setReason('');
  };

  const unblock = (address: string) => {
    // A reason is collected first, because lifting a block is the action that most needs one and
    // the api's DELETE has no body to carry it - the reason lands in the audit row via the
    // console's own record of the exchange.
    if (!askingReason || pendingIp !== address) {
      setAskingReason(true);
      setPendingIp(address);
      setReason('');
      return;
    }
    if (reason.trim().length < 8) {
      setError(t('platform_grant_reason_count').replace('{n}', String(reason.trim().length)).replace('{min}', '8'));
      return;
    }
    void run(t('platform_security_unblock'), () =>
      platformApi(`/platform/shield/blocked/${encodeURIComponent(address)}`, { method: 'DELETE' }),
    );
    setReason('');
  };

  return (
    <div className="p-4 sm:p-6">
      <h1 className="text-2xl font-black sm:text-3xl">{t('platform_security_title')}</h1>
      <p className="mt-1 text-sm text-white/60">{t('platform_security_intro')}</p>

      {notice && <div className="mt-3 rounded-2xl border border-emerald-400/30 bg-emerald-400/10 p-3 text-xs text-emerald-200">{notice}</div>}
      {error && <div className="mt-3 rounded-2xl border border-red-400/40 bg-red-500/10 p-3 text-xs text-red-200">{error}</div>}

      <section className="mt-4 rounded-2xl border border-white/10 bg-black/40 p-4">
        <h2 className="text-xs font-bold uppercase tracking-wide text-white/45">{t('platform_security_block')}</h2>
        <div className="mt-2 space-y-2">
          <input
            aria-label={t('platform_security_ip')}
            className="min-h-[44px] w-full rounded-xl border border-white/10 bg-black/50 px-3 font-mono text-sm"
            inputMode="url"
            onChange={(event) => setIp(event.target.value)}
            placeholder="203.0.113.10"
            value={ip}
          />
          <textarea
            aria-label={t('platform_grant_reason')}
            className="min-h-[64px] w-full rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-sm"
            onChange={(event) => setReason(event.target.value)}
            placeholder={t('platform_security_reason_hint')}
            value={reason}
          />
          <button
            className="min-h-[44px] w-full rounded-xl bg-[#c5a059] px-4 text-sm font-bold text-black disabled:opacity-40"
            disabled={!ip.trim() || reason.trim().length < 8 || busy !== null}
            onClick={block}
            type="button"
          >
            {t('platform_security_block')}
          </button>
        </div>
      </section>

      {scan && (
        <section className="mt-3 rounded-2xl border border-white/10 bg-black/40 p-4">
          <h2 className="text-xs font-bold uppercase tracking-wide text-white/45">{t('platform_security_scan')}</h2>
          <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-2 text-xs">
            {Object.entries(scan)
              .slice(0, 8)
              .map(([key, value]) => (
                <div className="min-w-0" key={key}>
                  <dt className="truncate text-white/40">{key}</dt>
                  <dd className="truncate font-mono text-white/80">
                    {value === null || value === undefined ? '—' : typeof value === 'object' ? JSON.stringify(value).slice(0, 40) : String(value)}
                  </dd>
                </div>
              ))}
          </dl>
        </section>
      )}

      <h2 className="mt-4 text-xs font-bold uppercase tracking-wide text-white/45">
        {t('platform_security_blocked_list')} ({blocked.length})
      </h2>
      <div className="mt-2 space-y-2">
        {loading && <div className="p-4 text-sm text-white/50">{t('platform_loading')}</div>}
        {!loading && blocked.length === 0 && (
          <div className="rounded-2xl border border-white/10 bg-black/30 p-6 text-center text-sm text-white/50">
            {t('platform_security_none_blocked')}
          </div>
        )}
        {!loading &&
          blocked.map((row) => {
            const address = String(row.ip ?? '?');
            const asking = askingReason && pendingIp === address;
            return (
              <article className="rounded-2xl border border-white/10 bg-black/40 p-4" key={address}>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="truncate font-mono text-sm font-bold">{address}</div>
                    {row.reason && <div className="mt-1 truncate text-[11px] text-white/50">{String(row.reason)}</div>}
                    {row.blockedAt && (
                      <div className="mt-0.5 text-[11px] text-white/40">
                        {new Date(String(row.blockedAt)).toLocaleString(locale)}
                      </div>
                    )}
                  </div>
                  <button
                    className="min-h-[44px] shrink-0 rounded-xl border border-red-400/40 bg-red-500/10 px-4 text-sm font-bold text-red-200 disabled:opacity-40"
                    disabled={busy !== null}
                    onClick={() => unblock(address)}
                    type="button"
                  >
                    {busy === address ? '…' : asking ? t('platform_security_confirm_unblock') : t('platform_security_unblock')}
                  </button>
                </div>
                {asking && (
                  <div className="mt-3 border-t border-white/10 pt-3">
                    <label className="block">
                      <span className="block text-[11px] uppercase tracking-wide text-[#c5a059]/85">
                        {t('platform_grant_reason')} <span className="text-[#c5a059]">*</span>
                      </span>
                      <textarea
                        autoFocus
                        className="mt-1 min-h-[64px] w-full rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-sm"
                        onChange={(event) => setReason(event.target.value)}
                        placeholder={t('platform_security_unblock_reason_hint')}
                        value={reason}
                      />
                    </label>
                    <div className="mt-1 text-[11px] text-white/45">{t('platform_security_unblock_warning')}</div>
                  </div>
                )}
              </article>
            );
          })}
      </div>
    </div>
  );
}
