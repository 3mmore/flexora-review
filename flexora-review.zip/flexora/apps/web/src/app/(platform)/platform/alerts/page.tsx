'use client';
/**
 * FLEXORA Gym OS — Owner Console
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R3 (R3.10) — the platform alert outbox.
 *
 * BEFORE R3 there was no such page and no such table: a platform alert was a single call to
 * notifications.whatsapp(null, PLATFORM_OWNER_PHONE, ...), which deliberately writes no
 * database row, so if the owner's number was not configured the only evidence was a line in
 * the api log (work/r3-evidence/00-before.log, B8: zero owner-channel calls in any of the
 * three files that implement the five alert events).
 *
 * Owner decision A3.4 is the reason the banner at the top of this page exists: "if no
 * channel is configured, that must be visible in the console as a warning, not only in a log
 * line." It names the missing variables and never shows a value.
 *
 * Mobile first for the same reason as the audit page: cards, not a table, and the banner is
 * the first thing on screen at 375 px.
 */
import { useCallback, useEffect, useMemo, useState } from 'react';
import { platformApi } from '../platform-guard';
import { useTranslation } from '@/lib/i18n';

type AlertRow = {
  id: string;
  type: string;
  severity: string;
  targetKind: string;
  targetId: string | null;
  auditSeq: number | null;
  status: string;
  attempts: number;
  maxAttempts: number;
  errorCode: string | null;
  createdAt: string;
  lastAttemptAt: string | null;
  sentAt: string | null;
};

type ChannelState = { configured: boolean; missing: string[] };

const SEVERITY_STYLE: Record<string, string> = {
  danger: 'border-red-400/40 bg-red-500/10 text-red-200',
  warning: 'border-amber-400/40 bg-amber-400/10 text-amber-200',
  info: 'border-white/10 bg-white/5 text-white/75',
};

const STATUS_STYLE: Record<string, string> = {
  SENT: 'bg-emerald-400/15 text-emerald-200',
  PENDING: 'bg-white/10 text-white/70',
  FAILED: 'bg-red-500/15 text-red-200',
  NO_CHANNEL: 'bg-amber-400/15 text-amber-200',
};

export default function PlatformAlertsPage() {
  const { t } = useTranslation();
  const [rows, setRows] = useState<AlertRow[]>([]);
  const [total, setTotal] = useState(0);
  const [channel, setChannel] = useState<ChannelState | null>(null);
  const [page, setPage] = useState(1);
  const [limit] = useState(25);
  const [type, setType] = useState('');
  const [status, setStatus] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const query = useMemo(() => {
    const params = new URLSearchParams();
    if (type) params.set('type', type);
    if (status) params.set('status', status);
    params.set('page', String(page));
    params.set('limit', String(limit));
    return params.toString();
  }, [type, status, page, limit]);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await platformApi(`/platform/alerts?${query}`);
      setRows(result?.rows ?? []);
      setTotal(Number(result?.total ?? 0));
      setChannel(result?.channel ?? null);
    } catch (e) {
      setError((e as Error).message);
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [query]);

  useEffect(() => {
    void load();
  }, [load]);

  const totalPages = Math.max(1, Math.ceil(total / limit));

  return (
    <div className="p-4 sm:p-6">
      <h1 className="text-2xl font-black sm:text-3xl">{t('platform_alerts_title')}</h1>
      <p className="mt-1 text-sm text-white/60">{t('platform_alerts_intro')}</p>

      {/* A3.4 - the warning is the first thing on the page, and it names variables only. */}
      {channel && !channel.configured && (
        <div className="mt-4 rounded-2xl border border-amber-400/50 bg-amber-400/10 p-4 text-sm text-amber-100">
          <div className="font-black">{t('platform_alerts_no_channel')}</div>
          <p className="mt-1 text-amber-100/80">{t('platform_alerts_no_channel_body')}</p>
          <ul className="mt-2 space-y-1 font-mono text-xs">
            {channel.missing.map((name) => (
              <li key={name}>· {name}</li>
            ))}
          </ul>
        </div>
      )}
      {channel?.configured && (
        <div className="mt-4 rounded-2xl border border-emerald-400/30 bg-emerald-400/10 p-3 text-sm text-emerald-200">
          {t('platform_alerts_channel_ready')}
        </div>
      )}

      <div className="mt-4 flex flex-col gap-2 sm:flex-row">
        <select
          className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-sm text-white"
          onChange={(event) => {
            setType(event.target.value);
            setPage(1);
          }}
          value={type}
        >
          <option value="">{t('platform_alerts_all_types')}</option>
          {['ADMIN_LOGIN_BURST', 'ADMIN_NEW_DEVICE', 'ADMIN_CREATED', 'ADMIN_REMOVED',
            'SUBSCRIPTION_GRANTED', 'GYM_DELETED', 'AUDIT_WRITE_FAILED', 'ALERT_SEND_FAILED'].map(
            (value) => (
              <option key={value} value={value}>
                {value}
              </option>
            ),
          )}
        </select>
        <select
          className="rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-sm text-white"
          onChange={(event) => {
            setStatus(event.target.value);
            setPage(1);
          }}
          value={status}
        >
          <option value="">{t('platform_alerts_all_statuses')}</option>
          {['PENDING', 'SENT', 'FAILED', 'NO_CHANNEL'].map((value) => (
            <option key={value} value={value}>
              {value}
            </option>
          ))}
        </select>
        <button
          className="rounded-xl border border-white/10 bg-white/5 px-4 py-2 text-sm text-white/80"
          onClick={() => void load()}
          type="button"
        >
          {t('platform_refresh')}
        </button>
      </div>

      {error && (
        <div className="mt-4 rounded-2xl border border-red-400/40 bg-red-500/10 p-4 text-sm text-red-200">
          {error}
        </div>
      )}

      <div className="mt-4 space-y-2">
        {loading && <div className="p-4 text-sm text-white/50">{t('platform_loading')}</div>}
        {!loading && rows.length === 0 && (
          <div className="rounded-2xl border border-white/10 bg-black/30 p-6 text-center text-sm text-white/50">
            {t('platform_alerts_empty')}
          </div>
        )}
        {!loading &&
          rows.map((row) => (
            <article
              className={`rounded-2xl border p-4 ${SEVERITY_STYLE[row.severity] ?? SEVERITY_STYLE.info}`}
              key={row.id}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="truncate font-mono text-sm font-bold">{row.type}</div>
                  <div className="mt-1 text-xs text-white/55">
                    {new Date(row.createdAt).toLocaleString()} · {row.targetKind}
                    {row.auditSeq !== null ? ` · ${t('platform_alerts_audit_seq')} #${row.auditSeq}` : ''}
                  </div>
                </div>
                <span
                  className={`shrink-0 rounded-lg px-2 py-1 font-mono text-[11px] ${
                    STATUS_STYLE[row.status] ?? STATUS_STYLE.PENDING
                  }`}
                >
                  {row.status}
                </span>
              </div>
              <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-white/55">
                <span>
                  {t('platform_alerts_attempts')}: {row.attempts}/{row.maxAttempts}
                </span>
                {row.errorCode && (
                  <span className="font-mono">
                    {t('platform_alerts_error_code')}: {row.errorCode}
                  </span>
                )}
                {row.sentAt && <span>{t('platform_alerts_sent_at')}: {new Date(row.sentAt).toLocaleString()}</span>}
              </div>
              {/* A3.1 - what is deliberately NOT here: the owner's phone number, the rendered
                  message body, and any provider's raw error text. Only the error code above. */}
            </article>
          ))}
      </div>

      {total > 0 && (
        <div className="mt-4 flex items-center justify-between gap-3 text-sm">
          <button
            className="rounded-xl border border-white/10 px-4 py-2 text-white/70 disabled:opacity-40"
            disabled={page <= 1}
            onClick={() => setPage((value) => Math.max(1, value - 1))}
            type="button"
          >
            {t('platform_prev')}
          </button>
          <span className="text-white/50">
            {t('platform_page_of')} {page} / {totalPages} · {total}
          </span>
          <button
            className="rounded-xl border border-white/10 px-4 py-2 text-white/70 disabled:opacity-40"
            disabled={page >= totalPages}
            onClick={() => setPage((value) => Math.min(totalPages, value + 1))}
            type="button"
          >
            {t('platform_next')}
          </button>
        </div>
      )}
    </div>
  );
}
