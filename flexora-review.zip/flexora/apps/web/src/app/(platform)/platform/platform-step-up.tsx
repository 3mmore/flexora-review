'use client';
/**
 * FLEXORA Gym OS - Web
 * (c) 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1.5 - the step-up prompt.
 *
 * A sensitive console action answers 403 STEP_UP_REQUIRED with the action's own
 * reason text. platformAction() in platform-guard.tsx catches that, calls the
 * prompt provided by this hook, and retries the original request once if the
 * assertion succeeded. The api rotates the session on step-up (R1.4), so the
 * browser is given a new cookie by that response and the retry carries it.
 *
 * The prompt is rendered once, at the shell level, and handed down through
 * context: a console page asks for an assertion, it does not build one.
 */
import { createContext, useCallback, useContext, useMemo, useState } from 'react';
import { useTranslation } from '@/lib/i18n';
import { PlatformApiError, platformApi } from './platform-guard';

/** Resolves true when the administrator asserted successfully, false on cancel. */
export type StepUpPrompt = (action: string) => Promise<boolean>;

const StepUpContext = createContext<StepUpPrompt | null>(null);

/** For console pages: returns null outside the shell, so callers can degrade. */
export function useStepUp(): StepUpPrompt {
  const prompt = useContext(StepUpContext);
  return useMemo<StepUpPrompt>(
    () =>
      prompt ??
      (() => {
        // No provider (a page rendered outside the shell, or a test): refuse rather
        // than pretend an assertion happened.
        return Promise.resolve(false);
      }),
    [prompt],
  );
}

export function StepUpProvider({ children }: { children: React.ReactNode }) {
  const { t, lang } = useTranslation();
  const [open, setOpen] = useState(false);
  const [action, setAction] = useState('');
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [resolve, setResolve] = useState<((value: boolean) => void) | null>(null);

  const prompt = useCallback<StepUpPrompt>((requestedAction: string) => {
    setAction(requestedAction || '');
    setCode('');
    setError('');
    setOpen(true);
    return new Promise<boolean>((resolver) => setResolve(() => resolver));
  }, []);

  const finish = useCallback(
    (value: boolean) => {
      setOpen(false);
      setCode('');
      setError('');
      if (resolve) resolve(value);
      setResolve(null);
    },
    [resolve],
  );

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    if (code.length !== 6) return;
    setBusy(true);
    setError('');
    try {
      await platformApi('/platform/auth/step-up', { method: 'POST', body: JSON.stringify({ code }) });
      finish(true);
    } catch (err) {
      setError(err instanceof PlatformApiError ? t('platform_step_up_failed') : t('platform_step_up_failed'));
    } finally {
      setBusy(false);
    }
  }

  return (
    <StepUpContext.Provider value={prompt}>
      {children}
      {open && (
        <div
          dir={lang === 'ar' ? 'rtl' : 'ltr'}
          role="dialog"
          aria-modal="true"
          aria-label={t('platform_step_up_title')}
          className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-5 text-white"
        >
          <form onSubmit={submit} className="w-full max-w-sm rounded-3xl border border-white/10 bg-[#0b0b0b] p-6">
            <h2 className="text-lg font-black text-[#c5a059]">{t('platform_step_up_title')}</h2>
            <p className="mt-2 text-sm text-white/70">{t('platform_step_up_intro')}</p>
            {action && <p className="mt-3 rounded-xl border border-white/10 bg-black/40 p-3 text-sm">{action}</p>}
            {error && <p className="mt-3 rounded-xl bg-red-500/10 p-3 text-sm text-red-400">{error}</p>}
            <input
              autoFocus
              className="mt-4 w-full rounded-xl border border-white/10 bg-black/40 p-3 text-center font-mono text-lg tracking-[0.4em]"
              inputMode="numeric"
              autoComplete="one-time-code"
              maxLength={6}
              placeholder="000000"
              aria-label={t('platform_totp_code')}
              value={code}
              onChange={(event) => setCode(event.target.value.replace(/\D/g, '').slice(0, 6))}
            />
            <div className="mt-4 flex gap-3">
              <button type="button" onClick={() => finish(false)} className="flex-1 rounded-xl border border-white/15 p-3 text-sm">
                {t('platform_cancel')}
              </button>
              <button disabled={busy || code.length !== 6} className="flex-1 rounded-xl bg-[#c5a059] p-3 font-bold text-black disabled:opacity-40">
                {busy ? t('loading') : t('platform_continue')}
              </button>
            </div>
          </form>
        </div>
      )}
    </StepUpContext.Provider>
  );
}
