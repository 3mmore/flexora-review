'use client';
/**
 * FLEXORA Gym OS — Owner Console
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R4 (R4.16) — administrators.
 *
 * BEFORE: 24 lines printing GET /platform/admins into a <pre>. The api already supported the
 * whole lifecycle - create pending, approve within a 24-hour window, remove - and the console
 * offered none of it, so a second administrator could never be added or approved without
 * hand-crafting requests.
 *
 * Two things this page is careful about, both from earlier phases:
 *   - The list is the api's own allowlist. It never selects a password hash, TOTP state or a
 *     session token (R1/R2), and this page renders only the fields it is given rather than
 *     asking for more.
 *   - Creating an administrator raises ADMIN_CREATED, and approval is audited as
 *     admin:approved but deliberately raises NO second alert, because A3.5's dedupe window would
 *     collapse it. That is recorded in the R3 report and is why "pending" and "approved" look
 *     different here but only one of them notifies the owner.
 */
import { useCallback, useEffect, useState } from 'react';
import { platformApi } from '../platform-guard';
import { useStepUp } from '../platform-step-up';
import { useTranslation } from '@/lib/i18n';
import { label } from '@/lib/i18n/codes';

type AdminRow = Record<string, unknown> & {
  id?: string;
  email?: string;
  name?: string;
  role?: string;
  status?: string;
  createdAt?: string;
  approvalExpiresAt?: string | null;
  totpEnabled?: boolean;
  lastLoginAt?: string | null;
};

const STATUSES = ['ACTIVE', 'PENDING_APPROVAL', 'SUSPENDED', 'TRIALING'];
const STATUS_STYLE: Record<string, string> = {
  ACTIVE: 'bg-emerald-400/15 text-emerald-200',
  PENDING_APPROVAL: 'bg-amber-400/15 text-amber-200',
  SUSPENDED: 'bg-red-500/15 text-red-200',
  TRIALING: 'bg-sky-400/15 text-sky-200',
};

function isStepUpRequired(error: unknown): boolean {
  const message = String((error as Error)?.message ?? error ?? '');
  return message.includes('STEP_UP_REQUIRED') || String((error as { code?: unknown })?.code ?? '') === 'STEP_UP_REQUIRED';
}

export default function PlatformAdminsPage() {
  const { t, lang } = useTranslation();
  const locale = lang === 'ar' ? 'ar-EG' : 'en-GB';
  const stepUp = useStepUp();

  const [rows, setRows] = useState<AdminRow[]>([]);
  const [status, setStatus] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [draft, setDraft] = useState({ name: '', email: '', role: 'PLATFORM_ADMIN' });
  const [confirming, setConfirming] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams();
      if (status) params.set('status', status);
      const suffix = params.toString() ? `?${params.toString()}` : '';
      const data = await platformApi(`/platform/admins${suffix}`);
      setRows(Array.isArray(data) ? (data as AdminRow[]) : Array.isArray(data?.items) ? (data.items as AdminRow[]) : []);
    } catch (e) {
      setError((e as Error).message);
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, [status]);

  useEffect(() => {
    void load();
  }, [load]);

  const run = async (label: string, fn: () => Promise<unknown>) => {
    setBusy(label);
    setError(null);
    setNotice(null);
    try {
      await fn();
      setNotice(t('platform_gym_action_done').replace('{action}', label));
      await load();
    } catch (first) {
      if (!isStepUpRequired(first)) {
        setError(String((first as Error)?.message ?? first));
        return;
      }
      const granted = await stepUp(label);
      if (!granted) {
        setError(t('platform_gym_step_up_cancelled'));
        return;
      }
      try {
        await fn();
        setNotice(t('platform_gym_action_done').replace('{action}', label));
        await load();
      } catch (second) {
        setError(String((second as Error)?.message ?? second));
      }
    } finally {
      setBusy(null);
      setConfirming(null);
    }
  };

  const create = () => {
    if (!draft.email.includes('@') || draft.name.trim().length < 2) {
      setError(t('platform_admins_invalid'));
      return;
    }
    void run(t('platform_admins_create'), () =>
      platformApi('/platform/admins', {
        method: 'POST',
        body: JSON.stringify({ email: draft.email.trim(), name: draft.name.trim(), role: draft.role }),
      }),
    ).then(() => {
      setCreating(false);
      setDraft({ name: '', email: '', role: 'PLATFORM_ADMIN' });
    });
  };

  return (
    <div className="p-4 sm:p-6">
      <h1 className="text-2xl font-black sm:text-3xl">{t('platform_admins_label')}</h1>
      <p className="mt-1 text-sm text-white/60">{t('platform_admins_intro')}</p>

      <div className="mt-4 flex flex-col gap-2 sm:flex-row">
        <select
          aria-label={t('platform_gyms_status')}
          className="min-h-[44px] rounded-2xl border border-white/10 bg-black/50 px-3 text-sm"
          onChange={(event) => setStatus(event.target.value)}
          value={status}
        >
          <option value="">{t('platform_gyms_all_statuses')}</option>
          {STATUSES.map((value) => (
            <option key={value} value={value}>
              {label(value, 'adminStatus', lang === 'en' ? 'en' : 'ar')}
            </option>
          ))}
        </select>
        <button
          className="min-h-[44px] rounded-2xl bg-[#c5a059] px-4 text-sm font-bold text-black"
          onClick={() => setCreating((value) => !value)}
          type="button"
        >
          {t('platform_admins_create')}
        </button>
      </div>

      {creating && (
        <section className="mt-3 space-y-2 rounded-2xl border border-[#c5a059]/40 bg-[#c5a059]/10 p-4">
          <div className="text-xs text-amber-100/80">{t('platform_admins_create_hint')}</div>
          <input
            aria-label={t('platform_admins_name')}
            className="min-h-[44px] w-full rounded-xl border border-white/10 bg-black/50 px-3 text-sm"
            onChange={(event) => setDraft((current) => ({ ...current, name: event.target.value }))}
            placeholder={t('platform_admins_name')}
            value={draft.name}
          />
          <input
            aria-label={t('platform_admins_email')}
            className="min-h-[44px] w-full rounded-xl border border-white/10 bg-black/50 px-3 text-sm"
            inputMode="email"
            onChange={(event) => setDraft((current) => ({ ...current, email: event.target.value }))}
            placeholder={t('platform_admins_email')}
            value={draft.email}
          />
          <button
            className="min-h-[44px] w-full rounded-xl bg-[#c5a059] px-4 text-sm font-bold text-black disabled:opacity-40"
            disabled={busy !== null}
            onClick={create}
            type="button"
          >
            {t('platform_admins_create_pending')}
          </button>
        </section>
      )}

      {notice && <div className="mt-3 rounded-2xl border border-emerald-400/30 bg-emerald-400/10 p-3 text-xs text-emerald-200">{notice}</div>}
      {error && <div className="mt-3 rounded-2xl border border-red-400/40 bg-red-500/10 p-3 text-xs text-red-200">{error}</div>}

      <div className="mt-4 space-y-2">
        {loading && <div className="p-4 text-sm text-white/50">{t('platform_loading')}</div>}
        {!loading && rows.length === 0 && (
          <div className="rounded-2xl border border-white/10 bg-black/30 p-6 text-center text-sm text-white/50">
            {t('platform_admins_empty')}
          </div>
        )}
        {!loading &&
          rows.map((row) => {
            const id = String(row.id ?? '');
            const adminStatus = String(row.status ?? '');
            const isConfirming = confirming === id;
            return (
              <article className="rounded-2xl border border-white/10 bg-black/40 p-4" key={id}>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="truncate font-bold">{String(row.name ?? '—')}</div>
                    <div className="mt-0.5 truncate font-mono text-[11px] text-white/50">{String(row.email ?? '')}</div>
                    <div className="mt-1 flex flex-wrap gap-x-3 gap-y-1 text-[11px] text-white/45">
                      <span>{label(String(row.role ?? ''), 'adminRole', lang === 'en' ? 'en' : 'ar')}</span>
                      {row.totpEnabled ? <span>{t('platform_admins_2fa_on')} ✓</span> : <span>{t('platform_admins_no_2fa')}</span>}
                      {row.lastLoginAt ? <span>{new Date(String(row.lastLoginAt)).toLocaleDateString(`${locale}-u-nu-latn`)}</span> : null}
                    </div>
                    {adminStatus === 'PENDING_APPROVAL' && row.approvalExpiresAt && (
                      <div className="mt-1 text-[11px] text-amber-200/80">
                        {t('platform_admins_approval_window').replace(
                          '{date}',
                          new Date(String(row.approvalExpiresAt)).toLocaleString(locale),
                        )}
                      </div>
                    )}
                  </div>
                  <span className={`shrink-0 rounded-lg px-2 py-1 text-[11px] ${STATUS_STYLE[adminStatus] ?? 'bg-white/10 text-white/70'}`}>
                    {label(adminStatus, 'adminStatus', lang === 'en' ? 'en' : 'ar')}
                  </span>
                </div>

                <div className="mt-3 flex flex-col gap-2 border-t border-white/10 pt-3 sm:flex-row">
                  {adminStatus === 'PENDING_APPROVAL' && (
                    <button
                      className="min-h-[44px] flex-1 rounded-xl bg-[#c5a059] px-4 text-sm font-bold text-black disabled:opacity-40"
                      disabled={busy !== null}
                      onClick={() => void run(t('platform_admins_approve'), () => platformApi(`/platform/admins/${id}/approve`, { method: 'POST' }))}
                      type="button"
                    >
                      {t('platform_admins_approve')}
                    </button>
                  )}
                  {/* Removing an administrator revokes every one of their sessions and raises
                      ADMIN_REMOVED. It is destructive and irreversible, so it takes two taps:
                      the first reveals the confirmation, the second does it. */}
                  <button
                    className={`min-h-[44px] flex-1 rounded-xl px-4 text-sm font-bold disabled:opacity-40 ${
                      isConfirming ? 'bg-red-500/20 text-red-200' : 'border border-red-400/40 bg-red-500/10 text-red-200'
                    }`}
                    disabled={busy !== null}
                    onClick={() => {
                      if (!isConfirming) {
                        setConfirming(id);
                        return;
                      }
                      void run(t('platform_admins_remove'), () => platformApi(`/platform/admins/${id}`, { method: 'DELETE' }));
                    }}
                    type="button"
                  >
                    {isConfirming ? t('platform_admins_remove_confirm') : t('platform_admins_remove')}
                  </button>
                </div>
              </article>
            );
          })}
      </div>
    </div>
  );
}
