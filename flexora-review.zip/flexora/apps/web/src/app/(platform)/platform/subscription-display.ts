export function subscriptionDate(value: string | null | undefined, lang: string): string {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-GB', { dateStyle: 'medium', timeStyle: 'short' });
}
export function subscriptionStatus(status: string | null | undefined, end: string | null | undefined): string {
  if (status === 'CANCELED' || status === 'SUSPENDED') return status;
  if (end && new Date(end).getTime() < Date.now()) return 'EXPIRED';
  return status || 'NONE';
}
