'use client';
/**
 * FLEXORA Gym OS — Owner Console
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R4 (R4.13) — health.
 *
 * BEFORE: 24 lines printing /platform/health, which returned
 * `{ database: 'connected', redis: 'unknown', ... }` — the database field was a literal string
 * that was true whether or not the database was reachable, and redis was the literal word
 * "unknown". A page built on that is decoration: it says "healthy" during an outage.
 *
 * The api now probes each dependency with a BOUNDED call and reports a status per dependency.
 * This page renders those statuses and nothing invented client-side, so what the owner reads is
 * what the api measured.
 *
 * The distinction that matters, and the reason `status` is not simply "are all dependencies
 * green": Redis being down is DEGRADED, not failed, because every cache path falls back to the
 * database (R4.8). A broken audit chain is a failure, because nothing else about the platform's
 * integrity can be trusted if the record of what happened cannot be verified.
 */
import { useCallback, useEffect, useState } from 'react';
import { platformApi } from '../platform-guard';
import { useTranslation } from '@/lib/i18n';

type Dependency = { status?: string; latencyMs?: number; code?: string };
type Health = {
  status?: string;
  database?: Dependency;
  redis?: Dependency;
  audit?: { status?: string; rowsChecked?: number; brokenRows?: number; headSeq?: number | null };
  alertChannel?: { configured?: boolean; missing?: string[] };
  uptimeSeconds?: number;
  checkedInMs?: number;
};

const STYLE: Record<string, string> = {
  ok: 'border-emerald-400/30 bg-emerald-400/10 text-emerald-200',
  degraded: 'border-amber-400/40 bg-amber-400/10 text-amber-200',
  unavailable: 'border-amber-400/40 bg-amber-400/10 text-amber-200',
  broken: 'border-red-400/40 bg-red-500/10 text-red-200',
  error: 'border-red-400/40 bg-red-500/10 text-red-200',
  unknown: 'border-white/10 bg-white/5 text-white/60',
};

export default function PlatformHealthPage() {
  const { t } = useTranslation();
  const [health, setHealth] = useState<Health | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [checkedAt, setCheckedAt] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setHealth(await platformApi('/platform/health'));
      setCheckedAt(new Date().toLocaleTimeString());
    } catch (e) {
      setError((e as Error).message);
      setHealth(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const overall = String(health?.status ?? 'unknown');

  return (
    <div className="p-4 sm:p-6">
      <h1 className="text-2xl font-black sm:text-3xl">{t('platform_health')}</h1>
      <p className="mt-1 text-sm text-white/60">{t('platform_health_intro')}</p>

      <div className={`mt-4 rounded-2xl border p-4 ${STYLE[overall] ?? STYLE.unknown}`}>
        <div className="text-lg font-black">{t(`platform_health_status_${overall}`)}</div>
        {checkedAt && (
          <div className="mt-1 text-[11px] opacity-70">
            {t('platform_audit_checked_at')} {checkedAt}
            {typeof health?.checkedInMs === 'number' ? ` · ${health.checkedInMs} ms` : ''}
          </div>
        )}
      </div>

      <button
        className="mt-3 min-h-[44px] w-full rounded-2xl border border-white/10 bg-white/5 px-4 text-sm font-bold text-white/80"
        onClick={() => void load()}
        type="button"
      >
        {t('platform_refresh')}
      </button>

      {error && (
        <div className="mt-3 rounded-2xl border border-red-400/40 bg-red-500/10 p-3 text-sm text-red-200">
          {t('platform_health_unreachable')} {error}
        </div>
      )}
      {loading && <div className="mt-4 text-sm text-white/50">{t('platform_loading')}</div>}

      {!loading && health && (
        <div className="mt-4 space-y-2">
          <Card
            detail={typeof health.database?.latencyMs === 'number' ? `${health.database.latencyMs} ms` : health.database?.code}
            label={t('platform_health_database')}
            status={String(health.database?.status ?? 'unknown')}
          />
          <Card
            detail={typeof health.redis?.latencyMs === 'number' ? `${health.redis.latencyMs} ms` : undefined}
            hint={t('platform_health_redis_hint')}
            label={t('platform_health_redis')}
            status={String(health.redis?.status ?? 'unknown')}
          />
          <Card
            detail={
              typeof health.audit?.rowsChecked === 'number'
                ? `${health.audit.rowsChecked} ${t('platform_audit_rows_checked').toLowerCase()} · ${t('platform_audit_chain_head')} #${health.audit.headSeq ?? '-'} · ${health.audit.brokenRows ?? 0} ${t('platform_audit_broken_rows').toLowerCase()}`
                : undefined
            }
            hint={t('platform_health_audit_hint')}
            label={t('platform_health_audit_chain')}
            status={String(health.audit?.status ?? 'unknown')}
          />
          <div className={`rounded-2xl border p-4 ${health.alertChannel?.configured ? STYLE.ok : STYLE.degraded}`}>
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="text-sm font-bold">{t('platform_health_alert_channel')}</div>
                <div className="mt-1 text-[11px] opacity-75">
                  {health.alertChannel?.configured
                    ? t('platform_alerts_channel_ready')
                    : t('platform_alerts_no_channel')}
                </div>
              </div>
              <span className="shrink-0 rounded-lg bg-black/30 px-2 py-1 font-mono text-[11px]">
                {health.alertChannel?.configured ? t('platform_health_ok') : t('platform_health_missing')}
              </span>
            </div>
            {!health.alertChannel?.configured && (health.alertChannel?.missing ?? []).length > 0 && (
              <ul className="mt-2 space-y-1 font-mono text-[11px] opacity-80">
                {(health.alertChannel?.missing ?? []).map((name) => (
                  <li key={name}>· {name}</li>
                ))}
              </ul>
            )}
          </div>
          <div className="rounded-2xl border border-white/10 bg-black/40 p-4 text-xs text-white/55">
            <div>
              {t('platform_health_uptime')}: {Math.floor((health.uptimeSeconds ?? 0) / 3600)}h{' '}
              {Math.floor(((health.uptimeSeconds ?? 0) % 3600) / 60)}m
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Card({
  label,
  status,
  detail,
  hint,
}: {
  label: string;
  status: string;
  detail?: string;
  hint?: string;
}) {
  return (
    <div className={`rounded-2xl border p-4 ${STYLE[status] ?? STYLE.unknown}`}>
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="text-sm font-bold">{label}</div>
          {detail && <div className="mt-1 font-mono text-[11px] opacity-75">{detail}</div>}
          {hint && <div className="mt-1 text-[11px] opacity-60">{hint}</div>}
        </div>
        <span className="shrink-0 rounded-lg bg-black/30 px-2 py-1 font-mono text-[11px] uppercase">{status}</span>
      </div>
    </div>
  );
}
