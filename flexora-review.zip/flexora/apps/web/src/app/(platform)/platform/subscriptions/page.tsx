'use client';
import { useCallback, useEffect, useState } from 'react';
import Link from 'next/link';
import { platformApi } from '../platform-guard';
import { GrantDialog, type GrantMode } from '../grant-dialog';
import { subscriptionDate } from '../subscription-display';
import { useTranslation } from '@/lib/i18n';

type Row = { gymId: string; gymName: string; gymStatus: string; gymEmail: string | null; gymPhone: string | null; ownerName: string | null; ownerPhone: string | null; tier: string | null; effectiveStatus: string | null; startDate: string | null; endDate: string | null; trialDays: number | null; lastPaymentAt: string | null; lastPaymentAmount: number | null; lastGrantAt: string | null };
type Page = { items: Row[]; total: number; page: number; limit: number };
export default function SubscriptionsPage() {
  const { t, lang } = useTranslation();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [plan, setPlan] = useState('');
  const [windowFilter, setWindowFilter] = useState('');
  const [direction, setDirection] = useState('asc');
  const [page, setPage] = useState(1);
  const [data, setData] = useState<Page | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  const [refresh, setRefresh] = useState(0);
  const [dialog, setDialog] = useState<{ row: Row; mode: GrantMode } | null>(null);
  const [copied, setCopied] = useState('');
  const load = useCallback(async (signal: { cancelled: boolean }) => {
    setLoading(true); setError('');
    const params = new URLSearchParams({ page: String(page), search, status, plan, window: windowFilter, dir: direction });
    try {
      const result = await platformApi(`/platform/subscriptions/console?${params}`);
      if (!signal.cancelled) setData(result);
    } catch (e) { if (!signal.cancelled) { setData(null); setError(String((e as Error).message)); } }
    finally { if (!signal.cancelled) setLoading(false); }
  }, [page, search, status, plan, windowFilter, direction, refresh]);
  useEffect(() => { const signal = { cancelled: false }; void load(signal); return () => { signal.cancelled = true; }; }, [load]);
  const selectClass = 'min-h-[44px] w-full rounded-xl border border-white/10 bg-black/50 px-3 text-sm text-white';
  const date = (v: string | null) => subscriptionDate(v, lang);
  return <main className="p-4 sm:p-6" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
    <h1 className="text-2xl font-black">{t('platform_subscriptions')}</h1>
    <div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
      <input aria-label={t('platform_sub_search')} className={selectClass} placeholder={t('platform_sub_search')} value={search} onChange={e => { setPage(1); setSearch(e.target.value); }} />
      <select aria-label={t('platform_sub_all_status')} className={selectClass} value={status} onChange={e => { setPage(1); setStatus(e.target.value); }}><option value="">{t('platform_sub_all_status')}</option>{['TRIALING','ACTIVE','EXPIRED','CANCELED','SUSPENDED','PAST_DUE'].map(v => <option key={v} value={v}>{t('platform_sub_status_' + v)}</option>)}</select>
      <select aria-label={t('platform_sub_all_plans')} className={selectClass} value={plan} onChange={e => { setPage(1); setPlan(e.target.value); }}><option value="">{t('platform_sub_all_plans')}</option>{['BASIC','PRO','ELITE'].map(v => <option key={v} value={v}>{t('platform_sub_plan_' + v)}</option>)}</select>
      <select aria-label={t('platform_sub_window_all')} className={selectClass} value={windowFilter} onChange={e => { setPage(1); setWindowFilter(e.target.value); }}><option value="">{t('platform_sub_window_all')}</option><option value="ending7">{t('platform_sub_ending7')}</option><option value="expired">{t('platform_sub_expired_filter')}</option></select>
      <select aria-label={t('platform_gyms_period_ends')} className={selectClass} value={direction} onChange={e => { setPage(1); setDirection(e.target.value); }}><option value="asc">{t('platform_sub_sort_asc')}</option><option value="desc">{t('platform_sub_sort_desc')}</option></select>
    </div>
    {loading && <p className="mt-4 text-white/60">{t('platform_loading')}</p>}
    {error && <p role="alert" className="mt-4 text-red-300">{error}</p>}
    {!loading && data?.items.length === 0 && <p className="mt-4 text-white/60">{t('platform_sub_empty')}</p>}
    {!loading && <div className="mt-4 grid gap-3 lg:grid-cols-2">{data?.items.map(row => {
      const days = row.endDate ? Math.ceil((new Date(row.endDate).getTime() - Date.now()) / 86400000) : null;
      const urgent = days !== null && days <= 3;
      return <article key={row.gymId} className="min-w-0 rounded-2xl border border-white/10 bg-black/40 p-4">
        <div className="flex flex-wrap items-start justify-between gap-2"><h2 className="break-words text-lg font-bold">{row.gymName}</h2><span className={`rounded-lg px-2 py-1 text-xs font-bold ${urgent ? 'bg-red-500/20 text-red-200' : 'bg-[#c5a059]/15 text-[#c5a059]'}`}>{t('platform_sub_status_' + (row.effectiveStatus || 'NONE'))}</span></div>
        <dl className="mt-3 grid grid-cols-2 gap-x-3 gap-y-3 text-sm">
          <Item title={t('platform_sub_owner')} value={[row.ownerName, row.ownerPhone].filter(Boolean).join(' · ') || '—'} />
          <Item title={t('platform_sub_business')} value={[row.gymEmail, row.gymPhone].filter(Boolean).join(' · ') || '—'} />
          <Item title={t('platform_grant_plan')} value={row.tier ? t('platform_sub_plan_' + row.tier) : '—'} />
          <Item title={t('platform_sub_days_left')} value={days === null ? '—' : days.toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-GB')} urgent={urgent} />
          <Item title={t('platform_subscription_start')} value={date(row.startDate)} />
          <Item title={t('platform_sub_end')} value={date(row.endDate)} urgent={urgent} />
          <Item title={t('platform_sub_trial_days')} value={row.trialDays === null ? '—' : String(row.trialDays)} />
          <Item title={t('platform_sub_last_payment')} value={row.lastPaymentAt ? `${date(row.lastPaymentAt)} · ${row.lastPaymentAmount === null ? '—' : (row.lastPaymentAmount / 100).toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-GB')} EGP` : '—'} />
          <Item title={t('platform_sub_last_grant')} value={date(row.lastGrantAt)} />
        </dl>
        <div className="mt-4 flex flex-wrap gap-2 text-sm"><Link className="rounded-xl border border-white/15 px-3 py-3" href={`/platform/gyms/${encodeURIComponent(row.gymId)}`}>{t('platform_sub_open')}</Link><button className="rounded-xl border border-[#c5a059]/40 px-3 py-3" onClick={() => setDialog({row, mode:'trial'})}>{t('platform_grant_trial_title')}</button><button className="rounded-xl bg-[#c5a059] px-3 py-3 font-bold text-black" onClick={() => setDialog({row, mode:'subscription'})}>{t('platform_grant_title')}</button><button className="rounded-xl px-2 py-3 text-xs text-white/60" onClick={() => { void navigator.clipboard.writeText(row.gymId).then(() => setCopied(row.gymId)).catch(() => setCopied('')); }}>{copied === row.gymId ? t('platform_sub_copied') : t('platform_sub_copy')}</button></div>
      </article>;
    })}</div>}
    {data && <div className="mt-4 flex flex-wrap items-center justify-between gap-2 text-sm"><button disabled={page <= 1 || loading} className="min-h-[44px] rounded-xl border border-white/10 px-3 disabled:opacity-40" onClick={() => setPage(p => p - 1)}>{t('platform_sub_previous')}</button><span>{t('platform_sub_page').replace('{page}', String(page)).replace('{pages}', String(Math.max(1,Math.ceil(data.total / 25)))).replace('{total}', String(data.total))}</span><button disabled={page * 25 >= data.total || loading} className="min-h-[44px] rounded-xl border border-white/10 px-3 disabled:opacity-40" onClick={() => setPage(p => p + 1)}>{t('platform_sub_next')}</button></div>}
    {dialog && <GrantDialog open gymId={dialog.row.gymId} gymName={dialog.row.gymName} mode={dialog.mode} onClose={() => setDialog(null)} onGranted={() => setRefresh(n => n + 1)} />}
  </main>;
}
function Item({title, value, urgent}: {title: string; value: string; urgent?: boolean}) { return <div className="min-w-0"><dt className="text-xs text-white/45">{title}</dt><dd className={`break-words ${urgent ? 'font-bold text-red-200' : 'text-white/85'}`}>{value}</dd></div>; }
