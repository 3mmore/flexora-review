/**
 * FLEXORA Gym OS - Web
 * (c) 2024 Ammar Allam. All rights reserved.
 */
/**
 * PHASE R0 - the owner-console host gate, app layer (owner decision: enforce in
 * nginx, Next middleware, the Next app and Nest independently, so that the failure
 * or misconfiguration of any one layer cannot expose the console).
 *
 * WHY THIS LAYOUT IS A SERVER COMPONENT NOW
 * It is the only place in this app that can refuse a console page with Next's OWN
 * not-found response. Middleware can refuse too, but every middleware rewrite adds
 * an `x-middleware-rewrite` response header (measured), which is a fingerprint an
 * attacker can compare against a genuinely unknown route. `notFound()` from a server
 * layout renders the same 14,415-byte not-found page, with the same content type,
 * CSP, HSTS and ETag, and adds nothing - so this layer is the one that answers when
 * the request reaches the app at all.
 *
 * `headers()` is read HERE and not in the root layout on purpose: it opts only this
 * route group into dynamic rendering. Reading it in app/layout.tsx would make every
 * page in the tenant app dynamic and destroy static prerendering app-wide.
 *
 * The console pages were prerendered before this change (the login page was served
 * with `x-nextjs-prerender: 1`); they are dynamic now. That is inherent to a
 * per-request host decision, and it is the console - seven placeholder pages behind
 * an admin session - not the tenant app.
 *
 * WHAT THIS IS NOT: an authentication layer. On an allowed hostname the console
 * still requires a platform session (PlatformGuard on the client, PlatformAdminGuard
 * plus the platform token on the api). This gate only decides whether the console is
 * served on this hostname at all.
 */
import { headers } from 'next/headers';
import { notFound } from 'next/navigation';
import { adminHostVerdict } from '@/lib/admin-hosts';
import { PlatformShell } from './platform-shell';

export default async function PlatformLayout({ children }: { children: React.ReactNode }) {
  const requestHeaders = await headers();
  const verdict = adminHostVerdict(
    requestHeaders.get('host') ?? undefined,
    requestHeaders.get('x-forwarded-host') ?? undefined,
  );
  // Refuse exactly like a route that does not exist: no explanation, no redirect to
  // /platform/login (that redirect is what used to confirm the console exists), no
  // admin-specific header, no distinct status code.
  if (!verdict.allowed) notFound();
  return <PlatformShell>{children}</PlatformShell>;
}
