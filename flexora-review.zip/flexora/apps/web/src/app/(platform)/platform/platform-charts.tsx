'use client';
/**
 * FLEXORA Gym OS — Owner Console
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R4 (R4.1, R4.6) — the console's charts, as inline SVG.
 *
 * NO CHART LIBRARY. The brief says so explicitly, and R4.1 makes it measurable: the JavaScript
 * shipped per admin page is reported from the production build, and a charting dependency would
 * dominate that number for a page the owner opens on a phone, often on mobile data. Everything
 * here is a <svg> with a <path>, a <rect> or a <circle> and nothing else - no dependency, no
 * canvas, no runtime layout engine.
 *
 * These are PURE components: props in, SVG out, no data fetching and no state. That is deliberate
 * - it means they can be unit-tested in jsdom (apps/web has a jest suite) and it means the page
 * that uses them owns the fetching, the error state and the cache indicator.
 *
 * RTL (R4.2). A time series read by an Arabic reader runs right-to-left, so every horizontal
 * mapping takes an `rtl` flag and mirrors. Mirroring the geometry without mirroring the month
 * labels would produce a chart that lies, so the labels are placed through the same mapping as
 * the data. Vertical axes are not mirrored: up is still more.
 *
 * Degenerate data is handled explicitly rather than left to produce NaN. An empty series, a
 * series of equal values, and a single point all render something honest - a flat baseline or a
 * single marker - because a division by a zero range is how a chart silently disappears.
 */
import type { ReactNode } from 'react';

export type SeriesPoint = { month: string; value: number };

/** Map an index onto the horizontal axis, mirrored for RTL. */
function xAt(index: number, count: number, width: number, padX: number, rtl: boolean): number {
  const usable = width - padX * 2;
  if (count <= 1) return rtl ? width - padX : padX;
  const fraction = index / (count - 1);
  const x = padX + usable * fraction;
  return rtl ? width - x : x;
}

function formatMonth(month: string, locale: string): string {
  // month is 'YYYY-MM' from the api. Rendered short and locale-aware, and never trusted to
  // Date parsing alone: an invalid string falls back to the raw value rather than 'Invalid Date'.
  const parsed = new Date(`${month}-01T00:00:00Z`);
  if (Number.isNaN(parsed.getTime())) return month;
  try {
    return parsed.toLocaleDateString(`${locale}-u-nu-latn`, { month: 'short', timeZone: 'UTC' });
  } catch {
    return month.slice(5);
  }
}

function niceMax(value: number): number {
  if (!Number.isFinite(value) || value <= 0) return 1;
  const magnitude = Math.pow(10, Math.floor(Math.log10(value)));
  const scaled = value / magnitude;
  const step = scaled <= 1 ? 1 : scaled <= 2 ? 2 : scaled <= 5 ? 5 : 10;
  return step * magnitude;
}

const GOLD = '#c5a059';

/**
 * An area + line chart for a monthly series. Used for revenue.
 *
 * `viewBox` is fixed and the SVG is width:100% height:auto, so it scales from 375 px to a
 * desktop without a resize observer and without JavaScript measuring anything.
 */
export function AreaSeries({
  points,
  rtl = false,
  locale = 'en',
  label,
  valueFormat,
  height = 132,
}: {
  points: SeriesPoint[];
  rtl?: boolean;
  locale?: string;
  label: string;
  valueFormat: (value: number) => string;
  height?: number;
}): ReactNode {
  const width = 320;
  const padX = 6;
  const padTop = 10;
  const padBottom = 22;
  const plotHeight = height - padTop - padBottom;
  const max = niceMax(Math.max(0, ...points.map((point) => Number(point.value) || 0)));
  const yAt = (value: number) => padTop + plotHeight - (Math.max(0, value) / max) * plotHeight;

  if (!points.length) {
    return (
      <svg aria-label={label} className="h-auto w-full" role="img" viewBox={`0 0 ${width} ${height}`}>
        <line stroke="rgba(255,255,255,0.14)" strokeWidth="1" x1={padX} x2={width - padX} y1={padTop + plotHeight} y2={padTop + plotHeight} />
      </svg>
    );
  }

  const coords = points.map((point, index) => ({
    x: xAt(index, points.length, width, padX, rtl),
    y: yAt(Number(point.value) || 0),
  }));
  const line = coords.map((coord, index) => `${index === 0 ? 'M' : 'L'}${coord.x.toFixed(2)},${coord.y.toFixed(2)}`).join(' ');
  const baseline = padTop + plotHeight;
  const area = `${line} L${coords[coords.length - 1].x.toFixed(2)},${baseline} L${coords[0].x.toFixed(2)},${baseline} Z`;
  // Show at most six month labels; twelve at 375 px would overlap into illegibility.
  const labelEvery = Math.max(1, Math.ceil(points.length / 6));

  return (
    <svg aria-label={label} className="h-auto w-full" role="img" viewBox={`0 0 ${width} ${height}`}>
      <title>{label}</title>
      {[0, 0.5, 1].map((fraction) => (
        <line
          key={fraction}
          stroke="rgba(255,255,255,0.08)"
          strokeWidth="1"
          x1={padX}
          x2={width - padX}
          y1={padTop + plotHeight * fraction}
          y2={padTop + plotHeight * fraction}
        />
      ))}
      <path d={area} fill={GOLD} fillOpacity="0.16" stroke="none" />
      <path d={line} fill="none" stroke={GOLD} strokeLinejoin="round" strokeLinecap="round" strokeWidth="2" />
      {coords.map((coord, index) => (
        <circle cx={coord.x} cy={coord.y} fill={GOLD} key={index} r="2">
          <title>{`${points[index].month}: ${valueFormat(Number(points[index].value) || 0)}`}</title>
        </circle>
      ))}
      {points.map((point, index) =>
        index % labelEvery === 0 || index === points.length - 1 ? (
          <text
            fill="rgba(255,255,255,0.45)"
            fontSize="9"
            key={point.month}
            textAnchor="middle"
            x={coords[index].x}
            y={height - 7}
          >
            {formatMonth(point.month, locale)}
          </text>
        ) : null,
      )}
    </svg>
  );
}

/** Vertical bars for a count series. Used for gym growth. */
export function BarSeries({
  points,
  rtl = false,
  locale = 'en',
  label,
  height = 120,
}: {
  points: SeriesPoint[];
  rtl?: boolean;
  locale?: string;
  label: string;
  height?: number;
}): ReactNode {
  const width = 320;
  const padX = 6;
  const padTop = 8;
  const padBottom = 22;
  const plotHeight = height - padTop - padBottom;
  const max = niceMax(Math.max(0, ...points.map((point) => Number(point.value) || 0)));
  const slot = points.length ? (width - padX * 2) / points.length : width - padX * 2;
  const barWidth = Math.max(2, slot * 0.62);
  const labelEvery = Math.max(1, Math.ceil(points.length / 6));

  return (
    <svg aria-label={label} className="h-auto w-full" role="img" viewBox={`0 0 ${width} ${height}`}>
      <title>{label}</title>
      <line stroke="rgba(255,255,255,0.14)" strokeWidth="1" x1={padX} x2={width - padX} y1={padTop + plotHeight} y2={padTop + plotHeight} />
      {points.map((point, index) => {
        const value = Math.max(0, Number(point.value) || 0);
        const barHeight = (value / max) * plotHeight;
        // The bar is positioned by its slot index, mirrored for RTL the same way the line
        // chart's points are, so the two charts on one page agree about which end is oldest.
        const slotStart = padX + slot * index + (slot - barWidth) / 2;
        const x = rtl ? width - slotStart - barWidth : slotStart;
        return (
          <g key={point.month}>
            <rect fill={GOLD} fillOpacity={value > 0 ? 0.85 : 0.18} height={Math.max(1, barHeight)} rx="2" width={barWidth} x={x} y={padTop + plotHeight - Math.max(1, barHeight)} />
            {index % labelEvery === 0 || index === points.length - 1 ? (
              <text fill="rgba(255,255,255,0.45)" fontSize="9" textAnchor="middle" x={x + barWidth / 2} y={height - 7}>
                {formatMonth(point.month, locale)}
              </text>
            ) : null}
            <title>{`${point.month}: ${value}`}</title>
          </g>
        );
      })}
    </svg>
  );
}

/**
 * A horizontal segmented bar for a distribution - used for plan tiers (BASIC / PRO / ELITE).
 *
 * Horizontal rather than a donut on purpose: a donut needs a legend to be readable, and at
 * 375 px a legend plus an arc plus labels is three things competing for one column. A segmented
 * bar with the count written inside each segment is legible at thumb width, and it degrades
 * honestly when a segment is zero.
 */
export function SegmentBar({
  segments,
  label,
  height = 34,
}: {
  segments: Array<{ key: string; label: string; value: number }>;
  label: string;
  height?: number;
}): ReactNode {
  const width = 320;
  const total = segments.reduce((sum, segment) => sum + Math.max(0, Number(segment.value) || 0), 0);
  const shades = [0.95, 0.62, 0.34];

  if (total <= 0) {
    return (
      <svg aria-label={label} className="h-auto w-full" role="img" viewBox={`0 0 ${width} ${height}`}>
        <rect fill="rgba(255,255,255,0.06)" height={height} rx="8" width={width} />
      </svg>
    );
  }

  let cursor = 0;
  return (
    <svg aria-label={label} className="h-auto w-full" role="img" viewBox={`0 0 ${width} ${height}`}>
      <title>{label}</title>
      {segments.map((segment, index) => {
        const value = Math.max(0, Number(segment.value) || 0);
        const segmentWidth = (value / total) * width;
        const x = cursor;
        cursor += segmentWidth;
        if (segmentWidth <= 0) return null;
        return (
          <g key={segment.key}>
            <rect fill={GOLD} fillOpacity={shades[index % shades.length]} height={height} rx={index === 0 ? 8 : 0} width={segmentWidth} x={x} />
            {segmentWidth > 34 ? (
              <text fill="#0b0b0c" fontSize="11" fontWeight="700" textAnchor="middle" x={x + segmentWidth / 2} y={height / 2 + 4}>
                {value}
              </text>
            ) : null}
            <title>{`${segment.label}: ${value}`}</title>
          </g>
        );
      })}
    </svg>
  );
}

/**
 * A delta badge for a period-over-period change.
 *
 * Deliberately NOT colour-coded red/green. The console is dark-with-gold and a red badge on a
 * revenue figure reads as an error; up and down are conveyed by the arrow and the sign, and the
 * text states the direction in words, which also keeps it correct in Arabic where a "+" prefix
 * is not the idiomatic way to say "increased".
 */
export function DeltaBadge({ current, previous, upLabel, downLabel, flatLabel }: {
  current: number;
  previous: number;
  upLabel: string;
  downLabel: string;
  flatLabel: string;
}): ReactNode {
  const safeCurrent = Number(current) || 0;
  const safePrevious = Number(previous) || 0;
  if (!Number.isFinite(safePrevious) || safePrevious === 0) {
    // A percentage against zero is not a number, and rendering "Infinity%" or "NaN%" on the
    // owner's dashboard is worse than saying there is nothing to compare with.
    return <span className="text-xs text-white/45">{flatLabel}</span>;
  }
  const change = ((safeCurrent - safePrevious) / Math.abs(safePrevious)) * 100;
  const rounded = Math.round(change * 10) / 10;
  if (rounded === 0) return <span className="text-xs text-white/45">{flatLabel}</span>;
  const rising = rounded > 0;
  return (
    <span className="text-xs text-white/60">
      {rising ? '▲' : '▼'} {Math.abs(rounded)}% {rising ? upLabel : downLabel}
    </span>
  );
}
