'use client';
/**
 * FLEXORA Gym OS — Owner Console
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R4 (R4.10, R4.11) — gym detail, and the actions that change a gym's standing.
 *
 * BEFORE: this page did not exist. The gyms list printed JSON and there was nowhere to go from it,
 * so every platform action on a gym — suspend, reactivate, soft-delete, restore, change plan,
 * grant, extend trial — was reachable only by hand-crafting an HTTP request. The api had supported
 * all of them since R2/R3; the console simply had no surface for them.
 *
 * Every state-changing action here goes through the same path: step-up, a required reason of at
 * least eight characters, CSRF (handled by platformApi), and an audit row written server-side.
 * Nothing on this page can act without all four, and the reason is collected in the UI rather than
 * left to a 400, because losing a typed paragraph to a validation error is its own kind of bug.
 *
 * Step-up is RETRIED ONCE, not assumed. A claim expires after five minutes, and an owner who opens
 * this page on a phone, walks away, and comes back has an expired claim. So an action that answers
 * STEP_UP_REQUIRED opens the console's single step-up dialog (useStepUp) and, only if the owner
 * completes it, repeats the request exactly once. If they cancel, nothing is sent and the page says
 * so.
 *
 * Mobile first: actions are a vertical stack of full-width buttons at least 44 px tall, the
 * destructive one last and visually distinct, and the grant/extend dialog is a bottom sheet so the
 * confirm button is not under the keyboard.
 */
import { useCallback, useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { platformApi } from '../../platform-guard';
import { useStepUp } from '../../platform-step-up';
import { GrantDialog, type GrantMode } from '../../grant-dialog';
import { subscriptionDate, subscriptionStatus } from '../../subscription-display';
import { useTranslation } from '@/lib/i18n';

type GymDetail = Record<string, unknown> & {
  id?: string;
  name?: string;
  slug?: string;
  status?: string;
  email?: string;
  phone?: string;
  address?: string;
  memberCount?: number;
  userCount?: number;
  branchCount?: number;
  ownerName?: string;
  ownerPhone?: string;
  subscription?: { tier?: string | null; status?: string | null; currentPeriodStart?: string | null; currentPeriodEnd?: string | null; trialStartDate?: string | null; trialEndDate?: string | null } | null;
  deletedAt?: string | null;
};

const REASON_MIN = 8;

const STATUS_STYLE: Record<string, string> = {
  ACTIVE: 'bg-emerald-400/15 text-emerald-200',
  SUSPENDED: 'bg-amber-400/15 text-amber-200',
  TRIALING: 'bg-sky-400/15 text-sky-200',
  PENDING: 'bg-white/10 text-white/70',
  DELETED: 'bg-red-500/15 text-red-200',
};

function isStepUpRequired(error: unknown): boolean {
  const message = String((error as Error)?.message ?? error ?? '');
  const code = (error as { code?: unknown })?.code;
  return message.includes('STEP_UP_REQUIRED') || String(code ?? '') === 'STEP_UP_REQUIRED';
}

export default function PlatformGymDetailPage() {
  const { t, lang } = useTranslation();
  const locale = lang === 'ar' ? 'ar-EG' : 'en-GB';
  const params = useParams<{ id: string }>();
  const gymId = String(params?.id ?? '');
  const stepUp = useStepUp();

  const [gym, setGym] = useState<GymDetail | null>(null);
  const [revenue, setRevenue] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [pending, setPending] = useState<string | null>(null);
  const [reasonFor, setReasonFor] = useState<string | null>(null);
  const [reason, setReason] = useState('');
  const [dialog, setDialog] = useState<GrantMode | null>(null);

  const load = useCallback(async () => {
    if (!gymId) return;
    setLoading(true);
    setError(null);
    try {
      const data = await platformApi(`/platform/gyms/${gymId}`);
      setGym((data?.gym ?? null) as GymDetail | null);
      setRevenue(typeof data?.revenue === 'number' ? data.revenue : null);
    } catch (e) {
      setError((e as Error).message);
      setGym(null);
    } finally {
      setLoading(false);
    }
  }, [gymId]);

  useEffect(() => {
    void load();
  }, [load]);

  /**
   * Run a state-changing action: step-up first if the claim has expired, a required reason, and
   * exactly one retry. Returns the response body, or null if the owner cancelled step-up.
   */
  const runAction = useCallback(
    async (label: string, method: string, path: string, body: Record<string, unknown>) => {
      setPending(label);
      setError(null);
      setNotice(null);
      const attempt = () => platformApi(path, { method, body: JSON.stringify(body) });
      try {
        const result = await attempt();
        setNotice(t('platform_gym_action_done').replace('{action}', label));
        await load();
        return result;
      } catch (firstError) {
        if (!isStepUpRequired(firstError)) {
          setError(String((firstError as Error)?.message ?? firstError));
          return null;
        }
        const granted = await stepUp(label);
        if (!granted) {
          // The owner cancelled. Nothing was sent, and the page says so rather than leaving them
          // guessing whether the action happened.
          setError(t('platform_gym_step_up_cancelled'));
          return null;
        }
        try {
          const result = await attempt();
          setNotice(t('platform_gym_action_done').replace('{action}', label));
          await load();
          return result;
        } catch (secondError) {
          setError(String((secondError as Error)?.message ?? secondError));
          return null;
        }
      } finally {
        setPending(null);
        setReasonFor(null);
        setReason('');
      }
    },
    [load, stepUp, t],
  );

  /** Ask for a reason inline, then act. Returns false if the reason is too short. */
  const withReason = (action: string, run: (reason: string) => Promise<unknown>) => {
    if (reasonFor === action) {
      if (reason.trim().length < REASON_MIN) {
        setError(t('platform_grant_reason_count').replace('{n}', String(reason.trim().length)).replace('{min}', String(REASON_MIN)));
        return;
      }
      void run(reason.trim());
      return;
    }
    setReasonFor(action);
    setReason('');
    setError(null);
  };

  const dateLabel = (value?: string | null) => {
    if (!value) return '—';
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? String(value) : parsed.toLocaleString(locale, { dateStyle: 'medium', timeStyle: 'short' });
  };
  const status = String(gym?.status ?? '');
  const isDeleted = status === 'DELETED';

  return (
    <div className="p-4 sm:p-6">
      {loading && <div className="text-sm text-white/50">{t('platform_loading')}</div>}

      {!loading && !gym && (
        <div className="rounded-2xl border border-red-400/40 bg-red-500/10 p-4 text-sm text-red-200">
          {error ?? t('platform_gym_not_found')}
        </div>
      )}

      {!loading && gym && (
        <>
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <h1 className="truncate text-xl font-black sm:text-2xl">{String(gym.name ?? gym.id)}</h1>
              <div className="mt-1 truncate font-mono text-[11px] text-white/45">{String(gym.slug ?? '')}</div>
            </div>
            <span className={`shrink-0 rounded-lg px-2 py-1 font-mono text-[11px] ${STATUS_STYLE[status] ?? STATUS_STYLE.PENDING}`}>
              {status}
            </span>
          </div>

          {isDeleted && (
            <div className="mt-3 rounded-2xl border border-red-400/40 bg-red-500/10 p-3 text-xs text-red-200">
              {t('platform_gym_deleted_banner').replace('{date}', dateLabel(gym.deletedAt))}
            </div>
          )}

          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat label={t('platform_gyms_members')} value={(gym.memberCount ?? 0).toLocaleString(locale)} />
            <Stat label={t('platform_gym_staff')} value={(gym.userCount ?? 0).toLocaleString(locale)} />
            <Stat label={t('platform_gym_branches')} value={(gym.branchCount ?? 0).toLocaleString(locale)} />
            <Stat
              label={t('platform_gym_revenue')}
              value={revenue === null ? '—' : Math.round(revenue).toLocaleString(locale)}
            />
          </div>

          <section className="mt-4 rounded-2xl border border-white/10 bg-black/40 p-4 text-sm">
            <h2 className="text-xs font-bold uppercase tracking-wide text-white/45">{t('platform_gym_subscription')}</h2>
            <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-2">
              <Field label={t('platform_grant_plan')} value={gym.subscription?.tier ? t('platform_sub_plan_' + gym.subscription.tier) : '—'} />
              <Field label={t('platform_gym_subscription_status')} value={t('platform_sub_status_' + subscriptionStatus(gym.subscription?.status, gym.subscription?.status === 'TRIALING' ? (gym.subscription.trialEndDate ?? gym.subscription.currentPeriodEnd) : gym.subscription?.currentPeriodEnd))} />
              <Field label={t('platform_subscription_start')} value={subscriptionDate(gym.subscription?.status === 'TRIALING' ? gym.subscription.trialStartDate : gym.subscription?.currentPeriodStart, lang)} />
              <Field label={t('platform_gyms_period_ends')} value={subscriptionDate(gym.subscription?.status === 'TRIALING' ? (gym.subscription.trialEndDate ?? gym.subscription.currentPeriodEnd) : gym.subscription?.currentPeriodEnd, lang)} />
            </dl>
          </section>

          <section className="mt-3 rounded-2xl border border-white/10 bg-black/40 p-4 text-sm">
            <h2 className="text-xs font-bold uppercase tracking-wide text-white/45">{t('platform_gym_contact')}</h2>
            <dl className="mt-2 grid grid-cols-1 gap-x-3 gap-y-2 sm:grid-cols-2">
              <Field label={t('platform_gym_owner_name')} value={gym.ownerName ? String(gym.ownerName) : '—'} />
              <Field label={t('platform_gym_owner_phone')} value={gym.ownerPhone ? String(gym.ownerPhone) : '—'} />
              <Field label={t('platform_gym_gym_email')} value={gym.email ? String(gym.email) : '—'} />
              <Field label={t('platform_gym_gym_phone')} value={gym.phone ? String(gym.phone) : '—'} />
            </dl>
            {/* R2 decision Q2: the gym's own business contact and its owner's name and phone are
                platform-level data the owner console is allowed to see. Member data is not, and
                none is fetched here — the counts above come from the SECURITY DEFINER aggregate. */}
          </section>

          {notice && (
            <div className="mt-3 rounded-2xl border border-emerald-400/30 bg-emerald-400/10 p-3 text-xs text-emerald-200">
              {notice}
            </div>
          )}
          {error && (
            <div className="mt-3 rounded-2xl border border-red-400/40 bg-red-500/10 p-3 text-xs text-red-200">{error}</div>
          )}

          {/* The inline reason collector. Rendered for whichever action asked for one, so the
              owner is not shown four empty text boxes at once. */}
          {reasonFor && (
            <div className="mt-3 rounded-2xl border border-[#c5a059]/40 bg-[#c5a059]/10 p-3">
              <label className="block">
                <span className="block text-[11px] uppercase tracking-wide text-[#c5a059]/85">
                  {t('platform_grant_reason')} <span className="text-[#c5a059]">*</span>
                </span>
                <textarea
                  autoFocus
                  className="mt-1 min-h-[72px] w-full rounded-xl border border-white/10 bg-black/50 px-3 py-2 text-sm"
                  onChange={(event) => setReason(event.target.value)}
                  placeholder={t('platform_grant_reason_hint')}
                  value={reason}
                />
              </label>
              <div className="mt-1 text-[11px] text-white/50">
                {t('platform_grant_reason_count').replace('{n}', String(reason.trim().length)).replace('{min}', String(REASON_MIN))}
              </div>
            </div>
          )}

          <section className="mt-4 space-y-2">
            <h2 className="text-xs font-bold uppercase tracking-wide text-white/45">{t('platform_gym_actions')}</h2>

            {!isDeleted && (
              <>
                <Action
                  disabled={pending !== null}
                  label={t('platform_grant_title')}
                  onClick={() => setDialog('subscription')}
                  pending={pending === t('platform_grant_title')}
                />
                <Action
                  disabled={pending !== null}
                  label={t('platform_grant_trial_title')}
                  onClick={() => setDialog('trial')}
                  pending={pending === t('platform_grant_trial_title')}
                />
                {status === 'ACTIVE' && (
                  <Action
                    disabled={pending !== null}
                    label={t('platform_gym_suspend')}
                    onClick={() =>
                      withReason(t('platform_gym_suspend'), (value) =>
                        runAction(t('platform_gym_suspend'), 'POST', `/platform/gyms/${gymId}/suspend`, { reason: value }),
                      )
                    }
                    pending={pending === t('platform_gym_suspend')}
                  />
                )}
                {(status === 'SUSPENDED' || status === 'TRIALING') && (
                  <Action
                    disabled={pending !== null}
                    label={t('platform_gym_reactivate')}
                    onClick={() =>
                      withReason(t('platform_gym_reactivate'), (value) =>
                        runAction(t('platform_gym_reactivate'), 'POST', `/platform/gyms/${gymId}/reactivate`, { reason: value }),
                      )
                    }
                    pending={pending === t('platform_gym_reactivate')}
                  />
                )}
              </>
            )}

            {isDeleted ? (
              <Action
                disabled={pending !== null}
                label={t('platform_gym_restore')}
                onClick={() =>
                  withReason(t('platform_gym_restore'), (value) =>
                    runAction(t('platform_gym_restore'), 'POST', `/platform/gyms/${gymId}/restore`, { reason: value }),
                  )
                }
                pending={pending === t('platform_gym_restore')}
              />
            ) : (
              /* Destructive, so it is last and visually distinct. It is a SOFT delete (R2
                 decision Q1): the gym leaves the list, keeps its data, and can be restored
                 inside the 30-day window. The label says so, because "delete" on its own reads
                 as permanent and the owner should not have to know the implementation to know
                 that it is not. */
              <Action
                danger
                disabled={pending !== null}
                label={t('platform_gym_delete')}
                onClick={() =>
                  withReason(t('platform_gym_delete'), (value) =>
                    runAction(t('platform_gym_delete'), 'DELETE', `/platform/gyms/${gymId}`, { reason: value }),
                  )
                }
                pending={pending === t('platform_gym_delete')}
              />
            )}
          </section>
        </>
      )}

      {dialog && gym && (
        <GrantDialog
          gymId={gymId}
          gymName={String(gym.name ?? gymId)}
          mode={dialog}
          onClose={() => setDialog(null)}
          onGranted={(result) => {
            setNotice(
              result.idempotent === 'replayed'
                ? t('platform_grant_replayed')
                : t('platform_gym_action_done').replace(
                    '{action}',
                    dialog === 'trial' ? t('platform_grant_trial_title') : t('platform_grant_title'),
                  ),
            );
            void load();
          }}
          open
        />
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-3">
      <div className="text-[11px] uppercase tracking-wide text-white/45">{label}</div>
      <div className="mt-1 break-all text-lg font-black">{value}</div>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="min-w-0">
      <dt className="text-[11px] text-white/40">{label}</dt>
      <dd className="truncate text-white/80">{value}</dd>
    </div>
  );
}

function Action({
  label,
  onClick,
  disabled,
  pending,
  danger,
}: {
  label: string;
  onClick: () => void;
  disabled?: boolean;
  pending?: boolean;
  danger?: boolean;
}) {
  return (
    <button
      className={`min-h-[44px] w-full rounded-xl px-4 text-sm font-bold disabled:opacity-40 ${
        danger
          ? 'border border-red-400/40 bg-red-500/10 text-red-200'
          : 'border border-white/10 bg-white/5 text-white/85'
      }`}
      disabled={disabled}
      onClick={onClick}
      type="button"
    >
      {pending ? '…' : label}
    </button>
  );
}
