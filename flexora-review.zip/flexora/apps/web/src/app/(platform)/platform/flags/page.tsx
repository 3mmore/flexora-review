'use client';
/**
 * FLEXORA Gym OS — Owner Console
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R4 (R4.14) — feature flags.
 *
 * BEFORE: there was no flags page. GET and POST /platform/flags existed in the api and the console
 * had no surface for either, so a flag could only be changed by hand-crafting a request.
 *
 * Changing a flag is a state-changing action, so R4.22 applies, and the api side was fixed in this
 * phase: POST /platform/flags carried @RequireStepUp but wrote NO audit row, so a flag could be
 * flipped platform-wide with nothing recording who did it. It now writes `flag:set`.
 */
import { useCallback, useEffect, useState } from 'react';
import { platformApi } from '../platform-guard';
import { useStepUp } from '../platform-step-up';
import { useTranslation } from '@/lib/i18n';

type FlagRow = Record<string, unknown> & { flag?: string; key?: string; name?: string; value?: unknown; gymId?: string | null };

function isStepUpRequired(error: unknown): boolean {
  const message = String((error as Error)?.message ?? error ?? '');
  return message.includes('STEP_UP_REQUIRED') || String((error as { code?: unknown })?.code ?? '') === 'STEP_UP_REQUIRED';
}

export default function PlatformFlagsPage() {
  const { t } = useTranslation();
  const stepUp = useStepUp();
  const [rows, setRows] = useState<FlagRow[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [newFlag, setNewFlag] = useState('');
  const [newValue, setNewValue] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await platformApi('/platform/flags');
      // The route returns whatever the flags service holds. Normalise the shapes it can take -
      // an array, {items}, or a plain object map - so the page renders instead of guessing.
      const list: FlagRow[] = Array.isArray(data)
        ? (data as FlagRow[])
        : Array.isArray(data?.items)
          ? (data.items as FlagRow[])
          : data && typeof data === 'object'
            ? Object.entries(data as Record<string, unknown>).map(([key, value]) => ({ key, flag: key, value }))
            : [];
      setRows(list);
    } catch (e) {
      setError((e as Error).message);
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const setFlag = async (flag: string, value: boolean) => {
    setBusy(flag);
    setError(null);
    setNotice(null);
    const attempt = () => platformApi('/platform/flags', { method: 'POST', body: JSON.stringify({ flag, value }) });
    try {
      await attempt();
      setNotice(t('platform_gym_action_done').replace('{action}', `${flag} = ${value}`));
      await load();
    } catch (first) {
      if (!isStepUpRequired(first)) {
        setError(String((first as Error)?.message ?? first));
        return;
      }
      // A claim expires after five minutes, so an action is retried ONCE after the owner
      // completes step-up. If they cancel, nothing is sent and the page says so.
      const granted = await stepUp(t('platform_flags_title'));
      if (!granted) {
        setError(t('platform_gym_step_up_cancelled'));
        return;
      }
      try {
        await attempt();
        setNotice(t('platform_gym_action_done').replace('{action}', `${flag} = ${value}`));
        await load();
      } catch (second) {
        setError(String((second as Error)?.message ?? second));
      }
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="p-4 sm:p-6">
      <h1 className="text-2xl font-black sm:text-3xl">{t('platform_flags_title')}</h1>
      <p className="mt-1 text-sm text-white/60">{t('platform_flags_intro')}</p>

      {notice && <div className="mt-3 rounded-2xl border border-emerald-400/30 bg-emerald-400/10 p-3 text-xs text-emerald-200">{notice}</div>}
      {error && <div className="mt-3 rounded-2xl border border-red-400/40 bg-red-500/10 p-3 text-xs text-red-200">{error}</div>}

      <section className="mt-4 rounded-2xl border border-white/10 bg-black/40 p-4">
        <h2 className="text-xs font-bold uppercase tracking-wide text-white/45">{t('platform_flags_add')}</h2>
        <div className="mt-2 flex flex-col gap-2 sm:flex-row">
          <input
            aria-label={t('platform_flags_name')}
            className="min-h-[44px] flex-1 rounded-xl border border-white/10 bg-black/50 px-3 font-mono text-sm"
            onChange={(event) => setNewFlag(event.target.value)}
            placeholder={t('platform_flags_name')}
            value={newFlag}
          />
          <button
            className="min-h-[44px] rounded-xl border border-white/10 bg-white/5 px-4 text-sm text-white/80"
            onClick={() => setNewValue((value) => !value)}
            type="button"
          >
            {newValue ? t('platform_yes') : t('platform_no')}
          </button>
          <button
            className="min-h-[44px] rounded-xl bg-[#c5a059] px-4 text-sm font-bold text-black disabled:opacity-40"
            disabled={!newFlag.trim() || busy !== null}
            onClick={() => void setFlag(newFlag.trim(), newValue)}
            type="button"
          >
            {t('platform_flags_set')}
          </button>
        </div>
      </section>

      <div className="mt-4 space-y-2">
        {loading && <div className="p-4 text-sm text-white/50">{t('platform_loading')}</div>}
        {!loading && rows.length === 0 && (
          <div className="rounded-2xl border border-white/10 bg-black/30 p-6 text-center text-sm text-white/50">
            {t('platform_flags_empty')}
          </div>
        )}
        {!loading &&
          rows.map((row) => {
            const name = String(row.flag ?? row.key ?? row.name ?? '?');
            const on = row.value === true || row.value === 'true';
            return (
              <article className="flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-black/40 p-4" key={name}>
                <div className="min-w-0">
                  <div className="truncate font-mono text-sm font-bold">{name}</div>
                  {row.gymId ? <div className="truncate text-[11px] text-white/45">gym {String(row.gymId)}</div> : null}
                </div>
                <button
                  className={`min-h-[44px] shrink-0 rounded-xl px-4 text-sm font-bold disabled:opacity-40 ${
                    on ? 'bg-emerald-400/20 text-emerald-200' : 'border border-white/10 text-white/60'
                  }`}
                  disabled={busy === name}
                  onClick={() => void setFlag(name, !on)}
                  type="button"
                >
                  {busy === name ? '…' : on ? t('platform_yes') : t('platform_no')}
                </button>
              </article>
            );
          })}
      </div>
    </div>
  );
}
