'use client';
/**
 * FLEXORA Gym OS - Web
 * (c) 2024 Ammar Allam. All rights reserved.
 */
/**
 * PHASE R1 - the console's API client and its session gate.
 *
 * Three things changed here, and each one is forced by an api-side rule:
 *
 *   1. R1.6 CSRF. Every state-changing platform request must double-submit the
 *      readable flx_platform_csrf cookie in an x-csrf-token header. Before R1 the
 *      console sent no such header, and it did not matter only because the api's
 *      CsrfMiddleware never ran (measured: work/r1-evidence/00-before.log B2).
 *   2. R1.1 the enrolment gate. An administrator who has not enrolled TOTP gets 403
 *      TOTP_ENROLMENT_REQUIRED from every route except the enrolment ones. The old
 *      gate here probed /platform/health and redirected to /platform/login on any
 *      failure, which with R1 in place would have bounced an unenrolled owner
 *      between login and dashboard forever. It now asks /platform/auth/me - which is
 *      explicitly allowed before enrolment - and renders the enrolment flow.
 *   3. R1.5 step-up. A 403 STEP_UP_REQUIRED is not an error to display, it is a
 *      request for a fresh authenticator code. platformAction() catches it, opens
 *      the step-up prompt and retries the ORIGINAL request once.
 *
 * Errors carry their status and machine-readable code so callers can branch on the
 * reason instead of parsing a message. The message text is unchanged ('HTTP 403')
 * for anything that was already catching it.
 */
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { PlatformTotpEnrolment } from './platform-totp-enrol';

// Empty NEXT_PUBLIC_API_URL -> same-origin proxy mode.
const API_ORIGIN = (process.env.NEXT_PUBLIC_API_URL || '').replace(/\/$/, '');
const API_BASE = API_ORIGIN ? (API_ORIGIN.endsWith('/api') ? API_ORIGIN : `${API_ORIGIN}/api`) : '/api';

export const PLATFORM_CSRF_COOKIE = 'flx_platform_csrf';
const SAFE_METHODS = ['GET', 'HEAD', 'OPTIONS'];

export class PlatformApiError extends Error {
  readonly status: number;
  readonly code: string | null;
  readonly body: unknown;
  constructor(message: string, status: number, code: string | null, body: unknown) {
    super(message);
    this.name = 'PlatformApiError';
    this.status = status;
    this.code = code;
    this.body = body;
  }
}

/** The readable half of the double-submit pair. Never the session cookie. */
/**
 * PHASE R3 (R3.8) - download a file from a platform route, keeping API_BASE private.
 *
 * A CSV export cannot go through platformApi, which parses the body as JSON. This fetches
 * with the same credentials, reads the filename the server chose out of Content-Disposition
 * and hands the bytes to the browser as a blob. It reports the truncation headers the export
 * sets, so the console can tell an operator that a download was capped rather than letting
 * them believe they have the whole history.
 */
/**
 * PHASE R4 (R4.7/R4.8) - a GET that also returns the cache verdict.
 *
 * platformApi is left alone: eleven pages call it and none of them need headers. The Overview
 * does, because R4.8's fallback has to be VISIBLE - an operator debugging a Redis outage should
 * be able to see that the page is serving uncached data instead of having to read an api log.
 * The api reports it in `x-flexora-cache` as `hit` or `miss-<reason>` where reason is miss
 * (cold), timeout (Redis slower than the 250 ms bound) or unavailable (Redis rejected).
 *
 * It also returns ok/status instead of throwing, because the page renders three independent
 * requests and one failing must not blank the other two.
 */
export async function platformApiMeta(
  path: string,
): Promise<{ data: any; cache: string | null; ok: boolean; status: number }> {
  const res = await fetch(`${API_BASE}${path}`, {
    credentials: 'include',
    headers: { 'Content-Type': 'application/json' },
  });
  const text = await res.text();
  let body: unknown = null;
  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    body = text;
  }
  return { data: body, cache: res.headers.get('x-flexora-cache'), ok: res.ok, status: res.status };
}

export async function platformDownload(
  path: string,
  fallbackName: string,
): Promise<{ filename: string; rows: string | null; matching: string | null; truncated: boolean }> {
  const res = await fetch(`${API_BASE}${path}`, { credentials: 'include' });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(text ? `${res.status}: ${text.slice(0, 200)}` : `download failed (${res.status})`);
  }
  const disposition = res.headers.get('content-disposition') ?? '';
  const match = /filename="?([^";]+)"?/.exec(disposition);
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = match?.[1] ?? fallbackName;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  // Revoking on the next tick, not immediately: some browsers have not started the
  // download yet when click() returns.
  setTimeout(() => URL.revokeObjectURL(url), 4000);
  return {
    filename: anchor.download,
    rows: res.headers.get('x-flexora-audit-rows'),
    matching: res.headers.get('x-flexora-audit-matching'),
    truncated: res.headers.get('x-flexora-audit-truncated') === 'true',
  };
}

export function readCsrfToken(): string | null {
  if (typeof document === 'undefined') return null;
  const match = new RegExp(`(?:^|;\\s*)${PLATFORM_CSRF_COOKIE}=([^;]+)`).exec(document.cookie);
  return match ? decodeURIComponent(match[1]) : null;
}

export async function platformApi(path: string, opts: RequestInit = {}): Promise<any> {
  const method = String(opts.method || 'GET').toUpperCase();
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...((opts.headers as Record<string, string>) || {}),
  };
  if (!SAFE_METHODS.includes(method)) {
    const token = readCsrfToken();
    // Only attach it when there is one: the login call happens before any cookie
    // exists, and that route is exempt on the api side.
    if (token) headers['x-csrf-token'] = token;
  }

  const res = await fetch(`${API_BASE}${path}`, { ...opts, credentials: 'include', headers });
  const text = await res.text();
  let body: unknown = null;
  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    body = text;
  }
  if (!res.ok) {
    const code = body && typeof body === 'object' && 'code' in body ? String((body as Record<string, unknown>).code) : null;
    throw new PlatformApiError(`HTTP ${res.status}`, res.status, code, body);
  }
  return body;
}

/**
 * A state-changing console action. On STEP_UP_REQUIRED it asks for a fresh
 * authenticator code through `prompt` and retries the same request once.
 */
export async function platformAction(
  path: string,
  opts: RequestInit,
  prompt: (action: string) => Promise<boolean>,
): Promise<any> {
  try {
    return await platformApi(path, opts);
  } catch (error) {
    if (error instanceof PlatformApiError && error.code === 'STEP_UP_REQUIRED') {
      const action = error.body && typeof error.body === 'object' ? String((error.body as Record<string, unknown>).action || '') : '';
      const asserted = await prompt(action);
      if (!asserted) throw error;
      return platformApi(path, opts);
    }
    throw error;
  }
}

export type GateState = 'loading' | 'enrol' | 'ok' | 'out';

export function PlatformGuard({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [state, setState] = useState<GateState>('loading');

  useEffect(() => {
    let cancelled = false;
    platformApi('/platform/auth/me')
      .then((me: any) => {
        if (cancelled) return;
        setState(me?.admin?.totpEnabled ? 'ok' : 'enrol');
      })
      .catch((error: unknown) => {
        if (cancelled) return;
        if (error instanceof PlatformApiError && error.status === 401) {
          setState('out');
          router.replace('/platform/login');
          return;
        }
        // Anything else (the api being down, a network failure) must not render the
        // console as though it were authorised.
        setState('out');
      });
    return () => {
      cancelled = true;
    };
  }, [router]);

  if (state === 'enrol') return <PlatformTotpEnrolment onEnrolled={() => setState('ok')} />;
  return state === 'ok' ? <>{children}</> : null;
}
