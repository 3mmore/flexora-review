'use client';
/**
 * FLEXORA Gym OS — Owner Console
 * © 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R4 (R4.6, R4.7, R4.8) — the Overview.
 *
 * BEFORE (measured): this page was 43 lines. It fetched /platform/overview, mapped three fields
 * and rendered three numbers - gyms, members, revenue - with `.catch(() => undefined)`, so a
 * failed request rendered zeros that were indistinguishable from a platform with no gyms. There
 * were no charts, nothing was cached, and the two twelve-month series the api already exposed
 * (/platform/revenue/chart and /platform/gyms/growth) were never fetched by anything.
 *
 * AFTER: three requests in parallel, inline SVG charts, a period-over-period delta, an explicit
 * error state with a retry, and a visible cache verdict. Mobile first: the stat grid is one
 * column at 375 px and the charts are width:100% over a fixed viewBox, so nothing measures
 * anything at runtime and nothing overflows.
 *
 * The three requests fail INDEPENDENTLY. Revenue being unavailable must not blank the gym count,
 * and a chart with no data renders its axis rather than vanishing - which is why platformApiMeta
 * returns ok/status instead of throwing.
 */
import { useCallback, useEffect, useState } from 'react';
import { platformApiMeta } from '../platform-guard';
import { AreaSeries, BarSeries, DeltaBadge, SegmentBar, type SeriesPoint } from '../platform-charts';
import { useTranslation } from '@/lib/i18n';
import { PLAN_CODES, label } from '@/lib/i18n/codes';

type Overview = {
  totalGyms?: number;
  activeGyms?: number;
  deletedGyms?: number;
  trialGyms?: number;
  totalMembers?: number;
  monthlyRevenue?: number;
  previousMonthRevenue?: number;
  totalRevenue?: number;
  planDistribution?: Record<string, number>;
};

type LoadState = 'loading' | 'ready' | 'error';

export default function PlatformDashboardPage() {
  const { t, lang } = useTranslation();
  const rtl = lang === 'ar';
  const locale = rtl ? 'ar-EG' : 'en-GB';

  const [overview, setOverview] = useState<Overview | null>(null);
  const [revenue, setRevenue] = useState<SeriesPoint[]>([]);
  const [growth, setGrowth] = useState<SeriesPoint[]>([]);
  const [state, setState] = useState<LoadState>('loading');
  const [failed, setFailed] = useState<string[]>([]);
  const [cacheVerdicts, setCacheVerdicts] = useState<string[]>([]);
  const [reloadToken, setReloadToken] = useState(0);

  const load = useCallback(async () => {
    setState('loading');
    setFailed([]);
    // Three independent requests. Promise.allSettled, not Promise.all: one failing endpoint
    // must not discard the two that worked, which is what the old .catch(() => undefined)
    // version effectively did to the whole page.
    const [overviewResult, revenueResult, growthResult] = await Promise.allSettled([
      platformApiMeta('/platform/overview'),
      platformApiMeta('/platform/revenue/chart?months=12'),
      platformApiMeta('/platform/gyms/growth?months=12'),
    ]);

    const names = ['overview', 'revenue/chart', 'gyms/growth'];
    const results = [overviewResult, revenueResult, growthResult];
    const failedNames: string[] = [];
    const verdicts: string[] = [];

    results.forEach((result, index) => {
      if (result.status === 'rejected' || !result.value.ok) {
        failedNames.push(names[index]);
        return;
      }
      if (result.value.cache) verdicts.push(result.value.cache);
    });

    if (overviewResult.status === 'fulfilled' && overviewResult.value.ok) {
      setOverview(overviewResult.value.data as Overview);
    }
    if (revenueResult.status === 'fulfilled' && revenueResult.value.ok) {
      setRevenue(Array.isArray(revenueResult.value.data) ? (revenueResult.value.data as SeriesPoint[]) : []);
    }
    if (growthResult.status === 'fulfilled' && growthResult.value.ok) {
      setGrowth(Array.isArray(growthResult.value.data) ? (growthResult.value.data as SeriesPoint[]) : []);
    }

    setCacheVerdicts(verdicts);
    setFailed(failedNames);
    // The page is an error only if the OVERVIEW failed; the charts are enhancements and their
    // absence is reported inline rather than replacing the numbers with a red screen.
    setState(failedNames.includes('overview') ? 'error' : 'ready');
  }, []);

  useEffect(() => {
    void load();
  }, [load, reloadToken]);

  const money = (value: number | undefined) =>
    `${Math.round(Number(value) || 0).toLocaleString(locale)} ${rtl ? 'ج.م' : 'EGP'}`;
  const count = (value: number | undefined) => (Number(value) || 0).toLocaleString(locale);

  const distribution = overview?.planDistribution ?? {};
  const segments = PLAN_CODES.map((tier) => ({
    key: tier,
    // the code stays the segment's identity/colour; the LABEL is Arabic
    label: label(tier, 'plan', lang === 'en' ? 'en' : 'ar'),
    value: Number(distribution[tier] ?? 0),
  }));

  // R4.8 made visible: 'hit' means cached, anything else names why it was not.
  const cacheLabel = (() => {
    if (!cacheVerdicts.length) return null;
    if (cacheVerdicts.every((verdict) => verdict === 'hit')) return t('platform_overview_cached');
    if (cacheVerdicts.some((verdict) => verdict.includes('timeout') || verdict.includes('unavailable'))) {
      return t('platform_overview_cache_degraded');
    }
    return t('platform_overview_live');
  })();

  return (
    <div className="p-4 sm:p-6">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h1 className="text-2xl font-black sm:text-3xl">{t('platform_dashboard')}</h1>
        {cacheLabel && (
          <span className="rounded-lg border border-white/10 bg-white/5 px-2 py-1 text-[11px] text-white/55">
            {cacheLabel}
          </span>
        )}
      </div>
      <p className="mt-1 text-sm text-white/60">{t('platform_overview_intro')}</p>

      {state === 'loading' && <div className="mt-6 text-sm text-white/50">{t('platform_loading')}</div>}

      {state === 'error' && (
        <div className="mt-4 rounded-2xl border border-red-400/40 bg-red-500/10 p-4 text-sm text-red-200">
          <div className="font-black">{t('platform_overview_error')}</div>
          <p className="mt-1 text-red-200/80">{t('platform_overview_error_body')}</p>
          <button
            className="mt-3 rounded-xl bg-[#c5a059] px-4 py-2 text-sm font-bold text-black"
            onClick={() => setReloadToken((value) => value + 1)}
            type="button"
          >
            {t('platform_overview_retry')}
          </button>
        </div>
      )}

      {state === 'ready' && (
        <>
          {/* One column at 375 px. The old page used md:grid-cols-3, which is fine, but the
              cards themselves had text-4xl numbers that overflowed a 375 px column when the
              revenue figure got long - hence the smaller type and the break-all. */}
          <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            <Card label={t('platform_overview_active_gyms')} value={count(overview?.activeGyms)}>
              <span className="text-xs text-white/45">
                {t('platform_overview_of_total')} {count(overview?.totalGyms)}
              </span>
            </Card>
            <Card label={t('platform_overview_monthly_revenue')} value={money(overview?.monthlyRevenue)}>
              <DeltaBadge
                current={Number(overview?.monthlyRevenue) || 0}
                downLabel={t('platform_overview_down')}
                flatLabel={t('platform_overview_no_comparison')}
                previous={Number(overview?.previousMonthRevenue) || 0}
                upLabel={t('platform_overview_up')}
              />
            </Card>
            <Card label={t('total_members')} value={count(overview?.totalMembers)} />
            <Card label={t('platform_overview_trial_gyms')} value={count(overview?.trialGyms)} />
            <Card label={t('platform_overview_deleted_gyms')} value={count(overview?.deletedGyms)}>
              <span className="text-xs text-white/45">{t('platform_overview_restore_window')}</span>
            </Card>
            <Card label={t('platform_overview_plans')} value={segments.filter((s) => s.value > 0).length ? '' : '0'}>
              <SegmentBar label={t('platform_overview_plans')} segments={segments} />
              <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1 text-[11px] text-white/50">
                {segments.map((segment, index) => (
                  <span key={segment.key}>
                    <span className="mr-1 inline-block h-2 w-2 rounded-sm" style={{ background: '#c5a059', opacity: [0.95, 0.62, 0.34][index] }} />
                    {segment.label} · {segment.value}
                  </span>
                ))}
              </div>
            </Card>
          </div>

          {failed.length > 0 && (
            <div className="mt-3 rounded-2xl border border-amber-400/40 bg-amber-400/10 p-3 text-xs text-amber-100">
              {t('platform_overview_partial').replace('{which}', failed.join(', '))}
            </div>
          )}

          <div className="mt-4 grid grid-cols-1 gap-3 lg:grid-cols-2">
            <Panel title={t('platform_overview_revenue_chart')}>
              {revenue.length ? (
                <AreaSeries
                  label={t('platform_overview_revenue_chart')}
                  locale={locale}
                  points={revenue}
                  rtl={rtl}
                  valueFormat={(value) => money(value)}
                />
              ) : (
                <Empty note={t('platform_overview_no_series')} />
              )}
            </Panel>
            <Panel title={t('platform_overview_growth_chart')}>
              {growth.length ? (
                <BarSeries label={t('platform_overview_growth_chart')} locale={locale} points={growth} rtl={rtl} />
              ) : (
                <Empty note={t('platform_overview_no_series')} />
              )}
            </Panel>
          </div>
        </>
      )}
    </div>
  );
}

function Card({ label, value, children }: { label: string; value: string; children?: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.04] p-4">
      <div className="text-xs font-bold uppercase tracking-wide text-white/45">{label}</div>
      {value ? <div className="mt-1 break-all text-2xl font-black sm:text-3xl">{value}</div> : null}
      {children ? <div className="mt-1">{children}</div> : null}
    </div>
  );
}

function Panel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-2xl border border-white/10 bg-black/40 p-4">
      <h2 className="text-sm font-bold text-white/70">{title}</h2>
      <div className="mt-3">{children}</div>
    </section>
  );
}

function Empty({ note }: { note: string }) {
  return <div className="py-6 text-center text-xs text-white/40">{note}</div>;
}
