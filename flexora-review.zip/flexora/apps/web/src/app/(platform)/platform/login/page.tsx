'use client';
import { useState } from 'react';
import { useTranslation } from '@/lib/i18n';

export default function PlatformLoginPage() {
  const { t, lang } = useTranslation();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');
  
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr('');
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || ''}/api/platform/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      if (!res.ok) throw new Error(t('invalid_platform_credentials'));
      location.href = '/platform/dashboard';
    } catch (e: any) {
      setErr(e.message);
    }
  }

  return (
    <main dir={lang === 'ar' ? 'rtl' : 'ltr'} className="grid min-h-screen place-items-center bg-[#050505] p-5 text-white">
      <form onSubmit={submit} className="w-full max-w-sm rounded-3xl border border-white/10 bg-white/[0.04] p-8">
        <h1 className="text-2xl font-black">{t('platform_login_title')}</h1>
        {err && <div className="mt-4 rounded-xl bg-red-500/10 p-3 text-sm text-red-400">{err}</div>}
        <div className="mt-6 space-y-4">
          <input 
            className="w-full rounded-xl border border-white/10 bg-black/40 p-3" 
            type="email" 
            placeholder={t('email')} 
            value={email} 
            onChange={e => setEmail(e.target.value)} 
            required 
          />
          <input 
            className="w-full rounded-xl border border-white/10 bg-black/40 p-3" 
            type="password" 
            placeholder={t('password')} 
            value={password} 
            onChange={e => setPassword(e.target.value)} 
            required 
          />
          <button className="w-full rounded-xl bg-[#c5a059] p-3 font-bold text-black">{t('sign_in')}</button>
        </div>
      </form>
    </main>
  );
}
