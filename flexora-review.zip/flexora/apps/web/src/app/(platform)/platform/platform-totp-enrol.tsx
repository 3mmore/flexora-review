'use client';
/**
 * FLEXORA Gym OS - Web
 * (c) 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1.1 - mandatory authenticator enrolment, shown instead of the console
 * until it is complete. Mobile-first: the owner enrols from a phone, so the QR is
 * optional and the manual key is always available, and the recovery codes are
 * presented as text that can be copied rather than as a download.
 *
 * The secret and the ten recovery codes exist in this component's state and in the
 * api response, once. Nothing here persists them: a reload starts enrolment again,
 * which is the intended behaviour for a code that was not written down.
 */
import { useEffect, useState } from 'react';
import { useTranslation } from '@/lib/i18n';
import { PlatformApiError, platformApi } from './platform-guard';

type Stage = 'loading' | 'scan' | 'codes' | 'failed';

interface Enrolment {
  secret: string;
  otpauthUrl: string;
  qrCodeDataUrl: string;
  issuer: string;
}

export function PlatformTotpEnrolment({ onEnrolled }: { onEnrolled: () => void }) {
  const { t, lang } = useTranslation();
  const [stage, setStage] = useState<Stage>('loading');
  const [enrolment, setEnrolment] = useState<Enrolment | null>(null);
  const [code, setCode] = useState('');
  const [recoveryCodes, setRecoveryCodes] = useState<string[]>([]);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let cancelled = false;
    platformApi('/platform/auth/totp/enrol', { method: 'POST' })
      .then((result: Enrolment) => {
        if (cancelled) return;
        setEnrolment(result);
        setStage('scan');
      })
      .catch((err: unknown) => {
        if (cancelled) return;
        setError(err instanceof PlatformApiError ? `${t('platform_totp_enrol_failed')} (${err.status})` : t('platform_totp_enrol_failed'));
        setStage('failed');
      });
    return () => {
      cancelled = true;
    };
    // Runs once per mount: re-requesting would mint a second secret.
  }, [t]);

  async function verify(event: React.FormEvent) {
    event.preventDefault();
    if (!code) return;
    setBusy(true);
    setError('');
    try {
      const result = await platformApi('/platform/auth/totp/verify', { method: 'POST', body: JSON.stringify({ code }) });
      setRecoveryCodes(Array.isArray(result?.recoveryCodes) ? result.recoveryCodes : []);
      setStage('codes');
    } catch (err) {
      setError(
        err instanceof PlatformApiError && err.code
          ? t(err.code === 'totp-replayed' ? 'platform_totp_replayed' : 'platform_totp_invalid')
          : t('platform_totp_invalid'),
      );
    } finally {
      setBusy(false);
    }
  }

  const dir = lang === 'ar' ? 'rtl' : 'ltr';

  return (
    <main dir={dir} className="grid min-h-screen place-items-start bg-[#050505] p-5 text-white sm:place-items-center">
      <div className="w-full max-w-md rounded-3xl border border-white/10 bg-white/[0.04] p-6">
        <h1 className="text-xl font-black text-[#c5a059]">{t('platform_totp_enrol_title')}</h1>
        <p className="mt-2 text-sm text-white/70">{t('platform_totp_enrol_intro')}</p>

        {stage === 'loading' && <p className="mt-6 text-sm text-white/50">{t('loading')}</p>}
        {stage === 'failed' && <p className="mt-6 rounded-xl bg-red-500/10 p-3 text-sm text-red-400">{error}</p>}

        {stage === 'scan' && enrolment && (
          <form onSubmit={verify} className="mt-6 space-y-4">
            {/* eslint-disable-next-line @next/next/no-img-element -- a data URL produced by the api, not a remote asset */}
            <img src={enrolment.qrCodeDataUrl} alt={t('platform_totp_qr_alt')} width={200} height={200} className="mx-auto rounded-2xl bg-white p-2" />
            <div className="rounded-xl border border-white/10 bg-black/40 p-3">
              <div className="text-xs uppercase tracking-wide text-white/50">{t('platform_totp_manual_key')}</div>
              <div className="mt-1 break-all font-mono text-sm text-white/90">{enrolment.secret}</div>
            </div>
            {error && <p className="rounded-xl bg-red-500/10 p-3 text-sm text-red-400">{error}</p>}
            <input
              className="w-full rounded-xl border border-white/10 bg-black/40 p-3 text-center font-mono text-lg tracking-[0.4em]"
              inputMode="numeric"
              autoComplete="one-time-code"
              maxLength={6}
              placeholder="000000"
              aria-label={t('platform_totp_code')}
              value={code}
              onChange={(event) => setCode(event.target.value.replace(/\D/g, '').slice(0, 6))}
            />
            <button disabled={busy || code.length !== 6} className="w-full rounded-xl bg-[#c5a059] p-3 font-bold text-black disabled:opacity-40">
              {busy ? t('loading') : t('platform_totp_verify')}
            </button>
          </form>
        )}

        {stage === 'codes' && (
          <div className="mt-6 space-y-4">
            <p className="text-sm text-white/80">{t('platform_totp_recovery_intro')}</p>
            <ol className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {recoveryCodes.map((value, index) => (
                <li key={value} className="rounded-xl border border-white/10 bg-black/40 p-2 font-mono text-xs break-all">
                  <span className="mr-2 text-white/40">{index + 1}.</span>
                  {value}
                </li>
              ))}
            </ol>
            <label className="flex items-start gap-3 text-sm text-white/70">
              <input type="checkbox" checked={saved} onChange={(event) => setSaved(event.target.checked)} className="mt-1" />
              {t('platform_totp_recovery_saved')}
            </label>
            <button
              disabled={!saved}
              onClick={onEnrolled}
              className="w-full rounded-xl bg-[#c5a059] p-3 font-bold text-black disabled:opacity-40"
            >
              {t('platform_continue')}
            </button>
            <p className="text-xs text-white/40">{t('platform_totp_recovery_warning')}</p>
          </div>
        )}
      </div>
    </main>
  );
}
