/**
 * FLEXORA Campaign Intelligence Center
 * Growth and retention campaign operations built on existing campaign/member APIs.
 */
'use client';
import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { useTranslation } from '@/lib/i18n';
import { ActionCenter, FeedbackLayer, InsightCard, InsightLayer, ProductPage, SmartAction, SmartTable } from '@/components/ProductOS';
import { Card } from '@/components/ui/Card';
import { EmptyState, Skeleton } from '@/components/ui/States';
import { Icon } from '@/components/brand/Icon';
import { safeErrorMessage } from '@/lib/safe-error';
import { fmtMoney } from '@/lib/money';
import { ModalPortal } from '@/components/ModalPortal';

type Campaign = {
  id: string;
  name: string;
  channel: 'INAPP' | 'EMAIL' | 'WHATSAPP' | 'SMS';
  body: string;
  templateKey?: string;
  status: 'DRAFT' | 'SCHEDULED' | 'SENDING' | 'COMPLETED' | 'CANCELLED';
  scheduledAt?: string;
  statsSent: number;
  statsFailed: number;
  createdAt: string;
};

type Member = {
  id: string;
  name: string;
  mobile?: string;
  vip?: boolean;
  status?: string;
  expiry?: string | null;
  lastVisit?: string | null;
  visits?: number;
  plan?: { name?: string; price?: number | string } | null;
};

type Sale = { id: string; memberId?: string | null; total?: number | string; createdAt?: string };
type AudienceKey = 'expiring' | 'churn' | 'inactive' | 'highValue' | 'vip' | 'frequent' | 'lowAttendance';

const money = (value?: number | string) => fmtMoney(value);
const daysUntil = (date?: string | null) => date ? Math.ceil((+new Date(date) - Date.now()) / 86400000) : null;
const daysSince = (date?: string | null) => date ? Math.max(0, Math.round((Date.now() - +new Date(date)) / 86400000)) : 999;

export default function CampaignIntelligenceCenter() {
  const { t } = useTranslation();
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [selectedAudience, setSelectedAudience] = useState<AudienceKey>('expiring');
  const [form, setForm] = useState({ name: '', channel: 'WHATSAPP' as Campaign['channel'], body: '', templateKey: '', audienceFilter: 'expiring' as AudienceKey });
  const [busy, setBusy] = useState(true);
  const [err, setErr] = useState('');
  const [feedback, setFeedback] = useState('');

  async function load() {
    setBusy(true);
    setErr('');
    try {
      const [c, m, s] = await Promise.all([
        api<Campaign[]>('/campaigns'),
        api<{ items: Member[] }>('/members?limit=500').then((r) => r.items || []),
        api<{ items: Sale[] }>('/sales?limit=250').then((r) => r.items || []),
      ]);
      setCampaigns(c);
      setMembers(m);
      setSales(s);
    } catch (e: unknown) {
      setErr((e as Error).message || t('operation_failed'));
    } finally {
      setBusy(false);
    }
  }
  useEffect(() => { load(); }, []);

  const memberRevenue = useMemo(() => {
    const map = new Map<string, number>();
    for (const sale of sales) if (sale.memberId) map.set(sale.memberId, (map.get(sale.memberId) || 0) + Number(sale.total || 0));
    return map;
  }, [sales]);

  const audiences = useMemo(() => {
    const expiring = members.filter((m) => { const d = daysUntil(m.expiry); return d != null && d >= 0 && d <= 30; });
    const churn = members.filter((m) => daysSince(m.lastVisit) >= 14 || m.status === 'expired' || m.status === 'soon');
    const inactive = members.filter((m) => daysSince(m.lastVisit) >= 30);
    const highValue = members.filter((m) => (memberRevenue.get(m.id) || 0) >= 1000).sort((a, b) => (memberRevenue.get(b.id) || 0) - (memberRevenue.get(a.id) || 0));
    const vip = members.filter((m) => m.vip);
    const frequent = members.filter((m) => (m.visits || 0) >= 10);
    const lowAttendance = members.filter((m) => daysSince(m.lastVisit) >= 7 && daysSince(m.lastVisit) < 30);
    const value = (rows: Member[]) => rows.reduce((sum, m) => sum + Number(m.plan?.price || memberRevenue.get(m.id) || 0), 0);
    return {
      expiring: { label: t('expiring_soon_label'), rows: expiring, reason: t('renewal_val_influenced'), value: value(expiring) },
      churn: { label: t('high_churn_risk'), rows: churn, reason: t('recovery_recommended'), value: value(churn) },
      inactive: { label: t('inactive_members_label'), rows: inactive, reason: t('prioritize_contact'), value: value(inactive) },
      highValue: { label: t('high_value_members'), rows: highValue, reason: t('revenue_contribution_desc'), value: value(highValue) },
      vip: { label: t('vip_members'), rows: vip, reason: t('vip_members'), value: value(vip) },
      frequent: { label: t('frequent_visitors'), rows: frequent, reason: t('upsell'), value: value(frequent) },
      lowAttendance: { label: t('low_attendance_label'), rows: lowAttendance, reason: t('monitor_attendance'), value: value(lowAttendance) },
    } as Record<AudienceKey, { label: string; rows: Member[]; reason: string; value: number }>;
  }, [members, memberRevenue, t]);

  const selected = audiences[selectedAudience];
  const activeCampaigns = campaigns.filter((c) => ['SCHEDULED', 'SENDING'].includes(c.status));
  const completed = campaigns.filter((c) => c.status === 'COMPLETED');
  const sent = campaigns.reduce((sum, c) => sum + Number(c.statsSent || 0), 0);
  const failed = campaigns.reduce((sum, c) => sum + Number(c.statsFailed || 0), 0);
  const successRate = sent + failed ? Math.round((sent / (sent + failed)) * 100) : 0;
  const revenueInfluenced = completed.reduce((sum, c) => sum + Math.max(0, Number(c.statsSent || 0) - Number(c.statsFailed || 0)) * 150, 0);
  const retentionRecoveries = Math.round((completed.reduce((sum, c) => sum + Number(c.statsSent || 0), 0) || 0) * 0.08);
  const renewalValue = audiences.expiring.value;
  const upgradeValue = audiences.frequent.rows.length * 250;
  const topOpportunity = Object.entries(audiences).sort((a, b) => b[1].value - a[1].value)[0];

  function seedCampaign(audience: AudienceKey, type: 'renewal' | 'recovery' | 'vip' | 'referral' | 'upgrade') {
    const label = audiences[audience].label;
    const bodyByType = {
      renewal: t('campaign_tpl_renewal'),
      recovery: t('campaign_tpl_recovery'),
      vip: t('campaign_tpl_vip'),
      referral: t('campaign_tpl_referral'),
      upgrade: t('campaign_tpl_upgrade'),
    }[type];
    setSelectedAudience(audience);
    setForm({ name: `${label} — ${t('campaign')}`, channel: 'WHATSAPP', body: bodyByType, templateKey: type.toUpperCase(), audienceFilter: audience });
    setShowCreate(true);
  }

  async function create() {
    try {
      await api('/campaigns', { method: 'POST', body: JSON.stringify({ ...form, audienceFilter: { segment: form.audienceFilter } }) });
      setShowCreate(false);
      setFeedback(`${form.name} draft created.`);
      setForm({ name: '', channel: 'WHATSAPP', body: '', templateKey: '', audienceFilter: 'expiring' });
      await load();
    } catch (e: unknown) { setErr((e as Error).message || t('operation_failed')); }
  }

  async function send(id: string) {
    try {
      await api(`/campaigns/${id}/send`, { method: 'POST' });
      setFeedback('Campaign queued.');
      await load();
    } catch (e: unknown) { setErr((e as Error).message || t('operation_failed')); }
  }
  async function cancel(id: string) { try { await api(`/campaigns/${id}/cancel`, { method: 'POST' }); await load(); } catch (e: unknown) { setErr(safeErrorMessage(e)); } }
  async function remove(id: string) { try { await api(`/campaigns/${id}`, { method: 'DELETE' }); await load(); } catch (e: unknown) { setErr(safeErrorMessage(e)); } }

  const timeline = [
    ...campaigns.map((c) => ({ id: `camp-${c.id}`, type: t(c.status.toLowerCase()) || c.status, title: c.name, detail: `${t(c.channel.toLowerCase()) || c.channel} · ${t('sent')} ${c.statsSent || 0} · ${t('failed')} ${c.statsFailed || 0}`, at: c.createdAt })),
  ].sort((a, b) => +new Date(b.at) - +new Date(a.at));

  return (
    <Shell>
      <ProductPage
        eyebrow={t('campaign_intel_center')}
        title={t('campaign_growth_title')}
        narrative={t('campaign_narrative_desc')}
        primaryAction={{ label: t('launch_renewal_campaign'), icon: 'send', onClick: () => seedCampaign('expiring', 'renewal') }}
        secondaryAction={{ label: t('members'), href: '/members', icon: 'users' }}
      >
        {err && <FeedbackLayer type="danger" title={t('operation_failed')} detail={err} action={<button className="btn btn-ghost px-3 py-1.5 text-xs" onClick={load}>{t('retry')}</button>} />}
        {feedback && <FeedbackLayer type="success" title={t('success')} detail={feedback} action={<button className="btn btn-ghost px-3 py-1.5 text-xs" onClick={() => setFeedback('')}>{t('close')}</button>} />}

        <InsightLayer>
          {busy ? <><Skeleton /><Skeleton /><Skeleton /><Skeleton /></> : <>
            <InsightCard label={t('active_campaigns_label')} value={activeCampaigns.length} detail={`${campaigns.length} ${t('total')}`} icon="send" />
            <InsightCard label={t('members_targeted')} value={sent} detail={t('members_targeted')} icon="users" />
            <InsightCard label={t('revenue_influenced')} value={money(revenueInfluenced)} detail={t('revenue_influenced')} icon="coins" />
            <InsightCard label={t('retention_recoveries')} value={retentionRecoveries} detail={t('retention_recoveries')} icon="shield" tone={retentionRecoveries ? 'good' : 'neutral'} />
          </>}
        </InsightLayer>

        <ActionCenter title={t('campaign_action_center')}>
          <SmartAction title={t('launch_renewal_campaign')} detail={`${audiences.expiring.rows.length} ${t('member')}`} icon="send" onClick={() => seedCampaign('expiring', 'renewal')} />
          <SmartAction title={t('launch_recovery_campaign')} detail={`${audiences.inactive.rows.length} ${t('member')}`} icon="users" onClick={() => seedCampaign('inactive', 'recovery')} />
          <SmartAction title={t('launch_vip_offer')} detail={`${audiences.vip.rows.length} ${t('member')}`} icon="sparkle" onClick={() => seedCampaign('vip', 'vip')} />
        </ActionCenter>

        <section className="campaign-intel-grid">
          <Card padding="lg" className="campaign-audience-center">
            <div className="product-section-head"><div><h2>{t('audience_intel_center')}</h2><p>{t('segments_meaning_desc')}</p></div></div>
            {busy ? <Skeleton lines={9} /> : <div className="campaign-audience-grid">{(Object.keys(audiences) as AudienceKey[]).map((key) => (
              <button key={key} className="campaign-audience-card" onClick={() => { setSelectedAudience(key); setForm((f) => ({ ...f, audienceFilter: key })); }}>
                <span>{audiences[key].label}</span>
                <b>{audiences[key].rows.length}</b>
              </button>
            ))}</div>}
          </Card>

          <Card padding="lg">
            <div className="product-section-head"><div><h2>{t('campaign_opp_center')}</h2><p>{t('expected_rev_impact_desc')}</p></div></div>
            <div className="campaign-opportunity-list">
              <button className="btn btn-secondary w-full mb-2" onClick={() => seedCampaign('expiring', 'renewal')}>{t('launch_renewal_campaign')}</button>
              <button className="btn btn-secondary w-full" onClick={() => seedCampaign('inactive', 'recovery')}>{t('launch_recovery_campaign')}</button>
            </div>
          </Card>

          <Card padding="lg" className="campaign-builder-card">
            <div className="product-section-head"><div><h2>{t('campaign_builder')}</h2><p>{t('builder_desc')}</p></div></div>
            <div className="campaign-builder-preview">
              <div><span>{t('audience_label')}</span><b>{selected.label}</b></div>
              <div><span>{t('channel')}</span><b>{t(form.channel.toLowerCase()) || form.channel}</b></div>
              <div><span>{t('preview')}</span><p>{form.body || t('no_data')}</p></div>
            </div>
          </Card>

          <Card padding="lg">
            <div className="product-section-head"><div><h2>{t('campaign_perf_center')}</h2><p>{t('sent_delivered_opened')}</p></div></div>
            <div className="campaign-performance-grid"><div><span>{t('sent')}</span><b>{sent}</b></div><div><span>{t('success_rate')}</span><b>{successRate}%</b></div></div>
          </Card>

          <Card padding="lg" className="campaign-timeline-card">
            <div className="product-section-head"><div><h2>{t('campaign_timeline_label')}</h2><p>{t('launches_milestones_desc')}</p></div></div>
            {busy ? <Skeleton lines={9} /> : timeline.length ? <div className="campaign-timeline">{timeline.map((e) => <div key={e.id}><div><span>{e.type}</span><b>{e.title}</b></div></div>)}</div> : <EmptyState icon="bell" title={t('no_campaign_timeline')} description={t('launches_appear_here')} />}
          </Card>
        </section>

        <SmartTable
          columns={[t('campaign'), t('channel'), t('status'), t('sent'), t('failed'), t('actions')]}
          rows={campaigns}
          loading={busy}
          emptyTitle={t('no_active_campaigns')}
          emptyDescription={t('choose_opp_create_desc')}
          renderRow={(c: Campaign) => (
            <tr key={c.id}>
              <td>{c.name}</td>
              <td>{t(c.channel.toLowerCase()) || c.channel}</td>
              <td><span className={`badge ${c.status === 'COMPLETED' ? 'badge-active' : 'badge-soon'}`}>{t(c.status.toLowerCase()) || c.status}</span></td>
              <td>{c.statsSent}</td>
              <td>{c.statsFailed}</td>
              <td>
                <span className="row-actions inline-flex gap-2">
                  {c.status === 'DRAFT' && <button className="btn btn-primary btn-sm" onClick={() => send(c.id)}>{t('sent')}</button>}
                  <button className="btn-danger btn-sm" onClick={() => remove(c.id)}>{t('delete')}</button>
                </span>
              </td>
            </tr>
          )}
        />

        {showCreate && (
          <ModalPortal>
        <div className="fixed inset-0 bg-black/70 z-50 grid place-items-center p-4" onClick={() => setShowCreate(false)}>
            <div className="card card-static glass w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
              <h2 className="text-xl font-bold mb-4">{t('build_campaign')}</h2>
              <div className="space-y-3">
                <input className="input w-full" placeholder={t('name')} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                <textarea className="input w-full" rows={4} placeholder={t('description')} value={form.body} onChange={(e) => setForm({ ...form, body: e.target.value })} />
              </div>
              <div className="flex justify-end gap-2 mt-4">
                <button className="btn btn-ghost" onClick={() => setShowCreate(false)}>{t('cancel')}</button>
                <button className="btn btn-primary" onClick={create}>{t('create_draft')}</button>
              </div>
            </div>
          </div>
        </ModalPortal>
        )}
      </ProductPage>
    </Shell>
  );
}
