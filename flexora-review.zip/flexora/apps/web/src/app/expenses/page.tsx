/**
 * FLEXORA Gym OS
 * © 2024 Ammar Allam. All rights reserved.
 */
'use client';
import { useCallback, useEffect, useState } from 'react';
import { formatDate } from '@/lib/dates';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { useTranslation } from '@/lib/i18n';
import { FeedbackLayer, InsightCard, InsightLayer, ProductPage, SmartTable } from '@/components/ProductOS';
import { Skeleton } from '@/components/ui/States';
import { safeErrorMessage } from '@/lib/safe-error';
import { useBranchScope } from '@/lib/branch-scope';
import { fmtMoney } from '@/lib/money';
import { ModalPortal } from '@/components/ModalPortal';

interface Expense {
  id: string;
  category: string;
  description?: string;
  amount: number;
  branch?: { name: string };
  createdAt: string;
}

interface Branch {
  id: string;
  name: string;
}

export default function Expenses() {
  const { t } = useTranslation();
  // ROUND 14 (security review, PHASE B): creating/deleting expenses is an
  // accounting.manage operation (the API enforces it too).
  const [perms, setPerms] = useState<string[] | null>(null);
  useEffect(() => { api<any>('/auth/me').then((r) => setPerms(r?.user?.permissions || [])).catch(() => setPerms([])); }, []);
  const canManageExpenses = perms === null || (perms || []).includes('accounting.manage');
  const [data, setData] = useState<{ items: Expense[], total: number }>({ items: [], total: 0 });
  const [branches, setBranches] = useState<Branch[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<Partial<Expense & { branchId?: string }> | null>(null);

  /** PHASE 4: an Accountant/Reception sees and records only their own branch. */
  const scope = useBranchScope();
  const [err, setErr] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [e, b] = await Promise.all([api<any>('/expenses'), api<any>('/branches')]);
      setData(e);
      setBranches(Array.isArray(b) ? b : (b.items || []));
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!form) return;
    setErr('');
    try {
      // PHASE 4: a restricted user's expense is always booked to their branch,
      // and the API pins it again server-side.
      const branchId = scope.unrestricted ? form.branchId : (scope.branchId || form.branchId);
      await api('/expenses', { method: 'POST', body: JSON.stringify({ ...form, branchId, amount: Number(form.amount) }) });
      setForm(null);
      load();
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    }
  }

  async function del(id: string) {
    if (!confirm(t('delete_expense_confirm'))) return;
    try {
      await api(`/expenses/${id}`, { method: 'DELETE' });
      load();
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    }
  }

  const totalAmount = (data.items || []).reduce((sum: number, item) => sum + Number(item.amount), 0);

  return (
    <Shell>
      <ProductPage
        eyebrow={t('accounting')}
        title={t('expenses')}
        narrative={t('expenses_desc')}
        primaryAction={canManageExpenses ? { label: t('add_expense') || 'إضافة مصروف', icon: 'plus', onClick: () => setForm({ category: 'Other', amount: 0 }) } : undefined}
      >
        {!canManageExpenses && perms !== null && (
          <p className="text-[11px] text-[var(--silver-dim)] mb-3" data-testid="expenses-locked-hint">{t('accounting_manage_required') || 'requires accounting.manage'}</p>
        )}
        <InsightLayer>
          <InsightCard label={t('total_expenses')} value={fmtMoney(totalAmount)} icon="coins" tone="warning" detail={t('total')} />
          <InsightCard label={t('transactions')} value={data.total || data.items?.length || 0} icon="chart" detail={t('records')} />
        </InsightLayer>

        {err && <FeedbackLayer type="danger" title={t('operation_failed')} detail={err} />}

        {loading ? <Skeleton lines={5} /> : (
          <SmartTable
            columns={[t('date'), t('category'), t('description'), t('amount'), t('branch'), t('actions')]}
            rows={data.items || []}
            emptyTitle={t('no_data')}
            emptyDescription={t('expenses_desc')}
            renderRow={(ex) => (
              <tr key={ex.id}>
                <td>{formatDate(ex.createdAt)}</td>
                <td>{t('cat_' + (ex.category || '').toLowerCase()) || ex.category}</td>
                <td>{ex.description || '—'}</td>
                <td>{fmtMoney(ex.amount)}</td>
                <td>{ex.branch?.name || t('all')}</td>
                <td>
                  <span className="row-actions inline-flex gap-2">
                    {canManageExpenses ? (
                      <button className="btn-danger btn-sm" onClick={() => del(ex.id)}>{t('delete')}</button>
                    ) : (
                      <span className="text-[11px] text-[var(--silver-dim)]" data-testid="expenses-locked" title={t('accounting_manage_required') || 'requires accounting.manage'}>{t('accounting_manage_required') || 'requires accounting.manage'}</span>
                    )}
                  </span>
                </td>
              </tr>
            )}
          />
        )}
      </ProductPage>

      {form && (
        <ModalPortal>
        <div className="fixed inset-0 bg-black/70 grid place-items-center p-5 z-50" onClick={() => setForm(null)}>
          <form onClick={(e) => e.stopPropagation()} onSubmit={save} className="card card-static glass w-full max-w-lg">
            <h3 className="text-title text-white mb-4">{t('new_expense')}</h3>
            <div className="grid grid-cols-2 gap-3">
              <input className="input" placeholder={t('category')} value={form.category || ''} onChange={(e) => setForm({ ...form, category: e.target.value })} required />
              <input className="input" type="number" placeholder={t('amount')} value={form.amount} onChange={(e) => setForm({ ...form, amount: Number(e.target.value) })} required />
              <textarea className="input col-span-2" placeholder={t('description')} value={form.description || ''} onChange={(e) => setForm({ ...form, description: e.target.value })} />
              {scope.unrestricted ? (
                <select className="input col-span-2" value={form.branchId || ''} onChange={(e) => setForm({ ...form, branchId: e.target.value || undefined })}>
                  <option value="">{t('all_branches')}</option>
                  {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
                </select>
              ) : (
                <div className="badge badge-active col-span-2" data-testid="expense-branch-locked">
                  {t('branch') || 'Branch'}: {scope.branchName || branches[0]?.name || '—'}
                </div>
              )}
            </div>
            <div className="flex gap-2 justify-end mt-4">
              <button type="button" className="btn-ghost" onClick={() => setForm(null)}>{t('cancel')}</button>
              <button className="btn-primary">{t('save')}</button>
            </div>
          </form>
        </div>
        </ModalPortal>
      )}
    </Shell>
  );
}
