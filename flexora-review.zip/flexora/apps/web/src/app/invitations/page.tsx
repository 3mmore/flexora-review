/**
 * FLEXORA Gym OS
 * © 2024 Ammar Allam. All rights reserved.
 * Unauthorized copying, distribution, or modification of this software
 * is strictly prohibited without written permission from the owner.
 * Contact: FLEXORA support
 */
'use client';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { formatDate } from '@/lib/dates';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { useTranslation } from '@/lib/i18n';
import { revealStyle } from '@/lib/hooks';
import { safeErrorMessage } from '@/lib/safe-error';
import { ModalPortal } from '@/components/ModalPortal';

type Tab = 'visits' | 'slots' | 'analytics';

function Stars({ score }: { score?: number | null }) {
  if (!score) return <span className="text-[var(--silver-muted)]">—</span>;
  return (
    <span className="text-[var(--warning)]">
      {'★'.repeat(score)}<span className="text-[var(--silver-muted)]">{'★'.repeat(5 - score)}</span>
    </span>
  );
}

interface Visit {
  id: string;
  visitorName: string;
  visitorPhone: string;
  member?: { name: string };
  visitDate: string;
  status: string;
  feedbackScore?: number;
}

interface Member {
  id: string;
  name: string;
}

interface Slot {
  memberId: string;
  name: string;
  plan?: string;
  totalSlots: number;
  usedSlots: number;
  remaining: number;
}

interface Stats {
  totalVisits: number;
  converted: number;
  pendingFeedback: number;
}

export default function InvitationsPage() {
  const { t, lang } = useTranslation();
  const [tab, setTab] = useState<Tab>('visits');
  const [err, setErr] = useState('');

  // visits
  const [visits, setVisits] = useState<Visit[]>([]);
  const [statusFilter, setStatusFilter] = useState('');
  const [showRegister, setShowRegister] = useState(false);
  const [convertFor, setConvertFor] = useState<Visit | null>(null);

  // shared members
  const [members, setMembers] = useState<Member[]>([]);

  // slots
  const [slots, setSlots] = useState<Slot[]>([]);
  const [editSlot, setEditSlot] = useState<Slot | null>(null);

  // stats
  const [stats, setStats] = useState<Stats | null>(null);

  const loadVisits = useCallback(() => {
    const qs = statusFilter ? `?status=${statusFilter}&limit=100` : '?limit=100';
    api<{ data: Visit[] }>(`/invitations${qs}`).then((r) => setVisits(r.data || [])).catch((e: unknown) => setErr(safeErrorMessage(e)));
  }, [statusFilter]);

  const loadSlots = useCallback(() => {
    api<Slot[]>('/invitations/slots').then((r) => setSlots(r)).catch((e: unknown) => setErr(safeErrorMessage(e)));
  }, []);

  useEffect(() => {
    api<{ items: Member[] }>('/members?limit=100').then((r) => setMembers(r.items || [])).catch(() => {});
    api<Stats>('/invitations/stats').then((r) => setStats(r)).catch(() => {});
  }, []);
  useEffect(() => { if (tab === 'visits') loadVisits(); if (tab === 'slots') loadSlots(); }, [tab, loadVisits, loadSlots]);

  const TabBtn = ({ id, label }: { id: Tab; label: string }) => (
    <button
      onClick={() => setTab(id)}
      className={`px-4 py-2 rounded-xl text-sm font-semibold transition ${tab === id ? 'bg-[var(--cyan-glow)] text-white border border-[var(--cyan-border)]' : 'text-[var(--silver-dim)] hover:text-[var(--silver)]'}`}
    >{label}</button>
  );

  return (
    <Shell>
      <div className="flex items-center gap-2 mb-5 flex-wrap">
        <TabBtn id="visits" label={t('tab_visits')} />
        <TabBtn id="slots" label={t('tab_slots')} />
        <TabBtn id="analytics" label={t('tab_analytics')} />
        <div className="flex-1" />
        {tab === 'visits' && (
          <>
            <select className="input max-w-[180px]" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
              <option value="">{t('status')}: {t('actions')}</option>
              {['VISITED', 'CONVERTED', 'NO_SHOW', 'DECLINED'].map((s) => <option key={s} value={s}>{t('st_' + s)}</option>)}
            </select>
            <button className="btn-primary" onClick={() => setShowRegister(true)}>＋ {t('registerVisit')}</button>
          </>
        )}
      </div>
      {err && <div className="text-[var(--danger)] mb-3">{err}</div>}

      {/* TAB 1 — visits */}
      {tab === 'visits' && (
        <div className="table-wrapper reveal" style={revealStyle(0)}>
          <table>
            <thead><tr>
              <th>{t('visitor_name')}</th><th>{t('visitor_phone')}</th><th>{t('invited_by')}</th>
              <th>{t('visit_date')}</th><th>{t('status')}</th><th>{t('feedback')}</th><th>{t('actions')}</th>
            </tr></thead>
            <tbody>
              {visits.map((v) => (
                <tr key={v.id}>
                  <td className="font-semibold text-white">{v.visitorName}</td>
                  <td className="text-mono" dir="ltr">{v.visitorPhone}</td>
                  <td>{v.member?.name ?? '—'}</td>
                  <td>{formatDate(v.visitDate)}</td>
                  <td>
                    <span className={`badge ${v.status === 'CONVERTED' ? 'badge-active' : v.status === 'VISITED' ? 'badge-frozen' : 'badge-expired'}`}>{t('st_' + v.status)}</span>
                  </td>
                  <td><Stars score={v.feedbackScore} /></td>
                  <td className="whitespace-nowrap">
                    {v.status === 'VISITED' && (
                      <button className="btn-ghost btn-sm row-actions" onClick={() => setConvertFor(v)}>{t('convert')}</button>
                    )}
                  </td>
                </tr>
              ))}
              {!visits.length && <tr><td colSpan={7} className="text-center text-[var(--silver-dim)] py-8">—</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      {/* TAB 2 — slots */}
      {tab === 'slots' && (
        <div className="table-wrapper reveal" style={revealStyle(0)}>
          <table>
            <thead><tr>
              <th>{t('name')}</th><th>{t('plan')}</th><th>{t('allocated')}</th><th>{t('used')}</th><th>{t('availableSlots')}</th><th>{t('actions')}</th>
            </tr></thead>
            <tbody>
              {slots.map((s) => (
                <tr key={s.memberId}>
                  <td className="font-semibold text-white">{s.name}</td>
                  <td>{s.plan ?? '—'}</td>
                  <td>{s.totalSlots}</td>
                  <td>{s.usedSlots}</td>
                  <td><span className={`font-bold ${s.remaining > 0 ? 'text-[var(--cyan)]' : 'text-[var(--silver-muted)]'}`}>{s.remaining}</span></td>
                  <td><button className="btn-ghost btn-sm row-actions" onClick={() => setEditSlot(s)}>{t('edit')}</button></td>
                </tr>
              ))}
              {!slots.length && <tr><td colSpan={6} className="text-center text-[var(--silver-dim)] py-8">—</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      {/* TAB 3 — analytics */}
      {tab === 'analytics' && <Analytics visits={visits.length ? visits : undefined} stats={stats} />}

      {showRegister && (
        <RegisterModal
          members={members}
          onClose={() => setShowRegister(false)}
          onDone={() => { setShowRegister(false); loadVisits(); api<Stats>('/invitations/stats').then((r) => setStats(r)).catch(() => {}); }}
        />
      )}
      {convertFor && (
        <ConvertModal
          invitation={convertFor}
          members={members}
          onClose={() => setConvertFor(null)}
          onDone={() => { setConvertFor(null); loadVisits(); api<Stats>('/invitations/stats').then((r) => setStats(r)).catch(() => {}); }}
        />
      )}
      {editSlot && (
        <SlotModal slot={editSlot} onClose={() => setEditSlot(null)} onDone={() => { setEditSlot(null); loadSlots(); }} />
      )}
    </Shell>
  );
}

function RegisterModal({ members, onClose, onDone }: { members: Member[]; onClose: () => void; onDone: () => void }) {
  const { t } = useTranslation();
  const [memberId, setMemberId] = useState(members[0]?.id ?? '');
  const [slot, setSlot] = useState<{ totalSlots: number; usedSlots: number } | null>(null);
  const [form, setForm] = useState<{ visitDate: string; visitorName?: string; visitorPhone?: string }>({ visitDate: new Date().toISOString().slice(0, 10) });
  const [err, setErr] = useState('');

  useEffect(() => {
    if (!memberId) return;
    api<{ totalSlots: number; usedSlots: number }>(`/invitations/slots/${memberId}`).then(setSlot).catch(() => setSlot(null));
  }, [memberId]);

  const remaining = slot ? slot.totalSlots - slot.usedSlots : 2; // default allocation is 2
  const noSlots = slot ? remaining <= 0 : false;

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr('');
    try {
      await api('/invitations/register', { method: 'POST', body: JSON.stringify({ memberId, ...form }) });
      onDone();
    } catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }

  return (
    <Modal title={t('registerVisit')} onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <div>
          <label className="text-label text-[var(--silver-dim)]">{t('select_member')}</label>
          <select className="input mt-1" value={memberId} onChange={(e) => setMemberId(e.target.value)}>
            {members.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
          </select>
          <div className={`text-xs mt-1 ${noSlots ? 'text-[var(--danger)]' : 'text-[var(--cyan)]'}`}>
            {noSlots ? t('no_slots') : `${t('availableSlots')}: ${remaining}${slot ? ` / ${slot.totalSlots}` : ''}`}
          </div>
        </div>
        <input className="input" placeholder={t('visitor_name')} required onChange={(e) => setForm({ ...form, visitorName: e.target.value })} />
        <input className="input" placeholder="01XXXXXXXXX" dir="ltr" maxLength={11} required onChange={(e) => setForm({ ...form, visitorPhone: e.target.value })} />
        <input className="input" type="date" dir="ltr" value={form.visitDate} onChange={(e) => setForm({ ...form, visitDate: e.target.value })} />
        {err && <div className="text-[var(--danger)] text-sm">{err}</div>}
        <div className="flex gap-2 justify-end pt-2">
          <button type="button" className="btn-ghost" onClick={onClose}>{t('cancel')}</button>
          <button className="btn-primary" disabled={noSlots}>{t('registerVisit')}</button>
        </div>
      </form>
    </Modal>
  );
}

function ConvertModal({ invitation, members, onClose, onDone }: { invitation: Visit; members: Member[]; onClose: () => void; onDone: () => void }) {
  const { t } = useTranslation();
  const [newMemberId, setNewMemberId] = useState(members[0]?.id ?? '');
  const [err, setErr] = useState('');
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr('');
    try { await api(`/invitations/${invitation.id}/convert`, { method: 'POST', body: JSON.stringify({ newMemberId }) }); onDone(); }
    catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }
  return (
    <Modal title={`${t('convert')} — ${invitation.visitorName}`} onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <select className="input" value={newMemberId} onChange={(e) => setNewMemberId(e.target.value)}>
          {members.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
        </select>
        {err && <div className="text-[var(--danger)] text-sm">{err}</div>}
        <div className="flex gap-2 justify-end pt-2">
          <button type="button" className="btn-ghost" onClick={onClose}>{t('cancel')}</button>
          <button className="btn-primary">{t('convert')}</button>
        </div>
      </form>
    </Modal>
  );
}

function SlotModal({ slot, onClose, onDone }: { slot: Slot; onClose: () => void; onDone: () => void }) {
  const { t } = useTranslation();
  const [val, setVal] = useState<number>(slot.totalSlots);
  const [err, setErr] = useState('');
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr('');
    try { await api(`/invitations/slots/${slot.memberId}`, { method: 'POST', body: JSON.stringify({ totalSlots: val }) }); onDone(); }
    catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }
  return (
    <Modal title={`${t('edit')} — ${slot.name}`} onClose={onClose}>
      <form onSubmit={submit} className="space-y-3">
        <label className="text-label text-[var(--silver-dim)]">{t('invitation_slots')}</label>
        <input className="input" type="number" min={0} max={20} value={val} onChange={(e) => setVal(Number(e.target.value))} />
        {err && <div className="text-[var(--danger)] text-sm">{err}</div>}
        <div className="flex gap-2 justify-end pt-2">
          <button type="button" className="btn-ghost" onClick={onClose}>{t('cancel')}</button>
          <button className="btn-primary">{t('save')}</button>
        </div>
      </form>
    </Modal>
  );
}

function Analytics({ visits, stats }: { visits?: Visit[]; stats: Stats | null }) {
  const { t, lang } = useTranslation();
  const [all, setAll] = useState<Visit[]>(visits || []);
  useEffect(() => { if (!visits) api<{ data: Visit[] }>('/invitations?limit=100').then((r) => setAll(r.data || [])).catch(() => {}); }, [visits]);

  const byMonth = useMemo(() => {
    const map: Record<string, number> = {};
    for (const v of all) { const k = new Date(v.visitDate).toISOString().slice(0, 7); map[k] = (map[k] || 0) + 1; }
    return Object.entries(map).sort().slice(-6).map(([month, count]) => ({ month, count }));
  }, [all]);

  const dist = useMemo(() => {
    const map: Record<string, number> = {};
    for (const v of all) map[v.status] = (map[v.status] || 0) + 1;
    return Object.entries(map).map(([status, count]) => ({ status, count }));
  }, [all]);

  const maxBar = Math.max(...byMonth.map((b) => b.count), 1);
  const colors: Record<string, string> = { VISITED: 'var(--brand)', CONVERTED: '#00e5a0', NO_SHOW: '#f5a623', DECLINED: '#ff4d6a' };
  const totalDist = dist.reduce((s, d) => s + d.count, 0) || 1;

  // pie chart geometry
  let acc = 0;
  const slices = dist.map((d) => {
    const frac = d.count / totalDist;
    const start = acc * 2 * Math.PI; acc += frac; const end = acc * 2 * Math.PI;
    const large = end - start > Math.PI ? 1 : 0;
    const x1 = 60 + 50 * Math.sin(start), y1 = 60 - 50 * Math.cos(start);
    const x2 = 60 + 50 * Math.sin(end), y2 = 60 - 50 * Math.cos(end);
    return { d: `M60,60 L${x1.toFixed(1)},${y1.toFixed(1)} A50,50 0 ${large} 1 ${x2.toFixed(1)},${y2.toFixed(1)} Z`, color: colors[d.status] || '#7a95ad', status: d.status, count: d.count };
  });

  return (
    <div className="grid gap-4" style={{ gridTemplateColumns: 'repeat(auto-fit,minmax(280px,1fr))' }}>
      {/* funnel */}
      <div className="card reveal" style={revealStyle(0)}>
        <div className="text-title text-white mb-4">📊 {t('conversionRate')}</div>
        {stats && (
          <div className="space-y-3">
            {[
              { label: t('total_visits'), value: stats.totalVisits, w: 100 },
              { label: t('pending_feedback'), value: stats.totalVisits - stats.pendingFeedback, w: stats.totalVisits ? ((stats.totalVisits - stats.pendingFeedback) / stats.totalVisits) * 100 : 0 },
              { label: t('converted'), value: stats.converted, w: stats.totalVisits ? (stats.converted / stats.totalVisits) * 100 : 0 },
            ].map((row, i) => (
              <div key={i}>
                <div className="flex justify-between text-sm mb-1"><span>{row.label}</span><b>{row.value}</b></div>
                <div className="progress"><i style={{ width: `${Math.max(row.w, 4)}%` }} /></div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* bar chart */}
      <div className="card reveal" style={revealStyle(1)}>
        <div className="text-title text-white mb-4">📈 {t('visits_by_month')}</div>
        <div className="flex items-end gap-3 h-40">
          {byMonth.map((b, i) => (
            <div key={b.month} className="flex-1 flex flex-col items-center justify-end gap-2">
              <div className="w-full rounded-t-lg" style={{ height: `${(b.count / maxBar) * 100}%`, background: 'linear-gradient(180deg,var(--brand),var(--brand-dim))', boxShadow: '0 0 12px var(--cyan-glow)', animation: `reveal .6s cubic-bezier(0.34,1.56,0.64,1) ${i * 60}ms both` }} />
              <div className="text-[10px] text-[var(--silver-dim)]">{b.month.slice(5)}</div>
            </div>
          ))}
          {!byMonth.length && <div className="text-[var(--silver-dim)] text-sm">—</div>}
        </div>
      </div>

      {/* pie chart */}
      <div className="card reveal" style={revealStyle(2)}>
        <div className="text-title text-white mb-4">🥧 {t('status_distribution')}</div>
        <div className="flex items-center gap-4">
          <svg viewBox="0 0 120 120" className="w-28 h-28">
            {slices.length ? slices.map((s, i) => <path key={i} d={s.d} fill={s.color} />) : <circle cx={60} cy={60} r={50} fill="#23201e" />}
          </svg>
          <div className="space-y-1">
            {dist.map((d) => (
              <div key={d.status} className="flex items-center gap-2 text-sm">
                <span className="w-3 h-3 rounded-sm" style={{ background: colors[d.status] || '#7a95ad' }} />
                <span>{t('st_' + d.status)}</span><span className="text-[var(--silver-dim)]">({d.count})</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function Modal({ title, children, onClose }: { title: string; children: React.ReactNode; onClose: () => void }) {
  return (
    <ModalPortal>
      <div className="fixed inset-0 bg-black/70 grid place-items-center p-5 z-50" onClick={onClose}>
        <div className="card card-static glass w-full max-w-md" onClick={(e) => e.stopPropagation()} style={{ boxShadow: 'var(--shadow-modal)' }}>
          <div className="flex items-center mb-4">
            <h3 className="text-title text-white flex-1">{title}</h3>
            <button className="btn-ghost btn-sm" onClick={onClose}>✕</button>
          </div>
          {children}
        </div>
      </div>
    </ModalPortal>
  );
}
