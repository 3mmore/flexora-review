/**
 * FLEXORA Gym OS — Executive Command Center
 * Product-experience redesign: turns the dashboard from a metric grid into a
 * narrative operating room for owners, operators, and franchise leadership.
 */
'use client';
import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { useTranslation } from '@/lib/i18n';
import { Card } from '@/components/ui/Card';
import { Icon } from '@/components/brand/Icon';
import { EmptyState, Skeleton } from '@/components/ui/States';
import { useCountUp } from '@/lib/hooks';
import { fmtMoney } from '@/lib/money';
import { useBranchScope } from '@/lib/branch-scope';

type DashboardData = {
  revenueToday: number;
  revenueMonth: number;
  expensesToday: number;
  netProfit: number;
  activeMembers: number;
  expiringMembers: number;
  checkinsToday: number;
  totalMembers: number;
};

type RevenuePoint = { month: string; value: number };
type Insight = { answer?: string; confidence?: string; dataUsed?: Record<string, unknown> };
type Branch = { id: string; name: string; stats?: { members?: number; staff?: number; revenue?: number } };
type SaleRow = { id: string; invoiceNo?: string; total?: number; createdAt?: string; userName?: string };
type AttendanceRow = { id: string; at?: string; member?: { name?: string }; staffName?: string };
type StaffRow = { id: string; user?: { name?: string; role?: string }; checkInAt?: string; checkOutAt?: string };



function ExecutiveMetric({
  label,
  value,
  detail,
  icon,
  tone = 'neutral',
}: {
  label: string;
  value: number;
  detail: string;
  icon: 'coins' | 'users' | 'home' | 'chart' | 'shield';
  tone?: 'neutral' | 'good' | 'warn' | 'risk';
}) {
  const animated = useCountUp(value || 0, 750);
  const toneClass = tone === 'good' ? 'text-[var(--success)]' : tone === 'warn' ? 'text-[var(--warning)]' : tone === 'risk' ? 'text-[var(--danger)]' : 'text-[var(--cyan)]';
  return (
    <Card hoverable padding="md" className="min-h-[150px]">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-bold uppercase tracking-[0.16em] text-[var(--silver-dim)]">{label}</p>
          <div className="mt-3 text-4xl font-extrabold text-white tracking-tight">{Math.round(animated).toLocaleString()}</div>
          <p className="mt-2 text-sm text-[var(--silver-dim)]">{detail}</p>
        </div>
        <div className={`h-10 w-10 rounded-xl bg-white/5 flex items-center justify-center ${toneClass}`}>
          <Icon name={icon} size={18} />
        </div>
      </div>
    </Card>
  );
}

function Sparkline({ data }: { data: RevenuePoint[] }) {
  const { t } = useTranslation();
  if (!data.length) return <EmptyState icon="chart" title={t('revenue_story_starts')} description={t('record_sales_growth')} />;
  const W = 720;
  const H = 180;
  const values = data.map((d) => d.value);
  const max = Math.max(...values, 1);
  const min = Math.min(...values, 0);
  const x = (i: number) => (i / Math.max(values.length - 1, 1)) * W;
  const y = (v: number) => H - ((v - min) / Math.max(max - min, 1)) * (H - 20) - 10;
  const path = values.map((v, i) => `${i === 0 ? 'M' : 'L'}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(' ');
  const area = `${path} L${W},${H} L0,${H} Z`;
  return (
    <div>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-56" preserveAspectRatio="none" role="img" aria-label="Revenue trend">
        <defs>
          <linearGradient id="revArea" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--cyan)" stopOpacity="0.32" />
            <stop offset="100%" stopColor="var(--cyan)" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d={area} fill="url(#revArea)" />
        <path d={path} stroke="var(--cyan)" strokeWidth="3" fill="none" strokeLinecap="round" />
      </svg>
      <div className="grid grid-cols-3 gap-3 text-xs text-[var(--silver-dim)]">
        {data.slice(-3).map((p) => <div key={p.month} className="rounded-xl bg-black/20 p-3"><b className="text-white">{p.month}</b><br />{fmtMoney(p.value)}</div>)}
      </div>
    </div>
  );
}

function ActivityTimeline({ sales, attendance, staff }: { sales: SaleRow[]; attendance: AttendanceRow[]; staff: StaffRow[] }) {
  const { t } = useTranslation();
  const rows = useMemo(() => {
    const a = sales.slice(0, 4).map((s) => ({ id: `sale-${s.id}`, icon: 'coins' as const, title: `${t('invoice')} ${s.invoiceNo || s.id.slice(0, 6)}`, detail: fmtMoney(Number(s.total || 0)), at: s.createdAt }));
    const b = attendance.slice(0, 4).map((x) => ({ id: `att-${x.id}`, icon: 'home' as const, title: `${x.member?.name || t('member')} ${t('member_checked_in')}`, detail: x.staffName || t('attendance'), at: x.at }));
    const c = staff.slice(0, 4).map((x) => ({ id: `staff-${x.id}`, icon: 'users' as const, title: `${x.user?.name || t('staff')} ${t('active_ floor_now')}`, detail: x.user?.role || t('staff_execution'), at: x.checkInAt }));
    return [...a, ...b, ...c].sort((x, y) => +(new Date(y.at || 0)) - +(new Date(x.at || 0))).slice(0, 8);
  }, [sales, attendance, staff, t]);
  if (!rows.length) return <EmptyState icon="bell" title={t('no_live_activity')} description={t('activity_real_time')} />;
  return (
    <div className="space-y-3">
      {rows.map((r) => (
        <div key={r.id} className="flex items-center gap-3 rounded-xl bg-black/20 p-3">
          <div className="h-9 w-9 rounded-lg bg-[var(--cyan)]/10 text-[var(--cyan)] flex items-center justify-center"><Icon name={r.icon} size={15} /></div>
          <div className="min-w-0 flex-1">
            <div className="text-sm font-semibold text-white truncate">{r.title}</div>
            <div className="text-xs text-[var(--silver-dim)] truncate">{r.detail}</div>
          </div>
          <div className="text-[10px] text-[var(--silver-muted)]">{r.at ? new Date(r.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'now'}</div>
        </div>
      ))}
    </div>
  );
}

function BranchLeaderboard({ branches }: { branches: Branch[] }) {
  const { t } = useTranslation();
  if (!branches.length) return <EmptyState icon="home" title={t('no_branches_configured')} description={t('add_branches_compare')} />;
  const max = Math.max(...branches.map((b) => b.stats?.revenue || 0), 1);
  return (
    <div className="space-y-4">
      {branches.slice(0, 5).map((b, index) => (
        <div key={b.id}>
          <div className="flex items-center justify-between text-sm">
            <span className="font-semibold text-white">#{index + 1} {b.name}</span>
            <span className="text-[var(--silver-dim)]">{fmtMoney(b.stats?.revenue)}</span>
          </div>
          <div className="progress mt-2"><i style={{ width: `${Math.max(8, ((b.stats?.revenue || 0) / max) * 100)}%` }} /></div>
          <div className="mt-1 text-xs text-[var(--silver-dim)]">{b.stats?.members || 0} {t('members')} · {b.stats?.staff || 0} {t('staff')}</div>
        </div>
      ))}
    </div>
  );
}

interface AiInsight {
  id: string;
  kind: string;
  payload: { content: string; weekOf: string };
}

export default function DashboardPage() {
  const { t, lang } = useTranslation();
  const [data, setData] = useState<DashboardData | null>(null);
  const [chart, setChart] = useState<RevenuePoint[]>([]);
  const [insights, setInsights] = useState<Insight | null>(null);
  const [aiInsights, setAiInsights] = useState<AiInsight[]>([]);
  const [generatingInsight, setGeneratingInsight] = useState(false);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [sales, setSales] = useState<SaleRow[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRow[]>([]);
  const [staff, setStaff] = useState<StaffRow[]>([]);
  const [gym, setGym] = useState<any>(null);
  const [billingSub, setBillingSub] = useState<any>(null);
  const [busy, setBusy] = useState(true);

  /** PHASE 4: restricted roles only ever see their own branch here. */
  const scope = useBranchScope();
  
  const [showSalesCoach, setShowSalesCoach] = useState(false);
  const [salesCoachInput, setSalesCoachInput] = useState('');
  const [salesCoachHistory, setSalesCoachHistory] = useState<{ role: string; content: string }[]>([]);
  const [salesCoachBusy, setSalesCoachBusy] = useState(false);

  async function load() {
    setBusy(true);
    try {
      const [d, c, i, g, b, s, a, st, bill, aiI] = await Promise.all([
        api<DashboardData>('/reports/dashboard').catch(() => null),
        api<RevenuePoint[]>('/reports/revenue-by-month').catch(() => []),
        api<Insight>('/ai-advanced/operational-insights').catch(() => null),
        api<any>('/gyms/me').catch(() => null),
        api<Branch[]>('/branches').catch(() => []),
        api<{ items: SaleRow[] }>('/sales?limit=8').then((r) => r.items || []).catch(() => []),
        api<{ items: AttendanceRow[] }>('/attendance?limit=8').then((r) => r.items || []).catch(() => []),
        api<StaffRow[]>('/staff-attendance/today').catch(() => []),
        api<any>('/billing/subscription').catch(() => null),
        api<AiInsight[]>('/ai/insights').catch(() => []),
      ]);
      setData(d); setChart(c); setInsights(i); setGym(g); setBranches(b); setSales(s); setAttendance(a); setStaff(st); setBillingSub(bill); setAiInsights(aiI);
      // STEP 2.3 — hand the four Home numbers to the offline banner, which keeps
      // them per account in sessionStorage (no names, no ids — see
      // lib/offline-snapshot.ts) so the owner is not staring at a blank screen
      // when the signal drops in the basement.
      if (d) {
        window.dispatchEvent(new CustomEvent('flexora:home-summary', { detail: d }));
      }
    } finally {
      setBusy(false);
    }
  }

  async function generateInsightNow() {
    setGeneratingInsight(true);
    try {
      await api('/ai/insights/generate', { method: 'POST' });
      await load();
    } finally {
      setGeneratingInsight(false);
    }
  }

  async function askSalesCoach() {
    if (!salesCoachInput.trim()) return;
    const msg = { role: 'user', content: salesCoachInput };
    setSalesCoachHistory([...salesCoachHistory, msg]);
    setSalesCoachInput('');
    setSalesCoachBusy(true);
    try {
      const res = await api<string>('/ai/sales-coach', { method: 'POST', body: JSON.stringify({ question: msg.content }) });
      setSalesCoachHistory(prev => [...prev, { role: 'assistant', content: res }]);
    } catch (e) {
      setSalesCoachHistory(prev => [...prev, { role: 'assistant', content: lang === 'ar' ? 'عذراً، حدث خطأ في التواصل مع مدرب المبيعات.' : 'Sorry, an error occurred communicating with the Sales Coach.' }]);
    } finally {
      setSalesCoachBusy(false);
    }
  }

  useEffect(() => { load(); }, []);

  const retention = data ? Math.max(0, Math.min(100, Math.round((data.activeMembers / Math.max(data.totalMembers, 1)) * 100))) : 0;
  const riskCount = (data?.expiringMembers || 0) + (insights?.answer?.includes('🔴') ? 1 : 0);

  return (
    <Shell>
      {/* Pack 2, item 2 — the phone's whole home screen. Four numbers an owner
          uses at the door, and the four actions that follow from them. Hidden
          above 760px, where the full executive surface below does the job. */}
      <div className="mobile-essentials" aria-label={t('todays_essentials')}>
        <div className="mobile-page-title">
          <h1>{t('todays_essentials')}</h1>
        </div>
        <div className="essentials-grid">
          <div className="essentials-card">
            <span>{t('checkins_today')}</span>
            <strong>{data ? data.checkinsToday : '—'}</strong>
          </div>
          <div className="essentials-card" data-tone={(data?.expiringMembers || 0) > 0 ? 'warning' : undefined}>
            <span>{t('expiring_soon')}</span>
            <strong>{data ? data.expiringMembers : '—'}</strong>
          </div>
          <div className="essentials-card">
            <span>{t('revenue_today')}</span>
            <strong>{data ? fmtMoney(data.revenueToday) : '—'}</strong>
          </div>
          <div className="essentials-card">
            <span>{t('active_members')}</span>
            <strong>{data ? data.activeMembers : '—'}</strong>
          </div>
        </div>
        <div className="quick-actions">
          <Link href="/members?action=new" className="quick-action primary">
            <Icon name="users" size={18} />
            <span>{t('add_member')}</span>
          </Link>
          <Link href="/checkin" className="quick-action">
            <Icon name="qr-scan" size={18} />
            <span>{t('checkin')}</span>
          </Link>
          <Link href="/pos" className="quick-action">
            <Icon name="coins" size={18} />
            <span>{t('collect_payment')}</span>
          </Link>
        </div>

        {/* Two more numbers, under the actions, filling what would otherwise be
            an empty screen: today's net and the roster size. */}
        <div className="essentials-grid" style={{ marginTop: 14 }}>
          <div className="essentials-card">
            <span>{t('net_profit')}</span>
            <strong>{data ? fmtMoney(data.netProfit) : '—'}</strong>
          </div>
          <div className="essentials-card">
            <span>{t('total_members')}</span>
            <strong>{data ? data.totalMembers : '—'}</strong>
          </div>
        </div>
      </div>

      <div className="px-8 py-8 space-y-6 desktop-only">
        {aiInsights.length > 0 && (
          <Card padding="lg" className="bg-[var(--primary)]/5 border-[var(--primary)]/20">
            <div className="flex justify-between items-start">
              <div className="flex gap-3">
                <Icon name="sparkle" className="text-[var(--primary)] mt-1" size={20} />
                <div>
                  <h3 className="font-bold text-lg">{t('ai_weekly_insight')}</h3>
                  <p className="text-sm text-[var(--silver)] leading-relaxed mt-2 whitespace-pre-line">
                    {generatingInsight ? t('analyzing_gym_data') : aiInsights[0].payload.content}
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <button className="btn-ghost btn-sm" onClick={load} title={t('refresh')}><Icon name="lightning" size={14} /></button>
                <button className="btn-primary btn-sm" onClick={generateInsightNow} disabled={generatingInsight}>
                  {generatingInsight ? '...' : t('generate_now')}
                </button>
              </div>
            </div>
          </Card>
        )}

        {billingSub?.status === 'TRIALING' && billingSub?.trialEndDate && Math.ceil((new Date(billingSub.trialEndDate).getTime() - Date.now()) / 86400000) <= 3 && (
          <div className="rounded-2xl border border-[rgba(var(--brand-rgb),0.40)] bg-[rgba(var(--brand-rgb),0.10)] p-4 text-sm text-white">{t('trial_ending_soon')} — <Link href="/billing" className="font-bold text-[var(--brand)]">{t('upgrade_now')}</Link> {t('keep_features_running') || 'to keep features running'}.</div>
        )}
        {billingSub?.plan === 'BASIC' && (data?.totalMembers || 0) >= 45 && (
          <div className="rounded-2xl border border-[var(--warning)]/40 bg-[var(--warning)]/10 p-4 text-sm text-white">{t('basic_limit_near')} ({data?.totalMembers}/50). <Link href="/billing" className="font-bold text-[var(--brand)]">{t('upgrade_to_pro')}</Link>.</div>
        )}

        <section className="grid grid-cols-1 xl:grid-cols-[1.35fr_0.65fr] gap-5">
          <Card variant="glow" padding="lg" className="grid-bg min-h-[260px]">
            <div className="relative z-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div>
                <p className="text-xs uppercase tracking-[0.22em] font-bold text-[var(--cyan)]">{t('dashboard')}</p>
                <h1 className="mt-3 text-4xl md:text-5xl font-extrabold text-white tracking-tight">{gym?.name || t('your_gym') || 'Your Gym'}</h1>
                <p className="mt-3 max-w-2xl text-[var(--silver-dim)] leading-7">{t('dashboard_description')}</p>
              </div>
              <div className="flex gap-2">
                <Link href="/members?action=new" className="btn btn-primary px-4 py-2 text-sm"><Icon name="plus" size={14} /> {t('add_member')}</Link>
                <Link href="/pos" className="btn btn-secondary px-4 py-2 text-sm"><Icon name="coins" size={14} /> {t('pos')}</Link>
              </div>
            </div>
            <div className="relative z-10 mt-8 grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="rounded-2xl bg-black/25 p-4"><div className="text-xs text-[var(--silver-dim)]">{t('revenue')}</div><div className="text-xl font-bold text-white">{fmtMoney(data?.revenueMonth)}</div></div>
              <div className="rounded-2xl bg-black/25 p-4"><div className="text-xs text-[var(--silver-dim)]">{t('retention')}</div><div className="text-xl font-bold text-white">{retention}/100</div></div>
              <div className="rounded-2xl bg-black/25 p-4"><div className="text-xs text-[var(--silver-dim)]">{t('risk')}</div><div className="text-xl font-bold text-[var(--warning)]">{riskCount}</div></div>
              <div className="rounded-2xl bg-black/25 p-4"><div className="text-xs text-[var(--silver-dim)]">{t('checkins_today')}</div><div className="text-xl font-bold text-white">{data?.checkinsToday || 0}</div></div>
            </div>
          </Card>

          <Card padding="lg">
            <div className="flex items-center gap-2 mb-4 text-[var(--cyan)]"><Icon name="sparkle" size={17} /><span className="text-xs font-bold uppercase tracking-[0.16em]">{t('ai_briefing')}</span></div>
            {busy ? <Skeleton lines={6} /> : insights?.answer ? (
              <div className="space-y-3 text-sm leading-7 text-[var(--silver)] whitespace-pre-line">{insights.answer}</div>
            ) : (
              <EmptyState icon="sparkle" title={t('ai_brief_here')} description={t('once_activity_grows')} />
            )}
            <Link href="/ai" className="btn btn-ghost mt-5 w-full justify-center px-4 py-2 text-sm">{t('open_ai_workspace')} <Icon name="arrow-right" size={13} /></Link>
          </Card>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
          {busy || !data ? <><Skeleton /><Skeleton /><Skeleton /><Skeleton /></> : (
            <>
              <ExecutiveMetric label={t('revenue_today')} value={data.revenueToday} detail={`${fmtMoney(data.revenueMonth)} ${t('this_month')}`} icon="coins" tone="good" />
              <ExecutiveMetric label={t('active_members')} value={data.activeMembers} detail={`${data.totalMembers} ${t('total_members')}`} icon="users" />
              <ExecutiveMetric label={t('attendance')} value={data.checkinsToday} detail={t('live_traffic_today')} icon="home" />
              <ExecutiveMetric label={t('retention')} value={retention} detail={`${data.expiringMembers} ${t('expiring_soon')}`} icon="shield" tone={data.expiringMembers > 0 ? 'warn' : 'good'} />
            </>
          )}
        </section>

        <section className="grid grid-cols-1 xl:grid-cols-[1.2fr_0.8fr] gap-5">
          <Card padding="lg" variant="elevated">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h2 className="text-xl font-bold text-white">{t('revenue_trajectory')}</h2>
                <p className="text-sm text-[var(--silver-dim)]">{t('revenue_trend_momentum')}</p>
              </div>
              <Link href="/reports" className="btn btn-ghost px-3 py-2 text-xs">{t('view_reports')}</Link>
            </div>
            {busy ? <Skeleton lines={8} /> : <Sparkline data={chart} />}
          </Card>

          <Card padding="lg">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h2 className="text-xl font-bold text-white">{t('next_best_actions')}</h2>
                <p className="text-sm text-[var(--silver-dim)]">{t('actions_column')}</p>
              </div>
              <Icon name="lightning" className="text-[var(--cyan)]" size={18} />
            </div>
            <div className="space-y-3">
              <Link href="/members?status=expired" className="flex items-center gap-3 rounded-xl bg-black/20 p-3 hover:bg-white/5 transition-colors"><Icon name="bell" className="text-[var(--warning)]" size={16} /><span className="flex-1 text-sm">{t('recover')} {data?.expiringMembers || 0} {t('expiring_soon')}</span><Icon name="arrow-right" size={12} /></Link>
              <Link href="/leads" className="flex items-center gap-3 rounded-xl bg-black/20 p-3 hover:bg-white/5 transition-colors"><Icon name="lightning" className="text-[var(--cyan)]" size={16} /><span className="flex-1 text-sm">{t('hot_leads_followups')}</span><Icon name="arrow-right" size={12} /></Link>
              <Link href="/inventory" className="flex items-center gap-3 rounded-xl bg-black/20 p-3 hover:bg-white/5 transition-colors"><Icon name="menu-grid" className="text-[var(--success)]" size={16} /><span className="flex-1 text-sm">{t('low_stock_peak')}</span><Icon name="arrow-right" size={12} /></Link>
              <Link href="/campaigns" className="flex items-center gap-3 rounded-xl bg-black/20 p-3 hover:bg-white/5 transition-colors"><Icon name="send" className="text-[var(--cyan)]" size={16} /><span className="flex-1 text-sm">{t('launch_campaign')}</span><Icon name="arrow-right" size={12} /></Link>
            </div>
          </Card>
        </section>

        <section className="grid grid-cols-1 xl:grid-cols-3 gap-5">
          <Card padding="lg">
            <h2 className="text-xl font-bold text-white mb-1">{t('branch_performance')}</h2>
            <p className="text-sm text-[var(--silver-dim)] mb-5">{t('compare_locations')}</p>
            {/* PHASE 4: restricted staff only ever receive their own branch from
                /branches, so this is a statement of fact, not a filter. */}
            {!scope.unrestricted && !scope.loading && (
              <div className="badge badge-active mb-4" data-testid="dashboard-branch-locked">
                {t('branch') || 'Branch'}: {scope.branchName || branches[0]?.name || '—'}
              </div>
            )}
            {busy ? <Skeleton lines={6} /> : <BranchLeaderboard branches={branches} />}
          </Card>
          <Card padding="lg">
            <h2 className="text-xl font-bold text-white mb-1">{t('staff_execution')}</h2>
            <p className="text-sm text-[var(--silver-dim)] mb-5">{t('active_floor_now')}</p>
            {busy ? <Skeleton lines={6} /> : staff.length ? staff.slice(0, 6).map((s) => <div key={s.id} className="mb-3 rounded-xl bg-black/20 p-3"><b className="text-white">{s.user?.name || t('staff')}</b><div className="text-xs text-[var(--silver-dim)]">{s.user?.role || t('staff')} · {s.checkOutAt ? t('checked_out') : t('on_shift')}</div></div>) : <EmptyState icon="users" title={t('no_staff_activity')} description={t('clock_ins_appear')} />}
          </Card>
          <Card padding="lg">
            <h2 className="text-xl font-bold text-white mb-1">{t('recent_activity')}</h2>
            <p className="text-sm text-[var(--silver-dim)] mb-5">{t('live_timeline_ops')}</p>
            {busy ? <Skeleton lines={8} /> : <ActivityTimeline sales={sales} attendance={attendance} staff={staff} />}
          </Card>
        </section>
      </div>

      {/* Sales Coach Widget */}
      <div className="fixed bottom-6 right-8 z-40">
        <button 
          className="h-14 w-14 rounded-full bg-[var(--primary)] text-black shadow-lg flex items-center justify-center hover:scale-105 transition-transform"
          onClick={() => setShowSalesCoach(!showSalesCoach)}
        >
          <Icon name="sparkle" size={24} />
        </button>

        {showSalesCoach && (
          <div className="absolute bottom-16 right-0 w-80 md:w-96 h-[500px] bg-[var(--bg-card)] border border-[var(--border)] rounded-2xl shadow-2xl flex flex-col overflow-hidden">
            <div className="bg-[var(--primary)] p-4 text-black flex justify-between items-center">
              <span className="font-bold">Sales Coach AI</span>
              <button onClick={() => setShowSalesCoach(false)}><Icon name="x" size={18} /></button>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {salesCoachHistory.length === 0 && (
                <div className="text-center text-[var(--silver-dim)] mt-10">
                  <Icon name="sparkle" size={40} className="mx-auto mb-3 opacity-20" />
                  <p>{lang === 'ar' ? 'أسألني عن أي عميل أو استفسار مبيعات وسأقوم بمساعدتك فوراً.' : 'Ask me about any customer or sales inquiry and I will help you immediately.'}</p>
                </div>
              )}
              {salesCoachHistory.map((m, i) => (
                <div key={i} className={`p-3 rounded-xl text-sm ${m.role === 'user' ? 'bg-[var(--border)] ml-8' : 'bg-[var(--primary)]/10 mr-8 text-white'}`}>
                  {m.content}
                </div>
              ))}
              {salesCoachBusy && <div className="text-[var(--muted)] text-xs animate-pulse">{t('thinking')}</div>}
            </div>
            <div className="p-4 border-t border-[var(--border)] flex gap-2">
              <input 
                className="input flex-1 text-sm" 
                placeholder={lang === 'ar' ? 'صف العميل أو اسأل سؤالاً...' : 'Describe the customer or ask a question...'} 
                value={salesCoachInput}
                onChange={(e) => setSalesCoachInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && askSalesCoach()}
              />
              <button className="btn-primary p-2" onClick={askSalesCoach}><Icon name="send" /></button>
            </div>
          </div>
        )}
      </div>
    </Shell>
  );
}
