/**
 * FLEXORA Inventory Intelligence Center
 * Reframes stock management as operational intelligence: risk, velocity,
 * reorder priorities, trapped value, and branch supply decisions.
 */
'use client';
import { useEffect, useMemo, useState } from 'react';
import { formatDate } from '@/lib/dates';
import Link from 'next/link';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { ActionCenter, FeedbackLayer, InsightCard, InsightLayer, ProductPage, SmartAction, SmartTable } from '@/components/ProductOS';
import { Card } from '@/components/ui/Card';
import { EmptyState, Skeleton } from '@/components/ui/States';
import { Icon } from '@/components/brand/Icon';
import { safeErrorMessage } from '@/lib/safe-error';
import { useTranslation } from '@/lib/i18n';
import { fmtMoney } from '@/lib/money';
import { ModalPortal } from '@/components/ModalPortal';
import { useBranchScope } from '@/lib/branch-scope';

type Supplier = { id: string; name: string; phone?: string; email?: string; contactName?: string };
type Product = { id: string; name: string; category?: string; price: number | string; cost?: number | string; qty: number; lowAlert: number; barcode?: string; active?: boolean; branchId?: string | null; branch?: { id: string; name: string } | null };
type PO = { id: string; poNo: string; status: string; total: number | string; notes?: string; supplier?: { id: string; name: string }; branch?: { id: string; name: string } | null; expectedAt?: string; receivedAt?: string; createdAt: string };
type Movement = { id: string; type: string; qty: number; unitCost?: number | string; product?: { name: string }; occurredAt: string; branchId?: string };
type Branch = { id: string; name: string; stats?: { members?: number; staff?: number; revenue?: number } };
type IncomingRow = { poId: string; poNo: string; status: string; expectedAt?: string; supplier?: { name: string }; branch?: { name: string } | null; product?: { name: string } | null; remaining: number; unitCost?: number | string };
type ProductStats = { inventoryValue?: number; lowStock?: Product[]; bestSellers?: Array<{ productId?: string; name: string; _sum?: { qty?: number } }> };

type Tab = 'orders' | 'suppliers' | 'risks' | 'movements';

const money = (value?: number | string) => fmtMoney(value);
const statusClass = (status: string) => ({
  DRAFT: 'badge badge-frozen',
  SENT: 'badge badge-soon',
  PARTIAL: 'badge badge-soon',
  RECEIVED: 'badge badge-active',
  CANCELLED: 'badge badge-expired',
} as Record<string, string>)[status] || 'badge';

export default function InventoryIntelligenceCenter() {
  const { t } = useTranslation();
  // PHASE 4: OWNER/MANAGER choose freely between branches; every other role is
  // pinned to their own branch and sees no branch control at all.
  const scope = useBranchScope();
  const [tab, setTab] = useState<Tab>('orders');
  const [orders, setOrders] = useState<PO[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [lowStock, setLowStock] = useState<Product[]>([]);
  const [movements, setMovements] = useState<Movement[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [stats, setStats] = useState<ProductStats | null>(null);
  const [incoming, setIncoming] = useState<IncomingRow[]>([]);
  const [showPO, setShowPO] = useState(false);
  const [showSupplier, setShowSupplier] = useState(false);
  const [poForm, setPoForm] = useState({ supplierId: '', notes: '', branchId: '', items: [{ productId: '', qty: 1 }] });
  const [supForm, setSupForm] = useState({ name: '', phone: '', email: '', contactName: '' });
  const [busy, setBusy] = useState(true);
  const [err, setErr] = useState('');
  // FIX (round 8): inventory page must require explicit branch selection before
  // showing any data. No stock levels, POs, movements, or risks are loaded
  // until the owner chooses a branch.
  const [selectedBranchId, setSelectedBranchId] = useState('');
  const [branchChosen, setBranchChosen] = useState(false);
  const [branchesLoaded, setBranchesLoaded] = useState(false);

  async function load() {
    if (!branchChosen || !selectedBranchId) return;
    setBusy(true);
    setErr('');
    const bp = `branchId=${encodeURIComponent(selectedBranchId)}`;
    try {
      const [poRows, supplierRows, lowRows, movementRows, productRows, branchRows, productStats, incomingRows] = await Promise.all([
        api<PO[]>(`/inventory/purchase-orders?${bp}`),
        api<Supplier[]>('/inventory/suppliers'),
        api<Product[]>(`/inventory/low-stock?${bp}`),
        api<Movement[]>(`/inventory/movements?${bp}`),
        api<Product[]>('/products').catch(() => []),
        api<Branch[]>('/branches').catch(() => []),
        api<ProductStats>(`/products/stats?${bp}`).catch(() => null),
        api<IncomingRow[]>(`/inventory/incoming?${bp}`).catch(() => []),
      ]);
      setOrders(poRows);
      setSuppliers(supplierRows);
      setLowStock(lowRows);
      setMovements(movementRows);
      setProducts(productRows);
      setBranches(branchRows);
      setStats(productStats);
      setIncoming(incomingRows);
    } catch (e: unknown) {
      setErr((e as Error).message || t('inventory_intelligence_unavailable'));
    } finally {
      setBusy(false);
    }
  }
  useEffect(() => {
    // Load branches on mount; data loading happens only after branch selection.
    api<Branch[]>('/branches').catch(() => []).then((list) => {
      setBranches(list);
      setBranchesLoaded(true);
      // Auto-select if exactly one branch exists.
      if (list.length === 1) {
        setSelectedBranchId(list[0].id);
        setBranchChosen(true);
      }
    });
    // Suppliers are branch-independent, load them immediately.
    api<Supplier[]>('/inventory/suppliers').then(setSuppliers).catch(() => {});
  }, []);
  useEffect(() => {
    if (branchChosen && selectedBranchId) load();
  }, [branchChosen, selectedBranchId]);
  // PHASE 4: restricted staff are pinned — no picker, no "choose a branch"
  // interstitial, the pinned branch is used straight away.
  useEffect(() => {
    if (scope.loading || scope.unrestricted) return;
    setSelectedBranchId(scope.branchId || '');
    setBranchChosen(true);
    setBranchesLoaded(true);
  }, [scope.loading, scope.unrestricted, scope.branchId]);

  const activeProducts = products.filter((p) => p.active !== false);
  const totalStockValue = activeProducts.reduce((sum, p) => sum + Number(p.cost || p.price || 0) * Number(p.qty || 0), 0) || Number(stats?.inventoryValue || 0);
  const outOfStock = activeProducts.filter((p) => p.qty <= 0);
  const criticalStock = activeProducts.filter((p) => p.qty > 0 && p.qty <= Math.max(1, Math.ceil((p.lowAlert || 1) / 2)));
  const healthyInventory = activeProducts.filter((p) => p.qty > p.lowAlert);
  const overstock = activeProducts.filter((p) => p.qty > Math.max(20, (p.lowAlert || 1) * 8));
  const bestSellerNames = new Set((stats?.bestSellers || []).map((p) => p.name));
  const fastMovers = activeProducts.filter((p) => bestSellerNames.has(p.name)).slice(0, 8);
  const deadStockItems = activeProducts.filter((p) => p.qty > Math.max(5, p.lowAlert * 2) && !bestSellerNames.has(p.name)).slice(0, 10);
  const inventoryHealth = activeProducts.length ? Math.max(0, Math.round(((healthyInventory.length - lowStock.length - outOfStock.length) / activeProducts.length) * 100)) : 0;
  const reorderUrgency = outOfStock.length > 0 ? 'Critical' : lowStock.length > 0 ? 'High' : criticalStock.length > 0 ? 'Watch' : 'Stable';
  const reorderPriority = [...outOfStock, ...criticalStock, ...lowStock].filter((p, i, arr) => arr.findIndex((x) => x.id === p.id) === i).slice(0, 12);
  const branchByRevenue = [...branches].sort((a, b) => Number(b.stats?.revenue || 0) - Number(a.stats?.revenue || 0));
  const bestBranch = branchByRevenue[0];
  const attentionBranch = branchByRevenue.at(-1);
  const recentTimeline = useMemo(() => [
    ...movements.slice(0, 20).map((m) => ({ id: `move-${m.id}`, type: t('mv_' + (m.type || '').toLowerCase()) || m.type, title: m.product?.name || t('stock'), detail: `${m.qty > 0 ? '+' : ''}${m.qty} ${t('units')}`, at: m.occurredAt })),
    ...lowStock.slice(0, 8).map((p) => ({ id: `low-${p.id}`, type: t('low_stock'), title: p.name, detail: `${p.qty} ${t('remaining')} · ${t('reorder')} ${p.lowAlert}`, at: new Date().toISOString() })),
    ...orders.slice(0, 8).map((p) => ({ id: `po-${p.id}`, type: t('journal_entry'), title: p.poNo, detail: `${p.status} · ${p.supplier?.name || t('suppliers')}`, at: p.createdAt })),
  ].sort((a, b) => +new Date(b.at) - +new Date(a.at)), [movements, lowStock, orders, t]);

  async function createPO() {
    // FIX (reorder failed with "Invalid supplier"): the modal used to default
    // to an empty supplier and only errored server-side with no guidance.
    // Validate here with a clear message, and require at least one item.
    if (!poForm.supplierId) { setErr(t('supplier_required') || 'Please select a supplier for this order'); return; }
    const items = poForm.items.filter(i => i.productId && i.qty > 0);
    if (!items.length) { setErr(t('po_items_required') || 'Add at least one product with quantity'); return; }
    try {
      await api('/inventory/purchase-orders', { 
        method: 'POST', 
        body: JSON.stringify({ supplierId: poForm.supplierId, notes: poForm.notes, branchId: poForm.branchId || undefined, items }) 
      });
      setShowPO(false); setPoForm({ supplierId: suppliers[0]?.id || '', notes: '', branchId: '', items: [{ productId: '', qty: 1 }] });
      await load();
    } catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }
  async function createSupplier() {
    try {
      await api('/inventory/suppliers', { method: 'POST', body: JSON.stringify(supForm) });
      setShowSupplier(false); setSupForm({ name: '', phone: '', email: '', contactName: '' });
      await load();
    } catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }
  async function sendPO(id: string) {
    try { await api(`/inventory/purchase-orders/${id}/send`, { method: 'POST' }); await load(); }
    catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }

  return (
    <Shell>
      <ProductPage
        eyebrow={t('inventory_timeline_label')}
        title={t('stock_decisions_revenue')}
        narrative={branchChosen && selectedBranchId ? `${t('inventory_health')} ${inventoryHealth}%. ${reorderUrgency === 'Stable' ? t('attendance_stable') : t('need_attention')}.` : (t('select_branch_for_inventory') || 'Select a branch to view inventory data.')}
        primaryAction={branchChosen ? { label: t('reorder_stock'), icon: 'plus', onClick: () => { setPoForm((f) => ({ ...f, supplierId: f.supplierId || suppliers[0]?.id || '', branchId: selectedBranchId })); setShowPO(true); } } : undefined}
        secondaryAction={{ label: t('pos'), href: '/pos', icon: 'coins' }}
      >
        {err && <FeedbackLayer type="danger" title={t('inventory_intelligence_unavailable')} detail={err} action={<button className="btn btn-ghost px-3 py-1.5 text-xs" onClick={load}>{t('retry')}</button>} />}

        {/* FIX (round 8): require explicit branch selection before showing any
            inventory data. No stock levels, POs, or movements are visible
            until the owner picks a branch. */}
        {!branchChosen && branchesLoaded && scope.unrestricted && (
          <div className="card card-static glass w-full max-w-xl mx-auto mt-8 p-8 text-center" style={{ boxShadow: 'var(--shadow-modal)' }}>
            <div className="text-5xl mb-4">📦</div>
            <h2 className="text-xl font-bold text-white mb-2">{t('select_branch_for_inventory') || 'Select a branch to view inventory'}</h2>
            <p className="text-sm text-[var(--silver-dim)] mb-6">{t('branch_inventory_help') || 'Inventory, stock levels, and purchase orders are scoped to a specific branch. Choose which branch to manage.'}</p>
            {branches.length === 0 ? (
              <div className="space-y-4">
                <p className="text-sm text-[var(--warning)]">{t('no_branches_yet') || 'No branches have been created yet.'}</p>
                <a href="/branches" className="btn btn-primary inline-block">{t('create_first_branch') || 'Create your first branch'}</a>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {branches.map((b) => (
                    <button
                      key={b.id}
                      className="card p-4 text-start hover:border-[var(--cyan)] hover:bg-[var(--primary-soft)] transition-all cursor-pointer border border-[var(--border)]"
                      onClick={() => { setSelectedBranchId(b.id); setBranchChosen(true); }}
                    >
                      <div className="font-bold text-white">{b.name}</div>
                      <div className="text-xs text-[var(--silver-dim)] mt-1">{t('view_inventory') || 'View inventory'}</div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {branchChosen && selectedBranchId && (
          <>
            <div className="flex items-center gap-3 mb-4">
              {scope.unrestricted ? (
                <select className="input max-w-[240px]" value={selectedBranchId} onChange={(e) => { setSelectedBranchId(e.target.value); setBranchChosen(!!e.target.value); }} aria-label={t('select_branch') || 'Select branch'}>
                  {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
                </select>
              ) : null}
              <span className="text-xs text-[var(--silver-dim)]" data-testid="inventory-branch-label">
                {t('viewing_branch') || 'Viewing'}: {scope.branchName || branches.find(b => b.id === selectedBranchId)?.name}
              </span>
            </div>

        <InsightLayer>
          {busy ? <><Skeleton /><Skeleton /><Skeleton /><Skeleton /></> : <>
            <InsightCard label={t('inventory_health_center')} value={`${inventoryHealth}%`} detail={t('healthy_inventory_label')} icon="shield" tone={inventoryHealth > 70 ? 'good' : 'warning'} />
            <InsightCard label={t('inventory_value_label')} value={money(totalStockValue)} detail={t('inventory_value_desc')} icon="coins" />
            <InsightCard label={t('low_stock')} value={lowStock.length} detail={`${outOfStock.length} ${t('out_of_stock')} · ${criticalStock.length} ${t('risk')}`} icon="bell" tone={lowStock.length ? 'warning' : 'good'} />
            <InsightCard label={t('dead_stock')} value={deadStockItems.length} detail={t('weak_movement_signal')} icon="menu-grid" tone={deadStockItems.length ? 'warning' : 'neutral'} />
          </>}
        </InsightLayer>

        <ActionCenter title={t('inventory_decision_center')}>
          <SmartAction title={t('reorder_stock')} detail={`${reorderPriority.length} ${t('review_reorder_desc')}`} icon="plus" onClick={() => setShowPO(true)} tone={reorderPriority.length ? 'warning' : 'good'} />
          <SmartAction title={t('products')} detail={t('products_description')} icon="menu-grid" href="/products" />
          <SmartAction title={t('pos')} detail={t('move_fast_stock')} icon="coins" href="/pos" />
          <SmartAction title={t('review_fast_movers')} detail={`${fastMovers.length} ${t('driving_demand_desc')}`} icon="chart" onClick={() => setTab('risks')} />
          <SmartAction title={t('review_dead_stock')} detail={t('bundle_discount_promote')} icon="menu-grid" onClick={() => setTab('risks')} tone={deadStockItems.length ? 'warning' : 'neutral'} />
          <SmartAction title={t('transfer_inventory')} detail={t('use_branch_rebalance')} icon="send" onClick={() => setTab('movements')} />
        </ActionCenter>

        <section className="inventory-intel-grid">
          <Card padding="lg">
            <div className="product-section-head"><div><h2>{t('inventory_health_center')}</h2><p>{t('inventory_business_action')}</p></div></div>
            {busy ? <Skeleton lines={7} /> : <div className="inventory-health-grid">
              <div><span>{t('healthy_inventory_label')}</span><b>{healthyInventory.length}</b><small>{t('ready_sell_no_action')}</small></div>
              <div><span>{t('low_stock')}</span><b>{lowStock.length}</b><small>{t('reorder_transfer_peaks')}</small></div>
              <div><span>{t('critical_inventory')}</span><b>{criticalStock.length + outOfStock.length}</b><small>{t('revenue_at_risk_demand')}</small></div>
              <div><span>{t('overstock')}</span><b>{overstock.length}</b><small>{t('review_trapped_capital')}</small></div>
            </div>}
          </Card>

          <Card padding="lg">
            <div className="product-section-head"><div><h2>{t('fast_movers_center')}</h2><p>{t('strongest_demand_signals')}</p></div></div>
            {busy ? <Skeleton lines={7} /> : fastMovers.length ? <div className="inventory-list">{fastMovers.map((p) => <div key={p.id}><div><b>{p.name}</b><span>{p.qty} {t('in_stock')} · {t('reorder')} {p.lowAlert}</span></div><strong>{money(p.price)}</strong></div>)}</div> : <EmptyState icon="chart" title={t('no_results')} description={t('get_started_desc')} />}
          </Card>

          <Card padding="lg">
            <div className="product-section-head"><div><h2>{t('dead_stock_center')}</h2><p>{t('discount_bundle_transfer')}</p></div></div>
            {busy ? <Skeleton lines={7} /> : deadStockItems.length ? <div className="inventory-list">{deadStockItems.map((p) => <div key={p.id}><div><b>{p.name}</b><span>{p.qty} {t('units')} · {t('inventory_value_label')} {money(Number(p.qty) * Number(p.cost || p.price || 0))}</span></div><div className="inventory-row-actions"><Link href="/campaigns?action=inventory-promo" className="btn btn-ghost px-2 py-1 text-xs">{t('create_promotion')}</Link><button className="btn btn-secondary px-2 py-1 text-xs">{t('bundle_discount_promote')}</button></div></div>)}</div> : <EmptyState icon="sparkle" title={t('no_dead_stock')} description={t('monitor_attendance')} />}
          </Card>

          <Card padding="lg">
            <div className="product-section-head"><div><h2>{t('reorder_intelligence')}</h2><p>{t('stockout_risk_priority')}</p></div></div>
            {busy ? <Skeleton lines={7} /> : reorderPriority.length ? <div className="inventory-list">{reorderPriority.map((p, i) => <div key={`${p.id}-${i}`}><div><b>#{i + 1} {p.name}{p.branch?.name ? ` · ${p.branch.name}` : ''}</b><span>{p.qty} {t('remaining')} · {t('suggested_actions')} {Math.max((p.lowAlert || 1) * 3 - p.qty, p.lowAlert || 1)} {t('units')}</span></div><span className="risk-indicator" data-level={p.qty <= 0 ? 'critical' : 'high'}>{p.qty <= 0 ? t('out_of_stock') : t('risk')}</span></div>)}</div> : <EmptyState icon="shield" title={t('no_reorder_pressure')} description={t('ready_sell_no_action')} />}
          </Card>

          <Card padding="lg">
            <div className="product-section-head"><div><h2>{t('inventory_opportunity_center')}</h2><p>{t('upsell_cross_sell_margin')}</p></div></div>
            {busy ? <Skeleton lines={7} /> : <div className="inventory-opportunity-grid">
              <div><span>{t('high_margin_candidates')}</span><b>{activeProducts.filter((p) => Number(p.price) > Number(p.cost || 0) * 1.5).length}</b><small>{t('promote_strong_spread')}</small></div>
              <div><span>{t('cross_sell_candidates')}</span><b>{fastMovers.length}</b><small>{t('pair_fast_slow')}</small></div>
              <div><span>{t('promotion_candidates')}</span><b>{deadStockItems.length}</b><small>{t('discount_bundle_low_velocity')}</small></div>
            </div>}
          </Card>

          <Card padding="lg">
            <div className="product-section-head"><div><h2>{t('branch_inventory_intelligence')}</h2><p>{t('branch_revenue_decide_transfers')}</p></div></div>
            {busy ? <Skeleton lines={7} /> : branches.length ? <div className="inventory-list">{branchByRevenue.slice(0, 5).map((b, i) => <div key={b.id}><div><b>{i === 0 ? t('most_popular') + ': ' : ''}{b.name}</b><span>{b.stats?.members || 0} {t('members')} · {t('revenue')} {money(b.stats?.revenue || 0)}</span></div>{attentionBranch?.id === b.id && <span className="risk-indicator" data-level="medium">{t('need_attention')}</span>}</div>)}</div> : <EmptyState icon="home" title={t('no_branches_configured')} description={t('add_branches_compare')} />}
          </Card>

          <Card padding="lg" className="inventory-timeline-card">
            <div className="product-section-head"><div><h2>{t('inventory_timeline_label')}</h2><p>{t('inventory_history_desc')}</p></div></div>
            {busy ? <Skeleton lines={9} /> : recentTimeline.length ? <div className="inventory-timeline">{recentTimeline.slice(0, 24).map((e) => <div key={e.id}><div><span>{t(e.type) || e.type}</span><b>{e.title}</b><small>{e.detail}</small></div><time>{new Date(e.at).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</time></div>)}</div> : <EmptyState icon="bell" title={t('no_inventory_timeline_yet') || 'No timeline'} description={t('build_inventory_timeline')} />}
          </Card>
        </section>

        <div className="inventory-tabs" role="tablist" aria-label="Inventory operational surfaces">
          {(['orders', 'suppliers', 'risks', 'movements'] as const).map((item) => <button key={item} className={tab === item ? 'active' : ''} onClick={() => setTab(item)}>{item === 'orders' ? t('journal_entry') : item === 'risks' ? t('stock_risks') : item === 'movements' ? t('movements') : t('suppliers')}</button>)}
        </div>

        {tab === 'orders' && (
          <div className="space-y-6">
            {/* P4-3: pending/incoming stock from OPEN purchase orders — what's
                actually on its way, per line, before anything is received. */}
            <Card padding="lg">
              <div className="product-section-head"><div><h2>{t('incoming_stock')}</h2><p>{t('incoming_desc')}</p></div></div>
              {busy ? <Skeleton lines={4} /> : incoming.length ? (
                <SmartTable
                  columns={[t('products'), t('remaining_label'), t('po'), t('suppliers'), t('branch'), t('expected_label')]}
                  rows={incoming}
                  emptyTitle={t('no_incoming')}
                  emptyDescription={t('no_incoming_desc')}
                  renderRow={(r: IncomingRow, i = 0) => (
                    <tr key={`${r.poId}-${r.poNo}-${i}`}>
                      <td className="font-bold">{r.product?.name || '—'}</td>
                      <td><span className="badge badge-soon">{r.remaining} {t('units')}</span></td>
                      <td>{r.poNo}</td>
                      <td>{r.supplier?.name || '—'}</td>
                      <td>{r.branch?.name || t('all_branches')}</td>
                      <td>{r.expectedAt ? formatDate(r.expectedAt) : '—'}</td>
                    </tr>
                  )}
                />
              ) : <EmptyState icon="menu-grid" title={t('no_incoming')} description={t('no_incoming_desc')} />}
            </Card>

            <SmartTable columns={[t('po'), t('suppliers'), t('branch'), t('status'), t('total'), t('actions')]} rows={orders} loading={busy} emptyTitle={t('no_data')} emptyDescription={t('get_started_desc')} renderRow={(p: PO) => <tr key={p.id}><td>{p.poNo}</td><td>{p.supplier?.name || '—'}</td><td>{p.branch?.name || t('all_branches')}</td><td><span className={statusClass(p.status)}>{t('st_' + (p.status || '').toLowerCase()) || p.status}</span></td><td>{money(p.total)}</td><td>{p.status === 'DRAFT' ? <button className="btn btn-secondary px-3 py-1.5 text-xs" onClick={() => sendPO(p.id)}>{t('send')}</button> : '—'}</td></tr>} />
          </div>
        )}
        {tab === 'suppliers' && <SmartTable columns={[t('suppliers'), t('contacted'), t('phone'), t('email'), t('actions')]} rows={suppliers} loading={busy} emptyTitle={t('no_suppliers_connected')} emptyDescription={t('add_suppliers_faster')} renderRow={(s: Supplier) => <tr key={s.id}><td>{s.name}</td><td>{s.contactName || '—'}</td><td>{s.phone || '—'}</td><td>{s.email || '—'}</td><td><button className="btn btn-ghost px-3 py-1.5 text-xs">{t('edit')}</button></td></tr>} />}
        {tab === 'risks' && <SmartTable columns={[t('products'), t('stock'), t('low_stock'), t('risk'), t('actions')]} rows={reorderPriority} loading={busy} emptyTitle={t('no_inventory_risk')} emptyDescription={t('no_product_below_threshold')} renderRow={(p: Product) => <tr key={p.id}><td>{p.name}{p.branch?.name && <span className="text-xs text-[var(--silver-dim)] block" data-testid="risk-branch">{p.branch.name}</span>}</td><td>{p.qty}</td><td>{p.lowAlert}</td><td><span className="risk-indicator" data-level={p.qty <= 0 ? 'critical' : 'high'}>{p.qty <= 0 ? t('out_of_stock') : t('low_stock')}</span></td><td><button className="btn btn-secondary px-3 py-1.5 text-xs" onClick={() => setShowPO(true)}>{t('reorder')}</button></td></tr>} />}
        {tab === 'movements' && <SmartTable columns={[t('date'), t('products'), t('type'), t('stock'), t('source')]} rows={movements} loading={busy} emptyTitle={t('no_stock_movement')} emptyDescription={t('build_inventory_timeline')} renderRow={(m: Movement) => <tr key={m.id}><td>{new Date(m.occurredAt).toLocaleString()}</td><td>{m.product?.name || '—'}</td><td>{t('mv_' + (m.type || '').toLowerCase()) || m.type}</td><td>{m.qty > 0 ? `+${m.qty}` : m.qty}</td><td>{m.qty < 0 ? t('demand') || 'Demand' : t('supply') || 'Supply'}</td></tr>} />}

            </>
        )}

        {showPO && (
          <ModalPortal>
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 overflow-auto" onClick={() => setShowPO(false)}>
            <div className="card card-static glass max-w-2xl w-full my-8" onClick={(e) => e.stopPropagation()}>
              <h2 className="text-xl font-bold mb-4 text-white">{t('create_po')}</h2>
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="col-span-2">
                  <label className="text-xs text-[var(--silver-dim)] block mb-1">{t('suppliers')} <span className="text-[var(--danger)]">*</span></label>
                  <select value={poForm.supplierId} onChange={(e) => setPoForm({ ...poForm, supplierId: e.target.value })} className="input">
                    <option value="">{t('select_supplier') || 'Select supplier…'}</option>
                    {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
                  </select>
                </div>
                {/* P4-3: choose the destination branch for this order */}
                <div className="col-span-2">
                  <label className="text-xs text-[var(--silver-dim)] block mb-1">{t('branch')}</label>
                  <select value={poForm.branchId || ''} onChange={(e) => setPoForm({ ...poForm, branchId: e.target.value })} className="input">
                    <option value="">{t('all_branches')}</option>
                    {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
                  </select>
                  {suppliers.length === 0 && (
                    <p className="text-xs text-amber-400/90 mt-1">
                      {t('no_suppliers_reorder_help') || 'You have no suppliers yet — add one first, then create the order.'}
                      <button type="button" className="underline ms-2" onClick={() => { setShowPO(false); setShowSupplier(true); }}>{t('add_supplier')}</button>
                    </p>
                  )}
                </div>
              </div>

              <div className="mb-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs font-bold text-[var(--silver-dim)] uppercase">{t('items')}</span>
                  <button className="text-xs text-[var(--primary)]" onClick={() => setPoForm({ ...poForm, items: [...poForm.items, { productId: '', qty: 1 }] })}>+ {t('add')}</button>
                </div>
                <div className="space-y-2">
                  {poForm.items.map((item, idx) => (
                    <div key={idx} className="flex gap-2">
                      <select 
                        className="input flex-1" 
                        value={item.productId} 
                        onChange={(e) => {
                          const newItems = [...poForm.items];
                          newItems[idx].productId = e.target.value;
                          setPoForm({ ...poForm, items: newItems });
                        }}
                      >
                        <option value="">{t('select_product') || 'Select Product'}</option>
                        {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                      </select>
                      <input 
                        type="number" className="input w-24" placeholder="Qty" 
                        value={item.qty} 
                        onChange={(e) => {
                          const newItems = [...poForm.items];
                          newItems[idx].qty = Number(e.target.value);
                          setPoForm({ ...poForm, items: newItems });
                        }} 
                      />
                      {poForm.items.length > 1 && <button className="text-red-500 px-2" onClick={() => setPoForm({ ...poForm, items: poForm.items.filter((_, i) => i !== idx) })}>✕</button>}
                    </div>
                  ))}
                </div>
              </div>

              <label className="text-xs text-[var(--silver-dim)] block mb-1">{t('notes')}</label>
              <textarea value={poForm.notes} onChange={(e) => setPoForm({ ...poForm, notes: e.target.value })} className="input h-20 mb-4" />
              <div className="flex gap-2 justify-end"><button className="btn btn-ghost" onClick={() => setShowPO(false)}>{t('cancel')}</button><button className="btn btn-primary" onClick={createPO}>{t('create')}</button></div>
            </div>
          </div>
        </ModalPortal>
        )}

        {showSupplier && (
          <ModalPortal>
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4" onClick={() => setShowSupplier(false)}>
            <div className="card card-static glass max-w-md w-full" onClick={(e) => e.stopPropagation()}>
              <h2 className="text-xl font-bold mb-4 text-white">{t('add_supplier')}</h2>
              <input className="input mb-3" placeholder={t('name')} value={supForm.name} onChange={(e) => setSupForm({ ...supForm, name: e.target.value })} />
              <input className="input mb-3" placeholder={t('contacted')} value={supForm.contactName} onChange={(e) => setSupForm({ ...supForm, contactName: e.target.value })} />
              <input className="input mb-3" placeholder={t('phone')} value={supForm.phone} onChange={(e) => setSupForm({ ...supForm, phone: e.target.value })} />
              <input className="input mb-4" placeholder={t('email')} value={supForm.email} onChange={(e) => setSupForm({ ...supForm, email: e.target.value })} />
              <div className="flex gap-2 justify-end"><button className="btn btn-ghost" onClick={() => setShowSupplier(false)}>{t('cancel')}</button><button className="btn btn-primary" onClick={createSupplier}>{t('create')}</button></div>
            </div>
          </div>
        </ModalPortal>
        )}
      </ProductPage>
    </Shell>
  );
}
