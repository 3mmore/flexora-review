'use client';
import React from 'react';
import { HeroSection } from '@/components/landing/HeroSection';
import { TrustSection, ProblemSection } from '@/components/landing/TrustAndProblem';
import { ModulesSection, AISystemSection } from '@/components/landing/AIAndModules';
import { SecuritySection, AutomationSection, PerformanceSection, PricingSection } from '@/components/landing/EnterpriseCore';
import { FAQSection, FooterSection } from '@/components/landing/FAQAndFooter';
import { Button } from '@/components/ui/Button';
import { useTranslation } from '@/lib/i18n';

export default function LandingPage() {
  const { t } = useTranslation();
  return (
    <div className="bg-base min-h-screen font-body selection:bg-violet-DEFAULT/30">
      <HeroSection />
      <TrustSection />
      <ProblemSection />
      <ModulesSection />
      <AISystemSection />
      <SecuritySection />
      <AutomationSection />
      <PerformanceSection />
      <PricingSection />
      <FAQSection />
      
      {/* Final CTA */}
      <section className="py-24 bg-base relative overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[60%] h-[60%] bg-violet-DEFAULT/10 rounded-full blur-[120px]" />
        <div className="max-w-4xl mx-auto px-4 relative z-10 text-center space-y-8">
          <h2 className="text-5xl md:text-7xl font-display font-bold text-white leading-tight">
            {t('landing_cta_title') || 'The Operating System For Modern Fitness Businesses.'}
          </h2>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-8">
            <Button className="bg-violet-DEFAULT hover:bg-violet-dim text-white px-10 py-5 rounded-full text-xl font-medium transition-all hover:scale-105">
              {t('watch_demo')}
            </Button>
            <Button variant="ghost" className="border-titanium text-white px-10 py-5 rounded-full text-xl font-medium backdrop-blur-md hover:bg-white/5 transition-all">
              {t('start_free_trial') || 'Start Free Trial'}
            </Button>
          </div>
        </div>
      </section>

      <FooterSection />
    </div>
  );
}
