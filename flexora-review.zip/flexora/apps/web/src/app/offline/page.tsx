'use client';
import { useTranslation } from '@/lib/i18n';

export default function OfflinePage() {
  const { t, lang } = useTranslation();
  return (
    <main dir={lang === 'ar' ? 'rtl' : 'ltr'} style={{
      minHeight: '100vh',
      background: 'var(--bg-base)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'white',
      fontFamily: 'sans-serif',
      textAlign: 'center',
      padding: '2rem',
    }}>
      <div style={{ fontSize: '4rem' }}>📵</div>
      <h1 style={{
        fontSize: '2rem',
        fontWeight: 900,
        marginTop: '1rem',
        color: 'var(--brand)',
      }}>
        {t('offline_title')}
      </h1>
      <p style={{
        marginTop: '1rem',
        color: 'rgba(255,255,255,0.6)',
        maxWidth: '400px',
      }}>
        {t('offline_desc')}
      </p>
      <button
        onClick={() => window.location.reload()}
        style={{
          marginTop: '2rem',
          padding: '0.75rem 2rem',
          background: 'var(--brand)',
          border: 'none',
          borderRadius: '12px',
          color: 'white',
          fontWeight: 700,
          fontSize: '1rem',
          cursor: 'pointer',
        }}>
        {t('retry')}
      </button>
      <p style={{
        marginTop: '3rem',
        color: 'rgba(255,255,255,0.3)',
        fontSize: '0.8rem',
      }}>
        {t('offline_title')}
      </p>
    </main>
  );
}
