'use client';
import { useQuery, useMutation } from '@tanstack/react-query';
import Shell from '@/components/Shell';
import { Button } from '@/components/ui/Button';
import { api } from '@/lib/api';
import { useTranslation } from '@/lib/i18n';
import { isAllowedRedirect } from '@/lib/validate-url';
import { safeErrorMessage } from '@/lib/safe-error';
import { label } from '@/lib/i18n/codes';
import { featureLabel } from '@/lib/i18n/features';
import { formatDate } from '@/lib/dates';

const planLimits: Record<string, { members: string; staff: string; features: string[] }> = {
  BASIC: { members: '50', staff: '1', features: ['basic_reports', 'members_attendance'] },
  PRO: { members: '500', staff: '5', features: ['smart_ai', 'messaging_landing', 'advanced_reports', 'api_access'] },
  ELITE: { members: 'unlimited', staff: 'unlimited', features: ['all_pro_features', 'white_label', 'multi_branch', 'dedicated_support'] },
};

export default function BillingPage() {
  const { t, lang } = useTranslation();
  const subscription = useQuery({ queryKey: ['billing-subscription'], queryFn: () => api<any>('/billing/subscription').catch(() => ({ plan: 'BASIC', status: 'ACTIVE' })) });
  const checkout = useMutation({ mutationFn: (plan: 'PRO' | 'ELITE') => api<{ url?: string }>('/billing/checkout', { method: 'POST', body: JSON.stringify({ plan }) }), onSuccess: (r) => { if (r?.url && isAllowedRedirect(r.url)) location.href = r.url; else if (r?.url) alert(t('invalid_redirect_url')); else subscription.refetch(); } });
  const portal = useMutation({ mutationFn: () => api<{ url?: string }>('/billing/portal'), onSuccess: (r) => { if (r?.url && isAllowedRedirect(r.url)) location.href = r.url; else alert(t('invalid_redirect_url')); } });
  const cancel = useMutation({ mutationFn: () => api('/billing/cancel', { method: 'POST' }), onSuccess: () => subscription.refetch() });
  const sub = subscription.data || { plan: 'BASIC', status: 'ACTIVE' };
  const current = sub.plan || sub.tier || 'BASIC';
  const limits = planLimits[current] || planLimits.BASIC;

  return <Shell><main className="space-y-6 px-8 py-8">
    <section className="rounded-3xl border border-white/10 bg-black/30 p-6">
      <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#c5a059]">{t('billing_config') || 'FLEXORA Billing'}</p>
      <h1 className="text-4xl font-black text-white">{t('subscription')}</h1>
      <p className="mt-3 text-white/60">{t('billing_description')}</p>
    </section>
    <section className="grid gap-5 lg:grid-cols-[1fr_1.2fr]">
      <div className="rounded-3xl border border-[#c5a059]/40 bg-[#c5a059]/10 p-6">
        <h2 className="text-2xl font-black">{t('current_plan')}: {label(String(current), 'plan', lang === 'en' ? 'en' : 'ar')}</h2>
        <p className="mt-2 text-white/70">{t('status')}: {t('sub_' + sub.status.toLowerCase()) || sub.status}</p>
        <p className="mt-2 text-white/70">{t('members')}: {sub.memberCount || 0}/{t(limits.members) || limits.members} · {t('staff')}: {sub.staffCount || 0}/{t(limits.staff) || limits.staff}</p>
        {sub.currentPeriodEnd && <p className="mt-2 text-white/50">{t('expires_on')}: {formatDate(sub.currentPeriodEnd)}</p>}
        <div className="mt-5 flex flex-wrap gap-3">
          <Button onClick={() => portal.mutate()} loading={portal.isPending}>{t('manage_subscription')}</Button>
          <Button variant="danger" onClick={() => confirm(t('confirm_delete')) && cancel.mutate()} loading={cancel.isPending}>{t('cancel')}</Button>
        </div>
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        {(['BASIC', 'PRO', 'ELITE'] as const).map((plan) => (
          <div key={plan} className={`rounded-3xl border p-5 ${plan === current ? 'border-[#c5a059] bg-[#c5a059]/10' : 'border-white/10 bg-white/[0.04]'}`}>
            <h3 className="text-xl font-black">{label(plan, 'plan', lang === 'en' ? 'en' : 'ar')}</h3>
            <p className="mt-2 text-[#c5a059]">{plan === 'BASIC' ? t('free') : plan === 'PRO' ? `499 ${t('egp_month')}` : `999 ${t('egp_month')}`}</p>
            <ul className="mt-4 space-y-2 text-sm text-white/70">{planLimits[plan].features.map((f) => <li key={f}>✅ {featureLabel(f, lang === 'en' ? 'en' : 'ar')}</li>)}</ul>
            {plan !== 'BASIC' && plan !== current && <Button className="mt-5 w-full" onClick={() => checkout.mutate(plan)} loading={checkout.isPending}>{t('upgrade')}</Button>}
          </div>
        ))}
      </div>
    </section>
    <section className="rounded-3xl border border-white/10 bg-white/[0.04] p-6">
      <h2 className="text-2xl font-black">{t('billing_history')}</h2>
      <p className="mt-3 text-white/55">{t('billing_history_desc')}</p>
    </section>
  </main></Shell>;
}
