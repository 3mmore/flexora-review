'use client';
import Link from 'next/link';
import { useTranslation } from '@/lib/i18n';

export default function BillingCancelPage() { 
  const { t } = useTranslation();
  return <main className="min-h-screen bg-[#050505] px-5 py-24 text-center text-white">
    <div className="mx-auto max-w-xl rounded-3xl border border-white/10 bg-white/[0.04] p-8">
      <div className="text-6xl">⚠️</div>
      <h1 className="mt-5 text-4xl font-black">{t('billing_cancel_title')}</h1>
      <p className="mt-3 text-white/60">{t('billing_cancel_desc')}</p>
      <div className="mt-8 flex justify-center gap-3">
        <Link href="/billing" className="rounded-2xl bg-[#c5a059] px-6 py-3 font-bold text-black">{t('try_again')}</Link>
        <Link href="/dashboard" className="rounded-2xl border border-white/15 px-6 py-3 font-bold">{t('continue_free')}</Link>
      </div>
    </div>
  </main>; 
}
