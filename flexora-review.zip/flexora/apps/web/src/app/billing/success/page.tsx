'use client';
import Link from 'next/link';
import { useTranslation } from '@/lib/i18n';

export default function BillingSuccessPage() { 
  const { t } = useTranslation();
  return <main className="min-h-screen bg-[#050505] px-5 py-24 text-center text-white">
    <div className="mx-auto max-w-xl rounded-3xl border border-white/10 bg-white/[0.04] p-8">
      <div className="text-6xl">✅</div>
      <h1 className="mt-5 text-4xl font-black">{t('billing_success_title')}</h1>
      <p className="mt-3 text-white/60">{t('billing_success_desc')}</p>
      <Link href="/dashboard" className="mt-8 inline-flex rounded-2xl bg-[#c5a059] px-6 py-3 font-bold text-black">{t('go_to_dashboard')}</Link>
    </div>
  </main>; 
}
