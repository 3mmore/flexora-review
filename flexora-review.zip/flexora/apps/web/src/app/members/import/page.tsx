'use client';
import { useState, useCallback, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useTranslation } from '@/lib/i18n';
import { localizePlanName, planOptionLabel } from '@/lib/plan-label';

const API_ORIGIN = (process.env.NEXT_PUBLIC_API_URL || '').replace(/\/$/, '');
const API_BASE = API_ORIGIN.endsWith('/api') ? API_ORIGIN : `${API_ORIGIN}/api`;
function csrfToken() {
  if (typeof document === 'undefined') return '';
  return document.cookie.split(';').map((v) => v.trim()).find((v) => v.startsWith('_csrf='))?.slice(6) || '';
}

type FlexoraField = 'name'|'mobile'|'email'|'dob'|
  'gender'|'nationalId'|'planName'|'startDate'|
  'expiryDate'|'sessionsLeft'|'branch'|
  'notes'|'status'|null;

export default function ImportPage() {
  const { t, lang } = useTranslation();
  const router = useRouter();
  const [step, setStep] = useState<1|2|3|4|5>(1);
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState<{
    totalRows: number;
    columns: string[];
    mapping: Record<string, FlexoraField>;
    preview: Record<string,unknown>[];
    warnings: string[];
    aiMappedCount: number;
    uploadId?: string;
  } | null>(null);
  const [importing, setImporting] = useState(false);
  const [result, setResult] = useState<{
    imported: number; updated: number;
    skipped: number; failed: number;
    errors: {row:number; reason:string; code?: 'DUPLICATE'|'NO_PLAN_MATCH'|'NO_BRANCH_MATCH'|'VALIDATION'|'OTHER'}[];
    summary?: { alreadyMember?: number; duplicateSkipped?: number; duplicateFailed?: number; duplicate?: number; noPlanMatch: number; noBranchMatch: number; validation: number; other: number; totalRows?: number; wouldCreateNew?: number; missingExpiry?: number; missingSessions?: number };
    createdPlans?: { id: string; name: string; price: number; days: number; type: string }[];
  } | null>(null);
  const [options, setOptions] = useState({
    skipDuplicates: true,
    updateExisting: false,
    defaultPlanId: '',
    defaultBranchId: '',
  });
  // ROUND 14 (security review, PHASE K3): an import must never create a member
  // who can train without a paid period. The desk chooses how rows land; the
  // API enforces the same rule and needs `members.import` for 'paid'.
  type Activation = 'pending' | 'expired' | 'paid';
  const [activation, setActivation] = useState<Activation>('pending');
  const [allowOpenEnded, setAllowOpenEnded] = useState(false);
  const [canImportActive, setCanImportActive] = useState<boolean | null>(null);
  const [plans, setPlans] = useState<{id:string;name:string;price:number}[]>([]);
  const [branches, setBranches] = useState<{id:string;name:string}[]>([]);

  // ROUND 13 (Phase 4): the pre-import plan-mapping step. Every DISTINCT plan
  // name found in the file gets one decision: use an existing plan, create the
  // plan now (name/price/duration), or skip (those rows fail with a reason).
  type PlanMapEntry = {
    action: 'unmapped' | 'existing' | 'create' | 'skip';
    planId?: string;
    name?: string;
    price?: string;
    days?: string;
    type?: 'SESSION' | 'TIME';
    sessions?: string;
  };
  const [filePlanNames, setFilePlanNames] = useState<{ name: string; rows: number }[]>([]);
  const [planMap, setPlanMap] = useState<Record<string, PlanMapEntry>>({});
  // ROUND 13 (security review, PHASE B): creating plans from the mapping step
  // is a plans.manage operation — the API enforces it (403); the wizard hides
  // the option so the control is never offered to someone who lacks it.
  const [canCreatePlans, setCanCreatePlans] = useState<boolean | null>(null);

  const FIELD_LABELS: Record<string, string> = {
    name: t('name'),
    mobile: t('mobile'),
    email: t('email'),
    dob: t('dob'),
    gender: t('gender'),
    nationalId: t('national_id'),
    planName: t('plan'),
    startDate: t('start_date') || 'Start Date',
    expiryDate: t('expiry'),
    sessionsLeft: t('sessions'),
    branch: t('branch'),
    notes: t('notes'),
    status: t('status'),
  };

  useEffect(() => {
    // Who is importing? (decides whether "create this plan now" is offered)
    fetch(`${API_BASE}/permissions/me`, { credentials: 'include' })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        const perms: string[] = Array.isArray(d?.permissions) ? d.permissions : [];
        setCanCreatePlans(perms.includes('plans.manage'));
        // PHASE K3: importing rows as ALREADY-PAID memberships needs its own
        // permission (OWNER by default, grantable on the Team page).
        setCanImportActive(perms.includes('members.import'));
      })
      .catch(() => { setCanCreatePlans(false); setCanImportActive(false); });
  }, []);

  useEffect(() => {
    // Load plans and branches for the default selector dropdowns
    fetch(`${API_BASE}/plans`, { credentials: 'include' })
      .then((r) => r.json()).then((d) => setPlans(Array.isArray(d) ? d : (d.items || []))).catch(() => {});
    fetch(`${API_BASE}/branches`, { credentials: 'include' })
      .then((r) => r.json()).then((d) => {
        const list = Array.isArray(d) ? d : (d.items || []);
        setBranches(list);
        // Auto-select if exactly one branch exists
        if (list.length === 1) setOptions((o) => ({ ...o, defaultBranchId: list[0].id }));
      }).catch(() => {});
  }, []);

  // ROUND 13 (Phase 4): initialize one decision per distinct file plan name.
  // When the gym has exactly ONE plan, preselect it for every name — the
  // common case for a young gym importing its first file. Existing user
  // choices are never overwritten.
  useEffect(() => {
    if (!filePlanNames.length) return;
    setPlanMap((prev) => {
      const next: Record<string, PlanMapEntry> = {};
      for (const { name } of filePlanNames) {
        const existing = prev[name];
        next[name] =
          existing && existing.action !== 'unmapped'
            ? existing
            : plans.length === 1
              ? { action: 'existing', planId: plans[0].id }
              : { action: 'unmapped' };
      }
      return next;
    });
  }, [plans, filePlanNames]);

  const handleUpload = useCallback(async (file: File) => {
    setUploading(true);
    try {
      const form_data = new FormData();
      form_data.append('file', file);
      const res = await fetch(`${API_BASE}/members/import/preview`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'X-CSRF-Token': csrfToken() },
        body: form_data,
      });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      setPreview({ ...data, uploadId: data.uploadId });
      // ROUND 13 (Phase 4): distinct plan names in the file → mapping step.
      setFilePlanNames(Array.isArray(data.planNames) ? data.planNames : []);
      setStep(2);
    } catch (e) {
      alert(e instanceof Error ? e.message : t('upload_failed'));
    } finally {
      setUploading(false);
    }
  }, [t]);

  const handleConfirm = async () => {
    if (!preview) return;
    setImporting(true);
    try {
      // ROUND 13 (Phase 4): send the owner's plan-mapping decisions — only
      // names with an actual decision; unmapped names fall through to the
      // fuzzy/default-plan behavior exactly as before.
      const planMapping: Record<string, unknown> = {};
      for (const { name } of filePlanNames) {
        const e = planMap[name];
        if (!e || e.action === 'unmapped') continue;
        if (e.action === 'existing' && e.planId) {
          planMapping[name] = { action: 'existing', planId: e.planId };
        } else if (e.action === 'create') {
          planMapping[name] = {
            action: 'create',
            name: (e.name || '').trim() || name,
            price: Number(e.price || 0),
            days: Number(e.days || 30),
            type: e.type || 'TIME',
            sessions: Number(e.sessions || 0),
          };
        } else if (e.action === 'skip') {
          planMapping[name] = { action: 'skip' };
        }
      }
      const res = await fetch(`${API_BASE}/members/import/confirm`, {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken() },
        body: JSON.stringify({
          uploadId: preview.uploadId,
          mapping: preview.mapping,
          // PHASE K3: how these rows land (pending / expired / paid).
          options: { ...options, planMapping, activation, allowOpenEnded },
        }),
      });
      const data = await res.json();
      setResult(data);
      setStep(5);
    } catch (e) {
      alert(e instanceof Error ? e.message : t('import_failed'));
    } finally {
      setImporting(false);
    }
  };

  /**
   * PHASE 9 — the failure breakdown shown at the top of the results.
   * "Already a member" (duplicate prevention) and "nothing matched" are
   * counted separately; when the API does not send codes (older deployment)
   * the same categories are derived from the reason text.
   */
  const failureBreakdown = (() => {
    if (!result) return null;
    const codeOf = (e: { reason: string; code?: string }) => {
      if (e.code) return e.code;
      const m = e.reason || '';
      if (/already exists|already a member|Duplicate member/i.test(m)) return 'DUPLICATE';
      if (/No plan matched|no plan and no default plan/i.test(m)) return 'NO_PLAN_MATCH';
      if (/No branch matched|no branch and no default branch/i.test(m)) return 'NO_BRANCH_MATCH';
      // ROUND 14 (security review, PHASE K3): a row that would have created a
      // member able to train without paying is called out on its own — it is
      // the one failure that is a safety net firing, not a data problem.
      if (/expiry date is required|expiry.*required for a time-based plan/i.test(m)) return 'MISSING_EXPIRY';
      if (/session count is required|sessions.*required/i.test(m)) return 'MISSING_SESSIONS';
      if (/is required|invalid/i.test(m)) return 'VALIDATION';
      return 'OTHER';
    };
    const counts = { DUPLICATE: 0, NO_PLAN_MATCH: 0, NO_BRANCH_MATCH: 0, VALIDATION: 0, OTHER: 0, MISSING_EXPIRY: 0, MISSING_SESSIONS: 0 } as Record<string, number>;
    for (const e of result.errors) counts[codeOf(e)] = (counts[codeOf(e)] || 0) + 1;
    if (result.summary) {
      counts.DUPLICATE =
        result.summary.alreadyMember ??
        (typeof result.summary.duplicate === 'number' ? result.summary.duplicate + result.skipped : counts.DUPLICATE);
      counts.NO_PLAN_MATCH = result.summary.noPlanMatch;
      counts.NO_BRANCH_MATCH = result.summary.noBranchMatch;
      counts.VALIDATION = result.summary.validation;
      counts.OTHER = result.summary.other;
      counts.MISSING_EXPIRY = result.summary.missingExpiry ?? 0;
      counts.MISSING_SESSIONS = result.summary.missingSessions ?? 0;
    }
    return counts;
  })();

  return (
    <div dir={lang === 'ar' ? 'rtl' : 'ltr'} style={{
      minHeight: '100vh',
      background: '#0A0A0F',
      color: 'white',
      padding: '2rem',
    }}>
      <h1 style={{
        fontSize: '1.8rem',
        fontWeight: 900,
        marginBottom: '0.5rem',
        color: 'var(--brand)',
      }}>
        {t('import_members_title')}
      </h1>
      <p style={{ color: 'rgba(255,255,255,0.5)', marginBottom: '2rem' }}>
        {t('import_members_desc')}
      </p>

      {/* Progress */}
      <div style={{ display:'flex', gap:'1rem', marginBottom:'2rem' }}>
        {[
          ['1', t('upload_file')],
          ['2', t('map_columns')],
          ['3', t('map_plans')],
          ['4', t('import_options')],
          ['5', t('results')],
        ].map(([n, label]) => (
          <div key={n} style={{
            flex: 1, textAlign: 'center',
            padding: '0.5rem',
            background: step >= Number(n)
              ? 'var(--brand)' : 'rgba(255,255,255,0.05)',
            borderRadius: '8px',
            fontSize: '0.8rem',
            fontWeight: step === Number(n) ? 700 : 400,
          }}>
            {n}. {label}
          </div>
        ))}
      </div>

      {/* STEP 1: Upload */}
      {step === 1 && (
        <div
          onDragOver={e => e.preventDefault()}
          onDrop={e => {
            e.preventDefault();
            const f = e.dataTransfer.files[0];
            if (f) handleUpload(f);
          }}
          style={{
            border: '2px dashed rgba(var(--brand-rgb),0.4)',
            borderRadius: '16px',
            padding: '4rem 2rem',
            textAlign: 'center',
            cursor: 'pointer',
          }}>
          <div style={{ fontSize: '3rem' }}>📂</div>
          <p style={{ marginTop: '1rem', fontSize: '1.1rem' }}>
            {t('drag_drop_file')}
          </p>
          <input
            type="file"
            accept=".xlsx,.csv"
            style={{ display: 'none' }}
            id="fileInput"
            data-testid="import-file-input"
            onChange={e => {
              const f = (e.target as HTMLInputElement).files?.[0];
              if (f) handleUpload(f);
            }}
          />
          <label htmlFor="fileInput" style={{
            display: 'inline-block',
            marginTop: '1rem',
            padding: '0.75rem 2rem',
            background: 'var(--brand)',
            borderRadius: '8px',
            cursor: 'pointer',
            fontWeight: 700,
          }}>
            {uploading ? t('ai_analyzing') : t('select_excel_csv')}
          </label>
          <p style={{ marginTop: '1rem', color: 'rgba(255,255,255,0.3)', fontSize: '0.8rem' }}>
            {t('max_size_10mb')}
          </p>
        </div>
      )}

      {/* STEP 2: AI Mapping */}
      {step === 2 && preview && (
        <div>
          <div style={{
            background: 'rgba(var(--brand-rgb),0.1)',
            border: '1px solid rgba(var(--brand-rgb),0.3)',
            borderRadius: '12px',
            padding: '1rem',
            marginBottom: '1.5rem',
          }}>
            🤖 {t('ai_mapped_desc')}{' '}
            <strong>{preview.aiMappedCount}</strong>
            {' '} {t('out_of')} {' '}
            <strong>{preview.columns.length}</strong>
            {' '} {t('columns_auto')} •{' '}
            <strong>{preview.totalRows}</strong> {t('rows')}
          </div>
          {preview.warnings.map((w, i) => (
            <div key={i} style={{
              background:'rgba(255,200,0,0.1)',
              border:'1px solid rgba(255,200,0,0.3)',
              borderRadius:'8px', padding:'0.75rem',
              marginBottom:'0.5rem',
              color:'#FFD700', fontSize:'0.85rem',
            }}>⚠️ {w}</div>
          ))}
          <table style={{
            width: '100%',
            borderCollapse: 'collapse',
            marginBottom: '1.5rem',
          }}>
            <thead>
              <tr style={{ background:'rgba(255,255,255,0.05)' }}>
                <th style={{ padding:'0.75rem', textAlign: lang === 'ar' ? 'right' : 'left' }}>{t('file_column')}</th>
                <th style={{ padding:'0.75rem', textAlign: lang === 'ar' ? 'right' : 'left' }}>{t('flexora_field')}</th>
              </tr>
            </thead>
            <tbody>
              {preview.columns.map(col => (
                <tr key={col} style={{ borderBottom:'1px solid rgba(255,255,255,0.05)' }}>
                  <td style={{ padding:'0.75rem' }}>{col}</td>
                  <td style={{ padding:'0.75rem' }}>
                    <select
                      value={preview.mapping[col] || ''}
                      onChange={e => {
                        setPreview(p => p ? {
                          ...p,
                          mapping: {
                            ...p.mapping,
                            [col]: (e.target as HTMLSelectElement).value as FlexoraField || null,
                          }
                        } : p);
                      }}
                      style={{
                        background: '#1a1a2e',
                        color: 'white',
                        border: '1px solid rgba(255,255,255,0.2)',
                        borderRadius: '6px',
                        padding: '0.4rem',
                        width: '100%',
                      }}>
                      <option value="">— {t('ignore')} —</option>
                      {Object.entries(FIELD_LABELS).map(([val, lbl]) => (
                        <option key={val} value={val}>{lbl}</option>
                      ))}
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <button
            data-testid="import-next-mapping"
            onClick={async () => {
              // ROUND 13 (Phase 4): the plan-mapping step lists the distinct
              // plan names for the mapping CONFIRMED here (the owner may have
              // corrected the AI proposal) — ask the server with the final
              // mapping instead of trusting the preview-time guess.
              if (preview?.uploadId) {
                try {
                  const r = await fetch(`${API_BASE}/members/import/plan-names`, {
                    method: 'POST',
                    credentials: 'include',
                    headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken() },
                    body: JSON.stringify({ uploadId: preview.uploadId, mapping: preview.mapping }),
                  });
                  if (r.ok) {
                    const d = await r.json();
                    setFilePlanNames(Array.isArray(d.planNames) ? d.planNames : []);
                  }
                } catch { /* keep whatever the preview reported */ }
              }
              setStep(3);
            }}
            style={{
              padding: '0.75rem 2rem',
              background: 'var(--brand)',
              border: 'none',
              borderRadius: '8px',
              color: 'white',
              fontWeight: 700,
              cursor: 'pointer',
              fontSize: '1rem',
            }}>
            {t('next_options')} ←
          </button>
        </div>
      )}

      {/* STEP 3: Plan mapping (ROUND 13 Phase 4) — every distinct plan name
          in the file gets a decision BEFORE the import runs. */}
      {step === 3 && preview && (
        <div>
          <div style={{
            background: 'rgba(var(--brand-rgb),0.1)',
            border: '1px solid rgba(var(--brand-rgb),0.3)',
            borderRadius: '12px',
            padding: '1rem',
            marginBottom: '1.5rem',
            fontSize: '0.9rem',
          }}>
            {t('map_plans_desc')}
          </div>
          {Object.values(planMap).some((e) => e.action === 'unmapped') && (
            <div data-testid="import-planmap-warning" style={{
              background: 'rgba(255,200,0,0.1)',
              border: '1px solid rgba(255,200,0,0.3)',
              borderRadius: '8px', padding: '0.75rem',
              marginBottom: '1rem',
              color: '#FFD700', fontSize: '0.85rem',
            }}>⚠️ {t('unmapped_plans_warning')}</div>
          )}
          {filePlanNames.length === 0 ? (
            <p style={{ color: 'rgba(255,255,255,0.5)', marginBottom: '1.5rem' }}>
              {t('no_plan_names_in_file')}
            </p>
          ) : (
            <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '1.5rem' }}>
              <thead>
                <tr style={{ background: 'rgba(255,255,255,0.05)' }}>
                  <th style={{ padding: '0.75rem', textAlign: lang === 'ar' ? 'right' : 'left' }}>{t('plan')} ({t('rows')})</th>
                  <th style={{ padding: '0.75rem', textAlign: lang === 'ar' ? 'right' : 'left' }}>{t('map_plans')}</th>
                </tr>
              </thead>
              <tbody>
                {filePlanNames.map(({ name, rows }) => {
                  const entry = planMap[name] || { action: 'unmapped' as const };
                  return (
                    <tr key={name} data-testid="import-planmap-row" style={{ borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                      <td style={{ padding: '0.75rem' }}>
                        <strong>{name}</strong>{' '}
                        <span style={{ color: 'rgba(255,255,255,0.45)', fontSize: '0.8rem' }}>({rows} {t('rows')})</span>
                      </td>
                      <td style={{ padding: '0.75rem' }}>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                          <select
                            data-testid={`import-planmap-action-${name}`}
                            value={entry.action === 'unmapped' ? '' : entry.action}
                            onChange={(e) => {
                              const action = e.target.value as PlanMapEntry['action'];
                              setPlanMap((pm) => ({
                                ...pm,
                                [name]: {
                                  action,
                                  planId: action === 'existing' ? (plans.length === 1 ? plans[0].id : '') : undefined,
                                  name: action === 'create' ? name : undefined,
                                  price: action === 'create' ? '' : undefined,
                                  days: action === 'create' ? '30' : undefined,
                                  type: action === 'create' ? 'TIME' : undefined,
                                  sessions: undefined,
                                },
                              }));
                            }}
                            style={{ background: '#1a1a2e', color: 'white', border: '1px solid rgba(255,255,255,0.2)', borderRadius: '6px', padding: '0.4rem' }}
                          >
                            <option value="">— {t('choose_action')} —</option>
                            <option value="existing">{t('use_existing_plan')}</option>
                            <option value="create" disabled={canCreatePlans === false}>
                              {t('create_this_plan')}{canCreatePlans === false ? ` (${t('plans_manage_required') || 'requires plans.manage'})` : ''}
                            </option>
                            <option value="skip">{t('skip_this_plan')}</option>
                          </select>
                          {entry.action === 'existing' && (
                            <select
                              data-testid={`import-planmap-plan-${name}`}
                              value={entry.planId || ''}
                              onChange={(e) => setPlanMap((pm) => ({ ...pm, [name]: { ...pm[name], planId: e.target.value } }))}
                              style={{ background: '#1a1a2e', color: 'white', border: '1px solid rgba(255,255,255,0.2)', borderRadius: '6px', padding: '0.4rem' }}
                            >
                              <option value="">— {t('select_plan')} —</option>
                              {plans.map((pl) => (<option key={pl.id} value={pl.id}>{planOptionLabel(pl, lang, t)}</option>))}
                            </select>
                          )}
                          {entry.action === 'create' && (
                            <div data-testid={`import-planmap-create-${name}`} style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem', alignItems: 'center' }}>
                              <input
                                data-testid={`import-planmap-create-name-${name}`}
                                value={entry.name || ''}
                                onChange={(e) => setPlanMap((pm) => ({ ...pm, [name]: { ...pm[name], name: e.target.value } }))}
                                placeholder={t('name')}
                                style={{ flex: '1 1 160px', background: '#1a1a2e', color: 'white', border: '1px solid rgba(255,255,255,0.2)', borderRadius: '6px', padding: '0.4rem' }}
                              />
                              <input
                                data-testid={`import-planmap-create-price-${name}`}
                                type="number" min="0" step="0.01"
                                value={entry.price || ''}
                                onChange={(e) => setPlanMap((pm) => ({ ...pm, [name]: { ...pm[name], price: e.target.value } }))}
                                placeholder={t('price')}
                                style={{ width: '110px', background: '#1a1a2e', color: 'white', border: '1px solid rgba(255,255,255,0.2)', borderRadius: '6px', padding: '0.4rem' }}
                              />
                              <input
                                data-testid={`import-planmap-create-days-${name}`}
                                type="number" min="0"
                                value={entry.days || ''}
                                onChange={(e) => setPlanMap((pm) => ({ ...pm, [name]: { ...pm[name], days: e.target.value } }))}
                                placeholder={t('duration_days')}
                                style={{ width: '120px', background: '#1a1a2e', color: 'white', border: '1px solid rgba(255,255,255,0.2)', borderRadius: '6px', padding: '0.4rem' }}
                              />
                              <select
                                data-testid={`import-planmap-create-type-${name}`}
                                value={entry.type || 'TIME'}
                                onChange={(e) => setPlanMap((pm) => ({ ...pm, [name]: { ...pm[name], type: e.target.value as 'SESSION' | 'TIME' } }))}
                                style={{ background: '#1a1a2e', color: 'white', border: '1px solid rgba(255,255,255,0.2)', borderRadius: '6px', padding: '0.4rem' }}
                              >
                                <option value="TIME">{t('type')}: TIME</option>
                                <option value="SESSION">{t('type')}: SESSION</option>
                              </select>
                              {entry.type === 'SESSION' && (
                                <input
                                  data-testid={`import-planmap-create-sessions-${name}`}
                                  type="number" min="0"
                                  value={entry.sessions || ''}
                                  onChange={(e) => setPlanMap((pm) => ({ ...pm, [name]: { ...pm[name], sessions: e.target.value } }))}
                                  placeholder={t('sessions')}
                                  style={{ width: '110px', background: '#1a1a2e', color: 'white', border: '1px solid rgba(255,255,255,0.2)', borderRadius: '6px', padding: '0.4rem' }}
                                />
                              )}
                            </div>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
          <div style={{ display: 'flex', gap: '1rem' }}>
            <button
              onClick={() => setStep(2)}
              style={{
                padding: '0.75rem 2rem',
                background: 'transparent',
                border: '1px solid rgba(255,255,255,0.2)',
                borderRadius: '8px',
                color: 'white',
                cursor: 'pointer',
              }}>
              ← {t('back')}
            </button>
            <button
              data-testid="import-next-planmap"
              onClick={() => setStep(4)}
              style={{
                flex: 1,
                padding: '0.75rem 2rem',
                background: 'var(--brand)',
                border: 'none',
                borderRadius: '8px',
                color: 'white',
                fontWeight: 700,
                cursor: 'pointer',
                fontSize: '1rem',
              }}>
              {t('next')} →
            </button>
          </div>
        </div>
      )}

      {/* STEP 4: Options */}
      {step === 4 && (
        <div>
          {/* ROUND 14 (security review, PHASE K3) — how the imported rows land.
              A file with no expiry column must not be able to mint members who
              can train for free, so "already paid" is a separate, permissioned
              choice and the default is a pending registration. */}
          <div data-testid="import-activation" style={{
            background: 'rgba(255,255,255,0.03)',
            borderRadius: '12px',
            padding: '1.5rem',
            marginBottom: '1.5rem',
          }}>
            <p style={{ color: 'rgba(255,255,255,0.7)', fontSize: '0.9rem', fontWeight: 600, marginBottom: '0.75rem' }}>
              {t('import_activation_title') || 'How should these rows be imported?'}
            </p>
            {([
              ['pending', t('import_as_pending') || 'Pending payment — registered, cannot train until the desk collects payment', '🕓'],
              ['expired', t('import_as_expired') || 'Expired — archived records, cannot train (dates kept as data)', '📁'],
              ['paid', t('import_as_paid') || 'Already paid — active memberships (requires a valid expiry date)', '✅'],
            ] as [Activation, string, string][]).map(([value, label, icon]) => {
              const locked = value === 'paid' && canImportActive === false;
              return (
                <label key={value} style={{
                  display: 'flex', alignItems: 'flex-start', gap: '0.75rem', marginBottom: '0.75rem',
                  cursor: locked ? 'not-allowed' : 'pointer', opacity: locked ? 0.45 : 1,
                }}>
                  <input
                    type="radio"
                    name="import-activation"
                    data-testid={`import-activation-${value}`}
                    value={value}
                    checked={activation === value}
                    disabled={locked}
                    onChange={() => setActivation(value)}
                    style={{ width: '18px', height: '18px', marginTop: '2px' }}
                  />
                  <span style={{ fontSize: '0.9rem', lineHeight: 1.5 }}>
                    {icon} {label}
                    {locked ? (
                      <span style={{ display: 'block', color: '#FF6B6B', fontSize: '0.8rem', marginTop: '0.25rem' }}>
                        {t('members_import_permission_required') || 'Requires the members.import permission (owner can grant it on the Team page).'}
                      </span>
                    ) : null}
                  </span>
                </label>
              );
            })}
            {activation === 'paid' && (
              <label style={{ display: 'flex', alignItems: 'flex-start', gap: '0.75rem', marginTop: '0.5rem', cursor: 'pointer' }}>
                <input
                  type="checkbox"
                  data-testid="import-allow-open-ended"
                  checked={allowOpenEnded}
                  onChange={(e) => setAllowOpenEnded((e.target as HTMLInputElement).checked)}
                  style={{ width: '18px', height: '18px', marginTop: '2px' }}
                />
                <span style={{ fontSize: '0.85rem', color: 'rgba(255,255,255,0.75)', lineHeight: 1.5 }}>
                  {t('import_allow_open_ended') || 'Rows with no expiry date: import as EXPIRED instead of rejecting them (they are kept, but cannot train).'}
                </span>
              </label>
            )}
            {activation !== 'paid' && (
              <p style={{ fontSize: '0.8rem', color: 'rgba(255,255,255,0.55)', marginTop: '0.5rem', lineHeight: 1.5 }}>
                {t('import_pending_hint') || 'Activate a pending member later from the Leads or Members page with "Collect payment".'}
              </p>
            )}
          </div>
          <div style={{
            background: 'rgba(255,255,255,0.03)',
            borderRadius: '12px',
            padding: '1.5rem',
            marginBottom: '1.5rem',
          }}>
            {[
              ['skipDuplicates', t('skip_duplicates_label')],
              ['updateExisting', t('update_existing_label')],
            ].map(([key, label]) => (
              <label key={key} style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.75rem',
                marginBottom: '1rem',
                cursor: 'pointer',
              }}>
                <input
                  type="checkbox"
                  checked={options[key as keyof typeof options] as boolean}
                  onChange={e =>
                    setOptions(o => ({
                      ...o, [key]: (e.target as HTMLInputElement).checked
                    }))}
                  style={{ width:'20px', height:'20px'}}
                />
                {label}
              </label>
            ))}
          </div>
          {options.updateExisting && (
            <div data-testid="import-update-existing-warning" style={{
              background: 'rgba(255,200,0,0.08)',
              border: '1px solid rgba(255,200,0,0.35)',
              borderRadius: '10px',
              padding: '0.9rem 1rem',
              marginBottom: '1.5rem',
              color: '#FFD700',
              fontSize: '0.9rem',
            }}>
              ⚠️ {t('import_update_existing_warning') || 'Rows whose mobile number already belongs to a member will UPDATE that member — including moving them to the branch selected below. To only add new people, leave "update existing" switched off; rows that already exist will then be counted as "already a member" and skipped.'}
            </div>
          )}
          <div style={{
            background: 'rgba(255,255,255,0.03)',
            borderRadius: '12px',
            padding: '1.5rem',
            marginBottom: '1.5rem',
          }}>
            <p style={{ color: 'rgba(255,255,255,0.7)', fontSize: '0.9rem', fontWeight: 600, marginBottom: '0.5rem' }}>{t('default_plan_label')}</p>
            <select value={options.defaultPlanId} onChange={(e) => setOptions((o) => ({ ...o, defaultPlanId: e.target.value }))} style={{ width: '100%', padding: '0.65rem', background: '#1a1a2e', color: 'white', border: '1px solid rgba(255,255,255,0.2)', borderRadius: '8px', marginBottom: '1.25rem' }}>
              <option value="">— {t('select_plan')} —</option>
              {plans.map((p) => (<option key={p.id} value={p.id}>{planOptionLabel(p, lang, t)}</option>))}
            </select>
            <p style={{ color: 'rgba(255,255,255,0.7)', fontSize: '0.9rem', fontWeight: 600, marginBottom: '0.5rem' }}>{t('default_branch_label')}</p>
            <select value={options.defaultBranchId} onChange={(e) => setOptions((o) => ({ ...o, defaultBranchId: e.target.value }))} style={{ width: '100%', padding: '0.65rem', background: '#1a1a2e', color: 'white', border: '1px solid rgba(255,255,255,0.2)', borderRadius: '8px' }}>
              <option value="">— {t('select_branch')} —</option>
              {branches.map((b) => (<option key={b.id} value={b.id}>{b.name}</option>))}
            </select>
          </div>
          <div style={{
            background: 'rgba(255,50,50,0.1)',
            border: '1px solid rgba(255,50,50,0.3)',
            borderRadius: '8px',
            padding: '1rem',
            marginBottom: '1.5rem',
            color: '#FF6B6B',
          }}>
            ⚠️ {t('confirm')} <strong>{preview?.totalRows}</strong> {t('import_warning')}
          </div>
          <div style={{ display: 'flex', gap: '1rem' }}>
            <button
              onClick={() => setStep(3)}
              style={{
                padding: '0.75rem 2rem',
                background: 'transparent',
                border: '1px solid rgba(255,255,255,0.2)',
                borderRadius: '8px',
                color: 'white',
                cursor: 'pointer',
              }}>
              ← {t('back')}
            </button>
            <button
              data-testid="import-confirm"
              onClick={handleConfirm}
              disabled={importing}
              style={{
                flex: 1,
                padding: '0.75rem 2rem',
                background: importing ? 'rgba(var(--brand-rgb),0.4)' : 'var(--brand)',
                border: 'none',
                borderRadius: '8px',
                color: 'white',
                fontWeight: 700,
                cursor: importing ? 'not-allowed' : 'pointer',
                fontSize: '1rem',
              }}>
              {importing ? t('importing_label') : t('confirm_import')}
            </button>
          </div>
        </div>
      )}

      {/* STEP 5: Results */}
      {step === 5 && result && (
        <div>
          {failureBreakdown && (
            <div data-testid="import-summary" style={{
              background: 'rgba(255,255,255,0.03)',
              border: '1px solid rgba(255,255,255,0.10)',
              borderRadius: '14px',
              padding: '1.25rem 1.5rem',
              marginBottom: '1.5rem',
            }}>
              <h2 style={{ fontSize: '1.05rem', fontWeight: 800, marginBottom: '0.35rem' }}>
                {t('import_summary_title') || 'What happened to each row'}
              </h2>
              <p style={{ color: 'rgba(255,255,255,0.55)', fontSize: '0.85rem', marginBottom: '1rem' }}>
                {t('import_summary_help') || 'Reasons are counted separately so an import that failed because the members already exist is never confused with one where nothing could be matched.'}
              </p>
              <div style={{ display: 'grid', gap: '0.5rem' }}>
                <div data-testid="import-summary-duplicates" style={{ display: 'flex', justifyContent: 'space-between', gap: '1rem', padding: '0.6rem 0.8rem', borderRadius: '10px', background: 'rgba(78,205,196,0.08)', border: '1px solid rgba(78,205,196,0.25)' }}>
                  <span style={{ fontSize: '0.9rem' }}>
                    <strong>{failureBreakdown.DUPLICATE}</strong> {t('import_reason_duplicate') || 'already a member — duplicate prevention (their mobile number is already registered in this gym)'}
                  </span>
                  <span style={{ color: '#4ECDC4', fontSize: '0.8rem' }}>{t('import_reason_duplicate_tag') || 'expected, not a bug'}</span>
                </div>
                <div data-testid="import-summary-no-plan" style={{ display: 'flex', justifyContent: 'space-between', gap: '1rem', padding: '0.6rem 0.8rem', borderRadius: '10px', background: 'rgba(231,76,60,0.08)', border: '1px solid rgba(231,76,60,0.25)' }}>
                  <span style={{ fontSize: '0.9rem' }}>
                    <strong>{failureBreakdown.NO_PLAN_MATCH}</strong> {t('import_reason_no_plan') || 'no plan matched — pick a default plan below and import again'}
                  </span>
                  <span style={{ color: '#E74C3C', fontSize: '0.8rem' }}>{t('import_reason_needs_action') || 'needs action'}</span>
                </div>
                <div data-testid="import-summary-no-branch" style={{ display: 'flex', justifyContent: 'space-between', gap: '1rem', padding: '0.6rem 0.8rem', borderRadius: '10px', background: 'rgba(231,76,60,0.06)', border: '1px solid rgba(231,76,60,0.2)' }}>
                  <span style={{ fontSize: '0.9rem' }}>
                    <strong>{failureBreakdown.NO_BRANCH_MATCH}</strong> {t('import_reason_no_branch') || 'no branch matched — pick a default branch and import again'}
                  </span>
                  <span style={{ color: '#E74C3C', fontSize: '0.8rem' }}>{t('import_reason_needs_action') || 'needs action'}</span>
                </div>
                {(failureBreakdown.MISSING_EXPIRY > 0 || failureBreakdown.MISSING_SESSIONS > 0) && (
                  <div
                    data-testid="import-summary-missing-proof"
                    style={{
                      display: 'flex', justifyContent: 'space-between', gap: '1rem',
                      padding: '0.7rem 0.8rem', borderRadius: '10px',
                      background: 'rgba(243,156,18,0.10)', border: '1px solid rgba(243,156,18,0.35)',
                    }}
                  >
                    <span style={{ fontSize: '0.9rem' }}>
                      <strong>{failureBreakdown.MISSING_EXPIRY + failureBreakdown.MISSING_SESSIONS}</strong>{' '}
                      {t('import_reason_missing_proof') ||
                        'refused — these rows had no expiry date / session count, so importing them would have created members who could train without ever paying'}
                      {failureBreakdown.MISSING_EXPIRY > 0 && failureBreakdown.MISSING_SESSIONS > 0 && (
                        <span style={{ display: 'block', color: 'rgba(255,255,255,0.55)', fontSize: '0.8rem', marginTop: '0.25rem' }}>
                          {failureBreakdown.MISSING_EXPIRY} {t('import_reason_missing_expiry') || 'missing an expiry date'} ·{' '}
                          {failureBreakdown.MISSING_SESSIONS} {t('import_reason_missing_sessions') || 'missing a session count'}
                        </span>
                      )}
                    </span>
                    <span style={{ color: '#F39C12', fontSize: '0.8rem', whiteSpace: 'nowrap' }}>
                      {t('import_reason_refused_on_purpose') || 'refused on purpose'}
                    </span>
                  </div>
                )}
                {(failureBreakdown.VALIDATION > 0 || failureBreakdown.OTHER > 0) && (
                  <div data-testid="import-summary-other" style={{ display: 'flex', justifyContent: 'space-between', gap: '1rem', padding: '0.6rem 0.8rem', borderRadius: '10px', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.12)' }}>
                    <span style={{ fontSize: '0.9rem' }}>
                      <strong>{failureBreakdown.VALIDATION + failureBreakdown.OTHER}</strong> {t('import_reason_other') || 'invalid or unreadable rows — see the row list below'}
                    </span>
                    <span style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.8rem' }}>{t('import_reason_needs_action') || 'needs action'}</span>
                  </div>
                )}
              </div>
            </div>
          )}
          {result.createdPlans && result.createdPlans.length > 0 && (
            <div data-testid="import-created-plans" style={{
              background: 'rgba(var(--brand-rgb),0.08)',
              border: '1px solid rgba(var(--brand-rgb),0.3)',
              borderRadius: '12px',
              padding: '1rem 1.25rem',
              marginBottom: '1.5rem',
              fontSize: '0.9rem',
            }}>
              <strong>✨ {t('plans_created_during_import') || 'Plans created during this import'}:</strong>{' '}
              {result.createdPlans.map((p) => (
                <span key={p.id} data-testid={`import-created-plan-${p.name}`} style={{ marginInlineEnd: '0.75rem' }}>
                  {p.name} ({p.price} · {p.days}d)
                </span>
              ))}
            </div>
          )}
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(4, 1fr)',
            gap: '1rem',
            marginBottom: '2rem',
          }}>
            {[
              ['✅', result.imported, t('imported_label'), '#00C896'],
              ['🔄', result.updated, t('updated_label'), '#4ECDC4'],
              ['⏭️', result.skipped, t('skipped_label'), '#95A5A6'],
              ['❌', result.failed, t('failed_label'), '#E74C3C'],
            ].map(([icon, count, label, color]) => (
              <div key={String(label)} style={{
                background: 'rgba(255,255,255,0.03)',
                borderRadius: '12px',
                padding: '1.5rem',
                textAlign: 'center',
                border: `1px solid ${String(color)}30`,
              }}>
                <div style={{ fontSize: '2rem' }}>{String(icon)}</div>
                <div style={{ fontSize: '2rem', fontWeight: 900, color: String(color) }}>
                  {String(count)}
                </div>
                <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.8rem' }}>
                  {String(label)}
                </div>
              </div>
            ))}
          </div>
          {result.errors.length > 0 && (
            <div style={{ marginBottom: '1.5rem' }}>
              <h3 style={{ color: '#E74C3C', marginBottom: '0.5rem' }}>
                {t('errors_label')} ({result.errors.length})
              </h3>
              <div style={{
                maxHeight: '200px',
                overflow: 'auto',
                background: 'rgba(255,0,0,0.05)',
                borderRadius: '8px',
                padding: '1rem',
              }}>
                {result.errors.map((err_row, i) => (
                  <div key={i} style={{
                    fontSize: '0.85rem',
                    padding: '0.25rem 0',
                    borderBottom: '1px solid rgba(255,255,255,0.05)',
                  }}>
                    <span style={{
                      display: 'inline-block', minWidth: '5.5rem', fontWeight: 700,
                      color: err_row.code === 'DUPLICATE' ? '#4ECDC4' : err_row.code === 'NO_PLAN_MATCH' || err_row.code === 'NO_BRANCH_MATCH' ? '#E74C3C' : 'rgba(255,255,255,0.6)',
                    }} data-testid={`import-error-code-${err_row.row}`}>
                      {err_row.code === 'DUPLICATE' ? (t('import_reason_duplicate_short') || 'already a member')
                        : err_row.code === 'NO_PLAN_MATCH' ? (t('import_reason_no_plan_short') || 'no plan matched')
                        : err_row.code === 'NO_BRANCH_MATCH' ? (t('import_reason_no_branch_short') || 'no branch matched')
                        : (t('row') || 'Row')}
                    </span>{' '}
                    {t('row')} {err_row.row}: {err_row.reason}
                  </div>
                ))}
              </div>
            </div>
          )}
          <button
            onClick={() => router.push('/members')}
            style={{
              width: '100%',
              padding: '1rem',
              background: 'var(--brand)',
              border: 'none',
              borderRadius: '8px',
              color: 'white',
              fontWeight: 700,
              cursor: 'pointer',
              fontSize: '1rem',
            }}>
            {t('view_members_btn')} ←
          </button>
        </div>
      )}
    </div>
  );
}
