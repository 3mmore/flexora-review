/**
 * FLEXORA Gym OS
 * © 2024 Ammar Allam. All rights reserved.
 * Unauthorized copying, distribution, or modification of this software
 * is strictly prohibited without written permission from the owner.
 * Contact: FLEXORA support
 */
'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import Shell from '@/components/Shell';
import { api, auth } from '@/lib/api';
import { useTranslation } from '@/lib/i18n';
import { localizePlanName, planOptionLabel } from '@/lib/plan-label';
import { ActionCenter, FeedbackLayer, InsightCard, InsightLayer, ProductPage, SmartAction, SmartTable } from '@/components/ProductOS';
import { Card } from '@/components/ui/Card';
import { EmptyState, Skeleton } from '@/components/ui/States';
import { Icon } from '@/components/brand/Icon';
import { safeErrorMessage } from '@/lib/safe-error';
// PACK 2, item 3: dates the operator just chose or is about to buy are shown
// dd/mm/yyyy (the agreed format), not raw ISO — and never bidi-reordered.
import { formatDate } from '@/lib/dates';
import { useBranchScope } from '@/lib/branch-scope';
import { ModalPortal } from '@/components/ModalPortal';

interface Member {
  id: string;
  name: string;
  mobile: string;
  vip: boolean;
  status: string;
  branchId?: string;
  planId?: string;
  frozen?: boolean;
  expiry?: string;
  invitationSlots?: number;
  maxFreezes?: number;
  freezeDaysLeft?: number;
  sessionsLeft?: number;
  plan?: { name: string; type: string; price: number };
  lastVisit?: string;
  notes?: string;
  createdAt?: string;
  updatedAt?: string;
  attendance?: { id: string; at: string; method: string; branch?: { name: string } }[];
  registeredBy?: { name: string };
  lastRenewedBy?: { name: string };
}

interface Plan {
  id: string;
  name: string;
  price: number;
  // PACK 2, item 3: needed to preview the end date of a period before it is
  // sold. Both are already returned by GET /plans.
  type?: string;
  days?: number | null;
}

interface Branch {
  id: string;
  name: string;
}

export default function Members() {
  const { t, lang } = useTranslation();
  const [data, setData] = useState<{ items: Member[], total: number }>({ items: [], total: 0 });
  const [plans, setPlans] = useState<Plan[]>([]);
  // ROUND 13 (Phase 1): shown when GET /plans fails (e.g. 403) so the empty
  // plan picker is explained instead of silently breaking add/renew.
  const [plansErr, setPlansErr] = useState('');
  const [branches, setBranches] = useState<Branch[]>([]);
  const [user, setUser] = useState<any>(null);
  // PHASE 4: OWNER/MANAGER keep the branch picker; every other role is pinned
  // to their own branch and never sees a picker at all.
  const scope = useBranchScope();
  const [q, setQ] = useState('');
  const [filterBranchId, setFilterBranchId] = useState('');
  // FIX (round 8): members page must REQUIRE a branch selection before showing
  // any data. `branchChosen` tracks whether the owner has explicitly picked a
  // branch (or explicitly chosen "all branches"). Until then, no member list
  // is loaded or displayed — just a clear branch picker prompt.
  const [branchChosen, setBranchChosen] = useState(false);
  const [branchesLoaded, setBranchesLoaded] = useState(false);
  const [form, setForm] = useState<Partial<Member & { gender: string; planId: string; branchId: string; invitationSlots: number }> | null>(null);

  // Pack 2, item 2: the product links to /members?action=new from Home, from the
  // dashboard and from the runtime action engine, but this page never read it, so
  // the primary "add a member" action landed on an unfiltered list with nothing
  // open. Read it once, after the plans have arrived (the form needs a planId).
  const searchParams = useSearchParams();
  const wantsNewMember = searchParams?.get('action') === 'new';
  // The member detail screen is a modal with no URL of its own, so on a phone it
  // could not be bookmarked, shared, or restored after the browser drops the tab.
  // /members?member=<id> opens it, from the same data the list already loaded.
  const wantsMemberId = searchParams?.get('member');
  const openNewMemberOnce = useRef(false);
  const [renewingMemberId, setRenewingMemberId] = useState<string | null>(null);
  const [renewPlanId, setRenewPlanId] = useState<string>('');
  const [paymentStep, setPaymentStep] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState('CASH');
  const [paymentAmount, setPaymentAmount] = useState(0);
  const [paymentBusy, setPaymentBusy] = useState(false);
  // PACK 2, item 3: the day the membership begins. Empty = today (the API's
  // default), so an operator who ignores the field gets the old behaviour.
  const [startDate, setStartDate] = useState<string>('');
  const [startDateReason, setStartDateReason] = useState<string>('');
  // Renewal: which of the three choices was made, and the chosen date.
  const [renewMode, setRenewMode] = useState<'TODAY' | 'FROM_EXPIRY' | 'CUSTOM'>('TODAY');
  const [renewCustomDate, setRenewCustomDate] = useState<string>('');
  /**
   * ROUND 14 (security review, PHASE K4): a PENDING_PAYMENT member is not
   * being renewed — it is being ACTIVATED for the first time. That path uses
   * the single-transaction activate endpoint (payment + activation together),
   * instead of pay-then-renew.
   */
  const [activatingPending, setActivatingPending] = useState(false);
  const [err, setErr] = useState('');
  const [measMember, setMeasMember] = useState<Member | null>(null);
  const [meas, setMeas] = useState<Record<string, any>[]>([]);
  const [measForm, setMeasForm] = useState<any>({});
  const [profile, setProfile] = useState<Member | null>(null);
  const [profileBusy, setProfileBusy] = useState(false);
  const [profileSales, setProfileSales] = useState<Record<string, any>[]>([]);
  const [profileContracts, setProfileContracts] = useState<Record<string, any>[]>([]);
  const [noteDraft, setNoteDraft] = useState('');
  // ROUND 14 (security review, PHASE E): staff-generated one-time access code
  // (the portal fallback login when WhatsApp is not configured).
  // ROUND 14 (security review, PHASE F1): the staff "Renewal requests" screen
  // behind the portal Renew action (members.edit).
  const [renewalRequests, setRenewalRequests] = useState<any[]>([]);
  const [renewConfirm, setRenewConfirm] = useState<any | null>(null);
  const canEditMembers = (user?.permissions || []).includes('members.edit');
  async function loadRenewalRequests() {
    if (!canEditMembers) return;
    try { setRenewalRequests(await api<any[]>('/members/renewal-requests?status=PENDING')); } catch { /* ignore */ }
  }
  async function confirmRenewalRequest(req: any) {
    // the front-desk payment step for this request, then the normal paid
    // renewal flow (the only thing that extends the membership)
    setRenewConfirm(req);
    setRenewingMemberId(req.member.id);
    setRenewPlanId(req.plan.id);
    setPaymentAmount(Number(req.amount || req.plan.price || 0));
    setPaymentStep(true);
  }
  async function cancelRenewalRequest(req: any) {
    if (!confirm(t('cancel_renewal_request') || 'Cancel this renewal request?')) return;
    try {
      await api(`/members/renewal-requests/${req.id}/cancel`, { method: 'POST' });
      loadRenewalRequests();
    } catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }
  const [accessCodeFor, setAccessCodeFor] = useState<Member | null>(null);
  const [accessCode, setAccessCode] = useState<{ code: string; expiresAt: string; member: { name: string } } | null>(null);
  const [accessCodeBusy, setAccessCodeBusy] = useState(false);

  const [busy, setBusy] = useState(false);
  const [success, setSuccess] = useState('');

  async function openMeasurements(m: Member) {
    setMeasMember(m); setMeas([]); setMeasForm({});
    try { setMeas(await api<Record<string, any>[]>(`/measurements/${m.id}`)); } catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }

  async function generateAccessCode(m: Member) {
    setAccessCodeBusy(true); setAccessCode(null); setErr('');
    try {
      const r = await api<{ code: string; expiresAt: string; member: { name: string } }>(`/members/${m.id}/access-code`, { method: 'POST' });
      setAccessCodeFor(m); setAccessCode(r);
    } catch (e: unknown) { setErr(safeErrorMessage(e)); } finally { setAccessCodeBusy(false); }
  }

  async function openMember360(m: Member) {
    setProfileBusy(true);
    setProfile(m);
    setNoteDraft(m.notes || '');
    try {
      const [full, sales, contracts] = await Promise.all([
        api<Member>(`/members/${m.id}`).catch(() => m),
        api<{ items: { memberId: string }[] }>('/sales?limit=200').then((r) => (r.items || []).filter((s) => s.memberId === m.id)).catch(() => []),
        api<Record<string, any>[]>('/contracts').then((rows) => rows.filter((c) => c.memberId === m.id)).catch(() => []),
      ]);
      setProfile(full);
      setNoteDraft(full.notes || '');
      setProfileSales(sales);
      setProfileContracts(contracts);
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    } finally {
      setProfileBusy(false);
    }
  }
  async function addMeasurement(e: React.FormEvent) {
    e.preventDefault();
    if (!measMember) return;
    try {
      await api(`/measurements/${measMember.id}`, { method: 'POST', body: JSON.stringify(measForm) });
      setMeas(await api<Record<string, any>[]>(`/measurements/${measMember.id}`)); setMeasForm({});
    } catch (e: unknown) { alert((e as Error).message); }
  }
  // Simple SVG dual-line chart (weight + body fat) — no extra deps.
  function chart(rows: { weight?: number; bodyFat?: number }[]) {
    const pts = rows.filter((r) => r.weight != null || r.bodyFat != null);
    if (pts.length < 1) return <div className="text-[var(--muted)] text-sm">—</div>;
    const W = 320, H = 120, pad = 24;
    const xs = (i: number) => pad + (i * (W - pad * 2)) / Math.max(pts.length - 1, 1);
    const series = (key: 'weight' | 'bodyFat', color: string) => {
      const vals = pts.map((p) => (p[key] != null ? Number(p[key]) : null));
      const nums = vals.filter((v): v is number => v != null);
      if (!nums.length) return null;
      const max = Math.max(...nums), min = Math.min(...nums);
      const ys = (v: number) => H - pad - ((v - min) / (max - min || 1)) * (H - pad * 2);
      const d = vals.map((v, i) => (v == null ? '' : `${i === 0 || vals[i - 1] == null ? 'M' : 'L'}${xs(i).toFixed(1)},${ys(v).toFixed(1)}`)).join(' ');
      return <path d={d} fill="none" stroke={color} strokeWidth={2} />;
    };
    return (
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full">
        {series('weight', '#22d3a8')}
        {series('bodyFat', '#0ea5e9')}
      </svg>
    );
  }

  const load = useCallback(() => {
    loadRenewalRequests();
    // Only fetch members when a branch has been explicitly chosen.
    // When branchChosen is true but filterBranchId is '' it means the owner
    // explicitly picked "all branches"; when filterBranchId is set it's a
    // specific branch. Either way, only load after the explicit choice.
    if (!branchChosen) return;
    // PHASE 4: a restricted user must not send a branch parameter at all —
    // the API pins the branch itself and would reject a mismatching value.
    const branchParam = scope.unrestricted && filterBranchId ? `&branchId=${encodeURIComponent(filterBranchId)}` : '';
    api<any>(`/members?q=${encodeURIComponent(q)}&limit=50${branchParam}`).then(setData).catch((e: unknown) => setErr(safeErrorMessage(e)));
  }, [q, filterBranchId, branchChosen, scope.unrestricted]);
  // Open a member's detail when the URL names one, once the rows are loaded.
  useEffect(() => {
    if (!wantsMemberId || profile) return;
    // The row may not be on the page the list happened to load (the list is
    // paged and its order is the API's), so fall back to the member endpoint
    // rather than silently opening nothing.
    const found = data.items.find((m) => m.id === wantsMemberId);
    if (found) {
      void openMember360(found);
      return;
    }
    if (data.items.length === 0) return; // wait for the first page to land
    api<Member>(`/members/${wantsMemberId}`)
      .then((m) => m && openMember360(m))
      .catch(() => setErr(t('could_not_load')));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [wantsMemberId, data.items]);

  // Open the create form when the URL asks for it. Runs once; a plan must be
  // known first because the form is created with one.
  useEffect(() => {
    if (!wantsNewMember || openNewMemberOnce.current || !plans.length) return;
    openNewMemberOnce.current = true;
    setForm({ gender: 'MALE', planId: plans[0]?.id, invitationSlots: 2, ...(scope.unrestricted ? {} : { branchId: scope.branchId || '' }) } as never);
    setPaymentStep(false);
    setErr('');
  }, [wantsNewMember, plans, scope]);

  useEffect(() => {
    // Always load branches + plans + user on mount.
    // ROUND 13 (Phase 1): a failed /plans load must be VISIBLE — the plan
    // picker in the add/renew modals would otherwise silently render empty
    // and "add member" would fail with a confusing "plan required" error.
    api<Plan[]>('/plans')
      .then(setPlans)
      .catch((e: unknown) => setPlansErr(safeErrorMessage(e) || 'Failed to load plans'));
    auth.me().then(setUser);
    api<any>('/branches').then(res => {
      const list = Array.isArray(res) ? res : (res.items || []);
      setBranches(list);
      setBranchesLoaded(true);
      // If there's exactly one branch, auto-select it so the owner isn't
      // forced to click through for a trivial single-branch gym.
      if (list.length === 1) {
        setFilterBranchId(list[0].id);
        setBranchChosen(true);
      }
    });
  }, []);
  // PHASE 4: a restricted staff member has nothing to choose — the API only
  // ever returns their own branch, so select it and skip the picker screen.
  useEffect(() => {
    if (scope.loading || scope.unrestricted) return;
    setFilterBranchId(scope.branchId || '');
    setBranchChosen(true);
    setBranchesLoaded(true);
  }, [scope.loading, scope.unrestricted, scope.branchId]);
  useEffect(() => {
    // Only load members after the owner has explicitly chosen a branch.
    if (branchChosen) load();
  }, [load, branchChosen]);

  async function save(e: React.FormEvent) {
    e.preventDefault(); setErr('');
    // A renewal session has no `form` — only renewingMemberId is set — so the
    // guard must allow that path too. (Previously `if (!form) return;` made
    // "confirm payment" on the renew modal a silent no-op: no request, no
    // error, no success — "clicking renew does nothing".)
    if (!form && !renewingMemberId) return;

    // If editing, skip payment step (form is NULL for renewals — must be `?.`)
    if (form?.id) {
      setPaymentBusy(true);
      try {
        // FIX (member edits were 400ing): the previous payload always included
        // invitationSlots (not a field of UpdateMemberDto — "property
        // invitationSlots should not exist") and the list-derived lowercase
        // status ("status must be one of ACTIVE, EXPIRED, …"). Only send fields
        // UpdateMemberDto accepts. `status` is never sent: the API's list
        // returns a DERIVED status ('active'/'expired'/'soon'/'frozen'), which
        // is not the stored enum and cannot be round-tripped — membership
        // state is driven by the plan/expiry/frozen fields, not this column.
        const patchBody: Record<string, unknown> = {};
        if (typeof form.name === 'string' && form.name.trim()) patchBody.name = form.name.trim();
        if (typeof form.mobile === 'string' && form.mobile.trim()) patchBody.mobile = form.mobile.trim();
        if (form.gender === 'MALE' || form.gender === 'FEMALE') patchBody.gender = form.gender;
        const email = (form as any).email;
        if (typeof email === 'string' && email.trim()) patchBody.email = email.trim();
        if (form.planId) patchBody.planId = form.planId;
        if (form.branchId) patchBody.branchId = form.branchId;
        if (typeof (form as any).notes === 'string') patchBody.notes = (form as any).notes;
        if (typeof form.vip === 'boolean') patchBody.vip = form.vip;
        if (typeof form.frozen === 'boolean') patchBody.frozen = form.frozen;
        await api(`/members/${form.id}`, { method: 'PATCH', body: JSON.stringify(patchBody) });
        setForm(null);
        setSuccess(t('success') || 'Updated successfully');
        setTimeout(() => setSuccess(''), 3000);
        load();
        return;
      } catch (e: unknown) {
        setErr(safeErrorMessage(e));
        return;
      } finally {
        setPaymentBusy(false);
      }
    }

    // Step 1: Collect member details, then show payment step
    // (renewals have no `form`; they go straight to the payment step below)
    if (!paymentStep && form) {
      const nameParts = (form.name || '').trim().split(/\s+/);
      if (nameParts.length < 3) { setErr(t('name_3_parts_required') || 'Full name must contain at least 3 parts (First Middle Last)'); return; }
      if (!form.mobile || !/^01[0125]\d{8}$/.test(form.mobile)) { setErr(t('invalid_mobile') || 'Please enter a valid Egyptian mobile number'); return; }
      if (!form.planId) { setErr(t('required_field') || 'Plan is required'); return; }
      const selectedPlan = plans.find((p) => p.id === form.planId);
      setPaymentAmount(selectedPlan?.price || 0);
      setPaymentStep(true);
      return;
    }
    // Step 2: Process payment, then create/renew member
    setPaymentBusy(true);
    try {
      if (renewingMemberId) {
        // ROUND 14 (security review, PHASE K4): first activation of a pending
        // registration — ONE call, ONE transaction (payment + activation).
        if (activatingPending) {
          await api(`/members/${renewingMemberId}/activate`, {
            method: 'POST',
            body: JSON.stringify({
              amount: paymentAmount, method: paymentMethod,
              // item 3: only send a date when one was chosen, so "no choice"
              // keeps meaning TODAY on the server too.
              startDate: startDate && startDate !== todayIso() ? startDate : undefined,
              startDateReason: startDateReason || undefined,
            }),
          });
          setRenewingMemberId(null);
          setRenewPlanId('');
          setActivatingPending(false);
          setStartDate('');
          setStartDateReason('');
          setPaymentStep(false);
          setSuccess(t('success') || 'Operation completed successfully');
          setTimeout(() => setSuccess(''), 3000);
          load();
          return;
        }
        // Renewal flow — ROUND 14 (security review, PHASE I1 + J2): the
        // payment is recorded FOR the member being renewed (a membership
        // payment is always bound to the member it was taken for).
        const res = await api<{ payment: { id: string } }>('/payments/manual', {
          method: 'POST',
          body: JSON.stringify({
            amount: paymentAmount,
            method: paymentMethod,
            memberName: profile?.name || undefined,
            memberId: renewingMemberId,
          }),
        });
        const renewed = await api<Member>(`/members/${renewingMemberId}/renew`, {
          method: 'POST',
          body: JSON.stringify({
            paymentId: res.payment.id,
            planId: renewPlanId || undefined,
            // item 3: the three modes. TODAY is the default and matches the
            // server's default, so an old build keeps working.
            mode: renewMode,
            startDate: renewMode === 'CUSTOM' && renewCustomDate && renewCustomDate !== todayIso()
              ? renewCustomDate : undefined,
            startDateReason: renewMode === 'CUSTOM' ? startDateReason || undefined : undefined,
          }),
        });
        // ROUND 14 (Phase F1): if this renewal was started from a portal
        // renewal request, confirm it (the only extension path) with the payment
        if (renewConfirm) {
          await api(`/members/renewal-requests/${renewConfirm.id}/confirm`, {
            method: 'POST',
            body: JSON.stringify({ paymentId: res.payment.id }),
          }).catch(() => {});
          setRenewConfirm(null);
        }
        if (profile?.id === renewingMemberId) setProfile({ ...profile, ...renewed });
        setRenewingMemberId(null);
        setRenewPlanId('');
        setRenewMode('TODAY');
        setRenewCustomDate('');
        setStartDateReason('');
      } else {
        // Creation flow — ROUND 14 (security review, PHASE K4): register +
        // pay + activate in ONE request and ONE transaction.
        //
        // It used to be three calls (POST /members → /payments/manual →
        // /members/:id/renew). A failure between them left real damage behind:
        // a registered member with no payment (unpaid, and the phone number is
        // now taken so the next attempt fails as a duplicate), or a payment
        // that bought nothing. The single endpoint commits all three or none.
        // `POST /members` (register only, pay later) stays available.
        await api('/members/register-and-activate', {
          method: 'POST',
          body: JSON.stringify({
            name: form?.name,
            mobile: form?.mobile,
            gender: form?.gender,
            planId: form?.planId,
            branchId: form?.branchId || undefined,
            invitationSlots: form?.invitationSlots,
            amount: paymentAmount,
            method: paymentMethod,
            // item 3: the chosen start date (today = the old behaviour, so it is
            // not sent at all).
            startDate: startDate && startDate !== todayIso() ? startDate : undefined,
            startDateReason: startDateReason || undefined,
          }),
        });
        setForm(null);
        setStartDate('');
        setStartDateReason('');
      }

      setPaymentStep(false);
      setSuccess(t('success') || 'Operation completed successfully');
      setQ(''); 
      setTimeout(() => setSuccess(''), 3000);
      load();
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
      setPaymentStep(false);
    } finally {
      setPaymentBusy(false);
    }
  }
  async function startRenew(m: Member) {
    setRenewingMemberId(m.id);
    setRenewPlanId(m.planId || '');
    // A renewal defaults to TODAY, which is exactly what the button did before
    // item 3; the other two choices are opt-in.
    setRenewMode('TODAY');
    setRenewCustomDate('');
    setStartDate('');
    setPaymentAmount(m.plan?.price || 0);
    // PHASE K4: a pending registration is activated (one transaction), a live
    // or expired membership is renewed.
    setActivatingPending(m.status === 'pending');
    setPaymentStep(true);
  }
  async function saveNote() {
    if (!profile) return;
    const updated = await api<Member>(`/members/${profile.id}`, { method: 'PATCH', body: JSON.stringify({ notes: noteDraft }) });
    setProfile({ ...profile, ...updated, notes: noteDraft });
    load();
  }
  async function del(id: string) { if (confirm(t('confirm_delete'))) { await api(`/members/${id}`, { method: 'DELETE' }); load(); } }

  /**
   * PACK 2, item 3 — the calendar facts the dialog shows BEFORE the operator
   * commits. The server decides; this only previews it, in the same Cairo
   * calendar the server uses (a phone in Egypt is already on that calendar, so
   * local midnight is Cairo midnight; the API is the authority either way).
   */
  const todayIso = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };
  const addDaysIso = (iso: string, days: number) => {
    const d = new Date(`${iso}T00:00:00`);
    d.setDate(d.getDate() + days);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };
  const shownStartDate = () => startDate || todayIso();
  /** The plan the dialog is about, for the expiry preview. */
  const dialogPlan = () => plans.find((p) => p.id === (renewingMemberId ? renewPlanId : form?.planId)) || null;
  /** Where the renewal period begins, for the preview (mirrors the API's modes). */
  const renewalPreviewStart = () => {
    if (renewMode === 'CUSTOM' && renewCustomDate) return renewCustomDate;
    if (renewMode === 'FROM_EXPIRY') {
      const exp = profile?.id === renewingMemberId ? profile.expiry : null;
      if (exp && +new Date(exp) > Date.now()) return String(exp).slice(0, 10);
    }
    return todayIso();
  };
  const renewalPreviewExpiry = () => {
    const pl = dialogPlan();
    if (!pl || pl.type !== 'TIME' || !pl.days) return null;
    return addDaysIso(renewalPreviewStart(), pl.days);
  };
  /** "الاشتراك منتهي بالفعل": a past start whose plan is already over. */
  const startIsAlreadyOver = () => {
    if (!startDate || startDate >= todayIso()) return false;
    const pl = dialogPlan();
    if (!pl || pl.type !== 'TIME' || !pl.days) return false;
    return addDaysIso(startDate, pl.days) < todayIso();
  };
  const startIsFuture = () => startDate > todayIso();

  const badgeClass = (s: string) => (({
    active: 'badge badge-active', soon: 'badge badge-soon', expired: 'badge badge-expired', frozen: 'badge badge-frozen',
    // ROUND 14 (PHASE J2): registered but not paid for yet — shows as
    // "Pending" and cannot check in until the membership is activated.
    pending: 'badge badge-soon',
    // PACK 2, item 3: paid, valid, and not begun — the desk must see it.
    not_started: 'badge badge-frozen',
  } as Record<string, string>)[s] || 'badge');

  const profileAttendance = profile?.attendance || [];
  const lifetimeValue = profileSales.reduce((sum, sale) => sum + Number(sale.total || 0), 0);
  const daysSinceLastVisit = profile?.lastVisit ? Math.max(0, Math.round((Date.now() - +new Date(profile.lastVisit)) / 86400000)) : null;
  const daysToExpiry = profile?.expiry ? Math.round((+new Date(profile.expiry) - Date.now()) / 86400000) : null;
  const riskScore = profile ? Math.min(100, Math.max(0,
    (profile.status === 'expired' ? 45 : profile.status === 'soon' ? 24 : 0) +
    (daysSinceLastVisit != null && daysSinceLastVisit > 14 ? 28 : daysSinceLastVisit != null && daysSinceLastVisit > 7 ? 14 : 0) +
    (daysToExpiry != null && daysToExpiry <= 7 ? 20 : 0) +
    (profile.sessionsLeft != null && profile.sessionsLeft <= 2 ? 16 : 0)
  )) : 0;
  const weeklyFrequency = profileAttendance.length ? Math.min(7, +(profileAttendance.length / 4).toFixed(1)) : 0;
  const timeline = [
    ...profileAttendance.map((a) => ({ id: `att-${a.id}`, at: a.at, type: t('check_in'), title: t('visited_gym') || 'Visited the gym', detail: `${a.branch?.name || t('branch')} · ${a.method}` })),
    ...profileSales.map((s) => ({ id: `sale-${s.id}`, at: s.createdAt, type: t('payment'), title: s.invoiceNo || t('invoice'), detail: `${Number(s.total || 0).toLocaleString()} ${t('currency')}` })),
    ...profileContracts.map((c) => ({ id: `contract-${c.id}`, at: c.signedAt || c.createdAt, type: c.signedAt ? t('contract_signed') || 'Contract signed' : t('contract'), title: c.title, detail: c.contractNo })),
    ...(profile?.notes ? [{ id: 'note-current', at: profile.updatedAt || profile.createdAt, type: t('note') || 'Note', title: t('staff_note') || 'Staff note', detail: profile.notes }] : []),
    ...(profile?.expiry ? [{ id: 'expiry', at: profile.expiry, type: t('renew') || 'Renewal', title: daysToExpiry != null && daysToExpiry < 0 ? t('membership_expired') || 'Membership expired' : t('membership_expiry') || 'Membership expiry', detail: profile.plan?.name ? localizePlanName(profile.plan.name, lang) : t('plan') }] : []),
  ].sort((a, b) => +(new Date(b.at || 0)) - +(new Date(a.at || 0)));

  return (
    <Shell>
      <ProductPage
        eyebrow={t('member_os')}
        title={t('members')}
        narrative={t('members_description')}
        primaryAction={{ label: t('add_member'), icon: 'plus', onClick: () => { setForm({ gender: 'MALE', planId: plans[0]?.id, invitationSlots: 2 }); setPaymentStep(false); setErr(''); } }}
        secondaryAction={{ label: t('review_renewals'), href: '/members?status=expired', icon: 'bell' }}
      >
        <InsightLayer>
          <InsightCard label={t('members')} value={data.total || data.items.length || 0} detail={t('total_base')} icon="users" />
          <InsightCard label={t('active')} value={data.items.filter((m) => m.status === 'active').length} detail={t('revenue_positive')} icon="shield" tone="good" />
          <InsightCard label={t('at_risk')} value={data.items.filter((m) => ['soon', 'expired'].includes(m.status)).length} detail={t('need_attention')} icon="bell" tone="warning" />
          <InsightCard label={t('vip_members')} value={data.items.filter((m) => m.vip).length} detail={t('vip_accounts')} icon="sparkle" />
        </InsightLayer>

        <ActionCenter title={t('member_action_center')}>
          <SmartAction title={t('add_member')} detail={t('register_member_desc')} icon="plus" onClick={() => {
            // PHASE 4: restricted staff can only ever create members in their
            // own branch, so the branch is pre-filled instead of being asked.
            setForm({ gender: 'MALE', planId: plans[0]?.id, invitationSlots: 2, ...(scope.unrestricted ? {} : { branchId: scope.branchId || '' }) } as any);
            setPaymentStep(false); setErr('');
          }} />
          <SmartAction title={t('search_base')} detail={t('search_member_desc')} icon="search" onClick={() => document.getElementById('member-search')?.focus()} />
          <SmartAction title={t('open_ai_retention')} detail={t('find_churn_risks')} icon="sparkle" href="/ai" />
          <SmartAction
            title={t('import_excel') || "Import from Excel"}
            detail={t('import_members_ai') || "Import members from any legacy system (Excel/CSV) with AI assistance"}
            icon="plus"
            href="/members/import"
          />
        </ActionCenter>

        {err && <FeedbackLayer type="danger" title={t('member_workflow_attention')} detail={err} />}
        {success && <FeedbackLayer type="success" title={t('success')} detail={success} />}
        {plansErr && (
          <FeedbackLayer
            type="warning"
            title={t('plans_load_failed_title') || 'Plans could not be loaded'}
            detail={`${t('plans_load_failed_body') || 'The membership plan list failed to load, so adding or renewing a member is not possible right now.'} (${plansErr})`}
          />
        )}

        {/* FIX (round 8): require explicit branch selection before showing any
            member data. Until the owner picks a branch (or explicitly chooses
            "all branches"), show a clear prompt instead of the member list. */}
        {!branchChosen && branchesLoaded && scope.unrestricted && (
          <div className="card card-static glass w-full max-w-xl mx-auto mt-8 p-8 text-center" style={{ boxShadow: 'var(--shadow-modal)' }}>
            <div className="text-5xl mb-4">🏢</div>
            <h2 className="text-xl font-bold text-white mb-2">{t('select_branch_to_view') || 'Select a branch to view members'}</h2>
            <p className="text-sm text-[var(--silver-dim)] mb-6">{t('branch_selection_help') || 'Members are organized by branch. Choose a specific branch to see its members, or view all branches together.'}</p>
            {branches.length === 0 ? (
              <div className="space-y-4">
                <p className="text-sm text-[var(--warning)]">{t('no_branches_yet') || 'No branches have been created yet.'}</p>
                <a href="/branches" className="btn btn-primary inline-block">{t('create_first_branch') || 'Create your first branch'}</a>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {branches.map((b) => (
                    <button
                      key={b.id}
                      className="card p-4 text-start hover:border-[var(--cyan)] hover:bg-[var(--primary-soft)] transition-all cursor-pointer border border-[var(--border)]"
                      onClick={() => { setFilterBranchId(b.id); setBranchChosen(true); }}
                    >
                      <div className="font-bold text-white">{b.name}</div>
                      <div className="text-xs text-[var(--silver-dim)] mt-1">{t('view_members') || 'View members'}</div>
                    </button>
                  ))}
                </div>
                {branches.length > 1 && (
                  <button
                    className="btn btn-ghost w-full mt-2 text-sm"
                    onClick={() => { setFilterBranchId(''); setBranchChosen(true); }}
                  >
                    {t('view_all_branches') || 'View all branches together'} →
                  </button>
                )}
              </div>
            )}
          </div>
        )}

        {branchChosen && (
          <>
            <div className="flex gap-3 flex-wrap items-center">
              <input id="member-search" className="input max-w-sm" placeholder={t('search_members')} value={q} onChange={(e) => setQ(e.target.value)} />
              {scope.unrestricted ? (
                <>
                  <select className="input max-w-[200px]" value={filterBranchId} onChange={(e) => setFilterBranchId(e.target.value)} aria-label={t('filter_branch') || 'Filter by branch'}>
                    <option value="">{t('all_branches') || 'All branches'}</option>
                    {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
                  </select>
                  <span className="text-xs text-[var(--silver-dim)]">
                    {filterBranchId
                      ? `${t('branch') || 'Branch'}: ${branches.find(b => b.id === filterBranchId)?.name || ''}`
                      : (t('showing_all_branches') || 'Showing all branches')}
                  </span>
                </>
              ) : (
                /* PHASE 4: restricted roles get no picker — just the branch they
                   are pinned to, stated plainly. */
                <span className="badge badge-active" data-testid="branch-locked">
                  {t('branch') || 'Branch'}: {scope.branchName || branches.find((b) => b.id === scope.branchId)?.name || '—'}
                </span>
              )}
            </div>

            {canEditMembers && renewalRequests.length > 0 && (
              <div className="card glass p-4 mb-4" data-testid="renewal-requests-card">
                <div className="flex items-center justify-between mb-2">
                  <h2 className="font-bold">{t('renewal_requests') || 'Renewal requests'}</h2>
                  <span className="text-xs text-[var(--silver-dim)]">{renewalRequests.length}</span>
                </div>
                <p className="text-xs text-[var(--silver-dim)] mb-3">{t('renewal_requests_desc') || 'Members asked to renew from the member app. Confirm with a payment to extend the membership.'}</p>
                <div className="grid gap-2">
                  {renewalRequests.map((req: any) => (
                    <div key={req.id} className="flex items-center justify-between gap-3 rounded-lg border border-[var(--border)] px-3 py-2 text-sm" data-testid={`renewal-request-${req.id}`}>
                      <div className="min-w-0">
                        <b className="block truncate">{req.member?.name}</b>
                        <span className="text-xs text-[var(--silver-dim)]">{req.plan?.name} · {Number(req.amount).toLocaleString()} {t('currency')} · {formatDate(req.requestedAt)}</span>
                      </div>
                      <span className="row-actions inline-flex gap-2 shrink-0">
                        <button className="btn-primary btn-sm" data-testid={`renewal-confirm-${req.id}`} onClick={() => confirmRenewalRequest(req)}>{t('confirm_renewal') || 'Confirm'}</button>
                        <button className="btn-ghost btn-sm" data-testid={`renewal-cancel-${req.id}`} onClick={() => cancelRenewalRequest(req)}>{t('cancel')}</button>
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
            <SmartTable
              columns={[t('name'), t('mobile'), t('plan'), t('status'), t('remaining'), t('actions')]}
              rows={data.items}
              emptyTitle={t('member_base_starts')}
              emptyDescription={t('add_first_member')}
              renderRow={(m: Member) => (
                <tr key={m.id}>
                  <td>
                    <button className="member-name-link" onClick={() => openMember360(m)}>
                      {m.name}{m.vip && <span className="text-[var(--cyan)] ms-2">★</span>}
                    </button>
                  </td>
                  <td className="text-mono" dir="ltr">{m.mobile}</td>
                  <td>{m.plan?.name ? localizePlanName(m.plan.name, lang) : '—'}</td>
                  <td><span className={badgeClass(m.status)}>{t('st_' + m.status)}</span></td>
                  <td>{m.plan?.type === 'SESSION' ? `${m.sessionsLeft} ${t('sessions')}` : (m.expiry ? formatDate(m.expiry) : '—')}</td>
                  <td className="whitespace-nowrap">
                    <span className="row-actions inline-flex gap-2">
                      <button className="btn-ghost btn-sm" onClick={() => setForm(m)} title={t('edit')}>✏️</button>
                      <button className="btn-ghost btn-sm" onClick={() => startRenew(m)}>{t('renew')}</button>
                      <button className="btn-ghost btn-sm" onClick={() => openMeasurements(m)} title={t('record_measurement')}>📏</button>
                      <button className="btn-danger btn-sm" onClick={() => del(m.id)}>{t('delete')}</button>
                    </span>
                  </td>
                </tr>
              )}
            />
          </>
        )}
      </ProductPage>

      {(form || renewingMemberId) && (
        <ModalPortal>
        <div className="fixed inset-0 bg-black/70 grid place-items-center p-5 z-50" onClick={() => { setForm(null); setPaymentStep(false); setRenewingMemberId(null); setRenewPlanId(''); setStartDate(''); setStartDateReason(''); setRenewMode('TODAY'); setRenewCustomDate(''); }}>
          <form onClick={(e) => e.stopPropagation()} onSubmit={save} className="card card-static glass w-full max-w-lg" style={{ boxShadow: 'var(--shadow-modal)' }}>
            <h3 className="text-title text-white mb-4">{paymentStep ? t("confirm_payment") : (form?.id ? t("edit") : t("new_member"))}</h3>

            {/* Errors must render INSIDE the modal: the page-level FeedbackLayer
                (top of ProductPage) sits behind this z-50 backdrop, so a limit
                error reached during add-member would be invisible. */}
            {err && (
              <div className="mb-3 rounded-lg border border-red-400/40 bg-red-500/15 text-red-200 text-sm p-3" role="alert">{err}</div>
            )}

            {!paymentStep && form ? (
              <>
                <div className="grid grid-cols-2 gap-3">
                  <div className="col-span-2">
                    <label className="text-label text-[var(--silver-dim)] mb-1 block">{t("full_name")}</label>
                    <input className="input w-full" placeholder={t("full_name")} value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
                  </div>
                  <div>
                    <label className="text-label text-[var(--silver-dim)] mb-1 block">{t("mobile")}</label>
                    <input className="input w-full" placeholder="01XXXXXXXXX" dir="ltr" maxLength={11} value={form.mobile || ''} onChange={(e) => setForm({ ...form, mobile: e.target.value })} required />
                  </div>
                  <div>
                    <label className="text-label text-[var(--silver-dim)] mb-1 block">{t("gender")}</label>
                    <select className="input w-full" value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })}>
                      <option value="MALE">{t("male")}</option><option value="FEMALE">{t("female")}</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-label text-[var(--silver-dim)] mb-1 block">{t("plan")}</label>
                    <select className="input w-full" value={form.planId} onChange={(e) => setForm({ ...form, planId: e.target.value })} required>
                      <option value="" disabled>{t("select_plan")}</option>
                      {plans.map((p) => <option key={p.id} value={p.id}>{planOptionLabel(p, lang, t)}</option>)}
                    </select>
                  </div>
                  {/* Point 3: Branch Selection */}
                  {scope.unrestricted && (
                    <div>
                      <label className="text-label text-[var(--silver-dim)] mb-1 block">{t("branch")}</label>
                      <select className="input w-full" value={form.branchId || ''} onChange={(e) => setForm({ ...form, branchId: e.target.value || undefined })}>
                        <option value="">{t("select_branch")}</option>
                        {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
                      </select>
                    </div>
                  )}
                  {/* PACK 2, item 3: the day the membership begins. Empty means
                      today, so doing nothing keeps the old behaviour. Not shown on
                      an EDIT: UpdateMemberDto has no start date, and changing it on
                      a live membership is a renewal decision, not a typo fix. */}
                  <div className="col-span-2" hidden={!!form.id}>
                    <label className="text-label text-[var(--silver-dim)] mb-1 block" htmlFor="startDate">{t("start_date")}</label>
                    {/* The value is never empty on purpose: an empty native date
                        input paints the BROWSER's placeholder, which on an
                        English-locale phone is "mm/dd/yyyy" — Latin text inside
                        an Arabic screen, and exactly the kind of leak item 1
                        forbids. Showing today's date (the default anyway) means
                        the field only ever paints digits and slashes. */}
                    <input id="startDate" className="input w-full" type="date" dir="ltr" lang="ar-EG"
                      value={startDate || todayIso()} disabled={!!form.id}
                      max={addDaysIso(todayIso(), 90)} min={addDaysIso(todayIso(), -365)}
                      onChange={(e) => setStartDate(e.target.value || todayIso())} />
                    <p className="text-xs text-[var(--silver-dim)] mt-1" data-testid="start-date-shown">
                      {t('start_date')}: <bdi dir="ltr">{formatDate(`${(startDate || todayIso())}T12:00:00`)}</bdi>
                    </p>
                    <p className="text-xs text-[var(--silver-dim)] mt-1">{t("start_date_hint")}</p>
                    {startIsFuture() && (
                      <p className="text-xs mt-1" data-testid="start-date-future" style={{ color: 'var(--warning)' }}>
                        {t("start_date_future_warning")}
                      </p>
                    )}
                    {startIsAlreadyOver() && (
                      <p className="text-xs mt-1" data-testid="start-date-over" style={{ color: 'var(--danger, #ef4444)' }}>
                        {t("start_date_already_over")}
                      </p>
                    )}
                    {startDate && startDate < todayIso() && !startIsAlreadyOver() && (
                      <p className="text-xs text-[var(--silver-dim)] mt-1">{t("start_date_past_info")}</p>
                    )}
                    {(startDate || startDateReason) && (
                      <input className="input w-full mt-2" placeholder={t("start_date_reason")} maxLength={200}
                        value={startDateReason} onChange={(e) => setStartDateReason(e.target.value)} />
                    )}
                  </div>
                  <div className="col-span-2">
                    <label className="text-label text-[var(--silver-dim)] mb-1 block">{t("invitation_slots")}</label>
                    <input className="input w-full" type="number" min={0} max={20} value={form.invitationSlots ?? 2}
                      onChange={(e) => setForm({ ...form, invitationSlots: Number(e.target.value) })} />
                  </div>
                </div>
                <div className="flex gap-2 justify-end mt-4">
                  <button type="button" className="btn-ghost" onClick={() => { setForm(null); setRenewingMemberId(null); setRenewPlanId(''); setStartDate(''); setStartDateReason(''); setRenewMode('TODAY'); setRenewCustomDate(''); }}>{t("cancel")}</button>
                  <button className="btn-primary">{form.id ? t("save") : t("continue")}</button>
                </div>
              </>
            ) : (
              <>
                <div className="grid gap-3">
                  <div>
                    <label className="text-label text-[var(--silver-dim)]">{t("payment_method")}</label>
                    <select className="input mt-1" value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}>
                      <option value="CASH">{t("cash")}</option>
                      <option value="TRANSFER">{t("transfer")}</option>
                      <option value="ONLINE">{t("online")}</option>
                    </select>
                  </div>
                  {renewingMemberId ? (
                    <div>
                      <label className="text-label text-[var(--silver-dim)]">{t("plan")}</label>
                      <select className="input mt-1" value={renewPlanId} onChange={(e) => {
                        const newPlanId = e.target.value;
                        setRenewPlanId(newPlanId);
                        const newPlan = plans.find((p) => p.id === newPlanId);
                        if (newPlan) setPaymentAmount(newPlan.price || 0);
                      }}>
                        {plans.map((p) => <option key={p.id} value={p.id}>{planOptionLabel(p, lang, t)}</option>)}
                      </select>
                      {/* PACK 2, item 3 — WHERE THE NEW PERIOD BEGINS.
                          FROM TODAY is the pre-item-3 behaviour and stays the
                          default, so tapping "renew" twice keeps doing exactly
                          what it did. FROM EXPIRY continues from the day the
                          current period stops (no paid day is lost). */}
                      <fieldset className="mt-3" data-testid="renew-start-modes">
                        <legend className="text-label text-[var(--silver-dim)] mb-1">{t('start_date')}</legend>
                        {([
                          ['TODAY', t('renew_from_today')],
                          ['FROM_EXPIRY', t('renew_from_expiry')],
                          ['CUSTOM', t('renew_custom_date')],
                        ] as const).map(([mode, label]) => (
                          <label key={mode} className="flex items-center gap-2 py-1 text-sm cursor-pointer">
                            <input type="radio" name="renewMode" value={mode} checked={renewMode === mode}
                              onChange={() => setRenewMode(mode)} />
                            <span>{label}</span>
                            {mode === 'FROM_EXPIRY' && profile?.expiry && renewingMemberId === profile.id && (
                              <span className="text-xs text-[var(--silver-dim)]">
                                ({t('current_expiry_label')}: <bdi dir="ltr">{formatDate(profile.expiry)}</bdi>)
                              </span>
                            )}
                          </label>
                        ))}
                        {renewMode === 'CUSTOM' && (
                          <input className="input w-full mt-2" type="date" dir="ltr" lang="ar-EG"
                            value={renewCustomDate || todayIso()}
                            onChange={(e) => setRenewCustomDate(e.target.value || todayIso())}
                            min={addDaysIso(todayIso(), -365)} max={addDaysIso(todayIso(), 90)} />
                        )}
                      </fieldset>
                      {renewalPreviewExpiry() && (
                        <p className="text-sm mt-2" data-testid="renew-expiry-preview">
                          <span className="text-[var(--silver-dim)]">{t('resulting_expiry')}: </span>
                          <strong><bdi dir="ltr">{formatDate(`${renewalPreviewExpiry()}T12:00:00`)}</bdi></strong>
                        </p>
                      )}
                    </div>
                  ) : (
                    <p className="text-xs text-[var(--silver-dim)]">
                      {t("plan")}: {(() => { const pl = plans.find((p) => p.id === (form?.planId || profile?.planId)); return pl ? localizePlanName(pl.name, lang) : '—'; })()} — {plans.find((p) => p.id === (form?.planId || profile?.planId))?.price?.toLocaleString() || 0} {t('currency')}
                    </p>
                  )}
                  <div>
                    <label className="text-label text-[var(--silver-dim)]">{t("amount")}</label>
                    <input className="input mt-1" type="number" min={1} value={paymentAmount}
                      onChange={(e) => setPaymentAmount(Number(e.target.value))} />
                  </div>
                </div>
                <div className="flex gap-2 justify-end mt-4">
                  <button type="button" className="btn-ghost" onClick={() => { setPaymentStep(false); setErr(''); }}>{t("back")}</button>
                  <button className="btn-primary" disabled={paymentBusy}>
                    {paymentBusy ? t("processing") : t("confirm_payment")}
                  </button>
                </div>
              </>
            )}
          </form>
        </div>
        </ModalPortal>
      )}

      {profile && (
        <ModalPortal>
        <div className="member360-shell" role="dialog" aria-modal="true" onClick={() => setProfile(null)}>
          <section className="member360" onClick={(e) => e.stopPropagation()}>
            <header className="member360-hero">
              <div className="member360-avatar" aria-hidden="true">{profile.name?.slice(0, 2).toUpperCase() || 'FX'}</div>
              <div className="member360-title">
                <span className="product-eyebrow">{t('member_profile')}</span>
                <h2>{profile.name}</h2>
                <p>{profile.mobile} · {profile.plan?.name ? localizePlanName(profile.plan.name, lang) : t('no_plan')}</p>
                {(profile.registeredBy?.name || profile.lastRenewedBy?.name) && (
                  <p className="text-xs text-[var(--silver-dim)] mt-1">
                    {profile.registeredBy?.name && <>{t('registered_by')}: {profile.registeredBy.name}</>}
                    {profile.registeredBy?.name && profile.lastRenewedBy?.name && ' · '}
                    {profile.lastRenewedBy?.name && <>{t('last_renewed_by')}: {profile.lastRenewedBy.name}</>}
                  </p>
                )}
                <div className="member360-tags">
                  <span className={badgeClass(profile.status)}>{t('st_' + profile.status)}</span>
                  <span className="risk-indicator" data-level={riskScore > 70 ? 'critical' : riskScore > 40 ? 'high' : 'medium'}>{t('risk')} {riskScore}/100</span>
                  {riskScore < 30 && <span className="opportunity-signal">{t('healthy_relationship')}</span>}
                </div>
                <button className="btn btn-secondary btn-sm mt-3 px-3" onClick={() => { setForm(profile); setProfile(null); }}>
                  ✏️ {t('edit')}
                </button>
              </div>
              <button className="modal-close" onClick={() => setProfile(null)} aria-label={t('close')}>✕</button>
            </header>

            {profileBusy ? <Skeleton lines={10} /> : (
              <>
                <div className="member360-summary">
                  <Card padding="md"><span>{t('expiry')}</span><strong>{profile.expiry ? formatDate(profile.expiry) : '—'}</strong><small>{daysToExpiry == null ? t('no_expiry') : daysToExpiry < 0 ? `${Math.abs(daysToExpiry)} ${t('days_overdue')}` : `${daysToExpiry} ${t('days_remaining_label')}`}</small></Card>
                  <Card padding="md"><span>{t('lifetime_value')}</span><strong>{lifetimeValue.toLocaleString()} {t('currency')}</strong><small>{profileSales.length} {t('payment_events')}</small></Card>
                  <Card padding="md"><span>{t('last_visit')}</span><strong>{profile.lastVisit ? formatDate(profile.lastVisit) : t('never_visited')}</strong><small>{daysSinceLastVisit == null ? t('no_visit_history') : `${daysSinceLastVisit} ${t('day_ago')}`}</small></Card>
                  <Card padding="md"><span>{t('weekly_frequency') || 'Weekly frequency'}</span><strong>{weeklyFrequency}/{t('date')}</strong><small>{profileAttendance.length} {t('recent_checkins')}</small></Card>
                </div>

                <div className="member360-grid">
                  <Card padding="lg" className="member360-panel wide">
                    <div className="product-section-head"><div><h2>{t('member_timeline')}</h2><p>{t('member_history_desc')}</p></div></div>
                    {timeline.length ? <div className="member360-timeline">
                      {timeline.map((item) => <div key={item.id} className="member360-event"><div><b>{item.type}</b><span>{item.title}</span><small>{item.detail}</small></div><time>{item.at ? formatDate(item.at) : '—'}</time></div>)}
                    </div> : <EmptyState icon="bell" title={t('no_member_timeline')} description={t('member_story_desc')} />}
                  </Card>

                  <Card padding="lg" className="member360-panel">
                    <div className="product-section-head"><div><h2>{t('risk_retention')}</h2><p>{t('recovery_prioritized')}</p></div></div>
                    <div className="member360-risk-meter"><i style={{ width: `${riskScore}%` }} /></div>
                    <FeedbackLayer type={riskScore > 60 ? 'warning' : 'info'} title={riskScore > 60 ? t('recovery_recommended') : t('relationship_stable')} detail={riskScore > 60 ? t('prioritize_contact') : t('monitor_attendance')} />
                    <div className="member360-actions">
                      <button className="btn btn-primary" onClick={() => startRenew(profile)}>{t('renew_membership')}</button>
                      <button className="btn btn-secondary" onClick={() => openMeasurements(profile)}>{t('record_measurement')}</button>
                      <a className="btn btn-secondary" href={`/classes?memberId=${profile.id}`}>{t('book_class')}</a>
                      {(user?.permissions || []).includes('members.edit') && (
                        <button className="btn btn-secondary" data-testid="member-access-code-btn" disabled={accessCodeBusy} onClick={() => generateAccessCode(profile)}>
                          🔑 {t('generate_access_code')}
                        </button>
                      )}
                    </div>
                  </Card>

                  <Card padding="lg" className="member360-panel">
                    <div className="product-section-head"><div><h2>{t('payment_center')}</h2><p>{t('revenue_contribution_desc')}</p></div></div>
                    {profileSales.length ? <div className="member360-payments">{profileSales.slice(0, 6).map((s) => <div key={s.id}><span>{s.invoiceNo}</span><b>{Number(s.total || 0).toLocaleString()} {t('currency')}</b></div>)}</div> : <EmptyState icon="coins" title={t('no_payments_yet')} description={t('member_purchases_desc')} />}
                    <a className="btn btn-ghost w-full justify-center mt-3" href={`/pos?memberId=${profile.id}`}>{t('record_payment')}</a>
                  </Card>

                  <Card padding="lg" className="member360-panel">
                    <div className="product-section-head"><div><h2>{t('ai_member_insight')}</h2><p>{t('executive_summary_action')}</p></div><Icon name="sparkle" className="text-[var(--primary)]" size={18} /></div>
                    <p className="text-sm leading-7 text-[var(--silver-dim)]">{riskScore > 60 ? `${profile.name} ${t('shows_pressure') || 'shows renewal pressure. Contact now.'}` : `${profile.name} ${t('appears_stable') || 'appears stable.'}`}</p>
                    <div className="member360-actions mt-4">
                      <a className="btn btn-secondary" href={`/campaigns?memberId=${profile.id}`}>{t('send_message')}</a>
                      <a className="btn btn-secondary" href="/ai">{t('ask_flexora_ai')}</a>
                    </div>
                  </Card>

                  <Card padding="lg" className="member360-panel wide">
                    <div className="product-section-head"><div><h2>{t('notes')}</h2><p>{t('keep_staff_context') || 'Keep staff context visible.'}</p></div></div>
                    <textarea className="input" rows={4} value={noteDraft} onChange={(e) => setNoteDraft(e.target.value)} placeholder={t('add_private_note')} />
                    <div className="flex justify-end mt-3"><button className="btn btn-primary px-4 py-2" onClick={saveNote}>{t('save_note')}</button></div>
                  </Card>
                </div>
              </>
            )}
          </section>
        </div>
        </ModalPortal>
      )}

      {accessCode && accessCodeFor && (
        <ModalPortal>
        <div className="fixed inset-0 bg-black/70 grid place-items-center p-5 z-[70]" onClick={() => { setAccessCode(null); setAccessCodeFor(null); }}>
          <div className="card card-static glass w-full max-w-md p-6 text-center" onClick={(e) => e.stopPropagation()} data-testid="member-access-code-modal">
            <h3 className="text-title text-white mb-1">{t('access_code_modal_title')}</h3>
            <p className="text-xs text-[var(--silver-dim)] mb-4">{t('access_code_for')} <b>{accessCodeFor.name}</b> · {t('access_code_valid_15')}</p>
            <div className="text-4xl font-black tracking-[0.35em] font-mono text-[var(--brand)] select-all" data-testid="member-access-code-value">{accessCode.code}</div>
            <p className="text-[11px] text-[var(--silver-dim)] mt-3">⏱ {new Date(accessCode.expiresAt).toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-US')} · {t('access_code_shown_once')}</p>
            <div className="flex gap-2 justify-center mt-5">
              <button className="btn-primary" data-testid="member-access-code-copy" onClick={() => { navigator.clipboard?.writeText(accessCode.code).catch(() => {}); }}>{t('copy_code')}</button>
              <button className="modal-close" onClick={() => { setAccessCode(null); setAccessCodeFor(null); }} aria-label={t('close')}>✕</button>
            </div>
          </div>
        </div>
        </ModalPortal>
      )}

      {measMember && (
        <ModalPortal>
        <div className="fixed inset-0 bg-black/60 grid place-items-center p-5 z-50" onClick={() => setMeasMember(null)}>
          <div className="card w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center mb-3">
              <h3 className="font-extrabold text-lg flex-1">📏 {measMember.name}</h3>
              <button className="modal-close" onClick={() => setMeasMember(null)} aria-label={t('close')}>✕</button>
            </div>
            <div className="mb-3">{chart(meas)}</div>
            <div className="text-xs text-[var(--muted)] mb-3">
              <span className="text-[#22d3a8]">●</span> {t('weight_kg')} &nbsp;
              <span className="text-[#0ea5e9]">●</span> {t('body_fat_pct')}
            </div>
            <div className="max-h-48 overflow-auto mb-3 text-sm">
              {meas.length ? meas.slice().reverse().map((r) => (
                <div key={r.id} className="p-2 border-t border-[var(--border)]">
                  <div className="flex justify-between mb-1">
                    <span className="font-bold">{formatDate(r.measuredAt)}</span>
                    <span className="text-[var(--silver-dim)] text-xs">{r.recordedBy}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs">
                    {r.weight && <div>{t('weight')}: {r.weight}kg</div>}
                    {r.bodyFat && <div>{t('bodyFat')}: {r.bodyFat}%</div>}
                    {r.muscleMass && <div>{t('muscleMass')}: {r.muscleMass}kg</div>}
                    {r.chest && <div>{t('chest')}: {r.chest}cm</div>}
                    {r.waist && <div>{t('waist')}: {r.waist}cm</div>}
                    {r.hips && <div>{t('hips')}: {r.hips}cm</div>}
                    {r.arms && <div>{t('arms')}: {r.arms}cm</div>}
                  </div>
                  {r.notes && <div className="mt-1 italic text-[var(--silver-muted)] text-[10px]">{r.notes}</div>}
                </div>
              )) : <div className="text-[var(--muted)]">—</div>}
            </div>
            <form onSubmit={addMeasurement} className="grid grid-cols-3 gap-2">
              {[
                { k: 'weight', l: t('weight'), u: 'kg' },
                { k: 'bodyFat', l: t('bodyFat'), u: '%' },
                { k: 'muscleMass', l: t('muscleMass'), u: 'kg' },
                { k: 'chest', l: t('chest'), u: 'cm' },
                { k: 'waist', l: t('waist'), u: 'cm' },
                { k: 'hips', l: t('hips'), u: 'cm' },
                { k: 'arms', l: t('arms'), u: 'cm' },
              ].map(({ k, l, u }) => (
                <div key={k}>
                  <label className="text-[10px] uppercase font-bold text-[var(--silver-dim)] mb-1 block">{l} ({u})</label>
                  <input className="input w-full" type="number" step="0.1" placeholder="0"
                    value={measForm[k] ?? ''} onChange={(e) => setMeasForm({ ...measForm, [k]: e.target.value ? Number(e.target.value) : undefined })} />
                </div>
              ))}
              <div className="col-span-2">
                <label className="text-[10px] uppercase font-bold text-[var(--silver-dim)] mb-1 block">{t('notes')}</label>
                <input className="input w-full" placeholder={t('notes')} value={measForm.notes as any as string || ''} 
                  onChange={(e) => setMeasForm({ ...measForm, notes: e.target.value })} />
              </div>
              <button className="btn justify-center self-end h-[42px]">{t('save')}</button>
            </form>
          </div>
        </div>
        </ModalPortal>
      )}
    </Shell>
  );
}
