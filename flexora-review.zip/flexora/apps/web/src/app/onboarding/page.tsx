'use client';
import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import Shell from '@/components/Shell';
import { Button } from '@/components/ui/Button';
import { api, auth } from '@/lib/api';
import { dispatchBrandRefresh } from '@/context/BrandContext';
import { isAllowedRedirect } from '@/lib/validate-url';
import { useTranslation } from '@/lib/i18n';
import { safeErrorMessage } from '@/lib/safe-error';

const STORAGE_KEY = 'flexora_onboarding_progress';
const governorates = [
  'القاهرة (Cairo)', 'الجيزة (Giza)', 'الإسكندرية (Alexandria)', 'الدقهلية (Dakahlia)',
  'البحر الأحمر (Red Sea)', 'البحيرة (Beheira)', 'الفيوم (Fayyum)', 'الغربية (Gharbia)',
  'الإسماعيلية (Ismailia)', 'المنوفية (Monufia)', 'المنيا (Minya)', 'القليوبية (Qalyubia)',
  'الوادي الجديد (New Valley)', 'السويس (Suez)', 'الشرقية (Sharqia)', 
  'دمياط (Damietta)', 'بورسعيد (Port Said)', 'بني سويف (Beni Suef)', 'مطروح (Matrouh)',
  'كفر الشيخ (Kafr El Sheikh)', 'قنا (Qena)', 'الأقصر (Luxor)', 'أسوان (Aswan)',
  'أسيوط (Asyut)', 'سوهاج (Sohag)', 'شمال سيناء (North Sinai)', 'جنوب سيناء (South Sinai)',
  'other'
];

// P1: single client-side rule mirroring the API's EG_PHONE validator
// (11 digits, starts with 010/011/012/015). Kept in sync with
// apps/api/src/common/validators/phone.ts.
const EG_PHONE_RE = /^(010|011|012|015)\d{8}$/;

interface BranchDraft {
  name: string;
  address?: string;
  phone?: string;
}

interface PlanTemplate {
  name: string;
  price: number;
  duration: number;
  accessType: string;
  maxSessions: string | number;
}

export default function OnboardingPage() {
  const { t, lang } = useTranslation();
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [data, setData] = useState<Record<string, any>>({ 
    step3: { plans: [] }, 
    step4: { methods: [] }, 
    step6: { aiEnabled: true, provider: 'gemini' } 
  });
  const [logoError, setLogoError] = useState('');
  // Phase 6.3: result of persisting the owner's AI key to POST /ai/config.
  const [aiKeySaved, setAiKeySaved] = useState(false);
  const [aiKeyError, setAiKeyError] = useState('');
  const total = 7;

  // The wizard draft cache is scoped to the CURRENT user. REGRESSION FIX
  // (P0: demo branches المعادي/نصر سيتي leaked into fresh signups): the old
  // code merged localStorage drafts unconditionally, so a draft left behind by
  // ANY previous session on this browser (an older build that pre-filled demo
  // data, an abandoned signup, or a different gym of the same owner) was
  // silently resumed inside a brand-new signup and its branches/plans were
  // created for the new gym. Now:
  //   - drafts are stored together with the userId that created them,
  //   - a draft from another user/unknown session is discarded, never merged,
  //   - /register clears the key, and complete() already removes it.
  const [wizardUserId, setWizardUserId] = useState<string>('');
  useEffect(() => {
    let cancelled = false;
    (async () => {
      let uid = '';
      try {
        const me = (await auth.me()) as { id?: string } | null;
        uid = me?.id || '';
      } catch { uid = ''; }
      if (cancelled) return;
      setWizardUserId(uid);
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        let parsed: { userId?: string; step?: number; data?: Record<string, any> } | null = null;
        try { parsed = JSON.parse(raw); } catch { parsed = null; }
        if (parsed && uid && parsed.userId === uid && parsed.data) {
          setData((d) => ({ ...d, ...parsed!.data }));
          setStep(parsed.step || 1);
        } else {
          // Stale draft (different user, logged-out session, or pre-scoping
          // format) — never let it reach this signup.
          localStorage.removeItem(STORAGE_KEY);
        }
      }
    })();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    api<{
      currentStep?: number;
      step1Data?: Record<string, any>;
      step2Data?: Record<string, any>;
      step3Data?: Record<string, any>;
      step4Data?: Record<string, any>;
      step5Data?: Record<string, any>;
      step6Data?: Record<string, any>;
    }>('/onboarding/progress').then((p) => {
      setStep(Math.min(p.currentStep || 1, 7));
      setData((d) => ({
        ...d,
        step1: p.step1Data || d.step1,
        step2: p.step2Data || d.step2,
        // FIX (demo plans leaked into brand-new gyms): step 3 used to default
        // to the 5 pre-filled template plans, which the wizard then SAVED and
        // created on completion — so a gym whose owner never created any plan
        // still ended up with the seeded/demo plans. A new gym now starts with
        // ZERO plans; templates are opt-in via the "fill with suggestions"
        // button.
        step3: p.step3Data || d.step3 || { plans: [] },
        step4: p.step4Data || d.step4,
        step5: p.step5Data || d.step5,
        step6: p.step6Data || d.step6,
      }));
    }).catch(() => undefined);
  }, []);

  useEffect(() => {
    // Persist drafts only for a known user and tag them with that userId so a
    // later, different signup in this browser can never inherit them.
    if (!wizardUserId) return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ userId: wizardUserId, step, data }));
  }, [step, data, wizardUserId]);

  const current = data[`step${step}`] || {};
  const phoneOk = EG_PHONE_RE.test(String(current.phone || '').trim());
  const requiredOk = useMemo(() => {
    if (step === 1) return !!current.gymName && EG_PHONE_RE.test(String(current.phone || '').trim());
    // Step 3 (plans) is fully optional: a new gym legitimately starts with
    // zero plans and adds them later from the Plans page.
    if (step === 3) return true;
    return true;
  }, [step, current]);

  function patch(value: Record<string, any>) { setData((d) => ({ ...d, [`step${step}`]: { ...(d[`step${step}`] || {}), ...value } })); }
  async function next(skip = false) {
    if (!skip && !requiredOk) return;
    setBusy(true); setErr('');
    try {
      if (step === 6) {
        // The AI key must NOT be parked in the onboarding progress JSON blob —
        // it goes straight to the encrypted per-gym AI config, and only the
        // non-secret toggle/provider are kept in the wizard payload.
        const s6 = data.step6 || {};
        const { apiKey, ...safe } = s6 as Record<string, any>;
        try {
          await api('/ai/config', { method: 'POST', body: JSON.stringify({
            enabled: safe.aiEnabled !== false,
            provider: safe.provider || 'gemini',
            ...(apiKey ? { apiKey } : {}),
          }) });
          if (apiKey) { setAiKeySaved(true); setAiKeyError(''); }
        } catch (e) { setAiKeyError(safeErrorMessage(e)); }
        setData((d) => ({ ...d, step6: safe }));
        await api(`/onboarding/step/${step}`, { method: 'POST', body: JSON.stringify({ data: safe }) });
      } else if (step <= 6) {
        await api(`/onboarding/step/${step}`, { method: 'POST', body: JSON.stringify({ data: data[`step${step}`] || {} }) });
      }
      if (step < 7) setStep(step + 1);
    } catch (e) { setErr(safeErrorMessage(e)); }
    finally { setBusy(false); }
  }
  async function complete() {
    setBusy(true); setErr('');
    try {
      await api('/onboarding/complete', { method: 'POST' });
      // Refresh session to get updated onboardingCompleted flag in the JWT.
      // Do NOT silently catch — if refresh fails, the middleware will still
      // see onboardingCompleted:false and redirect back to /onboarding,
      // making "continue to dashboard" appear stuck.
      try {
        await api('/auth/refresh', { method: 'POST' });
      } catch {
        // If refresh fails, the current token may still work for /dashboard
        // (onboarding/complete sets onboardingCompleted=true in DB but the
        // JWT claim is stale). Force a hard navigation so the middleware
        // re-reads from the DB via the next /auth/me call.
      }
      localStorage.removeItem(STORAGE_KEY);
      // REGRESSION FIX (P0: theme color/logo ignored until F5): the brand
      // provider loaded /gyms/me right after register — BEFORE this step
      // persisted the chosen accentColor/logo — and never reloaded. Tell it
      // to re-read branding NOW so the chosen color/logo apply immediately
      // on the dashboard, no full page refresh needed.
      dispatchBrandRefresh();
      // FIX (P1: "continue to dashboard" does nothing): use window.location
      // for a hard navigation. Next.js router.replace() can silently fail
      // when the middleware redirects (onboarding → dashboard loop) because
      // the client-side router doesn't re-evaluate server middleware for
      // same-app navigations. A hard reload forces the middleware to run
      // with the fresh cookies from the token refresh above.
      window.location.href = '/dashboard';
    } catch (e) {
      setErr(safeErrorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  function input(name: string, placeholder: string, type = 'text') { return <input className="input w-full" type={type} placeholder={placeholder} value={current[name] || ''} onChange={(e) => patch({ [name]: e.target.value })} />; }
  function planChange(i: number, key: string, value: unknown) { const plans = [...(current.plans || [])]; plans[i] = { ...plans[i], [key]: value }; patch({ plans }); }
  function branchChange(i: number, key: string, value: unknown) { const branches = [...(current.branches || [])]; branches[i] = { ...branches[i], [key]: value }; patch({ branches }); }
  function removeBranch(i: number) { const branches = [...(current.branches || [])]; branches.splice(i, 1); patch({ branches }); }
  function removePlan(i: number) { const plans = [...(current.plans || [])]; plans.splice(i, 1); patch({ plans }); }
  function handleLogoFile(file?: File | null) {
    setLogoError('');
    if (!file) return;
    if (file.size > 1024 * 1024) { setLogoError(t('logo_too_large') || 'Image is too large — please use one under 1MB.'); return; }
    if (!file.type.startsWith('image/')) { setLogoError(t('logo_bad_type') || 'Please choose an image file (PNG/JPG/WebP/SVG).'); return; }
    const reader = new FileReader();
    reader.onload = () => { patch({ logo: String(reader.result || '') }); };
    reader.onerror = () => setLogoError(t('logo_read_error') || 'Could not read that image — try another one.');
    reader.readAsDataURL(file);
  }

  return <Shell><main className="mx-auto max-w-5xl px-5 py-8">
    <div className="mb-6 rounded-3xl border border-white/10 bg-black/25 p-5"><div className="flex items-center justify-between text-sm text-white/60"><span>{t('step_label')} {step} {t('of')} {total}</span><span>{Math.round((step / total) * 100)}%</span></div><div className="mt-3 h-2 rounded-full bg-white/10"><div className="h-2 rounded-full bg-[var(--brand)]" style={{ width: `${(step / total) * 100}%` }} /></div></div>
    {err && <div className="bg-red-500/20 border border-red-500/50 rounded-xl p-4 mb-6 text-sm text-red-200">{err}</div>}
    <section className="rounded-3xl border border-white/10 bg-white/[0.04] p-6 md:p-8">
      {step === 1 && <div className="space-y-4"><h1 className="text-3xl font-black">{t('onboarding_welcome')}</h1>{input('gymName', t('gym_name_req'))}
        <div>
          <input className="input w-full" dir="ltr" type="tel" inputMode="numeric" maxLength={11} pattern="01[0125][0-9]{8}" placeholder={t('gym_phone_req')} value={current.phone || ''} onChange={(e) => patch({ phone: e.target.value.replace(/[^\d]/g, '').slice(0, 11) })} />
          {current.phone && !phoneOk && <p className="text-xs text-red-300 mt-1">{t('eg_phone_hint') || 'رقم الموبايل يجب أن يكون 11 رقماً ويبدأ بـ 010 أو 011 أو 012 أو 015'}</p>}
        </div>
        {input('address', t('address'))}
        <div className="flex gap-2">
          <select className="input flex-1" value={current.city || ''} onChange={(e) => patch({ city: e.target.value })}><option value="">{t('select_city')}</option>{governorates.map((c) => <option key={c} value={c}>{c === 'other' ? t('other') || 'Other' : c}</option>)}</select>
          {current.city === 'other' && <input className="input flex-1" placeholder={t('city') || 'City'} value={current.otherCity || ''} onChange={(e) => patch({ otherCity: e.target.value })} />}
        </div>
        <div>
          <label className="text-xs font-bold text-[var(--silver-dim)] uppercase mb-1 block">{t('gym_logo') || 'Gym logo'}</label>
          <p className="text-xs text-white/50 mb-3">{t('logo_upload_help') || 'Upload a square image (PNG/JPG, max ~1MB). You can remove it and pick another one anytime.'}</p>
          <div className="grid gap-4 md:grid-cols-[minmax(0,240px)_1fr]">
            {current.logo ? (
              <div className="rounded-2xl border border-white/10 p-4 bg-black/30">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={current.logo} alt="Logo preview" className="h-32 w-32 object-contain rounded-xl bg-white/10 p-2" />
                <div className="flex gap-2 mt-3">
                  <button type="button" className="btn btn-ghost text-xs px-3 py-1.5" onClick={() => { patch({ logo: '' }); setLogoError(''); }}>
                    {t('remove_logo') || '✕ Remove logo'}
                  </button>
                  <label className="btn btn-ghost text-xs px-3 py-1.5 cursor-pointer">
                    {t('choose_different_logo') || 'Choose a different image'}
                    <input type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" className="hidden"
                      onChange={(e) => handleLogoFile(e.target.files?.[0])} />
                  </label>
                </div>
              </div>
            ) : (
              <label className="flex flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-white/20 p-8 cursor-pointer hover:border-[var(--primary)] transition-colors min-h-[190px]">
                <span className="text-3xl" aria-hidden>📷</span>
                <span className="text-sm text-white/70 font-semibold">{t('upload_logo') || 'Upload logo'}</span>
                <span className="text-[11px] text-white/40 text-center">{t('upload_logo_hint')}</span>
                <input type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" className="hidden"
                  onChange={(e) => handleLogoFile(e.target.files?.[0])} />
              </label>
            )}
            {/* In-context preview: shows exactly how the logo will appear in the
                app header once onboarding completes. */}
            <div className="rounded-2xl border border-white/10 p-4 bg-black/20">
              <p className="text-[11px] uppercase tracking-wide text-white/40 mb-3">{t('logo_preview_header') || 'How it will look'}</p>
              <div className="flex items-center gap-3 rounded-xl border border-white/10 bg-[var(--bg-base,#000)] px-4 py-3">
                {current.logo
                  ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={current.logo} alt="" className="h-10 w-10 object-contain rounded-md" />
                  )
                  : (
                    <svg width="40" height="40" viewBox="0 0 100 100" fill="none" aria-hidden style={{ color: current.primaryColor || '#c5a059' }}>
                      <path d="M35 15V85M35 15H75M35 48H65" stroke="currentColor" strokeWidth="8" strokeLinecap="round" />
                    </svg>
                  )}
                <div className="leading-tight">
                  <div className="font-display text-lg text-white">{current.gymName || t('gymName') || 'Gym name'}</div>
                  <div className="text-[10px] tracking-widest text-white/40">{t('brand_tagline')}</div>
                </div>
              </div>
            </div>
          </div>
          {logoError && <p className="text-xs text-red-400 mt-2">{logoError}</p>}
        </div>
      </div>}
      {step === 2 && <div className="space-y-4"><h1 className="text-3xl font-black">{t('visual_identity')}</h1><input className="input h-12 w-full" type="color" value={current.primaryColor || '#c5a059'} onChange={(e) => patch({ primaryColor: e.target.value })} />{input('coverPhoto', t('cover_photo_url'))}
        <textarea className="input min-h-28 w-full" placeholder={t('gym_description')} value={current.description || ''} onChange={(e) => patch({ description: e.target.value })} /><div className="rounded-2xl border border-white/10 p-4" style={{ borderColor: current.primaryColor || '#c5a059' }}><b>{data.step1?.gymName || t('gymName')}</b><p className="text-white/60">{current.description || t('profile_preview')}</p></div></div>}
      {step === 3 && <div className="space-y-4"><h1 className="text-3xl font-black">{t('plans_and_pricing')}</h1>
        <p className="text-white/60">{t('plans_owner_control')}</p>
        {(current.plans || []).map((p: PlanTemplate, i: number) => <div key={i} className="grid gap-2 rounded-2xl border border-white/10 p-3 md:grid-cols-5 items-center">
          <input className="input" placeholder={t('plan_name') || 'Plan name'} value={p.name || ''} onChange={(e) => planChange(i, 'name', e.target.value)} />
          <input className="input" type="number" placeholder={t('price')} value={p.price || 0} onChange={(e) => planChange(i, 'price', Number(e.target.value))} />
          <input className="input" type="number" placeholder={t('days_duration')} value={p.duration || 30} onChange={(e) => planChange(i, 'duration', Number(e.target.value))} />
          <select className="input" value={p.accessType || 'time'} onChange={(e) => planChange(i, 'accessType', e.target.value)}><option value="time">{t('time')}</option><option value="sessions">{t('sessions')}</option></select>
          <div className="flex gap-1 items-center">
            <input className="input" placeholder={t('sessions_count')} value={p.maxSessions || ''} onChange={(e) => planChange(i, 'maxSessions', e.target.value)} />
            <button type="button" className="btn-ghost px-2 text-red-400" onClick={() => removePlan(i)} title={t('remove_plan') || 'Remove this plan'}>✕</button>
          </div>
        </div>)}
        <div className="flex flex-wrap gap-2">
          <Button onClick={() => patch({ plans: [...(current.plans || []), { name: t('new_plan') || 'باقة جديدة', price: 0, duration: 30, accessType: 'time', maxSessions: '' }] })}>{t('add_plan_btn')}</Button>
        </div>
      </div>}
      {step === 4 && <div className="space-y-4"><h1 className="text-3xl font-black">{t('payment_methods_setup')}</h1>{[t('cash_reception'), 'فودافون كاش', t('transfer'), 'Visa/Mastercard'].map((m) => <label key={m} className="flex gap-2"><input type="checkbox" checked={(current.methods || []).includes(m)} onChange={(e) => patch({ methods: e.target.checked ? [...(current.methods || []), m] : (current.methods || []).filter((x: string) => x !== m) })} />{m}</label>)}{input('bankName', t('bank_name'))}{input('accountNumber', t('account_number'))}{input('accountName', t('account_name'))}</div>}
      {step === 5 && <div className="space-y-4"><h1 className="text-3xl font-black">{t('branches_step_title')}</h1>
        <p className="text-white/60">{t('branches_step_help')}</p>
        {(current.branches || []).map((br: BranchDraft, i: number) => <div key={i} className="grid gap-2 rounded-2xl border border-white/10 p-3 md:grid-cols-[1.2fr_1.4fr_1fr_auto] items-end">
          <div>
            <label className="text-[11px] font-bold text-[var(--silver-dim)] uppercase mb-1 block">{t('branch_name')}</label>
            <input className="input w-full" placeholder={t('branch_name')} value={br.name || ''} onChange={(e) => branchChange(i, 'name', e.target.value)} />
          </div>
          <div>
            <label className="text-[11px] font-bold text-[var(--silver-dim)] uppercase mb-1 block">{t('address')}</label>
            <input className="input w-full" placeholder={t('address')} value={br.address || ''} onChange={(e) => branchChange(i, 'address', e.target.value)} />
          </div>
          <div>
            <label className="text-[11px] font-bold text-[var(--silver-dim)] uppercase mb-1 block">{t('phone')}</label>
            <input className="input w-full" dir="ltr" type="tel" inputMode="numeric" maxLength={11} pattern="01[0125][0-9]{8}" placeholder="01xxxxxxxxx" value={br.phone || ''} onChange={(e) => branchChange(i, 'phone', e.target.value.replace(/[^\d]/g, '').slice(0, 11))} />
            {br.phone && !EG_PHONE_RE.test(br.phone) && <p className="text-xs text-red-300 mt-1">{t('eg_phone_hint') || 'رقم الموبايل يجب أن يكون 11 رقماً ويبدأ بـ 010 أو 011 أو 012 أو 015'}</p>}
          </div>
          <button type="button" className="btn-ghost px-3 py-2 text-red-400" onClick={() => removeBranch(i)} title={t('delete')}>✕</button>
        </div>)}
        <Button onClick={() => patch({ branches: [...(current.branches || []), { name: '', address: '', phone: '' }] })}>{t('add_branch')}</Button>
        <p className="text-xs text-white/40">{t('staff_moved_to_dashboard')}</p>
      </div>}
      {step === 6 && <div className="space-y-4"><h1 className="text-3xl font-black">{t('enable_ai_assistant')}</h1>
        <p className="text-white/60">{t('ai_desc_onboarding')}</p>
        <label className="flex gap-2"><input type="checkbox" checked={current.aiEnabled !== false} onChange={(e) => patch({ aiEnabled: e.target.checked })} />{t('enable_ai')}</label>
        <div>
          <label className="text-[11px] font-bold text-[var(--silver-dim)] uppercase mb-1 block">{t('ai_provider')}</label>
          <select className="input w-full" value={current.provider || 'gemini'} onChange={(e) => patch({ provider: e.target.value })}>
            <option value="gemini">Gemini (Google) — {t('free')}</option>
            <option value="anthropic">Claude (Anthropic) — {t('ai_paid_provider')}</option>
            <option value="groq">Groq (Llama) — {t('ai_paid_provider')}</option>
          </select>
          <p className="text-xs text-white/50 mt-1">{(current.provider || 'gemini') === 'gemini' ? t('ai_free_tier_note') : t('ai_paid_tier_note')}</p>
        </div>
        {/* Phase 6.3: the owner's OWN provider API key. Sent once to
            POST /ai/config, encrypted at rest server-side, never read back. */}
        <div>
          <label className="text-[11px] font-bold text-[var(--silver-dim)] uppercase mb-1 block">{t('ai_api_key')}</label>
          <input className="input w-full" dir="ltr" type="password" autoComplete="off"
            placeholder={aiKeySaved ? t('ai_key_saved_note') : t('ai_api_key_placeholder')}
            value={current.apiKey || ''} onChange={(e) => patch({ apiKey: e.target.value })} />
          <p className="text-xs text-white/50 mt-1">{t('ai_key_help')}</p>
          {aiKeyError && <p className="text-xs text-red-300 mt-1">{aiKeyError}</p>}
          {aiKeySaved && <p className="text-xs text-green-300 mt-1">✅ {t('ai_key_saved_note')}</p>}
        </div>
        <p className="text-xs text-white/40">{t('ai_can_skip')}</p>
      </div>}
      {step === 7 && <div className="space-y-5 text-center"><div className="text-7xl">🎉</div><h1 className="text-4xl font-black">{t('gym_ready')}</h1><p className="text-white/60">{t('basic_setup_done')}</p><Button onClick={complete} loading={busy}>{t('enter_dashboard')}</Button><Button variant="ghost" onClick={() => navigator.clipboard?.writeText(`${location.origin}/portal/login`)}>{t('get_gym_link')}</Button></div>}
      <div className="mt-8 flex justify-between gap-3"><Button variant="ghost" disabled={step === 1 || busy} onClick={() => setStep(step - 1)}>{t('previous')}</Button><div className="flex gap-2">{[3,4,5,6].includes(step) && <Button variant="ghost" onClick={() => next(true)} disabled={busy}>{t('skip')}</Button>}{step < 7 && <Button disabled={!requiredOk || busy} loading={busy} onClick={() => next()}>{t('next')}</Button>}</div></div>
    </section>
  </main></Shell>;
}
