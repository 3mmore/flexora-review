'use client';
/**
 * FEATURE B — Team performance (owner + anyone granted `team.performance.view`).
 *
 * The screen answers one question per person: how much money did they bring in,
 * how many sessions did they run, how many people turned up — and where are they
 * against their monthly target.
 *
 * The definitions a reader would otherwise have to guess are ON THE PAGE:
 *   * "new" vs "renewal" as separate columns;
 *   * membership and POS shown apart, plus the total;
 *   * attendance labelled "booked and marked attended" with the rate beside the
 *     raw counts and a low-sample marker;
 *   * a row for money that cannot be attributed, never spread over staff.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Shell from '@/components/Shell';
import { api, API_BASE_URL } from '@/lib/api';
import { EmptyState, ErrorState, Skeleton } from '@/components/ui/States';
import { Icon } from '@/components/brand/Icon';
import { ModalPortal } from '@/components/ModalPortal';
import { useTranslation } from '@/lib/i18n';
import { safeErrorMessage } from '@/lib/safe-error';
import {
  TEAM_DEFAULT_FILTERS,
  TeamFeed,
  TeamFilters,
  TeamRow,
  barWidth,
  buildTeamQuery,
  csvFilename,
  isOverTarget,
  pct,
  personKind,
  rangeLabel,
  tzLabelKey,
} from '@/lib/team';
import { formatDate } from '@/lib/dates';

interface BranchOption { id: string; name: string }
interface Detail {
  staff: { userId: string; name: string; role: string; active: boolean; branchName: string | null };
  range: { from: string; to: string; tz: string; days: number };
  sales: {
    newSubscriptions: number; renewals: number; membershipGross: string; posGross: string;
    refunds: string; net: string; posSalesCount: number; membershipCount: number; refundCount: number;
  };
  attendance: null | {
    sessionsHeld: number; booked: number; membersAttended: number; rate: number | null; lowSample: boolean;
    byClassType: Array<{ name: string; nameAr: string | null; sessions: number; booked: number; attended: number; rate: number | null; lowSample: boolean }>;
  };
  trend: Array<{ day: string; net: string; newSubscriptions: number }>;
}

export default function TeamPerformancePage() {
  const { t, lang } = useTranslation();
  /**
   * The app's `t()` takes a key only — no interpolation — so numbers are spliced
   * in here. Keeping it in one place means no screen ever interpolates its own
   * way (and `{n}`/`{v}` placeholders stay visible in the dictionary, which is
   * what makes a missing one obvious in review).
   */
  const fill = useCallback((key: string, vars?: Record<string, string | number>) => {
    let out = t(key);
    if (vars) for (const [k, v] of Object.entries(vars)) out = out.split(`{${k}}`).join(String(v));
    return out;
  }, [t]);
  const [filters, setFilters] = useState<TeamFilters>(TEAM_DEFAULT_FILTERS);
  const [feed, setFeed] = useState<TeamFeed | null>(null);
  const [branches, setBranches] = useState<BranchOption[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [detail, setDetail] = useState<Detail | null>(null);
  const [detailFor, setDetailFor] = useState<TeamRow | null>(null);
  const [detailBusy, setDetailBusy] = useState(false);
  const [targetFor, setTargetFor] = useState<TeamRow | null>(null);
  const [targetBusy, setTargetBusy] = useState(false);
  const [notice, setNotice] = useState('');
  // PACK 2, item 4: a second view of the same data — per employee × per month.
  const [tab, setTab] = useState<'range' | 'monthly'>('range');
  const [months, setMonths] = useState<6 | 12>(6);
  const [monthly, setMonthly] = useState<any | null>(null);
  const [monthlyBusy, setMonthlyBusy] = useState(false);
  const reqId = useRef(0);

  useEffect(() => {
    api<BranchOption[]>('/branches')
      .then((list) => setBranches(Array.isArray(list) ? list : []))
      .catch(() => setBranches([]));
  }, []);

  const load = useCallback(async (f: TeamFilters) => {
    const id = ++reqId.current;
    setLoading(true);
    setError('');
    try {
      const data = await api<TeamFeed>(`/team/performance?${buildTeamQuery(f)}`);
      if (id !== reqId.current) return; // a newer request already answered
      setFeed(data);
    } catch (e) {
      if (id !== reqId.current) return;
      setFeed(null);
      setError(safeErrorMessage(e) || 'team_load_failed');
    } finally {
      if (id === reqId.current) setLoading(false);
    }
  }, []);

  // 250 ms debounce: typing in the search box must not fire a request per key
  useEffect(() => {
    const timer = setTimeout(() => load(filters), 250);
    return () => clearTimeout(timer);
  }, [filters, load]);

  const patch = (p: Partial<TeamFilters>) => setFilters((f) => ({ ...f, ...p, page: p.page ?? 1 }));

  /**
   * The monthly row carries the same identity as a range row but not the range
   * money. Only `userId` and `name` are read by the modal — every figure in it
   * comes from the per-employee endpoint — so a monthly row can open the same
   * detail without inventing a single number.
   */
  const openDetailById = (id: string, name: string) => {
    if (!id) return;                       // the "no known staff" row has no person
    void openDetail({ userId: id, name } as TeamRow);
  };

  const openDetail = async (row: TeamRow) => {
    setDetailFor(row);
    setDetail(null);
    setDetailBusy(true);
    setError('');
    try {
      const q = buildTeamQuery({ ...filters, page: 1, pageSize: 25 });
      const data = await api<Detail>(`/team/performance/${encodeURIComponent(row.userId)}?${q.replace(/(^|&)page(Size)?=[^&]*/g, '')}`);
      setDetail(data);
    } catch (e) {
      setError(safeErrorMessage(e) || 'team_load_failed');
      setDetailFor(null);
    } finally {
      setDetailBusy(false);
    }
  };

  const saveTarget = async (kind: string, value: string) => {
    if (!targetFor) return;
    setTargetBusy(true);
    setError('');
    try {
      await api('/team/performance/targets', {
        method: 'POST',
        body: JSON.stringify({
          items: [{ userId: targetFor.userId, period: feed?.period, kind, targetValue: value }],
        }),
      });
      setNotice(t('team_target_saved'));
      setTargetFor(null);
      await load(filters);
      setTimeout(() => setNotice(''), 4000);
    } catch (e) {
      setError(safeErrorMessage(e) || 'team_target_failed');
    } finally {
      setTargetBusy(false);
    }
  };

  const exportCsv = async () => {
    setError('');
    try {
      const q = buildTeamQuery({ ...filters, page: 1 });
      const res = await fetch(`${API_BASE_URL}/team/performance/export.csv?${q}`, { credentials: 'include' });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        setError(safeErrorMessage(body?.message ? body : new Error(`HTTP ${res.status}`)) || 'team_export_failed');
        return;
      }
      const blob = await res.blob();
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = csvFilename(res.headers.get('content-disposition'), feed?.range);
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(a.href);
    } catch (e) {
      setError(safeErrorMessage(e) || 'team_export_failed');
    }
  };

  // Load the matrix the first time its tab is opened, and again whenever the
  // window or the branch filter changes. Kept separate from the range feed so
  // switching tabs never refetches the other view.
  useEffect(() => {
    if (tab !== 'monthly') return;
    let dead = false;
    (async () => {
      setMonthlyBusy(true);
      try {
        const qs = new URLSearchParams({ months: String(months) });
        if (filters.branchId) qs.set('branchId', filters.branchId);
        const res = await api<any>(`/team/performance/monthly?${qs}`);
        if (!dead) setMonthly(res);
      } catch (e) {
        if (!dead) setError(safeErrorMessage(e));
      } finally {
        if (!dead) setMonthlyBusy(false);
      }
    })();
    return () => { dead = true; };
  }, [tab, months, filters.branchId]);

  const items = feed?.items ?? [];
  const na = feed?.notAttributable;

  return (
    <Shell>
      <div className="team-page">
        <header className="team-head">
          <div>
            <h1 className="team-title">{t('team_performance')}</h1>
            <p className="team-sub">
              {feed ? rangeLabel(feed.range, formatDate, tzLabelKey(feed.range.tz) ? t(tzLabelKey(feed.range.tz)!) : null) : '—'} · {fill('team_days_left', { n: feed?.daysLeft ?? 0 })}
            </p>
          </div>
          <div className="team-head-actions">
            <button className="btn btn-ghost" onClick={() => load(filters)} disabled={loading}>
              <Icon name="arrow-down" size={16} /> {t('refresh')}
            </button>
            {/* this one exports the range feed; the matrix tab has its own export */}
            {tab === 'range' && (
              <button className="btn btn-primary" onClick={exportCsv} disabled={loading || items.length === 0}>
                <Icon name="arrow-down" size={16} /> {t('team_export_csv')}
              </button>
            )}
          </div>
        </header>

        {/* PACK 2, item 4: two questions, two tabs. The range view keeps every
            number it already had; the monthly view answers "is this a trend or
            one good month?" */}
        <div className="team-tabs" role="tablist" aria-label={t('team_performance')}>
          <button role="tab" aria-selected={tab === 'range'} className={tab === 'range' ? 'team-tab is-active' : 'team-tab'}
            onClick={() => setTab('range')}>{t('team_tab_range')}</button>
          <button role="tab" aria-selected={tab === 'monthly'} className={tab === 'monthly' ? 'team-tab is-active' : 'team-tab'}
            onClick={() => setTab('monthly')}>{t('team_tab_monthly')}</button>
        </div>

        {tab === 'monthly' ? (
          <section className="team-monthly" aria-label={t('team_monthly_title')}>
            <div className="team-monthly-head">
              <div>
                <h2 className="team-monthly-title">{t('team_monthly_title')}</h2>
                <p className="team-sub">{t('team_monthly_hint')}</p>
              </div>
              <div className="team-head-actions">
                <select className="input" value={months} onChange={(e) => setMonths(Number(e.target.value) as 6 | 12)}
                  aria-label={t('team_tab_monthly')}>
                  <option value={6}>{t('team_months_6')}</option>
                  <option value={12}>{t('team_months_12')}</option>
                </select>
                <button className="btn btn-primary" disabled={!monthly}
                  onClick={() => {
                    const qs = new URLSearchParams({ months: String(months), format: 'csv' });
                    if (filters.branchId) qs.set('branchId', filters.branchId);
                    window.location.href = `${API_BASE_URL}/team/performance/monthly?${qs}`;
                  }}>
                  <Icon name="arrow-down" size={16} /> {t('team_export_csv')}
                </button>
              </div>
            </div>

            {monthlyBusy && <Skeleton lines={6} />}
            {!monthlyBusy && monthly && (
              <>
                <div className="team-mom" data-testid="month-over-month">
                  {monthly.monthOverMonth.filter(Boolean).slice(-1).map((d: any) => (
                    <span key={d.month} className="team-mom-pill" data-sign={String(d.netDelta).startsWith('-') ? 'down' : 'up'}>
                      {t('team_month_delta')}: <bdi>{d.netDelta} {t('currency')}</bdi>
                      {d.netDeltaPct == null ? '' : ' '}
                      {d.netDeltaPct == null ? '' : <bdi dir="ltr">({d.netDeltaPct > 0 ? '+' : ''}{d.netDeltaPct}%)</bdi>}
                    </span>
                  ))}
                </div>

                <div className="team-monthly-cards">
                  {monthly.rows.map((r: any) => (
                    <div className="team-mcard" key={r.userId}>
                      <div className="team-mcard-head">
                        {r.unattributed ? (
                          <strong>{t('team_unattributed_staff')}</strong>
                        ) : (
                          <button className="team-mcard-name" onClick={() => openDetailById(r.userId, r.name)}>
                            {r.name}
                          </button>
                        )}
                        <span className="team-sub">{r.branchName ?? ''}</span>
                      </div>
                      <div className="team-mcard-grid">
                        <div><span>{t('team_col_net')}</span><b>{r.totals.net}</b></div>
                        <div><span>{t('team_col_collected')}</span><b>{r.totals.collected}</b></div>
                        <div><span>{t('team_col_best')}</span><b>{r.bestMonth ? `${r.bestMonth.month} · ${r.bestMonth.net}` : '—'}</b></div>
                        <div><span>{t('team_col_avg')}</span><b>{r.averageNet ?? '—'}</b></div>
                      </div>
                      <svg viewBox={`0 0 ${Math.max(120, r.months.length * 28)} 36`} className="team-spark" role="img"
                        aria-label={`${t('team_spark')} — ${r.name}`}>
                        {r.months.map((c: any, i: number) => {
                          const vals = r.months.map((x: any) => Number(x.net));
                          const max = Math.max(1, ...vals.map((v: number) => Math.abs(v)));
                          const h = Math.max(2, (Math.abs(Number(c.net)) / max) * 30);
                          return <rect key={c.month} x={i * 28 + 3} width={18} height={h} y={34 - h} rx={3}
                            fill={Number(c.net) < 0 ? 'var(--danger, #ef4444)' : 'var(--brand, #d4af37)'} />;
                        })}
                      </svg>
                      <div className="team-sub">{r.months.map((c: any) => c.month.slice(5)).join(' · ')}</div>
                    </div>
                  ))}
                </div>

                <div className="table-wrap team-monthly-table">
                  <table className="table">
                    <thead>
                      <tr>
                        <th>{t('team_col_staff')}</th>
                        {monthly.months.map((m: string) => <th key={m}>{m}</th>)}
                        <th>{t('team_col_net')}</th>
                        <th>{t('team_col_collected')}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {monthly.rows.map((r: any) => (
                        <tr key={r.userId || 'unattributed'}>
                          <td>
                            {r.unattributed ? (
                              <em>{t('team_unattributed_staff')}</em>
                            ) : (
                              <button className="team-mcard-name" onClick={() => openDetailById(r.userId, r.name)}>
                                {r.name}
                              </button>
                            )}
                          </td>
                          {r.months.map((c: any) => <td key={c.month}>{c.net}</td>)}
                          <td><b>{r.totals.net}</b></td>
                          <td>{r.totals.collected}</td>
                        </tr>
                      ))}
                      <tr className="row-total">
                        <td><b>{t('team_totals')}</b></td>
                        {monthly.totalsPerMonth.map((t2: any) => <td key={t2.month}><b>{t2.net}</b></td>)}
                        <td><b>{monthly.rows.reduce((a: number, r: any) => a + Number(r.totals.net), 0).toFixed(2)}</b></td>
                        <td><b>{monthly.rows.reduce((a: number, r: any) => a + Number(r.totals.collected), 0).toFixed(2)}</b></td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <p className="team-sub" data-testid="monthly-caveats">
                  {t('team_monthly_pos_caveat')}
                  {monthly.posNotAttributable.some((x: any) => Number(x.amount) !== 0) && (
                    <>
                      {' · '}{t('team_pos_unattributed')}:{' '}
                      {/* only the months that actually carry money, and each date in
                          its own bdi so RTL does not reorder 2026-11 into 11-2026 */}
                      {monthly.posNotAttributable
                        .filter((x: any) => Number(x.amount) !== 0)
                        .map((x: any, i: number) => (
                          <span key={x.month}>
                            {i > 0 && ' · '}
                            <bdi dir="ltr">{x.month}</bdi> <bdi>{x.amount}</bdi>
                          </span>
                        ))}
                    </>
                  )}
                </p>
              </>
            )}
          </section>
        ) : (
        <>
        {/* filters */}
        <div className="team-filters">
          <label className="team-field">
            <span>{t('team_period')}</span>
            <select className="input" value={filters.period} onChange={(e) => patch({ period: e.target.value as TeamFilters['period'] })}>
              <option value="today">{t('team_period_today')}</option>
              <option value="week">{t('team_period_week')}</option>
              <option value="month">{t('team_period_month')}</option>
              <option value="custom">{t('team_period_custom')}</option>
            </select>
          </label>
          {filters.period === 'custom' && (
            <>
              <label className="team-field">
                <span>{t('from')}</span>
                <input className="input" type="date" value={filters.from} max={filters.to || undefined} onChange={(e) => patch({ from: e.target.value })} />
              </label>
              <label className="team-field">
                <span>{t('to')}</span>
                <input className="input" type="date" value={filters.to} min={filters.from || undefined} onChange={(e) => patch({ to: e.target.value })} />
              </label>
            </>
          )}
          <label className="team-field">
            <span>{t('branch')}</span>
            <select className="input" value={filters.branchId} onChange={(e) => patch({ branchId: e.target.value })}>
              <option value="">{t('all_branches')}</option>
              {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
            </select>
          </label>
          <label className="team-field">
            <span>{t('search')}</span>
            <input className="input" value={filters.q} placeholder={t('team_search_staff')} onChange={(e) => patch({ q: e.target.value })} />
          </label>
          <label className="team-field">
            <span>{t('team_sort')}</span>
            <select className="input" value={filters.sort} onChange={(e) => patch({ sort: e.target.value as TeamFilters['sort'] })}>
              <option value="net">{t('team_sort_net')}</option>
              <option value="newSubs">{t('team_sort_new_subs')}</option>
              <option value="attendance">{t('team_sort_attendance')}</option>
              <option value="name">{t('team_sort_name')}</option>
            </select>
          </label>
          <label className="team-field">
            <span>{t('team_inactive')}</span>
            <select className="input" value={filters.includeInactive ? '1' : '0'} onChange={(e) => patch({ includeInactive: e.target.value === '1' })}>
              <option value="0">{t('team_active_only')}</option>
              <option value="1">{t('team_include_inactive')}</option>
            </select>
          </label>
        </div>

        {notice && <p className="team-footnote" role="status">{notice}</p>}

        {error && (
          <ErrorState title={t('something_went_wrong')} description={t(error)} onRetry={() => load(filters)} />
        )}

        {!error && loading && <Skeleton lines={6} />}

        {!error && !loading && feed && (
          <>
            <section className="team-kpis" aria-label={t('team_totals')}>
              <div className="team-kpi"><span>{t('team_staff')}</span><strong>{feed.totals.staffCount}</strong></div>
              <div className="team-kpi"><span>{t('team_new_subs')}</span><strong>{feed.totals.newSubscriptions}</strong><small>{t('team_new_subs_note')}</small></div>
              <div className="team-kpi"><span>{t('team_renewals')}</span><strong>{feed.totals.renewals}</strong></div>
              <div className="team-kpi"><span>{t('team_net')}</span><strong>{feed.totals.net}</strong><small>{t('team_net_note')}</small></div>
              <div className="team-kpi"><span>{t('team_sessions_held')}</span><strong>{feed.totals.sessionsHeld}</strong><small>{t('team_sessions_held_note')}</small></div>
              <div className="team-kpi"><span>{t('team_attended')}</span><strong>{feed.totals.membersAttended}</strong></div>
            </section>

            {items.length === 0 ? (
              <EmptyState title={t('team_empty_title')} description={t('team_empty_desc')} />
            ) : (
              <div className="team-table-scroll">
                <table className="team-table">
                  <thead>
                    <tr>
                      <th>{t('team_col_staff')}</th>
                      <th className="num">{t('team_new_subs')}</th>
                      <th className="num">{t('team_renewals')}</th>
                      <th className="num">{t('team_membership')}</th>
                      <th className="num">{t('team_pos')}</th>
                      <th className="num">{t('team_refunds')}</th>
                      <th className="num">{t('team_net')}</th>
                      <th className="num">{t('team_avg_sale')}</th>
                      <th>{t('team_target')}</th>
                      <th className="num">{t('team_attendance_rate')}</th>
                      <th />
                    </tr>
                  </thead>
                  <tbody>
                    {items.map((r) => {
                      const kind = personKind(r.role);
                      const target = kind === 'coach' ? r.attendanceTarget : r.salesTarget;
                      const progress = target?.progressPct ?? null;
                      return (
                        <tr key={r.userId}>
                          <td>
                            <div className="team-person">
                              <a href="#" onClick={(e) => { e.preventDefault(); openDetail(r); }}>{r.name}</a>
                              <small>
                                {t(r.role.toLowerCase())} · {r.branchName || '—'}
                                {!r.active ? ` · ${t('team_inactive_tag')}` : ''}
                                {r.rank && r.rankMetric ? ` · #${r.rank}` : ''}
                              </small>
                            </div>
                          </td>
                          <td className="num">{r.newSubscriptions}</td>
                          <td className="num">{r.renewals}</td>
                          <td className="num">{r.membershipGross}</td>
                          <td className="num">{r.posGross}</td>
                          <td className="num">{r.refunds}</td>
                          <td className="num"><strong>{r.net}</strong></td>
                          <td className="num">{r.average}</td>
                          <td>
                            {target ? (
                              <div>
                                <div className={`team-bar${isOverTarget(progress) ? ' is-over' : ''}`}>
                                  <i style={{ width: barWidth(progress) }} />
                                </div>
                                <small>
                                  {target.target} · {pct(progress)} · {fill('team_remaining', { v: target.remaining })}
                                </small>
                              </div>
                            ) : (
                              <button className="btn-ghost btn-sm" onClick={() => setTargetFor(r)}>{t('team_set_target')}</button>
                            )}
                          </td>
                          <td className="num">
                            {kind === 'coach' || r.sessionsHeld > 0 ? (
                              <>
                                {pct(r.attendanceRate)}
                                <br />
                                <small>{fill('team_booked_attended', { b: r.booked, a: r.membersAttended })}</small>
                                {r.attendanceLowSample && <><br /><span className="team-low-sample">{t('team_low_sample')}</span></>}
                              </>
                            ) : (
                              <span className="team-empty-inline">—</span>
                            )}
                          </td>
                          <td>
                            <button className="btn-ghost btn-sm" onClick={() => openDetail(r)} aria-label={t('details')}>
                              <Icon name="arrow-left" size={14} />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* money that could not be attributed is its own line, never hidden */}
            {na && (Number(na.posGross) !== 0 || Number(na.refunds) !== 0 || Number(na.membershipGross) !== 0 || na.sessionsWithoutCoach > 0) && (
              <div className="team-panel">
                <h3>{t('team_not_attributable')}</h3>
                <p className="team-footnote">{t('team_not_attributable_help')}</p>
                <div className="team-kpis">
                  <div className="team-kpi"><span>{t('team_pos')}</span><strong>{na.posGross}</strong><small>{fill('team_rows_n', { n: na.posCount })}</small></div>
                  <div className="team-kpi"><span>{t('team_refunds')}</span><strong>{na.refunds}</strong><small>{fill('team_rows_n', { n: na.refundCount })}</small></div>
                  <div className="team-kpi"><span>{t('team_membership')}</span><strong>{na.membershipGross}</strong><small>{fill('team_rows_n', { n: na.membershipCount })}</small></div>
                  <div className="team-kpi"><span>{t('team_sessions_held')}</span><strong>{na.sessionsWithoutCoach}</strong><small>{t('team_no_coach')}</small></div>
                </div>
              </div>
            )}

            <div className="team-panel">
              <h3>{t('team_definitions')}</h3>
              <div className="team-defs">
                <div><b>{t('team_net')}</b><span>{t('team_def_sales_value')}</span></div>
                <div><b>{t('team_new_subs')}</b><span>{t('team_def_new_vs_renewal')}</span></div>
                <div><b>{t('team_pos')}</b><span>{t('team_def_pos_attribution')}</span></div>
                <div><b>{t('team_attendance_rate')}</b><span>{t('team_def_attendance_rate')}</span></div>
                <div><b>{t('team_low_sample')}</b><span>{t('team_def_low_sample')}</span></div>
                <div><b>{t('team_net_sign')}</b><span>{t('team_def_net_can_be_negative')}</span></div>
              </div>
            </div>

            {feed.totalPages > 1 && (
              <div className="team-actions">
                <button className="btn btn-ghost" disabled={filters.page <= 1} onClick={() => patch({ page: filters.page - 1 })}>{t('previous')}</button>
                <span className="team-footnote">{filters.page} / {feed.totalPages}</span>
                <button className="btn btn-ghost" disabled={filters.page >= feed.totalPages} onClick={() => patch({ page: filters.page + 1 })}>{t('next')}</button>
              </div>
            )}
          </>
        )}
        </>
        )}
      </div>

      {/* detail */}
      {detailFor && (
        <ModalPortal>
          <div className="ntf-modal-backdrop" onClick={() => { setDetailFor(null); setDetail(null); }}>
            <div className="ntf-modal" role="dialog" aria-modal="true" onClick={(e) => e.stopPropagation()}>
              <div className="ntf-modal-head">
                <h2>{detailFor.name}</h2>
                <button className="btn-ghost btn-sm" onClick={() => { setDetailFor(null); setDetail(null); }} aria-label={t('close')}>
                  <Icon name="x" size={16} />
                </button>
              </div>
              {detailBusy && <Skeleton lines={4} />}
              {detail && (
                <div className="team-page">
                  <p className="team-footnote">{rangeLabel(detail.range, formatDate, tzLabelKey(detail.range.tz) ? t(tzLabelKey(detail.range.tz)!) : null)}</p>
                  <div className="team-kpis">
                    <div className="team-kpi"><span>{t('team_new_subs')}</span><strong>{detail.sales.newSubscriptions}</strong></div>
                    <div className="team-kpi"><span>{t('team_renewals')}</span><strong>{detail.sales.renewals}</strong></div>
                    <div className="team-kpi"><span>{t('team_membership')}</span><strong>{detail.sales.membershipGross}</strong></div>
                    <div className="team-kpi"><span>{t('team_pos')}</span><strong>{detail.sales.posGross}</strong></div>
                    <div className="team-kpi"><span>{t('team_refunds')}</span><strong>{detail.sales.refunds}</strong></div>
                    <div className="team-kpi"><span>{t('team_net')}</span><strong>{detail.sales.net}</strong></div>
                  </div>

                  {detail.attendance && (
                    <div className="team-panel">
                      <h3>{t('team_attendance')}</h3>
                      <p className="team-footnote">{t('team_attendance_note')}</p>
                      <div className="team-table-scroll">
                        <table className="team-table">
                          <thead>
                            <tr>
                              <th>{t('team_class_type')}</th>
                              <th className="num">{t('team_sessions')}</th>
                              <th className="num">{t('team_booked')}</th>
                              <th className="num">{t('team_attended')}</th>
                              <th className="num">{t('team_rate')}</th>
                            </tr>
                          </thead>
                          <tbody>
                            {detail.attendance.byClassType.map((c) => (
                              <tr key={c.name}>
                                <td>{lang === 'ar' && c.nameAr ? c.nameAr : c.name}</td>
                                <td className="num">{c.sessions}</td>
                                <td className="num">{c.booked}</td>
                                <td className="num">{c.attended}</td>
                                <td className="num">
                                  {pct(c.rate)}
                                  {c.lowSample && <span className="team-low-sample"> {t('team_low_sample')}</span>}
                                </td>
                              </tr>
                            ))}
                            {detail.attendance.byClassType.length === 0 && (
                              <tr><td colSpan={5} className="team-empty-inline">{t('team_no_sessions')}</td></tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  {detail.trend.length > 0 && (
                    <div className="team-panel">
                      <h3>{t('team_trend')}</h3>
                      <svg className="team-chart" viewBox={`0 0 ${Math.max(60, detail.trend.length * 14)} 100`} preserveAspectRatio="none" role="img" aria-label={t('team_trend')}>
                        {(() => {
                          const max = Math.max(1, ...detail.trend.map((d) => Math.abs(Number(d.net))));
                          return detail.trend.map((d, i) => {
                            const h = Math.round((Math.abs(Number(d.net)) / max) * 90);
                            return <rect key={d.day} x={i * 14 + 2} y={100 - h} width={10} height={h} rx={2} fill="var(--cyan)" opacity={Number(d.net) < 0 ? 0.4 : 0.9} />;
                          });
                        })()}
                      </svg>
                      <p className="team-footnote">{t('team_trend_note')}</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </ModalPortal>
      )}

      {/* target editor */}
      {targetFor && (
        <ModalPortal>
          <div className="ntf-modal-backdrop" onClick={() => setTargetFor(null)}>
            <div className="ntf-modal" role="dialog" aria-modal="true" onClick={(e) => e.stopPropagation()}>
              <div className="ntf-modal-head">
                <h2>{fill('team_set_target_for', { name: targetFor.name })}</h2>
                <button className="btn-ghost btn-sm" onClick={() => setTargetFor(null)} aria-label={t('close')}><Icon name="x" size={16} /></button>
              </div>
              <TargetForm
                t={(k: string, v?: Record<string, string | number>) => {
                  let out = t(k);
                  if (v) for (const [kk, vv] of Object.entries(v)) out = out.split(`{${kk}}`).join(String(vv));
                  return out;
                }}
                busy={targetBusy}
                currencyHint={feed?.period ?? ''}
                onSubmit={saveTarget}
              />
            </div>
          </div>
        </ModalPortal>
      )}
    </Shell>
  );
}

function TargetForm({
  t,
  busy,
  currencyHint,
  onSubmit,
}: {
  t: (k: string, v?: Record<string, string | number>) => string;
  busy: boolean;
  currencyHint: string;
  onSubmit: (kind: string, value: string) => Promise<void>;
}) {
  const [kind, setKind] = useState('SALES_VALUE');
  const [value, setValue] = useState('');
  const valid = useMemo(() => /^\d{1,12}(\.\d{1,2})?$/.test(value) && (kind !== 'ATTENDANCE_RATE' || Number(value) <= 100), [value, kind]);
  return (
    <form
      className="team-target-form"
      onSubmit={(e) => { e.preventDefault(); if (valid) void onSubmit(kind, value); }}
    >
      <p className="team-footnote">{t('team_target_period_note', { period: currencyHint })}</p>
      <label className="team-field">
        <span>{t('team_target_kind')}</span>
        <select className="input" value={kind} onChange={(e) => setKind(e.target.value)}>
          <option value="SALES_VALUE">{t('team_target_sales')}</option>
          <option value="NEW_SUBSCRIPTIONS">{t('team_target_subs')}</option>
          <option value="ATTENDANCE_RATE">{t('team_target_rate')}</option>
        </select>
      </label>
      <label className="team-field">
        <span>{kind === 'ATTENDANCE_RATE' ? t('team_target_rate_hint') : t('team_target_value')}</span>
        <input
          className="input"
          inputMode="decimal"
          value={value}
          onChange={(e) => setValue(e.target.value.trim())}
          placeholder={kind === 'ATTENDANCE_RATE' ? '0–100' : '0.00'}
        />
      </label>
      <button className="btn btn-primary" type="submit" disabled={!valid || busy}>
        {busy ? t('saving') : t('save')}
      </button>
    </form>
  );
}
