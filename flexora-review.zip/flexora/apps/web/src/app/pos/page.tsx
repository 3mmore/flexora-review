'use client';
/**
 * FLEXORA Revenue Terminal
 * Front-desk POS redesigned for speed, member-aware selling, and recovery.
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import { formatDate } from '@/lib/dates';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { Card } from '@/components/ui/Card';
import { EmptyState, Skeleton } from '@/components/ui/States';
import { Icon } from '@/components/brand/Icon';
import { FeedbackLayer } from '@/components/ProductOS';
import { useTranslation } from '@/lib/i18n';
import { ModalPortal } from '@/components/ModalPortal';
import { label } from '@/lib/i18n/codes';

type Product = {
  id: string;
  name: string;
  category?: string;
  icon?: string;
  barcode?: string;
  price: number | string;
  qty: number;
  lowAlert?: number;
};

type Member = {
  id: string;
  name: string;
  mobile: string;
  status?: string;
  expiry?: string;
  sessionsLeft?: number;
  plan?: { name?: string; type?: string };
  lastVisit?: string;
};

type Sale = {
  id: string;
  invoiceNo: string;
  total: number | string;
  createdAt?: string;
  items?: Array<{ id: string; name: string; qty: number; price: number | string }>;
};

const formatMoney = (value: number | string | undefined, t: (k: string) => string) => `${Math.round(Number(value || 0)).toLocaleString()} ${t('currency')}`;

export default function RevenueTerminal() {
  const { t, lang } = useTranslation();
  const [products, setProducts] = useState<Product[]>([]);
  const [recent, setRecent] = useState<Sale[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [cart, setCart] = useState<Record<string, number>>({});
  const [receipt, setReceipt] = useState<Sale | null>(null);
  const [query, setQuery] = useState('');
  const [memberQuery, setMemberQuery] = useState('');
  const [barcode, setBarcode] = useState('');
  const [category, setCategory] = useState('all');
  const [discount, setDiscount] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState<'CASH' | 'CARD' | 'WALLET' | 'BANK' | 'OTHER'>('CASH');
  const [busy, setBusy] = useState(true);
  const [paying, setPaying] = useState(false);
  const [err, setErr] = useState('');
  const searchRef = useRef<HTMLInputElement>(null);
  const barcodeRef = useRef<HTMLInputElement>(null);

  const moneyLabel = (v: any) => formatMoney(v, t);

  async function load() {
    setBusy(true);
    try {
      const [p, s] = await Promise.all([
        api<Product[]>('/products').catch(() => []),
        api<{ items: Sale[] }>('/sales?limit=8').then((r) => r.items || []).catch(() => []),
      ]);
      setProducts(p);
      setRecent(s);
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => { load(); }, []);

  useEffect(() => {
    let cancelled = false;
    async function searchMembers() {
      if (memberQuery.trim().length < 2) { setMembers([]); return; }
      const res = await api<{ items: Member[] }>(`/members?q=${encodeURIComponent(memberQuery)}&limit=5`).catch(() => ({ items: [] }));
      if (!cancelled) setMembers(res.items || []);
    }
    const t = setTimeout(searchMembers, 160);
    return () => { cancelled = true; clearTimeout(t); };
  }, [memberQuery]);

  const categories = useMemo(() => ['all', ...Array.from(new Set(products.map((p) => p.category || 'other')))], [products]);
  const filtered = useMemo(() => {
    const q = query.toLowerCase().trim();
    return products
      .filter((p) => category === 'all' || (p.category || 'other') === category)
      .filter((p) => !q || `${p.name} ${p.barcode || ''}`.toLowerCase().includes(q))
      .sort((a, b) => Number(Boolean(b.qty)) - Number(Boolean(a.qty)) || Number(a.qty <= (a.lowAlert || 0)) - Number(b.qty <= (b.lowAlert || 0)) || a.name.localeCompare(b.name));
  }, [products, query, category]);

  const items = Object.entries(cart)
    .map(([id, qty]) => ({ product: products.find((p) => p.id === id), qty }))
    .filter((row): row is { product: Product; qty: number } => Boolean(row.product));
  const subtotal = items.reduce((sum, row) => sum + Number(row.product.price) * row.qty, 0);
  const appliedDiscount = Math.min(Math.max(discount || 0, 0), subtotal);
  const tax = 0;
  const total = subtotal - appliedDiscount + tax;

  const lowStockItems = items.filter((row) => row.product.qty - row.qty <= (row.product.lowAlert || 0));
  const frequentlySold = products.filter((p) => p.qty > 0).slice(0, 6);
  const recommendations = useMemo(() => {
    const recs: Product[] = [];
    if (selectedMember?.status === 'expired' || selectedMember?.status === 'soon') {
      recs.push(...products.filter((p) => /protein|water|bar|drink/i.test(p.name)).slice(0, 2));
    }
    recs.push(...frequentlySold.filter((p) => !cart[p.id]).slice(0, 4));
    return Array.from(new Map(recs.map((p) => [p.id, p])).values()).slice(0, 5);
  }, [selectedMember, products, frequentlySold, cart]);

  const add = (id: string) => {
    const p = products.find((x) => x.id === id);
    if (!p || p.qty <= (cart[id] || 0)) return;
    setCart((current) => ({ ...current, [id]: (current[id] || 0) + 1 }));
  };
  const sub = (id: string) => setCart((current) => {
    const next = { ...current, [id]: (current[id] || 0) - 1 };
    if (next[id] <= 0) delete next[id];
    return next;
  });
  const clearSale = () => { setCart({}); setDiscount(0); setSelectedMember(null); setMemberQuery(''); setErr(''); barcodeRef.current?.focus(); };

  function submitBarcode() {
    const code = barcode.trim();
    if (!code) return;
    const p = products.find((item) => item.barcode === code || item.name.toLowerCase().includes(code.toLowerCase()));
    if (!p) { setErr(`${t('no_results_found')}: ${code}`); return; }
    add(p.id);
    setBarcode('');
    setErr('');
  }

  async function checkout() {
    if (!items.length || paying) return;
    setErr('');
    setPaying(true);
    try {
      const sale = await api<Sale>('/sales', {
        method: 'POST',
        body: JSON.stringify({
          memberId: selectedMember?.id,
          discount: appliedDiscount,
          paymentMethod,
          paymentStatus: 'PAID',
          idempotencyKey: `pos-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
          items: items.map(({ product, qty }) => ({ productId: product.id, qty })),
        }),
      });
      setReceipt(sale);
      setCart({});
      setDiscount(0);
      await load();
    } catch (e: unknown) {
      setErr((e as Error).message || t('operation_failed'));
    } finally {
      setPaying(false);
    }
  }

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === '/' && !['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement)?.tagName)) { e.preventDefault(); searchRef.current?.focus(); }
      if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') { e.preventDefault(); checkout(); }
      if (e.key === 'F2') { e.preventDefault(); barcodeRef.current?.focus(); }
      if (e.key === 'Escape' && receipt) setReceipt(null);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [items, receipt, paying, selectedMember, discount]);

  return (
    <Shell>
      <div className="revenue-terminal">
        <section className="terminal-topbar">
          <div className="terminal-search-cluster">
            <label>
              <span>{t('product_search')}</span>
              <input ref={searchRef} className="input" placeholder={`${t('search')}...`} value={query} onChange={(e) => setQuery(e.target.value)} />
            </label>
            <label>
              <span>{t('barcode')}</span>
              <div className="terminal-inline-input">
                <input ref={barcodeRef} className="input" placeholder={`${t('barcode')}...`} value={barcode} onChange={(e) => setBarcode(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && submitBarcode()} />
                <button className="btn btn-secondary px-3" onClick={submitBarcode}>{t('add')}</button>
              </div>
            </label>
            <label>
              <span>{t('member')}</span>
              <input className="input" placeholder={t('lookup_member')} value={memberQuery} onChange={(e) => setMemberQuery(e.target.value)} />
            </label>
          </div>
          <div className="terminal-quick-actions">
            <button className="btn btn-ghost px-3 py-2" onClick={clearSale}>{t('cancel')}</button>
            <button className="btn btn-primary px-4 py-2" onClick={checkout} disabled={!items.length || paying}>{paying ? `${t('processing')}...` : `${t('checkout')} ⌘↵`}</button>
          </div>
          {members.length > 0 && (
            <div className="terminal-member-results">
              {members.map((m) => <button key={m.id} onClick={() => { setSelectedMember(m); setMemberQuery(m.name); setMembers([]); }}><b>{m.name}</b><span>{m.mobile}</span></button>)}
            </div>
          )}
        </section>

        {err && <FeedbackLayer type="danger" title={t('checkout_needs_recovery')} detail={err} action={<button className="btn btn-ghost px-3 py-1.5 text-xs" onClick={() => setErr('')}>{t('close')}</button>} />}

        <section className="terminal-grid">
          <main className="terminal-catalog">
            <div className="terminal-section-head">
              <div><span>{t('products')}</span><h2>{t('fast_sale_surface')}</h2><p>{t('interactions_desc')}</p></div>
              <div className="terminal-shortcuts">
                <kbd className="kbd">/</kbd> {t('search')} &nbsp;
                <kbd className="kbd">F2</kbd> {t('barcode')} &nbsp;
                <kbd className="kbd">⌘↵</kbd> {t('payment')}
              </div>
            </div>

            <div className="terminal-categories">
              {categories.map((c) => <button key={c} className={c === category ? 'active' : ''} onClick={() => setCategory(c)}>{t(c) || c}</button>)}
            </div>

            <div className="terminal-recommendations">
              <span>{t('smart_upsell')}</span>
              {recommendations.length ? recommendations.map((p) => <button key={p.id} onClick={() => add(p.id)}>{p.icon || '•'} {p.name}<b>{moneyLabel(p.price)}</b></button>) : <span className="terminal-muted">{t('recent_transactions_appear')}</span>}
            </div>

            {busy ? <div className="terminal-product-grid"><Skeleton /><Skeleton /><Skeleton /><Skeleton /><Skeleton /><Skeleton /></div> : filtered.length ? (
              <div className="terminal-product-grid">
                {filtered.map((p) => {
                  const inCart = cart[p.id] || 0;
                  const isLow = p.qty <= (p.lowAlert || 0);
                  return (
                    <button key={p.id} disabled={p.qty <= inCart} onClick={() => add(p.id)} className="terminal-product-card" data-low={isLow || undefined}>
                      <div className="terminal-product-icon">{p.icon || '◼'}</div>
                      <div className="terminal-product-name">{p.name}</div>
                      <div className="terminal-product-price">{moneyLabel(p.price)}</div>
                      <div className="terminal-product-stock">{p.qty <= inCart ? t('sold_out_cart') : `${p.qty - inCart} ${t('available_qty_label')}`}</div>
                      {isLow && <span className="risk-indicator" data-level="high">{t('low_stock')}</span>}
                    </button>
                  );
                })}
              </div>
            ) : (
              <EmptyState icon="search" title={t('no_products_match')} description={t('scan_start_checkout')} />
            )}
          </main>

          <aside className="terminal-cart-panel">
            <Card padding="lg" className="terminal-cart-card">
              <div className="terminal-section-head compact"><div><span>{t('active_cart')}</span><h2>{moneyLabel(total)}</h2><p>{items.length} {t('item_types')} · {items.reduce((s, i) => s + i.qty, 0)} {t('units')}</p></div></div>

              {selectedMember ? (
                <div className="terminal-member-card">
                  <b>{selectedMember.name}</b>
                  <span>{selectedMember.plan?.name || t('no_plan')} · {t('st_' + selectedMember.status) || selectedMember.status}</span>
                  <small>{selectedMember.expiry ? `${t('expiry')} ${formatDate(selectedMember.expiry)}` : t('no_expiry')} · {selectedMember.sessionsLeft ?? '—'} {t('sessions')}</small>
                </div>
              ) : (
                <div className="terminal-member-card muted"><b>{t('no_member_selected')}</b><span>{t('associate_member_desc')}</span></div>
              )}

              {items.length === 0 ? <EmptyState icon="coins" title={t('ready_next_sale')} description={t('scan_start_checkout')} /> : (
                <div className="terminal-cart-items">
                  {items.map(({ product, qty }) => (
                    <div key={product.id} className="terminal-cart-row">
                      <div>
                        <b>{product.name}</b>
                        <span>{moneyLabel(product.price)} {t('each')} × {qty} = <strong className="text-white">{moneyLabel(Number(product.price) * qty)}</strong></span>
                      </div>
                      <div className="terminal-qty"><button onClick={() => sub(product.id)}>−</button><strong>{qty}</strong><button onClick={() => add(product.id)}>+</button></div>
                    </div>
                  ))}
                </div>
              )}

              <div className="terminal-totals">
                <div><span>{t('subtotal')}</span><b>{moneyLabel(subtotal)}</b></div>
                <div className="terminal-discount-row">
                  <span>{t('discount')}</span>
                  <div className="flex gap-2 items-center">
                    <input className="input w-24" type="number" min={0} value={discount} onChange={(e) => setDiscount(Number(e.target.value || 0))} />
                    <span className="text-xs text-silver-dim">{t('currency')}</span>
                  </div>
                  {appliedDiscount > 0 && <b className="text-[var(--success)]">− {moneyLabel(appliedDiscount)}</b>}
                </div>
                <div><span>{t('tax')}</span><b>{moneyLabel(tax)}</b></div>
                <div className="terminal-payment-methods">
                  <span>{t('payment')}</span>
                  <div className="flex flex-wrap justify-end gap-1">
                    {(['CASH', 'CARD', 'WALLET', 'BANK', 'OTHER'] as const).map((m) => (
                      <button key={m} className={`btn px-2 py-1 text-[11px] ${paymentMethod === m ? 'btn-secondary text-white' : 'btn-ghost'}`} onClick={() => setPaymentMethod(m)}>
                        {label(m, 'paymentMethod', lang === 'en' ? 'en' : 'ar')}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="grand"><span>{t('total_due')}</span><b>{moneyLabel(total)}</b></div>
              </div>

              {lowStockItems.length > 0 && <FeedbackLayer type="warning" title={t('inventory_needs_attention')} detail={`${lowStockItems.length} ${t('low_stock_after_sale')}`} />}

              <div className="terminal-payment-actions">
                <button className="btn btn-primary" onClick={checkout} disabled={!items.length || paying}>{paying ? `${t('processing')}...` : t('complete_payment')}</button>
                <button className="btn btn-secondary" onClick={() => setDiscount(Math.round(subtotal * 0.1))} disabled={!items.length}>{t('apply_loyalty')}</button>
              </div>
            </Card>
          </aside>
        </section>

        <section className="terminal-bottom">
          <Card padding="md">
            <div className="terminal-section-head compact"><div><span>{t('recent_transactions')}</span><h2>{t('recovery_continuity')}</h2><p>{t('pos_bottom_desc')}</p></div></div>
            <div className="terminal-recent-list">
              {recent.length ? recent.map((s) => <button key={s.id} onClick={() => setReceipt(s)}><b>{s.invoiceNo}</b><span>{moneyLabel(s.total)}</span><small>{s.createdAt ? new Date(s.createdAt).toLocaleTimeString() : t('now')}</small></button>) : <span className="terminal-muted">{t('recent_transactions_appear')}</span>}
            </div>
          </Card>
        </section>
      </div>

      {receipt && (
        <ModalPortal>
        <div className="fixed inset-0 bg-black/70 grid place-items-center p-5 z-50" onClick={() => setReceipt(null)}>
          <div className="terminal-receipt-success" onClick={(e) => e.stopPropagation()}>
            <div className="terminal-success-mark">✓</div>
            <p className="product-eyebrow">{t('payment_complete')}</p>
            <h2>{receipt.invoiceNo}</h2>
            <strong>{moneyLabel(receipt.total)}</strong>
            <div className="terminal-receipt-lines">
              {(receipt.items || []).map((i) => <div key={i.id}><span>{i.qty}× {i.name}</span><b>{moneyLabel(Number(i.price) * i.qty)}</b></div>)}
            </div>
            <div className="terminal-receipt-actions">
              <button className="btn btn-secondary" onClick={() => window.print()}>{t('print')}</button>
              <a className="btn btn-secondary" href={`https://wa.me/?text=${encodeURIComponent(`FLEXORA receipt ${receipt.invoiceNo}: ${moneyLabel(receipt.total)}`)}`} target="_blank" rel="noopener noreferrer">{t('whatsapp')}</a>
              <a className="btn btn-secondary" href={`mailto:?subject=FLEXORA receipt ${receipt.invoiceNo}&body=${encodeURIComponent(`Receipt ${receipt.invoiceNo}: ${moneyLabel(receipt.total)}`)}`}>{t('email')}</a>
              <button className="btn btn-primary" onClick={() => { setReceipt(null); clearSale(); }}>{t('new_sale')}</button>
            </div>
          </div>
        </div>
        </ModalPortal>
      )}
    </Shell>
  );
}
