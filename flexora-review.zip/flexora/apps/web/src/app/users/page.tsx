/**
 * FLEXORA Gym OS
 * © 2024 Ammar Allam. All rights reserved.
 */
'use client';
import { useCallback, useEffect, useState } from 'react';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { useTranslation, translateKey } from '@/lib/i18n';
import { FeedbackLayer, InsightCard, InsightLayer, ProductPage, SmartTable } from '@/components/ProductOS';
import { Skeleton } from '@/components/ui/States';
import { safeErrorMessage } from '@/lib/safe-error';
import { ModalPortal } from '@/components/ModalPortal';
import { isUnrestrictedRole } from '@/lib/branch-scope';

interface User {
  id: string; name: string; email: string; phone?: string | null; role: string; active: boolean;
  branchId?: string | null;
  branch?: { name: string };
}
interface Branch { id: string; name: string; }

/**
 * PACK 2, item 1: permission labels come from the dictionary, not from the API's
 * English catalogue. The API label is only a fallback for a permission the
 * server gained before the web dictionary caught up — and the unit test
 * permission-labels.test.ts fails the build in that case, so it never ships.
 */
function permissionLabel(t: (k: string) => string, key: string, apiLabel: string): string {
  const k = 'perm_' + key.replace(/\./g, '_');
  const fromDict = t(k);
  return fromDict === k ? apiLabel : fromDict;
}

export default function Users() {
  const { t } = useTranslation();
  const [items, setItems] = useState<User[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<Partial<User & { password?: string; branchId?: string | null }> | null>(null);
  const [err, setErr] = useState('');
  const [success, setSuccess] = useState('');
  // Phase 4 (4.4): branch assignment is managed HERE, inline per employee,
  // against branches that actually exist — not guessed during onboarding.
  const [savingBranch, setSavingBranch] = useState<string | null>(null);
  /**
   * PHASE 2: per-field reasons from the API's structured 400
   * ({ errors: [{ field, message, translationKey }] }), so the user is told
   * WHICH field is wrong and WHY instead of getting a generic failure.
   */
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  // ROUND 13 (Phase 5): the per-employee Permissions panel. Only the OWNER
  // can manage permissions (the API enforces it too); the panel is hidden for
  // everyone else. Grouped checkboxes + "reset to role defaults".
  const [me, setMe] = useState<{ id?: string; role?: string } | null>(null);
  const [permCatalog, setPermCatalog] = useState<{
    groups: { key: string; label: string; permissions: string[] }[];
    permissions: { key: string; label: string; group: string }[];
  } | null>(null);
  const [permTarget, setPermTarget] = useState<User | null>(null);
  const [permData, setPermData] = useState<{
    defaults: string[]; overrides: { permission: string; granted: boolean }[]; effective: string[];
  } | null>(null);
  const [permDraft, setPermDraft] = useState<Set<string>>(new Set());
  const [permSaving, setPermSaving] = useState(false);
  const isOwner = me?.role === 'OWNER';

  useEffect(() => {
    api<any>('/auth/me').then((r) => setMe(r?.user || null)).catch(() => setMe(null));
    api<any>('/permissions/catalog')
      .then((c) => setPermCatalog(c))
      .catch(() => setPermCatalog(null));
  }, []);

  async function openPerms(u: User) {
    setPermTarget(u);
    setPermData(null);
    setPermDraft(new Set());
    try {
      const d = await api<any>(`/permissions/users/${u.id}`);
      setPermData(d);
      setPermDraft(new Set(d.effective || []));
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    }
  }

  async function savePerms() {
    if (!permTarget || !permData) return;
    setPermSaving(true);
    try {
      const changes: { permission: string; granted: boolean }[] = [];
      for (const p of permCatalog?.permissions || []) {
        const want = permDraft.has(p.key);
        const has = (permData.effective || []).includes(p.key);
        if (want !== has) changes.push({ permission: p.key, granted: want });
      }
      if (!changes.length) { setPermTarget(null); return; }
      const res = await api<any>(`/permissions/users/${permTarget.id}`, {
        method: 'PUT',
        body: JSON.stringify({ changes }),
      });
      setPermData((d) => (d ? { ...d, effective: res?.after || d.effective } : d));
      setPermDraft(new Set(res?.after || permDraft));
      setSuccess(t('permissions_saved') || 'Permissions saved');
      setTimeout(() => setSuccess(''), 3000);
      setPermTarget(null);
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    } finally {
      setPermSaving(false);
    }
  }

  async function resetPerms() {
    if (!permTarget) return;
    setPermSaving(true);
    try {
      const res = await api<any>(`/permissions/users/${permTarget.id}/reset`, { method: 'POST' });
      setPermData((d) => (d ? { ...d, effective: res?.after || d.defaults, overrides: [] } : d));
      setPermDraft(new Set(res?.after || []));
      setSuccess(t('permissions_reset') || 'Permissions reset to role defaults');
      setTimeout(() => setSuccess(''), 3000);
      setPermTarget(null);
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    } finally {
      setPermSaving(false);
    }
  }

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [u, b] = await Promise.all([api<any>('/users'), api<any>('/branches')]);
      setItems(Array.isArray(u) ? u : (u.items || []));
      setBranches(Array.isArray(b) ? b : (b.items || []));
    } catch (e: unknown) { setErr(safeErrorMessage(e)); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!form) return; setErr(''); setFieldErrors({});
    /**
     * The modal form is `noValidate`: the browser's own "please fill out this
     * field" bubble (in the browser's language, silently blocking submit) is
     * what made the add-employee button look dead. Every rule is checked here
     * instead, in the app's language, and the API's own reasons are shown for
     * anything we cannot know client-side.
     */
    const nameParts = String(form.name || '').trim().split(/\s+/).filter(Boolean);
    if (nameParts.length < 3) {
      const msg = t('error_staff_name_parts');
      setFieldErrors({ name: msg });
      setErr(`${t('full_name')}: ${msg}`);
      return;
    }
    if (!form.email || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email)) {
      const msg = t('error_invalid_email');
      setFieldErrors({ email: msg });
      setErr(`${t('email')}: ${msg}`);
      return;
    }
    if (!form.id && !form.password) {
      const msg = t('error_required_field');
      setFieldErrors({ password: msg });
      setErr(`${t('password')}: ${msg}`);
      return;
    }
    // P1: staff phone must be a valid Egyptian mobile (same rule the API
    // enforces) — block the submit with an instant, clear message.
    if (form.phone && !/^(010|011|012|015)\d{8}$/.test(form.phone.trim())) {
      setErr(t('eg_phone_hint') || 'Mobile number must be 11 digits and start with 010, 011, 012 or 015');
      return;
    }
    // PHASE 4: only OWNER and MANAGER can work across every branch. Every
    // other role is pinned to a single branch by the API, so a branch must be
    // chosen — otherwise the account could not see anything at all.
    if (!isUnrestrictedRole(form.role) && !form.branchId) {
      setErr(t('staff_branch_required') || 'Select a branch: only Owner and General Manager roles can work across all branches.');
      return;
    }
    // Success toast fires ONLY after the API returns 2xx — no false "success"
    // on a failed create (previously the toast could appear without the row
    // ever existing, and the list was not guaranteed to reflect the new row).
    try {
      const payload: Record<string, unknown> = {
        name: form.name, email: form.email, role: form.role,
        phone: form.phone || undefined,
        branchId: form.branchId || undefined, active: form.active,
        ...(!form.id && form.password ? { password: form.password } : {}),
      };
      if (form.id) await api(`/users/${form.id}`, { method: 'PATCH', body: JSON.stringify(payload) });
      else await api('/users', { method: 'POST', body: JSON.stringify(payload) });
      setForm(null);
      setSuccess(t('success') || 'Saved successfully');
      setTimeout(() => setSuccess(''), 3000);
      await load();
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
      const issues = (e as any)?.errors;
      if (Array.isArray(issues) && issues.length) {
        const map: Record<string, string> = {};
        for (const issue of issues) {
          const text = issue?.translationKey ? translateKey(issue.translationKey) : issue?.message;
          if (issue?.field && text && !map[issue.field]) map[issue.field] = text;
        }
        setFieldErrors(map);
      }
    }
  }
  async function assignBranch(id: string, branchId: string) {
    setErr(''); setSavingBranch(id);
    // Optimistic UI, then reload from the server so the row shows the value the
    // API actually stored (never a fake success).
    try {
      await api(`/users/${id}/branch`, { method: 'PATCH', body: JSON.stringify({ branchId: branchId || null }) });
      setSuccess(t('branch_updated'));
      setTimeout(() => setSuccess(''), 3000);
      await load();
    } catch (e: unknown) { setErr(safeErrorMessage(e)); }
    finally { setSavingBranch(null); }
  }
  async function toggle(id: string) {
    try { await api(`/users/${id}/toggle`, { method: 'PATCH' }); load(); }
    catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }
  async function del(id: string) {
    if (!confirm(t('confirm_delete'))) return;
    try { await api(`/users/${id}`, { method: 'DELETE' }); load(); }
    catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }

  return (
    <Shell>
      <ProductPage
        eyebrow={t('staff')}
        title={t('staff')}
        narrative={t('staff_description')}
        primaryAction={{ label: t('add_staff'), icon: 'plus', onClick: () => setForm({ role: 'RECEPTION' }) }}
      >
        <InsightLayer>
          <InsightCard label={t('staff_count')} value={items.length} icon="users" detail={t('registered_team_members')} />
        </InsightLayer>
        {err && <FeedbackLayer type="danger" title={t('operation_failed')} detail={err} />}
        {success && <FeedbackLayer type="success" title={t('success')} detail={success} />}
        {loading ? <Skeleton lines={5} /> : (
          <SmartTable
            columns={[t('name'), t('email'), t('phone'), t('role'), t('branch'), t('status'), t('actions')]}
            rows={items}
            emptyTitle={t('no_staff')}
            emptyDescription={t('invite_staff')}
            renderRow={(u) => (
              <tr key={u.id}>
                <td>{u.name}</td>
                <td>{u.email}</td>
                <td dir="ltr">{u.phone || '—'}</td>
                <td>{t(u.role === 'OWNER' ? 'owner' : u.role === 'MANAGER' ? 'manager' : u.role === 'RECEPTION' ? 'reception' : u.role === 'COACH' ? 'coach' : u.role === 'ACCOUNTANT' ? 'accountant' : u.role === 'SUPER_ADMIN' ? 'super_admin' : u.role)}</td>
                <td>
                  <select
                    className="input py-1 text-xs min-w-[140px]"
                    aria-label={t('assign_branch')}
                    disabled={savingBranch === u.id}
                    value={u.branchId || ''}
                    onChange={(e) => assignBranch(u.id, e.target.value)}
                  >
                    {/* PHASE 4: "All branches" is only valid for the two
                        cross-branch roles; the API rejects an unpinned
                        restricted role, so do not offer it here either. */}
                    {isUnrestrictedRole(u.role)
                      ? <option value="">{t('all_branches')}</option>
                      : <option value="">{t('select_branch')}</option>}
                    {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
                  </select>
                </td>
                <td><button onClick={() => toggle(u.id)} className={`badge ${u.active ? 'badge-active' : 'badge-expired'}`}>{u.active ? t('active') : t('inactive')}</button></td>
                <td><span className="row-actions inline-flex gap-2">
                  {isOwner && u.role !== 'OWNER' && (
                    <button
                      className="btn-ghost btn-sm"
                      data-testid={`staff-perms-${u.id}`}
                      onClick={() => openPerms(u)}
                    >{t('permissions') || 'Permissions'}</button>
                  )}
                  {me && u.id === me.id ? (
                    /* ROUND 14 (security review, PHASE A): your own account is
                       edited on the self-service profile card (the staff form
                       refuses self password/email changes and the OWNER row is
                       protected) — send the user there instead. */
                    <a className="btn-ghost btn-sm" data-testid={`staff-profile-${u.id}`} href="/settings">{t('my_profile') || 'My profile'}</a>
                  ) : (
                    <>
                      <button className="btn-ghost btn-sm" onClick={() => setForm(u)}>{t('edit')}</button><button className="btn-danger btn-sm" onClick={() => del(u.id)}>{t('delete')}</button>
                    </>
                  )}</span></td>
              </tr>
            )}
          />
        )}
      </ProductPage>

      {form && (
        <ModalPortal>
        <div className="fixed inset-0 bg-black/70 grid place-items-center p-5 z-50" onClick={() => setForm(null)}>
          <form noValidate onClick={(e) => e.stopPropagation()} onSubmit={save} className="card card-static glass w-full max-w-lg max-h-[90vh] overflow-auto">
            <h3 className="text-title text-white mb-1">{form.id ? t('edit_user') : t('new_staff')}</h3>
            <p className="text-xs text-[var(--silver-dim)] mb-5">{t('staff_form_desc') || 'One block per employee — each field is explained below.'}</p>
            <div className="grid gap-4">
              <div>
                <label className="text-label text-[var(--silver-dim)] mb-1 block">{t('full_name')} <span className="text-[var(--danger)]">*</span></label>
                <input className="input w-full" placeholder={t('full_name')} value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                <p className="text-[10px] text-[var(--silver-muted)] mt-1">{t('staff_name_help') || 'Full name as it appears on payroll/roster (first middle last).'}</p>
                {fieldErrors.name && <p className="text-[11px] text-[var(--danger)] mt-1">{fieldErrors.name}</p>}
              </div>
              <div>
                <label className="text-label text-[var(--silver-dim)] mb-1 block">{t('email')} <span className="text-[var(--danger)]">*</span></label>
                <input className="input w-full" dir="ltr" placeholder="name@gym.com" type="email" value={form.email || ''} onChange={(e) => setForm({ ...form, email: e.target.value })} disabled={!!form.id} />
                <p className="text-[10px] text-[var(--silver-muted)] mt-1">{t('staff_email_help') || 'Login email for this employee. Cannot be changed after creation.'}</p>
                {fieldErrors.email && <p className="text-[11px] text-[var(--danger)] mt-1">{fieldErrors.email}</p>}
              </div>
              <div>
                <label className="text-label text-[var(--silver-dim)] mb-1 block">{t('phone')}</label>
                <input className="input w-full" dir="ltr" type="tel" inputMode="numeric" maxLength={11} pattern="01[0125][0-9]{8}" placeholder="01xxxxxxxxx" value={form.phone || ''} onChange={(e) => setForm({ ...form, phone: e.target.value.replace(/[^\d]/g, '').slice(0, 11) })} />
                <p className="text-[10px] text-[var(--silver-muted)] mt-1">{t('staff_phone_help')}</p>
                {fieldErrors.phone && <p className="text-[11px] text-[var(--danger)] mt-1">{fieldErrors.phone}</p>}
              </div>
              {!form.id && (
                <div>
                  <label className="text-label text-[var(--silver-dim)] mb-1 block">{t('password')} <span className="text-[var(--danger)]">*</span></label>
                  <input className="input w-full" type="password" placeholder="••••••••" onChange={(e) => setForm({ ...form, password: e.target.value })} />
                  <p className="text-[10px] text-[var(--silver-muted)] mt-1">{t('staff_password_help') || 'At least 8 characters, mixed letters and numbers.'}</p>
                  {fieldErrors.password && <p className="text-[11px] text-[var(--danger)] mt-1">{fieldErrors.password}</p>}
                </div>
              )}
              <div>
                <label className="text-label text-[var(--silver-dim)] mb-1 block">{t('role')} <span className="text-[var(--danger)]">*</span></label>
                {/* ROUND 13 (security review, PHASE A): rank rules — nobody may
                    create/assign an OWNER (only the ownership-transfer flow may),
                    and only an OWNER may create/assign a MANAGER. Do not offer
                    roles the acting user is not allowed to assign. */}
                <select className="input w-full" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
                  {isOwner && <option value="MANAGER">{t('manager')}</option>}
                  <option value="RECEPTION">{t('reception')}</option>
                  <option value="COACH">{t('coach')}</option>
                  <option value="ACCOUNTANT">{t('accountant')}</option>
                  {isOwner && <option value="OWNER">{t('owner')}</option>}
                </select>
                <p className="text-[10px] text-[var(--silver-muted)] mt-1">{t('staff_role_help') || 'What this employee is allowed to do: Manager runs the gym, Reception handles front desk & check-ins, Coach teaches classes, Accountant sees money reports only.'}</p>
              </div>
              <div>
                <label className="text-label text-[var(--silver-dim)] mb-1 block">
                  {t('branch')} {!isUnrestrictedRole(form.role) && <span className="text-[var(--danger)]">*</span>}
                </label>
                <select
                  className="input w-full"
                  data-testid="staff-branch-select"
                  value={form.branchId || ''}
                  onChange={(e) => setForm({ ...form, branchId: e.target.value || null })}
                >
                  {/* PHASE 4: "All branches" is only a real option for the two
                      cross-branch roles; every other role must be pinned. */}
                  {isUnrestrictedRole(form.role)
                    ? <option value="">{t('all_branches')}</option>
                    : <option value="">{t('select_branch') || '— اختر الفرع —'}</option>}
                  {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
                </select>
                <p className="text-[10px] text-[var(--silver-muted)] mt-1">
                  {isUnrestrictedRole(form.role)
                    ? (t('staff_branch_help') || 'The branch this employee works at. Choose a specific branch to filter their check-ins and sales — "All branches" gives access to every branch.')
                    : (t('staff_branch_help_restricted') || 'This role is limited to ONE branch — it has no branch picker and cannot see any other branch\'s members, inventory or attendance.')}
                </p>
                {fieldErrors.branchId && <p className="text-[11px] text-[var(--danger)] mt-1">{fieldErrors.branchId}</p>}
              </div>
            </div>
            {/* PHASE 2: the page-level feedback layer sits BEHIND this modal's
                overlay, so a rejected create looked like nothing happened. The
                reason must be readable right where the user is looking. */}
            {err && (
              <div
                role="alert"
                className="mt-4 rounded-xl border border-[var(--danger)]/40 bg-[var(--danger)]/10 p-3 text-xs leading-relaxed text-[var(--danger)]"
              >
                {err}
              </div>
            )}
            <div className="flex gap-2 justify-end mt-5 pt-4 border-t border-[var(--border)]">
              <button type="button" className="btn-ghost" onClick={() => setForm(null)}>{t('cancel')}</button>
              <button className="btn-primary">{t('save')}</button>
            </div>
          </form>
        </div>
        </ModalPortal>
      )}

      {/* ROUND 13 (Phase 5): per-employee Permissions panel — grouped
          checkboxes over the permission catalog, plus reset-to-role-defaults.
          Only the OWNER sees the button (the API rejects anyone else). */}
      {permTarget && (
        <ModalPortal>
        <div className="fixed inset-0 bg-black/70 grid place-items-center p-5 z-50" onClick={() => setPermTarget(null)}>
          <div className="card card-static glass w-full max-w-2xl max-h-[90vh] overflow-auto" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-title text-white mb-1" data-testid="staff-perms-panel">
              {t('permissions') || 'Permissions'} — {permTarget.name}
            </h3>
            <p className="text-xs text-[var(--silver-dim)] mb-4">
              {t('permissions_panel_desc') || 'Choose exactly what this employee can do. Changes apply immediately — the API enforces them on every request.'}
            </p>
            {permData && permCatalog ? (
              <div className="grid gap-4">
                {permCatalog.groups.map((g) => (
                  <div key={g.key} data-testid={`staff-perms-group-${g.key}`}>
                    <p className="text-label text-[var(--silver-dim)] mb-2">{t('permgroup_' + g.key) === 'permgroup_' + g.key ? g.label : t('permgroup_' + g.key)}</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {permCatalog.permissions
                        .filter((p) => p.group === g.key)
                        .map((p) => {
                          const checked = permDraft.has(p.key);
                          const isDefault = (permData.defaults || []).includes(p.key);
                          const overridden = (permData.overrides || []).some((o) => o.permission === p.key);
                          return (
                            <label key={p.key} className="flex items-center gap-2 rounded-lg border border-[var(--border)] px-3 py-2 text-sm cursor-pointer">
                              <input
                                type="checkbox"
                                data-testid={`staff-perm-checkbox-${p.key}`}
                                checked={checked}
                                onChange={(e) => {
                                  const next = new Set(permDraft);
                                  if (e.target.checked) next.add(p.key); else next.delete(p.key);
                                  setPermDraft(next);
                                }}
                              />
                              <span className="flex-1">{permissionLabel(t, p.key, p.label)}</span>
                              {overridden && (
                                <span className="text-[10px] px-1.5 py-0.5 rounded bg-[var(--brand)]/20 text-[var(--brand)]">
                                  {isDefault ? (t('custom_on') || 'custom: on') : (t('custom_off') || 'custom: off')}
                                </span>
                              )}
                            </label>
                          );
                        })}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <Skeleton lines={5} />
            )}
            {err && <div role="alert" className="mt-4 rounded-xl border border-[var(--danger)]/40 bg-[var(--danger)]/10 p-3 text-xs text-[var(--danger)]">{err}</div>}
            <div className="flex gap-2 justify-between mt-5 pt-4 border-t border-[var(--border)]">
              <button
                className="btn-ghost"
                data-testid="staff-perms-reset"
                disabled={permSaving || !permData}
                onClick={resetPerms}
              >{t('reset_to_role_defaults') || 'Reset to role defaults'}</button>
              <span className="flex gap-2">
                <button className="btn-ghost" onClick={() => setPermTarget(null)}>{t('cancel')}</button>
                <button
                  className="btn-primary"
                  data-testid="staff-perms-save"
                  disabled={permSaving || !permData}
                  onClick={savePerms}
                >{t('save')}</button>
              </span>
            </div>
          </div>
        </div>
        </ModalPortal>
      )}
    </Shell>
  );
}
