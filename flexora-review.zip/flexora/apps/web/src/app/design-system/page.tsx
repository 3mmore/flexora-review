/**
 * FLEXORA Gym OS — Design System Reference
 * © 2024 Ammar Allam. All rights reserved.
 */
'use client';
import Link from 'next/link';
import { Logo } from '@/components/brand/Logo';
import { Icon } from '@/components/brand/Icon';
import { Button } from '@/components/ui/Button';
import { Card } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { Skeleton } from '@/components/ui/States';
import { StatusBadge } from '@/components/ui/StatusBadge';
import { useTranslation } from '@/lib/i18n';
import { buttonVariantLabel } from '@/lib/i18n/features';

const BRAND_COLORS = [
  { name: 'الذهبي (الأساسي)', value: 'var(--brand)', usage: 'الإجراءات الأساسية · التركيز · الإبرازات' },
  { name: 'الذهبي الهادئ', value: 'var(--brand-dim)', usage: 'المرور · حالة الضغط' },
  { name: 'توهّج ذهبي', value: 'rgba(var(--brand-rgb),.15)', usage: 'الهالات · حلقات التركيز · الظلال' },
  { name: 'قاعدة دافئة', value: '#141312', usage: 'خلفية الصفحة' },
  { name: 'فضي', value: '#e9e1dd', usage: 'النص الأساسي' },
  { name: 'فضي هادئ', value: '#97908c', usage: 'النص الثانوي' },
  { name: 'فضي خافت', value: '#4b4643', usage: 'المعطّل · الحدود' },
];
const SURFACES = [
  { name: 'bg-base', value: '#141312', depth: 'الطبقة 0 — الصفحة' },
  { name: 'bg-surface', value: '#1d1b1a', depth: 'الطبقة 1 — البطاقات' },
  { name: 'bg-elevated', value: '#1d1b1a', depth: 'الطبقة 2 — النشط والمرور' },
  { name: 'bg-overlay', value: '#23201e', depth: 'الطبقة 3 — النوافذ' },
];
const SEMANTIC = [
  { name: 'نجاح', value: '#00E5A0', usage: 'نشط · مدفوع · إيجابي' },
  { name: 'تحذير', value: '#F5A623', usage: 'قارب على الانتهاء · يحتاج انتباه' },
  { name: 'خطر', value: '#FF4D6A', usage: 'إجراء هدّام · أخطاء' },
  { name: 'معلومة', value: 'var(--brand)', usage: 'معلوماتي — يتبع لون الصالة' },
];
const TYPE_SCALE = [
  { cls: 'text-display', label: 'عنوان ضخم', css: '48px / 800 / -1.5px', sample: '1,280,000 ج.م' },
  { cls: 'text-heading', label: 'عنوان', css: '28px / 700 / -0.5px', sample: 'صحة الاشتراكات' },
  { cls: 'text-title', label: 'عنوان فرعي', css: '18px / 600 / -0.2px', sample: 'مسار الإيراد' },
  { cls: 'text-body', label: 'نص', css: '14px / 400 / 1.6', sample: 'الإيراد والاحتفاظ والحضور في شاشة واحدة.' },
  { cls: 'text-label', label: 'تسمية', css: '12px / 500 / +0.4px', sample: 'مركز القيادة التنفيذي' },
  { cls: 'text-mono', label: 'أحادي المسافة', css: '13px / أحادي', sample: 'FLEX-A1B2-C3D4' },
];
const RADII = [
  { name: 'radius-sm', value: '8px' }, { name: 'radius-md', value: '12px' },
  { name: 'radius-lg', value: '16px' }, { name: 'radius-xl', value: '20px' },
];
const SPACING = [4, 8, 12, 16, 24, 32, 48, 64];
const ICONS: Parameters<typeof Icon>[0]['name'][] = [
  'dumbbell','circuit','qr-scan','bio','bell','chart','coins','shield','calendar',
  'users','search','plus','check','x','menu','home','cog','logout','arrow-right',
  'arrow-down','lightning','sparkle','send','image','menu-grid',
];

function Swatch({ name, value, usage }: { name: string; value: string; usage: string }) {
  return (
    <div className="ds-swatch">
      <div className="ds-swatch-chip" style={{ background: value, boxShadow: value.startsWith('rgba') ? `inset 0 0 0 1px var(--border)` : 'none' }} />
      <div className="ds-swatch-body">
        <b>{name}</b>
        <code>{value}</code>
        <div style={{ fontSize: 11, color: 'var(--silver-muted)', marginTop: 4 }}>{usage}</div>
      </div>
    </div>
  );
}

export default function DesignSystemPage() {
  const { t, lang } = useTranslation();
  return (
    <div className="ds-wrap" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
      <Link href="/dashboard" className="ds-back">
        <Icon name="arrow-right" size={14} className={lang === 'ar' ? '' : 'rotate-180'} /> {t('back_to_workspace')}
      </Link>

      <header className="ds-hero">
        <div style={{ marginBottom: 20 }}><Logo variant="full" size={150} tone="dark" /></div>
        <span className="ds-eyebrow">{t('design_system_truth')}</span>
        <h1>{t('flex_excellence')}</h1>
      </header>

      <section className="ds-section">
        <div className="ds-section-head"><h2>{t('brand_colors')}</h2></div>
        <div className="ds-grid ds-swatches">
          {BRAND_COLORS.map((c) => <Swatch key={c.name} {...c} />)}
        </div>
      </section>

      <section className="ds-section">
        <div className="ds-section-head"><h2>{t('layered_surfaces')}</h2></div>
        <div className="ds-grid ds-swatches">
          {SURFACES.map((c) => <Swatch key={c.name} name={c.name} value={c.value} usage={c.depth} />)}
        </div>
      </section>

      <section className="ds-section">
        <div className="ds-section-head"><h2>{t('semantic')}</h2></div>
        <div className="ds-grid ds-swatches">
          {SEMANTIC.map((c) => <Swatch key={c.name} {...c} />)}
        </div>
      </section>

      <section className="ds-section">
        <div className="ds-section-head"><h2>{t('typography')}</h2></div>
        <Card padding="lg">
          {TYPE_SCALE.map((t_row) => (
            <div className="ds-type-row" key={t_row.cls}>
              <p className={`ds-type-sample ${t_row.cls}`}>{t_row.sample}</p>
              <code>{t_row.label} — {t_row.css}</code>
            </div>
          ))}
        </Card>
      </section>

      <section className="ds-section">
        <div className="ds-section-head"><h2>{t('radius_system')}</h2></div>
        <div className="ds-grid ds-radius-grid">
          {RADII.map((r) => (
            <div className="ds-radius-cell" key={r.name}>
              <div className="ds-radius-box" style={{ borderRadius: r.value }} />
              <span>{r.name} · {r.value}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="ds-section">
        <div className="ds-section-head"><h2>{t('spacing_system')}</h2></div>
        <Card padding="lg">
          {SPACING.map((s) => (
            <div className="ds-row" key={s}>
              <span className="ds-row-label">{s}px</span>
              <div className="ds-demo"><div className="ds-spacing-bar" style={{ width: s * 3 }} /></div>
            </div>
          ))}
        </Card>
      </section>

      <section className="ds-section">
        <div className="ds-section-head"><h2>{t('buttons')}</h2></div>
        <Card padding="lg">
          {(['primary','secondary','danger','ghost'] as const).map((v) => (
            <div className="ds-row" key={v}>
              <span className="ds-row-label">{buttonVariantLabel(v, lang === 'en' ? 'en' : 'ar')}</span>
              <div className="ds-demo">
                <Button variant={v} size="sm" icon={<Icon name="plus" size={12} />}>{t('sm')}</Button>
                <Button variant={v} size="md" icon={<Icon name="plus" size={13} />}>{t('md')}</Button>
                <Button variant={v} size="lg" icon={<Icon name="plus" size={14} />}>{t('lg')}</Button>
                <Button variant={v} size="md" loading>{t('loading')}</Button>
              </div>
            </div>
          ))}
        </Card>
      </section>

      <section className="ds-section">
        <div className="ds-section-head"><h2>{t('status_badges')}</h2></div>
        <Card padding="lg">
          <div className="ds-demo" style={{ gap: 14 }}>
            <StatusBadge tone="success" dot>{t('active')}</StatusBadge>
            <StatusBadge tone="warning" dot>{t('st_soon')}</StatusBadge>
            <StatusBadge tone="danger" dot>{t('expired')}</StatusBadge>
            <StatusBadge tone="info" dot>{t('sub_trialing')}</StatusBadge>
            <StatusBadge tone="neutral">{t('frozen')}</StatusBadge>
          </div>
        </Card>
      </section>

      <section className="ds-section">
        <div className="ds-section-head"><h2>{t('cards')}</h2></div>
        <div className="ds-grid ds-card-grid">
          <Card variant="default" title={t('none')} />
          <Card variant="elevated" title={t('platform')} />
          <Card variant="glow" title={t('sparkle')} />
        </div>
      </section>

      <section className="ds-section">
        <div className="ds-section-head"><h2>{t('form_fields')}</h2></div>
        <Card padding="lg">
          <div className="ds-grid" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))' }}>
            <Input label={t('email')} type="email" placeholder={t('email_placeholder')} />
            <Input label={t('mobile')} icon="qr-scan" placeholder={t('phone_mask')} dir="ltr" />
          </div>
        </Card>
      </section>

      <section className="ds-section">
        <div className="ds-section-head"><h2>{t('loading_feedback')}</h2></div>
        <Card padding="lg">
          <div className="ds-demo" style={{ flexDirection: 'column', alignItems: 'stretch', gap: 18 }}>
            <Skeleton lines={3} />
          </div>
        </Card>
      </section>

      <section className="ds-section">
        <div className="ds-section-head"><h2>{t('iconography')}</h2></div>
        <div className="ds-grid ds-icon-grid">
          {ICONS.map((n) => (
            <div className="ds-icon-cell" key={n}>
              <Icon name={n} size={22} />
              <span>{n}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="ds-section">
        <div className="ds-section-head"><h2>{t('logo_system')}</h2></div>
        <div className="ds-grid ds-card-grid">
          <Card padding="lg"><div className="ds-demo" style={{ justifyContent: 'center', padding: 24 }}><Logo variant="full" size={140} /></div></Card>
          <Card padding="lg"><div className="ds-demo" style={{ justifyContent: 'center', padding: 24 }}><Logo variant="mark" size={56} /></div></Card>
        </div>
      </section>

      <section className="ds-section">
        <div className="ds-section-head"><h2>{t('motion_rules')}</h2></div>
      </section>
    </div>
  );
}
