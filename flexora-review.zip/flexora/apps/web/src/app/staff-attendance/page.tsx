/**
 * FLEXORA Workforce Intelligence Center
 * Staff attendance transformed into workforce performance, coaching impact and reliability intelligence.
 */
'use client';
import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { ActionCenter, FeedbackLayer, InsightCard, InsightLayer, ProductPage, SmartAction, SmartTable } from '@/components/ProductOS';
import { Card } from '@/components/ui/Card';
import { EmptyState, Skeleton } from '@/components/ui/States';
import { Icon } from '@/components/brand/Icon';
import { safeErrorMessage } from '@/lib/safe-error';
import { useTranslation } from '@/lib/i18n';
import { fmtMoney } from '@/lib/money';

type StaffAttendance = {
  id: string;
  userId: string;
  checkInAt: string;
  checkOutAt?: string;
  method: string;
  notes?: string;
  // P2-3: computed at check-in against the staff member's shift schedule
  expectedAt?: string | null;
  lateMinutes?: number | null;
  user?: { id?: string; name: string; role: string };
};
type StaffShift = {
  id: string;
  userId?: string | null;
  name?: string | null;
  dayOfWeek: number;
  start: string;
  end: string;
  graceMin: number;
  active: boolean;
  user?: { id: string; name: string; role: string } | null;
};
type User = { id: string; name: string; email?: string; role: string; active?: boolean; branchId?: string };
type CoachStat = { coachId: string; coachName: string; sessions: number; revenue: number };
type PtSession = { id: string; coachId: string; scheduledAt: string; status: string; price?: number | string; coach?: { name: string }; member?: { name: string } };
type Sale = { id: string; total?: number | string; userName?: string; createdAt?: string };

const money = (v?: number | string) => fmtMoney(v);
const durationMinutes = (row: StaffAttendance) => row.checkOutAt ? Math.max(0, Math.round((+new Date(row.checkOutAt) - +new Date(row.checkInAt)) / 60000)) : Math.max(0, Math.round((Date.now() - +new Date(row.checkInAt)) / 60000));
const reliabilityScore = (attendanceCount: number, openShifts: number) => Math.max(0, Math.min(100, attendanceCount * 14 - openShifts * 8));

export default function StaffIntelligenceCenter() {
  const { t } = useTranslation();
  const [today, setToday] = useState<StaffAttendance[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [coachStats, setCoachStats] = useState<CoachStat[]>([]);
  const [ptSessions, setPtSessions] = useState<PtSession[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [shifts, setShifts] = useState<StaffShift[]>([]);
  const [busy, setBusy] = useState(true);
  const [err, setErr] = useState('');
  const [feedback, setFeedback] = useState('');
  const [showShiftForm, setShowShiftForm] = useState(false);
  const [shiftForm, setShiftForm] = useState({ userId: '', dayOfWeek: new Date().getDay(), start: '09:00', end: '17:00', graceMin: 15, name: '' });

  const toMin = (hhmm: string) => { const [h, m] = hhmm.split(':').map(Number); return (h || 0) * 60 + (m || 0); };

  async function load() {
    setBusy(true); setErr('');
    try {
      // ROUND 13 (Phase 1): every panel is loaded independently — one denied
      // endpoint (e.g. /pt/sessions or /sales for a role without them) must
      // degrade to an empty panel, never fail the whole page. Previously a
      // single 403 in this Promise.all left RECEPTION/COACH with an error
      // screen and no self check-in at all.
      const [attendanceRows, userRows, statRows, ptRows, saleRows, shiftRows] = await Promise.all([
        api<StaffAttendance[]>('/staff-attendance/today'),
        api<User[]>('/users').catch(() => []),
        api<CoachStat[]>('/pt/coach-stats').catch(() => []),
        api<{ items: PtSession[] }>('/pt/sessions?limit=100').then((r) => r.items || []).catch(() => []),
        api<{ items: Sale[] }>('/sales?limit=100').then((r) => r.items || []).catch(() => []),
        api<StaffShift[]>('/staff-attendance/shifts').catch(() => []),
      ]);
      setToday(attendanceRows); setUsers(userRows); setCoachStats(statRows); setPtSessions(ptRows); setSales(saleRows); setShifts(shiftRows);
    } catch (e: unknown) { setErr((e as Error).message || t('operation_failed')); }
    finally { setBusy(false); }
  }
  useEffect(() => { load(); }, []);

  async function addShift() {
    setErr(''); setFeedback('');
    try {
      await api('/staff-attendance/shifts', { method: 'POST', body: JSON.stringify({
        userId: shiftForm.userId || undefined, name: shiftForm.name || undefined,
        dayOfWeek: shiftForm.dayOfWeek, startMin: toMin(shiftForm.start), endMin: toMin(shiftForm.end), graceMin: shiftForm.graceMin,
      }) });
      setShowShiftForm(false); setFeedback(t('saved') || 'Saved'); load();
    } catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }

  async function deleteShift(id: string) {
    setErr('');
    try { await api(`/staff-attendance/shifts/${id}`, { method: 'DELETE' }); load(); }
    catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }

  async function checkIn() {
    try { await api('/staff-attendance/check-in', { method: 'POST' }); setFeedback(t('check_in_success') || 'Checked in'); load(); }
    catch (e: unknown) { setErr(safeErrorMessage(e)); }
  }

  const activeStaff = today.filter((row) => !row.checkOutAt);
  const staffUsers = users.filter((u) => u.role !== 'SUPER_ADMIN');
  const attendanceRate = staffUsers.length ? Math.round((new Set(today.map((row) => row.userId)).size / staffUsers.length) * 100) : 0;
  const ptRevenue = coachStats.reduce((sum, row) => sum + Number(row.revenue || 0), 0);
  const salesInfluenced = sales.reduce((sum, sale) => sum + Number(sale.total || 0), 0);

  return (
    <Shell>
      <ProductPage
        eyebrow={t('staff')}
        title={t('staff_execution')}
        narrative={`${activeStaff.length} ${t('staff')} ${t('active')}.`}
        primaryAction={{ label: t('checkin'), icon: 'plus', onClick: checkIn }}
      >
        {err && <FeedbackLayer type="danger" title={t('operation_failed')} detail={err} action={<button className="btn btn-ghost px-3 py-1.5 text-xs" onClick={load}>{t('retry')}</button>} />}
        
        <InsightLayer>
          {busy ? <Skeleton lines={1} /> : <>
            <InsightCard label={t('active_floor_now')} value={activeStaff.length} detail={`${staffUsers.length} ${t('total')}`} icon="users" />
            <InsightCard label={t('attendance_rate')} value={`${attendanceRate}%`} detail={t('attendance_rate')} icon="home" />
            <InsightCard label={t('revenue_influenced')} value={money(ptRevenue + salesInfluenced)} detail={t('revenue_influenced')} icon="coins" />
          </>}
        </InsightLayer>

        <ActionCenter title={t('actions_column')}>
          <SmartAction title={t('checkin')} detail={t('check_in')} onClick={checkIn} icon="plus" />
        </ActionCenter>

        <section className="staff-intel-grid">
          <Card padding="lg">
            <div className="product-section-head"><div><h2>{t('staff_execution')}</h2></div></div>
            {busy ? <Skeleton lines={7} /> : <div className="staff-list">{today.map((row) => (
              <div key={row.id} className="mb-3"><b>{row.user?.name}</b><span>{row.user?.role}</span></div>
            ))}</div>}
          </Card>
        </section>

        <SmartTable
          columns={[t('staff'), t('role'), t('date'), t('status'), t('late')]}
          rows={today}
          loading={busy}
          emptyTitle={t('no_staff_activity')}
          emptyDescription={t('clock_ins_appear')}
          renderRow={(a: StaffAttendance) => {
            const lateness = a.lateMinutes == null
              ? <span className="text-white/40 text-xs">{t('no_shift')}</span>
              : a.lateMinutes === 0
                ? <span className="text-emerald-400 text-xs font-semibold">✓ {t('on_time')}</span>
                : <span className="text-red-400 text-xs font-semibold">⏰ {t('late_by')} {a.lateMinutes} {t('minutes')}</span>;
            return (
              <tr key={a.id}>
                <td>{a.user?.name}</td>
                <td>{a.user?.role}</td>
                <td>{new Date(a.checkInAt).toLocaleString()}</td>
                <td>{a.checkOutAt ? t('checked_out') : t('on_shift')}</td>
                <td>{lateness}</td>
              </tr>
            );
          }}
        />

        {/* P2-3: shift schedules */}
        <Card padding="lg" className="mt-6">
          <div className="product-section-head">
            <div>
              <h2>{t('shift_schedule')}</h2>
              <p className="text-xs text-white/50">{t('shifts_desc')}</p>
            </div>
            <button className="btn btn-primary px-3 py-1.5 text-xs" onClick={() => setShowShiftForm((s) => !s)}>{t('add_shift')}</button>
          </div>

          {showShiftForm && (
            <div className="grid grid-cols-2 md:grid-cols-6 gap-2 mb-4 p-3 rounded-lg bg-white/5 border border-white/10">
              <select className="rounded-md bg-black/40 border border-white/15 px-2 py-1.5 text-xs" value={shiftForm.userId} onChange={(e) => setShiftForm({ ...shiftForm, userId: e.target.value })}>
                <option value="">{t('all_staff')}</option>
                {staffUsers.map((u) => <option key={u.id} value={u.id}>{u.name} ({u.role})</option>)}
              </select>
              <select className="rounded-md bg-black/40 border border-white/15 px-2 py-1.5 text-xs" value={shiftForm.dayOfWeek} onChange={(e) => setShiftForm({ ...shiftForm, dayOfWeek: Number(e.target.value) })}>
                {[0, 1, 2, 3, 4, 5, 6].map((d) => <option key={d} value={d}>{t(`day_${d}`)}</option>)}
              </select>
              <input type="time" className="rounded-md bg-black/40 border border-white/15 px-2 py-1.5 text-xs" value={shiftForm.start} onChange={(e) => setShiftForm({ ...shiftForm, start: e.target.value })} aria-label={t('start_time')} />
              <input type="time" className="rounded-md bg-black/40 border border-white/15 px-2 py-1.5 text-xs" value={shiftForm.end} onChange={(e) => setShiftForm({ ...shiftForm, end: e.target.value })} aria-label={t('end_time')} />
              <input type="number" min={0} max={240} className="rounded-md bg-black/40 border border-white/15 px-2 py-1.5 text-xs" value={shiftForm.graceMin} onChange={(e) => setShiftForm({ ...shiftForm, graceMin: Number(e.target.value) })} placeholder={t('grace_minutes')} aria-label={t('grace_minutes')} />
              <button className="btn btn-primary px-3 py-1.5 text-xs" onClick={addShift}>{t('add_shift')}</button>
            </div>
          )}

          {busy ? <Skeleton lines={3} /> : shifts.length === 0 ? (
            <EmptyState title={t('no_shift')} description={t('shifts_desc')} />
          ) : (
            <table className="w-full text-sm">
              <thead><tr className="text-left text-white/50 text-xs border-b border-white/10">
                <th className="py-2">{t('staff')}</th><th>{t('date')}</th><th>{t('start_time')}</th><th>{t('end_time')}</th><th>{t('grace_minutes')}</th><th></th>
              </tr></thead>
              <tbody>
                {shifts.map((s) => (
                  <tr key={s.id} className="border-b border-white/5">
                    <td className="py-2">{s.user ? `${s.user.name} (${s.user.role})` : t('all_staff')}{s.name ? ` — ${s.name}` : ''}</td>
                    <td>{t(`day_${s.dayOfWeek}`)}</td>
                    <td dir="ltr">{s.start}</td>
                    <td dir="ltr">{s.end}</td>
                    <td>{s.graceMin} {t('minutes')}</td>
                    <td className="text-right"><button className="text-red-400/80 text-xs hover:text-red-300" onClick={() => deleteShift(s.id)}>{t('delete')}</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
      </ProductPage>
    </Shell>
  );
}
