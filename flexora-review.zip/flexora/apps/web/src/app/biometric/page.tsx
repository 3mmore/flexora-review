'use client';
import { OperationalResourcePage } from '@/components/OperationalResourcePage';
import { useTranslation } from '@/lib/i18n';

/**
 * P2-2: This page lists WebAuthn passkeys (the member's OWN device
 * fingerprint / Face ID / security key) registered from the member app.
 * It is NOT a camera or facial-recognition gate — camera face recognition
 * is out of scope for FLEXORA.
 */
export default function Page() {
  const { t } = useTranslation();
  return <OperationalResourcePage config={{ queryKey: 'biometric', endpoint: '/biometric/members/current/credentials', eyebrow: t('biometric_eyebrow'), title: t('biometric_auth'), narrative: t('biometric_narrative'), columns: [{ key: 'id', label: t('member') }, { key: 'deviceName', label: t('device_name') }, { key: 'createdAt', label: t('date') }] }} />;
}
