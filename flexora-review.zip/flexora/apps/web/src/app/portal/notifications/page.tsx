'use client';
/**
 * FLEXORA Gym OS — Member Notification Center
 * © 2024 Ammar Allam. All rights reserved.
 */
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { portalApi, getMemberToken } from '@/lib/portal';
import { safeErrorMessage } from '@/lib/safe-error';
import { useTranslation } from '@/lib/i18n';

type NotifItem = { id: string; channel: string; subject: string | null; body: string; createdAt: string; isRead: boolean };
type NotifData = { items: NotifItem[]; unreadCount: number };

export default function PortalNotifications() {
  const router = useRouter();
  const { t, lang } = useTranslation();
  const [data, setData] = useState<NotifData | null>(null);
  const [err, setErr] = useState('');

  const load = () => portalApi<NotifData>('/portal/notifications').then(setData).catch((e) => setErr(safeErrorMessage(e)));

  useEffect(() => {
    if (!getMemberToken()) { router.replace('/portal/login'); return; }
    load();
  }, [router]);

  async function markRead(id: string) {
    try { await portalApi(`/portal/notifications/${id}/read`, { method: 'POST' }); load(); } catch { /* ignore */ }
  }

  const CHANNEL_ICON: Record<string, string> = { WHATSAPP: '💬', SMS: '📱', EMAIL: '✉️', INAPP: '🔔' };

  return (
    <div dir={lang === 'ar' ? 'rtl' : 'ltr'} className="min-h-screen p-4" style={{ background: 'var(--bg)', color: 'var(--text)' }}>
      <div className="max-w-md mx-auto">
        <div className="flex items-center gap-3 py-3">
          <button className="btn-ghost text-sm" onClick={() => router.push('/portal/dashboard')}>{t('back')}</button>
          <div className="font-extrabold flex-1">{t('my_notifications')}</div>
          {data && data.unreadCount > 0 && <span className="text-xs text-[var(--cyan)] font-bold">{data.unreadCount} {t('unread_label')}</span>}
        </div>
        {err && <div className="text-red-400 text-sm">{err}</div>}
        {!data ? <div className="text-[var(--muted)]">{t('loading')}</div> : (
          <div className="space-y-2">
            {data.items.length === 0 ? <div className="card text-center text-[var(--muted)]">{t('no_notifications')}</div> : data.items.map((n) => (
              <div key={n.id} className="card" style={n.isRead ? { opacity: 0.6 } : { borderLeft: '3px solid var(--cyan)' }}>
                <div className="flex items-start gap-2">
                  <span className="text-lg">{CHANNEL_ICON[n.channel] || '🔔'}</span>
                  <div className="flex-1">
                    {n.subject && <div className="font-bold text-sm">{n.subject}</div>}
                    <div className="text-sm text-[var(--muted)]">{n.body}</div>
                    <div className="text-xs text-[var(--muted)] mt-1">{new Date(n.createdAt).toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-US')}</div>
                  </div>
                  {!n.isRead && <button className="btn-ghost text-xs" onClick={() => markRead(n.id)}>{t('mark_read')}</button>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
