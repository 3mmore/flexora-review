'use client';
/**
 * FLEXORA Gym OS — Member Digital Card
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Displays a printable, dark-mode-compatible member card with QR code.
 * QR payload encodes: { g, m } where g=gymId, m=memberId — scannable
 * at the gym entrance for check-in.
 */
import { useEffect, useState } from 'react';
import { formatDate } from '@/lib/dates';
import { useRouter } from 'next/navigation';
import { portalApi, getMemberToken } from '@/lib/portal';
import { safeErrorMessage } from '@/lib/safe-error';
import { useTranslation } from '@/lib/i18n';
import { QrCode } from '@/components/QrCode';
import { localizePlanName } from '@/lib/plan-label';

type MemberInfo = {
  id: string;
  code: string;
  name: string;
  mobile: string;
  vip: boolean;
  status: string;
  subscription: {
    planName: string | null;
    planType: string | null;
    expiry: string | null;
    sessionsLeft: number | null;
    frozen: boolean;
  };
  branch: string | null;
};

export default function MemberCard() {
  const router = useRouter();
  const { t, lang } = useTranslation();
  const [me, setMe] = useState<MemberInfo | null>(null);
  const [err, setErr] = useState('');

  useEffect(() => {
    if (!getMemberToken()) { router.replace('/portal/login'); return; }
    portalApi<MemberInfo>('/portal/me').then(setMe).catch((e) => setErr(safeErrorMessage(e)));
  }, [router]);

  if (err) return <div className="p-4 text-center text-red-400">{err}</div>;
  if (!me) return <div className="p-4 text-center" style={{ color: 'var(--silver-dim)' }}>{t('loading')}</div>;

  // ROUND 14 (Phase E): a REAL, scannable QR whose payload is the member's
  // unique code — exactly what the entrance check-in scanner consumes
  // (CheckinDto.memberCode). The old decorative pattern encoded nothing.
  const qrPayload = me.code;
  const stLabel = t(me.status.toLowerCase()) || me.status;

  return (
    <div dir={lang === 'ar' ? 'rtl' : 'ltr'} style={{ padding: 16, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
      <style>{`@media print { body * { visibility: hidden; } .print-card, .print-card * { visibility: visible; } .print-card { position: absolute; top: 0; left: 50%; transform: translateX(-50%); } nav, .offline-banner { display: none !important; } }`}</style>

      {/* Member Card */}
      <div
        className="print-card"
        style={{
          width: '100%',
          maxWidth: 360,
          borderRadius: 20,
          overflow: 'hidden',
          background: 'linear-gradient(135deg, var(--bg-surface) 0%, var(--bg-elevated) 60%, #23201e 100%)',
          border: '1px solid rgba(var(--brand-rgb),0.15)',
          boxShadow: '0 0 40px rgba(var(--brand-rgb),0.08), 0 8px 32px rgba(0,0,0,0.6)',
        }}
      >
        {/* Card header */}
        <div style={{ padding: '20px 24px 12px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/icon-192.png" alt="FLEXORA" style={{ width: 28, height: 28, borderRadius: 6 }} onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
            <span style={{ fontWeight: 800, fontSize: 13, letterSpacing: '0.05em', color: 'var(--brand)' }}>FLEXORA</span>
          </div>
          <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--silver-dim, #7a95ad)' }}>{t('membership')}</span>
        </div>

        {/* Member info */}
        <div style={{ padding: '8px 24px 20px' }}>
          <div style={{ fontSize: 22, fontWeight: 800, color: '#fff', marginBottom: 4 }}>{me.name}{me.vip && <span style={{ color: 'var(--brand)' }}> ★</span>}</div>
          <div style={{ fontSize: 13, color: 'var(--silver-dim, #7a95ad)', marginBottom: 12, fontFamily: 'monospace' }} dir="ltr">{me.mobile}</div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 16 }}>
            <div>
              <div style={{ fontSize: 10, color: 'var(--silver-muted, #3d5166)', textTransform: 'uppercase' }}>{t('plan_label')}</div>
              <div style={{ fontSize: 14, fontWeight: 700, color: '#fff' }}>{localizePlanName(me.subscription.planName || '', lang) || '—'}</div>
            </div>
            <div>
              <div style={{ fontSize: 10, color: 'var(--silver-muted, #3d5166)', textTransform: 'uppercase' }}>{t('expiry_label')}</div>
              <div style={{ fontSize: 14, fontWeight: 700, color: '#fff' }}>
                {me.subscription.expiry ? formatDate(me.subscription.expiry) : '—'}
              </div>
            </div>
          </div>

          {/* Status badge */}
          <div style={{ marginBottom: 16 }}>
            <span className={`status-pill status-${me.status.toLowerCase()}`}>
              {stLabel}
            </span>
            {me.subscription.sessionsLeft != null && (
              <span style={{ marginLeft: 8, fontSize: 12, color: 'var(--silver-dim)' }}>{me.subscription.sessionsLeft} {t('sessions')}</span>
            )}
          </div>

          {/* QR Code */}
          <div style={{ display: 'flex', justifyContent: 'center', padding: '12px', background: '#fff', borderRadius: 12 }}>
            <QrCode payload={qrPayload} size={180} testId="member-card-qr" />
          </div>
          <div style={{ textAlign: 'center', marginTop: 8, fontSize: 10, color: 'var(--silver-muted)' }}>{t('scan_at_entrance')}</div>
        </div>
      </div>

      {/* Print button */}
      <button
        onClick={() => window.print()}
        style={{
          marginTop: 20,
          padding: '10px 32px',
          borderRadius: 12,
          border: '1px solid rgba(var(--brand-rgb),0.2)',
          background: 'rgba(var(--brand-rgb),0.06)',
          color: 'var(--brand)',
          fontWeight: 700,
          fontSize: 14,
          cursor: 'pointer',
        }}
      >
        🖨️ {t('print_card')}
      </button>
    </div>
  );
}
