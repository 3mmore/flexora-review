'use client';
/**
 * FLEXORA Gym OS — Offline banner (member portal)
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Detects navigator.onLine and online/offline events. Shows a fixed,
 * mobile-friendly banner while offline and auto-hides on reconnect.
 */
import { useEffect, useState } from 'react';
import { useTranslation } from '@/lib/i18n';

export default function OfflineBanner() {
  const { t, lang } = useTranslation();
  const [offline, setOffline] = useState(false);

  useEffect(() => {
    const update = () => setOffline(!navigator.onLine);
    update();
    window.addEventListener('online', update);
    window.addEventListener('offline', update);
    return () => {
      window.removeEventListener('online', update);
      window.removeEventListener('offline', update);
    };
  }, []);

  if (!offline) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      dir={lang === 'ar' ? 'rtl' : 'ltr'}
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        zIndex: 60,
        background: '#b91c1c',
        color: '#fff',
        textAlign: 'center',
        padding: '8px 12px',
        fontSize: 13,
        fontWeight: 700,
        boxShadow: '0 2px 8px rgba(0,0,0,.35)',
      }}
    >
      {t('offline_banner_text')}
    </div>
  );
}
