'use client';
/**
 * FLEXORA Gym OS — Member Portal Layout
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Provides:
 *   - SW registration + offline detection banner
 *   - Native-style bottom navigation (Home, Classes, Attendance, Wallet, Profile)
 *   - iPhone/Android safe-area padding
 *   - Consistent FLEXORA dark branding
 */
import { useEffect, useState, useMemo } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import Link from 'next/link';
import { getMemberToken } from '@/lib/portal';
import { useTranslation } from '@/lib/i18n';

const PUBLIC_ROUTES = ['/portal/login'];

export default function PortalChrome({ children }: { children: React.ReactNode }) {
  const { t, lang } = useTranslation();
  const pathname = usePathname();
  const router = useRouter();
  const [online, setOnline] = useState(true);
  const [swReady, setSwReady] = useState(false);

  const NAV = useMemo(() => [
    { href: '/portal/dashboard', label: t('nav_home'), icon: '🏠' },
    { href: '/portal/classes', label: t('nav_classes'), icon: '🏋️' },
    { href: '/portal/attendance', label: t('tab_visits'), icon: '📊' },
    { href: '/portal/financial', label: t('my_wallet'), icon: '💰' },
    { href: '/portal/member-card', label: t('my_card'), icon: '🪪' },
  ], [t]);

  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').then(() => setSwReady(true)).catch(() => {});
    }
  }, []);

  useEffect(() => {
    const update = () => setOnline(navigator.onLine);
    window.addEventListener('online', update);
    window.addEventListener('offline', update);
    return () => {
      window.removeEventListener('online', update);
      window.removeEventListener('offline', update);
    };
  }, []);

  const isPublic = PUBLIC_ROUTES.includes(pathname);
  const hasToken = getMemberToken();

  // Redirect to login if accessing protected route without token
  useEffect(() => {
    if (!isPublic && !hasToken) {
      router.replace('/portal/login');
    }
  }, [isPublic, hasToken, router]);

  const isActive = (href: string) => pathname === href || pathname.startsWith(href + '/');

  if (isPublic) return <>{children}</>;

  return (
    <div
      dir={lang === 'ar' ? 'rtl' : 'ltr'}
      className="min-h-screen"
      style={{
        background: 'var(--bg-base, #000000)',
        color: 'var(--silver, #c8d6e5)',
        fontFamily: 'var(--font-arabic, Cairo, sans-serif)',
        paddingBottom: 'calc(64px + env(safe-area-inset-bottom))',
      }}
    >
      {/* Offline banner */}
      {!online && (
        <div
          style={{
            background: 'rgba(245,166,35,0.15)',
            color: '#f5a623',
            textAlign: 'center',
            padding: '6px 12px',
            fontSize: 12,
            fontWeight: 600,
            position: 'sticky',
            top: 0,
            zIndex: 100,
            backdropFilter: 'blur(8px)',
          }}
        >
          ⚠️ {t('portal_offline_msg')}
        </div>
      )}

      {/* Content */}
      <div style={{ maxWidth: 480, margin: '0 auto' }}>{children}</div>

      {/* Bottom Navigation */}
      <nav
        style={{
          position: 'fixed',
          bottom: 0,
          left: 0,
          right: 0,
          height: 'calc(64px + env(safe-area-inset-bottom))',
          paddingBottom: 'env(safe-area-inset-bottom)',
          background: 'rgba(8,13,18,0.92)',
          backdropFilter: 'blur(20px)',
          borderTop: '1px solid rgba(var(--brand-rgb),0.1)',
          display: 'flex',
          justifyContent: 'space-around',
          alignItems: 'flex-start',
          paddingTop: 8,
          zIndex: 90,
        }}
      >
        {NAV.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 2,
              textDecoration: 'none',
              fontSize: 10,
              fontWeight: 600,
              padding: '4px 8px',
              borderRadius: 8,
              transition: 'color 150ms ease',
              color: isActive(item.href) ? 'var(--cyan)' : 'var(--silver-dim, #7a95ad)',
            }}
          >
            <span style={{ fontSize: 20, filter: isActive(item.href) ? 'drop-shadow(0 0 6px rgba(var(--brand-rgb),0.4))' : 'none' }}>
              {item.icon}
            </span>
            {item.label}
          </Link>
        ))}
      </nav>
    </div>
  );
}
