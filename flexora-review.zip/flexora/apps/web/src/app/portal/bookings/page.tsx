'use client';
/**
 * FLEXORA Gym OS — Member Booking History
 * © 2024 Ammar Allam. All rights reserved.
 */
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { portalApi, getMemberToken } from '@/lib/portal';
import { safeErrorMessage } from '@/lib/safe-error';
import { useTranslation } from '@/lib/i18n';

type Booking = { id: string; className: string; coachId: string | null; date: string; status: string; bookedAt: string };
type BookingHistory = { upcoming: Booking[]; past: Booking[]; cancelled: Booking[] };

export default function PortalBookings() {
  const router = useRouter();
  const { t, lang } = useTranslation();
  const [data, setData] = useState<BookingHistory | null>(null);
  const [err, setErr] = useState('');

  const STATUS_LABEL: Record<string, string> = { 
    CONFIRMED: t('confirmed'), 
    ATTENDED: t('attended'), 
    CANCELLED: t('cancelled_label') 
  };

  useEffect(() => {
    if (!getMemberToken()) { router.replace('/portal/login'); return; }
    portalApi<BookingHistory>('/portal/bookings').then(setData).catch((e) => setErr(safeErrorMessage(e)));
  }, [router]);

  const Section = ({ title, bookings }: { title: string; bookings: Booking[] }) => (
    <div className="card mb-4">
      <div className="font-bold mb-2">{title} ({bookings.length})</div>
      {bookings.length === 0 ? <div className="text-[var(--muted)] text-sm">{t('none')}</div> : bookings.map((b) => (
        <div key={b.id} className="flex justify-between py-2 text-sm border-t border-[var(--border)]">
          <div><div className="font-bold">{b.className}</div><div className="text-[var(--muted)] text-xs">{new Date(b.date).toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-US')}</div></div>
          <div className={`text-xs font-bold ${b.status === 'ATTENDED' ? 'text-emerald-400' : b.status === 'CANCELLED' ? 'text-red-400' : 'text-sky-400'}`}>{STATUS_LABEL[b.status] || b.status}</div>
        </div>
      ))}
    </div>
  );

  return (
    <div dir={lang === 'ar' ? 'rtl' : 'ltr'} className="min-h-screen p-4" style={{ background: 'var(--bg)', color: 'var(--text)' }}>
      <div className="max-w-md mx-auto">
        <div className="flex items-center gap-3 py-3">
          <button className="btn-ghost text-sm" onClick={() => router.push('/portal/dashboard')}>{t('back')}</button>
          <div className="font-extrabold flex-1">{t('my_bookings')}</div>
          <button className="btn text-xs px-3 py-1.5" onClick={() => router.push('/portal/classes')}>{t('book_class')}</button>
        </div>
        {err && <div className="text-red-400 text-sm">{err}</div>}
        {!data ? <div className="text-[var(--muted)]">{t('loading')}</div> : (
          <>
            <Section title={t('upcoming')} bookings={data.upcoming} />
            <Section title={t('past')} bookings={data.past} />
            <Section title={t('cancelled_label')} bookings={data.cancelled} />
          </>
        )}
      </div>
    </div>
  );
}
