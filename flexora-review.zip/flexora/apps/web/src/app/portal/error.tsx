'use client';
/**
 * FLEXORA Gym OS — Portal Error Boundary
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Catches unhandled render errors in any portal page, preventing a blank
 * screen. Provides a retry action and a safe fallback UI.
 */
import { useEffect } from 'react';
import { useTranslation } from '@/lib/i18n';

export default function PortalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  const { t, lang } = useTranslation();

  useEffect(() => {
    // Log to console for debugging (no sensitive data — error.message only)
    console.error('Portal render error:', error.message);
  }, [error]);

  return (
    <div
      dir={lang === 'ar' ? 'rtl' : 'ltr'}
      style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 24,
        textAlign: 'center',
        background: 'var(--bg-base, #000000)',
        color: 'var(--silver, #c8d6e5)',
        fontFamily: 'var(--font-arabic, Cairo, sans-serif)',
      }}
    >
      <div style={{ fontSize: 48, marginBottom: 16 }}>⚠️</div>
      <h2 style={{ fontSize: 18, fontWeight: 700, color: '#fff', marginBottom: 8 }}>
        {t('portal_error_title')}
      </h2>
      <p style={{ fontSize: 13, color: 'var(--silver-dim, #7a95ad)', maxWidth: 320, marginBottom: 20 }}>
        {t('portal_error_desc')}
      </p>
      <div style={{ display: 'flex', gap: 8 }}>
        <button
          onClick={reset}
          style={{
            padding: '10px 24px',
            borderRadius: 12,
            border: '1px solid rgba(var(--brand-rgb),0.25)',
            background: 'rgba(var(--brand-rgb),0.08)',
            color: 'var(--brand)',
            fontWeight: 700,
            fontSize: 14,
            cursor: 'pointer',
          }}
        >
          {t('retry')}
        </button>
        <a
          href="/portal/dashboard"
          style={{
            padding: '10px 24px',
            borderRadius: 12,
            border: '1px solid rgba(var(--brand-rgb),0.1)',
            background: 'transparent',
            color: 'var(--silver-dim, #7a95ad)',
            fontWeight: 600,
            fontSize: 14,
            textDecoration: 'none',
          }}
        >
          {t('home_page')}
        </a>
      </div>
    </div>
  );
}
