'use client';
/**
 * FLEXORA Gym OS — Member Executive Dashboard
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Redesigned executive summary — Apple Fitness × Stripe × Whoop style.
 * Single-screen overview: status, sessions, expiry, next booking.
 * Quick actions: Book, Renew, QR Card.
 */
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { portalApi, clearMemberSession, getMemberToken } from '@/lib/portal';
import { safeErrorMessage } from '@/lib/safe-error';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useTranslation } from '@/lib/i18n';
import { useBrand } from '@/context/BrandContext';
import { localizePlanName } from '@/lib/plan-label';
import { SelfCheckinCard } from '@/components/portal/SelfCheckin';

type Dashboard = {
  membership: {
    status: string; planName: string | null; planType: string | null;
    daysRemaining: number | null; sessionsLeft: number | null;
    expiry: string | null; renewalEligible: boolean; frozen: boolean;
  };
  nextClass: { className: string; date: string; status: string } | null;
  lastPayment: { amount: number; method: string; date: string; reference: string | null } | null;
  outstandingBalance: number;
  totalPaid: number;
  attendance: { totalVisits: number; monthVisits: number; lastVisit: string | null };
  unreadNotifications: number;
};

interface Session {
  id: string;
  scheduledAt: string;
  exercisesDone: { weight: number }[];
  memberProgress?: string;
}

export default function PortalDashboard() {
  const router = useRouter();
  const { t, lang, setLang } = useTranslation();
  const { brand } = useBrand();
  // recharts needs a real color string, so resolve the live accent here.
  const accent = brand.accentColor || brand.primaryColor || "#c5a059";
  const [data, setData] = useState<Dashboard | null>(null);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [err, setErr] = useState('');

  useEffect(() => {
    if (!getMemberToken()) { router.replace('/portal/login'); return; }
    portalApi<Dashboard>('/portal/dashboard').then(setData).catch((e: unknown) => setErr(safeErrorMessage(e)));
    portalApi<Session[]>('/pt/sessions/my?limit=8').then(setSessions).catch(() => {});
  }, [router]);

  if (err) return <div className="p-6 text-center text-red-400 text-sm">{err}</div>;
  if (!data) return <div className="p-6 text-center" style={{ color: 'var(--silver-dim)' }}>{t('loading')}</div>;

  return (
    <div style={{ padding: '12px 16px 24px' }}>
      {/* Top header bar */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16, paddingTop: 8 }}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/icon-192.png" alt="FLEXORA" style={{ width: 32, height: 32, borderRadius: 8 }} onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
        <span style={{ fontSize: 13, fontWeight: 800, letterSpacing: '0.05em', color: 'var(--brand)' }}>FLEXORA</span>
        <div style={{ flex: 1 }} />
        <button 
          onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}
          style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, color: 'var(--silver-dim)' }}
        >
          {lang === 'ar' ? 'EN' : 'AR'}
        </button>
        {data.unreadNotifications > 0 && (
          <button onClick={() => router.push('/portal/notifications')} style={{ position: 'relative', background: 'none', border: 'none', cursor: 'pointer', fontSize: 18 }}>
            🔔
            <span style={{ position: 'absolute', top: -4, right: -4, background: 'var(--brand)', color: '#000', fontSize: 9, fontWeight: 800, borderRadius: 999, width: 16, height: 16, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{data.unreadNotifications}</span>
          </button>
        )}
        <button onClick={() => { clearMemberSession(); router.replace('/portal/login'); }} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 16 }}>🚪</button>
      </div>

      {/* PACK 2 item 5: one tap to say "I'm here", when the gym enables it.
          Renders nothing at all when the owner has it off (the default). */}
      <SelfCheckinCard />

      {/* Membership hero card */}
      <div style={{
        borderRadius: 20, padding: 24, marginBottom: 12,
        background: 'linear-gradient(135deg, var(--bg-surface) 0%, var(--bg-elevated) 100%)',
        border: '1px solid rgba(var(--brand-rgb),0.12)',
        boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
          <div>
            <div style={{ fontSize: 11, color: 'var(--silver-muted, #3d5166)', textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: 4 }}>{t('subscription')}</div>
            <div style={{ fontSize: 22, fontWeight: 800, color: '#fff' }}>{localizePlanName(data.membership.planName || '', lang) || t('not_found')}</div>
          </div>
          <span className={`badge ${badgeClass(data.membership.status.toLowerCase())}`}>{t(data.membership.status.toLowerCase()) || data.membership.status}</span>
        </div>

        {/* Metrics row */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 28, fontWeight: 800, color: 'var(--brand)' }}>
              {data.membership.planType === 'SESSION' ? (data.membership.sessionsLeft ?? 0) : (data.membership.daysRemaining ?? 0)}
            </div>
            <div style={{ fontSize: 10, color: 'var(--silver-dim)' }}>{data.membership.planType === 'SESSION' ? t('sessions') : t('expiring_soon_label')}</div>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 28, fontWeight: 800, color: '#fff' }}>{data.attendance.monthVisits}</div>
            <div style={{ fontSize: 10, color: 'var(--silver-dim)' }}>{t('new_this_month')}</div>
          </div>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 16, fontWeight: 800, color: '#fff' }}>
              {data.membership.expiry ? new Date(data.membership.expiry).toLocaleDateString(lang === 'ar' ? 'ar-EG-u-nu-latn' : 'en-GB', { day: 'numeric', month: 'short' }) : '—'}
            </div>
            <div style={{ fontSize: 10, color: 'var(--silver-dim)' }}>{t('expiry')}</div>
          </div>
        </div>
      </div>

      {/* Quick actions */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, marginBottom: 12 }}>
        <QuickAction emoji="🏋️" label={t('classes')} onClick={() => router.push('/portal/classes')} />
        <QuickAction emoji="🔄" label={t('renew')} onClick={() => router.push('/portal/renew')} disabled={!data.membership.renewalEligible} />
        <QuickAction emoji="🪪" label={t('member')} onClick={() => router.push('/portal/member-card')} highlight />
      </div>

      {/* Next booking */}
      {data.nextClass && (
        <div style={{ borderRadius: 16, padding: 16, marginBottom: 8, background: 'var(--bg-surface)', border: '1px solid rgba(var(--brand-rgb),0.1)' }}>
          <div style={{ fontSize: 11, color: 'var(--silver-muted)', textTransform: 'uppercase', marginBottom: 4 }}>{t('upcoming_class')}</div>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#fff' }}>{data.nextClass.className}</div>
          <div style={{ fontSize: 12, color: 'var(--silver-dim)' }}>{new Date(data.nextClass.date).toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-US', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</div>
        </div>
      )}

      {/* Summary cards */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 12 }}>
        <SummaryCard emoji="💰" label={t('total_paid')} value={`${data.totalPaid.toLocaleString()} ${lang === 'ar' ? 'ج.م' : 'EGP'}`} color="#00e5a0" onClick={() => router.push('/portal/financial')} />
        <SummaryCard emoji="⚠️" label={t('outstanding_balance')} value={`${data.outstandingBalance.toLocaleString()} ${lang === 'ar' ? 'ج.م' : 'EGP'}`} color={data.outstandingBalance > 0 ? '#f5a623' : '#00e5a0'} onClick={() => router.push('/portal/financial')} />
        <SummaryCard emoji="📊" label={t('attendance')} value={String(data.attendance.totalVisits)} onClick={() => router.push('/portal/attendance')} />
        <SummaryCard emoji="📅" label={t('schedule')} value={t('view_bookings')} onClick={() => router.push('/portal/bookings')} />
      </div>

      {/* My Progress Section */}
      <div style={{
        borderRadius: 20, padding: 20, marginBottom: 12,
        background: 'var(--bg-surface)',
        border: '1px solid rgba(var(--brand-rgb),0.08)',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <h3 style={{ fontSize: 16, fontWeight: 700, color: '#fff' }}>{t('my_progress')}</h3>
          <button 
            onClick={() => window.open(`${process.env.NEXT_PUBLIC_API_URL || ''}/api/pt/sessions/my/export`, '_blank')}
            style={{ fontSize: 12, color: 'var(--brand)', background: 'none', border: 'none', cursor: 'pointer' }}
          >
            {t('download_pdf')} 📥
          </button>
        </div>

        {sessions.length > 0 ? (
          <>
            <div style={{ height: 180, width: '100%', marginBottom: 16 }}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={sessions.slice().reverse().map(s => ({ 
                  date: new Date(s.scheduledAt).toLocaleDateString(lang === 'ar' ? 'ar-EG-u-nu-latn' : 'en-GB', { day: 'numeric', month: 'short' }),
                  weight: s.exercisesDone?.[0]?.weight || 0 
                }))}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="date" stroke="var(--silver-muted)" fontSize={10} />
                  <YAxis stroke="var(--silver-muted)" fontSize={10} />
                  <Tooltip 
                    contentStyle={{ background: 'var(--bg-elevated)', border: '1px solid rgba(var(--brand-rgb),0.2)', borderRadius: 8 }}
                    itemStyle={{ color: 'var(--brand)' }}
                  />
                  <Line type="monotone" dataKey="weight" stroke={accent} strokeWidth={2} dot={{ fill: accent }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
            
            <div style={{ background: 'rgba(var(--brand-rgb),0.03)', borderRadius: 12, padding: 12 }}>
              <div style={{ fontSize: 11, color: 'var(--silver-muted)', marginBottom: 4 }}>{t('last_session')}</div>
              <div style={{ fontSize: 13, color: '#fff' }}>{sessions[0].memberProgress || t('no_notes')}</div>
            </div>
          </>
        ) : (
          <div style={{ textAlign: 'center', color: 'var(--silver-dim)', fontSize: 13, padding: '20px 0' }}>{t('no_data')}</div>
        )}
      </div>
    </div>
  );
}

function badgeClass(s: string) {
  if (s === 'active') return 'badge-active';
  if (s === 'expiring_soon') return 'badge-soon';
  if (s === 'expired') return 'badge-expired';
  if (s === 'frozen') return 'badge-frozen';
  return '';
}

function QuickAction({ emoji, label, onClick, disabled, highlight }: { emoji: string; label: string; onClick: () => void; disabled?: boolean; highlight?: boolean }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
        padding: '12px 4px', borderRadius: 14, cursor: disabled ? 'not-allowed' : 'pointer',
        background: highlight ? 'linear-gradient(135deg, rgba(var(--brand-rgb),0.12), rgba(var(--brand-dim-rgb),0.08))' : 'var(--bg-surface)',
        border: `1px solid ${highlight ? 'rgba(var(--brand-rgb),0.25)' : 'rgba(var(--brand-rgb),0.08)'}`,
        opacity: disabled ? 0.4 : 1,
        color: 'var(--silver)', fontSize: 10, fontWeight: 600,
      }}
    >
      <span style={{ fontSize: 22 }}>{emoji}</span>
      {label}
    </button>
  );
}

function SummaryCard({ emoji, label, value, color, onClick }: { emoji: string; label: string; value: string; color?: string; onClick: () => void }) {
  return (
    <button onClick={onClick} style={{
      textAlign: 'right', padding: 14, borderRadius: 14, cursor: 'pointer',
      background: 'var(--bg-surface)', border: '1px solid rgba(var(--brand-rgb),0.08)',
    }}>
      <div style={{ fontSize: 11, color: 'var(--silver-muted)', marginBottom: 4 }}>{emoji} {label}</div>
      <div style={{ fontSize: 16, fontWeight: 800, color: color || '#fff' }}>{value}</div>
    </button>
  );
}
