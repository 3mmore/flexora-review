'use client';
/**
 * PACK 2 · ITEM 5 — the page the entrance QR opens.
 *
 * The QR encodes this URL with the token in `?t=`, so a phone's camera app goes
 * straight here: one tap, no typing, and the token dies 120 seconds after it was
 * minted (so a screenshot forwarded on WhatsApp is already expired).
 */
import { Suspense } from 'react';
import { SelfCheckinPage } from '@/components/portal/SelfCheckin';

export default function Page() {
  // useSearchParams needs a Suspense boundary in the app router
  return (
    <Suspense fallback={null}>
      <SelfCheckinPage />
    </Suspense>
  );
}
