'use client';
/**
 * FLEXORA Gym OS
 * © 2024 Ammar Allam. All rights reserved.
 * Unauthorized copying, distribution, or modification of this software
 * is strictly prohibited without written permission from the owner.
 * Contact: FLEXORA support
 */
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { portalApi, getMemberToken } from '@/lib/portal';
import { safeErrorMessage } from '@/lib/safe-error';
import { useTranslation } from '@/lib/i18n';

export default function PortalRenew() {
  const router = useRouter();
  const { t, lang } = useTranslation();
  const [msg, setMsg] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => { if (!getMemberToken()) router.replace('/portal/login'); }, [router]);

  // ROUND 14 (security review, PHASE F1 — CRITICAL): the portal Renew action
  // NEVER extends the membership by itself. It creates a renewal REQUEST and
  // notifies the front desk; when the gym has an online payment provider
  // configured, a checkout for the exact plan price is offered instead.
  const [checkoutUrl, setCheckoutUrl] = useState<string | null>(null);
  async function renew() {
    setMsg(''); setLoading(true); setCheckoutUrl(null);
    try {
      const r = await portalApi<{ request?: { id: string; status: string; amount: number }; checkout?: { iframeUrl: string; amount: number } | null; renewed?: boolean }>('/portal/renew', { method: 'POST', body: JSON.stringify({}) });
      if (r.checkout?.iframeUrl) {
        setCheckoutUrl(r.checkout.iframeUrl);
        setMsg(t('renewal_checkout_ready') || 'Checkout ready — complete the payment to renew. Your membership is extended only after the payment is confirmed.');
      } else {
        setMsg(`✓ ${t('renewal_request_sent') || 'Renewal request sent to the front desk. Your membership is extended once the staff confirms the payment.'}`);
      }
    } catch (e: unknown) { setMsg(safeErrorMessage(e)); } finally { setLoading(false); }
  }

  return (
    <div dir={lang === 'ar' ? 'rtl' : 'ltr'} className="min-h-screen p-4" style={{ background: 'var(--bg)', color: 'var(--text)' }}>
      <div className="max-w-md mx-auto">
        <div className="flex items-center gap-3 py-3">
          <button className="btn-ghost text-sm" onClick={() => router.push('/portal/dashboard')}>{t('back')}</button>
          <div className="font-extrabold">{t('renew_membership_title')}</div>
        </div>
        {msg && <div className="card text-sm mb-4" style={{ borderColor: msg.includes('✓') ? 'var(--cyan-border,rgba(var(--brand-rgb),.3))' : 'rgba(255,77,106,.3)' }}>{msg}</div>}
        <div className="card">
          <p className="text-sm text-[var(--muted)] mb-4">{t('renew_desc')}</p>
          <button className="btn w-full" disabled={loading} onClick={renew} data-testid="portal-renew-btn">
            {loading ? '...' : t('renew_now')}
          </button>
          {checkoutUrl && (
            <button className="btn btn-primary w-full mt-3" data-testid="portal-renew-pay" onClick={() => window.open(checkoutUrl, '_blank')}>
              💳 {t('pay_now') || 'Pay now'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
