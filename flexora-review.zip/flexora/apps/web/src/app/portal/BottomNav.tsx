'use client';
/**
 * FLEXORA Gym OS — Member portal bottom navigation
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Mobile-first fixed bottom nav: Dashboard, Classes, Renew, Member Card,
 * Profile. Hidden on the login screen.
 */
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useTranslation } from '@/lib/i18n';

export default function BottomNav() {
  const { t, lang } = useTranslation();
  const pathname = usePathname() || '';

  const ITEMS: { href: string; label: string; icon: string }[] = [
    { href: '/portal/dashboard', label: t('nav_home'), icon: '🏠' },
    { href: '/portal/classes', label: t('nav_classes'), icon: '📅' },
    { href: '/portal/renew', label: t('nav_renew'), icon: '♻️' },
    { href: '/portal/member-card', label: t('nav_card'), icon: '🪪' },
    { href: '/portal/profile', label: t('nav_profile'), icon: '👤' },
  ];

  // Don't render on the login route.
  if (pathname.startsWith('/portal/login')) return null;

  return (
    <nav
      dir={lang === 'ar' ? 'rtl' : 'ltr'}
      aria-label={t('bottom_nav_aria')}
      style={{
        position: 'fixed',
        bottom: 0,
        left: 0,
        right: 0,
        zIndex: 50,
        display: 'grid',
        gridTemplateColumns: `repeat(${ITEMS.length}, 1fr)`,
        background: 'rgba(13,17,23,0.96)',
        borderTop: '1px solid rgba(255,255,255,0.08)',
        backdropFilter: 'blur(10px)',
        paddingBottom: 'env(safe-area-inset-bottom)',
      }}
    >
      {ITEMS.map((it) => {
        const active = pathname === it.href || pathname.startsWith(it.href + '/');
        return (
          <Link
            key={it.href}
            href={it.href}
            aria-current={active ? 'page' : undefined}
            style={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 2,
              padding: '8px 4px',
              fontSize: 11,
              fontWeight: 700,
              textDecoration: 'none',
              color: active ? 'var(--accent, var(--cyan))' : 'rgba(255,255,255,0.6)',
            }}
          >
            <span style={{ fontSize: 20, lineHeight: 1 }}>{it.icon}</span>
            <span>{it.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
