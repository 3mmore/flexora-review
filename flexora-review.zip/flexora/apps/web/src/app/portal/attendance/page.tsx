'use client';
/**
 * FLEXORA Gym OS — Member Attendance Analytics
 * © 2024 Ammar Allam. All rights reserved.
 */
import { useEffect, useState } from 'react';
import { formatDate } from '@/lib/dates';
import { useRouter } from 'next/navigation';
import { portalApi, getMemberToken } from '@/lib/portal';
import { safeErrorMessage } from '@/lib/safe-error';
import { useTranslation } from '@/lib/i18n';

type AttendanceData = {
  summary: { totalVisits: number; monthVisits: number; lastVisit: string | null };
  timeline: { id: string; date: string; method: string; branch: string | null }[];
};

export default function PortalAttendance() {
  const router = useRouter();
  const { t, lang } = useTranslation();
  const [data, setData] = useState<AttendanceData | null>(null);
  const [err, setErr] = useState('');

  useEffect(() => {
    if (!getMemberToken()) { router.replace('/portal/login'); return; }
    portalApi<AttendanceData>('/portal/attendance').then(setData).catch((e) => setErr(safeErrorMessage(e)));
  }, [router]);

  return (
    <div dir={lang === 'ar' ? 'rtl' : 'ltr'} className="min-h-screen p-4" style={{ background: 'var(--bg)', color: 'var(--text)' }}>
      <div className="max-w-md mx-auto">
        <div className="flex items-center gap-3 py-3">
          <button className="btn-ghost text-sm" onClick={() => router.push('/portal/dashboard')}>{t('back')}</button>
          <div className="font-extrabold flex-1">{t('visit_history_label')}</div>
        </div>
        {err && <div className="text-red-400 text-sm">{err}</div>}
        {!data ? <div className="text-[var(--muted)]">{t('loading')}</div> : (
          <>
            <div className="grid grid-cols-3 gap-3 mb-4">
              <div className="card text-center"><div className="text-[var(--muted)] text-xs">{t('total_visits')}</div><div className="font-extrabold text-xl">{data.summary.totalVisits}</div></div>
              <div className="card text-center"><div className="text-[var(--muted)] text-xs">{t('this_month')}</div><div className="font-extrabold text-xl">{data.summary.monthVisits}</div></div>
              <div className="card text-center"><div className="text-[var(--muted)] text-xs">{t('last_visit')}</div><div className="font-bold text-sm">{data.summary.lastVisit ? formatDate(data.summary.lastVisit) : '—'}</div></div>
            </div>
            <div className="card">
              <div className="font-bold mb-2">{t('visit_timeline')}</div>
              {data.timeline.length === 0 ? <div className="text-[var(--muted)] text-sm">{t('no_visits_yet')}</div> : data.timeline.map((a) => (
                <div key={a.id} className="flex justify-between py-2 text-sm border-t border-[var(--border)]">
                  <div><div className="font-bold">{formatDate(a.date)}</div><div className="text-[var(--muted)] text-xs">{a.branch || ''} · {a.method === 'QR' ? 'QR' : t('manual')}</div></div>
                  <div className="text-[var(--muted)] text-xs">{new Date(a.date).toLocaleTimeString(lang === 'ar' ? 'ar-EG' : 'en-US', { hour: '2-digit', minute: '2-digit' })}</div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
