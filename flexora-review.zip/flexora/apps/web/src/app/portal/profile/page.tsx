'use client';
/**
 * FLEXORA Gym OS — Member profile (member portal)
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Shows member info, push-notification toggle, and a logout that purges all
 * member caches (prevents account-switching leaks).
 */
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { portalApi, getMemberToken, setMemberToken } from '@/lib/portal';
import { safeErrorMessage } from '@/lib/safe-error';
import { useTranslation } from '@/lib/i18n';
import {
  subscribeToPush,
  unsubscribeFromPush,
  currentPushPermission,
  pushSupported,
  clearMemberCaches,
} from '@/lib/pwa';

interface Me {
  name: string;
  mobile: string;
}

export default function ProfilePage() {
  const router = useRouter();
  const { t, lang } = useTranslation();
  const [me, setMe] = useState<Me | null>(null);
  const [err, setErr] = useState('');
  const [pushState, setPushState] = useState<string>('default');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!getMemberToken()) {
      router.replace('/portal/login');
      return;
    }
    portalApi<Me>('/portal/me').then(setMe).catch((e: unknown) => setErr(safeErrorMessage(e)));
    setPushState(currentPushPermission());
  }, [router]);

  const togglePush = async () => {
    setBusy(true);
    try {
      if (pushState === 'granted') {
        await unsubscribeFromPush();
        setPushState('default');
      } else {
        const endpoint = await subscribeToPush();
        setPushState(endpoint ? 'granted' : currentPushPermission());
      }
    } catch (e: unknown) {
      setErr((e as Error).message || 'Push error');
    } finally {
      setBusy(false);
    }
  };

  const logout = async () => {
    // Purge member caches BEFORE clearing the token so the SW is still active.
    await clearMemberCaches();
    setMemberToken(null);
    router.replace('/portal/login');
  };

  return (
    <div
      dir={lang === 'ar' ? 'rtl' : 'ltr'}
      style={{ minHeight: '100vh', padding: 16, background: 'var(--bg, var(--bg-base))', color: 'var(--text, #e6edf3)' }}
    >
      <div style={{ maxWidth: 440, margin: '0 auto' }}>
        <h1 style={{ fontSize: 18, fontWeight: 800, margin: '8px 0 16px', textAlign: 'center' }}>{t('profile')}</h1>
        {err && <div style={{ color: '#f87171', textAlign: 'center' }}>{err}</div>}
        {me && (
          <div
            style={{
              background: 'rgba(255,255,255,0.04)',
              border: '1px solid rgba(255,255,255,0.08)',
              borderRadius: 16,
              padding: 20,
              textAlign: 'center',
            }}
          >
            <div style={{ fontSize: 22, fontWeight: 800 }}>{me.name}</div>
            <div style={{ color: 'rgba(255,255,255,0.6)', fontSize: 13 }} dir="ltr">{me.mobile}</div>
          </div>
        )}

        <div
          style={{
            marginTop: 16,
            background: 'rgba(255,255,255,0.04)',
            border: '1px solid rgba(255,255,255,0.08)',
            borderRadius: 16,
            padding: 16,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <div>
            <div style={{ fontWeight: 700 }}>{t('push_notifications')}</div>
            <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 12 }}>
              {pushSupported() ? (pushState === 'granted' ? t('enabled') : t('disabled')) : t('not_supported')}
            </div>
          </div>
          <button
            disabled={!pushSupported() || busy}
            onClick={togglePush}
            style={{
              background: pushState === 'granted' ? 'transparent' : 'var(--accent, var(--cyan))',
              color: pushState === 'granted' ? 'rgba(255,255,255,0.8)' : '#04110d',
              border: pushState === 'granted' ? '1px solid rgba(255,255,255,0.2)' : 'none',
              borderRadius: 10,
              padding: '8px 16px',
              fontWeight: 800,
              cursor: pushSupported() && !busy ? 'pointer' : 'not-allowed',
              opacity: !pushSupported() ? 0.5 : 1,
            }}
          >
            {busy ? '…' : pushState === 'granted' ? t('disabled') : t('enabled')}
          </button>
        </div>

        <button
          onClick={logout}
          style={{
            width: '100%',
            marginTop: 16,
            background: '#7f1d1d',
            color: '#fff',
            border: 'none',
            borderRadius: 12,
            padding: '12px',
            fontWeight: 800,
            fontSize: 15,
            cursor: 'pointer',
          }}
        >
          {t('logout')}
        </button>
      </div>
    </div>
  );
}
