/**
 * PACK 2 · STEP 2.3 — the portal's own manifest.
 *
 * This file exists only because the portal chrome is a client component and
 * metadata cannot be exported from one. The staff app (app/layout.tsx) declares
 * the gym-app manifest; without this override a member installing from the
 * portal would install the STAFF app — the same mistake in the other direction.
 */
import type { Metadata, Viewport } from 'next';
import PortalChrome from './PortalChrome';

export const metadata: Metadata = {
  manifest: '/manifest.webmanifest',
  applicationName: 'فليكسورا — بوابة الأعضاء',
  appleWebApp: { capable: true, title: 'فليكسورا', statusBarStyle: 'black-translucent' },
  icons: { apple: '/icon-192.png' },
};

export const viewport: Viewport = {
  themeColor: '#FF7A00',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  viewportFit: 'cover',
};

export default function PortalLayout({ children }: { children: React.ReactNode }) {
  return <PortalChrome>{children}</PortalChrome>;
}
