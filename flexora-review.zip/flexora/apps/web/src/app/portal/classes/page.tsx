'use client';
/**
 * FLEXORA Gym OS — Member Class Schedule
 * © 2024 Ammar Allam. All rights reserved.
 */
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { portalApi, getMemberToken } from '@/lib/portal';
import { safeErrorMessage } from '@/lib/safe-error';
import { useTranslation } from '@/lib/i18n';

import { Icon } from '@/components/brand/Icon';
import { weekdayName } from '@/lib/dates';

interface Session {
  id: string;
  startsAt: string;
  endsAt?: string;
  booked: number;
  capacity: number;
  full: boolean;
  isBooked: boolean;
  status: string;
  coach?: { name: string };
  template?: { name?: string; nameAr?: string; color?: string; durationMin?: number };
}

export default function PortalClasses() {
  const router = useRouter();
  const { t, lang } = useTranslation();
  const [sessions, setSessions] = useState<Session[]>([]);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState('');

  const load = () => portalApi<Session[]>('/portal/classes').then(setSessions).catch((e: unknown) => setErr(safeErrorMessage(e)));
  
  useEffect(() => { 
    if (!getMemberToken()) { 
      router.replace('/portal/login'); 
      return; 
    } 
    load(); 
  }, [router]);

  async function book(id: string) {
    setBusy(id);
    try { 
      await portalApi(`/portal/classes/${id}/book`, { method: 'POST' }); 
      await load(); 
    } catch (e: unknown) { 
      alert(safeErrorMessage(e)); 
    } finally { 
      setBusy(''); 
    }
  }

  async function cancelBooking(id: string) {
    setBusy(id);
    try { 
      await portalApi(`/portal/classes/${id}/cancel`, { method: 'POST' }); 
      await load(); 
    } catch (e: unknown) { 
      alert(safeErrorMessage(e)); 
    } finally { 
      setBusy(''); 
    }
  }

  return (
    <div dir={lang === 'ar' ? 'rtl' : 'ltr'} className="min-h-screen p-4" style={{ background: 'var(--bg-base)', color: 'var(--silver)' }}>
      <div className="max-w-md mx-auto">
        <div className="flex items-center gap-3 py-3 mb-4">
          <button className="btn btn-ghost btn-sm" onClick={() => router.push('/portal/dashboard')}>← {t('back')}</button>
          <h1 className="text-xl font-extrabold flex-1">{t('classes')}</h1>
        </div>

        {err && <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-3 text-xs text-red-300 mb-4">{t(err) || err}</div>}

        <div className="space-y-3">
          {sessions.length === 0 ? (
            <div className="text-center py-12 text-[var(--silver-dim)] italic">{t('no_classes_this_week')}</div>
          ) : (
            sessions.map((s) => (
              <div key={s.id} className="card p-4 border border-white/5 bg-white/[0.02]">
                <div className="flex items-start gap-4">
                  <div className="w-1.5 h-12 rounded-full shrink-0" style={{ background: s.template?.color || 'var(--primary)' }} />
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start">
                      <h3 className="font-bold text-white truncate">
                        {lang === 'ar' ? (s.template?.nameAr || s.template?.name) : s.template?.name}
                      </h3>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${s.status === 'CANCELLED' ? 'bg-red-500/20 text-red-400' : 'bg-green-500/20 text-green-400'}`}>
                        {t(s.status.toLowerCase() + '_label') || s.status}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 mt-1 text-xs text-[var(--silver-dim)]">
                      <Icon name="calendar" size={12} />
                      <>{weekdayName(s.startsAt, lang === 'en' ? 'en' : 'ar')} {new Date(s.startsAt).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}</>
                      {s.endsAt && ` – ${new Date(s.endsAt).toLocaleTimeString(lang === 'ar' ? 'ar-EG' : 'en-US', { hour: '2-digit', minute: '2-digit' })}`}
                    </div>
                    <div className="flex items-center gap-1.5 mt-1 text-xs text-[var(--silver-dim)]">
                      <Icon name="users" size={12} />
                      {s.coach?.name || t('unassigned')}
                    </div>
                    <div className="mt-2 flex items-center justify-between">
                      <div className="text-[10px] uppercase font-bold tracking-wider text-[var(--silver-muted)]">
                        {s.booked} / {s.capacity} {t('booked')}
                      </div>
                      <div className="flex gap-2">
                        {s.status !== 'CANCELLED' && (
                          s.isBooked ? (
                            <button 
                              className="btn btn-ghost btn-sm px-4 py-1 text-[11px]" 
                              disabled={!!busy} 
                              onClick={() => cancelBooking(s.id)}
                            >
                              {busy === s.id ? '...' : t('cancel')}
                            </button>
                          ) : (
                            s.full ? (
                              <span className="text-[10px] font-bold text-red-400 uppercase">{t('full')}</span>
                            ) : (
                              <button 
                                className="btn btn-primary btn-sm px-4 py-1 text-[11px]" 
                                disabled={!!busy} 
                                onClick={() => book(s.id)}
                              >
                                {busy === s.id ? '...' : t('book')}
                              </button>
                            )
                          )
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
