'use client';
/**
 * FLEXORA Gym OS — Member Financial History
 * © 2024 Ammar Allam. All rights reserved.
 */
import { useEffect, useState } from 'react';
import { formatDate } from '@/lib/dates';
import { useRouter } from 'next/navigation';
import { portalApi, getMemberToken } from '@/lib/portal';
import { safeErrorMessage } from '@/lib/safe-error';
import { useTranslation } from '@/lib/i18n';

type FinancialHistory = {
  summary: {
    totalPaid: number; outstandingBalance: number;
    lastPayment: { amount: number; method: string; date: string; reference: string | null } | null;
    lastRenewal: { invoiceNo: string; amount: number; date: string } | null;
  };
  invoices: { id: string; invoiceNo: string; date: string; status: string; total: number; paid: number; lines: { description: string }[] }[];
  payments: { id: string; amount: number; status: string; method: string; reference: string | null; date: string }[];
  receipts: { id: string; receiptNo: string; date: string; channel: string }[];
};

export default function PortalFinancial() {
  const router = useRouter();
  const { t, lang } = useTranslation();
  const [data, setData] = useState<FinancialHistory | null>(null);
  const [err, setErr] = useState('');

  useEffect(() => {
    if (!getMemberToken()) { router.replace('/portal/login'); return; }
    portalApi<FinancialHistory>('/portal/financial-history').then(setData).catch((e) => setErr(safeErrorMessage(e)));
  }, [router]);

  return (
    <div dir={lang === 'ar' ? 'rtl' : 'ltr'} className="min-h-screen p-4" style={{ background: 'var(--bg)', color: 'var(--text)' }}>
      <div className="max-w-md mx-auto">
        <div className="flex items-center gap-3 py-3">
          <button className="btn-ghost text-sm" onClick={() => router.push('/portal/dashboard')}>{t('back')}</button>
          <div className="font-extrabold flex-1">{t('financial_record')}</div>
        </div>
        {err && <div className="text-red-400 text-sm">{err}</div>}
        {!data ? <div className="text-[var(--muted)]">{t('loading')}</div> : (
          <>
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="card text-center"><div className="text-[var(--muted)] text-xs">{t('total_paid')}</div><div className="font-extrabold text-lg text-emerald-400">{data.summary.totalPaid.toLocaleString()} {lang === 'ar' ? 'ج.م' : 'EGP'}</div></div>
              <div className="card text-center"><div className="text-[var(--muted)] text-xs">{t('outstanding_balance')}</div><div className={`font-extrabold text-lg ${data.summary.outstandingBalance > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>{data.summary.outstandingBalance.toLocaleString()} {lang === 'ar' ? 'ج.م' : 'EGP'}</div></div>
            </div>
            <div className="card mb-4">
              <div className="font-bold mb-2">{t('invoice')}</div>
              {data.invoices.length === 0 ? <div className="text-[var(--muted)] text-sm">{t('no_data')}</div> : data.invoices.map((inv) => (
                <div key={inv.id} className="flex justify-between py-2 text-sm border-t border-[var(--border)]">
                  <div><div className="font-bold">{inv.invoiceNo}</div><div className="text-[var(--muted)] text-xs">{inv.lines.map((l) => l.description).join(', ')}</div><div className="text-[var(--muted)] text-xs">{formatDate(inv.date)}</div></div>
                  <div className="text-left"><div className="font-bold">{Number(inv.total).toLocaleString()} {lang === 'ar' ? 'ج.م' : 'EGP'}</div><div className={`text-xs font-bold ${inv.status === 'PAID' ? 'text-emerald-400' : inv.status === 'PARTIALLY_PAID' ? 'text-amber-400' : 'text-red-400'}`}>{t(inv.status.toLowerCase()) || inv.status}</div></div>
                </div>
              ))}
            </div>
            <div className="card mb-4">
              <div className="font-bold mb-2">{t('payment')}</div>
              {data.payments.length === 0 ? <div className="text-[var(--muted)] text-sm">{t('no_data')}</div> : data.payments.map((p) => (
                <div key={p.id} className="flex justify-between py-2 text-sm border-t border-[var(--border)]">
                  <div><div className="font-bold">{t(p.method.toLowerCase()) || p.method}</div><div className="text-[var(--muted)] text-xs">{formatDate(p.date)}</div>{p.reference && <div className="text-[var(--muted)] text-xs">{t('reference')}: {p.reference}</div>}</div>
                  <div className="font-bold">{Number(p.amount).toLocaleString()} {lang === 'ar' ? 'ج.م' : 'EGP'}</div>
                </div>
              ))}
            </div>
            <div className="card">
              <div className="font-bold mb-2">{t('receipt')}</div>
              {data.receipts.length === 0 ? <div className="text-[var(--muted)] text-sm">{t('no_data')}</div> : data.receipts.map((r) => (
                <div key={r.id} className="flex justify-between py-2 text-sm border-t border-[var(--border)]">
                  <div><div className="font-bold">{r.receiptNo}</div><div className="text-[var(--muted)] text-xs">{r.channel}</div></div>
                  <div className="text-[var(--muted)] text-xs">{formatDate(r.date)}</div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
