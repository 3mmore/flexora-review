/**
 * FLEXORA Gym OS — Leads CRM
 * © 2024 Ammar Allam. All rights reserved.
 */
'use client';
import { useEffect, useState } from 'react';
import { formatDate } from '@/lib/dates';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { safeErrorMessage } from '@/lib/safe-error';
import { useBranchScope } from '@/lib/branch-scope';
import { useTranslation } from '@/lib/i18n';
import { localizePlanName, planOptionLabel } from '@/lib/plan-label';
import { ModalPortal } from '@/components/ModalPortal';

type Lead = {
  id: string; name: string; mobile: string; email?: string;
  status: string; priority: string; source: string;
  aiScore?: number; aiRecommendation?: string;
  notes?: string; nextFollowUpAt?: string; lastContactAt?: string;
  createdAt: string;
  /** ROUND 14 (PHASE K2): the member a converted lead became. */
  convertedMember?: {
    id: string; name: string; status: string;
    expiry?: string | null; sessionsLeft?: number | null;
    membershipStatus: 'active' | 'expired' | 'soon' | 'frozen' | 'pending';
    plan?: { id: string; name: string; type: string; price: number } | null;
  } | null;
};

const STATUS_COLORS: Record<string, string> = {
  NEW: 'bg-blue-500/20 text-blue-300',
  CONTACTED: 'bg-purple-500/20 text-purple-300',
  INTERESTED: 'bg-yellow-500/20 text-yellow-300',
  TRIAL_BOOKED: 'bg-orange-500/20 text-orange-300',
  CONVERTED: 'bg-green-500/20 text-green-300',
  LOST: 'bg-red-500/20 text-red-300',
};

const PRIORITY_COLORS: Record<string, string> = {
  LOW: 'text-white/40', MEDIUM: 'text-yellow-300', HIGH: 'text-orange-300', HOT: 'text-red-300',
};

interface LeadStats {
  total: number;
  new: number;
  interested: number;
  converted: number;
  lost: number;
}

export default function LeadsPage() {
  const { t, lang } = useTranslation();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [stats, setStats] = useState<LeadStats | null>(null);
  const [staff, setStaff] = useState<any[]>([]);
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ name: '', mobile: '', email: '', source: 'WALK_IN', priority: 'MEDIUM', notes: '', assignedTo: '' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const [convertFor, setConvertFor] = useState<Lead | null>(null);
  const [plans, setPlans] = useState<any[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [convertForm, setConvertForm] = useState({ planId: '', branchId: '' });

  // ROUND 14 (security review, PHASE K2): conversion registers the member as
  // PENDING_PAYMENT, so the board offers "Collect payment" — the paid
  // activation is what turns it into a live membership.
  const [payFor, setPayFor] = useState<{ leadId: string; memberId: string; name: string; planName?: string | null } | null>(null);
  const [payForm, setPayForm] = useState({ amount: 0, method: 'CASH' });
  const [payBusy, setPayBusy] = useState(false);

  /** PHASE 4: restricted staff convert leads into their OWN branch only. */
  const scope = useBranchScope();

  const load = async () => {
    setBusy(true); setErr('');
    try {
      // Each sub-request is independent on purpose.
      //
      // NOT every role may read every panel on this page — `/leads/stats` and
      // `/plans` are OWNER/MANAGER-only while RECEPTION is a first-class user of
      // the leads list. With one shared Promise.all a single 403 rejected the
      // whole batch and the page rendered EMPTY for reception (found live in
      // Phase 4 verification), even though `GET /leads` had answered 200.
      // Now only the parts a role may read are shown; the rest degrade to their
      // empty state instead of taking the page down.
      const [l, s, u, p, b] = await Promise.all([
        api<Lead[]>('/leads'),
        api<LeadStats>('/leads/stats').catch(() => null),
        api<any[]>('/users').catch(() => []),
        api<any[]>('/plans').catch(() => []),
        api<any>('/branches').then(res => Array.isArray(res) ? res : (res.items || [])).catch(() => []),
      ]);
      setLeads(l); setStats(s); setStaff(u); setPlans(p); setBranches(b);
    } catch (e: unknown) { setErr(safeErrorMessage(e)); }
    finally { setBusy(false); }
  };

  useEffect(() => { load(); }, []);

  const create = async () => {
    const nameParts = (form.name || '').trim().split(/\s+/);
    if (nameParts.length < 3) { setErr(t('name_3_parts_required') || 'Full name must contain at least 3 parts (First Middle Last)'); return; }
    // P1: enforce the Egyptian-mobile rule client-side too (backend rejects
    // with the same message — this gives instant feedback before the request).
    if (!/^(010|011|012|015)\d{8}$/.test((form.mobile || '').trim())) {
      setErr(t('eg_phone_hint') || 'Mobile number must be 11 digits and start with 010, 011, 012 or 015');
      return;
    }
    try {
      const payload = { ...form, email: form.email || undefined };
      await api('/leads', { method: 'POST', body: JSON.stringify(payload) });
      setShowCreate(false);
      setForm({ name: '', mobile: '', email: '', source: 'WALK_IN', priority: 'MEDIUM', notes: '', assignedTo: '' });
      await load();
    } catch (e) { setErr(safeErrorMessage(e)); }
  };

  const aiFollowUp = async (id: string) => {
    try { await api(`/leads/${id}/ai-follow-up`, { method: 'POST' }); alert(t('ai_follow_up_queued')); }
    catch (e) { setErr(safeErrorMessage(e)); }
  };

  const startConvert = (l: Lead) => {
    setConvertFor(l);
    // PHASE 4: restricted staff are pinned to their own branch — the value is
    // filled in for them and never shown as a choice.
    setConvertForm({
      planId: plans[0]?.id || '',
      branchId: scope.unrestricted ? (branches[0]?.id || '') : (scope.branchId || branches[0]?.id || ''),
    });
  };

  const confirmConvert = async () => {
    if (!convertFor) return;
    try { 
      await api(`/leads/${convertFor.id}/convert`, { 
        method: 'POST', 
        body: JSON.stringify(convertForm) 
      }); 
      setConvertFor(null);
      await load(); 
    }
    catch (e) { setErr(safeErrorMessage(e)); }
  };

  /** PHASE K2: open the payment step for a converted (pending) member. */
  const startCollectPayment = (l: Lead) => {
    if (!l.convertedMember) return;
    setPayFor({
      leadId: l.id,
      memberId: l.convertedMember.id,
      name: l.convertedMember.name,
      planName: l.convertedMember.plan?.name ?? null,
    });
    setPayForm({ amount: Number(l.convertedMember.plan?.price || 0), method: 'CASH' });
  };

  /**
   * PHASE K2/K4: ONE call — POST /members/:id/activate records the member-bound
   * payment AND activates the membership in a single transaction, so a failure
   * can never leave a payment that bought nothing.
   */
  const collectPayment = async () => {
    if (!payFor) return;
    setPayBusy(true);
    try {
      await api(`/members/${payFor.memberId}/activate`, {
        method: 'POST',
        body: JSON.stringify({ amount: Number(payForm.amount), method: payForm.method }),
      });
      setPayFor(null);
      await load();
    } catch (e) { setErr(safeErrorMessage(e)); }
    finally { setPayBusy(false); }
  };

  return (
    <Shell>
      <div className="px-4 py-6 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-extrabold">🎯 {t('leads')}</h1>
            <p className="text-sm text-white/60">{t('crm_pipeline_ai')}</p>
          </div>
          <button onClick={() => setShowCreate(true)} className="px-4 py-2 rounded-lg bg-[var(--brand)] text-black font-bold">+ {t('new_lead')}</button>
        </div>

        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-6">
            <Stat label={t('total')} value={stats.total} />
            <Stat label={t('new')} value={stats.new} />
            <Stat label={t('interested')} value={stats.interested} />
            <Stat label={t('converted')} value={stats.converted} />
            <Stat label={t('lost')} value={stats.lost} />
          </div>
        )}

        {err && <div className="bg-red-500/20 border border-red-500/50 rounded p-3 mb-4 text-sm">{err}</div>}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {leads.map((l) => (
            <div key={l.id} className="bg-black/40 border border-white/10 rounded-xl p-4">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <div className="font-bold text-lg">{l.name}</div>
                  <div className="text-xs text-white/60 font-mono">{l.mobile}</div>
                  {l.email && <div className="text-xs text-white/40">{l.email}</div>}
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className={`text-xs px-2 py-0.5 rounded ${STATUS_COLORS[l.status] || ''}`}>{t('st_' + l.status) || l.status}</span>
                  <span className={`text-xs ${PRIORITY_COLORS[l.priority]}`}>{t('priority_' + l.priority.toLowerCase()) || l.priority}</span>
                </div>
              </div>

              {typeof l.aiScore === 'number' && (
                <div className="bg-[rgba(var(--brand-rgb),0.10)] border border-[rgba(var(--brand-rgb),0.30)] rounded p-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-[var(--brand)] font-bold">{t('ai_score')}: {l.aiScore}</span>
                    <div className="flex-1 bg-black/40 rounded h-1.5 overflow-hidden">
                      <div className="bg-[var(--brand)] h-full" style={{ width: `${l.aiScore}%` }} />
                    </div>
                  </div>
                  {l.aiRecommendation && <div className="text-xs text-white/70 mt-1">{l.aiRecommendation}</div>}
                </div>
              )}

              {l.notes && <div className="text-xs text-white/60 mb-2 italic">"{l.notes}"</div>}

              {/* ROUND 14 (security review, PHASE K2): conversion registers the
                  member as PENDING_PAYMENT — say so, and give the desk the one
                  action that turns it into a live membership. */}
              {l.convertedMember && (
                <div
                  data-testid={l.convertedMember.membershipStatus === 'pending' ? 'lead-member-pending' : 'lead-member-active'}
                  className={`mt-2 mb-1 rounded-lg px-2.5 py-2 text-xs flex items-center justify-between gap-2 ${
                    l.convertedMember.membershipStatus === 'pending'
                      ? 'bg-yellow-500/10 border border-yellow-500/40 text-yellow-200'
                      : 'bg-green-500/10 border border-green-500/40 text-green-200'
                  }`}
                >
                  <span>
                    {l.convertedMember.membershipStatus === 'pending'
                      ? `🕓 ${t('member_pending_payment') || 'Registered — pending payment (cannot check in yet)'}`
                      : `✅ ${t('membership_active') || 'Membership active'}${l.convertedMember.expiry ? ` — ${t('expires') || 'expires'} ${formatDate(l.convertedMember.expiry)}` : ''}`}
                  </span>
                  {l.convertedMember.membershipStatus === 'pending' && (
                    <button
                      data-testid="lead-collect-payment"
                      onClick={() => startCollectPayment(l)}
                      className="shrink-0 px-2 py-1 rounded bg-[var(--brand)] text-black font-bold text-[11px]"
                    >
                      💳 {t('collect_payment') || 'Collect payment'}
                    </button>
                  )}
                </div>
              )}

              <div className="flex gap-2 mt-3">
                <button onClick={() => aiFollowUp(l.id)} className="text-xs px-2 py-1 rounded bg-[rgba(var(--brand-rgb),0.20)] hover:bg-[rgba(var(--brand-rgb),0.30)] text-[var(--brand)]">🤖 {t('ai_followup')}</button>
                <button onClick={() => startConvert(l)} disabled={l.status === 'CONVERTED'}
                  className="text-xs px-2 py-1 rounded bg-green-500/20 hover:bg-green-500/30 text-green-300 disabled:opacity-30">
                  {t('convert')}
                </button>
              </div>
            </div>
          ))}
        </div>

        {leads.length === 0 && !busy && (
          <div className="text-center py-16 text-white/40">{t('no_leads_yet')}</div>
        )}

        {showCreate && (
          <ModalPortal>
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--bg-base)] border border-[rgba(var(--brand-rgb),0.30)] rounded-2xl p-6 max-w-md w-full">
              <h2 className="text-xl font-bold mb-4 text-[var(--brand)]">{t('new_lead')}</h2>
              <Field label={t('name')} value={form.name} onChange={(v) => setForm({ ...form, name: v })} />
              <Field label={t('mobile')} tel value={form.mobile} onChange={(v) => setForm({ ...form, mobile: v })} />
              
              <div className="mb-3">
                <label className="text-xs text-white/60 block mb-1">{t('assigned_to') || 'Assigned To'}</label>
                <select value={form.assignedTo} onChange={(e) => setForm({ ...form, assignedTo: e.target.value })}
                  className="w-full bg-black/40 border border-white/10 rounded p-2 text-sm">
                  <option value="">{t('select_staff') || 'Select Staff'}</option>
                  {staff.map((u) => (
                    <option key={u.id} value={u.id}>{u.name} ({u.role})</option>
                  ))}
                </select>
              </div>

              <div className="mb-3">
                <label className="text-xs text-white/60 block mb-1">{t('source')}</label>
                <select value={form.source} onChange={(e) => setForm({ ...form, source: e.target.value })}
                  className="w-full bg-black/40 border border-white/10 rounded p-2 text-sm">
                  {['WALK_IN', 'REFERRAL', 'SOCIAL_MEDIA', 'WEBSITE', 'WHATSAPP', 'INVITATION', 'OTHER'].map((s) => (
                    <option key={s} value={s}>{t('source_' + s.toLowerCase()) || s}</option>
                  ))}
                </select>
              </div>
              <div className="mb-3">
                <label className="text-xs text-white/60 block mb-1">{t('priority')}</label>
                <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}
                  className="w-full bg-black/40 border border-white/10 rounded p-2 text-sm">
                  {['LOW', 'MEDIUM', 'HIGH', 'HOT'].map((p) => (<option key={p} value={p}>{t('priority_' + p.toLowerCase()) || p}</option>))}
                </select>
              </div>
              <div className="mb-4">
                <label className="text-xs text-white/60 block mb-1">{t('notes')}</label>
                <textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  className="w-full bg-black/40 border border-white/10 rounded p-2 text-sm h-20" />
              </div>
              <div className="flex gap-2 justify-end">
                <button onClick={() => setShowCreate(false)} className="px-4 py-2 rounded bg-white/5 hover:bg-white/10 text-sm">{t('cancel')}</button>
                <button onClick={create} className="px-4 py-2 rounded bg-[var(--brand)] text-black font-bold text-sm">{t('create')}</button>
              </div>
            </div>
          </div>
        </ModalPortal>
        )}
        {/* ROUND 14 (security review, PHASE K2): "Collect payment" — the paid
            activation of a converted lead. One call, one transaction. */}
        {payFor && (
          <ModalPortal>
            <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4">
              <div data-testid="collect-payment-modal" className="bg-[var(--bg-base)] border border-[rgba(var(--brand-rgb),0.30)] rounded-2xl p-6 max-w-md w-full">
                <h2 className="text-xl font-bold mb-1 text-[var(--brand)]">{t('collect_payment') || 'Collect payment'}</h2>
                <p className="text-sm text-white/60 mb-4">{payFor.name}{payFor.planName ? ` · ${payFor.planName}` : ''}</p>
                <div className="mb-3">
                  <label className="text-xs text-white/60 block mb-1">{t('amount') || 'Amount'}</label>
                  <input
                    data-testid="collect-payment-amount"
                    type="number" min="0" step="0.01" value={payForm.amount}
                    onChange={(e) => setPayForm({ ...payForm, amount: Number(e.target.value) })}
                    className="w-full bg-black/40 border border-white/10 rounded p-2 text-sm" />
                </div>
                <div className="mb-4">
                  <label className="text-xs text-white/60 block mb-1">{t('payment_method') || 'Payment method'}</label>
                  <select
                    data-testid="collect-payment-method"
                    value={payForm.method}
                    onChange={(e) => setPayForm({ ...payForm, method: e.target.value })}
                    className="w-full bg-black/40 border border-white/10 rounded p-2 text-sm">
                    {['CASH', 'CARD', 'VODAFONE_CASH', 'INSTAPAY', 'BANK_TRANSFER'].map((m) => (
                      <option key={m} value={m}>{m.replace(/_/g, ' ')}</option>
                    ))}
                  </select>
                </div>
                <p className="text-[11px] text-white/40 mb-4">
                  {t('collect_payment_hint') || 'This records the payment and activates the membership in one step — the member can check in immediately.'}
                </p>
                <div className="flex gap-2 justify-end">
                  <button onClick={() => setPayFor(null)} className="px-4 py-2 rounded bg-white/5 hover:bg-white/10 text-sm">{t('cancel')}</button>
                  <button
                    data-testid="collect-payment-confirm"
                    onClick={collectPayment}
                    disabled={payBusy || !(payForm.amount > 0)}
                    className="px-4 py-2 rounded bg-[var(--brand)] text-black font-bold text-sm disabled:opacity-40">
                    {payBusy ? (t('loading') || '…') : (t('confirm_payment') || 'Confirm payment')}
                  </button>
                </div>
              </div>
            </div>
          </ModalPortal>
        )}
        {convertFor && (
          <ModalPortal>
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4">
            <div className="bg-[var(--bg-base)] border border-[rgba(var(--brand-rgb),0.30)] rounded-2xl p-6 max-w-md w-full">
              <h2 className="text-xl font-bold mb-4 text-[var(--brand)]">{t('convert')} — {convertFor.name}</h2>
              <div className="mb-3">
                <label className="text-xs text-white/60 block mb-1">{t('plan')}</label>
                <select value={convertForm.planId} onChange={(e) => setConvertForm({ ...convertForm, planId: e.target.value })}
                  className="w-full bg-black/40 border border-white/10 rounded p-2 text-sm">
                  <option value="">{t('select_plan')}</option>
                  {plans.map((p) => <option key={p.id} value={p.id}>{planOptionLabel(p, lang, t)}</option>)}
                </select>
              </div>
              <div className="mb-4">
                <label className="text-xs text-white/60 block mb-1">{t('branch')}</label>
                {scope.unrestricted ? (
                  <select value={convertForm.branchId} onChange={(e) => setConvertForm({ ...convertForm, branchId: e.target.value })}
                    className="w-full bg-black/40 border border-white/10 rounded p-2 text-sm">
                    <option value="">{t('select_branch')}</option>
                    {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
                  </select>
                ) : (
                  <div className="badge badge-active" data-testid="lead-branch-locked">
                    {scope.branchName || branches.find((b) => b.id === scope.branchId)?.name || '—'}
                  </div>
                )}
              </div>
              <div className="flex gap-2 justify-end">
                <button onClick={() => setConvertFor(null)} className="px-4 py-2 rounded bg-white/5 hover:bg-white/10 text-sm">{t('cancel')}</button>
                <button onClick={confirmConvert} className="px-4 py-2 rounded bg-green-600 text-white font-bold text-sm">{t('confirm')}</button>
              </div>
            </div>
          </div>
        </ModalPortal>
        )}
      </div>
    </Shell>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="bg-white/5 border border-white/10 rounded-lg p-3">
      <div className="text-xs text-white/60">{label}</div>
      <div className="text-xl font-bold text-[var(--brand)]">{value}</div>
    </div>
  );
}

function Field({ label, value, onChange, tel }: { label: string; value: string; onChange: (v: string) => void; tel?: boolean }) {
  return (
    <div className="mb-3">
      <label className="text-xs text-white/60 block mb-1">{label}</label>
      <input value={value} onChange={(e) => onChange(tel ? e.target.value.replace(/[^\d]/g, '').slice(0, 11) : e.target.value)}
        {...(tel ? { type: 'tel', inputMode: 'numeric', maxLength: 11, pattern: '01[0125][0-9]{8}', dir: 'ltr', placeholder: '01xxxxxxxxx' } : {})}
        className="w-full bg-black/40 border border-white/10 rounded p-2 text-sm" />
    </div>
  );
}
