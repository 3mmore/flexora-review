'use client';
import { Logo } from '@/components/brand/Logo';
import { useTranslation } from '@/lib/i18n';

export default function Loading() {
  const { t } = useTranslation();
  return (
    <div className="premium-page-loader" role="status" aria-live="polite" aria-label={t('loading_workspace')}>
      <div className="premium-loader-card">
        <Logo variant="mark" size={44} />
        <div className="premium-loader-copy">
          <span className="premium-loader-eyebrow">{t('preparing_workspace')}</span>
          <strong>{t('loading_operating_picture')}</strong>
        </div>
        <div className="premium-loader-grid" aria-hidden="true">
          <span /><span /><span /><span /><span /><span />
        </div>
      </div>
    </div>
  );
}
