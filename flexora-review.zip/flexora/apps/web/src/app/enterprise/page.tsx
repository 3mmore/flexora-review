'use client';
import { OperationalResourcePage } from '@/components/OperationalResourcePage';
import { useTranslation } from '@/lib/i18n';

export default function Page() {
  const { t } = useTranslation();
  return <OperationalResourcePage config={{ queryKey: 'enterprise', endpoint: '/enterprise/roles', title: t('enterprise_label'), narrative: t('enterprise_narrative'), columns: [{ key: 'name' }, { key: 'scope' }, { key: 'createdAt' }] }} />;
}
