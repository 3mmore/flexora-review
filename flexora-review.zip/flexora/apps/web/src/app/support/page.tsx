'use client';
import { OperationalResourcePage } from '@/components/OperationalResourcePage';
import { useTranslation } from '@/lib/i18n';

export default function Page() {
  const { t } = useTranslation();
  // ROUND 13 (Phase 1): GET /health is SUPER_ADMIN-only by design (F-023 —
  // it leaks version/uptime/memory), so every gym staff role got a 403 here.
  // The public readiness probe (/health/ready) is the right surface for a
  // staff-facing support page: real status, no privileged detail.
  return <OperationalResourcePage config={{ queryKey: 'support', endpoint: '/health/ready', title: t('support_center'), narrative: t('support_narrative'), columns: [{ key: 'status' }, { key: 'timestamp' }] }} />;
}
