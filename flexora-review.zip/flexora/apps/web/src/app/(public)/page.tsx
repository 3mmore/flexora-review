'use client';
import Link from 'next/link';
import { useTranslation } from '@/lib/i18n';
import { fmtMoney } from '@/lib/money';

function CtaButton({ children, href = '/register', ghost = false }: { children: React.ReactNode; href?: string; ghost?: boolean }) {
  return <Link href={href} className={`inline-flex items-center justify-center rounded-2xl px-6 py-3 font-bold transition-all ${ghost ? 'border border-white/15 text-white hover:bg-white/10' : 'bg-[#c5a059] text-black shadow-[0_0_32px_rgba(197,160,89,0.35)] hover:scale-[1.02]'}`}>{children}</Link>;
}

export default function LandingPage() {
  const { t } = useTranslation();

  const features = [
    ['👥', t('member_management'), t('member_mgmt_desc')],
    ['✅', t('attendance_tracking'), t('attendance_tracking_desc')],
    ['🧾', t('pos_system'), t('pos_system_desc')],
    ['📅', t('class_schedule_landing'), t('class_schedule_desc')],
    ['💬', t('messaging_landing'), t('messaging_desc')],
    ['🤖', t('smart_ai'), t('smart_ai_desc')],
    ['📊', t('reports_landing'), t('reports_desc')],
    ['📱', t('mobile_app'), t('mobile_app_desc')],
    ['🔐', t('high_security'), t('high_security_desc')],
  ];

  const plansList = [
    { name: 'BASIC', price: t('free'), badge: '', features: [`50 ${t('member')}`, `1 ${t('staff')}`, t('basic_reports')], misses: [t('smart_ai'), 'WhatsApp automation'] },
    { name: 'PRO', price: `499 ${t('egp_month')}`, badge: t('most_popular'), features: [`500 ${t('member')}`, `5 ${t('staff')}`, t('smart_ai'), 'WhatsApp', t('advanced_reports')], misses: ['White-label'] },
    { name: 'ELITE', price: `999 ${t('egp_month')}`, badge: '', features: [t('unlimited_members'), t('unlimited_users'), t('all_features'), t('priority_support')], misses: [] },
  ];

  const faqsList = [
    [t('faq_q1') || 'هل محتاج سيرفر أو حاجة؟', t('faq_a1') || 'لا، كل حاجة على السحابة. تفتح المتصفح وتبدأ فوراً.'],
    [t('faq_q2') || 'إزاي أدفع؟', t('faq_a2') || 'فيزا أو فودافون كاش أو تحويل بنكي حسب الباقة وطريقة الدفع المتاحة.'],
    [t('faq_q3') || 'ممكن أجرب قبل ما أدفع؟', t('faq_a3') || 'أيوا، 14 يوم مجاناً بدون كارت بنكي.'],
    [t('faq_q4') || 'لو مش عجبني؟', t('faq_a4') || 'تلغي وقت اللي عاوزه، مفيش تعاقد طويل أو التزام إجباري.'],
    [t('faq_q5') || 'البيانات بتاعتي آمنة؟', t('faq_a5') || 'أيوه، تشفير AES-256، صلاحيات، نسخ احتياطي، وعزل كامل لكل جيم.'],
    [t('faq_q6') || 'ممكن أضيف أكثر من فرع؟', t('faq_a6') || 'أيوا، باقة ELITE معمولة للجيمات متعددة الفروع.'],
  ];

  return <main className="min-h-screen overflow-hidden bg-[#050505] text-white scroll-smooth">
    <section className="relative px-5 py-20 md:py-28">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(197,160,89,0.22),transparent_34%),radial-gradient(circle_at_80%_0%,rgba(255,255,255,0.09),transparent_30%)]" />
      <div className="relative mx-auto grid max-w-7xl items-center gap-10 lg:grid-cols-[1.05fr_0.95fr]">
        <div className="animate-[fadeInUp_0.8s_ease_both]">
          <div className="mb-5 inline-flex rounded-full border border-[#c5a059]/30 bg-[#c5a059]/10 px-4 py-2 text-sm font-bold text-[#c5a059]">{t('landing_subtitle')}</div>
          <h1 className="text-4xl font-black leading-tight md:text-6xl">{t('landing_title')}</h1>
          <p className="mt-6 max-w-2xl text-lg leading-9 text-white/70">{t('landing_description')}</p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <CtaButton>{t('start_free_14_days')}</CtaButton>
            <CtaButton href="#features" ghost>{t('watch_demo')}</CtaButton>
          </div>
        </div>
        <div className="relative min-h-[360px] rounded-[2rem] border border-white/10 bg-gradient-to-br from-[#171717] via-[#0b0b0b] to-[#c5a059]/20 p-6 shadow-2xl animate-[fadeInUp_1s_ease_both]">
          <div className="absolute inset-6 rounded-[1.5rem] border border-[#c5a059]/20 bg-black/35" />
          <div className="relative grid gap-4">
            {[
              `${t('today_revenue')} ${fmtMoney(18450)}`, 
              `34 ${t('members_attended_today')}`, 
              `⚠️ 7 ${t('subscriptions_ending_soon')}`, 
              t('ai_renewal_campaign')
            ].map((x, i) => <div key={x} className="rounded-2xl border border-white/10 bg-white/[0.04] p-4 text-sm text-white/85" style={{ marginInlineStart: i % 2 ? 36 : 0 }}>{x}</div>)}
          </div>
        </div>
      </div>
    </section>

    <section className="border-y border-white/10 bg-white/[0.03] px-5 py-5">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-center gap-5 text-sm font-bold text-white/70"><span>{t('over_500_gyms')}</span><span>{t('ssl_encrypted')}</span><span>{t('egypt_servers')}</span><span>{t('support_24_7')}</span></div>
    </section>

    <section id="features" className="mx-auto max-w-7xl px-5 py-20">
      <h2 className="text-center text-3xl font-black md:text-5xl">{t('all_tools_one_platform')}</h2>
      <div className="mt-12 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
        {features.map(([icon, title, desc]) => <div key={title} className="animate-[fadeInUp_0.8s_ease_both] rounded-3xl border border-white/10 bg-white/[0.04] p-6 transition hover:border-[#c5a059]/50 hover:bg-[#c5a059]/5"><div className="text-3xl">{icon}</div><h3 className="mt-4 text-xl font-black">{title}</h3><p className="mt-3 leading-7 text-white/65">{desc}</p></div>)}
      </div>
    </section>

    <section className="bg-white/[0.025] px-5 py-20">
      <div className="mx-auto max-w-7xl"><h2 className="text-center text-3xl font-black md:text-5xl">{t('prices_suitable')}</h2><div className="mt-12 grid gap-5 lg:grid-cols-3">
        {plansList.map((p) => <div key={p.name} className={`relative rounded-3xl border p-7 ${p.name === 'PRO' ? 'border-[#c5a059] bg-[#c5a059]/10 shadow-[0_0_35px_rgba(197,160,89,0.2)]' : 'border-white/10 bg-black/30'}`}>{p.badge && <div className="absolute -top-4 right-6 rounded-full bg-[#c5a059] px-4 py-1 text-xs font-black text-black">{p.badge}</div>}<h3 className="text-2xl font-black">{p.name}</h3><div className="mt-4 text-3xl font-black text-[#c5a059]">{p.price}</div><ul className="mt-6 space-y-3 text-white/75">{p.features.map((f) => <li key={f}>✅ {f}</li>)}{p.misses.map((f) => <li key={f} className="text-white/35">❌ {f}</li>)}</ul><div className="mt-8"><CtaButton>{t('start_free')}</CtaButton></div></div>)}
      </div></div>
    </section>

    <section className="mx-auto max-w-7xl px-5 py-20"><h2 className="text-center text-3xl font-black md:text-5xl">{t('how_it_works')}</h2><div className="mt-12 grid gap-5 md:grid-cols-3">{[t('step_1'), t('step_2'), t('step_3')].map((s, i) => <div key={s} className="rounded-3xl border border-white/10 bg-white/[0.04] p-7"><div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-[#c5a059] text-xl font-black text-black">{i + 1}</div><p className="text-lg font-bold leading-8">{s}</p></div>)}</div></section>

    <section className="bg-white/[0.025] px-5 py-20"><div className="mx-auto max-w-4xl"><h2 className="text-center text-3xl font-black md:text-5xl">{t('faqs')}</h2><div className="mt-10 space-y-3">{faqsList.map(([q, a]) => <details key={q} className="rounded-2xl border border-white/10 bg-black/35 p-5"><summary className="cursor-pointer font-bold">{q}</summary><p className="mt-3 leading-7 text-white/65">{a}</p></details>)}</div></div></section>

    <section className="px-5 py-24 text-center"><h2 className="text-4xl font-black md:text-6xl">{t('ready_to_start')}</h2><p className="mx-auto mt-4 max-w-2xl text-white/70">{t('start_free_14_days')}</p><div className="mt-8"><CtaButton>{t('start_free_14_days')}</CtaButton></div><p className="mt-3 text-sm text-white/45">{t('no_credit_card')}</p></section>

    <footer className="border-t border-white/10 px-5 py-10"><div className="mx-auto flex max-w-7xl flex-col gap-5 text-center text-sm text-white/55 md:flex-row md:items-center md:justify-between"><div className="text-2xl font-black text-white">FLEXORA</div><div className="flex justify-center gap-5"><a className="cursor-pointer">{t('privacy_policy')}</a><a className="cursor-pointer">{t('terms_of_use')}</a><a className="cursor-pointer">{t('contact_us')}</a></div><div>© 2025 FLEXORA · {t('all_rights_reserved')}</div></div></footer>
  </main>;
}
