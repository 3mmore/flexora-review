'use client';
import { OperationalResourcePage } from '@/components/OperationalResourcePage';
import { useTranslation } from '@/lib/i18n';

export default function Page() {
  const { t } = useTranslation();
  return <OperationalResourcePage config={{ queryKey: 'white-label', endpoint: '/white-label/config', title: t('white_label_title'), narrative: t('white_label_narrative'), columns: [{ key: 'name' }, { key: 'logo' }, { key: 'accentColor' }] }} />;
}
