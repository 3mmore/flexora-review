'use client';
/**
 * FLEXORA Attendance Intelligence Center
 * Turns check-in records into retention, occupancy, peak-hour and recovery intelligence.
 */
import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import Shell from '@/components/Shell';
import { api, API_BASE_URL } from '@/lib/api';
import { useTranslation } from '@/lib/i18n';
import { ActionCenter, FeedbackLayer, InsightCard, InsightLayer, ProductPage, SmartAction, SmartTable } from '@/components/ProductOS';
import { Card } from '@/components/ui/Card';
import { EmptyState, Skeleton } from '@/components/ui/States';
import { Icon } from '@/components/brand/Icon';
import { safeErrorMessage } from '@/lib/safe-error';
import { attendanceCsvFilename, buildAttendanceCsvUrl } from '@/lib/attendance-csv';
import { useBranchScope } from '@/lib/branch-scope';
import { ModalPortal } from '@/components/ModalPortal';
import { label } from '@/lib/i18n/codes';
import { formatDate } from '@/lib/dates';

type AttendanceRow = {
  id: string;
  at: string;
  method?: string;
  staffName?: string;
  /** PACK 2 item 5: HOW the check-in was authorised; NULL = unknown, shown as «غير محدد» */
  source?: string | null;
  branchId?: string | null;
  member?: { id?: string; name?: string; mobile?: string };
  branch?: { id?: string; name?: string };
};

type MemberRow = {
  id: string;
  name: string;
  /** PHASE 5: which branch this member belongs to (null/absent = not branch-bound). */
  branchId?: string | null;
  mobile?: string;
  lastVisit?: string | null;
  status?: string;
  expiry?: string | null;
  sessionsLeft?: number | null;
  plan?: { name?: string; type?: string } | null;
};

type PeakHour = { hour: number; count: number };

const startOfDay = (d = new Date()) => {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
};
const daysAgo = (date?: string | null) => date ? Math.round((Date.now() - +new Date(date)) / 86400000) : 999;
const hourLabel = (h: number) => `${String(h).padStart(2, '0')}:00`;

export default function AttendanceIntelligenceCenter() {
  const { t, lang } = useTranslation();
  // PHASE 4/5: OWNER + MANAGER may filter across all branches; every other
  // role is pinned to their own branch and is shown no picker at all.
  const scope = useBranchScope();
  const [attendance, setAttendance] = useState<AttendanceRow[]>([]);
  const [members, setMembers] = useState<MemberRow[]>([]);
  const [branches, setBranches] = useState<any[]>([]);
  const [peak, setPeak] = useState<PeakHour[]>([]);
  const [busy, setBusy] = useState(true);
  const [showManual, setShowManual] = useState(false);
  const [manualForm, setManualForm] = useState({ memberId: '', branchId: '' });
  const [manualSearch, setManualSearch] = useState('');
  // PHASE 5: OWNER/MANAGER may view every branch or one at a time; restricted
  // roles never see this control and never send a branchId (the API pins them).
  const [attBranchFilter, setAttBranchFilter] = useState('');
  /** PACK 2 item 5 (owner decision): isolate unverified self check-ins */
  const [attSourceFilter, setAttSourceFilter] = useState('');
  const [summary, setSummary] = useState<{ date: string; total: number; selfPlain: number; verified: number } | null>(null);
  const attBranchName = branches.find((b) => b.id === attBranchFilter)?.name || '';
  const [err, setErr] = useState('');
  const [recoveryLog, setRecoveryLog] = useState<Array<{ id: string; title: string; at: string }>>([]);
  const [exportBusy, setExportBusy] = useState(false);
  const [exportErr, setExportErr] = useState('');

  /**
   * Download the SAME rows the table is showing, as CSV.
   *
   * The API writes the file (UTF-8 BOM so Arabic opens correctly in Excel,
   * formula-neutral cells so a member name starting with "=" cannot execute),
   * and this only hands the browser the bytes. The branch filter travels with
   * the request so the file cannot disagree with the screen.
   */
  const exportCsv = async () => {
    setExportBusy(true); setExportErr('');
    try {
      const res = await fetch(buildAttendanceCsvUrl(API_BASE_URL, attBranchFilter, attSourceFilter), { credentials: 'include' });
      if (!res.ok) { setExportErr(t('attendance_export_failed')); return; }
      const blob = await res.blob();
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = attendanceCsvFilename(res.headers.get('content-disposition'));
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(a.href);
    } catch { setExportErr(t('attendance_export_failed')); }
    finally { setExportBusy(false); }
  };

  /**
   * PHASE 5: the manual check-in dropdown only ever offers members of the branch
   * being checked into. The API refuses a mismatched member/branch pair with
   * `400 Member does not belong to this branch`, so offering one would be a
   * guaranteed dead end — the filter belongs in the list itself, not in an
   * error toast after the fact. (Members with no branch of their own remain
   * eligible anywhere, matching the API's own rule.)
   */
  const filteredManualMembers = useMemo(() => {
    // An owner who has not chosen the branch yet gets no member list at all —
    // showing every branch's members as a disabled list would still be the
    // wrong information on screen.
    if (scope.unrestricted && !manualForm.branchId) return [];
    const search = manualSearch.trim().toLowerCase();
    let list = members;
    if (manualForm.branchId) {
      list = list.filter((m) => !m.branchId || m.branchId === manualForm.branchId);
    }
    if (search) {
      list = list.filter((m) => m.name.toLowerCase().includes(search) || (m.mobile || '').includes(search));
    }
    return list.slice(0, 100);
  }, [members, manualSearch, manualForm.branchId, scope.unrestricted]);

  async function load() {
    setBusy(true);
    setErr('');
    try {
      // PHASE 5: the owner's chosen branch is applied SERVER-side through the
      // same `branchId` filter every other list uses. Restricted staff send no
      // branchId at all — the backend pins their own branch.
      const branchQuery = (scope.unrestricted && attBranchFilter
        ? `&branchId=${encodeURIComponent(attBranchFilter)}`
        : '') + (attSourceFilter ? `&source=${encodeURIComponent(attSourceFilter)}` : '');
      const [a, m, p, b, sum] = await Promise.all([
        api<{ items: AttendanceRow[] }>(`/attendance?limit=250${branchQuery}`).then((r) => r.items || []),
        api<{ items: MemberRow[] }>('/members?limit=1000').then((r) => r.items || []),
        api<PeakHour[]>('/reports/peak-hours').catch(() => []),
        api<any[]>('/branches').catch(() => []),
        // counted on the SERVER, in the gym's own day — the browser never adds up
        // a partial page and calls it a total
        api<{ date: string; total: number; selfPlain: number; verified: number }>(
          `/attendance/daily-summary${scope.unrestricted && attBranchFilter ? `?branchId=${encodeURIComponent(attBranchFilter)}` : ''}`,
        ).catch(() => null),
      ]);
      setAttendance(a);
      setMembers(m);
      setPeak(p);
      setBranches(b);
      setSummary(sum);
    } catch (e: unknown) {
      setErr((e as Error).message || t('attendance_failed'));
    } finally {
      setBusy(false);
    }
  }

  // Reloads on mount and whenever the owner changes the branch filter.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => { load(); }, [attBranchFilter, attSourceFilter]);

  /**
   * PHASE 3 (round 11): the manual check-in dropdown must be able to offer a
   * member the instant they are created — including on a page that has been
   * open for a while (someone added the member in another tab, then came back
   * to this one). `load()` only runs on mount / branch-filter change, so the
   * member list held in state could be older than the server's. Re-read the
   * list the moment the modal is opened; the server side is invalidated on
   * every member write, so this read is always fresh.
   */
  async function refreshMembersForCheckin() {
    try {
      const fresh = await api<{ items: MemberRow[] }>('/members?limit=1000');
      if (fresh?.items) setMembers(fresh.items);
    } catch {
      /* keep the list we already have — the user can still search it */
    }
  }

  async function handleManualCheckin() {
    if (!manualForm.memberId) return;
    try {
      // PHASE 4: restricted staff can only ever check members into their own
      // branch — the API pins it too, but never send anything else.
      const payload = scope.unrestricted
        ? manualForm
        : { ...manualForm, branchId: scope.branchId || '' };
      await api('/attendance/manual', { method: 'POST', body: JSON.stringify(payload) });
      setShowManual(false);
      setManualForm({ memberId: '', branchId: '' });
      await load();
    } catch (e) {
      alert(safeErrorMessage(e));
    }
  }

  const todayStart = startOfDay();
  const todayRows = attendance.filter((a) => +new Date(a.at) >= +todayStart);
  const activeToday = new Set(todayRows.map((a) => a.member?.id || a.member?.name).filter(Boolean)).size;
  const checkedInNow = todayRows.filter((a) => Date.now() - +new Date(a.at) < 2 * 60 * 60 * 1000).slice(0, 12);
  const hourlyToday = Array.from({ length: 24 }, (_, hour) => ({ hour, count: todayRows.filter((a) => new Date(a.at).getHours() === hour).length }));
  const peakToday = hourlyToday.slice().sort((a, b) => b.count - a.count)[0] || { hour: 0, count: 0 };
  const peakAll = peak.length ? peak.slice().sort((a, b) => b.count - a.count)[0] : peakToday;
  const quietHours = (peak.length ? peak : hourlyToday).filter((p) => p.count === 0).slice(0, 4);
  const capacityUtilization = Math.min(100, Math.round((checkedInNow.length / 50) * 100));
  const yesterdayRows = attendance.filter((a) => {
    const at = +new Date(a.at);
    return at >= +new Date(todayStart.getTime() - 86400000) && at < +todayStart;
  });
  const trend = todayRows.length - yesterdayRows.length;
  const weeklyVelocity = +(attendance.filter((a) => Date.now() - +new Date(a.at) < 7 * 86400000).length / 7).toFixed(1);
  const monthlyVelocity = +(attendance.filter((a) => Date.now() - +new Date(a.at) < 30 * 86400000).length / 30).toFixed(1);
  const absent14 = members.filter((m) => daysAgo(m.lastVisit) >= 14);
  const absent30 = members.filter((m) => daysAgo(m.lastVisit) >= 30);
  const highRisk = members.filter((m) => daysAgo(m.lastVisit) >= 14 || m.status === 'expired' || m.status === 'soon').slice(0, 12);

  const timeline = useMemo(() => [
    ...attendance.slice(0, 18).map((a) => ({ id: `check-${a.id}`, type: t('check_in'), title: `${a.member?.name || t('member')} ${t('member_checked_in')}`, detail: `${a.branch?.name || t('branch')} · ${a.method || ''} · ${a.source ? t('source_' + a.source.toLowerCase()) : t('source_unknown')}`, at: a.at })),
    ...absent14.slice(0, 6).map((m) => ({ id: `risk-${m.id}`, type: t('missed_attendance_alert'), title: `${m.name} ${t('has_been_absent')} ${daysAgo(m.lastVisit)} ${t('days')}`, detail: t('recovery_action_recommended'), at: new Date().toISOString() })),
    ...recoveryLog.map((r) => ({ id: r.id, type: t('recovery_action'), title: r.title, detail: t('action_recorded_session'), at: r.at })),
  ].sort((a, b) => +new Date(b.at) - +new Date(a.at)), [attendance, absent14, recoveryLog, t]);

  function recordRecovery(title: string) {
    setRecoveryLog((rows) => [{ id: `rec-${Date.now()}`, title, at: new Date().toISOString() }, ...rows].slice(0, 20));
  }

  return (
    <Shell>
      <ProductPage
        eyebrow={t('attendance')}
        title={t('attendance_title')}
        narrative={t('attendance_narrative')}
        primaryAction={{ label: t('checkin'), href: '/checkin', icon: 'qr-scan' }}
        secondaryAction={{ label: t('attendance_recovery_campaign'), href: '/campaigns?action=attendance-recovery', icon: 'send' }}
      >
        {err && <FeedbackLayer type="danger" title={t('attendance_failed')} detail={err} action={<button className="btn btn-ghost px-3 py-1.5 text-xs" onClick={load}>{t('retry')}</button>} />}

        <InsightLayer>
          {busy ? <><Skeleton /><Skeleton /><Skeleton /><Skeleton /></> : <>
            <InsightCard label={t('todays_checkins')} value={todayRows.length} detail={`${trend >= 0 ? '+' : ''}${trend} vs ${t('previous')}`} icon="home" tone={trend >= 0 ? 'good' : 'warning'} />
            <InsightCard label={t("active_now")} value={checkedInNow.length} detail={`${capacityUtilization}% ${t('estimated_floor_utilization')}`} icon="users" tone={capacityUtilization > 80 ? 'warning' : 'neutral'} />
            <InsightCard label={t("peak_hour")} value={hourLabel(peakToday.hour)} detail={`${peakToday.count} ${t('checkins_today')} · ${t('all_time_peak')} ${hourLabel(peakAll.hour)}`} icon="chart" />
            <InsightCard label={t("at_risk_members")} value={highRisk.length} detail={`${absent14.length} ${t('absent_14_days')} · ${absent30.length} ${t('absent_30_days')}`} icon="bell" tone={highRisk.length ? 'warning' : 'good'} />
          </>}
        </InsightLayer>

        <ActionCenter title={t("attendance_recovery_decisions")}>
          <SmartAction title={t("manual_checkin") || "Manual Check-in"} detail={t("checkin_without_scan") || "Check in a member without scanning"} icon="plus" onClick={() => { setManualForm(scope.unrestricted ? { memberId: '', branchId: '' } : { memberId: '', branchId: scope.branchId || '' }); setShowManual(true); void refreshMembersForCheckin(); }} />
          <SmartAction title={t("contact_inactive")} detail={`${absent14.length} ${t('contact_inactive_detail')}`} icon="users" tone="warning" onClick={() => recordRecovery(`${t('queued_contact_workflow')} ${absent14.length} ${t('inactive_members')}`)} />
          <SmartAction title={t("launch_campaign")} detail={t('campaign_absent_help')} icon="send" href="/campaigns?action=attendance-recovery" />
          <SmartAction title={t("review_attendance")} detail={trend < 0 ? `${Math.abs(trend)} ${t('review_attendance_detail')}` : t('attendance_stable')} icon="chart" href="/reports" tone={trend < 0 ? 'warning' : 'good'} />
        </ActionCenter>

        <section className="attendance-intel-grid">
          <Card padding="lg" className="attendance-live-board">
            <div className="product-section-head"><div><h2>{t('live_attendance_board')}</h2><p>{t('live_attendance_help')}</p></div><span className="risk-indicator" data-level={capacityUtilization > 80 ? 'high' : 'medium'}>{capacityUtilization}% {t('occupied')}</span></div>
            {busy ? <Skeleton lines={8} /> : checkedInNow.length ? <div className="attendance-live-list">{checkedInNow.map((a) => <div key={a.id} className="attendance-live-row"><div><b>{a.member?.name || t('member')}</b><span>{a.branch?.name || t('branch')} · {a.source ? t('source_' + a.source.toLowerCase()) : t('source_unknown')}</span></div><time>{new Date(a.at).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}</time></div>)}</div> : <EmptyState icon="home" title={t('no_one_checked_in')} description={t('open_checkin_help')} />}
          </Card>

          <Card padding="lg">
            <div className="product-section-head"><div><h2>{t('attendance_insights')}</h2><p>{t('attendance_insights_help')}</p></div></div>
            {busy ? <Skeleton lines={7} /> : <div className="attendance-insight-stack">
              <div><span>{t('daily_trend')}</span><b>{trend >= 0 ? t('growing') : t('declining')}</b><small>{trend >= 0 ? `${trend} ${t('more_checkins_yesterday')}` : `${Math.abs(trend)} ${t('fewer_checkins_yesterday')}`}</small></div>
              <div><span>{t('weekly_velocity')}</span><b>{weeklyVelocity}/{t('date')}</b><small>{t('weekly_average')}</small></div>
              <div><span>{t('monthly_velocity')}</span><b>{monthlyVelocity}/{t('date')}</b><small>{t('monthly_average')}</small></div>
            </div>}
          </Card>

          <Card padding="lg">
            <div className="product-section-head"><div><h2>{t('peak_hours_analysis')}</h2><p>{t('peak_hours_help')}</p></div></div>
            {busy ? <Skeleton lines={6} /> : <div className="attendance-hours-chart">{(peak.length ? peak : hourlyToday).map((p) => <div key={p.hour} title={`${hourLabel(p.hour)} · ${p.count}`}><i style={{ height: `${Math.max(4, (p.count / Math.max(peakAll.count, 1)) * 100)}%` }} /><span>{p.hour % 3 === 0 ? p.hour : ''}</span></div>)}</div>}
            <div className="attendance-staffing-note">{quietHours.length ? `${t('quiet_windows')}: ${quietHours.map((h) => hourLabel(h.hour)).join(', ')}. ${t('consider_staff_breaks')}` : t('no_quiet_windows')}</div>
          </Card>

          <Card padding="lg" className="attendance-risk-center">
            <div className="product-section-head"><div><h2>{t('risk_detection_center')}</h2><p>{t('risk_detection_help')}</p></div></div>
            {busy ? <Skeleton lines={8} /> : highRisk.length ? <div className="attendance-risk-list">{highRisk.map((m) => <div key={m.id} className="attendance-risk-row"><div><b>{m.name}</b><span>{daysAgo(m.lastVisit)} ${t('days_absent')} · {label(String(m.status ?? ''), 'memberStatus', lang === 'en' ? 'en' : 'ar')}</span></div><div className="attendance-risk-actions"><a href={`tel:${m.mobile || ''}`} className="btn btn-ghost px-2 py-1 text-xs">{t('call')}</a><button className="btn btn-secondary px-2 py-1 text-xs" onClick={() => recordRecovery(`${t('reminder')} ${m.name}`)}>{t('reminder')}</button></div></div>)}</div> : <EmptyState icon="shield" title={t('no_attendance_risk')} description={t('no_attendance_risk_help')} />}
          </Card>

          <Card padding="lg" className="attendance-timeline-card">
            <div className="product-section-head"><div><h2>{t('attendance_timeline')}</h2><p>{t('attendance_timeline_help')}</p></div></div>
            {busy ? <Skeleton lines={10} /> : timeline.length ? <div className="attendance-timeline">{timeline.slice(0, 24).map((e) => <div key={e.id} className="attendance-timeline-event"><div><span>{e.type}</span><b>{e.title}</b><small>{e.detail}</small></div><time>{`${formatDate(e.at)} ${new Date(e.at).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}`}</time></div>)}</div> : <EmptyState icon="bell" title={t('no_attendance_story')} description={t('attendance_story_help')} />}
          </Card>
        </section>

        {/* PHASE 5: attendance history obeys the same branch rule as the rest
            of the system — owner/manager pick a branch (or all of them), every
            other role is pinned to their own and shown no control at all. */}
        <div className="product-section-head" style={{ marginTop: 28 }}>
          <div>
            <h2>{t('attendance_history') || 'Attendance history'}</h2>
            <p>{t('attendance_history_help') || 'Every check-in recorded for the selected branch.'}</p>
          </div>
          <div className="flex items-center gap-2 flex-wrap justify-end">
          {scope.unrestricted ? (
            <select
              className="input py-1.5 text-sm min-w-[200px]"
              data-testid="attendance-branch-filter"
              aria-label={t('filter_branch')}
              value={attBranchFilter}
              onChange={(e) => setAttBranchFilter(e.target.value)}
            >
              <option value="">{t('all_branches') || 'All branches'}</option>
              {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
            </select>
          ) : (
            <span className="badge badge-active" data-testid="attendance-branch-locked">
              {t('branch') || 'Branch'}: {scope.branchName || scope.branchId || '—'}
            </span>
          )}
            {/* PACK 2 item 5 (owner decision): isolate unverified self check-ins so
                the owner can see abuse at a glance. The options are the allowlist;
                the value is validated again on the server. */}
            <select
              className="input py-1.5 text-sm min-w-[190px]"
              data-testid="attendance-source-filter"
              aria-label={t('attendance_source')}
              value={attSourceFilter}
              onChange={(e) => setAttSourceFilter(e.target.value)}
            >
              <option value="">{t('source_filter_all')}</option>
              <option value="SELF_PLAIN">{t('source_self_plain')}</option>
              <option value="SELF_QR">{t('source_self_qr')}</option>
              <option value="SELF_IP">{t('source_self_ip')}</option>
              <option value="SELF_GEO">{t('source_self_geo')}</option>
              <option value="SELF_IP_GEO">{t('source_self_ip_geo')}</option>
              <option value="STAFF">{t('source_staff')}</option>
              <option value="KIOSK">{t('source_kiosk')}</option>
            </select>
            <button
              type="button"
              className="btn btn-secondary"
              data-testid="attendance-export"
              disabled={exportBusy || busy || attendance.length === 0}
              onClick={exportCsv}
            >
              {exportBusy ? t('attendance_exporting') : t('attendance_export_csv')}
            </button>
          </div>
        </div>
        {exportErr && (
          <p className="text-xs mb-2" style={{ color: 'var(--danger, #b91c1c)' }} role="alert" data-testid="attendance-export-error">
            {exportErr}
          </p>
        )}
        {scope.unrestricted && attBranchName && (
          <p className="text-xs text-[var(--silver-dim)] mb-2" data-testid="attendance-branch-note">
            {t('showing_branch_only') || 'Showing'} {attBranchName}
          </p>
        )}

        {/* Counted on the server for the gym's own day. «بدون تحقق» is shown in
            the warning colour: it is not an error, but it is the number an owner
            checks after turning the feature on. */}
        {summary && (
          <div className="flex items-center gap-3 flex-wrap mb-3" data-testid="attendance-daily-summary">
            <span className="text-xs text-[var(--silver-dim)]">{t('attendance_summary_today')}:</span>
            <span className="badge badge-active" data-testid="summary-total">{summary.total}</span>
            <span className="text-xs text-[var(--silver-dim)]">{t('attendance_summary_verified')}:</span>
            <span className="badge" data-testid="summary-verified">{summary.verified}</span>
            <span className="text-xs text-[var(--silver-dim)]">{t('attendance_summary_plain')}:</span>
            <span
              className="badge"
              data-testid="summary-plain"
              style={summary.selfPlain > 0
                ? { color: 'var(--warning, #b45309)', borderColor: 'var(--warning, #b45309)' }
                : undefined}
              title={t('source_self_plain_hint')}
            >
              {summary.selfPlain}
            </span>
          </div>
        )}

        <SmartTable
          columns={[t('member'), t('date'), t('time'), t('branch'), t('staff'), t('attendance_source')]}
          rows={attendance}
          loading={busy}
          emptyTitle={t("no_attendance_data")}
          emptyDescription={t('build_retention_signals')}
          renderRow={(a: AttendanceRow) => (
            <tr key={a.id}>
              <td>{a.member?.name || t('member')}</td>
              <td>{formatDate(a.at)}</td>
              <td>{new Date(a.at).toLocaleTimeString('en-GB')}</td>
              <td>{a.branch?.name || '—'}</td>
              <td>{a.staffName || '—'}</td>
              <td>
                {a.source === 'SELF_PLAIN' ? (
                  <span
                    className="badge"
                    data-testid="source-plain-chip"
                    style={{ color: 'var(--warning, #b45309)', borderColor: 'var(--warning, #b45309)' }}
                    title={t('source_self_plain_hint')}
                  >
                    {t('source_self_plain')}
                  </span>
                ) : a.source ? t('source_' + a.source.toLowerCase()) : t('source_unknown')}
              </td>
            </tr>
          )}
        />

        {showManual && (
          <ModalPortal>
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4">
            <div className="card card-static glass max-w-md w-full p-6">
              <h2 className="text-xl font-bold mb-4 text-white">{t('manual_checkin') || "Manual Check-in"}</h2>
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('member')}</label>
                  <input 
                    className="input w-full mb-2" 
                    placeholder={t('search_members')} 
                    value={manualSearch}
                    onChange={(e) => setManualSearch(e.target.value)} 
                  />
                  <select
                    className="input w-full"
                    data-testid="manual-member-select"
                    value={manualForm.memberId}
                    disabled={scope.unrestricted && !manualForm.branchId}
                    onChange={e => setManualForm({ ...manualForm, memberId: e.target.value })}
                  >
                    <option value="">
                      {scope.unrestricted && !manualForm.branchId
                        ? (t('select_branch_first') || 'Select a branch first')
                        : t('select_member')}
                    </option>
                    {filteredManualMembers.map((m) => <option key={m.id} value={m.id}>{m.name} ({m.mobile})</option>)}
                  </select>
                </div>
                {scope.unrestricted ? (
                  <div>
                    <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('branch')}</label>
                    {/* PHASE 5: the branch drives the member list above, so it
                        is chosen FIRST and changing it clears any member that
                        belongs elsewhere. "All branches" is deliberately not an
                        option here — a check-in always lands in ONE branch. */}
                    <select
                      className="input w-full"
                      data-testid="manual-branch-select"
                      value={manualForm.branchId}
                      onChange={e => setManualForm({ ...manualForm, branchId: e.target.value, memberId: '' })}
                    >
                      <option value="">{t('select_branch') || 'Select branch'}</option>
                      {branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
                    </select>
                    {!manualForm.branchId && (
                      <p className="text-xs text-[var(--silver-dim)] mt-1">{t('manual_branch_required') || 'Choose the branch first — the member list follows it.'}</p>
                    )}
                  </div>
                ) : (
                  <div>
                    <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('branch')}</label>
                    <div className="badge badge-active" data-testid="manual-branch-locked">
                      {scope.branchName || branches.find((b) => b.id === scope.branchId)?.name || '—'}
                    </div>
                  </div>
                )}
              </div>
              <div className="flex gap-2 justify-end mt-6">
                <button className="btn btn-ghost" onClick={() => setShowManual(false)}>{t('cancel')}</button>
                <button className="btn btn-primary" onClick={handleManualCheckin} disabled={!manualForm.memberId || (scope.unrestricted && !manualForm.branchId)}>{t('checkin')}</button>
              </div>
            </div>
          </div>
        </ModalPortal>
        )}
      </ProductPage>
    </Shell>
  );
}
