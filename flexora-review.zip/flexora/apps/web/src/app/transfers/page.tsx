"use client";
import { useMemo, useState, useEffect } from "react";
import { formatDate } from '@/lib/dates';
import Shell from "@/components/Shell";
import { ProductPage, InsightLayer, InsightCard, SmartTable, ActionCenter, SmartAction, FeedbackLayer } from "@/components/ProductOS";
import { Skeleton, EmptyState } from "@/components/ui/States";
import { Button } from "@/components/ui/Button";
import { api, auth } from "@/lib/api";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useTranslation } from "@/lib/i18n";
import { safeErrorMessage } from "@/lib/safe-error";
import { ModalPortal } from '@/components/ModalPortal';

export default function TransfersPage() {
  const { t } = useTranslation();
  const qc = useQueryClient();
  const [user, setUser] = useState<any>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [form, setForm] = useState({ entity: 'MEMBER', entityId: '', toBranchId: '', reason: '' });
  const [err, setErr] = useState('');

  useEffect(() => { auth.me().then(setUser); }, []);

  const query = useQuery({ queryKey: ["transfers"], queryFn: () => api<any[]>("/transfers") });
  const branchesQuery = useQuery({ queryKey: ["branches"], queryFn: () => api<any>("/branches").then(res => Array.isArray(res) ? res : (res.items || [])) });
  const membersQuery = useQuery({ queryKey: ["members-list"], queryFn: () => api<any>("/members?limit=1000").then(res => res.items || []) });
  const coachesQuery = useQuery({ queryKey: ["coaches-list"], queryFn: () => api<any[]>("/users").then(users => users.filter(u => u.role === 'COACH')) });
  const productsQuery = useQuery({ queryKey: ["products-list"], queryFn: () => api<any[]>("/products") });
  
  const createMutation = useMutation({ 
    mutationFn: (payload: any) => api("/transfers", { method: "POST", body: JSON.stringify(payload) }), 
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["transfers"] });
      setShowCreate(false);
      setForm({ entity: 'MEMBER', entityId: '', toBranchId: '', reason: '' });
    },
    onError: (e) => setErr(safeErrorMessage(e))
  });

  const approveMutation = useMutation({
    mutationFn: (id: string) => api(`/transfers/${id}/approve`, { method: "POST" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["transfers"] })
  });

  const completeMutation = useMutation({
    mutationFn: (id: string) => api(`/transfers/${id}/complete`, { method: "POST" }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["transfers"] })
  });

  const rows = query.data || [];

  return <Shell>
    <ProductPage 
      eyebrow={t('operations')} 
      title={t('branch_transfers')} 
      narrative={t('move_members_desc')} 
      primaryAction={{ label: t('add'), icon: 'plus', onClick: () => setShowCreate(true) }}
    >
      {err && <FeedbackLayer type="danger" title={t('operation_failed')} detail={err} />}
      
      <InsightLayer>
        <InsightCard label={t('total')} value={rows.length} detail={t('records')} icon="send" />
        <InsightCard label={t('st_PENDING')} value={rows.filter(r => r.status === 'PENDING').length} detail={t('need_attention')} icon="bell" tone="warning" />
        <InsightCard label={t('st_COMPLETED')} value={rows.filter(r => r.status === 'COMPLETED').length} detail={t('success')} icon="shield" tone="good" />
      </InsightLayer>

      {query.isLoading ? <Skeleton lines={8} /> : (
        <SmartTable 
          columns={[t('date'), t('member'), t('to'), t('status'), t('actions')]} 
          rows={rows} 
          emptyTitle={t('no_data')} 
          emptyDescription={t('get_started_desc')}
          renderRow={(r) => (
            <tr key={r.id}>
              <td>{formatDate(r.createdAt)}</td>
              <td>{r.entity === 'MEMBER' ? membersQuery.data?.find((m: any) => m.id === r.entityId)?.name || r.entityId : r.entityId} ({t(r.entity.toLowerCase()) || r.entity})</td>
              <td>{branchesQuery.data?.find((b: any) => b.id === r.toBranchId)?.name || r.toBranchId}</td>
              <td><span className={`badge ${r.status === 'COMPLETED' ? 'badge-active' : r.status === 'PENDING' ? 'badge-frozen' : 'badge-soon'}`}>{t('st_' + r.status) || r.status}</span></td>
              <td>
                <div className="flex gap-2">
                  {r.status === 'PENDING' && (user?.role === 'OWNER' || user?.role === 'MANAGER') && <button className="btn btn-secondary btn-sm" onClick={() => approveMutation.mutate(r.id)}>{t('confirm')}</button>}
                  {r.status === 'APPROVED' && (user?.role === 'OWNER' || user?.role === 'MANAGER') && <button className="btn btn-primary btn-sm" onClick={() => completeMutation.mutate(r.id)}>{t('complete')}</button>}
                </div>
              </td>
            </tr>
          )} 
        />
      )}

      {showCreate && (
        <ModalPortal>
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4">
          <div className="card card-static glass max-w-md w-full p-6">
            <h2 className="text-xl font-bold mb-4 text-white">{t('add')} {t('transfer')}</h2>
            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('type')}</label>
                <select className="input w-full" value={form.entity} onChange={e => setForm({...form, entity: e.target.value})}>
                  <option value="MEMBER">{t('member')}</option>
                  <option value="COACH">{t('coach')}</option>
                  <option value="INVENTORY">{t('inventory')}</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('member')}/{t('coach')}/{t('product')}</label>
                <select className="input w-full" value={form.entityId} onChange={e => setForm({...form, entityId: e.target.value})}>
                  <option value="">{t('select') || 'Select...'}</option>
                  {form.entity === 'MEMBER' && membersQuery.data?.map((m: any) => <option key={m.id} value={m.id}>{m.name}</option>)}
                  {form.entity === 'COACH' && coachesQuery.data?.map((u: any) => <option key={u.id} value={u.id}>{u.name}</option>)}
                  {form.entity === 'INVENTORY' && productsQuery.data?.map((p: any) => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('to')} {t('branch')}</label>
                <select className="input w-full" value={form.toBranchId} onChange={e => setForm({...form, toBranchId: e.target.value})}>
                  <option value="">{t('select_branch')}</option>
                  {branchesQuery.data?.map((b: any) => <option key={b.id} value={b.id}>{b.name}</option>)}
                </select>
              </div>
              <div>
                <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('notes')}</label>
                <textarea className="input w-full h-20" value={form.reason} onChange={e => setForm({...form, reason: e.target.value})} />
              </div>
            </div>
            <div className="flex gap-2 justify-end mt-6">
              <button className="btn btn-ghost" onClick={() => setShowCreate(false)}>{t('cancel')}</button>
              <button className="btn btn-primary" onClick={() => createMutation.mutate(form)} disabled={!form.entityId || !form.toBranchId}>{t('create')}</button>
            </div>
          </div>
        </div>
        </ModalPortal>
      )}
    </ProductPage>
  </Shell>;
}
