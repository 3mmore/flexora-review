'use client';
/**
 * FLEXORA Revenue Command Center
 * Sales transformed from transaction history into executive revenue intelligence.
 */
import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { ActionCenter, FeedbackLayer, InsightCard, InsightLayer, ProductPage, SmartAction, SmartTable } from '@/components/ProductOS';
import { Card } from '@/components/ui/Card';
import { EmptyState, Skeleton } from '@/components/ui/States';
import { Icon } from '@/components/brand/Icon';
import { useTranslation } from '@/lib/i18n';
import { fmtMoney } from '@/lib/money';
import { useBranchScope } from '@/lib/branch-scope';
import { weekdayName } from '@/lib/dates';

type SaleItem = { id: string; productId?: string; name: string; qty: number; price: number | string };
type Sale = { id: string; invoiceNo: string; subtotal?: number | string; discount?: number | string; total: number | string; memberId?: string | null; userName?: string; createdAt: string; items?: SaleItem[] };
type Member = { id: string; name: string; mobile?: string; status?: string; lastVisit?: string; expiry?: string; plan?: { name?: string } };
type Branch = { id: string; name: string; stats?: { members?: number; staff?: number; revenue?: number } };
type ProductStats = { bestSellers?: Array<{ productId?: string; name: string; _sum?: { qty?: number } }>; inventoryValue?: number; lowStock?: Array<{ id: string; name: string; qty: number }> };

type ProductRevenue = { key: string; name: string; qty: number; revenue: number; sales: number };
type CustomerRevenue = { id: string; name: string; revenue: number; purchases: number; member?: Member };

const money = (value?: number | string) => fmtMoney(value);
const pct = (current = 0, previous = 0) => previous <= 0 ? (current > 0 ? 100 : 0) : Math.round(((current - previous) / previous) * 100);
const tone = (value: number) => value > 8 ? 'good' : value < -8 ? 'warning' : 'neutral';

function startOfDay(d = new Date()) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}

function MiniTrend({ points }: { points: Array<{ label: string; value: number }> }) {
  const { t } = useTranslation();
  const max = Math.max(1, ...points.map((p) => p.value));
  if (!points.length) return <EmptyState icon="chart" title={t('revenue_story_starts')} description={t('record_sales_growth')} />;
  return <div className="sales-trend-bars">{points.map((p) => <div key={p.label}><i style={{ height: `${Math.max(5, (p.value / max) * 100)}%` }} /><span>{p.label}</span></div>)}</div>;
}

/** Local {name} interpolation — t() takes no placeholders in this codebase. */
function fill(template: string, vars: Record<string, string>): string {
  return template.replace(/\{(\w+)\}/g, (_, k) => vars[k] ?? '');
}

export default function RevenueCommandCenter() {
  const { t, lang } = useTranslation();
  const [sales, setSales] = useState<Sale[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [branches, setBranches] = useState<Branch[]>([]);
  const [productStats, setProductStats] = useState<ProductStats | null>(null);
  const [busy, setBusy] = useState(true);
  const [err, setErr] = useState('');

  /** PHASE 4: restricted roles get their own branch back from /branches. */
  const scope = useBranchScope();

  async function load() {
    setBusy(true);
    setErr('');
    try {
      const [s, m, b, ps] = await Promise.all([
        api<{ items: Sale[] }>('/sales?limit=250').then((r) => r.items || []),
        api<{ items: Member[] }>('/members?limit=250').then((r) => r.items || []),
        api<Branch[]>('/branches').catch(() => []),
        api<ProductStats>('/products/stats').catch(() => null),
      ]);
      setSales(s);
      setMembers(m);
      setBranches(b);
      setProductStats(ps);
    } catch (e: unknown) {
      setErr((e as Error).message || t('operation_failed'));
    } finally {
      setBusy(false);
    }
  }
  useEffect(() => { load(); }, []);

  const today = startOfDay();
  const yesterday = new Date(+today - 86400000);
  const todaySales = sales.filter((s) => +new Date(s.createdAt) >= +today);
  const yesterdaySales = sales.filter((s) => +new Date(s.createdAt) >= +yesterday && +new Date(s.createdAt) < +today);
  const totalRevenue = sales.reduce((sum, s) => sum + Number(s.total || 0), 0);
  const todayRevenue = todaySales.reduce((sum, s) => sum + Number(s.total || 0), 0);
  const yesterdayRevenue = yesterdaySales.reduce((sum, s) => sum + Number(s.total || 0), 0);
  const revenueGrowth = pct(todayRevenue, yesterdayRevenue);
  const averageOrderValue = sales.length ? totalRevenue / sales.length : 0;
  const revenueVelocity = todaySales.length ? todayRevenue / Math.max((Date.now() - +today) / 3600000, 1) : 0;

  const productRevenue = useMemo(() => {
    const map = new Map<string, ProductRevenue>();
    for (const sale of sales) {
      for (const item of sale.items || []) {
        const key = item.productId || item.name;
        const cur = map.get(key) || { key, name: item.name, qty: 0, revenue: 0, sales: 0 };
        cur.qty += item.qty;
        cur.revenue += Number(item.price || 0) * item.qty;
        cur.sales += 1;
        map.set(key, cur);
      }
    }
    return Array.from(map.values()).sort((a, b) => b.revenue - a.revenue);
  }, [sales]);

  const customerRevenue = useMemo(() => {
    const map = new Map<string, CustomerRevenue>();
    for (const sale of sales) {
      const id = sale.memberId || 'walk-in';
      const member = members.find((m) => m.id === id);
      const cur = map.get(id) || { id, name: member?.name || (id === 'walk-in' ? t('walk_in') : t('none')), revenue: 0, purchases: 0, member };
      cur.revenue += Number(sale.total || 0);
      cur.purchases += 1;
      map.set(id, cur);
    }
    return Array.from(map.values()).sort((a, b) => b.revenue - a.revenue);
  }, [sales, members, t]);

  const topProduct = productRevenue[0];
  const fastestProduct = productRevenue.slice().sort((a, b) => b.qty - a.qty)[0];
  const topCustomer = customerRevenue[0];
  const concentrationRisk = topProduct && totalRevenue ? Math.round((topProduct.revenue / totalRevenue) * 100) : 0;
  const customerConcentration = topCustomer && totalRevenue ? Math.round((topCustomer.revenue / totalRevenue) * 100) : 0;
  const revenueRisk = revenueGrowth < -8 || concentrationRisk > 45 || customerConcentration > 35;
  const highValueAtRisk = customerRevenue.filter((c) => c.id !== 'walk-in' && (c.member?.status === 'expired' || c.member?.status === 'soon')).slice(0, 6);
  const dailyTrend = Array.from({ length: 7 }, (_, i) => {
    const day = new Date(+today - (6 - i) * 86400000);
    const next = new Date(+day + 86400000);
    return { label: weekdayName(day, lang === 'en' ? 'en' : 'ar'), value: sales.filter((s) => +new Date(s.createdAt) >= +day && +new Date(s.createdAt) < +next).reduce((sum, s) => sum + Number(s.total || 0), 0) };
  });
  const timeline = [
    ...sales.slice(0, 20).map((sale) => ({ id: `sale-${sale.id}`, type: t('sale'), title: sale.invoiceNo, detail: `${money(sale.total)} · ${sale.userName || t('staff')}`, at: sale.createdAt })),
    ...(topProduct ? [{ id: 'top-product', type: t('milestone') || 'Milestone', title: `${topProduct.name} leads revenue`, detail: `${money(topProduct.revenue)} contribution`, at: new Date().toISOString() }] : []),
    ...(topCustomer ? [{ id: 'top-customer', type: t('milestone') || 'Milestone', title: `${topCustomer.name} is top customer`, detail: `${money(topCustomer.revenue)} lifetime contribution`, at: new Date().toISOString() }] : []),
  ].sort((a, b) => +new Date(b.at) - +new Date(a.at));
  const attentionBranch = [...branches].sort((a, b) => Number(a.stats?.revenue || 0) - Number(b.stats?.revenue || 0))[0];

  const trendText = revenueGrowth > 8 ? t('growing') : revenueGrowth < -8 ? t('declining') : t('stable');

  return (
    <Shell>
      <ProductPage
        eyebrow={t('revenue_command_center')}
        title={t('revenue_intelligence_not_history')}
        narrative={fill(t('sales_narrative_revenue_trend'), { trend: trendText })}
        primaryAction={{ label: t('pos'), href: '/pos', icon: 'coins' }}
        secondaryAction={{ label: t('revenue_risk_label'), href: revenueRisk ? '/inventory' : '/reports', icon: 'bell' }}
      >
        {err && <FeedbackLayer type="danger" title={t('operation_failed')} detail={err} action={<button className="btn btn-ghost px-3 py-1.5 text-xs" onClick={load}>{t('retry')}</button>} />}

        <InsightLayer>
          {busy ? <><Skeleton /><Skeleton /><Skeleton /><Skeleton /></> : <>
            <InsightCard label={t('revenue_label')} value={money(totalRevenue)} detail={`${sales.length} ${t('transactions')}`} icon="coins" />
            <InsightCard label={t('growth_label')} value={`${revenueGrowth >= 0 ? '+' : ''}${revenueGrowth}%`} detail={fill(t('reports_revenue_trend'), { trend: trendText })} icon="chart" tone={tone(revenueGrowth) as 'good' | 'warning' | 'neutral'} />
            <InsightCard label={t('average_sale_label')} value={money(averageOrderValue)} detail={t('average_sale_label')} icon="sparkle" />
            <InsightCard label={t('revenue_risk_label')} value={revenueRisk ? t('active') : t('low')} detail={revenueRisk ? t('need_attention') : t('no_revenue_recorded')} icon="bell" tone={revenueRisk ? 'warning' : 'good'} />
          </>}
        </InsightLayer>

        <ActionCenter title={t('revenue_decision_center')}>
          <SmartAction title={t('pos')} detail={t('move_fast_stock')} href="/pos" icon="coins" />
          <SmartAction title={t('products')} detail={topProduct ? `${topProduct.name} ${t('contributes')} ${concentrationRisk}%` : t('no_product_revenue')} href="/inventory" icon="menu-grid" />
          <SmartAction title={t('members')} detail={`${highValueAtRisk.length} ${t('high_risk_members')}`} href="/members" icon="users" tone={highValueAtRisk.length ? 'warning' : 'good'} />
          <SmartAction title={t('create_promotion')} detail={t('dead_stock_offer')} href="/campaigns?action=revenue-promo" icon="send" />
          <SmartAction title={t('inventory')} detail={t('low_stock_peak')} href="/inventory" icon="menu-grid" />
          <SmartAction title={t('revenue_risk_label')} detail={t('need_attention')} href="/reports" icon="chart" tone={revenueRisk ? 'warning' : 'neutral'} />
        </ActionCenter>

        <section className="sales-command-grid">
          <Card padding="lg" className="sales-executive-brief">
            <div className="product-section-head"><div><h2>{t('executive_revenue_header')}</h2></div><Icon name="coins" size={18} className="text-[var(--primary)]" /></div>
            {busy ? <Skeleton lines={7} /> : <div className="sales-brief-grid">
              <div><span>{t('top_product') || 'Top product'}</span><b>{topProduct?.name || t('none')}</b></div>
              <div><span>{t('top_customer') || 'Top customer'}</span><b>{topCustomer?.name || t('none')}</b></div>
              <div><span>{t('velocity')}</span><b>{money(revenueVelocity)}{t('per_hour_suffix')}</b></div>
              <div><span>{t('risk')}</span><b>{revenueRisk ? t('need_attention') : t('active')}</b></div>
            </div>}
          </Card>

          <Card padding="lg">
            <div className="product-section-head"><div><h2>{t('revenue_trend_center')}</h2></div></div>
            {busy ? <Skeleton lines={7} /> : <><MiniTrend points={dailyTrend} /><div className="sales-narrative"><b>{fill(t('reports_revenue_trend'), { trend: trendText })}.</b></div></>}
          </Card>

          <Card padding="lg">
            <div className="product-section-head"><div><h2>{t('product_revenue_intelligence')}</h2></div></div>
            {busy ? <Skeleton lines={8} /> : productRevenue.length ? <div className="sales-list">{productRevenue.slice(0, 8).map((p, i) => <div key={p.key}><div><b>{p.name}</b><span>{p.qty} {t('units')} · {p.sales} {t('sales')}</span></div><strong>{money(p.revenue)}</strong></div>)}</div> : <EmptyState icon="coins" title={t('no_product_revenue')} description={t('record_sales_growth')} />}
          </Card>

          <Card padding="lg">
            <div className="product-section-head"><div><h2>{t('customer_revenue_intelligence')}</h2></div></div>
            {busy ? <Skeleton lines={8} /> : customerRevenue.length ? <div className="sales-list">{customerRevenue.slice(0, 8).map((c, i) => <div key={c.id}><div><b>{c.name}</b><span>{c.purchases} {t('payment_events')} · {t('st_' + c.member?.status) || t('member')}</span></div><strong>{money(c.revenue)}</strong></div>)}</div> : <EmptyState icon="users" title={t('no_customer_revenue')} description={t('associate_member_desc')} />}
          </Card>

          <Card padding="lg">
            <div className="product-section-head"><div><h2>{t('opportunity_center')}</h2></div></div>
            {busy ? <Skeleton lines={7} /> : <div className="sales-opportunity-grid">
              <div><span>{t('upsell') || 'Upsell'}</span><b>{topProduct ? topProduct.name : t('none')}</b></div>
              <div><span>{t('cross_sell') || 'Cross-sell'}</span><b>{productRevenue.length > 1 ? `${productRevenue[0].name} + ${productRevenue[1].name}` : t('none')}</b></div>
            </div>}
          </Card>

          <Card padding="lg">
            <div className="product-section-head"><div><h2>{t('revenue_risk_center')}</h2></div></div>
            {busy ? <Skeleton lines={7} /> : revenueRisk ? <div className="sales-risk-stack">
              {revenueGrowth < -8 && <div><span className="risk-indicator" data-level="high">{t('revenue_decline')}</span></div>}
              {concentrationRisk > 45 && <div><span className="risk-indicator" data-level="high">{t('product_dependency')}</span></div>}
              {customerConcentration > 35 && <div><span className="risk-indicator" data-level="medium">{t('customer_concentration')}</span></div>}
            </div> : <EmptyState icon="shield" title={t('no_revenue_recorded')} description={t('no_revenue_recorded')} />}
          </Card>

          <Card padding="lg">
            <div className="product-section-head"><div><h2>{t('branch_revenue_comparison')}</h2></div></div>
            {!scope.unrestricted && !scope.loading && (
              <div className="badge badge-active mb-4" data-testid="sales-branch-locked">
                {t('branch') || 'Branch'}: {scope.branchName || branches[0]?.name || '—'}
              </div>
            )}
            {busy ? <Skeleton lines={8} /> : branches.length ? <div className="sales-list">{branches.slice().sort((a, b) => Number(b.stats?.revenue || 0) - Number(a.stats?.revenue || 0)).slice(0, 6).map((b, i) => <div key={b.id}><div><b>{b.name}</b><span>{b.stats?.members || 0} {t('members')} · {b.stats?.staff || 0} {t('staff')}</span></div><strong>{money(b.stats?.revenue || 0)}</strong></div>)}</div> : <EmptyState icon="home" title={t('no_branches_configured')} description={t('add_branches_compare')} />}
          </Card>

          <Card padding="lg" className="sales-timeline-card">
            <div className="product-section-head"><div><h2>{t('revenue_timeline')}</h2></div></div>
            {busy ? <Skeleton lines={9} /> : timeline.length ? <div className="sales-timeline">{timeline.slice(0, 24).map((e) => <div key={e.id}><div><span>{e.type}</span><b>{e.title}</b><small>{e.detail}</small></div><time>{new Date(e.at).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</time></div>)}</div> : <EmptyState icon="bell" title={t('no_live_activity')} description={t('activity_real_time')} />}
          </Card>
        </section>

        <SmartTable
          columns={[t('invoice'), t('total'), t('member'), t('staff'), t('date'), t('actions')]}
          rows={sales}
          loading={busy}
          emptyTitle={t('no_revenue_recorded')}
          emptyDescription={t('scan_start_checkout')}
          renderRow={(sale: Sale) => {
            const member = members.find((m) => m.id === sale.memberId);
            return <tr key={sale.id}><td>{sale.invoiceNo}</td><td>{money(sale.total)}</td><td>{member?.name || t('walk_in')}</td><td>{sale.userName || '—'}</td><td>{new Date(sale.createdAt).toLocaleString()}</td><td><Link className="btn btn-ghost px-3 py-1.5 text-xs" href="/pos">{t('pos')}</Link></td></tr>;
          }}
        />
      </ProductPage>
    </Shell>
  );
}
