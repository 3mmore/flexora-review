/**
 * FLEXORA Gym OS — Coach Dashboard
 * © 2024 Ammar Allam. All rights reserved.
 */
'use client';
import { useCallback, useEffect, useState } from 'react';
import { formatDate } from '@/lib/dates';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { useTranslation } from '@/lib/i18n';
import { FeedbackLayer, InsightCard, InsightLayer, ProductPage, SmartTable } from '@/components/ProductOS';
import { Skeleton, EmptyState } from '@/components/ui/States';
import { safeErrorMessage } from '@/lib/safe-error';
import { ModalPortal } from '@/components/ModalPortal';

interface Exercise {
  name: string;
  sets: number;
  reps: number;
  weight: number;
}

interface LogForm {
  id: string;
  notes?: string;
  progress?: string;
  exercises: Exercise[];
  nextPlan?: string;
  rating: number;
}

interface DashboardData {
  today: { id: string; scheduledAt: string; member: { name: string }; status: string; coachCheckedIn: boolean }[];
  upcoming: { id: string; scheduledAt: string; member: { name: string } }[];
  completedThisMonth: number;
  recentProgress: { memberName: string; date: string; progress: string }[];
}

export default function CoachDashboard() {
  const { t, lang } = useTranslation();
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');
  const [logForm, setLogForm] = useState<LogForm | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api<DashboardData>('/pt/coach-dashboard');
      setData(res);
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  async function checkIn(sessionId: string) {
    try {
      await api(`/pt/sessions/${sessionId}/check-in`, { method: 'POST' });
      load();
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    }
  }

  async function completeSession(e: React.FormEvent) {
    e.preventDefault();
    if (!logForm) return;
    setErr('');
    try {
      await api(`/pt/sessions/${logForm.id}/complete`, {
        method: 'PATCH',
        body: JSON.stringify({
          coachSessionNotes: logForm.notes,
          memberProgress: logForm.progress,
          exercisesDone: logForm.exercises,
          nextSessionPlan: logForm.nextPlan,
          rating: Number(logForm.rating),
        }),
      });
      setLogForm(null);
      load();
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    }
  }

  if (loading) return <Shell><Skeleton lines={10} /></Shell>;

  return (
    <Shell>
      <ProductPage
        eyebrow={t('coach')}
        title={t('personal_training')}
        narrative={t('pt_desc')}
      >
        <InsightLayer>
          <InsightCard label={t('todays_sessions')} value={data?.today?.length || 0} icon="calendar" detail={t('scheduled')} />
          <InsightCard label={t('completed_month')} value={data?.completedThisMonth || 0} icon="shield" tone="good" detail={t('attended')} />
        </InsightLayer>

        {err && <FeedbackLayer type="danger" title={t('operation_failed')} detail={err} />}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6">
          <div className="card p-6">
            <h3 className="text-xl font-bold mb-4">{t('todays_sessions')}</h3>
            <SmartTable
              columns={[t('time'), t('member'), t('status'), t('actions')]}
              rows={data?.today || []}
              emptyTitle={t('no_sessions_today')}
              emptyDescription={t('schedule_clear_desc')}
              renderRow={(s) => (
                <tr key={s.id}>
                  <td>{new Date(s.scheduledAt).toLocaleTimeString(lang === 'ar' ? 'ar-EG' : 'en-US', { hour: '2-digit', minute: '2-digit' })}</td>
                  <td>{s.member.name}</td>
                  <td><span className={`badge ${s.status === 'COMPLETED' ? 'badge-active' : 'badge-soon'}`}>{t(s.status.toLowerCase()) || s.status}</span></td>
                  <td>
                    <div className="flex gap-2">
                      {!s.coachCheckedIn && s.status === 'SCHEDULED' && (
                        <button className="btn-primary btn-sm" onClick={() => checkIn(s.id)}>{t('checkin')}</button>
                      )}
                      {s.status === 'SCHEDULED' && (
                        <button className="btn-secondary btn-sm" onClick={() => setLogForm({ id: s.id, rating: 5, exercises: [{ name: '', sets: 3, reps: 10, weight: 0 }] })}>{t('log_session')}</button>
                      )}
                    </div>
                  </td>
                </tr>
              )}
            />
          </div>

          <div className="card p-6">
            <h3 className="text-xl font-bold mb-4">{t('recent_progress')}</h3>
            <div className="space-y-4">
              {data?.recentProgress?.map((p, i: number) => (
                <div key={i} className="border-b border-[var(--border)] pb-2">
                  <div className="flex justify-between items-center">
                    <span className="font-bold">{p.memberName}</span>
                    <span className="text-xs text-[var(--muted)]">{formatDate(p.date)}</span>
                  </div>
                  <p className="text-sm text-[var(--silver-dim)] mt-1">{p.progress}</p>
                </div>
              )) || <EmptyState icon="chart" title={t('no_recent_progress')} description={t('completed_session_desc')} />}
            </div>
          </div>
        </div>
      </ProductPage>

      {logForm && (
        <ModalPortal>
        <div className="fixed inset-0 bg-black/70 grid place-items-center p-5 z-50" onClick={() => setLogForm(null)}>
          <form onClick={(e) => e.stopPropagation()} onSubmit={completeSession} className="card card-static glass w-full max-w-2xl max-h-[90vh] overflow-auto">
            <h3 className="text-title text-white mb-4">{t('log_session')}</h3>
            <div className="grid grid-cols-1 gap-4">
              <div>
                <label className="text-label mb-1 block">{t('exercises')}</label>
                {logForm.exercises.map((ex, i: number) => (
                  <div key={i} className="grid grid-cols-4 gap-2 mb-2">
                    <input className="input" placeholder={t('class')} value={ex.name} onChange={(e) => {
                      const exes = [...logForm.exercises];
                      exes[i].name = e.target.value;
                      setLogForm({ ...logForm, exercises: exes });
                    }} required />
                    <input className="input" type="number" placeholder={t('sets')} value={ex.sets} onChange={(e) => {
                      const exes = [...logForm.exercises];
                      exes[i].sets = Number(e.target.value);
                      setLogForm({ ...logForm, exercises: exes });
                    }} />
                    <input className="input" type="number" placeholder={t('reps')} value={ex.reps} onChange={(e) => {
                      const exes = [...logForm.exercises];
                      exes[i].reps = Number(e.target.value);
                      setLogForm({ ...logForm, exercises: exes });
                    }} />
                    <input className="input" type="number" placeholder={t('weight_kg')} value={ex.weight} onChange={(e) => {
                      const exes = [...logForm.exercises];
                      exes[i].weight = Number(e.target.value);
                      setLogForm({ ...logForm, exercises: exes });
                    }} />
                  </div>
                ))}
                <button type="button" className="btn-ghost btn-sm" onClick={() => setLogForm({ ...logForm, exercises: [...logForm.exercises, { name: '', sets: 3, reps: 10, weight: 0 }] })}>+ {t('add_exercise')}</button>
              </div>

              <div>
                <label className="text-label mb-1 block">{t('session_notes')}</label>
                <textarea className="input w-full" rows={2} value={logForm.notes || ''} onChange={(e) => setLogForm({ ...logForm, notes: e.target.value })} />
              </div>

              <div>
                <label className="text-label mb-1 block">{t('member_health_average')}</label>
                <textarea className="input w-full" rows={2} value={logForm.progress || ''} onChange={(e) => setLogForm({ ...logForm, progress: e.target.value })} />
              </div>

              <div>
                <label className="text-label mb-1 block">{t('next_session_goal')}</label>
                <input className="input w-full" value={logForm.nextPlan || ''} onChange={(e) => setLogForm({ ...logForm, nextPlan: e.target.value })} />
              </div>

              <div>
                <label className="text-label mb-1 block">{t('rating_label')}</label>
                <input className="input w-full" type="number" min={1} max={5} value={logForm.rating} onChange={(e) => setLogForm({ ...logForm, rating: Number(e.target.value) })} />
              </div>
            </div>
            <div className="flex gap-2 justify-end mt-4">
              <button type="button" className="btn-ghost" onClick={() => setLogForm(null)}>{t('cancel')}</button>
              <button className="btn-primary">{t('save_complete')}</button>
            </div>
          </form>
        </div>
        </ModalPortal>
      )}
    </Shell>
  );
}
