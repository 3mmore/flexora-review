/**
 * FLEXORA Gym OS
 * © 2024 Ammar Allam. All rights reserved.
 */
'use client';
import { useCallback, useEffect, useState } from 'react';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { useTranslation } from '@/lib/i18n';
import { localizePlanName, planOptionLabel } from '@/lib/plan-label';
import { FeedbackLayer, InsightCard, InsightLayer, ProductPage, SmartTable } from '@/components/ProductOS';
import { Skeleton } from '@/components/ui/States';
import { safeErrorMessage } from '@/lib/safe-error';
import { ModalPortal } from '@/components/ModalPortal';

interface Plan {
  id?: string;
  name: string;
  type: string;
  sessions?: number;
  days: number;
  price: number;
  active: boolean;
  invitations: number;
  maxFreezes: number;
  freezeDays: number;
}

export default function Plans() {
  const { t, lang } = useTranslation();
  const [items, setItems] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<Partial<Plan> | null>(null);
  const [err, setErr] = useState('');
  const [deleteDialog, setDeleteDialog] = useState<{ id: string; memberCount: number } | null>(null);
  const [targetPlanId, setTargetPlanId] = useState('');
  // ROUND 14 (security review, PHASE B): deleting a plan is plans.delete —
  // OWNER-only by default (the API enforces it too).
  const [perms, setPerms] = useState<string[] | null>(null);
  useEffect(() => { api<any>('/auth/me').then((r) => setPerms(r?.user?.permissions || [])).catch(() => setPerms([])); }, []);
  const canDeletePlans = perms === null || (perms || []).includes('plans.delete');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api<any>('/plans');
      setItems(Array.isArray(data) ? data : (data.items || []));
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!form) return;
    setErr('');
    if (!form.id) { 
      const dup = items.find((p) => p.name === form.name && p.type === form.type && p.price === form.price); 
      if (dup) { setErr(t('plan_duplicate')); return; } 
    }
    const payload = { 
      ...form, 
      price: Number(form.price), 
      sessions: form.sessions ? Number(form.sessions) : undefined, 
      days: Number(form.days),
      invitations: Number(form.invitations || 0),
      maxFreezes: Number(form.maxFreezes || 0),
      freezeDays: Number(form.freezeDays || 0)
    };
    try {
      if (form.id) {
        await api(`/plans/${form.id}`, { method: 'PATCH', body: JSON.stringify(payload) });
      } else {
        await api('/plans', { method: 'POST', body: JSON.stringify(payload) });
      }
      setForm(null);
      load();
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    }
  }

  async function del(id: string, targetId?: string) {
    try {
      const url = targetId ? `/plans/${id}?targetPlanId=${targetId}` : `/plans/${id}`;
      await api(url, { method: 'DELETE' });
      setDeleteDialog(null);
      setTargetPlanId('');
      load();
    } catch (e: any) {
      const errorData = await (async () => {
        try { return JSON.parse(e.message); } catch { return null; }
      })();
      // PHASE N1.5: the database now refuses to delete a plan that members or
      // renewal history still point at ("Member"."planId" is NOT NULL with
      // ON DELETE NO ACTION), and the API answers 409 PLAN_IN_USE instead of a
      // 500. Say why, in the operator's language, and offer the move-then-delete
      // dialog when it is members that are blocking it.
      if (errorData?.code === 'PLAN_IN_USE') {
        setErr(t(errorData.translationKey === 'plan_in_use_history' ? 'plan_in_use_history' : 'plan_in_use'));
        if (errorData.translationKey !== 'plan_in_use_history') {
          setDeleteDialog({ id, memberCount: errorData.memberCount || 0 });
        }
      } else if (e.message?.includes('members are still assigned')) {
        setDeleteDialog({ id, memberCount: errorData?.memberCount || 0 });
      } else {
        setErr(safeErrorMessage(e));
      }
    }
  }

  return (
    <Shell>
      <ProductPage
        eyebrow={t('memberships')}
        title={t('plans')}
        narrative={`${t('plans_description')} — ${t('plans_owner_control')}`}
        primaryAction={{ label: t('add_plan'), icon: 'plus', onClick: () => setForm({ type: 'TIME', days: 30, price: 0, active: true }) }}
      >
        <InsightLayer>
          <InsightCard label={t('total_plans')} value={items.length} icon="coins" detail={t('available_memberships')} />
          <InsightCard label={t('active')} value={items.filter(i => i.active).length} detail={t('active')} icon="shield" tone="good" />
        </InsightLayer>

        {err && <FeedbackLayer type="danger" title={t('error')} detail={err} />}

        {loading ? <Skeleton lines={5} /> : (
          <SmartTable
            columns={[t('name'), t('type'), t('sessions'), t('duration'), t('price'), t('invitations'), t('freezes'), t('status'), t('actions')]}
            rows={items}
            emptyTitle={t('no_plans')}
            emptyDescription={t('create_plans_desc')}
            renderRow={(p) => (
              <tr key={p.id} className={!p.active ? 'opacity-50' : ''}>
                <td className="font-bold">{localizePlanName(p.name, lang)}</td>
                <td>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${p.type === 'SESSION' ? 'bg-purple-500/20 text-purple-400' : 'bg-blue-500/20 text-blue-400'}`}>
                    {p.type === 'TIME' ? t('plan_type_time') : t('plan_type_session')}
                  </span>
                </td>
                <td>{p.type === 'SESSION' ? `${p.sessions} ${t('sessions')}` : '—'}</td>
                <td title={t('days_duration')}>{p.days} {t('days_short') || 'days'}</td>
                <td className="font-mono text-[var(--cyan)]" title={t('price')}>{p.price} {t('currency')}</td>
                <td title={t('invitations')}>{p.invitations} {t('invitations_short') || 'invitations'}</td>
                <td title={t('freezes')}>{p.maxFreezes} {t('freezes_short') || 'freezes'} ({p.freezeDays} {t('days_short') || 'days'})</td>
                <td>
                  <span className={`status-pill ${p.active ? 'status-active' : 'status-expired'}`}>
                    {p.active ? t('active') : t('inactive')}
                  </span>
                </td>
                <td>
                  <span className="row-actions inline-flex gap-2">
                    <button className="btn-ghost btn-sm" onClick={() => setForm(p)}>{t('edit')}</button>
                    {canDeletePlans ? (
                      <button className="text-red-500 hover:text-red-400 text-sm px-2" onClick={() => p.id && del(p.id)}>{t('delete')}</button>
                    ) : (
                      <span className="text-[11px] text-[var(--silver-dim)] px-2" data-testid="plans-delete-locked" title={t('plans_delete_required') || 'requires plans.delete'}>{t('plans_delete_required') || 'requires plans.delete'}</span>
                    )}
                  </span>
                </td>
              </tr>
            )}
          />
        )}
      </ProductPage>

      {form && (
        <ModalPortal>
        <div className="fixed inset-0 bg-black/70 grid place-items-center p-5 z-50" onClick={() => setForm(null)}>
          <form onClick={(e) => e.stopPropagation()} onSubmit={save} className="card card-static glass w-full max-w-lg border-[var(--border)] border">
            <h3 className="text-xl font-bold text-white mb-6">{form.id ? t('edit') : t('add_plan')}</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('name')}</label>
                <input className="input w-full" placeholder={t('name')} value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
              </div>
              <div>
                <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('type')}</label>
                <select className="input w-full" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as any })}>
                  <option value="TIME">{t('time_based')}</option>
                  <option value="SESSION">{t('session_based')}</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('status')}</label>
                <select className="input w-full" value={form.active ? 'true' : 'false'} onChange={(e) => setForm({ ...form, active: e.target.value === 'true' })}>
                  <option value="true">{t('active')}</option>
                  <option value="false">{t('inactive')}</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('price')} ({t('currency')})</label>
                <input className="input w-full" type="number" value={form.price} onChange={(e) => setForm({ ...form, price: Number(e.target.value) })} required />
              </div>
              <div>
                <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('days_duration')}</label>
                <input className="input w-full" type="number" value={form.days} onChange={(e) => setForm({ ...form, days: Number(e.target.value) })} required />
              </div>
              {form.type === 'SESSION' && (
                <div className="col-span-2">
                  <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('sessions')}</label>
                  <input className="input w-full" type="number" value={form.sessions || ''} onChange={(e) => setForm({ ...form, sessions: Number(e.target.value) })} required />
                </div>
              )}
              {/* Point 15: New Plan Configs */}
              <div>
                <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('invitations')}</label>
                <input className="input w-full" type="number" value={form.invitations ?? 0} onChange={(e) => setForm({ ...form, invitations: Number(e.target.value) })} />
              </div>
              <div>
                <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('maxFreezes') || 'Max Freezes'}</label>
                <input className="input w-full" type="number" value={form.maxFreezes ?? 0} onChange={(e) => setForm({ ...form, maxFreezes: Number(e.target.value) })} />
              </div>
              <div className="col-span-2">
                <label className="text-xs font-bold text-silver-dim uppercase mb-1 block">{t('freezeDays') || 'Freeze Days (Total)'}</label>
                <input className="input w-full" type="number" value={form.freezeDays ?? 0} onChange={(e) => setForm({ ...form, freezeDays: Number(e.target.value) })} />
              </div>
            </div>
            <div className="flex gap-3 justify-end mt-8 pt-4 border-t border-[var(--border)]">
              <button type="button" className="btn-ghost" onClick={() => setForm(null)}>{t("cancel")}</button>
              <button className="btn-primary px-6">{t("save")}</button>
            </div>
          </form>
        </div>
        </ModalPortal>
      )}

      {deleteDialog && (
        <ModalPortal>
        <div className="fixed inset-0 bg-black/80 grid place-items-center p-5 z-[60]" onClick={() => setDeleteDialog(null)}>
          <div className="card w-full max-w-md border-red-900/50 border shadow-2xl shadow-red-950/20" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-xl font-bold text-red-500 mb-2">{t('delete_plan_title')}</h3>
            <p className="text-sm text-[var(--muted)] mb-4">
              {t('plan_assigned_members')} <b>{deleteDialog.memberCount} {t('members')}</b>. 
              {t('move_members_to')}
            </p>
            
            <div className="mb-6">
              <label className="text-xs font-bold text-[var(--muted)] uppercase mb-1 block">{t('move_members_to_label') || 'Move members to:'}</label>
              <select 
                className="input w-full" 
                value={targetPlanId} 
                onChange={(e) => setTargetPlanId(e.target.value)}
              >
                <option value="">{t('select_target_plan')}</option>
                {items.filter(p => p.id !== deleteDialog.id && p.active).map(p => (
                  <option key={p.id} value={p.id}>{planOptionLabel(p, lang, t)}</option>
                ))}
              </select>
            </div>

            <div className="flex gap-3 justify-end">
              <button className="btn-ghost" onClick={() => setDeleteDialog(null)}>{t('cancel')}</button>
              <button 
                className="btn-danger px-4" 
                disabled={!targetPlanId}
                onClick={() => del(deleteDialog.id, targetPlanId)}
              >
                {t('confirm_move_delete')}
              </button>
            </div>
          </div>
        </div>
        </ModalPortal>
      )}
    </Shell>
  );
}
