/**
 * FLEXORA Gym OS — Backup Management
 * © 2024 Ammar Allam. All rights reserved.
 */
'use client';
import { useCallback, useEffect, useState } from 'react';
import { formatDate } from '@/lib/dates';
import Shell from '@/components/Shell';
import { api, API_BASE_URL } from '@/lib/api';
import { useTranslation } from '@/lib/i18n';
import { FeedbackLayer, InsightCard, InsightLayer, ProductPage, SmartTable, ActionCenter, SmartAction } from '@/components/ProductOS';
import { Card } from '@/components/ui/Card';
import { Skeleton, EmptyState } from '@/components/ui/States';
import { safeErrorMessage } from '@/lib/safe-error';
import { Icon } from '@/components/brand/Icon';

interface Backup {
  id: string;
  filename: string;
  sizeBytes: number;
  location: string;
  createdAt: string;
}

export default function Backups() {
  const { t } = useTranslation();
  const [items, setItems] = useState<Backup[]>([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');
  const [restoreFile, setRestoreFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<Record<string, number> | null>(null);
  const [restoring, setRestoring] = useState(false);
  const [aiChat, setAiChat] = useState<{ role: string; content: string }[]>([]);
  const [aiInput, setAiInput] = useState('');
  const [aiBusy, setAiInputBusy] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api<Backup[]>('/backups/list');
      setItems(data);
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const latest = items[0];
  const nextBackup = new Date();
  nextBackup.setHours(Math.ceil(nextBackup.getHours() / 6) * 6, 0, 0, 0);

  // FIX (backup download returned 500 server_error with no feedback): the old
  // implementation used window.open() — a blind navigation that can't surface
  // the real API error, and relies on raw cookies for auth. Download through
  // the authenticated API client and show the actual failure when the server
  // can't produce a file.
  async function downloadBackup(filename?: string) {
    setErr('');
    try {
      const url = filename ? `/backups/download/${filename}` : '/backups/download/latest';
      const res = await fetch(`${API_BASE_URL}${url}`, { credentials: 'include' });
      if (!res.ok) {
        const err = await res.json().catch(() => ({ message: `Download failed (HTTP ${res.status})` }));
        setErr(safeErrorMessage(new Error((err as any)?.message || `Download failed (HTTP ${res.status})`)));
        return;
      }
      const blob = await res.blob();
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = filename || 'flexora-backup.xlsx';
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(a.href);
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    }
  }

  async function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setRestoreFile(file);
    setErr('');
    
    const formData = new FormData();
    formData.append('file', file);
    
    try {
      const res = await api<{ preview: Record<string, number> }>('/backups/restore', { method: 'POST', body: formData, headers: {} }); // Multipart doesn't need content-type header manually
      setPreview(res.preview);
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
      setRestoreFile(null);
    }
  }

  async function confirmRestore() {
    if (!confirm(t('restore_warning'))) return;
    setRestoring(true);
    const formData = new FormData();
    formData.append('file', restoreFile!);
    formData.append('confirmed', 'true');
    try {
      await api('/backups/restore', { method: 'POST', body: formData, headers: {} });
      alert(t('restore_successful'));
      setPreview(null);
      setRestoreFile(null);
      load();
    } catch (e: unknown) {
      setErr(safeErrorMessage(e));
    } finally {
      setRestoring(false);
    }
  }

  async function askAi() {
    if (!aiInput.trim()) return;
    const msg = { role: 'user', content: aiInput };
    setAiChat([...aiChat, msg]);
    setAiInput('');
    setAiInputBusy(true);
    try {
      // Mock AI response for backup assistant
      // In Issue 6, we'll implement the real AI brain
      setTimeout(() => {
        setAiChat(prev => [...prev, { role: 'assistant', content: 'أهلاً بك! أنا مساعد النسخ الاحتياطي. يمكنني مساعدتك في فهم ملفات الإكسيل وكيفية استرجاع البيانات بأمان. هل لديك سؤال محدد؟' }]);
        setAiInputBusy(false);
      }, 1000);
    } catch (e) {
      setAiInputBusy(false);
    }
  }

  return (
    <Shell>
      <ProductPage
        eyebrow={t("backups") || "النسخ الاحتياطي"}
        title={t('backup_recovery')}
        narrative={t('backup_narrative')}
        primaryAction={{ label: t('download_latest'), icon: 'lightning', onClick: () => downloadBackup() }}
      >
        <InsightLayer>
          <InsightCard label={t('last_backup')} value={latest ? new Date(latest.createdAt).toLocaleTimeString() : t('never')} detail={latest ? formatDate(latest.createdAt) : t('no_backups')} icon="check" tone="good" />
          <InsightCard label={t('next_run')} value={nextBackup.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} detail={t('automatic_six_hours')} icon="calendar" />
          <InsightCard label={t('storage')} value={latest ? `${(latest.sizeBytes / 1024).toFixed(1)} KB` : '0 KB'} detail={t('current_backup_size')} icon="shield" />
        </InsightLayer>

        {err && <FeedbackLayer type="danger" title={t('system_alert')} detail={err} />}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
          <div className="lg:col-span-2 space-y-6">
            <Card padding="lg">
              <h3 className="text-xl font-bold mb-4">{t('backup_history')}</h3>
              <SmartTable
                columns={[t('date'), t('filename'), t('size'), t('action')]}
                rows={items.slice(0, 30)}
                emptyTitle={t('no_history')}
                emptyDescription={t('backups_will_appear')}
                renderRow={(b) => (
                  <tr key={b.id}>
                    <td>{formatDate(b.createdAt)}</td>
                    <td className="text-sm text-mono">{b.filename}</td>
                    <td>{(b.sizeBytes / 1024).toFixed(1)} KB</td>
                    <td>
                      <button className="btn-ghost btn-sm" onClick={() => downloadBackup(b.filename)}>{t('download')}</button>
                    </td>
                  </tr>
                )}
              />
            </Card>

            <Card padding="lg">
              <h3 className="text-xl font-bold mb-4">{t('restore_assistant')}</h3>
              <p className="text-sm text-[var(--silver-dim)] mb-4">{t('upload_backup_help')}</p>
              
              {!preview ? (
                <div className="border-2 border-dashed border-[var(--border)] rounded-xl p-8 text-center">
                  <input type="file" id="restore-upload" hidden accept=".xlsx" onChange={handleFileUpload} />
                  <label htmlFor="restore-upload" className="btn-secondary cursor-pointer">{t('select_backup')}</label>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {Object.entries(preview).map(([key, val]) => (
                      <div key={key} className="bg-[var(--bg-card)] p-3 rounded-lg border border-[var(--border)]">
                        <div className="text-xs text-[var(--muted)] uppercase">{key}</div>
                        <div className="text-lg font-bold">{val} records</div>
                      </div>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <button className="btn-primary" onClick={confirmRestore} disabled={restoring}>{restoring ? t('restoring') : t('confirm_restore')}</button>
                    <button className="btn-ghost" onClick={() => { setPreview(null); setRestoreFile(null); }}>{t('cancel')}</button>
                  </div>
                </div>
              )}
            </Card>
          </div>

          <Card padding="lg" className="h-fit">
            <div className="flex items-center gap-2 mb-4">
              <Icon name="sparkle" className="text-[var(--primary)]" />
              <h3 className="text-lg font-bold">{t('ai_backup_help')}</h3>
            </div>
            <div className="space-y-4 h-80 overflow-auto mb-4 text-sm">
              {aiChat.length === 0 && <p className="text-[var(--silver-dim)] italic">{t('backup_question_help')}</p>}
              {aiChat.map((m, i) => (
                <div key={i} className={`p-3 rounded-lg ${m.role === 'user' ? 'bg-[var(--border)] ml-4' : 'bg-[var(--primary)]/10 mr-4'}`}>
                  {m.content}
                </div>
              ))}
              {aiBusy && <div className="text-[var(--muted)] animate-pulse">{t('thinking')}</div>}
            </div>
            <div className="flex gap-2">
              <input className="input flex-1" placeholder={t('type_question')} value={aiInput} onChange={(e) => setAiInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && askAi()} />
              <button className="btn-primary p-2" onClick={askAi}><Icon name="send" /></button>
            </div>
          </Card>
        </div>
      </ProductPage>
    </Shell>
  );
}
