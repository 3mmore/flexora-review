'use client';
import { useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { BrandProvider } from '@/context/BrandContext';
import { PwaRegistration } from '@/components/PwaRegistration';
import { I18nProvider } from '@/lib/i18n';

export function Providers({ children }: { children: React.ReactNode }) {
  const [queryClient] = useState(() => new QueryClient({
    defaultOptions: {
      queries: {
        // CRITICAL: Prevent retry storms on 4xx/client errors. 
        // Automatic retries are only for transient network/5xx failures.
        retry: (failureCount, error: any) => {
          if (failureCount >= 3) return false;
          // Do not retry 4xx errors (client-side errors like 400, 401, 403, 404, 409, 429)
          const status = error?.status;
          if (status >= 400 && status < 500) {
            return false;
          }
          // Also check message as fallback
          const msg = error?.message || '';
          if (msg.includes('400') || msg.includes('401') || msg.includes('403') || msg.includes('404') || msg.includes('409') || msg.includes('429')) {
            return false;
          }
          return true;
        },
        retryDelay: (attempt) => Math.min(1000 * 2 ** attempt, 30000),
      },
    },
  }));
  return (
    <QueryClientProvider client={queryClient}>
      <BrandProvider>
        <I18nProvider>
          <PwaRegistration />
          {children}
        </I18nProvider>
      </BrandProvider>
    </QueryClientProvider>
  );
}
