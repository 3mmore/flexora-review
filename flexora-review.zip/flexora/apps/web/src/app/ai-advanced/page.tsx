'use client';
import { OperationalResourcePage } from '@/components/OperationalResourcePage';
import { useTranslation } from '@/lib/i18n';

export default function Page() {
  const { t } = useTranslation();
  return <OperationalResourcePage config={{ queryKey: 'ai-advanced', endpoint: '/ai-advanced/operational-insights', title: t('advanced_ai'), narrative: t('ai_adv_narrative'), columns: [{ key: 'answer' }, { key: 'confidence' }, { key: 'source' }] }} />;
}
