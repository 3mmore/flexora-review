'use client';
import { useEffect, useState } from 'react';
import { formatDate } from '@/lib/dates';
import Shell from '@/components/Shell';
import { api } from '@/lib/api';
import { useTranslation } from '@/lib/i18n';
import { InsightCard, InsightLayer, ProductPage, FeedbackLayer } from '@/components/ProductOS';
import { Skeleton } from '@/components/ui/States';
import { safeErrorMessage } from '@/lib/safe-error';
import { featureLabel } from '@/lib/i18n/features';
import { label } from '@/lib/i18n/codes';

export default function LicensePage() {
  const { t, lang } = useTranslation();
  const [license, setLicense] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState('');

  useEffect(() => {
    api('/license/status')
      .then(setLicense)
      .catch(e => setErr(safeErrorMessage(e)))
      .finally(() => setLoading(false));
  }, []);

  return (
    <Shell>
      <ProductPage
        eyebrow={t('platform') || "Platform"}
        title={t('license') || "License"}
        narrative={t('license_narrative')}
      >
        {err && <FeedbackLayer type="danger" title={t('error')} detail={t(err) || err} action={<button className="btn btn-ghost px-3 py-1.5 text-xs" onClick={() => window.location.reload()}>{t('retry')}</button>} />}
        
        {loading ? <Skeleton lines={5} /> : (
          <>
            <InsightLayer>
              <InsightCard 
                label={t('status')} 
                value={license?.ok ? t('active') : t('inactive')} 
                detail={license?.reason ? t('license_' + license.reason) : t('active')}
                tone={license?.ok ? 'good' : 'danger'}
                icon="shield"
              />
              <InsightCard 
                label={t('expiry')} 
                value={license?.expiresAt ? formatDate(license.expiresAt) : '—'} 
                detail={t('expiry')}
                icon="calendar"
              />
              <InsightCard 
                label={t('current_plan')} 
                value={label(String(license?.tier || 'BASIC'), 'plan', lang === 'en' ? 'en' : 'ar')}
                detail={t('current_tier')}
                icon="coins"
              />
            </InsightLayer>

            <div className="card mt-6">
              <h3 className="text-lg font-bold mb-4">{t('features')}</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {license?.features?.map((f: string) => (
                  <div key={f} className="bg-[var(--surface-light)] p-2 rounded text-xs border border-[var(--border)]">
                    {featureLabel(String(f), lang === 'en' ? 'en' : 'ar')}
                  </div>
                ))}
              </div>
            </div>
          </>
        )}
      </ProductPage>
    </Shell>
  );
}
