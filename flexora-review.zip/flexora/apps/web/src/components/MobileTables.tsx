'use client';

/**
 * Every table, readable on a phone (Pack 2, item 2).
 *
 * `SmartTable` renders a card list beside its table, but thirteen routes still
 * build their own `<table>` by hand — settings, plans, branches, users, classes,
 * invitations, support, products, marketplace, white-label, AI advanced and team
 * performance. On a 375px screen each of those is a wide grid squeezed into a
 * card or scrolled sideways, which is exactly what the owner asked to stop.
 *
 * Rather than rewrite thirteen pages (and risk changing their behaviour), this
 * adapter runs only below 640px: for each table it builds a card per row from the
 * thead labels and the row's own cells, inserts the cards before the table and
 * hides the table. Above 640px it does nothing at all, so desktop keeps its
 * tables and no markup is duplicated in the React tree.
 *
 * It re-runs when the route changes and briefly afterwards, because tables
 * usually appear when their data arrives.
 */

import { useEffect } from 'react';
import { usePathname } from 'next/navigation';

const MOBILE = '(max-width: 640px)';

function adapt(root: ParentNode = document) {
  if (typeof window === 'undefined' || !window.matchMedia(MOBILE).matches) return;
  const tables = root.querySelectorAll('table:not([data-mobile-cards])');
  tables.forEach((table) => {
    const el = table as HTMLTableElement;
    el.setAttribute('data-mobile-cards', '1');

    const headers = Array.from(el.querySelectorAll('thead th')).map((th) => (th.textContent || '').trim());
    const bodyRows = Array.from(el.querySelectorAll('tbody tr'));
    if (!bodyRows.length) return;

    const list = document.createElement('ul');
    list.className = 'smart-cards mobile-table-cards';

    bodyRows.forEach((tr) => {
      const cells = Array.from(tr.children) as HTMLElement[];
      const li = document.createElement('li');
      li.className = 'smart-card';
      cells.forEach((cell, i) => {
        const row = document.createElement('div');
        row.className = 'smart-card-row';
        const label = document.createElement('span');
        label.className = 'smart-card-label';
        label.textContent = headers[i] || '';
        const value = document.createElement('span');
        value.className = 'smart-card-value';
        // Move the cell's children, not its text: a cell holding a button keeps
        // a working button. The original table is hidden, never removed, so the
        // moved nodes are the only copy on screen.
        while (cell.firstChild) value.appendChild(cell.firstChild);
        row.append(label, value);
        li.appendChild(row);
      });
      list.appendChild(li);
    });

    el.parentElement?.insertBefore(list, el);
    el.classList.add('table-as-cards-hidden');
  });
}

export function MobileTables() {
  const path = usePathname();

  useEffect(() => {
    let cancelled = false;
    const run = () => {
      if (!cancelled) adapt();
    };
    run();
    // Data usually lands after the first paint; catch it without polling forever.
    const timers = [300, 800, 1500, 2500].map((ms) => setTimeout(run, ms));
    const observer = new MutationObserver(run);
    observer.observe(document.body, { childList: true, subtree: true });
    const stop = setTimeout(() => observer.disconnect(), 6000);
    return () => {
      cancelled = true;
      timers.forEach(clearTimeout);
      clearTimeout(stop);
      observer.disconnect();
    };
  }, [path]);

  return null;
}
