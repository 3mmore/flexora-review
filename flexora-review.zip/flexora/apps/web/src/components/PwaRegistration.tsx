'use client';
import { useEffect } from 'react';

export function PwaRegistration() {
  useEffect(() => {
    // STEP 2.3 — the same worker now serves the gym app and the portal. Scope
    // '/', because the staff tabs live at the root and the portal lives under
    // /portal; a worker registered with the default scope could not answer a
    // navigation to /dashboard.
    if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js', { scope: '/' })
        .then((reg) => {

        })
        .catch((err) => {
          console.error('SW registration failed:', err);
        });
    }
  }, []);

  return null;
}
