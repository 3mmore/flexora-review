'use client';
/**
 * PACK 2 · ITEM 5 — «وصلت» (I arrived), the member's one-tap check-in.
 *
 * WHAT THIS SCREEN HONESTLY IS: a declaration with evidence attached. A web page
 * cannot know that a person walked into a building. So the card:
 *   · appears only when the owner turned self check-in ON for this gym,
 *   · asks for the strongest evidence the gym configured (entrance QR → in the
 *     URL; gym network → nothing to ask, the server checks the address;
 *     location → asked with the browser's own permission prompt),
 *   · and says, in Arabic, what that evidence is worth.
 *
 * It reuses the same check-in core as the staff screen and the kiosk: the gates
 * (frozen, expired, not started, no sessions) are enforced once, server-side.
 */
import { useCallback, useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { portalApi, getMemberToken } from '@/lib/portal';
import { safeErrorMessage } from '@/lib/safe-error';
import { useTranslation } from '@/lib/i18n';

type Config = {
  enabled: boolean;
  qr: boolean;
  network: boolean;
  geolocation: boolean;
  plain: boolean;
  radiusMeters: number | null;
  /** false when the server has no QR signing key (STEP 2a) */
  qrAvailable?: boolean;
  honesty: string;
};

type Result = {
  ok: boolean;
  duplicate: boolean;
  at?: string;
  source: string;
  memberName?: string;
};

export function SelfCheckinCard({ compact = false }: { compact?: boolean }) {
  const router = useRouter();
  const params = useSearchParams();
  const { t, lang } = useTranslation();
  const [cfg, setCfg] = useState<Config | null>(null);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<Result | null>(null);
  const [err, setErr] = useState('');

  const token = params?.get('t') || undefined;

  useEffect(() => {
    if (!getMemberToken()) { router.replace('/portal/login'); return; }
    portalApi<Config>('/portal/self-checkin/config')
      .then(setCfg)
      .catch(() => setCfg(null));
  }, [router]);

  const arrive = useCallback(async () => {
    setBusy(true);
    setErr('');
    try {
      let lat: number | undefined;
      let lng: number | undefined;
      // only if the gym asked for a location, and only if the member allows it:
      // denying the prompt is not an error, it just means less evidence
      if (cfg?.geolocation && typeof navigator !== 'undefined' && navigator.geolocation) {
        lat = await new Promise<number | undefined>((resolve) => {
          navigator.geolocation.getCurrentPosition(
            (pos) => resolve(pos.coords.latitude),
            () => resolve(undefined),
            { timeout: 8000, maximumAge: 30000 },
          );
        });
        lng = await new Promise<number | undefined>((resolve) => {
          if (lat === undefined) return resolve(undefined);
          navigator.geolocation.getCurrentPosition(
            (pos) => resolve(pos.coords.longitude),
            () => resolve(undefined),
            { timeout: 8000, maximumAge: 30000 },
          );
        });
      }
      const res = await portalApi<Result>('/portal/self-checkin', {
        method: 'POST',
        body: JSON.stringify({ ...(token ? { token } : {}), ...(lat !== undefined && lng !== undefined ? { lat, lng } : {}) }),
      });
      setDone(res);
    } catch (e) {
      setErr(safeErrorMessage(e));
    } finally {
      setBusy(false);
    }
  }, [cfg, token]);

  if (!cfg?.enabled) return null;

  // STEP 2a — a member who scanned an entrance QR on a server with no signing
  // key would otherwise get a bare 503. Say it in Arabic, before they tap.
  const qrDead = cfg.qrAvailable === false && Boolean(token);

  const sourceLabel: Record<string, string> = {
    SELF_QR: t('source_self_qr'),
    SELF_IP: t('source_self_ip'),
    SELF_GEO: t('source_self_geo'),
    SELF_IP_GEO: t('source_self_ip_geo'),
    STAFF: t('source_staff'),
    KIOSK: t('source_kiosk'),
  };

  return (
    <div
      dir={lang === 'ar' ? 'rtl' : 'ltr'}
      data-testid="portal-self-checkin"
      style={{
        margin: compact ? 0 : '0 0 16px',
        padding: 16,
        borderRadius: 16,
        border: '1px solid var(--border, rgba(197,160,89,.25))',
        background: 'var(--bg-elevated, rgba(255,255,255,.03))',
      }}
    >
      <div style={{ fontWeight: 700, marginBottom: 4 }}>{t('self_checkin_member_title')}</div>
      <p style={{ fontSize: 12, opacity: 0.75, margin: '0 0 12px' }}>
        {qrDead
          ? t('self_checkin_qr_unavailable')
          : cfg.qr ? t('self_checkin_member_hint_qr') : cfg.network ? t('self_checkin_member_hint_network') : t('self_checkin_member_hint_plain')}
      </p>

      {!done && !qrDead && (
        <button
          onClick={arrive}
          disabled={busy}
          data-testid="portal-arrive"
          style={{
            width: '100%', minHeight: 56, borderRadius: 14, border: 0, cursor: busy ? 'default' : 'pointer',
            fontSize: 18, fontWeight: 800, color: '#111', background: 'var(--brand, #c5a059)',
          }}
        >
          {busy ? t('saving') : t('self_checkin_arrive')}
        </button>
      )}

      {done && (
        <div role="status" data-testid="portal-arrive-done" style={{ fontSize: 14 }}>
          <div style={{ fontWeight: 700, marginBottom: 4 }}>
            {done.duplicate ? t('self_checkin_already') : t('self_checkin_done')}
          </div>
          <div style={{ fontSize: 12, opacity: 0.8 }}>
            {sourceLabel[done.source] ?? t('source_unknown')}
          </div>
        </div>
      )}

      {err && (
        <div role="alert" data-testid="portal-arrive-error" style={{ marginTop: 10, fontSize: 13, color: '#ff6b6b' }}>
          {err}
        </div>
      )}
    </div>
  );
}

/** The page body for /portal/checkin — used when the entrance QR is scanned. */
export function SelfCheckinPage() {
  const { t } = useTranslation();
  return (
    <div style={{ padding: '12px 16px 24px' }}>
      <h1 style={{ fontSize: 18, margin: '8px 0 12px' }}>{t('self_checkin_member_title')}</h1>
      <SelfCheckinCard />
    </div>
  );
}
