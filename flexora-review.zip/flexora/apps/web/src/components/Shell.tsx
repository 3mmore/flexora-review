/**
 * FLEXORA Gym OS — Premium Shell (Phase 5 — UI/UX Excellence)
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Stripe / Linear / Notion style navigation:
 *   - Persistent left sidebar (collapsible)
 *   - Top bar with command palette trigger
 *   - User menu with profile / sign-out
 *   - Live status pill
 *   - Active route highlight with cyan glow
 */
"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { auth } from "@/lib/api";
import { useEffect, useMemo, useState } from "react";
import { Logo } from "./brand/Logo";
import { Icon } from "./brand/Icon";
import { MobileTabBar } from "./MobileTabBar";
import { OfflineBanner } from "./OfflineBanner";
import { AddToHomeScreen } from "./AddToHomeScreen";
import { clearMemberCaches } from "@/lib/pwa";
import { clearSnapshot } from "@/lib/offline-snapshot";
import { MobileTables } from "./MobileTables";
import { NAV_GROUPS, type NavGroup } from "@/lib/nav-structure";
import { CommandPalette } from "./CommandPalette";
import { LangSwitcher } from "./LangSwitcher";
import OwnerNotificationsBell from "./OwnerNotificationsBell";
import { useTranslation } from "@/lib/i18n";
// PHASE 4: identity/branch scope is cached per session — clear it on sign-out.
import { resetBranchScopeCache, useBranchScope } from "@/lib/branch-scope";
import { Permission, effectivePermissionsOf } from "@/lib/permissions";
import {
  composeProductRuntime,
  ProductModule,
} from "@/lib/PRODUCT_RUNTIME_ENGINE";
import { subscribeToEventStream } from "@/lib/REALTIME_EVENT_STREAM";
// PHASE A: one unread-notification poll for the whole shell (the bell in the
// top bar and the badge on the /notifications nav item read the same number).
import { refreshUnreadCount, subscribeUnread } from "@/lib/notifications";


/** Routes that are themselves a tab: they get a title, not a back arrow. */
const TOP_LEVEL = ['/dashboard', '/members', '/checkin', '/money', '/more', '/attendance'];
/** A tab root is named after the tab, not after the product module it belongs to. */
const MOBILE_TITLES: Record<string, string> = {
  '/dashboard': 'nav_home',
  '/members': 'members',
  '/checkin': 'checkin',
  '/money': 'nav_money',
  '/more': 'nav_more',
  '/attendance': 'attendance',
};

export default function Shell({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  const router = useRouter();
  const { t, lang, setLang } = useTranslation();
  const [user, setUser] = useState<any>(null);
  const [collapsed, setCollapsed] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [eventVersion, setEventVersion] = useState(0);
  // PHASE A: live unread badge. Polling lives here (one interval for the shell);
  // the value is shared with OwnerNotificationsBell through lib/notifications.
  const [unread, setUnread] = useState(0);

  const MODULE_META: Partial<Record<ProductModule, { label: string; why: string; action: string; href: string }>> = useMemo(() => ({
    dashboard: { label: t('executive_command'), why: t('read_business_risks'), action: t('review_action_center'), href: "/dashboard" },
    ai: { label: t('ai'), why: t('convert_signals_decisions'), action: t('ask_flexora_ai'), href: "/ai" },
    members: { label: t('membership_health'), why: t('protect_recurring_revenue'), action: t('add_member'), href: "/members?action=new" },
    attendance: { label: t('floor_activity'), why: t('understand_demand_habits'), action: t('open_checkin'), href: "/checkin" },
    classes: { label: t('class_operations'), why: t('balance_capacity_bookings'), action: t('create_session'), href: "/classes" },
    pos: { label: t('revenue_capture'), why: t('turn_demand_invoices'), action: t('start_checkout'), href: "/pos" },
    sales: { label: t('sales_intelligence'), why: t('track_invoices_anomalies'), action: t('open_pos'), href: "/pos" },
    inventory: { label: t('supply_readiness'), why: t('prevent_stockouts_protect'), action: t('review_low_stock'), href: "/inventory" },
    reports: { label: t('business_truth'), why: t('explain_trends_surprises'), action: t('ask_ai_explain'), href: "/ai" },
    billing: { label: t('subscription_control'), why: t('keep_platform_access'), action: t('review_plan'), href: "/billing" },
    settings: { label: t('workspace_control'), why: t('govern_os_config'), action: t('review_settings'), href: "/settings" },
    campaigns: { label: t('growth_engine'), why: t('move_members_leads'), action: t('create_campaign'), href: "/campaigns" },
    staff: { label: t('team_execution'), why: t('know_operating_floor'), action: t('check_staff'), href: "/staff-attendance" },
  }), [t]);

  // One structure, two surfaces: the desktop sidebar here and the phone's
  // "More" index both render lib/nav-structure.ts.
  const GROUPS: NavGroup[] = NAV_GROUPS;

  useEffect(() => {
    let mounted = true;
    auth.me().then((u) => { 
      if (mounted) setUser(u); 
    }).catch((err) => { 
      if (mounted && err.message === 'Session expired') router.replace("/login"); 
    });
    return () => { mounted = false; };
  }, [router]);

  useEffect(() => {
    return subscribeToEventStream(() => setEventVersion((v) => v + 1));
  }, []);

  // PHASE A — unread badge polling. Only roles that may call the endpoint are
  // polled; the effect re-subscribes to the shared store so any other screen
  // (the inbox, the bell) that refreshes the count updates the badge instantly.
  const canPollUnread = user?.role === 'OWNER' || user?.role === 'MANAGER';
  useEffect(() => {
    const unsubscribe = subscribeUnread(setUnread);
    if (!canPollUnread) return unsubscribe;
    refreshUnreadCount();
    const timer = setInterval(() => { refreshUnreadCount(); }, 30000);
    return () => { clearInterval(timer); unsubscribe(); };
  }, [canPollUnread]);

  const role = user?.role;
  // ROUND 13 (Phase 5): the sidebar is driven by the user's EFFECTIVE
  // permissions (from /auth/me) — the same list the API guard enforces.
  const held = effectivePermissionsOf(user?.role, (user as any)?.permissions);
  // ROUND 12 — a restricted role (Reception, Coach, Accountant…) with no branch
  // assigned cannot see anything: the API pins such an account to an impossible
  // branch and every list comes back empty. That used to look like a broken app
  // (empty tables, "missing" data). Say it plainly instead — and never treat it
  // as a session problem.
  const scope = useBranchScope();
  const noBranchAssigned = !scope.loading && scope.ok && !scope.unrestricted && !scope.branchId;
  const getGroupItems = (g: NavGroup) => g.items.filter((i) => {
    // Permission-gated item: every listed permission must be held.
    if (i.perms) return i.perms.every((p) => held.includes(p));
    // Role-gated item (platform SUPER_ADMIN surface).
    if (i.roles) return !!role && i.roles.includes(role);
    return true;
  });
  const isActive = (href: string) => path === href || path.startsWith(href + "/");

  const module = useMemo<ProductModule>(() => {
    const first = path.split("/").filter(Boolean)[0] || "dashboard";
    if (first === "checkin") return "attendance";
    if (first === "coach") return "staff";
    if (first === "products") return "inventory";
    if (first === "ai-advanced") return "ai";
    return (first as ProductModule) || "dashboard";
  }, [path]);

  const runtime = useMemo(() => composeProductRuntime({ module, role: role || "GUEST", technicalState: "idle" }), [module, role, eventVersion]);
  const meta = MODULE_META[module] || { label: t('operating_context'), why: t('flexora_aligns_context'), action: t('open_dashboard'), href: "/dashboard" };

  const initials = user?.name?.split(" ").map((s: string) => s[0]).slice(0, 2).join("").toUpperCase() || "F";

  /**
   * STEP 2.3 — signing out on a shared desk tablet must leave nothing readable
   * behind. Three stores, three purges: the service worker's Cache Storage
   * (clearMemberCaches also tells the worker to drop what it owns), the per-user
   * offline snapshot in sessionStorage, and the branch-scope cache that already
   * had a reset. All are awaited before navigation so a fast tap cannot race it.
   */
  const signOut = async () => {
    await auth.logout().catch(() => undefined);
    resetBranchScopeCache();
    clearSnapshot();
    await clearMemberCaches();
    router.replace("/login");
  };

  return (
    <div className="shell" dir={lang === 'ar' ? 'rtl' : 'ltr'}>
      <aside className={`shell-sidebar ${collapsed ? "collapsed" : ""}`} aria-label={t('aria_primary_nav')}>
        <div className="shell-sidebar-head">
          <Link href="/dashboard" aria-label={t('aria_home')}>
            {collapsed ? <Logo variant="mark" size={32} /> : <Logo variant="full" size={130} />}
          </Link>
          <button onClick={() => setCollapsed(!collapsed)} className="shell-collapse" aria-label={collapsed ? t('aria_expand_sidebar') : t('aria_collapse_sidebar')}>
            <Icon name={collapsed ? (lang === 'ar' ? 'arrow-left' : 'arrow-right') : "menu"} size={14} />
          </button>
        </div>

        <nav className="shell-sidebar-body">
          {GROUPS.map((g) => {
            const visible = getGroupItems(g);
            if (visible.length === 0) return null;
            return (
              <div key={g.label} className="shell-nav-group">
                {!collapsed && <div className="nav-section-title">{g.label}</div>}
                {visible.map((i) => (
                  <Link key={i.href} href={i.href} className={`nav-item ${isActive(i.href) ? "active" : ""}`} aria-current={isActive(i.href) ? "page" : undefined} title={collapsed ? t(i.key) || i.key : undefined}>
                    <Icon name={i.icon} size={16} />
                    {!collapsed && <span>{t(i.key) || i.key.replace(/_/g, " ")}</span>}
                    {i.badge === 'unread' && unread > 0 && (
                      <span
                        className="nav-unread-badge"
                        data-testid="nav-unread-badge"
                        aria-label={`${unread}`}
                      >
                        {unread > 99 ? '99+' : unread}
                      </span>
                    )}
                    {isActive(i.href) && !collapsed && <span className="ml-auto w-1.5 h-1.5 rounded-full bg-[var(--cyan)] shadow-[0_0_8px_var(--cyan-glow)]" />}
                  </Link>
                ))}
              </div>
            );
          })}
        </nav>

        <div className="shell-sidebar-foot">
          <div className="px-3 py-2 border-t border-[var(--border)] mb-2">
            <button onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')} className="flex items-center gap-2 text-xs font-semibold text-[var(--silver-dim)] hover:text-white transition-colors w-full">
              <Icon name="sparkle" size={14} />
              {lang === 'ar' ? `🌐 ${t('lang_english_name')}` : '🌐 العربية'}
            </button>
          </div>
          {user && !collapsed && (
            <div className="text-xs text-[var(--silver-dim)] px-3 py-2">
              <div className="flex items-center gap-2 mb-1">
                <span className="live-dot" />
                <span className="font-semibold text-[var(--silver)]">{user.name}</span>
              </div>
              <div className="text-[10px] uppercase tracking-wider text-[var(--silver-muted)]">
                {t(user.role.toLowerCase()) || user.role} · {user.gymId?.slice(0, 8) || "—"}
              </div>
            </div>
          )}
        </div>
      </aside>

      <div className="shell-main">
        {/* Phone chrome: a title and a way back. The desktop sidebar does that
            job with a visible hierarchy; on a phone there is one screen at a
            time, so the title says where you are and the arrow goes up a level. */}
        <div className="mobile-topbar">
          {TOP_LEVEL.includes(path) ? (
            /* A tab root: the title IS the location, so it is shown once. */
            <span className="mobile-topbar-title">{t(MOBILE_TITLES[path] || meta.label)}</span>
          ) : (
            <>
              <button
                type="button"
                className="mobile-back"
                onClick={() => router.back()}
                aria-label={t('back')}
              >
                <Icon name={lang === 'ar' ? 'arrow-right' : 'arrow-left'} size={18} />
                <span>{t('back')}</span>
              </button>
              <span className="mobile-topbar-title">{t(meta.label)}</span>
            </>
          )}
        </div>

        <header className="shell-topbar">
          <div className="flex items-center gap-3 flex-1">
            <CommandPalette />
          </div>
          <div className="flex items-center gap-2">
            <OwnerNotificationsBell />
            <LangSwitcher />
            <div className="shell-user-menu">
              <button className="shell-avatar" onClick={() => setMenuOpen(!menuOpen)} aria-label={t('aria_user_menu')} aria-expanded={menuOpen}>{initials}</button>
              {menuOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setMenuOpen(false)} />
                  <div className="shell-user-dropdown" role="menu">
                    <div className="px-4 py-3 border-b border-[var(--border)]">
                      <div className="font-semibold text-sm">{user?.name || t('guest')}</div>
                      <div className="text-xs text-[var(--silver-dim)]">{user?.email}</div>
                    </div>
                    <Link href="/settings" className="shell-user-dropdown-item" role="menuitem"><Icon name="cog" size={14} /> {t('settings')}</Link>
                    <Link href="/support" className="shell-user-dropdown-item" role="menuitem"><Icon name="bell" size={14} /> {t('support')}</Link>
                    <button onClick={signOut} className="shell-user-dropdown-item text-[var(--danger)]" role="menuitem"><Icon name="logout" size={14} /> {t('sign_out')}</button>
                  </div>
                </>
              )}
            </div>
          </div>
        </header>

        <section className="runtime-context-strip" aria-label={t('aria_product_runtime')}>
          <div className="runtime-context-main">
            <span className="runtime-context-eyebrow">{meta.label}</span>
            <strong>{t(runtime.feedback.title) || runtime.feedback.title}</strong>
            <span>{meta.why}</span>
          </div>
          <div className="runtime-context-actions">
            <span className={`runtime-state runtime-state-${runtime.state}`}>{t(runtime.state.replace(/-/g, "_")) || runtime.state.replace(/-/g, " ")}</span>
            <Link href={runtime.actions[0]?.href || meta.href} className="btn btn-ghost px-3 py-1.5 text-xs">{t(runtime.actions[0]?.label) || runtime.actions[0]?.label || meta.action}<Icon name="arrow-right" size={12} /></Link>
          </div>
        </section>

        <section className="unified-executive-system" aria-label={t('aria_exec_summary')}>
          <div className="uos-header">
            <div><span className="uos-eyebrow">{t('executive_system')}</span><h2>{meta.label}</h2><p>{meta.why}</p></div>
            <Link href={runtime.actions[0]?.href || meta.href} className="btn btn-primary px-4 py-2 text-sm">{t(runtime.actions[0]?.label) || runtime.actions[0]?.label || meta.action}<Icon name="arrow-right" size={13} /></Link>
          </div>

          <div className="uos-summary-grid" aria-label={t('aria_business_summary')}>
            <div className="uos-summary-card"><span>{t('health_label')}</span><strong>{runtime.state === "business-active" ? t('stable_status') : t(runtime.state.replace(/-/g, "_")) || runtime.state.replace(/-/g, " ")}</strong><small>{t('current_system_state')}</small></div>
            <div className="uos-summary-card" data-tone={runtime.context.riskLevel === "none" ? "neutral" : "warning"}><span>{t('risk_label')}</span><strong>{t(runtime.context.riskLevel) || runtime.context.riskLevel}</strong><small>{runtime.context.riskLevel === "none" ? t('no_urgent_risk') : t('recovery_prioritized')}</small></div>
            <div className="uos-summary-card" data-tone={runtime.context.opportunityLevel === "none" ? "neutral" : "success"}><span>{t('opportunity_label')}</span><strong>{t(runtime.context.opportunityLevel) || runtime.context.opportunityLevel}</strong><small>{runtime.context.opportunityLevel === "none" ? t('monitor_leading_indicators') : t('growth_actions_available')}</small></div>
            <div className="uos-summary-card"><span>{t('next_decision')}</span><strong>{t(runtime.actions[0]?.label) || runtime.actions[0]?.label || meta.action}</strong><small>{t(runtime.actions[0]?.reason) || runtime.actions[0]?.reason || t('start_recommended_action')}</small></div>
          </div>

          <div className="uos-decision-layer" aria-label={t('aria_decision_layer')}>
            <div className="uos-section-title"><span>{t('decision_layer')}</span><small>{t('top_system_ranked')}</small></div>
            <div className="uos-actions">
              {runtime.actions.slice(0, 4).map((action, index) => (
                <Link key={action.id} href={action.href || meta.href} className="uos-action-card" data-priority={index === 0 ? "high" : "normal"}>
                  <div><span>{index === 0 ? t('high_priority') : t('suggested')}</span><strong>{t(action.label) || action.label}</strong><small>{t(action.reason) || action.reason}</small></div>
                  <em>{t(action.intent.type.toLowerCase()) || action.intent.type}</em>
                </Link>
              ))}
            </div>
          </div>

          <div className="uos-ai-feedback" aria-label={t('aria_ai_layer')}>
            <div className="uos-ai-card">
              <Icon name="sparkle" size={16} />
              <div><strong>{t(runtime.insights[0]?.title) || runtime.insights[0]?.title || t('ai_operating_note')}</strong><span>{t(runtime.insights[0]?.detail) || runtime.insights[0]?.detail || t(runtime.feedback.detail) || runtime.feedback.detail}</span></div>
            </div>
            <div className={`uos-feedback-card uos-feedback-${runtime.feedback.type}`}>
              <Icon name={runtime.feedback.type === "danger" ? "bell" : runtime.feedback.type === "success" ? "shield" : "chart"} size={16} />
              <div><strong>{t(runtime.feedback.title) || runtime.feedback.title}</strong><span>{t(runtime.feedback.detail) || runtime.feedback.detail}</span></div>
            </div>
          </div>
        </section>

        {noBranchAssigned && (
          <div
            data-testid="no-branch-notice"
            role="status"
            className="mx-6 mt-4 rounded-2xl border border-amber-400/40 bg-amber-400/10 px-4 py-3 text-sm text-amber-200"
          >
            <strong className="block font-bold mb-1">{t('no_branch_assigned_title') || 'No branch assigned to your account'}</strong>
            <span className="text-amber-100/80">
              {t('no_branch_assigned_body') || 'Your role works inside a single branch, and your account is not linked to one yet, so there is nothing to show on this page. Ask the owner or the general manager to assign you to a branch from the Team page.'}
            </span>
          </div>
        )}
        <main className="shell-content operational-surface" role="main" aria-label={t('operational_surface')}>{children}</main>
        {/* STEP 2.3 — offline notice above the tab bar, never over content */}
        <OfflineBanner />
        {/* and the Arabic "add to home screen" card, dismissible, phones only */}
        <AddToHomeScreen />
        <MobileTabBar />
        <MobileTables />
      </div>
    </div>
  );
}
