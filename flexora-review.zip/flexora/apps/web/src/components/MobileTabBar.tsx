'use client';

/**
 * The phone's primary navigation.
 *
 * WHY THIS EXISTS (Pack 2, item 2)
 * ---------------------------------
 * Before this component the only navigation was the desktop sidebar. Below 900px
 * a media query shrank it to a 64px rail of 29 unlabelled icons — on a 375px phone
 * that is 17% of the screen spent on a column nobody can read, and the four things
 * an owner does at the door (see who is in, take a payment, renew, add a member)
 * were 2–4 taps deep behind it.
 *
 * Five tabs, the last of which opens a grouped index of everything else, so no
 * route, feature or permission is removed — every destination that was in the
 * sidebar is still reachable, in at most two taps.
 *
 * The tab set is permission-aware exactly like the sidebar: a reception user with
 * no `attendance.manual` gets the attendance history instead of the check-in
 * screen, and never sees a tab that would only answer 403.
 */

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Icon, type IconName } from './brand/Icon';
import { useTranslation } from '@/lib/i18n';
import { auth } from '@/lib/api';
import { effectivePermissionsOf } from '@/lib/permissions';

type Tab = {
  href: string;
  key: string;
  icon: IconName;
  /** Alternative destination when the user lacks the permission above. */
  fallbackHref?: string;
  perms?: string[];
};

const TABS: Tab[] = [
  { href: '/dashboard', key: 'nav_home', icon: 'home' },
  { href: '/members', key: 'members', icon: 'users', perms: ['members.view'] },
  { href: '/checkin', key: 'checkin', icon: 'qr-scan', perms: ['attendance.manual'], fallbackHref: '/attendance' },
  { href: '/money', key: 'nav_money', icon: 'coins' },
  { href: '/more', key: 'nav_more', icon: 'menu-grid' },
];

export function MobileTabBar() {
  const path = usePathname() || '';
  const { t } = useTranslation();
  const [held, setHeld] = useState<string[] | null>(null);

  // The same source of truth as the sidebar: the effective permission list the
  // API guard enforces, not the role name.
  useEffect(() => {
    let live = true;
    auth
      .me()
      .then((u) => {
        if (live) setHeld(effectivePermissionsOf(u?.role, u?.permissions));
      })
      .catch(() => {
        // Not signed in yet, or the call failed: show the tabs that need no
        // permission and let each page answer for itself.
        if (live) setHeld([]);
      });
    return () => {
      live = false;
    };
  }, []);

  const visible = TABS.map((tab) => {
    if (held === null) return tab; // first paint: do not flicker the bar
    if (!tab.perms) return tab;
    const allowed = tab.perms.every((p) => held.includes(p));
    if (allowed) return tab;
    return tab.fallbackHref ? { ...tab, href: tab.fallbackHref } : null;
  }).filter(Boolean) as Tab[];

  const isActive = (href: string) => path === href || path.startsWith(href + '/');

  return (
    <nav className="mobile-tabbar" aria-label={t('aria_primary_nav')}>
      {visible.map((tab) => {
        const active = isActive(tab.href) || (tab.href === '/more' && !TABS.some((x) => x.href !== '/more' && isActive(x.href)));
        return (
          <Link
            key={tab.href}
            href={tab.href}
            className={`mobile-tab ${active ? 'active' : ''}`}
            aria-current={active ? 'page' : undefined}
            data-testid={`tab-${tab.href.replace('/', '')}`}
          >
            <Icon name={tab.icon} size={20} />
            <span>{t(tab.key)}</span>
          </Link>
        );
      })}
    </nav>
  );
}
