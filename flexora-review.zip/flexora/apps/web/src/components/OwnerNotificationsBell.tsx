'use client';

import { useState, useEffect, useCallback } from 'react';
import { api } from '@/lib/api';
import { useTranslation } from '@/lib/i18n';
import { useBranchScope } from '@/lib/branch-scope';
import Link from 'next/link';
// PHASE A: the count is shared with the sidebar badge (lib/notifications owns
// the single polling loop and the value); this component only renders it.
import { refreshUnreadCount, setUnreadCount, subscribeUnread } from '@/lib/notifications';

interface Notification {
  id: string;
  type: string;
  title: string;
  body: string;
  icon: string;
  severity: 'info' | 'warning' | 'danger' | 'success';
  isRead: boolean;
  createdAt: string;
}

const SEVERITY_COLORS: Record<string, string> = {
  danger: '#FF4444',
  warning: '#FFB800',
  success: '#00C896',
  info: '#4ECDC4',
};

const SEVERITY_BG: Record<string, string> = {
  danger: 'rgba(255,68,68,0.1)',
  warning: 'rgba(255,184,0,0.1)',
  success: 'rgba(0,200,150,0.1)',
  info: 'rgba(78,205,196,0.1)',
};

export default function OwnerNotificationsBell() {
  const { t } = useTranslation();
  // `/owner/notifications*` is `@Roles('OWNER','MANAGER')` on the API. Every
  // other staff role used to render this bell and poll `unread-count` every
  // 30s, which only ever produced a 403 in the console (and a dead bell). The
  // role is now read before anything is drawn, so the request is never made.
  const scope = useBranchScope();
  const canSee = scope.ok && ['OWNER', 'MANAGER'].includes(scope.role);
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  // The shared store is the single source of truth for the number.
  const [unreadCount, setLocalUnread] = useState(0);

  const fetchAll = useCallback(async () => {
    try {
      const data = await api<Notification[]>('/owner/notifications?limit=30');
      setNotifications(data);
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    if (!canSee) return;
    // Shell already polls every 30 s; subscribing here keeps the bell in sync
    // with the sidebar badge without a second request per interval.
    return subscribeUnread(setLocalUnread);
  }, [canSee]);

  const syncUnread = (next: number) => {
    setUnreadCount(next);
    setLocalUnread(next);
  };

  const handleOpen = async () => {
    setOpen(!open);
    if (!open) await fetchAll();
  };

  const markRead = async (id: string) => {
    await api(`/owner/notifications/${id}/read`, { method: 'PATCH' });
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
    );
    syncUnread(Math.max(0, unreadCount - 1));
  };

  const markAllRead = async () => {
    await api('/owner/notifications/read-all', { method: 'PATCH' });
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    syncUnread(0);
  };

  // Roles that can never receive these notifications render no bell at all.
  if (!canSee) return null;

  return (
    <div style={{ position: 'relative' }}>
      {/* Bell Button */}
      <button
        onClick={handleOpen}
        style={{
          background: 'rgba(255,255,255,0.05)',
          border: '1px solid rgba(255,255,255,0.1)',
          borderRadius: '10px',
          padding: '0.5rem 0.75rem',
          // Pack 2, item 2: a thumb target, not a mouse target. Measured 40×47
          // at 375px before this; the measured minimum on the phone is 44×44.
          minWidth: 44,
          minHeight: 44,
          justifyContent: 'center',
          cursor: 'pointer',
          color: 'white',
          fontSize: '1.2rem',
          position: 'relative',
          display: 'flex',
          alignItems: 'center',
          gap: '0.4rem',
        }}
      >
        🔔
        {unreadCount > 0 && (
          <span
            style={{
              background: '#FF4444',
              color: 'white',
              borderRadius: '999px',
              fontSize: '0.7rem',
              fontWeight: 900,
              padding: '0 6px',
              minWidth: '18px',
              textAlign: 'center',
            }}
          >
            {unreadCount > 99 ? '99+' : unreadCount}
          </span>
        )}
      </button>

      {/* Dropdown */}
      {open && (
        <div
          style={{
            position: 'absolute',
            top: '110%',
            right: 0,
            width: '360px',
            maxHeight: '480px',
            overflowY: 'auto',
            background: '#1A1A2E',
            border: '1px solid rgba(255,255,255,0.1)',
            borderRadius: '16px',
            boxShadow: '0 20px 60px rgba(0,0,0,0.5)',
            zIndex: 1000,
          }}
        >
          {/* Header */}
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              padding: '1rem',
              borderBottom: '1px solid rgba(255,255,255,0.07)',
            }}
          >
            <span
              style={{
                fontWeight: 700,
                fontSize: '0.95rem',
              }}
            >
              {t('notifications') || 'إشعارات'}
            </span>
            <Link
              href="/notifications"
              onClick={() => setOpen(false)}
              data-testid="notifications-view-all"
              style={{
                background: 'none',
                border: 'none',
                color: 'var(--cyan)',
                cursor: 'pointer',
                fontSize: '0.8rem',
                minHeight: '40px',
                display: 'inline-flex',
                alignItems: 'center',
                textDecoration: 'underline',
              }}
            >
              {t('notifications_view_all')}
            </Link>
            {unreadCount > 0 && (
              <button
                onClick={markAllRead}
                style={{
                  background: 'none',
                  border: 'none',
                  color: 'var(--brand)',
                  cursor: 'pointer',
                  fontSize: '0.8rem',
                }}
              >
                {t('mark_all_read') || 'قراءة الكل'}
              </button>
            )}
          </div>

          {/* List */}
          {notifications.length === 0 ? (
            <div
              style={{
                padding: '2rem',
                textAlign: 'center',
                color: 'rgba(255,255,255,0.3)',
                fontSize: '0.9rem',
              }}
            >
              {t('no_notifications') || 'لا توجد إشعارات'}
            </div>
          ) : (
            notifications.map((n) => (
              <div
                key={n.id}
                onClick={() => markRead(n.id)}
                style={{
                  padding: '0.85rem 1rem',
                  borderBottom: '1px solid rgba(255,255,255,0.05)',
                  background: n.isRead
                    ? 'transparent'
                    : SEVERITY_BG[n.severity] ?? 'rgba(255,255,255,0.03)',
                  cursor: 'pointer',
                  transition: 'background 0.2s',
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    marginBottom: '0.25rem',
                  }}
                >
                  <span
                    style={{
                      fontWeight: n.isRead ? 400 : 700,
                      fontSize: '0.85rem',
                      color: SEVERITY_COLORS[n.severity] ?? 'white',
                    }}
                  >
                    {n.title}
                  </span>
                  {!n.isRead && (
                    <span
                      style={{
                        width: '8px',
                        height: '8px',
                        borderRadius: '50%',
                        background: SEVERITY_COLORS[n.severity] ?? 'var(--brand)',
                        flexShrink: 0,
                        marginTop: '4px',
                      }}
                    />
                  )}
                </div>
                <div
                  style={{
                    fontSize: '0.8rem',
                    color: 'rgba(255,255,255,0.55)',
                    whiteSpace: 'pre-line',
                    lineHeight: 1.5,
                  }}
                >
                  {n.body}
                </div>
                <div
                  style={{
                    fontSize: '0.72rem',
                    color: 'rgba(255,255,255,0.25)',
                    marginTop: '0.4rem',
                  }}
                >
                  {new Date(n.createdAt).toLocaleString()}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Backdrop */}
      {open && (
        <div
          onClick={() => setOpen(false)}
          style={{
            position: 'fixed',
            inset: 0,
            zIndex: 999,
          }}
        />
      )}
    </div>
  );
}
