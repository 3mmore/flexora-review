'use client';
/**
 * ROUND 14 (security review, PHASE E) — a REAL, scannable QR code (SVG) rendered
 * with the `qrcode` package. Replaces the previous decorative hash-pattern
 * "QR" on the member card (which encoded nothing) and is reused by the
 * Settings "Member app" card for the portal link.
 */
import { useEffect, useState } from 'react';
import QRCode from 'qrcode';

export function QrCode({ payload, size = 180, testId }: { payload: string; size?: number; testId?: string }) {
  const [svg, setSvg] = useState('');
  useEffect(() => {
    let alive = true;
    QRCode.toString(payload, { type: 'svg', margin: 1, width: size })
      .then((s) => { if (alive) setSvg(s); })
      .catch(() => { if (alive) setSvg(''); });
    return () => { alive = false; };
  }, [payload, size]);
  if (!svg) return <div style={{ width: size, height: size }} data-testid={testId} />;
  return (
    <div
      data-testid={testId}
      style={{ width: size, height: size, background: '#fff', borderRadius: 8, padding: 6 }}
      dangerouslySetInnerHTML={{ __html: svg }}
    />
  );
}
