'use client';
import { useTranslation } from '@/lib/i18n';
import { Button } from './ui/Button';

export function LangSwitcher() {
  const { lang, setLang, t } = useTranslation();
  return (
    <Button 
      variant="ghost" 
      size="sm" 
      onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')} 
      className="text-xs uppercase"
    >
      {lang === 'ar' ? t('lang_english_name') : 'العربية'}
    </Button>
  );
}
