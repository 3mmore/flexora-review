'use client';
import Link from 'next/link';
import { Children, isValidElement, ReactNode } from 'react';
import { Card } from './ui/Card';
import { EmptyState, Skeleton } from './ui/States';
import { Icon } from './brand/Icon';

type IconName = 'sparkle' | 'chart' | 'users' | 'coins' | 'shield' | 'bell' | 'home' | 'menu-grid' | 'lightning' | 'arrow-right' | 'plus' | 'search' | 'calendar' | 'send' | 'qr-scan' | 'check' | 'x';

export function ProductPage({
  eyebrow,
  title,
  narrative,
  primaryAction,
  secondaryAction,
  children,
}: {
  eyebrow: string;
  title: string;
  narrative: string;
  primaryAction?: { label: string; href?: string; onClick?: () => void; icon?: IconName; testId?: string };
  secondaryAction?: { label: string; href?: string; onClick?: () => void; icon?: IconName; testId?: string };
  children: ReactNode;
}) {
  const Action = ({ action, primary }: { action: NonNullable<typeof primaryAction>; primary?: boolean }) => {
    const cls = primary ? 'btn btn-primary px-4 py-2 text-sm' : 'btn btn-secondary px-4 py-2 text-sm';
    const content = <>{action.icon && <Icon name={action.icon} size={14} />} {action.label}</>;
    if (action.href) return <Link href={action.href} className={cls} data-testid={action.testId}>{content}</Link>;
    return <button className={cls} data-testid={action.testId} onClick={action.onClick}>{content}</button>;
  };
  return (
    <div className="product-page">
      <section className="product-hero">
        <div>
          <div className="product-eyebrow">{eyebrow}</div>
          <h1>{title}</h1>
          <p>{narrative}</p>
        </div>
        <div className="product-hero-actions">
          {secondaryAction && <Action action={secondaryAction} />}
          {primaryAction && <Action action={primaryAction} primary />}
        </div>
      </section>
      {children}
    </div>
  );
}

export function InsightLayer({ children }: { children: ReactNode }) {
  return <section className="product-insight-grid">{children}</section>;
}

export function InsightCard({ label, value, detail, icon, tone = 'neutral' }: { label: string; value: string | number; detail: string; icon: IconName; tone?: 'neutral' | 'good' | 'warning' | 'danger' }) {
  return (
    <Card hoverable padding="md" className={`product-insight product-insight-${tone}`}>
      <div className="product-insight-icon"><Icon name={icon} size={17} /></div>
      <div className="product-insight-label">{label}</div>
      <div className="product-insight-value">{value}</div>
      <div className="product-insight-detail">{detail}</div>
    </Card>
  );
}

export function ActionCenter({ title, children }: { title: string; children: ReactNode }) {
  return (
    <Card padding="lg" className="product-action-center">
      <div className="product-section-head"><div><h2>{title}</h2></div><Icon name="lightning" size={18} /></div>
      <div className="product-action-list">{children}</div>
    </Card>
  );
}

export function SmartAction({ title, detail, href, onClick, icon = 'arrow-right', tone = 'neutral' }: { title: string; detail: string; href?: string; onClick?: () => void; icon?: IconName; tone?: 'neutral' | 'good' | 'warning' | 'danger' }) {
  const body = <><div className={`product-action-icon product-action-${tone}`}><Icon name={icon} size={15} /></div><div className="product-action-copy"><b>{title}</b><span>{detail}</span></div><Icon name="arrow-right" size={12} /></>;
  if (href) return <Link href={href} className="product-action-row">{body}</Link>;
  return <button className="product-action-row" onClick={onClick}>{body}</button>;
}

export function FeedbackLayer({ type = 'info', title, detail, action }: { type?: 'info' | 'success' | 'warning' | 'danger'; title: string; detail: string; action?: ReactNode }) {
  return (
    <div className={`product-feedback product-feedback-${type}`} role={type === 'danger' ? 'alert' : 'status'}>
      <Icon name={type === 'success' ? 'shield' : type === 'warning' ? 'bell' : type === 'danger' ? 'bell' : 'sparkle'} size={16} />
      <div><b>{title}</b><span>{detail}</span></div>
      {action && <div className="product-feedback-action">{action}</div>}
    </div>
  );
}

export function SmartTable<T = unknown>({
  columns,
  rows,
  loading,
  emptyTitle,
  emptyDescription,
  renderRow,
}: {
  columns: string[];
  rows: T[];
  loading?: boolean;
  emptyTitle: string;
  emptyDescription: string;
  renderRow: (row: T, index?: number) => ReactNode;
}) {
  if (loading) return <Card padding="lg"><Skeleton lines={10} /></Card>;
  if (!rows.length) return <EmptyState icon="sparkle" title={emptyTitle} description={emptyDescription} />;

  // Pack 2, item 2: a wide table is unreadable at 375px — it either scrolls
  // sideways inside its wrapper or squashes six columns into six slivers. The
  // table stays for desktop; beside it, every row is rendered once more as a
  // card, label above value. Both come from the SAME rendered row, so a column
  // never goes missing from one view and not the other.
  const rendered = rows.map(renderRow);
  const cards = rendered.map((row, index) => {
    const cells =
      isValidElement(row) && (row.props as { children?: ReactNode }).children
        ? Children.toArray((row.props as { children?: ReactNode }).children)
        : [];
    return (
      <li className="smart-card" key={`card-${index}`}>
        {cells.map((cell, i) => (
          <div className="smart-card-row" key={`c-${i}`}>
            <span className="smart-card-label">{columns[i]}</span>
            <span className="smart-card-value">
              {isValidElement(cell) ? (cell.props as { children?: ReactNode }).children : cell}
            </span>
          </div>
        ))}
      </li>
    );
  });

  return (
    <>
      <div className="table-wrapper smart-table">
        <table>
          <thead><tr>{columns.map((c) => <th key={c}>{c}</th>)}</tr></thead>
          <tbody>{rendered}</tbody>
        </table>
      </div>
      <ul className="smart-cards" role="list">{cards}</ul>
    </>
  );
}

export function RiskIndicator({ level = 'medium', label, detail }: { level?: 'low' | 'medium' | 'high' | 'critical'; label: string; detail?: string }) {
  return (
    <span className="risk-indicator" data-level={level} title={detail || label}>
      <Icon name="bell" size={13} />
      {label}
    </span>
  );
}

export function OpportunitySignal({ label, detail }: { label: string; detail?: string }) {
  return (
    <span className="opportunity-signal" title={detail || label}>
      <Icon name="sparkle" size={13} />
      {label}
    </span>
  );
}

export function ExecutiveHeader({ eyebrow, title, summary, children }: { eyebrow: string; title: string; summary: string; children?: ReactNode }) {
  return (
    <section className="executive-header">
      <div className="executive-header__eyebrow">{eyebrow}</div>
      <h1 className="executive-header__title">{title}</h1>
      <p className="executive-header__summary">{summary}</p>
      {children}
    </section>
  );
}

export function ActionCard(props: Parameters<typeof SmartAction>[0]) {
  return <SmartAction {...props} />;
}

export function RuntimeContextBar({ title, state, detail, action }: { title: string; state: string; detail: string; action?: ReactNode }) {
  return (
    <div className="runtime-context-strip">
      <div className="runtime-context-main">
        <span className="runtime-context-eyebrow">{title}</span>
        <strong>{state}</strong>
        <span>{detail}</span>
      </div>
      {action && <div className="runtime-context-actions">{action}</div>}
    </div>
  );
}
