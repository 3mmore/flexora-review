'use client';
import { useMemo, useState } from 'react';
import Shell from '@/components/Shell';
import { ProductPage, InsightLayer, InsightCard, SmartTable, ActionCenter, SmartAction, FeedbackLayer } from '@/components/ProductOS';
import { Skeleton, EmptyState } from '@/components/ui/States';
import { Button } from '@/components/ui/Button';
import { api } from '@/lib/api';
import { safeErrorMessage } from '@/lib/safe-error';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useTranslation } from '@/lib/i18n';
import { fieldLabel, valueLabel } from '@/lib/i18n/fields';
import { formatDate } from '@/lib/dates';

export type ResourceColumn = { key: string; label?: string };
export type ResourceConfig = {
  queryKey: string;
  endpoint: string;
  title: string;
  narrative: string;
  eyebrow?: string;
  columns: ResourceColumn[];
  /**
   * Optional per-endpoint presentation hook: returns the row as it should be
   * DISPLAYED (e.g. with an Arabic name looked up from a stable slug). The API
   * payload is untouched — this only affects rendering.
   */
  decorateRow?: (row: Record<string, unknown>) => Record<string, unknown>;
  createEndpoint?: string;
  createPayload?: Record<string, unknown>;
  deleteEndpoint?: (row: Record<string, unknown>) => string | null;
  primaryLabel?: string;
};

function normalizeRows(data: unknown): Array<Record<string, unknown>> {
  if (Array.isArray(data)) return data as Array<Record<string, unknown>>;
  if (data && typeof data === 'object') {
    const obj = data as Record<string, unknown>;
    for (const key of ['items', 'data', 'rows', 'results']) if (Array.isArray(obj[key])) return obj[key] as Array<Record<string, unknown>>;
    return [obj];
  }
  return [];
}

export function OperationalResourcePage({ config }: { config: ResourceConfig }) {
  const { t, lang } = useTranslation();
  const qc = useQueryClient();
  const [filter, setFilter] = useState('');
  const [err, setErr] = useState('');
  const query = useQuery({ queryKey: [config.queryKey, filter], queryFn: () => api<unknown>(`${config.endpoint}${filter ? (config.endpoint.includes('?') ? '&' : '?') + `q=${encodeURIComponent(filter)}` : ''}`) });
  const rows = useMemo(() => normalizeRows(query.data), [query.data]);
  const visibleRows = useMemo(() => rows.filter((row) => !filter || JSON.stringify(row).toLowerCase().includes(filter.toLowerCase())), [rows, filter]);
  const createMutation = useMutation({
    mutationFn: () => api(config.createEndpoint || config.endpoint, { method: 'POST', body: JSON.stringify(config.createPayload || {}) }),
    onSuccess: () => { setErr(''); qc.invalidateQueries({ queryKey: [config.queryKey] }); },
    onError: (e) => setErr(safeErrorMessage(e)),
  });
  const deleteMutation = useMutation({
    mutationFn: (row: Record<string, unknown>) => {
      const endpoint = config.deleteEndpoint?.(row);
      if (!endpoint) throw new Error(t('operation_failed'));
      return api(endpoint, { method: 'DELETE' });
    },
    onSuccess: () => { setErr(''); qc.invalidateQueries({ queryKey: [config.queryKey] }); },
    onError: (e) => setErr(safeErrorMessage(e)),
  });

  return <Shell><ProductPage eyebrow={config.eyebrow || 'FLEXORA'} title={config.title} narrative={config.narrative} primaryAction={config.createEndpoint ? { label: config.primaryLabel || t('create'), icon: 'plus', onClick: () => createMutation.mutate() } : undefined}>
    {(query.isError || err) && <FeedbackLayer type="danger" title={t('operation_failed')} detail={err || safeErrorMessage(query.error)} action={<Button variant="ghost" onClick={() => query.refetch()}>{t('refresh')}</Button>} />}
    <InsightLayer>
      <InsightCard label={t('records_label')} value={visibleRows.length} detail={t('loaded_api')} icon="chart" />
      <InsightCard label={t('active')} value={visibleRows.filter((r) => r.active !== false && r.status !== 'DELETED').length} detail={t('available_rows')} icon="shield" tone="good" />
      <InsightCard label={t('updated_at')} value={formatDate(new Date())} detail={t('current_snapshot')} icon="calendar" />
    </InsightLayer>
    <ActionCenter title={t('actions')}>
      <SmartAction title={t('refresh')} detail={t('reload_api_data')} icon="arrow-right" onClick={() => query.refetch()} />
      <SmartAction title={t('search')} detail={t('toggle_useful_filter')} icon="search" onClick={() => setFilter(filter ? '' : 'active')} />
    </ActionCenter>
    <div className="mb-4"><input className="input w-full" placeholder={t('search_current_data')} value={filter} onChange={(e) => setFilter(e.target.value)} /></div>
    {query.isLoading ? <Skeleton lines={8} /> : visibleRows.length ? <SmartTable columns={[...config.columns.map((c) => c.label || fieldLabel(c.key, lang === 'en' ? 'en' : 'ar')), ...(config.deleteEndpoint ? [t('actions')] : [])]} rows={visibleRows} emptyTitle={t('no_data')} emptyDescription={t('no_records_available')} renderRow={(row: Record<string, unknown>) => <tr key={String(row.id || JSON.stringify(row).slice(0, 40))}>{config.columns.map((column) => <td key={column.key}>{valueLabel(column.key, String((config.decorateRow ? config.decorateRow(row) : row)[column.key] ?? ''), lang === 'en' ? 'en' : 'ar')}</td>)}{config.deleteEndpoint && <td><Button size="sm" variant="danger" loading={deleteMutation.isPending} onClick={() => deleteMutation.mutate(row)}>{t('delete')}</Button></td>}</tr>} /> : <EmptyState icon="search" title={t('no_results_found')} description={t('no_records_avail')} />}
  </ProductPage></Shell>;
}
