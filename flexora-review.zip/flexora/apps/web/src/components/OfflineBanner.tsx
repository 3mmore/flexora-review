'use client';
/**
 * PACK 2 · STEP 2.3 — "you are offline", in Arabic, with the last numbers the
 * phone actually saw.
 *
 * This is not a spinner with a nicer word: a web app cannot fetch while offline,
 * so the banner says exactly what happened and shows the four Home numbers
 * captured on the last successful load (see lib/offline-snapshot.ts, which proves
 * the snapshot is numbers-only, per account, and cleared on sign-out). When the
 * connection returns the banner disappears on the `online` event.
 */
import { useEffect, useState } from 'react';
import { useTranslation } from '@/lib/i18n';
import { auth } from '@/lib/api';
import { readSnapshot, saveSnapshot, type LastSeen } from '@/lib/offline-snapshot';

export function OfflineBanner({ snapshot }: { snapshot?: unknown }) {
  const { lang } = useTranslation();
  const [offline, setOffline] = useState(false);
  const [lastSeen, setLastSeen] = useState<LastSeen | null>(null);
  const [identity, setIdentity] = useState<{ gymId: string; userId: string } | null>(null);

  // who is signed in decides which snapshot is readable — never a global key
  useEffect(() => {
    let live = true;
    auth
      .me()
      .then((u: { id?: string; gymId?: string }) => {
        if (!live || !u?.id || !u?.gymId) return;
        setIdentity({ gymId: u.gymId, userId: u.id });
        setLastSeen(readSnapshot(u.gymId, u.id));
      })
      .catch(() => undefined);
    return () => {
      live = false;
    };
  }, []);

  // every successful Home load refreshes the numbers this banner can show.
  // The dashboard dispatches `flexora:home-summary` after its own load, so the
  // banner does not need a prop threaded through Shell.
  useEffect(() => {
    const onSummary = (event: Event) => {
      if (!identity) return;
      const detail = (event as CustomEvent).detail;
      const saved = saveSnapshot(identity.gymId, identity.userId, detail);
      if (saved) setLastSeen(saved);
    };
    window.addEventListener('flexora:home-summary', onSummary as EventListener);
    return () => window.removeEventListener('flexora:home-summary', onSummary as EventListener);
  }, [identity]);

  // a prop is still honoured for direct use (tests, or a page that has the data)
  useEffect(() => {
    if (!identity || snapshot === undefined) return;
    const saved = saveSnapshot(identity.gymId, identity.userId, snapshot);
    if (saved) setLastSeen(saved);
  }, [identity, snapshot]);

  useEffect(() => {
    const goOffline = () => setOffline(true);
    const goOnline = () => setOffline(false);
    setOffline(typeof navigator !== 'undefined' && navigator.onLine === false);
    window.addEventListener('offline', goOffline);
    window.addEventListener('online', goOnline);
    return () => {
      window.removeEventListener('offline', goOffline);
      window.removeEventListener('online', goOnline);
    };
  }, []);

  if (!offline) return null;

  const ar = lang !== 'en';
  const time = lastSeen?.at
    ? new Date(lastSeen.at).toLocaleTimeString(ar ? 'ar-EG' : 'en-GB', { hour: '2-digit', minute: '2-digit' })
    : null;

  return (
    <div className="offline-banner" role="status" aria-live="polite" dir={ar ? 'rtl' : 'ltr'}>
      <span className="offline-banner-dot" aria-hidden="true" />
      <div>
        <strong>{ar ? 'لا يوجد اتصال بالإنترنت' : 'You are offline'}</strong>
        {lastSeen ? (
          <span className="offline-banner-sub">
            {ar ? (
              <>
                آخر بيانات معروفة{time ? ` (${time})` : ''}: حضور اليوم {lastSeen.checkinsToday} · أعضاء نشطون{' '}
                {lastSeen.activeMembers} · ينتهي قريبًا {lastSeen.expiringMembers}
              </>
            ) : (
              <>
                Last known{time ? ` (${time})` : ''}: {lastSeen.checkinsToday} check-ins ·{' '}
                {lastSeen.activeMembers} active · {lastSeen.expiringMembers} expiring
              </>
            )}
          </span>
        ) : (
          <span className="offline-banner-sub">
            {ar ? 'ستظهر الأرقام بعد أول تحميل ناجح.' : 'Numbers appear after the first successful load.'}
          </span>
        )}
      </div>
    </div>
  );
}
