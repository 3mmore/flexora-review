"use client";

import React from "react";
import { BRAND_TAGLINE } from '@/lib/brand-text';
import { useBrand } from "@/context/BrandContext";

type LogoProps = {
  className?: string;
  size?: number;
  showText?: boolean;
  variant?: "mark" | "full" | "wordmark" | "monogram" | string;
  tone?: "dark" | "light" | string;
};

/**
 * Default brand gold — the fallback for a gym that has chosen nothing.
 *
 * The mark itself follows the GYM accent (brand.accentColor): with a single
 * brand token the sidebar "F" repaints with the rest of the shell instead of
 * staying gold while every other element changes color.
 */
const BRAND_GOLD = "#c5a059";

export const Logo = ({
  className = "",
  size = 40,
  showText = true,
  variant,
  tone,
}: LogoProps) => {
  const { brand } = useBrand();
  const shouldShowText =
    variant === "mark" || variant === "monogram"
      ? false
      : variant === "full" || variant === "wordmark"
        ? true
        : showText;

  // Only show a custom raster logo if the gym explicitly uploaded one
  // (brand.logoUrl is set via white-label). Otherwise always render the
  // default single-stroke gold "F" SVG.
  if (brand.useCustomBrand && brand.logoUrl) {
    return (
      <img
        src={brand.logoUrl}
        alt="Logo"
        className={`object-contain ${className}`}
        style={{ width: size, height: size }}
      />
    );
  }

  // Monochrome variant: white on dark backgrounds, black on light.
  const monoColor = tone === "light" ? "#000000" : "#ffffff";
  // tone forces monochrome (photo overlays); otherwise the mark uses the gym's
  // live accent, falling back to the default gold.
  const accent = brand.accentColor || brand.primaryColor || BRAND_GOLD;
  const iconColor = tone ? monoColor : (String(accent).startsWith("#") ? accent : BRAND_GOLD);

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="transition-colors duration-300 flex-shrink-0"
      >
        {/* Single continuous geometric stroke "F" in brand gold */}
        <path
          d="M35 15V85M35 15H75M35 48H65"
          stroke={iconColor}
          strokeWidth="8"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />
      </svg>
      {shouldShowText && (
        <div className="flex flex-col leading-none">
          <span
            className="font-display tracking-tighter text-xl"
            style={{
              fontWeight: 500,
              color: tone === "light" ? "#000000" : "#ffffff",
            }}
          >
            {brand.companyName || "FLEXORA"}
          </span>
          <span className="text-[var(--silver-dim)] text-[10px] uppercase tracking-widest font-medium">
            {brand.systemName || BRAND_TAGLINE}
          </span>
        </div>
      )}
    </div>
  );
};
