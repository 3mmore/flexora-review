/**
 * FLEXORA — Iconography system
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Stroke-based, 1.5px weight, rounded caps, 24×24 grid.
 * Custom-drawn for gym-specific operations.
 */
export type IconName =
  | 'dumbbell' | 'circuit' | 'qr-scan' | 'bio' | 'bell'
  | 'chart' | 'coins' | 'shield' | 'calendar' | 'users'
  | 'search' | 'plus' | 'check' | 'x' | 'menu'
  | 'home' | 'cog' | 'logout' | 'arrow-right' | 'arrow-left' | 'arrow-down'
  | 'lightning' | 'sparkle' | 'send' | 'image' | 'menu-grid';

interface IconProps {
  name: IconName;
  size?: number;
  className?: string;
  strokeWidth?: number;
}

const paths: Record<IconName, React.ReactNode> = {
  dumbbell: <><circle cx="3" cy="12" r="4" /><circle cx="21" cy="12" r="4" /><rect x="6" y="9" width="12" height="6" rx="1" /></>,
  circuit: <><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8" cy="8" r="1.5" /><circle cx="16" cy="8" r="1.5" /><circle cx="8" cy="16" r="1.5" /><circle cx="16" cy="16" r="1.5" /><line x1="8" y1="8" x2="16" y2="8" /><line x1="8" y1="16" x2="16" y2="16" /></>,
  'qr-scan': <><rect x="3" y="3" width="7" height="7" /><rect x="14" y="3" width="7" height="7" /><rect x="3" y="14" width="7" height="7" /><line x1="14" y1="14" x2="14" y2="21" /><line x1="21" y1="14" x2="21" y2="21" /><line x1="14" y1="21" x2="21" y2="21" /></>,
  bio: <><path d="M12 4 v16 M8 8 v8 M16 8 v8 M4 12 h4 M16 12 h4" /></>,
  bell: <><path d="M6 8 a6 6 0 0 1 12 0 c0 7 3 9 3 9 H3 s3-2 3-9" /><path d="M10 21 a2 2 0 0 0 4 0" /></>,
  chart: <><line x1="4" y1="20" x2="4" y2="4" /><line x1="4" y1="20" x2="20" y2="20" /><polyline points="7,16 11,11 14,13 18,7" /></>,
  coins: <><circle cx="8" cy="8" r="6" /><path d="M18 9 a6 6 0 1 0 0 6 M18 13 v8 a6 6 0 1 1 0-8" /></>,
  shield: <><path d="M12 3 l8 3 v5 c0 5-3 9-8 11 c-5-2-8-6-8-11 V6 z" /><path d="M9 12 l2 2 l4-4" /></>,
  calendar: <><rect x="3" y="5" width="18" height="16" rx="2" /><line x1="3" y1="10" x2="21" y2="10" /><line x1="8" y1="3" x2="8" y2="7" /><line x1="16" y1="3" x2="16" y2="7" /></>,
  users: <><circle cx="9" cy="8" r="3" /><path d="M3 21 v-2 a4 4 0 0 1 4-4 h4 a4 4 0 0 1 4 4 v2" /><circle cx="17" cy="6" r="2.5" /><path d="M15 14 h2 a3 3 0 0 1 3 3 v4" /></>,
  search: <><circle cx="11" cy="11" r="7" /><line x1="16" y1="16" x2="20" y2="20" /></>,
  plus: <><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></>,
  check: <><polyline points="5 12 10 17 19 7" /></>,
  x: <><line x1="6" y1="6" x2="18" y2="18" /><line x1="18" y1="6" x2="6" y2="18" /></>,
  menu: <><line x1="4" y1="7" x2="20" y2="7" /><line x1="4" y1="12" x2="20" y2="12" /><line x1="4" y1="17" x2="20" y2="17" /></>,
  home: <><path d="M4 11 l8-7 l8 7 v9 a1 1 0 0 1-1 1 h-4 v-6 h-6 v6 H5 a1 1 0 0 1-1-1 z" /></>,
  cog: <><circle cx="12" cy="12" r="3" /><path d="M19 12 a7 7 0 0 0-0.2-1.6 l2-1.6 -2-3.4 -2.4 1 a7 7 0 0 0-2.7-1.6 l-0.4-2.6 h-4 l-0.4 2.6 a7 7 0 0 0-2.7 1.6 l-2.4-1 -2 3.4 2 1.6 a7 7 0 0 0 0 3.2 l-2 1.6 2 3.4 2.4-1 a7 7 0 0 0 2.7 1.6 l0.4 2.6 h4 l0.4-2.6 a7 7 0 0 0 2.7-1.6 l2.4 1 2-3.4 -2-1.6 a7 7 0 0 0 0.2-1.6 z" /></>,
  logout: <><path d="M9 21 H5 a2 2 0 0 1-2-2 V5 a2 2 0 0 1 2-2 h4" /><polyline points="16 17 21 12 16 7" /><line x1="21" y1="12" x2="9" y2="12" /></>,
  'arrow-right': <><line x1="5" y1="12" x2="19" y2="12" /><polyline points="12 5 19 12 12 19" /></>,
  'arrow-left': <><line x1="19" y1="12" x2="5" y2="12" /><polyline points="12 19 5 12 12 5" /></>,
  'arrow-down': <><line x1="12" y1="5" x2="12" y2="19" /><polyline points="5 12 12 19 19 12" /></>,
  lightning: <><polygon points="13 3 4 14 11 14 10 21 19 10 12 10" /></>,
  sparkle: <><path d="M12 3 l1.5 4.5 l4.5 1.5 l-4.5 1.5 l-1.5 4.5 l-1.5-4.5 l-4.5-1.5 l4.5-1.5 z M19 14 l0.7 2.3 l2.3 0.7 l-2.3 0.7 l-0.7 2.3 l-0.7-2.3 l-2.3-0.7 l2.3-0.7 z" /></>,
  send: <><path d="M22 2 L11 13 M22 2 L15 22 l-4-9 l-9-4 z" /></>,
  image: <><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="8.5" r="1.5" /><path d="M21 15 l-5-5 l-9 9" /></>,
  'menu-grid': <><rect x="3" y="3" width="7" height="7" /><rect x="14" y="3" width="7" height="7" /><rect x="3" y="14" width="7" height="7" /><rect x="14" y="14" width="7" height="7" /></>,
};

export function Icon({ name, size = 18, className = '', strokeWidth = 1.6 }: IconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      {paths[name]}
    </svg>
  );
}
