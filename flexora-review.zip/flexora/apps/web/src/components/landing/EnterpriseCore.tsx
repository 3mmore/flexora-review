import React from 'react';
import { Button } from '../ui/Button';

/**
 * SECURITY / AUTOMATION / PERFORMANCE / PRICING — Arabic only (PACK 2, item 1).
 *
 * Pricing note: the previous English block advertised "$49 / $149 / Custom" —
 * prices this product does not charge (billing is EGP through Paymob). Inventing
 * a dollar price on a public page is a false claim to a customer, so the three
 * cards now describe the REAL tiers (الأساسية / برو / النخبة) and say the price is
 * quoted per gym, with no number invented.
 */
export const SecuritySection = () => {
  const features = [
    { title: 'عزل كامل بين الأنشطة', desc: 'كل بيانات مربوطة بناديها. لا تتسرّب بيانات نادٍ إلى نادٍ آخر أبدًا.' },
    { title: 'حماية الجلسات', desc: 'توقيع مشفّر للجلسات وتدوير للأسرار وحماية من إعادة الاستخدام.' },
    { title: 'صلاحيات دقيقة', desc: 'من المالك إلى المدرب: كل دور يرى ما يحتاجه فقط.' },
    { title: 'سجل تدقيق', desc: 'كل تغيير وكل دخول يُسجَّل بالفاعل والوقت والقيمة القديمة والجديدة.' },
    { title: 'موافقات للإجراءات الحساسة', desc: 'الإجراءات المؤثرة تحتاج موافقة بشرية قبل التنفيذ.' },
    { title: 'حماية من محاولات الدخول', desc: 'قفل تلقائي للحساب بعد محاولات فاشلة متكررة.' },
  ];

  return (
    <section className="py-24 bg-base text-white">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center gap-16">
          <div className="flex-1 space-y-6">
            <h2 className="text-4xl md:text-5xl font-display font-bold">أمان <br /> بمستوى المؤسسات.</h2>
            <p className="text-silver-dim text-lg leading-relaxed">
              بياناتك أغلى أصولك. فليكسورا تحميها ببنية «لا ثقة افتراضية» مصمّمة لأصعب بيئات التشغيل.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {features.map((f, i) => (
                <div key={i} className="flex items-start gap-3 p-3 rounded-lg border border-titanium bg-white/5">
                  <div className="text-primary">✓</div>
                  <div>
                    <div className="text-sm font-bold">{f.title}</div>
                    <div className="text-xs text-silver-dim">{f.desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="flex-1 relative">
            <div className="relative w-full aspect-square bg-obsidian border border-titanium rounded-3xl p-8 overflow-hidden">
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-primary/20 rounded-full blur-3xl" />
              <div className="relative z-10 flex flex-col items-center justify-center h-full text-center space-y-6">
                <div className="text-6xl">🛡️</div>
                <div className="text-2xl font-bold">لا ثقة افتراضية</div>
                <div className="text-sm text-silver-dim max-w-xs">
                  العزل على مستوى قاعدة البيانات والتطبيق معًا يضمن فصل البيانات بنسبة كاملة.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export const AutomationSection = () => {
  const steps = [
    { title: 'الاكتشاف', desc: 'عقل النظام يفحص المؤشرات كل خمس دقائق.' },
    { title: 'التحليل', desc: 'يمرّر الإشارة على حدود النادي المعتمدة.' },
    { title: 'التوصية', desc: 'يقترح أفضل مسار تشغيلي.' },
    { title: 'الموافقة', desc: 'موافقة بشرية للتغييرات المؤثرة.' },
    { title: 'التنفيذ', desc: 'النظام ينفّذ الإجراء بنفسه.' },
    { title: 'القياس', desc: 'يقيس النتيجة ويغلق الدائرة.' },
  ];

  return (
    <section className="py-24 bg-obsidian text-white">
      <div className="max-w-6xl mx-auto px-4 text-center">
        <h2 className="text-4xl md:text-5xl font-display font-bold mb-16">تنفيذ ذاتي</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {steps.map((s, i) => (
            <div key={i} className="relative p-6 rounded-2xl border border-titanium bg-white/5 backdrop-blur-md text-start group hover:border-primary transition-all">
              <div className="text-xs text-primary mb-4">الخطوة {i + 1}</div>
              <h3 className="text-lg font-bold mb-2">{s.title}</h3>
              <p className="text-xs text-silver-dim leading-relaxed">{s.desc}</p>
              {i < steps.length - 1 && (
                <div className="hidden lg:block absolute -left-4 top-1/2 -translate-y-1/2 text-titanium">←</div>
              )}
            </div>
          ))}
        </div>
        <div className="mt-16 p-8 rounded-3xl border border-titanium bg-primary/5 backdrop-blur-xl max-w-3xl mx-auto">
          <h3 className="text-xl font-bold mb-4">استقلالية موجَّهة</h3>
          <p className="text-silver-dim leading-relaxed">
            المهام الروتينية تُنفَّذ تلقائيًا، والقرارات الاستراتيجية تُعرَض على الإدارة للموافقة — تحكّم كامل بلا عمل يدوي.
          </p>
        </div>
      </div>
    </section>
  );
};

export const PerformanceSection = () => {
  const metrics = [
    { val: '99.9%', label: 'جاهزية النظام' },
    { val: '1,000,000+', label: 'عضو يدعمه النظام' },
    { val: '10,000+', label: 'نادٍ في البنية' },
    { val: '500,000+', label: 'حدث يومي' },
  ];

  return (
    <section className="py-24 bg-base text-white border-y border-titanium">
      <div className="max-w-6xl mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {metrics.map((m, i) => (
            <div key={i} className="text-center space-y-2">
              <div className="text-4xl md:text-6xl font-display font-bold text-white">{m.val}</div>
              <div className="text-sm text-silver-dim tracking-wider">{m.label}</div>
            </div>
          ))}
        </div>
        <div className="text-center mt-16">
          <div className="inline-flex items-center gap-4 px-4 py-2 rounded-full border border-titanium bg-white/5 text-[10px] text-silver-dim tracking-tight">
            <span>حجم مؤسسي</span>
            <span className="w-1 h-1 rounded-full bg-titanium" />
            <span>سحابي بالكامل</span>
            <span className="w-1 h-1 rounded-full bg-titanium" />
            <span>أداء محسَّن</span>
          </div>
          <p className="text-[10px] text-silver-muted mt-4">السعة تعتمد على حجم البنية وطريقة التشغيل.</p>
        </div>
      </div>
    </section>
  );
};

export const PricingSection = () => {
  const tiers = [
    {
      name: 'الأساسية',
      desc: 'لصالات البداية التي تتحوّل إلى الرقمي.',
      features: ['فرع واحد', 'حتى 500 عضو', 'أساسيات إدارة النادي', 'دعم عادي'],
      cta: 'ابدأ الآن',
    },
    {
      name: 'برو',
      desc: 'للصالات النامية التي توسّع تشغيلها.',
      features: ['حتى 5 فروع', 'حتى 5,000 عضو', 'مركز الذكاء الاصطناعي', 'دعم أولوية', 'تحليلات متقدمة'],
      cta: 'ابدأ الآن',
    },
    {
      name: 'النخبة',
      desc: 'لسلاسل الصالات الكبيرة متعددة الفروع.',
      features: ['فروع غير محدودة', 'أعضاء غير محدودين', 'كل طبقات الأتمتة', 'مدير نجاح مخصّص', 'هوية بصرية كاملة'],
      cta: 'تواصل معنا',
    },
  ];

  return (
    <section className="py-24 bg-obsidian text-white">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-display font-bold">أسعار واضحة</h2>
          <p className="text-silver-dim max-w-2xl mx-auto">
            سعر يُحدَّد حسب حجم ناديك وعدد الفروع — بدون رسوم خفية وبدون نسبة على كل عضو.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {tiers.map((t, i) => (
            <div key={i} className={`p-8 rounded-3xl border ${i === 1 ? 'border-primary bg-primary/10' : 'border-titanium bg-white/5'} flex flex-col h-full`}>
              <div className="mb-8">
                <h3 className="text-xl font-bold mb-2">{t.name}</h3>
                <div className="text-2xl font-bold mt-2">سعر مخصّص لناديك</div>
                <p className="text-sm text-silver-dim mt-4 leading-relaxed">{t.desc}</p>
              </div>
              <div className="flex-1 space-y-4 mb-8">
                {t.features.map((f, j) => (
                  <div key={j} className="flex items-center gap-3 text-sm">
                    <div className="text-primary">✓</div>
                    <span>{f}</span>
                  </div>
                ))}
              </div>
              <Button className={i === 1 ? 'bg-primary hover:bg-primaryDim text-white w-full py-4 rounded-xl' : 'bg-white/10 hover:bg-white/20 text-white w-full py-4 rounded-xl'}>
                {t.cta}
              </Button>
            </div>
          ))}
        </div>
        <p className="text-center text-xs text-silver-muted mt-8">الأسعار بالجنيه المصري وتُفعَّل من صفحة الاشتراك داخل حسابك.</p>
      </div>
    </section>
  );
};
