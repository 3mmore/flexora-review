import React from 'react';

/**
 * MODULES + AI — Arabic only (PACK 2, item 1). Product names that are proper
 * nouns are avoided entirely here; the AI step labels, the benefit lines and the
 * six capability cards are Arabic.
 */
export const ModulesSection = () => {
  const modules = [
    {
      title: 'لوحة القيادة',
      desc: 'مركز تحكم لكل ناديك: مؤشرات لحظية، مؤشر صحة النادي، وملخصات تنفيذية.',
      benefit: 'كل شيء أمامك في نظرة واحدة',
      icon: '📊',
    },
    {
      title: 'ملف العضو',
      desc: 'ملف كامل لكل عضو مع تتبع رحلته، تسجيل حضور ببصمة الجهاز، وتسجيل تلقائي.',
      benefit: 'تجربة شخصية لكل عضو',
      icon: '👥',
    },
    {
      title: 'إدارة الحصص',
      desc: 'جدولة ذكية للحصص، متابعة أداء المدربين، وإدارة الحجوزات تلقائيًا.',
      benefit: 'سعة أكبر وفجوات أقل',
      icon: '🏋️',
    },
    {
      title: 'الإدارة المالية',
      desc: 'فوترة تلقائية، مطابقة مالية، رواتب، ومصروفات بدقة عالية.',
      benefit: 'عمليات مالية بلا أخطاء',
      icon: '💼',
    },
    {
      title: 'مركز الذكاء',
      desc: 'عقل النادي: يتوقع الانقطاع، يتوقع الإيراد، ويقترح تحسينات التشغيل.',
      benefit: 'قرارات بالأرقام لا بالتخمين',
      icon: '🧠',
    },
    {
      title: 'إعدادات النادي',
      desc: 'إدارة فروع متعددة، صلاحيات دقيقة، وهوية بصرية خاصة بناديك.',
      benefit: 'تحكم مركزي وتنفيذ محلي',
      icon: '⚙️',
    },
  ];

  return (
    <section className="py-24 bg-obsidian text-white">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-display font-bold">ما يميّز فليكسورا</h2>
          <p className="text-silver-dim max-w-2xl mx-auto">أكثر من إدارة: نظام واحد يربط كل جزء في ناديك ببعضه.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {modules.map((m, i) => (
            <div key={i} className="p-8 rounded-2xl border border-titanium bg-white/5 backdrop-blur-md hover:bg-white/10 transition-all group">
              <div className="text-4xl mb-6">{m.icon}</div>
              <h3 className="text-2xl font-bold mb-3 group-hover:text-primary transition-colors">{m.title}</h3>
              <p className="text-silver-dim mb-6 leading-relaxed">{m.desc}</p>
              <div className="pt-6 border-t border-titanium">
                <span className="text-xs font-bold text-primary tracking-wider">{m.benefit}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export const AISystemSection = () => {
  const flow = [
    { step: 'إشارة', desc: 'يكتشف ما يخرج عن الوضع الطبيعي، مثل خطر انقطاع بنسبة 30% في باقة النخبة', color: 'bg-cyan-DEFAULT' },
    { step: 'قرار', desc: 'يحلّل البيانات ليعرف السبب الحقيقي وأفضل تدخّل', color: 'bg-primary' },
    { step: 'تنفيذ', desc: 'ينفّذ المهام تلقائيًا أو يطلب موافقة بشرية', color: 'bg-primary' },
    { step: 'نتيجة', desc: 'يقيس الأثر ويعود به إلى عقل النظام', color: 'bg-success' },
  ];

  return (
    <section className="py-24 bg-base text-white overflow-hidden">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-20 space-y-4">
          <h2 className="text-4xl md:text-5xl font-display font-bold">نظام تشغيل بالذكاء الاصطناعي</h2>
          <p className="text-silver-dim max-w-2xl mx-auto">فليكسورا ليست روبوت محادثة: إنها عقل إداري يلاحظ، ويقرر، وينفّذ.</p>
        </div>

        <div className="relative flex flex-col md:flex-row items-center justify-between gap-8">
          {flow.map((f, i) => (
            <React.Fragment key={i}>
              <div className="relative z-10 flex flex-col items-center text-center space-y-4 w-full md:w-1/4">
                <div className={`w-16 h-16 rounded-2xl ${f.color} flex items-center justify-center text-2xl font-bold shadow-lg shadow-violet-DEFAULT/20`}>
                  {i + 1}
                </div>
                <h3 className="text-xl font-bold">{f.step}</h3>
                <p className="text-sm text-silver-dim leading-relaxed">{f.desc}</p>
              </div>
              {i < flow.length - 1 && (
                <div className="hidden md:block flex-1 h-px bg-gradient-to-r from-violet-DEFAULT/50 to-violet-DEFAULT/50 relative">
                  <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-primary rounded-full animate-pulse" />
                </div>
              )}
            </React.Fragment>
          ))}
        </div>

        <div className="mt-24 grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { title: 'توقّع الانقطاع', desc: 'يحدّد الأعضاء المعرّضين للمغادرة قبل أن يغادروا.' },
            { title: 'توقّع الإيراد', desc: 'تقدير الإيراد القادم من اتجاهك الحالي والموسمية.' },
            { title: 'ذكاء الاحتفاظ', desc: 'حملات استرجاع تلقائية مبنية على سلوك العضو.' },
            { title: 'تسعير أذكى', desc: 'توصيات تسعير تحافظ على قيمة العضو على المدى الطويل.' },
            { title: 'ترشيح المدرب', desc: 'مطابقة العضو بالمدرب المناسب حسب أهدافه ونتائجه.' },
            { title: 'رؤى تشغيلية', desc: 'يكشف الساعات غير المستغلة والطاقة المهدرة.' },
          ].map((item, i) => (
            <div key={i} className="p-6 rounded-xl border border-titanium bg-obsidian flex items-start gap-4">
              <div className="w-2 h-2 rounded-full bg-primary mt-2" />
              <div>
                <h4 className="font-bold mb-1">{item.title}</h4>
                <p className="text-sm text-silver-dim">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
