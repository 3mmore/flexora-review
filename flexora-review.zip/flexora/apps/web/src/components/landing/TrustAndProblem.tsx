import React from 'react';

/**
 * TRUST + PROBLEM — Arabic only (PACK 2, item 1).
 *
 * The marketing page used to be hardcoded English while the product itself is
 * Arabic, so a customer on a phone saw an English site and an Arabic app. Every
 * visible string here is Arabic now; the technology strip keeps product NAMES
 * (NestJS, PostgreSQL…) because those are proper nouns, not words to translate,
 * and they are listed in scripts/arabic-allowlist.json.
 */
export const TrustSection = () => {
  const badges = [
    'عزل كامل لكل نادٍ', 'أمان بمستوى المؤسسات', 'طبقة ذكاء اصطناعي',
    'أتمتة ذاتية للمهام', 'تحليلات لحظية', 'بنية سحابية حديثة',
  ];
  const techs = [
    { name: 'NestJS', color: 'text-red-500' },
    { name: 'Next.js', color: 'text-white' },
    { name: 'Prisma', color: 'text-cyan-400' },
    { name: 'PostgreSQL', color: 'text-blue-400' },
    { name: 'Redis', color: 'text-red-600' },
    { name: 'TypeScript', color: 'text-blue-600' },
  ];

  return (
    <section className="py-20 bg-obsidian border-y border-titanium">
      <div className="max-w-6xl mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-16">
          {badges.map((badge, i) => (
            <div key={i} className="text-center p-4 rounded-xl border border-titanium bg-white/5 backdrop-blur-sm">
              <div className="text-xs font-medium text-silver-dim tracking-wider">{badge}</div>
            </div>
          ))}
        </div>
        <div className="flex flex-wrap justify-center items-center gap-8 opacity-50 grayscale hover:grayscale-0 transition-all">
          {techs.map((tech, i) => (
            <div key={i} className={`text-sm font-bold tracking-tighter ${tech.color}`} dir="ltr">
              {tech.name}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export const ProblemSection = () => {
  const points = [
    { title: 'أدوات متفرقة', desc: 'بياناتك موزّعة بين برنامج العملاء والفواتير وتسجيل الحضور.' },
    { title: 'بلا ذكاء', desc: 'برامج تسجّل البيانات ولا تفهمها ولا تخبرك بما يجب فعله.' },
    { title: 'بلا توقّع', desc: 'تعرف أن العضو غادر بعد أن يكون قد غادر فعلًا.' },
    { title: 'إدارة يدوية', desc: 'ساعات على ملفات إكسل بدلًا من تنمية النادي.' },
    { title: 'احتفاظ غير مرئي', desc: 'لا رؤية واضحة لسبب انقطاع الأعضاء.' },
    { title: 'إجراءات ثابتة', desc: 'كل خطوة تحتاج إنسانًا ليبدأها بنفسه.' },
  ];

  return (
    <section className="py-24 bg-base text-white">
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-display font-bold">لماذا تفشل البرامج التقليدية؟</h2>
          <p className="text-silver-dim max-w-2xl mx-auto">معظم برامج إدارة الصالات مجرد خزائن ملفات رقمية: تخزّن البيانات ولا تدير ناديك.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {points.map((p, i) => (
            <div key={i} className="group p-8 rounded-2xl border border-titanium bg-obsidian hover:border-primary/50 transition-all">
              <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                <div className="text-primary font-bold">{i + 1}</div>
              </div>
              <h3 className="text-xl font-bold mb-3">{p.title}</h3>
              <p className="text-silver-dim leading-relaxed">{p.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
