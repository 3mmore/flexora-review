import React from 'react';

/**
 * FAQ + FOOTER — Arabic only (PACK 2, item 1).
 *
 * The answers are the same claims as before, in Arabic, except where the English
 * version stated something the product does not do (e.g. "database sharding and
 * read-replicas", "GDPR/CCPA", "99.9%" SLA). A public page must not promise
 * architecture that does not exist, so those claims are now accurate:
 * one PostgreSQL database per installation with tenant isolation under RLS.
 */
export const FAQSection = () => {
  const faqs = [
    { q: 'كيف يعزل فليكسورا بيانات كل نادٍ؟', a: 'كل سجل مرتبط برقم النادي، وقاعدة البيانات نفسها تمنع أي قراءة أو كتابة خارج ناديك — وليس التطبيق وحده.' },
    { q: 'هل الذكاء الاصطناعي ينفّذ قرارات بنفسه؟', a: 'المهام الروتينية تُنفَّذ تلقائيًا. الإجراءات المؤثرة تُعرَض عليك للموافقة قبل التنفيذ.' },
    { q: 'هل أستطيع نقل بياناتي من نظام آخر؟', a: 'نعم، عبر استيراد ملفات إكسل أو CSV مع مطابقة الأعمدة، ويظهر لك ما لم يُطابَق قبل الحفظ.' },
    { q: 'أين تُحفظ البيانات؟', a: 'على قاعدة بيانات PostgreSQL داخل بيئتك أو بيئة الاستضافة التي تختارها، مع نسخ احتياطي دوري تستطيع تحميله.' },
    { q: 'ماذا يحدث لو تعطّل أحد مكوّنات النظام؟', a: 'النظام مصمّم ليتراجع بأمان: التقارير تعود لقاعدة البيانات مباشرة، والمهام الدورية تتوقف بدلًا من تكرار الإجراء.' },
    { q: 'هل يوجد تسجيل حضور بالبصمة؟', a: 'نعم، العضو يسجّل بصمة جهازه الشخصي مرة واحدة ويسجّل حضوره بلمسة — بدون كاميرات وبدون التعرف على الوجه.' },
    { q: 'كيف تُحمى المدفوعات؟', a: 'الدفع يمرّ عبر مزوّد مرخّص، وبيانات البطاقة لا تُخزَّن على خوادمنا.' },
    { q: 'هل أستطيع تخصيص الهوية البصرية؟', a: 'نعم، باقة النخبة تتيح شعارًا وألوانًا واسمًا خاصًا بناديك.' },
    { q: 'ما هو مؤشر صحة النادي؟', a: 'مؤشر مركّب من الإيراد والحضور والاحتفاظ، يعطيك رقمًا واحدًا لحالة النادي.' },
    { q: 'هل يعمل بدون إنترنت؟', a: 'صفحات العضو تعمل كتطبيق ويب محمول، وتسجيل الحضور الأساسي يعمل عند انقطاع الشبكة ثم يُزامَن.' },
    { q: 'كيف يُختار المدرب المناسب؟', a: 'النظام يقارن أهداف العضو وتخصصات المدربين ونتائجهم السابقة ويقترح الأنسب.' },
    { q: 'ما هي الإجراءات الذاتية؟', a: 'خطوات تشغيلية مثل إنشاء مهمة احتفاظ، يبدأها النظام اعتمادًا على مؤشرات النادي.' },
    { q: 'هل يدعم إدارة عدة فروع؟', a: 'نعم، بفروع متعددة من حساب واحد مع تقارير موحّدة وصلاحيات مختلفة لكل فرع.' },
    { q: 'هل هناك حد لعدد الأعضاء؟', a: 'لا حد مبرمج في النظام، والسعة تعتمد على حجم الخادم الذي تشغّله.' },
    { q: 'كيف يعمل توقّع الانقطاع؟', a: 'يحلّل تكرار الحضور وانتظام الدفع وتفاعل العضو ليحدّد المعرّضين للانقطاع.' },
    { q: 'هل أستطيع إنشاء أدوار مخصّصة؟', a: 'نعم، الصلاحيات دقيقة ويمكن منحها لكل موظف على حدة من صفحة الفريق.' },
    { q: 'هل يوجد واجهة برمجية للتكامل؟', a: 'نعم، واجهة REST موثّقة للتوسّع والتكامل مع أنظمتك.' },
    { q: 'كيف تُؤمَّن النسخ الاحتياطي؟', a: 'نسخ دورية يمكنك تحميلها من صفحة النسخ الاحتياطي، مع إمكانية استعادة كاملة.' },
    { q: 'هل يدعم حجز جلسات التدريب الشخصي؟', a: 'نعم، بتقويم للمدرب وواجهة حجز سهلة للعضو.' },
    { q: 'كم يستغرق التشغيل؟', a: 'حسب حجم النادي، عادة من 3 إلى 14 يومًا بما يشمل إدخال البيانات وتدريب الفريق.' },
  ];

  return (
    <section className="py-24 bg-obsidian text-white">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-display font-bold">أسئلة متكررة</h2>
          <p className="text-silver-dim">كل ما تحتاج معرفته عن نظام فليكسورا.</p>
        </div>
        <div className="space-y-4">
          {faqs.map((faq, i) => (
            <details key={i} className="group p-6 rounded-2xl border border-titanium bg-white/5 backdrop-blur-sm cursor-pointer">
              <summary className="flex items-center justify-between font-bold text-lg list-none">
                {faq.q}
                <span className="text-primary group-open:rotate-180 transition-transform">↓</span>
              </summary>
              <p className="mt-4 text-silver-dim leading-relaxed">{faq.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
};

export const FooterSection = () => {
  return (
    <footer className="py-20 bg-base border-t border-titanium text-white">
      <div className="max-w-6xl mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-2 md:col-span-1 space-y-6">
            <div className="text-2xl font-display font-bold tracking-tighter">فليكسورا<span className="text-primary">.</span></div>
            <p className="text-sm text-silver-dim leading-relaxed">
              نظام تشغيل متكامل لإدارة الصالات الرياضية، عربي بالكامل من أول شاشة لآخر تقرير.
            </p>
          </div>
          <div>
            <h4 className="font-bold mb-6 text-xs tracking-wider text-silver-dim">المنتج</h4>
            <ul className="space-y-4 text-sm text-silver-dim">
              <li className="hover:text-primary cursor-pointer">المزايا</li>
              <li className="hover:text-primary cursor-pointer">الأمان</li>
              <li className="hover:text-primary cursor-pointer">الأسعار</li>
              <li className="hover:text-primary cursor-pointer">دليل الاستخدام</li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-6 text-xs tracking-wider text-silver-dim">الشركة</h4>
            <ul className="space-y-4 text-sm text-silver-dim">
              <li className="hover:text-primary cursor-pointer">من نحن</li>
              <li className="hover:text-primary cursor-pointer">المدونة</li>
              <li className="hover:text-primary cursor-pointer">الوظائف</li>
              <li className="hover:text-primary cursor-pointer">تواصل معنا</li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-6 text-xs tracking-wider text-silver-dim">الدعم</h4>
            <ul className="space-y-4 text-sm text-silver-dim">
              <li className="hover:text-primary cursor-pointer">مركز المساعدة</li>
              <li className="hover:text-primary cursor-pointer">حالة النظام</li>
              <li className="hover:text-primary cursor-pointer">سياسة الخصوصية</li>
              <li className="hover:text-primary cursor-pointer">شروط الاستخدام</li>
            </ul>
          </div>
        </div>
        <div className="pt-8 border-t border-titanium flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-silver-muted">
          <div>© 2024 فليكسورا — جميع الحقوق محفوظة.</div>
          <div className="flex gap-6">
            <span className="hover:text-white cursor-pointer">واتساب</span>
            <span className="hover:text-white cursor-pointer">فيسبوك</span>
            <span className="hover:text-white cursor-pointer">لينكدإن</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
