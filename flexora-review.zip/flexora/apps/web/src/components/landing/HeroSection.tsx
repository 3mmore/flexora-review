import React from 'react';
import { Button } from '../ui/Button';
import { useTranslation } from '@/lib/i18n';

export const HeroSection = () => {
  const { t } = useTranslation();
  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center px-4 pt-20 overflow-hidden bg-base text-white">
      {/* Background Ambient Glows */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primaryGlow rounded-full blur-[120px] opacity-50" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-primaryGlow rounded-full blur-[120px] opacity-30" />
      
      <div className="relative z-10 max-w-6xl w-full text-center space-y-8">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-titanium bg-white/5 text-primary text-xs font-medium backdrop-blur-md animate-fade-in">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
          </span>
          {t('ai_powered_os')}
        </div>

        <h1 className="text-6xl md:text-8xl font-display font-bold tracking-tight leading-[1.1] bg-clip-text text-transparent bg-gradient-to-b from-white to-silver-dim">
          {t('run_gym_intelligence')}
        </h1>

        <p className="max-w-2xl mx-auto text-lg md:text-xl text-silver-dim font-body leading-relaxed">
          {t('flexora_combines_desc')}
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
          <Button className="bg-primary hover:bg-primaryDim text-white px-8 py-4 rounded-full text-lg font-medium transition-all hover:scale-105">
            {t('start_free_demo')}
          </Button>
            <Button variant="ghost" className="border-titanium text-white px-8 py-4 rounded-full text-lg font-medium backdrop-blur-md hover:bg-white/5 transition-all">
              {t('watch_system_tour')}
            </Button>
        </div>

        {/* Hero Visual: OS Mockup */}
        <div className="relative mt-20 group">
          <div className="absolute -inset-1 bg-gradient-to-r from-violet-DEFAULT/20 to-cyan-DEFAULT/20 rounded-2xl blur-lg opacity-50 group-hover:opacity-100 transition-opacity" />
          <div className="relative bg-obsidian border border-titanium rounded-2xl overflow-hidden shadow-2xl backdrop-blur-xl">
            {/* OS Window Header */}
            <div className="h-10 bg-white/5 border-b border-titanium flex items-center px-4 justify-between">
              <div className="flex gap-2">
                <div className="w-3 h-3 rounded-full bg-danger" />
                <div className="w-3 h-3 rounded-full bg-warning" />
                <div className="w-3 h-3 rounded-full bg-success" />
              </div>
              <div className="text-[10px] text-silver-muted font-mono uppercase tracking-widest">{t('enterprise_core')}</div>
              <div className="w-10" />
            </div>
            
            {/* OS Content - Mock Dashboard */}
            <div className="grid grid-cols-12 gap-4 p-6 bg-base text-start" dir="ltr">
              {/* Sidebar Mock */}
              <div className="col-span-2 space-y-3 hidden md:block">
                {[1,2,3,4,5].map(i => (
                  <div key={i} className="h-3 w-full bg-white/5 rounded-md" />
                ))}
              </div>
              {/* Main Content Mock */}
              <div className="col-span-12 md:col-span-10 grid grid-cols-3 gap-4">
                <div className="col-span-2 grid grid-cols-2 gap-4">
                   <div className="h-32 bg-white/5 border border-titanium rounded-xl p-4">
                      <div className="text-xs text-silver-dim mb-2">{t('total_revenue_label')}</div>
                      <div className="text-2xl font-bold">124,500.00 ج.م</div>
                      <div className="text-[10px] text-success">{t('up_vs_last_month_12')}</div>
                   </div>
                   <div className="h-32 bg-white/5 border border-titanium rounded-xl p-4">
                      <div className="text-xs text-silver-dim mb-2">{t('active_members_label')}</div>
                      <div className="text-2xl font-bold">1,240</div>
                      <div className="text-[10px] text-success">{t('up_vs_last_month_4')}</div>
                   </div>
                   <div className="col-span-2 h-64 bg-white/5 border border-titanium rounded-xl p-4 relative overflow-hidden">
                      <div className="text-xs text-silver-dim mb-4">{t('business_health_index')}</div>
                      <div className="absolute bottom-0 left-0 w-full h-32 flex items-end gap-1 px-2">
                        {[40, 60, 45, 90, 70, 80, 100, 85, 95, 70, 60, 80].map((h, i) => (
                          <div key={i} className="flex-1 bg-primary/40 rounded-t-sm" style={{ height: `${h}%` }} />
                        ))}
                      </div>
                   </div>
                </div>
                {/* AI Sidebar Mock */}
                <div className="col-span-1 space-y-4">
                  <div className="bg-primary/10 border border-primary/30 rounded-xl p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                      <div className="text-[10px] font-bold text-primary uppercase">{t('ai_insights_label')}</div>
                    </div>
                    <div className="space-y-3">
                      <div className="text-[11px] text-silver-dim p-2 bg-black/20 rounded border border-white/5">
                        {t('critical_churn_risk_msg')}
                      </div>
                      <div className="text-[11px] text-silver-dim p-2 bg-black/20 rounded border border-white/5">
                        {t('revenue_gap_msg')}
                      </div>
                    </div>
                  </div>
                  <div className="h-40 bg-white/5 border border-titanium rounded-xl p-4">
                    <div className="text-xs text-silver-dim mb-2">{t('system_status_label')}</div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-[10px]"><span className="text-silver-dim">{t('mock_api')}</span> <span className="text-success">{t('mock_online')}</span></div>
                      <div className="flex justify-between text-[10px]"><span className="text-silver-dim">{t('mock_db')}</span> <span className="text-success">{t('mock_online')}</span></div>
                      <div className="flex justify-between text-[10px]"><span className="text-silver-dim">{t('mock_ai')}</span> <span className="text-success">{t('mock_active')}</span></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
