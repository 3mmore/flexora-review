/**
 * FLEXORA Gym OS — Modal Portal
 *
 * FIX (P0: modals rendering below the fold / requiring scroll):
 * Any ancestor with a CSS `transform` (even `translateY(0)` from a completed
 * `.reveal` animation), `filter`, `backdrop-filter`, or `perspective` creates
 * a new containing block, which breaks `position: fixed` for child elements.
 * The modal then positions itself relative to that ancestor's box instead of
 * the browser viewport, appearing "at the bottom" of the page.
 *
 * By rendering the modal via a React portal to `document.body`, it escapes
 * any transformed ancestor and positions correctly relative to the viewport.
 *
 * FIX (round 8 review — portal was invisible on first render): the previous
 * implementation used `useRef` to hold the container element, but mutating a
 * ref does NOT trigger a React re-render. On first mount: the initial render
 * saw the ref as null and returned null (rendered nothing); the effect then
 * created the container and set the ref — but since no state changed, React
 * never re-rendered the component, so `createPortal()` was never actually
 * called with real content. The modal appeared invisible until some unrelated
 * state change elsewhere triggered a re-render. Fix: use `useState` (not
 * `useRef`) so calling the setter after creating the container properly
 * triggers a re-render and the portal mounts on the very next render cycle.
 */
'use client';
import { useEffect, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';

interface ModalPortalProps {
  children: ReactNode;
}

export function ModalPortal({ children }: ModalPortalProps) {
  // FIX: useState (not useRef) — calling setContainer triggers a re-render so
  // the portal actually mounts after the container div is created.
  const [container, setContainer] = useState<HTMLDivElement | null>(null);

  useEffect(() => {
    // Create a container div at document.body level
    const el = document.createElement('div');
    el.className = 'modal-portal-container';
    el.style.position = 'fixed';
    el.style.inset = '0';
    el.style.zIndex = '9999';
    el.style.pointerEvents = 'none';
    document.body.appendChild(el);

    // Inject the pointer-events override style once (idempotent via a marker)
    const STYLE_ID = 'modal-portal-style';
    if (!document.getElementById(STYLE_ID)) {
      const style = document.createElement('style');
      style.id = STYLE_ID;
      style.textContent = `.modal-portal-container > * { pointer-events: auto; }`;
      document.head.appendChild(style);
    }

    // Set state → triggers re-render → createPortal runs with real container
    setContainer(el);

    return () => {
      document.body.removeChild(el);
    };
  }, []);

  if (!container) {
    // First render before effect runs (or SSR) — render nothing.
    // The setState in the effect above will trigger a re-render immediately
    // after mount, so the portal appears on the very next paint.
    return null;
  }

  return createPortal(children, container);
}
