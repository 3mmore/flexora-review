'use client';
/**
 * PACK 2 · STEP 2.3 — «أضف إلى الشاشة الرئيسية», in Arabic, for the two phones
 * that actually exist in this market.
 *
 *  • Android/Chrome: the browser fires `beforeinstallprompt`; we keep the event
 *    and show a button that calls `prompt()`. Once installed (or dismissed) the
 *    card never appears again.
 *  • iPhone/Safari: there is NO install API. The only honest thing is
 *    instructions: Safari → Share → Add to Home Screen. A web page cannot do it
 *    for the user, and the card says so.
 *
 * Rules: never covers the primary action (it sits above the tab bar, dismissible,
 * one line of text plus a button), never shown on desktop, never shown inside an
 * already-installed app (display-mode: standalone).
 */
import { useEffect, useState } from 'react';
import { useTranslation } from '@/lib/i18n';

type InstallPromptEvent = Event & { prompt: () => Promise<void>; userChoice?: Promise<{ outcome: string }> };

const DISMISS_KEY = 'flexora:a2hs-dismissed';

function isStandalone(): boolean {
  if (typeof window === 'undefined') return false;
  const standaloneMedia = window.matchMedia?.('(display-mode: standalone)').matches;
  // iOS Safari reports it on the navigator, not in a media query
  const iosStandalone = (window.navigator as unknown as { standalone?: boolean }).standalone === true;
  return Boolean(standaloneMedia || iosStandalone);
}

function isIosSafari(): boolean {
  if (typeof navigator === 'undefined') return false;
  const ua = navigator.userAgent;
  const iOS = /iPad|iPhone|iPod/.test(ua) || (ua.includes('Macintosh') && 'ontouchend' in document);
  const safari = /Safari/.test(ua) && !/CriOS|FxiOS|EdgiOS|OPiOS/.test(ua);
  return iOS && safari;
}

export function AddToHomeScreen() {
  const { t, lang } = useTranslation();
  const ar = lang !== 'en';
  const [visible, setVisible] = useState(false);
  const [ios, setIos] = useState(false);
  const [installEvent, setInstallEvent] = useState<InstallPromptEvent | null>(null);

  useEffect(() => {
    if (isStandalone()) return;
    try {
      if (window.localStorage.getItem(DISMISS_KEY) === '1') return;
    } catch {
      /* private mode: show it once per session, harmless */
    }
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setInstallEvent(e as InstallPromptEvent);
      setVisible(true);
    };
    window.addEventListener('beforeinstallprompt', onPrompt);
    if (isIosSafari()) {
      setIos(true);
      setVisible(true);
    }
    const onInstalled = () => {
      setVisible(false);
      setInstallEvent(null);
    };
    window.addEventListener('appinstalled', onInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', onPrompt);
      window.removeEventListener('appinstalled', onInstalled);
    };
  }, []);

  if (!visible) return null;

  const dismiss = () => {
    setVisible(false);
    try {
      window.localStorage.setItem(DISMISS_KEY, '1');
    } catch {
      /* ignore */
    }
  };

  const install = async () => {
    if (!installEvent) return;
    try {
      await installEvent.prompt();
      await installEvent.userChoice;
    } catch {
      /* the user closed the sheet — nothing to do */
    } finally {
      setVisible(false);
    }
  };

  return (
    <div className="a2hs-card" role="dialog" aria-label={t('add_to_home')} dir={ar ? 'rtl' : 'ltr'}>
      <div className="a2hs-body">
        <strong>{ar ? 'ثبّت التطبيق على هاتفك' : 'Install the app'}</strong>
        {ios ? (
          <ol className="a2hs-steps">
            <li>{ar ? 'اضغط زر المشاركة (المربّع والسهم) في أسفل سفاري.' : 'Tap Share (square with an arrow) in Safari.'}</li>
            <li>{ar ? 'اختر «إضافة إلى الشاشة الرئيسية».' : 'Choose “Add to Home Screen”.'}</li>
            <li>{ar ? 'اضغط «إضافة» — سيظهر باسم فليكسورا.' : 'Tap “Add” — it appears as فليكسورا.'}</li>
          </ol>
        ) : (
          <p className="a2hs-sub">
            {ar
              ? 'افتحه كتطبيق كامل الشاشة — بدون شريط المتصفح.'
              : 'Run it full screen, without the browser bar.'}
          </p>
        )}
        {ios ? (
          <span className="a2hs-note">
            {ar ? 'آيفون لا يسمح للصفحة بتثبيت نفسها؛ هذه الخطوات من سفاري.' : 'iOS does not let a page install itself; these steps are in Safari.'}
          </span>
        ) : null}
      </div>
      <div className="a2hs-actions">
        {!ios ? (
          <button type="button" className="a2hs-primary" onClick={install} disabled={!installEvent}>
            {ar ? 'تثبيت' : 'Install'}
          </button>
        ) : null}
        <button type="button" className="a2hs-secondary" onClick={dismiss}>
          {ar ? 'لاحقًا' : 'Later'}
        </button>
      </div>
    </div>
  );
}
