/**
 * FLEXORA Gym OS — Premium Button component (Phase 4)
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Apple × Stripe × Linear button system:
 *   - Primary: solid cyan with glow
 *   - Secondary: ghost with hover glow
 *   - Danger: red with hover glow
 *   - Loading state with spinner
 */
'use client';
import { ButtonHTMLAttributes, forwardRef } from 'react';

type Variant = 'primary' | 'secondary' | 'danger' | 'ghost';
type Size = 'sm' | 'md' | 'lg';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  icon?: React.ReactNode;
}

const variantStyles: Record<Variant, string> = {
  primary:   'btn-primary',
  secondary: 'btn-secondary',
  danger:    'btn-danger',
  ghost:     'btn-ghost',
};

const sizeStyles: Record<Size, string> = {
  sm: 'px-3 py-1.5 text-xs',
  md: 'px-4 py-2 text-sm',
  lg: 'px-6 py-3 text-base',
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = 'primary', size = 'md', loading, icon, children, disabled, className = '', ...props }, ref) => {
    return (
      <button
        ref={ref}
        disabled={disabled || loading}
        className={`btn ${variantStyles[variant]} ${sizeStyles[size]} ${className}`}
        {...props}
      >
        {loading && <span className="btn-spinner" />}
        {!loading && icon && <span className="btn-icon">{icon}</span>}
        {children && <span>{children}</span>}
      </button>
    );
  }
);
Button.displayName = 'Button';
