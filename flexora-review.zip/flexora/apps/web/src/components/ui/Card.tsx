/**
 * FLEXORA Gym OS — Premium Card component (Phase 4)
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Apple × Stripe inspired card:
 *   - Layered surfaces (base / surface / elevated)
 *   - Subtle border glow on hover
 *   - Soft shadow with cyan tint
 */
'use client';
import { HTMLAttributes, forwardRef, ReactNode } from 'react';

interface CardProps extends Omit<HTMLAttributes<HTMLDivElement>, 'title'> {
  variant?: 'default' | 'elevated' | 'glow' | 'outline';
  padding?: 'none' | 'sm' | 'md' | 'lg';
  hoverable?: boolean;
  title?: ReactNode;
  subtitle?: ReactNode;
  action?: ReactNode;
}

const variantClass = {
  default: 'bg-[var(--bg-surface)] border border-[var(--border)]',
  elevated: 'bg-[var(--bg-elevated)] border border-[var(--border)] shadow-[var(--shadow-card)]',
  glow:     'bg-[var(--bg-elevated)] border border-[var(--cyan-border)] shadow-[var(--shadow-glow)]',
  outline:  'bg-transparent border border-[var(--cyan-border)]',
};

const padClass = {
  none: '',
  sm: 'p-3',
  md: 'p-5',
  lg: 'p-7',
};

export const Card = forwardRef<HTMLDivElement, CardProps>(
  ({ variant = 'default', padding = 'md', hoverable = false, title, subtitle, action, className = '', children, ...props }, ref) => {
    return (
      <div
        ref={ref}
        className={`card rounded-2xl ${variantClass[variant]} ${padClass[padding]} ${hoverable ? 'card-hover' : ''} ${className}`}
        {...props}
      >
        {(title || action) && (
          <div className="flex items-start justify-between mb-4">
            <div>
              {title && <h3 className="text-lg font-bold text-white tracking-tight">{title}</h3>}
              {subtitle && <p className="text-xs text-[var(--silver-dim)] mt-1">{subtitle}</p>}
            </div>
            {action && <div>{action}</div>}
          </div>
        )}
        {children}
      </div>
    );
  }
);
Card.displayName = 'Card';
