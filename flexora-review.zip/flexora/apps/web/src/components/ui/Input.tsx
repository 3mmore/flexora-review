/**
 * FLEXORA Gym OS — Premium Input component
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Unified form control derived from the FLEXORA design system.
 * Wraps raw .input styling with consistent labelling, hints, icon
 * adornments, focus rings and error states so every form across the
 * product feels like one component.
 *
 *   <Input label="Email" type="email" placeholder="you@gym.com" />
 *   <Input label="Mobile" icon="qr-scan" dir="ltr" error="Invalid" />
 *   <Input as="textarea" label="Notes" rows={4} />
 *   <Input as="select" label="Plan">{options}</Input>
 */
'use client';
import { InputHTMLAttributes, TextareaHTMLAttributes, SelectHTMLAttributes, ReactNode } from 'react';
import { Icon } from '../brand/Icon';

type IconName = Parameters<typeof Icon>[0]['name'];

type CommonProps = {
  label?: ReactNode;
  hint?: ReactNode;
  error?: ReactNode;
  icon?: IconName;
  trailing?: ReactNode;
  containerClassName?: string;
};

type AsInput = CommonProps & InputHTMLAttributes<HTMLInputElement> & { as?: 'input' };
type AsTextarea = CommonProps & TextareaHTMLAttributes<HTMLTextAreaElement> & { as: 'textarea' };
type AsSelect = CommonProps & SelectHTMLAttributes<HTMLSelectElement> & { as: 'select' };

type InputProps = AsInput | AsTextarea | AsSelect;

const FieldShell = ({
  label, hint, error, icon, trailing, children, containerClassName,
}: CommonProps & { children: ReactNode }) => (
  <label className={`fx-field ${containerClassName ?? ''}`}>
    {label && <span className="fx-field-label">{label}</span>}
    <span className={`fx-field-control ${error ? 'fx-field-error' : ''}`}>
      {icon && (
        <span className="fx-field-leading">
          <Icon name={icon} size={15} />
        </span>
      )}
      {children}
      {trailing && <span className="fx-field-trailing">{trailing}</span>}
    </span>
    {error
      ? <span className="fx-field-message fx-field-message-error">{error}</span>
      : hint ? <span className="fx-field-message">{hint}</span> : null}
  </label>
);

export function Input(props: InputProps) {
  const { label, hint, error, icon, trailing, containerClassName, as = 'input', ...rest } = props;
  const controlClass = `input fx-field-input ${icon ? 'fx-field-input-with-leading' : ''}`;

  if (as === 'textarea') {
    return (
      <FieldShell label={label} hint={hint} error={error} icon={undefined} trailing={trailing} containerClassName={containerClassName}>
        <textarea className={controlClass} {...(rest as TextareaHTMLAttributes<HTMLTextAreaElement>)} />
      </FieldShell>
    );
  }
  if (as === 'select') {
    return (
      <FieldShell label={label} hint={hint} error={error} icon={icon} trailing={trailing} containerClassName={containerClassName}>
        <select className={controlClass} {...(rest as SelectHTMLAttributes<HTMLSelectElement>)} />
      </FieldShell>
    );
  }
  return (
    <FieldShell label={label} hint={hint} error={error} icon={icon} trailing={trailing} containerClassName={containerClassName}>
      <input className={controlClass} {...(rest as InputHTMLAttributes<HTMLInputElement>)} />
    </FieldShell>
  );
}
