/**
 * FLEXORA — UX States (Phase 5 — Premium UX)
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Linear / Stripe / Vercel style:
 *   - Skeleton (shimmer loading)
 *   - Empty (illustration + CTA)
 *   - Error (with retry)
 *   - Success (toast)
 */
'use client';
import { Icon } from '../brand/Icon';
import { useTranslation } from '@/lib/i18n';

export function Skeleton({ className = '', lines = 1, width }: { className?: string; lines?: number; width?: number | string }) {
  // A screen reader announces this label, so it is part of the Arabic UI too.
  const { t } = useTranslation();
  if (lines === 1) {
    return <div className="skeleton" style={{ width: width ?? '100%', height: 14 }} aria-label={t('loading')} />;
  }
  return (
    <div className={`space-y-2 ${className}`} aria-label={t('loading')}>
      {Array.from({ length: lines }).map((_, i) => (
        <div key={i} className="skeleton" style={{ width: i === lines - 1 ? '60%' : '100%', height: 14 }} />
      ))}
    </div>
  );
}

export function EmptyState({
  icon = 'search',
  title,
  description,
  action,
}: {
  icon?: 'search' | 'users' | 'chart' | 'coins' | 'bell' | 'shield' | 'home' | 'cog' | 'sparkle' | 'menu-grid' | 'calendar';
  title: string;
  description?: string;
  action?: { label: string; onClick: () => void };
}) {
  return (
    <div className="empty-state">
      <div className="empty-state-icon">
        <Icon name={icon} size={48} strokeWidth={1.2} />
      </div>
      <h3 className="empty-state-title">{title}</h3>
      {description && <p className="empty-state-text">{description}</p>}
      {action && (
        <button onClick={action.onClick} className="btn btn-primary mt-4 px-5 py-2 text-sm">
          {action.label}
        </button>
      )}
    </div>
  );
}

export function ErrorState({
  title,
  description,
  onRetry,
}: {
  title?: string;
  description?: string;
  onRetry?: () => void;
}) {
  return (
    <div className="empty-state">
      <div className="empty-state-icon" style={{ color: 'var(--danger)' }}>
        <Icon name="shield" size={48} strokeWidth={1.2} />
      </div>
      <h3 className="empty-state-title" style={{ color: 'var(--danger)' }}>{title || 'Error'}</h3>
      <p className="empty-state-text">{description}</p>
      {onRetry && (
        <button onClick={onRetry} className="btn btn-secondary mt-4 px-5 py-2 text-sm">
          Try again
        </button>
      )}
    </div>
  );
}

/** Toast / notification hook. */
import { createContext, useContext, useEffect, useState } from 'react';

type ToastKind = 'success' | 'error' | 'info' | 'warning';
type Toast = { id: number; kind: ToastKind; message: string };
const ToastCtx = createContext<{ push: (kind: ToastKind, message: string) => void } | null>(null);

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const push = (kind: ToastKind, message: string) => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, kind, message }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4000);
  };
  return (
    <ToastCtx.Provider value={{ push }}>
      {children}
      <div className="toast-stack" role="status" aria-live="polite">
        {toasts.map((t) => (
          <div key={t.id} className={`toast toast-${t.kind}`}>
            <Icon
              name={t.kind === 'success' ? 'check' : t.kind === 'error' ? 'x' : t.kind === 'warning' ? 'bell' : 'sparkle'}
              size={16}
            />
            <span className="flex-1 text-sm">{t.message}</span>
            <button onClick={() => setToasts((s) => s.filter((x) => x.id !== t.id))} className="text-[var(--silver-dim)] hover:text-white">
              <Icon name="x" size={14} />
            </button>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastCtx);
  if (!ctx) throw new Error('useToast must be used within <ToastProvider>');
  return ctx;
}
