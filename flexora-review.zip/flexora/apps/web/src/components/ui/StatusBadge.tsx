/**
 * FLEXORA Gym OS — Status Badge (Phase 4)
 * © 2024 Ammar Allam. All rights reserved.
 */
'use client';
type Tone = 'success' | 'warning' | 'danger' | 'info' | 'neutral';
interface Props {
  tone?: Tone;
  children: React.ReactNode;
  dot?: boolean;
  size?: 'sm' | 'md';
}
const toneClass = {
  success: 'bg-[var(--success)]/15 text-[var(--success)] border-[var(--success)]/30',
  warning: 'bg-[var(--warning)]/15 text-[var(--warning)] border-[var(--warning)]/30',
  danger:  'bg-[var(--danger)]/15 text-[var(--danger)] border-[var(--danger)]/30',
  info:    'bg-[var(--cyan)]/15 text-[var(--cyan)] border-[var(--cyan)]/30',
  neutral: 'bg-white/5 text-[var(--silver-dim)] border-white/10',
};
export function StatusBadge({ tone = 'neutral', children, dot, size = 'sm' }: Props) {
  const sizeClass = size === 'md' ? 'px-3 py-1 text-sm' : 'px-2 py-0.5 text-xs';
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border font-bold tracking-wide ${toneClass[tone]} ${sizeClass}`}>
      {dot && <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" />}
      {children}
    </span>
  );
}
