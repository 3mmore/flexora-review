/**
 * FLEXORA — Global Command Center (Cmd+K)
 * Product-level redesign: navigation, records, actions, and operator shortcuts
 * in a single keyboard-first experience.
 */
'use client';
import { useEffect, useMemo, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Icon } from './brand/Icon';
import { api } from '@/lib/api';
import { useTranslation } from '@/lib/i18n';
import { fmtMoney } from '@/lib/money';

type Item = {
  id: string;
  title: string;
  subtitle?: string;
  group: string;
  href: string;
  icon?: 'arrow-right' | 'lightning' | 'users' | 'coins' | 'calendar' | 'menu-grid' | 'chart' | 'cog' | 'sparkle' | 'home' | 'bell' | 'shield';
  keywords?: string[];
};

export function CommandPalette() {
  const { t } = useTranslation();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const [hi, setHi] = useState(0);
  const [remote, setRemote] = useState<Item[]>([]);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const STATIC_ITEMS: Item[] = useMemo(() => [
    { id: 'dash', title: t('dash_title'), subtitle: t('dash_sub'), group: t('navigation_group'), href: '/dashboard', icon: 'home', keywords: ['dashboard', 'overview', 'executive'] },
    { id: 'members', title: t('members_title'), subtitle: t('members_sub'), group: t('navigation_group'), href: '/members', icon: 'users', keywords: ['people', 'customers', 'renewals'] },
    { id: 'attendance', title: t('attendance_title_cp'), subtitle: t('attendance_sub'), group: t('navigation_group'), href: '/attendance', icon: 'home', keywords: ['checkin', 'visits'] },
    { id: 'classes', title: t('classes_title'), subtitle: t('classes_sub'), group: t('navigation_group'), href: '/classes', icon: 'calendar' },
    { id: 'pos', title: t('pos_title'), subtitle: t('pos_sub'), group: t('navigation_group'), href: '/pos', icon: 'coins', keywords: ['sales', 'checkout', 'invoice'] },
    { id: 'inventory', title: t('inventory_title'), subtitle: t('inventory_sub'), group: t('navigation_group'), href: '/inventory', icon: 'menu-grid', keywords: ['products', 'stock', 'supplier'] },
    { id: 'reports', title: t('reports_title'), subtitle: t('reports_sub'), group: t('navigation_group'), href: '/reports', icon: 'chart' },
    { id: 'ai', title: t('ai_title'), subtitle: t('ai_sub'), group: t('navigation_group'), href: '/ai', icon: 'sparkle', keywords: ['assistant', 'forecast', 'churn'] },
    { id: 'campaigns', title: t('campaigns_title'), subtitle: t('campaigns_sub'), group: t('navigation_group'), href: '/campaigns', icon: 'bell' },
    { id: 'settings', title: t('settings_title'), subtitle: t('settings_sub'), group: t('navigation_group'), href: '/settings', icon: 'cog' },
    { id: 'add-member', title: t('add_member_title'), subtitle: t('add_member_sub'), group: t('quick_actions_group'), href: '/members?action=new', icon: 'lightning', keywords: ['new member', 'register'] },
    { id: 'sell', title: t('sell_title'), subtitle: t('sell_sub'), group: t('quick_actions_group'), href: '/pos', icon: 'coins', keywords: ['sell', 'invoice'] },
    { id: 'renewals', title: t('renewals_title'), subtitle: t('renewals_sub'), group: t('quick_actions_group'), href: '/members?status=expired', icon: 'bell', keywords: ['risk', 'retention'] },
    { id: 'backup', title: t('backup_title'), subtitle: t('backup_sub'), group: t('quick_actions_group'), href: '/backups', icon: 'shield' },
  ], [t]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setOpen((v) => !v);
        setQ('');
        setHi(0);
        setTimeout(() => inputRef.current?.focus(), 30);
      } else if (e.key === 'Escape' && open) {
        setOpen(false);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  useEffect(() => {
    let cancelled = false;
    async function loadRemote() {
      if (!open || q.trim().length < 2) { setRemote([]); return; }
      setLoading(true);
      try {
        const [members, products, sales] = await Promise.all([
          api<{ items: Array<{ id: string; name: string; mobile?: string; code?: string }> }>(`/members?q=${encodeURIComponent(q)}&limit=5`).catch(() => ({ items: [] })),
          api<Array<{ id: string; name: string; barcode?: string }>>(`/products?q=${encodeURIComponent(q)}`).catch(() => []),
          api<{ items: Array<{ id: string; invoiceNo?: string; total?: number }> }>('/sales?limit=5').catch(() => ({ items: [] })),
        ]);
        if (cancelled) return;
        setRemote([
          ...(members.items || []).map((m) => ({ id: `member-${m.id}`, title: m.name, subtitle: `${m.code || t('member')} · ${m.mobile || ''}`, group: t('members_title'), href: `/members?q=${encodeURIComponent(m.name)}`, icon: 'users' as const })),
          ...(products || []).slice(0, 5).map((p) => ({ id: `product-${p.id}`, title: p.name, subtitle: p.barcode || t('inventory'), group: t('inventory_title'), href: `/inventory?q=${encodeURIComponent(p.name)}`, icon: 'menu-grid' as const })),
          ...(sales.items || []).filter((s) => (s.invoiceNo || '').toLowerCase().includes(q.toLowerCase())).map((s) => ({ id: `sale-${s.id}`, title: s.invoiceNo || s.id, subtitle: fmtMoney(s.total), group: t('sales'), href: '/pos', icon: 'coins' as const })),
        ]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    const t_timeout = setTimeout(loadRemote, 180);
    return () => { cancelled = true; clearTimeout(t_timeout); };
  }, [open, q, t]);

  const score = (q: string, item: Item): number => {
    if (!q) return 0.1;
    const hay = `${item.title} ${item.subtitle ?? ''} ${item.group} ${(item.keywords ?? []).join(' ')}`.toLowerCase();
    const term = q.toLowerCase().trim();
    if (hay.includes(term)) return 1;
    return term.split(/\s+/).filter((w) => hay.includes(w)).length / Math.max(term.split(/\s+/).length, 1);
  };

  const filtered = useMemo(() => {
    return [...remote, ...STATIC_ITEMS]
      .map((it) => ({ it, s: score(q, it) }))
      .filter((x) => x.s > 0 || !q)
      .sort((a, b) => b.s - a.s)
      .slice(0, 12)
      .map((x) => x.it);
  }, [q, remote, STATIC_ITEMS]);

  useEffect(() => { setHi(0); }, [q]);

  const pick = (i: number) => {
    const it = filtered[i];
    if (!it) return;
    router.push(it.href);
    setOpen(false);
  };

  return (
    <>
      <button onClick={() => { setOpen(true); setTimeout(() => inputRef.current?.focus(), 30); }} className="cmd-trigger" aria-label={t('search_workspace')}>
        <Icon name="search" size={14} />
        <span>{t('search_workspace')}</span>
        <kbd className="kbd">⌘K</kbd>
      </button>

      {open && (
        <div className="cmd-overlay" onClick={() => setOpen(false)} role="dialog" aria-modal="true">
          <div className="cmd-modal" onClick={(e) => e.stopPropagation()}>
            <div className="cmd-input-wrap">
              <Icon name="search" size={18} />
              <input
                ref={inputRef}
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder={t('search_placeholder')}
                className="cmd-input"
                onKeyDown={(e) => {
                  if (e.key === 'ArrowDown') { e.preventDefault(); setHi((h) => Math.min(h + 1, filtered.length - 1)); }
                  else if (e.key === 'ArrowUp') { e.preventDefault(); setHi((h) => Math.max(h - 1, 0)); }
                  else if (e.key === 'Enter') { e.preventDefault(); pick(hi); }
                }}
              />
              {loading ? <span className="loader" /> : <kbd className="kbd">ESC</kbd>}
            </div>
            <div className="cmd-list" role="listbox">
              {filtered.length === 0 ? (
                <div className="cmd-empty"><Icon name="search" size={32} /><p>{t('no_results_for')} "{q}"</p><span>{t('try_searching_for')}</span></div>
              ) : filtered.map((it, i) => (
                <button key={it.id} className={`cmd-item ${i === hi ? 'cmd-item-hi' : ''}`} onMouseEnter={() => setHi(i)} onClick={() => pick(i)} role="option" aria-selected={i === hi}>
                  <div className="cmd-item-icon"><Icon name={it.icon || (it.group === t('quick_actions_group') ? 'lightning' : 'arrow-right')} size={14} /></div>
                  <div className="cmd-item-body"><div className="cmd-item-title">{it.title}</div>{it.subtitle && <div className="cmd-item-sub">{it.subtitle}</div>}</div>
                  <div className="cmd-item-group">{it.group}</div>
                  <kbd className="kbd">↵</kbd>
                </button>
              ))}
            </div>
            <div className="cmd-footer"><span><kbd className="kbd">↑↓</kbd> {t('navigate')}</span><span><kbd className="kbd">↵</kbd> {t('open')}</span><span><kbd className="kbd">⌘K</kbd> {t('anywhere')}</span></div>
          </div>
        </div>
      )}
    </>
  );
}
