/**
 * FLEXORA Gym OS — Brand live-refresh regression tests.
 *
 * P0 (live round, 2026-09): the onboarding theme color & logo were persisted
 * to the gym but the BrandProvider fetched /api/gyms/me exactly ONCE per page
 * load — usually right after register, i.e. BEFORE onboarding had saved the
 * chosen color/logo — and never again. Result: the default blue (#6366F1) and
 * the placeholder "F" stayed until a full F5 reload.
 *
 * These tests lock down the fix: after the branding changes (onboarding
 * complete / white-label save), dispatching BRAND_REFRESH_EVENT makes the
 * provider re-read /api/gyms/me and re-apply the NEW color/logo immediately.
 */
import React from 'react';
import { act } from 'react';
import { createRoot } from 'react-dom/client';
import { BrandProvider, dispatchBrandRefresh, BRAND_REFRESH_EVENT } from './BrandContext';

(global as any).IS_REACT_ACT_ENVIRONMENT = true;

const DEFAULT_GYM = { name: 'Gym', accentColor: '#6366F1', logo: null };
const CHOSEN_GYM = { name: 'Gym', accentColor: '#ff0000', logo: 'data:image/png;base64,AAA' };

function mockGymsMe(sequence: Array<Record<string, unknown>>) {
  let i = 0;
  return jest.fn(async (url: string) => {
    if (String(url).includes('/api/gyms/me')) {
      const body = sequence[Math.min(i, sequence.length - 1)];
      i += 1;
      return { ok: true, json: async () => body } as unknown as Response;
    }
    return { ok: true, json: async () => ({}) } as unknown as Response;
  });
}

async function flush(ms = 0) {
  await act(async () => { await new Promise((r) => setTimeout(r, ms)); });
}

describe('BrandContext — live brand refresh (theme color/logo without F5)', () => {
  let container: HTMLDivElement;
  let root: ReturnType<typeof createRoot>;

  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
    document.documentElement.removeAttribute('style');
  });

  afterEach(() => {
    act(() => { root.unmount(); });
    container.remove();
    jest.restoreAllMocks();
  });

  it('applies the default color on first load', async () => {
    (global as any).fetch = mockGymsMe([DEFAULT_GYM]);
    root = createRoot(container);
    await act(async () => { root.render(React.createElement(BrandProvider, null, React.createElement('div'))); });
    await flush(10);
    expect(document.documentElement.style.getPropertyValue('--primary')).toBe('#6366F1');
  });

  it('re-applies the NEW color/logo when BRAND_REFRESH_EVENT is dispatched (no reload)', async () => {
    // First fetch (right after register) returns the still-default gym.
    // After onboarding completes, the second fetch returns the chosen brand.
    (global as any).fetch = mockGymsMe([DEFAULT_GYM, CHOSEN_GYM]);
    root = createRoot(container);
    await act(async () => { root.render(React.createElement(BrandProvider, null, React.createElement('div'))); });
    await flush(10);
    expect(document.documentElement.style.getPropertyValue('--primary')).toBe('#6366F1');

    // Onboarding complete -> dispatchBrandRefresh()
    await act(async () => { dispatchBrandRefresh(); });
    await flush(10);

    expect(document.documentElement.style.getPropertyValue('--primary')).toBe('#ff0000');
    expect(document.documentElement.style.getPropertyValue('--cyan')).toBe('#ff0000');
    expect((global as any).fetch).toHaveBeenCalledTimes(2);
  });

  it('exposes a stable event name used by both the provider and dispatcher', () => {
    expect(BRAND_REFRESH_EVENT).toBe('flexora:brand-refresh');
    // dispatchBrandRefresh must target the same event the provider listens to.
    const seen: string[] = [];
    const h = (e: Event) => seen.push(e.type);
    window.addEventListener(BRAND_REFRESH_EVENT, h);
    dispatchBrandRefresh();
    window.removeEventListener(BRAND_REFRESH_EVENT, h);
    expect(seen).toEqual([BRAND_REFRESH_EVENT]);
  });
});
