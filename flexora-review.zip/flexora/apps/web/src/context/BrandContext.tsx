"use client";
import { isConsolePath } from "@/lib/admin-hosts";
import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  ReactNode,
} from "react";

export type ThemeName =
  | "orange"
  | "silver"
  | "blue"
  | "green"
  | "red"
  | "gold"
  | "white"
  | "black";

export interface ThemeTokens {
  primary: string;
  primaryDim: string;
  primaryGlow: string;
  background: string;
  surface: string;
  elevated: string;
  overlay: string;
  border: string;
  textPrimary: string;
  textSecondary: string;
  textMuted: string;
  success: string;
  warning: string;
  danger: string;
}

export const THEME_LIBRARY: Record<ThemeName, ThemeTokens> = {
  orange: {
    primary: "#c5a059",
    primaryDim: "#4a3d21",
    primaryGlow: "rgba(197, 160, 89, 0.15)",
    background: "#141312",
    surface: "#1d1b1a",
    elevated: "#1d1b1a",
    overlay: "#23201e",
    border: "rgba(255, 255, 255, 0.08)",
    textPrimary: "#FFFFFF",
    textSecondary: "#B5B5B5",
    textMuted: "#737373",
    success: "#00D26A",
    warning: "#FFB000",
    danger: "#FF4D4D",
  },
  silver: {
    primary: "#C0C0C0",
    primaryDim: "#A9A9A9",
    primaryGlow: "rgba(192, 192, 192, 0.15)",
    background: "#0F0F0F",
    surface: "#1A1A1A",
    elevated: "#252525",
    overlay: "#2C2C2C",
    border: "rgba(255, 255, 255, 0.08)",
    textPrimary: "#FFFFFF",
    textSecondary: "#B5B5B5",
    textMuted: "#737373",
    success: "#00D26A",
    warning: "#FFB000",
    danger: "#FF4D4D",
  },
  blue: {
    primary: "#0066FF",
    primaryDim: "#0052CC",
    primaryGlow: "rgba(0, 102, 255, 0.15)",
    background: "#050A15",
    surface: "#0B1225",
    elevated: "#121B35",
    overlay: "#182445",
    border: "rgba(255, 255, 255, 0.08)",
    textPrimary: "#FFFFFF",
    textSecondary: "#B5B5B5",
    textMuted: "#737373",
    success: "#00D26A",
    warning: "#FFB000",
    danger: "#FF4D4D",
  },
  green: {
    primary: "#00C853",
    primaryDim: "#00A844",
    primaryGlow: "rgba(0, 200, 83, 0.15)",
    background: "#050A05",
    surface: "#0B120B",
    elevated: "#121B12",
    overlay: "#182418",
    border: "rgba(255, 255, 255, 0.08)",
    textPrimary: "#FFFFFF",
    textSecondary: "#B5B5B5",
    textMuted: "#737373",
    success: "#00D26A",
    warning: "#FFB000",
    danger: "#FF4D4D",
  },
  red: {
    primary: "#FF3B30",
    primaryDim: "#D7332A",
    primaryGlow: "rgba(255, 59, 48, 0.15)",
    background: "#0A0505",
    surface: "#110B0B",
    elevated: "#170E0E",
    overlay: "#1C1313",
    border: "rgba(255, 255, 255, 0.08)",
    textPrimary: "#FFFFFF",
    textSecondary: "#B5B5B5",
    textMuted: "#737373",
    success: "#00D26A",
    warning: "#FFB000",
    danger: "#FF4D4D",
  },
  gold: {
    primary: "#D4AF37",
    primaryDim: "#B8860B",
    primaryGlow: "rgba(212, 175, 55, 0.15)",
    background: "#0D0C0A",
    surface: "#151411",
    elevated: "#1C1B17",
    overlay: "#22211D",
    border: "rgba(255, 255, 255, 0.08)",
    textPrimary: "#FFFFFF",
    textSecondary: "#B5B5B5",
    textMuted: "#737373",
    success: "#00D26A",
    warning: "#FFB000",
    danger: "#FF4D4D",
  },
  white: {
    primary: "#333333",
    primaryDim: "#555555",
    primaryGlow: "rgba(0, 0, 0, 0.1)",
    background: "#F5F5F7",
    surface: "#FFFFFF",
    elevated: "#FAFAFB",
    overlay: "#F0F0F2",
    border: "rgba(0, 0, 0, 0.08)",
    textPrimary: "#000000",
    textSecondary: "#666666",
    textMuted: "#A1A1A1",
    success: "#00D26A",
    warning: "#FFB000",
    danger: "#FF4D4D",
  },
  black: {
    primary: "#FFFFFF",
    primaryDim: "#CCCCCC",
    primaryGlow: "rgba(255, 255, 255, 0.1)",
    background: "#000000",
    surface: "#050505",
    elevated: "#0A0A0A",
    overlay: "#0F0F0F",
    border: "rgba(255, 255, 255, 0.08)",
    textPrimary: "#FFFFFF",
    textSecondary: "#B5B5B5",
    textMuted: "#737373",
    success: "#00D26A",
    warning: "#FFB000",
    danger: "#FF4D4D",
  },
};

export interface BrandConfig {
  logoUrl?: string;
  faviconUrl?: string;
  companyName?: string;
  systemName?: string;
  tagline?: string;
  primaryColor?: string;
  secondaryColor?: string;
  accentColor?: string;
  customFont?: string;
  useCustomBrand: boolean;
}

export interface BrandContextType {
  theme: ThemeName;
  setTheme: (theme: ThemeName) => void;
  brand: BrandConfig;
  setBrand: (config: Partial<BrandConfig>) => void;
}

export const BrandContext = createContext<BrandContextType | undefined>(
  undefined,
);

function hexToRgba(hex: string, alpha: number): string {
  const m = String(hex || "").trim().replace("#", "");
  if (m.length !== 6 || /[^0-9a-fA-F]/.test(m)) return `rgba(0, 0, 0, ${alpha})`;
  const n = parseInt(m, 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${alpha})`;
}

/**
 * "197, 160, 89" — the triplet the stylesheet expects in `rgba(var(--brand-rgb), α)`.
 * Returns null for anything that is not a 6-digit hex (callers then leave the
 * stylesheet default alone rather than writing a broken value).
 */
export function hexToTriplet(hex: string): string | null {
  const m = String(hex || "").trim().replace("#", "");
  if (m.length !== 6 || /[^0-9a-fA-F]/.test(m)) return null;
  const n = parseInt(m, 16);
  return `${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}`;
}

function darken(hex: string, factor: number): string {
  const m = String(hex || "").trim().replace("#", "");
  if (m.length !== 6 || /[^0-9a-fA-F]/.test(m)) return hex;
  const n = parseInt(m, 16);
  const r = Math.round(((n >> 16) & 255) * factor);
  const g = Math.round(((n >> 8) & 255) * factor);
  const b = Math.round((n & 255) * factor);
  return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, "0")}`;
}

/**
 * Apply theme + brand CSS custom properties to :root. Pure DOM side effect —
 * called from the theme/brand effect AND synchronously the moment gym data
 * arrives (see applyGym), so the chosen accent color is applied the instant
 * /api/gyms/me responds instead of waiting for a React effect flush.
 */
export function applyBrandCss(root: HTMLElement, theme: ThemeName, brand: BrandConfig): void {
  const tokens = THEME_LIBRARY[theme];

  root.style.setProperty("--color-primary", tokens.primary);
  root.style.setProperty("--color-primary-dim", tokens.primaryDim);
  root.style.setProperty("--color-primary-glow", tokens.primaryGlow);
  root.style.setProperty("--color-background", tokens.background);
  root.style.setProperty("--color-surface", tokens.surface);
  root.style.setProperty("--color-elevated", tokens.elevated);
  root.style.setProperty("--color-overlay", tokens.overlay);
  root.style.setProperty("--color-border", tokens.border);
  root.style.setProperty("--color-text-primary", tokens.textPrimary);
  root.style.setProperty("--color-text-secondary", tokens.textSecondary);
  root.style.setProperty("--color-text-muted", tokens.textMuted);
  root.style.setProperty("--color-success", tokens.success);
  root.style.setProperty("--color-warning", tokens.warning);
  root.style.setProperty("--color-danger", tokens.danger);

  // Apply custom white-label colors if active
  if (brand.useCustomBrand) {
    if (brand.primaryColor)
      root.style.setProperty("--color-primary", brand.primaryColor);
    // A "dim" token must be a DARKENED color and a "glow" must carry alpha —
    // both used to be set to a raw accent hex, which is wrong for anything that
    // composites them. Derive them from the accent instead.
    const accentForTokens = brand.accentColor || brand.primaryColor;
    if (brand.secondaryColor)
      root.style.setProperty("--color-primary-dim", brand.secondaryColor);
    else if (accentForTokens)
      root.style.setProperty("--color-primary-dim", darken(accentForTokens, 0.4));
    if (accentForTokens)
      root.style.setProperty("--color-primary-glow", hexToRgba(accentForTokens, 0.25));

    // FLEXORA's UI is driven by the --cyan AND --primary families; theme
    // them so the chosen accent color actually changes the app (buttons,
    // focus rings, active nav, badges, borders). --primary is the single
    // source the main CTA button rule (globals.css) resolves to.
    const c = brand.accentColor || brand.primaryColor;
    if (c) {
      /**
       * ── THE ROOT-CAUSE FIX (theme color regression) ──────────────────────
       * Everything in the stylesheet that is tinted "the gym's color" now
       * derives from these four tokens: the sidebar's active item, borders,
       * glows, focus rings, scrollbars, empty states, icon strokes, the logo
       * mark — the whole shell. Previously only --cyan/--primary were set, so
       * ~200 hardcoded gold literals kept rendering the old default and the app
       * looked black-and-gold with a mismatched accent no matter how many of
       * those literals a previous round patched by hand.
       * ───────────────────────────────────────────────────────────────────── */
      root.style.setProperty("--brand", c);
      const triplet = hexToTriplet(c);
      if (triplet) root.style.setProperty("--brand-rgb", triplet);
      const dim = darken(c, 0.4);
      root.style.setProperty("--brand-dim", dim);
      const dimTriplet = hexToTriplet(dim);
      if (dimTriplet) root.style.setProperty("--brand-dim-rgb", dimTriplet);
      // the design-token layer (--color-*) must not stay gold either
      root.style.setProperty("--color-primary", c);
      root.style.setProperty("--color-primary-dim", dim);
      root.style.setProperty("--color-primary-glow", hexToRgba(c, 0.25));

      root.style.setProperty("--cyan", c);
      root.style.setProperty("--cyan-text", c);
      root.style.setProperty("--info", c);
      root.style.setProperty("--cyan-dim", darken(c, 0.4));
      root.style.setProperty("--cyan-glow", hexToRgba(c, 0.25));
      root.style.setProperty("--cyan-border", hexToRgba(c, 0.3));
      root.style.setProperty("--primary", c);
      root.style.setProperty("--primary-soft", hexToRgba(c, 0.14));
      root.style.setProperty("--primary-border", hexToRgba(c, 0.26));
      root.style.setProperty("--primary-glow", hexToRgba(c, 0.25));
      // Button label contrast: white on dark accents, near-black on light.
      const cm = String(c).trim().replace("#", "");
      if (cm.length === 6 && !/[^0-9a-fA-F]/.test(cm)) {
        const nn = parseInt(cm, 16);
        const lum = (0.299 * ((nn >> 16) & 255) + 0.587 * ((nn >> 8) & 255) + 0.114 * (nn & 255)) / 255;
        root.style.setProperty("--btn-text", lum > 0.6 ? "#000000" : "#ffffff");
      }
    }
  } else {
    // No custom brand: strip any inline overrides so a default gym renders
    // with the stylesheet gold (and a themed session's colors don't leak
    // into the next gym in the same tab after logout).
    for (const v of [
      "--cyan", "--cyan-text", "--cyan-dim", "--cyan-glow", "--cyan-border",
      "--info", "--btn-text", "--primary", "--primary-soft", "--primary-border", "--primary-glow",
      // The brand tokens themselves: removing them restores the stylesheet's
      // gold defaults, so a gym with no custom color (or a logout) can never
      // inherit the previous gym's accent.
      "--brand", "--brand-rgb", "--brand-dim", "--brand-dim-rgb",
    ]) root.style.removeProperty(v);
    try { localStorage.removeItem(BRAND_CACHE_KEY); } catch { /* private mode */ }
  }
}

export const BrandProvider = ({ children }: { children: ReactNode }) => {
  const [theme, setTheme] = useState<ThemeName>("orange");
  const [brand, setBrandState] = useState<BrandConfig>({
    useCustomBrand: false,
    companyName: "FLEXORA",
    // Arabic defaults: the product ships Arabic-first, and this context has no
    // i18n hook (it runs before providers mount), so the default text is literal.
    systemName: "نظام إدارة الصالات",
    tagline: "ذكاء يدير صالتك",
  });

  // Kept in sync so the one-shot load() can apply CSS synchronously with the
  // current theme without re-running the theme effect.
  const themeRef = React.useRef<ThemeName>(theme);
  themeRef.current = theme;

  const setBrand = (config: Partial<BrandConfig>) => {
    setBrandState((prev) => ({ ...prev, ...config }));
  };

  // FIX (onboarding logo + theme color had zero effect): the gym's logo and
  // accentColor ARE persisted by onboarding (/gyms/me returns them), but the
  // brand context never read them — so the header always rendered the default
  // "F" mark and the chosen color never reached the UI.
  //
  // SECOND FIX (logo/color still ignored after SIGNUP): this provider mounts
  // on the FIRST page load — often /login, where /api/gyms/me 401s and the
  // one-shot fetch silently gave up. Client-side navigation to /dashboard
  // does NOT remount the root-layout provider, so the brand was never loaded
  // for the whole session (the "F" stayed, the accent color never applied).
  // The login/register pages now set sessionStorage['flexora-brand-refresh']
  // when authentication succeeds; when the first fetch misses (no session),
  // we watch for that flag and load the branding then.
  useEffect(() => {
    let cancelled = false;
    let timer: ReturnType<typeof setInterval> | null = null;
    // Empty NEXT_PUBLIC_API_URL → same-origin proxy mode.
    const API = (process.env.NEXT_PUBLIC_API_URL || "").replace(/\/$/, "");

    const applyGym = (gym: any) => {
      if (cancelled || !gym) return;
      const logo = gym.logo || gym.logoUrl;
      const accent = gym.accentColor || gym.primaryColor;
      if (!logo && !accent) {
        // No custom branding on this gym → drop any cached accent so the next
        // load cannot flash a different gym's color.
        try { localStorage.removeItem(BRAND_CACHE_KEY); } catch { /* noop */ }
      }
      if (logo || accent || gym.name) {
        // Clear (don't carry over) brand fields the current gym doesn't have,
        // so switching gyms in the same tab can't leak the previous gym's
        // logo/colors.
        const next: BrandConfig = {
          useCustomBrand: Boolean(logo || accent),
          logoUrl: logo || undefined,
          primaryColor: accent || undefined,
          accentColor: accent || undefined,
          companyName: gym.name || "FLEXORA",
          systemName: "نظام إدارة الصالات",
          tagline: "ذكاء يدير صالتك",
        };
        setBrandState(next);
        cacheBrand(next);
        // Apply the CSS variables IMMEDIATELY (not only via the effect) so the
        // chosen accent color shows the moment the API responds. Waiting for
        // the React effect flush could take several seconds on slow tabs,
        // which made the theme look "ignored" right after login/signup.
        try {
          applyBrandCss(document.documentElement, themeRef.current, next);
        } catch { /* SSR/noop */ }
      }
    };

    const load = async (): Promise<boolean> => {
      // PHASE R1 - the owner console must not call tenant endpoints. This provider
      // lives in the root layout, so before R1 it fetched /api/gyms/me on console
      // pages too, where there is no tenant session at all. The api answered 401 -
      // correctly, and review item 1 is precisely about refusing a platform cookie
      // on a tenant route - but a console page has no business asking, and the
      // request showed up as an error in the owner's browser console on every page.
      // Measured: two 401s per console page load (work/r1-console-csp.spec.js).
      // The console's own colours come from the pre-paint brand script, so nothing
      // visual changes here.
      if (typeof window !== "undefined" && isConsolePath(window.location.pathname)) return false;
      try {
        const r = await fetch(`${API}/api/gyms/me`, { credentials: "include" });
        if (cancelled) return false;
        if (r.ok) { applyGym(await r.json()); return true; }
      } catch { /* network error */ }
      return false;
    };

    load().then((ok) => {
      if (ok || cancelled) return;
      // No session yet (provider mounted before login). Wait for the login
      // pages to flip the sessionStorage flag, then load branding once.
      let checks = 0;
      timer = setInterval(async () => {
        if (cancelled) { if (timer) clearInterval(timer); return; }
        checks += 1;
        let flag = false;
        try { flag = sessionStorage.getItem("flexora-brand-refresh") === "1"; } catch { /* SSR/noop */ }
        if (flag) {
          try { sessionStorage.removeItem("flexora-brand-refresh"); } catch { /* noop */ }
          await load();
          if (timer) clearInterval(timer);
        } else if (checks >= 120) { // give up after ~2 minutes
          if (timer) clearInterval(timer);
        }
      }, 1000);
    });

    // REGRESSION FIX (theme color/logo "ignored" after signup & only applied
    // after F5): the brand was fetched exactly once per page-load — usually
    // RIGHT AFTER register, i.e. BEFORE onboarding persisted the chosen
    // accentColor/logo — and then never again. Any code path that changes the
    // gym branding (onboarding complete, white-label save, settings branding)
    // dispatches the 'flexora:brand-refresh' window event and the provider
    // re-reads /gyms/me so the UI updates IMMEDIATELY, no reload needed.
    const onBrandRefresh = () => { void load(); };
    window.addEventListener(BRAND_REFRESH_EVENT, onBrandRefresh);

    return () => {
      cancelled = true;
      if (timer) clearInterval(timer);
      window.removeEventListener(BRAND_REFRESH_EVENT, onBrandRefresh);
    };
  }, []);

  useEffect(() => {
    // Keeps :root in sync when the theme is switched from the UI or the brand
    // is cleared (logout). The initial brand load is applied synchronously in
    // applyGym (faster); this effect is the safety net for those paths.
    try {
      applyBrandCss(document.documentElement, theme, brand);
    } catch { /* SSR/noop */ }
  }, [theme, brand]);

  return (
    <BrandContext.Provider value={{ theme, setTheme, brand, setBrand }}>
      {children}
    </BrandContext.Provider>
  );
};

export const useBrand = () => {
  const context = useContext(BrandContext);
  if (!context) throw new Error("useBrand must be used within a BrandProvider");
  return context;
};

/**
 * Ask the BrandProvider (mounted once in the root layout) to re-read the
 * gym's logo/accent color from /api/gyms/me and re-apply them immediately.
 * Call this after ANY successful mutation that changes branding: onboarding
 * completion, white-label saves, settings logo/color changes. This is what
 * makes branding changes go live without a full page reload (F5).
 */
/**
 * Pre-paint cache. The API is the source of truth, but it can only answer AFTER
 * the page has loaded — until then the stylesheet's default gold was painted,
 * which is the "flashes gold / still looks default" complaint. The inline script
 * in app/layout.tsx reads this cache and sets the brand tokens before first
 * paint, so a returning visit to x is branded instantly and /gyms/me then
 * confirms (or corrects) it.
 */
export const BRAND_CACHE_KEY = "flexora-brand-v1";

export function cacheBrand(brand: BrandConfig): void {
  try {
    localStorage.setItem(BRAND_CACHE_KEY, JSON.stringify({
      accent: brand.accentColor || brand.primaryColor || null,
      logo: brand.logoUrl || null,
      name: brand.companyName || null,
      at: Date.now(),
    }));
  } catch { /* private mode */ }
}

export const BRAND_REFRESH_EVENT = "flexora:brand-refresh";
export function dispatchBrandRefresh(): void {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new Event(BRAND_REFRESH_EVENT));
}
