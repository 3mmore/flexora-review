/**
 * @jest-environment node
 */
/**
 * FLEXORA Gym OS - Web
 * (c) 2024 Ammar Allam. All rights reserved.
 *
 * PHASE R1.8 / owner decision D1 - the console CSP in Next middleware.
 *
 * D1's conditions, each asserted here against the real exported middleware:
 *   - a nonce of at least 128 bits, base64, generated per request and never reused;
 *   - set on the REQUEST headers so Next can put it on the scripts it injects, and on
 *     the RESPONSE policy;
 *   - Cache-Control no-store, Referrer-Policy no-referrer, X-Robots-Tag noindex,
 *     frame-ancestors 'none', base-uri 'none', form-action 'self', connect-src 'self',
 *     img-src 'self' data:, and a report sink;
 *   - applied ONLY on admin hostnames and ONLY to /platform*;
 *   - tenant pages keep today's headers byte-identical, which is asserted by proving
 *     the middleware adds NOTHING to a tenant response on either kind of hostname.
 *
 * The live browser half of this proof (the pages actually render and hydrate with zero
 * violations at 375px, and fail visibly when the nonce is removed) is
 * work/r1-console-csp.spec.js.
 */
jest.mock('jose', () => ({ jwtVerify: jest.fn().mockRejectedValue(new Error('no token in this suite')) }));

import { NextRequest } from 'next/server';
import { middleware } from './middleware';
import {
  CONSOLE_CSP_NONCE_BYTES,
  CONSOLE_CSP_REPORT_PATH,
  CONSOLE_CSP_USE_STRICT_DYNAMIC,
  consoleContentSecurityPolicy,
  consoleResponseHeaders,
  newCspNonce,
} from '@/lib/console-csp';
import { consoleFamily, containsNulByte, structuralPathVariants } from '@/lib/admin-hosts';

const env = process.env as Record<string, string | undefined>;
const ADMIN_HOST = 'console.test';
const PUBLIC_HOST = 'app.test';

let savedAdminHosts: string | undefined;
let savedNodeEnv: string | undefined;

function makeRequest(path: string, host: string, headers: Record<string, string> = {}): NextRequest {
  const req = new NextRequest(new URL(`http://${host}${path}`), { headers: { ...headers, host } });
  req.headers.set('host', host);
  return req;
}

function nonceFrom(policy: string | null): string | null {
  const match = /'nonce-([^']+)'/.exec(policy ?? '');
  return match ? match[1] : null;
}

/** Next encodes overridden request headers as x-middleware-request-<name>. */
function requestHeaderSeenByApp(res: Response, name: string): string | null {
  return res.headers.get(`x-middleware-request-${name.toLowerCase()}`);
}

beforeAll(() => {
  savedAdminHosts = env.ADMIN_HOSTS;
  savedNodeEnv = env.NODE_ENV;
  env.NODE_ENV = 'test';
  env.ADMIN_HOSTS = ADMIN_HOST;
});

afterAll(() => {
  if (savedAdminHosts === undefined) delete env.ADMIN_HOSTS;
  else env.ADMIN_HOSTS = savedAdminHosts;
  if (savedNodeEnv === undefined) delete env.NODE_ENV;
  else env.NODE_ENV = savedNodeEnv;
});

describe('D1 — 1. the policy itself', () => {
  it('1a. contains every directive D1 lists, and no unsafe-inline or unsafe-eval', () => {
    const policy = consoleContentSecurityPolicy('TESTNONCE==');
    expect(policy).toContain("default-src 'none'");
    expect(policy).toContain("script-src 'self' 'nonce-TESTNONCE=='");
    expect(policy).toContain("style-src 'self' 'nonce-TESTNONCE=='");
    expect(policy).toContain("connect-src 'self'");
    expect(policy).toContain("img-src 'self' data:");
    expect(policy).toContain("frame-ancestors 'none'");
    expect(policy).toContain("base-uri 'none'");
    expect(policy).toContain("form-action 'self'");
    expect(policy).toContain(`report-uri ${CONSOLE_CSP_REPORT_PATH}`);
    expect(policy).not.toContain('unsafe-inline');
    expect(policy).not.toContain('unsafe-eval');
  });

  it("1b. 'strict-dynamic' follows the documented constant, not an accident", () => {
    // Off on purpose: with it, 'self' is ignored for script-src and the root layout's
    // same-origin pre-paint script (relocated there in PHASE R0) would be blocked.
    // See the constraint note in lib/console-csp.ts. Flipping the constant must change
    // the policy, so this asserts the wiring rather than freezing the value.
    const policy = consoleContentSecurityPolicy('TESTNONCE==');
    expect(policy.includes('strict-dynamic')).toBe(CONSOLE_CSP_USE_STRICT_DYNAMIC);
    expect(CONSOLE_CSP_USE_STRICT_DYNAMIC).toBe(false);
  });

  it('1c. the nonce is 128 bits of base64 and is never repeated', () => {
    expect(CONSOLE_CSP_NONCE_BYTES).toBeGreaterThanOrEqual(16);
    const seen = new Set(Array.from({ length: 200 }, () => newCspNonce()));
    expect(seen.size).toBe(200);
    for (const value of seen) {
      expect(value).toMatch(/^[A-Za-z0-9+/]+={0,2}$/);
      // 16 bytes -> 24 base64 characters including padding
      expect(value.length).toBeGreaterThanOrEqual(22);
    }
  });

  it('1d. the rest of the console header set is the R1.8 list', () => {
    const headers = Object.fromEntries(consoleResponseHeaders());
    expect(headers['Cache-Control']).toMatch(/no-store/);
    expect(headers['Referrer-Policy']).toBe('no-referrer');
    expect(headers['X-Robots-Tag']).toMatch(/noindex/);
    expect(headers['X-Frame-Options']).toBe('DENY');
    expect(headers['X-Content-Type-Options']).toBe('nosniff');
  });
});

describe('D1 — 2. a console page on an administrator hostname', () => {
  it('2a. gets the console policy, and the SAME nonce is passed to the app', async () => {
    const res = await middleware(makeRequest('/platform/login', ADMIN_HOST, { 'sec-fetch-dest': 'document' }));
    const policy = res.headers.get('content-security-policy');
    expect(policy).toBeTruthy();
    const nonce = nonceFrom(policy);
    expect(nonce).toBeTruthy();
    expect(requestHeaderSeenByApp(res, 'x-csp-nonce')).toBe(nonce);
  });

  it('2b. gets no-store, no-referrer, noindex and DENY', async () => {
    // A session cookie is present so this exercises the document path rather than the
    // anonymous redirect (which 2d covers, and which now carries the same headers).
    const res = await middleware(
      makeRequest('/platform/dashboard', ADMIN_HOST, { 'sec-fetch-dest': 'document', cookie: 'flx_platform_token=a.b.c' }),
    );
    expect(res.headers.get('cache-control')).toMatch(/no-store/);
    expect(res.headers.get('referrer-policy')).toBe('no-referrer');
    expect(res.headers.get('x-robots-tag')).toMatch(/noindex/);
    expect(res.headers.get('x-frame-options')).toBe('DENY');
  });

  it('2c. a fresh nonce per request, never reused', async () => {
    const first = nonceFrom((await middleware(makeRequest('/platform/login', ADMIN_HOST))).headers.get('content-security-policy'));
    const second = nonceFrom((await middleware(makeRequest('/platform/login', ADMIN_HOST))).headers.get('content-security-policy'));
    expect(first).toBeTruthy();
    expect(second).toBeTruthy();
    expect(first).not.toBe(second);
  });

  it('2d. an anonymous visitor to a console page is still sent to the login page, with console headers on the redirect', async () => {
    const res = await middleware(makeRequest('/platform/dashboard', ADMIN_HOST, { 'sec-fetch-dest': 'document' }));
    expect(res.headers.get('location')).toContain('/platform/login');
    expect(res.status).toBe(307);
    expect(res.headers.get('cache-control')).toMatch(/no-store/);
    expect(res.headers.get('referrer-policy')).toBe('no-referrer');
    expect(res.headers.get('x-robots-tag')).toMatch(/noindex/);
  });
});

describe('D1 — 3. tenant pages keep today\'s headers byte-identical', () => {
  const tenantPaths = ['/', '/login', '/register', '/dashboard', '/members', '/settings', '/design-system'];

  it.each(tenantPaths)('3a. %s on an ADMIN hostname: the middleware adds no header of its own', async (path) => {
    const res = await middleware(makeRequest(path, ADMIN_HOST, { 'sec-fetch-dest': 'document' }));
    // The tenant policy comes from next.config.mjs at build time; the middleware must
    // not add, replace or duplicate it. If it did, the console's nonce policy would
    // leak onto tenant pages and 'unsafe-inline' would fight the nonce.
    expect(res.headers.get('content-security-policy')).toBeNull();
    expect(res.headers.get('x-robots-tag')).toBeNull();
    expect(res.headers.get('referrer-policy')).toBeNull();
    expect(requestHeaderSeenByApp(res, 'x-csp-nonce')).toBeNull();
  });

  it.each(tenantPaths)('3b. %s on a PUBLIC hostname: unchanged as well', async (path) => {
    const res = await middleware(makeRequest(path, PUBLIC_HOST, { 'sec-fetch-dest': 'document' }));
    expect(res.headers.get('content-security-policy')).toBeNull();
    expect(res.headers.get('x-robots-tag')).toBeNull();
    expect(requestHeaderSeenByApp(res, 'x-csp-nonce')).toBeNull();
  });

  it('3c. a console API path is passed through for the api to answer, with no web CSP', async () => {
    const res = await middleware(makeRequest('/api/platform/overview', ADMIN_HOST));
    expect(res.headers.get('content-security-policy')).toBeNull();
    expect(res.headers.get('x-middleware-rewrite')).toBeNull();
  });
});

describe('D1/R0 — 4. a console page on a PUBLIC hostname gets none of this', () => {
  it('4a. it is gated, and the refusal carries no console header', async () => {
    const res = await middleware(makeRequest('/platform/login', PUBLIC_HOST, { 'sec-fetch-dest': 'document' }));
    expect(res.headers.get('x-middleware-rewrite')).not.toBeNull();
    // A console-only header on a refusal would be exactly the existence signal R0
    // removed: it would say "this path is special" to anybody on the public hostname.
    expect(res.headers.get('content-security-policy')).toBeNull();
    expect(res.headers.get('x-robots-tag')).toBeNull();
    expect(res.headers.get('cache-control')).toBeNull();
    expect(res.headers.get('referrer-policy')).toBeNull();
  });
});

describe('review item 2 — 5. NUL bytes and the exotic spellings', () => {
  it('5a. a NUL is refused with 400 for a console path AND an unknown path, identically', async () => {
    const consoleNul = await middleware(makeRequest('/platform%00', PUBLIC_HOST));
    const unknownNul = await middleware(makeRequest('/definitely-not-a-route%00', PUBLIC_HOST));
    expect(consoleNul.status).toBe(400);
    expect(unknownNul.status).toBe(400);
    expect(await consoleNul.text()).toBe(await unknownNul.text());
    expect(consoleNul.headers.get('location')).toBeNull();
  });

  it('5b. the classifier recognises a NUL and the other attack spellings', () => {
    expect(containsNulByte('/platform%00')).toBe(true);
    expect(containsNulByte('/platform\u0000')).toBe(true);
    expect(containsNulByte('/%2570latform%2500')).toBe(true);
    expect(containsNulByte('/members')).toBe(false);
    for (const spelling of ['/platform;x=1/login', '/\\platform/login', '/api\\platform/overview', '/%2570latform/login', '/platform%00']) {
      expect(consoleFamily(spelling)).not.toBeNull();
    }
  });

  it.each(['/platform;x=1/login', '/\\platform/login', '/api\\platform/overview', '/%2570latform/login'])(
    '5c. %s on a PUBLIC hostname is gated like a console path',
    async (spelling) => {
      const res = await middleware(makeRequest(spelling, PUBLIC_HOST, { 'sec-fetch-dest': 'document' }));
      // a page spelling is rewritten to the not-found path; an api spelling is handed
      // to the api unchanged so the api's own gate answers with a path-faithful 404
      const gated = res.headers.get('x-middleware-rewrite') !== null || spelling.startsWith('/api');
      expect(gated).toBe(true);
      expect(res.headers.get('location')).toBeNull();
    },
  );

  it('5d. the structural rewrites do not turn a tenant path into a console path', () => {
    for (const tenantPath of ['/platformer-x/login', '/members;v=2', '/\\members', '/member%73']) {
      expect(consoleFamily(tenantPath)).toBeNull();
    }
    expect(structuralPathVariants('/platform;x=1/login')).toContain('/platform/login');
    expect(structuralPathVariants('/\\platform/login')).toContain('/platform/login');
  });
});
