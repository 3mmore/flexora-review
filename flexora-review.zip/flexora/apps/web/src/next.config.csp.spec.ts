/**
 * Regression guard for the CSP "hardcoded connect-src" regression.
 *
 * History: `connect-src` in next.config.mjs was hand-edited to a hardcoded
 * `'self' https://*.stripe.com`, which silently blocked every browser API
 * call (the client bundle fetches NEXT_PUBLIC_API_URL, a cross-origin URL)
 * and surfaced only as mysterious "Failed to fetch" / CSP violation errors.
 *
 * These tests fail if:
 *  1. the config stops deriving the API origin from NEXT_PUBLIC_API_URL, or
 *  2. the rendered CSP does not actually contain the configured API origin, or
 *  3. the exact hardcoded regression string reappears.
 *
 * PHASE R0 REPAIR (test-only; next.config.mjs was NOT modified - it is byte-identical
 * to the delivered release). getConnectSrcFragment() used to match the first
 * "connect-src" in the file, and the first one is inside the warning comment at the top
 * of next.config.mjs. The guard therefore read prose instead of the directive: test 1
 * failed outright and test 2 passed VACUOUSLY, because a comment can never match the
 * regression pattern it was written to catch. Comments are now stripped before the
 * match, and the parser is self-tested against a synthetic config in which connect-src
 * appears ONLY in comments - so reverting the parser to the naive regex fails a test.
 */
import { execFile } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';

const CONFIG_PATH = path.join(__dirname, '..', 'next.config.mjs');

function readConfigSource(): string {
  return fs.readFileSync(CONFIG_PATH, 'utf8');
}

/**
 * Remove block comments and whole-line // comments. Deliberately simple: it only has
 * to be good enough that prose mentioning a CSP directive cannot be mistaken for the
 * directive. String/template literals in next.config.mjs contain no // or /* sequences,
 * and the self-test below pins the behaviour that matters.
 */
function stripComments(source: string): string {
  return source
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/^\s*\/\/.*$/gm, '')
    .replace(/^\s*\*.*$/gm, ''); // the continuation lines of a /** ... */ header
}

function getConnectSrcFragment(source: string): string {
  const match = stripComments(source).match(/connect-src[^;`]*/);
  if (!match) throw new Error('connect-src directive not found in next.config.mjs');
  return match[0];
}

describe('next.config.mjs CSP (regression guard)', () => {
  it('derives the API origin from NEXT_PUBLIC_API_URL', () => {
    const source = readConfigSource();
    expect(source).toContain('NEXT_PUBLIC_API_URL');
    // The connect-src directive must interpolate the derived origin variable.
    expect(getConnectSrcFragment(source)).toContain('${apiOrigin}');
  });

  it('PARSER SELF-TEST: connect-src mentioned only in comments is not the directive', () => {
    // This is the case that broke the guard. Without comment stripping, the naive
    // /connect-src[^;`]*/ returns the first comment's text and both assertions below
    // fail - which is exactly what a mutation back to the old parser must produce.
    const sample = [
      '// connect-src MUST derive the API origin from NEXT_PUBLIC_API_URL - NEVER',
      '// hardcode it. A previous regression hardcoded `connect-src \'self\'` and',
      '/* connect-src \'self\' https://*.stripe.com was the old broken value */',
      ' * connect-src is mentioned in JSDoc continuation lines too',
      'const header = `default-src \'self\'; connect-src \'self\' ${apiOrigin} https://*.stripe.com; `;',
    ].join('\n');
    const fragment = getConnectSrcFragment(sample);
    expect(fragment).toContain('${apiOrigin}');
    expect(fragment).not.toContain('MUST derive');
    expect(fragment).not.toContain('old broken value');
    expect(fragment).not.toContain('JSDoc');
    expect(fragment.trim().startsWith('connect-src')).toBe(true);
  });

  it('the fragment taken from the real config IS the directive, not prose', () => {
    const source = readConfigSource();
    // next.config.mjs mentions connect-src in comments as well, so a parser that does
    // not strip them silently reads the wrong thing. Pin both facts.
    expect((source.match(/connect-src/g) || []).length).toBeGreaterThan(1);
    const fragment = getConnectSrcFragment(source);
    expect(fragment.trim().startsWith("connect-src 'self'")).toBe(true);
    expect(fragment).toContain('${apiOrigin}');
    expect(fragment).not.toContain('NEVER');
  });

  it('does not contain the hardcoded self-only regression', () => {
    const fragment = getConnectSrcFragment(readConfigSource());
    // The historical regression: connect-src 'self' https://*.stripe.com (no API origin)
    expect(fragment).not.toMatch(/connect-src\s+'self'\s+https:\/\/\*\.stripe\.com/);
  });

  it('renders a CSP that contains the configured API origin', async () => {
    const script = `
      const m = await import(${JSON.stringify('file://' + CONFIG_PATH)});
      const headers = await m.default.headers();
      const csp = headers[0].headers.find((h) => h.key === 'Content-Security-Policy');
      process.stdout.write(csp.value);
    `;
    const { spawn } = await import('child_process');
    const out = await new Promise<string>((resolve, reject) => {
      const child = spawn(process.execPath, ['--input-type=module', '-e', script], {
        env: { ...process.env, NEXT_PUBLIC_API_URL: 'http://api.test.example:4000' },
      });
      let stdout = '';
      child.stdout.on('data', (d) => (stdout += d));
      child.on('error', reject);
      child.on('close', (code) => (code === 0 ? resolve(stdout) : reject(new Error(`node exited ${code}`))));
    });
    expect(out).toContain('http://api.test.example:4000');
    expect(out).toContain("connect-src 'self' http://api.test.example:4000 https://*.stripe.com");
  });

  it('uses same-origin /api proxy mode when NEXT_PUBLIC_API_URL is unset', async () => {
    const script = `
      const m = await import(${JSON.stringify('file://' + CONFIG_PATH)});
      const headers = await m.default.headers();
      const csp = headers[0].headers.find((h) => h.key === 'Content-Security-Policy');
      const rewrites = await m.default.rewrites();
      process.stdout.write(JSON.stringify({ csp: csp.value, rewrites }));
    `;
    const { spawn } = await import('child_process');
    const out = await new Promise<string>((resolve, reject) => {
      const env = { ...process.env };
      delete env.NEXT_PUBLIC_API_URL;
      const child = spawn(process.execPath, ['--input-type=module', '-e', script], { env });
      let stdout = '';
      child.stdout.on('data', (d) => (stdout += d));
      child.on('error', reject);
      child.on('close', (code) => (code === 0 ? resolve(stdout) : reject(new Error(`node exited ${code}`))));
    });
    const parsed = JSON.parse(out);
    // Proxy mode: browser calls same-origin /api, so 'self' in connect-src is
    // the correct (and only needed) API allowance.
    expect(parsed.csp).toContain("connect-src 'self'");
    expect(Array.isArray(parsed.rewrites) ? parsed.rewrites.length : 0).toBeGreaterThan(0);
    expect(JSON.stringify(parsed.rewrites)).toContain('/api/:path*');
  });
});
