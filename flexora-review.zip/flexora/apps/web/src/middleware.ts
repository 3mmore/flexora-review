import { NextResponse, NextRequest } from 'next/server';
import { jwtVerify } from 'jose';
import { requiredPermissionFor, effectivePermissionsOf } from '@/lib/permissions';
import { adminHostVerdict, consoleFamily, containsNulByte } from '@/lib/admin-hosts';
import { consoleContentSecurityPolicy, consoleResponseHeaders, newCspNonce } from '@/lib/console-csp';

/**
 * PHASE R0 - the path a refused console PAGE request is rewritten to, so that Next
 * renders ITS OWN not-found answer instead of a hand-built 404: an empty body with a
 * different header set is exactly the kind of response an attacker fingerprints as
 * "the console exists but is gated".
 *
 * The equivalence is measured, not assumed. Next's not-found page is byte-stable
 * across unknown paths (three different unknown paths each returned 14,415 bytes,
 * sha256 234af551c0737e17, with an identical header-name set), and
 * work/r0-evidence.sh compares every refused console request with an unknown route
 * of the same family on the SAME host - status, content type, header-name set and
 * normalised body.
 *
 * Console API paths are deliberately NOT rewritten to a sentinel: see the gate below.
 */
const HOST_GATE_NOT_FOUND = '/host-gate-not-found';

const exactPublicPaths = new Set([
  '/login', '/login/2fa', '/register', '/favicon.ico', '/logo.png',
  '/manifest.webmanifest', '/sw.js', '/landing', '/design-system',
  // PHASE R0.5: the brand pre-paint script moved out of the inline <script> in the
  // root layout into this same-origin file (see public/brand-prepaint.js). It is a
  // public asset exactly like /sw.js and /logo.png: no session, no redirect.
  '/brand-prepaint.js',
  // P2: self-service check-in kiosk screen — runs on a branch tablet with no
  // staff session; it authenticates with the device token instead.
  '/checkin/kiosk',
]);
const publicPrefixes = ['/api/', '/_next/'];
const encoder = new TextEncoder();

async function verifyJwtPayload(token?: string) {
  try {
    if (!token || !process.env.JWT_ACCESS_SECRET) return null;
    const { payload } = await jwtVerify(token, encoder.encode(process.env.JWT_ACCESS_SECRET), { algorithms: ['HS256'] });
    return payload as { role?: string; onboardingCompleted?: boolean; type?: string; permissions?: string[] };
  } catch {
    return null;
  }
}

/**
 * ROOT FIX (round 12 — "restricted staff get logged out when they navigate"):
 *
 * An expired/absent ACCESS cookie is NOT a finished session. The refresh cookie
 * lives for 7 days, but the access cookie only for 15 minutes, and the web app
 * only ever refreshed it as a side effect of a 401 from a client-side API call.
 * A NAVIGATION never made such a call — the middleware read the expired access
 * cookie and answered with a redirect to /login, throwing away a perfectly valid
 * session (the user's "clicking any page logs me out").
 *
 * So: when the access token cannot be verified but a refresh cookie is present,
 * ask the API for a new pair, hand the browser the new cookies, and let the
 * page load. Only a *failed* refresh means the person is really signed out.
 *
 * The refresh is a same-origin call to /api/auth/refresh, which the Next rewrite
 * proxies to the API (so this needs no extra configuration and works the same
 * in dev, in the sandbox preview and behind a reverse proxy).
 *
 * IMPORTANT — only a real page navigation may do this. Refresh tokens rotate
 * single-use: the API revokes the whole token family if the same refresh token
 * is presented twice, which is what stops a stolen token from being replayed.
 * A client-side navigation (Next.js fetches the RSC payload for the next page)
 * fires that request and the page's own API calls nearly simultaneously, and
 * the app already has a mutex that refreshes exactly once on a 401. If the edge
 * ALSO refreshed on those requests, one of the two would present an
 * already-rotated token, the family would be revoked, and the user would be
 * thrown back to /login — the very symptom being fixed, only rarer.
 *
 * So the rule is one refresher per situation, never two:
 *   • page navigation (document request) → refreshed here, before the app boots,
 *     so the first paint is already authenticated; and
 *   • anything else (RSC navigation, prefetch) → left alone, so the app's own
 *     401 → refresh mutex is the only refresher and nothing can race.
 */
function isPageNavigation(request: NextRequest): boolean {
  // Modern browsers label every request; a real navigation is "document".
  const dest = request.headers.get('sec-fetch-dest');
  if (dest) return dest === 'document';
  // Older clients: anything that is not an RSC fetch and wants HTML is a page.
  if (request.headers.get('rsc')) return false;
  return (request.headers.get('accept') || '').includes('text/html');
}
async function refreshSession(request: NextRequest): Promise<NextResponse | null> {
  if (!request.cookies.get('flx_refresh')) return null;
  try {
    const res = await fetch(new URL('/api/auth/refresh', request.url), {
      method: 'POST',
      headers: { cookie: request.headers.get('cookie') || '' },
      redirect: 'manual',
      cache: 'no-store',
    });
    if (!res.ok) return null;
    // Prefer the structured accessor; fall back to splitting the raw header
    // (two cookies are sent in one header, separated by ", name=").
    const setCookies = typeof res.headers.getSetCookie === 'function'
      ? res.headers.getSetCookie()
      : (res.headers.get('set-cookie') || '').split(/,(?=\s*[A-Za-z0-9_\-]+=)/).filter(Boolean);
    if (!setCookies.length) return null;
    const pass = NextResponse.next();
    for (const cookie of setCookies) pass.headers.append('set-cookie', cookie);
    return pass;
  } catch {
    return null;   // API unreachable — fall through to the /login redirect
  }
}

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // ── PHASE R0: owner-console host gate ────────────────────────────────────
  // The FIRST rule in this function: ahead of the '/' redirect and ahead of the
  // '/platform* -> /platform/login' redirect further down. That redirect was the
  // leak - on ANY hostname it answered 307 Location: /platform/login, telling a
  // scanner on the public origin that an owner console exists. Measured BEFORE
  // (work/r0-evidence.sh before, probes E): /platform/dashboard, /platform/gyms
  // and /platform/audit-log all returned 307 on host r0-public.example, and
  // /platform/login returned 200 with the full 16,754-byte login page.
  //
  // The hostname comes from the Host header. X-Forwarded-Host is consulted only
  // when TRUST_PROXY_HOPS declares a proxy, and even then it must AGREE with Host,
  // so a forwarded header can never widen access (see lib/admin-hosts.ts).
  //
  // This is an isolation layer, NOT an authentication layer: the api enforces the
  // same rule independently from route metadata, nginx enforces it again, and the
  // console still requires a platform session once the host is allowed.
  // PHASE R1 / review item 2 - a NUL byte anywhere in the request target is refused
  // with a plain 400, for EVERY path, before any routing decision. Path-independence
  // is the point: measured BEFORE (work/r1-evidence/00c S1), `/platform%00` reached
  // directly at Next answered 307 -> /platform/login while `/definitely-not-a-route%00`
  // answered 404, and that difference alone tells a scanner the console exists. One
  // rule for all paths removes the signal instead of special-casing the console, and
  // it matches what nginx already does at the edge (400 for any path with a NUL).
  if (containsNulByte(pathname) || containsNulByte(request.nextUrl.search)) {
    return new NextResponse('Bad Request', { status: 400, headers: { 'content-type': 'text/plain; charset=utf-8' } });
  }

  const consoleFamilyOfRequest = consoleFamily(pathname);
  if (consoleFamilyOfRequest) {
    const verdict = adminHostVerdict(
      request.headers.get('host') ?? undefined,
      request.headers.get('x-forwarded-host') ?? undefined,
    );
    if (!verdict.allowed) {
      if (consoleFamilyOfRequest === 'api') {
        // PHASE R0.6 (owner decision, measured): a console path that next.config
        // proxies to the Nest api is passed through UNCHANGED - original URI,
        // original method - so the api's own ADMIN_HOSTS gate produces the refusal.
        //
        // Why not rewrite to a sentinel here: Nest's 404 echoes the path it
        // received, so the rewrite made every refusal say
        //   {"path":"/api/host-gate-not-found","message":"Cannot GET /api/host-gate-not-found"}
        // no matter which console path was probed. An attacker comparing that
        // constant with the path they asked for learns that something is being
        // hidden at /api/platform/* - the exact existence signal R0 forbids. It
        // cost 31 of the 42 probes through the real nginx edge; with this change
        // the api answers with a path-faithful 404 and all 42 are
        // indistinguishable (work/r0-evidence/nginx{,-variant}/identical.tsv).
        //
        // Passing through cannot open the console, because of how Next proxies
        // (measured with a target that echoes headers): Next REPLACES Host with the
        // proxy target and reports the client's own Host in X-Forwarded-Host, so a
        // client-supplied X-Forwarded-Host is overwritten and cannot be smuggled.
        // The api therefore sees a forwarded host that disagrees with Host and
        // refuses fail-closed, while a genuine console hostname agrees and proceeds.
        // In production nginx sends /api/platform/ straight to the api and this
        // branch is not used at all.
        //
        // Regression test: work/r0-evidence.sh probe web-proxy-platform-pub (fails
        // if Next ever stops forwarding X-Forwarded-Host) and
        // src/middleware.admin-host.spec.ts case 5.
        return NextResponse.next();
      }
      const notFound = request.nextUrl.clone();
      notFound.pathname = HOST_GATE_NOT_FOUND;
      notFound.search = '';
      return NextResponse.rewrite(notFound);
    }

    // PHASE R1.8 / owner decision D1 - the host IS an administrator hostname and
    // this is a console PAGE, so it gets the console's own response headers: a
    // per-request nonce, a CSP with no 'unsafe-inline', no-store, no-referrer and
    // noindex. The nonce is passed to the app in a REQUEST header (x-csp-nonce) so
    // Next can put it on the scripts it injects, and the policy itself is set on the
    // RESPONSE. Tenant pages never reach this branch, so their headers stay exactly
    // as they were - asserted by src/middleware.console-csp.spec.ts.
    if (consoleFamilyOfRequest === 'page') {
      // The no-session redirect this middleware has always done, kept INSIDE the
      // branch: an anonymous visitor to /platform/dashboard is sent to the login page
      // rather than being handed a console shell. It is a presence check only - PHASE
      // R1 moved validation to PlatformSessionGuard on the api, because a token signed
      // with JWT_PLATFORM_SECRET and backed by a revocable session row cannot be
      // verified here (and verifying it with the tenant secret is what made every
      // console call 401 before R1).
      if (pathname !== '/platform/login' && !request.cookies.get('flx_platform_token')?.value) {
        // The redirect is a console response too, so it carries the same header set:
        // a 307 without no-store or no-referrer would be the one console answer an
        // attacker could cache or leak a referer from. No nonce policy is added, since
        // a redirect has no document to protect.
        const redirect = NextResponse.redirect(new URL('/platform/login', request.url));
        for (const [name, value] of consoleResponseHeaders()) redirect.headers.set(name, value);
        return redirect;
      }
      const nonce = newCspNonce();
      const requestHeaders = new Headers(request.headers);
      requestHeaders.set('x-csp-nonce', nonce);
      const response = NextResponse.next({ request: { headers: requestHeaders } });
      response.headers.set('Content-Security-Policy', consoleContentSecurityPolicy(nonce));
      for (const [name, value] of consoleResponseHeaders()) response.headers.set(name, value);
      return response;
    }
  }

  if (pathname === '/') {
    const accessToken = request.cookies.get('flx_access');
    if (await verifyJwtPayload(accessToken?.value)) return NextResponse.redirect(new URL('/dashboard', request.url));
    return NextResponse.next();
  }
  if (pathname.startsWith('/platform') && pathname !== '/platform/login') {
    // PHASE R1 - this used to VERIFY flx_platform_token with the tenant secret and
    // redirect to the login page when it did not check out. After R1 the platform
    // token is signed with JWT_PLATFORM_SECRET and names a revocable server-side
    // session, so this verification could never succeed again: left alone it would
    // have redirected every signed-in owner back to the login page.
    //
    // It is replaced by a presence check, not removed silently. Authorisation for a
    // console page is decided where the authority lives - PlatformSessionGuard on the
    // api, which checks the signature, the audience, the session row, idle and
    // absolute expiry, revocation and the administrator's status - and PlatformGuard
    // in the shell asks /platform/auth/me on mount and renders the enrolment flow or
    // the login redirect from that answer. A stateless middleware JWT check is the
    // weaker of the two; keeping it would have been a second, less accurate source of
    // truth rather than defence in depth.
    const platformToken = request.cookies.get('flx_platform_token');
    if (!platformToken?.value) return NextResponse.redirect(new URL('/platform/login', request.url));
    return NextResponse.next();
  }
  if (exactPublicPaths.has(pathname) || publicPrefixes.some((prefix) => pathname.startsWith(prefix))) {
    return NextResponse.next();
  }
  if (pathname.startsWith('/portal')) {
    // ROUND 14 (security review, PHASE E): /portal/login is the portal's own
    // public entry — exempting it here is what keeps the gate from redirecting
    // /portal/login to itself in a loop (the page was unreachable).
    if (pathname === '/portal/login') return NextResponse.next();
    const memberToken = request.cookies.get('flx_member_access');
    if (!memberToken) return NextResponse.redirect(new URL('/portal/login', request.url));
    return NextResponse.next();
  }
  const accessToken = request.cookies.get('flx_access');
  const payload = await verifyJwtPayload(accessToken?.value);
  if (!payload) {
    if (isPageNavigation(request)) {
      // Round 12: a real navigation with a live refresh cookie continues the
      // session instead of being treated as a logout.
      const continued = await refreshSession(request);
      if (continued) return continued;
      return NextResponse.redirect(new URL('/login', request.url));
    }
    // Client-side navigation / prefetch: let the page load and let the app's
    // 401 → refresh mutex renew the session (only one refresher, no race).
    return NextResponse.next();
  }
  if (payload.role === 'OWNER' && payload.onboardingCompleted === false && !pathname.startsWith('/onboarding')) {
    return NextResponse.redirect(new URL('/onboarding', request.url));
  }
  // ROUND 13 (Phase 5): routes are driven by the same permission list as the
  // sidebar. A user without the route's permission is sent to /dashboard —
  // never to /login (their session is fine; the page is simply not theirs).
  // The claim comes from the access token; tokens minted before Phase 5 fall
  // back to the role defaults. The API's PermissionsGuard remains the
  // authority — this gate only keeps forbidden pages out of the browser.
  const required = requiredPermissionFor(pathname);
  if (required && payload.role !== 'SUPER_ADMIN') {
    const held = effectivePermissionsOf(payload.role, payload.permissions);
    if (!held.includes(required)) {
      return NextResponse.redirect(new URL('/dashboard', request.url));
    }
  }
  return NextResponse.next();
}
export const config = { matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'] };
