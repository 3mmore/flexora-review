/**
 * @jest-environment node
 */
/**
 * FLEXORA Gym OS - Web
 * (c) 2024 Ammar Allam. All rights reserved.
 */
/**
 * PHASE R0 - the owner-console host gate in Next middleware, proven by calling the
 * real exported `middleware()` with real NextRequest objects and asserting the
 * response an attacker's browser would receive.
 *
 * WHY THE ASSERTIONS LOOK AT x-middleware-rewrite
 * A middleware rewrite is not a client-visible redirect: Next performs the rewrite
 * internally and signals it with `x-middleware-rewrite`. So the assertions are
 *   - a refused console request must NOT be a redirect to /platform/login (that
 *     redirect is exactly what confirmed the console existed before PHASE R0), and
 *   - it must be a rewrite to a path that does not exist, of the SAME FAMILY as the
 *     request: a page path to /host-gate-not-found (Next renders its own not-found
 *     page) and an /api path handed on UNCHANGED (the Nest api answers with
 *     its own JSON 404, because an /api request answered with Next's HTML 404 would
 *     itself be a fingerprint).
 * The byte-level equivalence with a genuinely unknown route is measured live by
 * work/r0-evidence.sh (section H), not asserted here.
 */
/**
 * `jose` publishes ESM-only entry points that ts-jest will not transform, and the
 * middleware imports it for the TENANT session refresh - which is not what this
 * suite attacks. Mocking it keeps the real gate code under test while letting the
 * file load, and a rejection is the honest stand-in for "no valid session here".
 */
jest.mock('jose', () => ({ jwtVerify: jest.fn().mockRejectedValue(new Error('no token in this suite')) }));

import { NextRequest } from 'next/server';

import { middleware } from './middleware';

/** Next's ambient types mark env.NODE_ENV readonly; tests need to change it. */
const env = process.env as Record<string, string | undefined>;

const ADMIN_HOST = 'console.test';
const PUBLIC_HOST = 'app.test';

let savedAdminHosts: string | undefined;
let savedNodeEnv: string | undefined;
let savedHops: string | undefined;

function makeRequest(path: string, host: string, headers: Record<string, string> = {}): NextRequest {
  const req = new NextRequest(new URL(`http://${host}${path}`), {
    headers: { ...headers, host },
  });
  // undici does not always keep a `host` header from init; the real server request
  // always has one, and the gate reads it, so set it explicitly.
  req.headers.set('host', host);
  return req;
}

function rewriteTarget(res: Response): string | null {
  return res.headers.get('x-middleware-rewrite');
}

beforeAll(() => {
  savedAdminHosts = env.ADMIN_HOSTS;
  savedNodeEnv = env.NODE_ENV;
  savedHops = env.TRUST_PROXY_HOPS;
  env.NODE_ENV = 'test';
  env.ADMIN_HOSTS = ADMIN_HOST;
  delete env.TRUST_PROXY_HOPS;
});

afterAll(() => {
  if (savedAdminHosts === undefined) delete env.ADMIN_HOSTS;
  else env.ADMIN_HOSTS = savedAdminHosts;
  if (savedNodeEnv === undefined) delete env.NODE_ENV;
  else env.NODE_ENV = savedNodeEnv;
  if (savedHops === undefined) delete env.TRUST_PROXY_HOPS;
  else env.TRUST_PROXY_HOPS = savedHops;
});

describe('PHASE R0 - middleware host gate: console page paths', () => {
  const pagePaths = ['/platform', '/platform/login', '/platform/dashboard', '/platform/gyms', '/platform/audit-log'];

  it.each(pagePaths)('1. ATTACK: %s on a public hostname is refused, not redirected to the console login', async (path) => {
    const res = await middleware(makeRequest(path, PUBLIC_HOST, { 'sec-fetch-dest': 'document' }));
    expect(res.headers.get('location')).toBeNull();
    const target = rewriteTarget(res);
    expect(target).not.toBeNull();
    expect(new URL(target as string).pathname).toBe('/host-gate-not-found');
  });

  it('2. the refusal happens BEFORE the redirect that used to leak the console (no Location header at all)', async () => {
    // Before PHASE R0 this exact request answered 307 with Location: /platform/login
    // on ANY hostname - measured: work/r0-evidence.sh before, probe web-platform-dash-pub.
    const res = await middleware(makeRequest('/platform/dashboard', PUBLIC_HOST, { 'sec-fetch-dest': 'document' }));
    expect(res.status).not.toBe(307);
    expect(res.headers.get('location')).toBeNull();
  });

  it('3. ATTACK: a forged X-Forwarded-Host does not open the console', async () => {
    const res = await middleware(
      makeRequest('/platform/login', PUBLIC_HOST, { 'x-forwarded-host': ADMIN_HOST, 'sec-fetch-dest': 'document' }),
    );
    expect(rewriteTarget(res)).not.toBeNull();
  });

  it('4. a forwarded host that contradicts an allowed Host is refused (fail closed on ambiguity)', async () => {
    const res = await middleware(
      makeRequest('/platform/login', ADMIN_HOST, { 'x-forwarded-host': PUBLIC_HOST, 'sec-fetch-dest': 'document' }),
    );
    expect(rewriteTarget(res)).not.toBeNull();
  });

  it('5. on an admin hostname the console pages are untouched: login passes through, dashboard still redirects to login when there is no platform session', async () => {
    const login = await middleware(makeRequest('/platform/login', ADMIN_HOST, { 'sec-fetch-dest': 'document' }));
    expect(rewriteTarget(login)).toBeNull();

    const dashboard = await middleware(makeRequest('/platform/dashboard', ADMIN_HOST, { 'sec-fetch-dest': 'document' }));
    expect(rewriteTarget(dashboard)).toBeNull();
    expect(dashboard.headers.get('location')).toContain('/platform/login');
  });

  it('6. decorated spellings of a console path are refused too (no oracle through encoding or extra slashes)', async () => {
    for (const path of ['/%70latform/login', '//platform/login', '/PLATFORM/DASHBOARD', '/platform/../platform/gyms']) {
      const res = await middleware(makeRequest(path, PUBLIC_HOST, { 'sec-fetch-dest': 'document' }));
      expect(rewriteTarget(res)).not.toBeNull();
    }
  });

  it('7. an RSC/prefetch request for a console path is refused the same way a document request is', async () => {
    const res = await middleware(makeRequest('/platform/dashboard', PUBLIC_HOST, { rsc: '1' }));
    expect(res.headers.get('location')).toBeNull();
    expect(rewriteTarget(res)).not.toBeNull();
  });
});

describe('PHASE R0 - middleware host gate: proxied console API paths', () => {
  it('8. ATTACK: /api/platform/* on a public hostname is handed to the api gate UNCHANGED - no rewrite, no sentinel path', async () => {
    // PHASE R0.6 (owner decision, measured). Rewriting these to a sentinel made
    // Nest's 404 echo that constant instead of the path the attacker asked for,
    // which is itself the "something is hidden here" signal R0 forbids: it cost 31
    // of 42 probes through the real nginx edge. Passing the request through keeps
    // the original URI and method and lets the api's own ADMIN_HOSTS gate answer
    // with a path-faithful 404 (42/42 indistinguishable, measured).
    //
    // It cannot open the console: Next replaces Host with the proxy target and
    // reports the client's Host in X-Forwarded-Host (measured with a target that
    // echoes headers), and the api refuses when the two disagree - fail closed.
    // The live regression test is work/r0-evidence.sh probe web-proxy-platform-pub.
    for (const path of ['/api/platform/overview', '/api/platform/auth/login', '/api/platform/gyms']) {
      const res = await middleware(makeRequest(path, PUBLIC_HOST));
      expect(rewriteTarget(res)).toBeNull();
      expect(res.headers.get('location')).toBeNull();
      expect(res.headers.get('x-middleware-next')).toBe('1');
    }
  });

  it('8b. ATTACK: a spoofed X-Forwarded-Host does not turn that pass-through into access', async () => {
    // The middleware's own verdict still refuses the PAGE family on a spoof, and
    // for the API family the api sees Host=<proxy target> against a forwarded host
    // it cannot agree with. Either way nothing is rewritten to a console route.
    const page = await middleware(makeRequest('/platform/dashboard', PUBLIC_HOST, { 'x-forwarded-host': ADMIN_HOST }));
    expect(new URL(rewriteTarget(page) as string).pathname).toBe('/host-gate-not-found');
    const api = await middleware(makeRequest('/api/platform/overview', PUBLIC_HOST, { 'x-forwarded-host': ADMIN_HOST }));
    expect(rewriteTarget(api)).toBeNull();
    expect(api.headers.get('x-middleware-next')).toBe('1');
  });

  it('8c. ATTACK: doubled-slash console paths are still recognised, so no slash variant slips past', async () => {
    // nginx hands a URI containing "//" to the app unmerged so that it normalises
    // exactly like any other doubled-slash path (308), and the merged path is gated
    // again. Should Next ever route such a path itself, this gate must still fire.
    for (const path of ['//platform/login', '///platform/login', '/platform//login', '//api/platform/overview', '/api/platform//overview']) {
      const res = await middleware(makeRequest(path, PUBLIC_HOST));
      if (path.startsWith('/api') || path.startsWith('//api')) {
        expect(res.headers.get('x-middleware-next')).toBe('1');
      } else {
        expect(new URL(rewriteTarget(res) as string).pathname).toBe('/host-gate-not-found');
      }
    }
  });

  it('9. on an admin hostname the proxy is untouched (the request goes to the api as before)', async () => {
    const res = await middleware(makeRequest('/api/platform/overview', ADMIN_HOST));
    expect(rewriteTarget(res)).toBeNull();
    expect(res.headers.get('x-middleware-next')).toBe('1');
  });
});

describe('PHASE R0 - middleware host gate: negative controls (the tenant app must not change)', () => {
  it('10. tenant pages and tenant API paths on a public hostname are NOT gated', async () => {
    for (const path of ['/dashboard', '/members', '/login', '/api/members', '/api/auth/login', '/api/plans']) {
      const res = await middleware(makeRequest(path, PUBLIC_HOST, { 'sec-fetch-dest': 'document' }));
      expect(rewriteTarget(res)).toBeNull();
    }
  });

  it('11. a path that merely starts with the console prefix is not treated as the console', async () => {
    for (const path of ['/platformer', '/platform-x', '/api/platforms']) {
      const res = await middleware(makeRequest(path, PUBLIC_HOST, { 'sec-fetch-dest': 'document' }));
      expect(rewriteTarget(res)).toBeNull();
    }
  });

  it('12. the brand pre-paint script is a public asset: no redirect, no gate', async () => {
    const res = await middleware(makeRequest('/brand-prepaint.js', PUBLIC_HOST));
    expect(rewriteTarget(res)).toBeNull();
    expect(res.headers.get('location')).toBeNull();
    expect(res.headers.get('x-middleware-next')).toBe('1');
  });

  it('13. the existing tenant behaviour still holds: an unauthenticated document navigation is redirected to /login', async () => {
    const res = await middleware(makeRequest('/dashboard', PUBLIC_HOST, { 'sec-fetch-dest': 'document' }));
    expect(res.headers.get('location')).toContain('/login');
  });

  it('14. the root path still redirects a signed-in tenant user to /dashboard', async () => {
    // no cookie at all: the root path simply continues, exactly as before the gate
    const res = await middleware(makeRequest('/', PUBLIC_HOST, { 'sec-fetch-dest': 'document' }));
    expect(rewriteTarget(res)).toBeNull();
    expect(res.headers.get('x-middleware-next')).toBe('1');
  });
});

describe('PHASE R0 - middleware host gate: fail-closed configuration', () => {
  it('15. in production with ADMIN_HOSTS unset, even localhost is refused (the owner must set it)', async () => {
    env.NODE_ENV = 'production';
    delete env.ADMIN_HOSTS;
    const res = await middleware(makeRequest('/platform/login', 'localhost', { 'sec-fetch-dest': 'document' }));
    expect(rewriteTarget(res)).not.toBeNull();
    env.NODE_ENV = 'test';
    env.ADMIN_HOSTS = ADMIN_HOST;
  });

  it('16. a wildcard ADMIN_HOSTS never opens the console on a public hostname', async () => {
    env.ADMIN_HOSTS = '*';
    const res = await middleware(makeRequest('/platform/login', PUBLIC_HOST, { 'sec-fetch-dest': 'document' }));
    expect(rewriteTarget(res)).not.toBeNull();
    env.ADMIN_HOSTS = ADMIN_HOST;
  });

  it('17. outside production, an unset ADMIN_HOSTS means trial mode: localhost reaches the console', async () => {
    env.NODE_ENV = 'development';
    delete env.ADMIN_HOSTS;
    const res = await middleware(makeRequest('/platform/login', 'localhost', { 'sec-fetch-dest': 'document' }));
    expect(rewriteTarget(res)).toBeNull();
    env.NODE_ENV = 'test';
    env.ADMIN_HOSTS = ADMIN_HOST;
  });
});
