'use client';

import React, { useState } from 'react';
import { useBrand, ThemeName, THEME_LIBRARY } from '@/context/BrandContext';
import { Button } from '@/components/ui/Button';

export const BrandingSettings = () => {
  const { theme, setTheme, brand, setBrand } = useBrand();
  const [activeTab, setActiveTab] = useState<'logo' | 'theme' | 'white-label' | 'preview'>('logo');

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-display font-bold text-white">Branding & Identity</h1>
          <p className="text-silver-dim">Manage the visual identity of your Gym OS deployment.</p>
        </div>
      </div>

      <div className="flex gap-2 p-1 bg-obsidian border border-titanium rounded-xl w-fit">
        {(['logo', 'theme', 'white-label', 'preview'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === tab ? 'bg-primary text-white shadow-lg' : 'text-silver-dim hover:text-white'
            }`}
          >
            {tab.replace('-', ' ').toUpperCase()}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 glass-card p-8">
          {activeTab === 'logo' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-white mb-4">Logo Assets</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs text-silver-muted uppercase font-bold">Primary Logo</label>
                  <input 
                    type="file" 
                    className="w-full p-2 bg-obsidian border border-titanium rounded-lg text-xs text-silver-dim"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) setBrand({ logoUrl: URL.createObjectURL(file) });
                    }}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs text-silver-muted uppercase font-bold">Favicon</label>
                  <input 
                    type="file" 
                    className="w-full p-2 bg-obsidian border border-titanium rounded-lg text-xs text-silver-dim"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) setBrand({ faviconUrl: URL.createObjectURL(file) });
                    }}
                  />
                </div>
              </div>
              <div className="mt-8 p-4 border border-dashed border-titanium rounded-xl flex items-center justify-center bg-obsidian/50">
                <img src={brand.logoUrl || '/logo.png'} alt="Logo Preview" className="max-h-20 object-contain" />
              </div>
            </div>
          )}

          {activeTab === 'theme' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-white mb-4">Preset Themes</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {(Object.keys(THEME_LIBRARY) as ThemeName[]).map(t => (
                  <button
                    key={t}
                    onClick={() => setTheme(t)}
                    className={`p-4 rounded-xl border transition-all text-center ${
                      theme === t ? 'border-primary bg-primary/10' : 'border-titanium bg-obsidian'
                    }`}
                  >
                    <div className="w-full h-8 rounded-md mb-2" style={{ background: THEME_LIBRARY[t].primary }} />
                    <div className="text-xs font-medium capitalize text-silver">{t}</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'white-label' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-white mb-4">White Label Configuration</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs text-silver-muted uppercase font-bold">Company Name</label>
                  <input 
                    type="text" 
                    value={brand.companyName}
                    onChange={(e) => setBrand({ companyName: e.target.value })}
                    className="w-full p-3 bg-obsidian border border-titanium rounded-lg text-white focus:border-primary outline-none"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs text-silver-muted uppercase font-bold">System Name</label>
                  <input 
                    type="text" 
                    value={brand.systemName}
                    onChange={(e) => setBrand({ systemName: e.target.value })}
                    className="w-full p-3 bg-obsidian border border-titanium rounded-lg text-white focus:border-primary outline-none"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs text-silver-muted uppercase font-bold">Primary Color</label>
                  <div className="flex gap-2">
                    <input 
                      type="color" 
                      value={brand.primaryColor || THEME_LIBRARY[theme].primary}
                      onChange={(e) => setBrand({ primaryColor: e.target.value, useCustomBrand: true })}
                      className="w-12 h-12 bg-transparent border-none cursor-pointer"
                    />
                    <input 
                      type="text" 
                      value={brand.primaryColor || THEME_LIBRARY[theme].primary}
                      onChange={(e) => setBrand({ primaryColor: e.target.value, useCustomBrand: true })}
                      className="flex-1 p-3 bg-obsidian border border-titanium rounded-lg text-white text-xs"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs text-silver-muted uppercase font-bold">Accent Color</label>
                  <div className="flex gap-2">
                    <input 
                      type="color" 
                      value={brand.accentColor || THEME_LIBRARY[theme].primaryGlow}
                      onChange={(e) => setBrand({ accentColor: e.target.value, useCustomBrand: true })}
                      className="w-12 h-12 bg-transparent border-none cursor-pointer"
                    />
                    <input 
                      type="text" 
                      value={brand.accentColor || THEME_LIBRARY[theme].primaryGlow}
                      onChange={(e) => setBrand({ accentColor: e.target.value, useCustomBrand: true })}
                      className="flex-1 p-3 bg-obsidian border border-titanium rounded-lg text-white text-xs"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'preview' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-white mb-4">Brand Preview</h3>
              <div className="p-6 border border-titanium rounded-2xl bg-obsidian space-y-4">
                <div className="flex items-center gap-4">
                  <img src={brand.logoUrl || '/logo.png'} className="w-10 h-10 object-contain" alt="Logo" />
                  <div>
                    <div className="text-lg font-bold text-white">{brand.companyName}</div>
                    <div className="text-xs text-silver-dim">{brand.systemName}</div>
                  </div>
                </div>
                <Button className="w-full bg-primary text-white py-3 rounded-xl">Action Button</Button>
                <div className="grid grid-cols-3 gap-2">
                   <div className="h-12 rounded-lg bg-surface border border-titanium" />
                   <div className="h-12 rounded-lg bg-surface border border-titanium" />
                   <div className="h-12 rounded-lg bg-surface border border-titanium" />
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="space-y-6">
          <div className="glass-card p-6">
            <h4 className="text-white font-bold mb-4">Active Identity</h4>
            <div className="space-y-4">
              <div className="flex justify-between text-sm">
                <span className="text-silver-muted">Current Theme:</span>
                <span className="text-white capitalize">{theme}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-silver-muted">Brand Mode:</span>
                <span className="text-white">{brand.useCustomBrand ? 'Custom' : 'FLEXORA Default'}</span>
              </div>
              <Button 
                variant="ghost" 
                className="w-full mt-4"
                onClick={() => setBrand({ useCustomBrand: false, primaryColor: undefined, accentColor: undefined })}
              >
                Reset to Default
              </Button>
            </div>
          </div>
          
          <div className="glass-card p-6 bg-primary/10 border-primary/30">
            <h4 className="text-white font-bold mb-2">White Label Pro</h4>
            <p className="text-xs text-silver-dim mb-4">Deploy a fully branded version of the OS for your franchise partners.</p>
            <Button className="w-full bg-primary text-white text-xs py-2 rounded-lg">Upgrade to Enterprise</Button>
          </div>
        </div>
      </div>
    </div>
  );
};
