/**
 * FLEXORA Gym OS — Frontend Web (Server-Side)
 * © 2024 Ammar Allam. All rights reserved.
 */
import * as Sentry from '@sentry/nextjs';

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  enabled: process.env.NODE_ENV === 'production' && !!process.env.SENTRY_DSN,
  environment: process.env.NODE_ENV || 'development',
  release: process.env.APP_VERSION || 'unknown',
  tracesSampleRate: process.env.NODE_ENV === 'production' ? 1.0 : 0.0,
  // Capture server-side errors from API routes and getServerSideProps
  beforeSend: (event) => {
    if (event.user) {
      delete event.user.email;
      delete event.user.username;
    }
    return event;
  },
});