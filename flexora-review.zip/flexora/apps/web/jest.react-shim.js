// PHASE R4 - the web jest suite ran only .ts specs until now, so nothing ever needed React's
// runtime in jsdom. react-dom/server under jsdom reaches for globals Node provides but jsdom
// does not (TextEncoder/TextDecoder). Providing them here keeps the shim out of every spec and
// out of production code.
const { TextEncoder, TextDecoder } = require('node:util');
if (typeof globalThis.TextEncoder === 'undefined') globalThis.TextEncoder = TextEncoder;
if (typeof globalThis.TextDecoder === 'undefined') globalThis.TextDecoder = TextDecoder;
