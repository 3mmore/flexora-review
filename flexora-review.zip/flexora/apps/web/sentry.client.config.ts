/**
 * FLEXORA Gym OS — Frontend Web
 * © 2024 Ammar Allam. All rights reserved.
 */
import * as Sentry from '@sentry/nextjs';

Sentry.init({
  dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,
  // Only enable in production
  enabled: process.env.NODE_ENV === 'production' && !!process.env.NEXT_PUBLIC_SENTRY_DSN,
  environment: process.env.NODE_ENV || 'development',
  release: process.env.APP_VERSION || 'unknown',
  // Capture all errors in production (1.0 = 100%)
  tracesSampleRate: process.env.NODE_ENV === 'production' ? 1.0 : 0.0,
  // Disable beforeSend in dev (all events allowed to flow through normal Next.js error handling)
  beforeSend: (event) => {
    // Strip any PII from user context
    if (event.user) {
      delete event.user.email;
      delete event.user.username;
    }
    return event;
  },
});