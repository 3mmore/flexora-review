/**
 * FLEXORA Gym OS
 * © 2024 Ammar Allam. All rights reserved.
 */
import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // FLEXORA warm gold palette — all mapped to the single source of truth
        // CSS variables defined in globals.css. These are the SAME tokens used
        // by the BrandContext runtime theme system, so Tailwind utility classes
        // (bg-primary, text-textPrimary, etc.) always resolve to the active theme.
        primary: 'var(--cyan, #c5a059)',
        primaryDim: 'var(--cyan-dim, #4a3d21)',
        primaryGlow: 'var(--cyan-glow, rgba(197,160,89,0.15))',
        
        background: 'var(--bg-base, #141312)',
        surface: 'var(--bg-surface, #1d1b1a)',
        elevated: 'var(--bg-elevated, #1d1b1a)',
        overlay: 'var(--bg-overlay, #23201e)',
        
        borderColor: 'var(--border, rgba(75,70,67,0.4))',
        
        textPrimary: 'var(--silver, #e9e1dd)',
        textSecondary: 'var(--silver-dim, #97908c)',
        textMuted: 'var(--silver-muted, #4b4643)',
        
        success: 'var(--success, #00e5a0)',
        warning: 'var(--warning, #f5a623)',
        danger: 'var(--danger, #ff4d6a)',

        // Legacy aliases for backward compatibility
        violet: { DEFAULT: 'var(--cyan, #c5a059)', dim: 'var(--cyan-dim, #4a3d21)', glow: 'var(--cyan-glow, rgba(197,160,89,0.15))' },
        obsidian: 'var(--bg-base, #141312)',
        base: 'var(--bg-base, #141312)',
        titanium: 'var(--border, rgba(75,70,67,0.4))',
        silver: { DEFAULT: 'var(--silver, #e9e1dd)', dim: 'var(--silver-dim, #97908c)', muted: 'var(--silver-muted, #4b4643)' },
      },
      fontFamily: {
        display: ['Inter', 'SF Pro Display', 'system-ui', 'sans-serif'],
        body: ['Inter', 'system-ui', 'sans-serif'],
        arabic: ['Cairo', 'Tajawal', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
export default config;
