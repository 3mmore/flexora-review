# FLEXORA — Obsidian Enterprise Design System (MASTER v1.0)

> "We don't manage gyms. We run gym ecosystems."
> FLEXORA is a **Gym Operating System** — Apple × Tesla × Stripe × Palantir × Nike.

Single source of truth: the final `:root` block in `src/app/globals.css`
(section **"OBSIDIAN ENTERPRISE TOKENS"**) + `tailwind.config.ts`.
**Rule: components never hardcode color — use tokens only.** (Verified: 0 cyan/teal
literals remain in the codebase.)

---

## 1. Color

### Obsidian backgrounds (layered depth)
| Token | Value | Use |
|---|---|---|
| `--bg-base` | `#050507` | App background, theme-color, splash |
| `--bg-surface` | `#0A0A0C` | Primary panels |
| `--bg-elevated` | `#101015` | Cards, raised surfaces |
| `--bg-overlay` | `#16161D` | Modals, popovers |

### Royal Electric Violet — the ONLY identity accent (AI / highlight states)
| Token | Value | Use |
|---|---|---|
| `--accent` | `#6D5EF6` | Primary actions, active nav, AI states |
| `--accent-bright` | `#8B7DFF` | Hover / emphasis |
| `--accent-dim` | `#5648D6` | Gradient end, pressed |
| `--accent-soft` | `rgba(109,94,246,0.12)` | Tinted fills |
| `--accent-glow` | `rgba(109,94,246,0.22)` | AI glow (used sparingly) |

> **No cyan, no neon-blue dominance.** Violet marks *meaning* (AI, active, primary),
> never decoration.

### Titanium silver (neutral chrome + text)
| Token | Value |
|---|---|
| `--titanium` / `--text-secondary` | `#BFC5CC` |
| `--titanium-dim` / `--text-muted` | `#8E97A1` |
| `--titanium-muted` / `--text-faint` | `#5A626B` |
| `--text-primary` | `#F4F6F8` |

### Semantic states
`--success #2BD576` · `--warning #FFB020` · `--danger #FF4D5E` · `--info #6D5EF6`

### Borders (thin 1px metallic)
`--border rgba(191,197,204,.10)` · `--border-strong .18` · `--border-hover` (violet) · `--hairline rgba(255,255,255,.06)`

---

## 2. Obsidian Enterprise Glass

| Token | Value |
|---|---|
| `--glass-blur` | `20px` (range 18–24) |
| `--glass-blur-strong` | `24px` |
| `--glass-surface` | `rgba(16,16,21,0.66)` |
| `--glass-elevated` | `rgba(22,22,29,0.72)` |

`.card` = obsidian glass (`backdrop-filter: blur(20px)`, 1px border, deep shadow).
No bright fills.

---

## 3. Spacing — 8pt system
`--space-xs 4` · `sm 8` · `md 16` · `lg 24` · `xl 32` · `2xl 48` · `3xl 64`
Layout: **12-column desktop / 4-column mobile.**

## 4. Radii
`--radius-sm 10` · `md 14` · `lg 20` · `xl 28`

## 5. Elevation (deep shadows, no bright UI)
`--shadow-soft` · `--shadow-card` · `--shadow-medium` · `--shadow-float` ·
`--shadow-modal` · `--shadow-glow` (violet) · `--shadow-ai` (violet AI emphasis)

---

## 6. Typography — Inter, 8-step scale
| Token | Size / LH | Use |
|---|---|---|
| `--fs-display` | 36 / 44 | Hero metrics, command headers |
| `--fs-h1` | 28 / 36 | Page titles |
| `--fs-h2` | 22 / 30 | Section titles |
| `--fs-h3` | 18 / 26 | Card titles |
| `--fs-body` | 15 / 24 | Body |
| `--fs-sm` | 13 / 20 | Secondary |
| `--fs-xs` | 12 / 16 | Labels |
| `--fs-micro` | 11 / 14 | Eyebrows, meta (uppercase, tracked) |

Numbers/KPIs: tabular-nums. Headings: tight tracking.

---

## 7. Motion — luxury machine, no bounce (300–600ms)
| Token | Value |
|---|---|
| `--ease-premium` | `cubic-bezier(0.16, 1, 0.3, 1)` |
| `--ease-machine` | `cubic-bezier(0.4, 0, 0.2, 1)` |
| `--motion-micro` | 180ms |
| `--motion-hover` | 300ms |
| `--motion-state` | 360ms |
| `--motion-premium` | 420ms |
| `--motion-emphasis` | 560ms |
| `--motion-page` | 480ms |

No spring overshoot. Data counts up on load. AI states fade with a subtle violet aura.

---

## 8. Iconography
Custom stroke set (`components/brand/Icon.tsx`): 1.5px stroke, 24×24 grid,
rounded caps. Gym-specific glyphs (`dumbbell`, `qr-scan`, `bio`, `circuit`).

## 9. Logo (`components/brand/Logo.tsx`)
"F" = barbell structure + AI circuit traces + upward growth.
Materials palette: **violet gradient** (`#6D5EF6 → #5648D6`) + **titanium frame**
(`#BFC5CC`) on **obsidian** body (`#0A0A0C`).
Variants: `full` · `mark` (app icon) · `wordmark` (header) · `monogram` (stamp).

## 10. AI behavior (system engine, not chatbot)
AI surfaces as **inline micro-intelligence** (dropout risk, revenue-drop detection,
optimization suggestions, auto-insights) using `--shadow-ai` / `--accent-soft` —
not a chat bubble UI.

---

## 11. Governance
- Add new colors only as tokens here + `tailwind.config.ts`.
- Never write `#hex` / `rgba()` in `.tsx` `style=` or in component CSS rules.
- One accent (violet). One neutral family (titanium). One base (obsidian).
- PWA chrome (`manifest.webmanifest`, layout `themeColor`) = `#050507`.
