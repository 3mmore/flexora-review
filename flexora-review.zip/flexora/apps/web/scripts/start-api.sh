#!/usr/bin/env bash
# Start the Nest api for measurement runs. Lives in the workspace so a sandbox
# reset cannot delete it (that happened twice).
set -u
cd /home/user/work/flexora/apps/api || exit 1
set -a; . ./.env; set +a
export TZ=Africa/Cairo
# The owner-console host gate fails CLOSED when ADMIN_HOSTS is unset and
# NODE_ENV=production. A real deployment sets its console hostname here; this box
# has no DNS, so the product's own documented dev default is used
# (apps/web/src/lib/admin-hosts.ts ADMIN_HOSTS_DEV_DEFAULT).
export ADMIN_HOSTS='localhost,127.0.0.1'
exec node dist/src/main.js
