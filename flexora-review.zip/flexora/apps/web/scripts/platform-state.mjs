#!/usr/bin/env node
/**
 * PACK 2 / ITEM 1 — mint a real OWNER-CONSOLE session for the Arabic crawl.
 *
 * The platform console is behind TOTP enrolment + step-up, which is a security
 * control I am not going to weaken just to take screenshots. Instead this script
 * does exactly what a human operator does, in order:
 *
 *   1. POST /api/platform/auth/login            (email + password)
 *   2. POST /api/platform/auth/totp/enrol       (only if not enrolled yet — this
 *      is the same call the enrolment screen makes; it returns the secret that
 *      the QR code encodes)
 *   3. POST /api/platform/auth/totp/verify      (a code computed from that secret,
 *      RFC 6238, exactly as the authenticator app would)
 *   4. writes the resulting cookies as Playwright storage state
 *
 * Nothing is bypassed and no guard is disabled: a wrong code fails here just as
 * it would for a person. The secret is written to /tmp only.
 *
 * usage: node scripts/platform-state.mjs [--out=/tmp/platform-state.json]
 *        credentials from apps/api/.env (PLATFORM_ADMIN_EMAIL / SUPER_ADMIN_PASSWORD)
 */
import { createHmac } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const ENV = resolve(HERE, '../../api/.env');
const API = process.env.API_BASE || 'http://127.0.0.1:4000';
// Browser host for the cookie jar. The owner console refuses a hostname that
// disagrees with the one Next proxies to, so this is not cosmetic.
const HOST = process.env.MEASURE_HOST || 'localhost';

function env(name) {
  try {
    const line = readFileSync(ENV, 'utf8').split('\n').find((l) => l.startsWith(`${name}=`));
    return line ? line.slice(name.length + 1).replace(/^["']|["']$/g, '') : undefined;
  } catch {
    return undefined;
  }
}

/** RFC 6238 TOTP, SHA-1, 6 digits, 30 s — the parameters in the otpauth URL. */
function totp(secretB32, at = Date.now()) {
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = '';
  for (const ch of secretB32.replace(/=+$/, '').toUpperCase()) {
    const i = alphabet.indexOf(ch);
    if (i < 0) continue;
    bits += i.toString(2).padStart(5, '0');
  }
  const key = Buffer.from(bits.match(/.{8}/g).map((b) => parseInt(b, 2)));
  const counter = Buffer.alloc(8);
  counter.writeBigUInt64BE(BigInt(Math.floor(at / 1000 / 30)));
  const mac = createHmac('sha1', key).update(counter).digest();
  const off = mac[mac.length - 1] & 0xf;
  const code = ((mac.readUInt32BE(off) & 0x7fffffff) % 1_000_000).toString().padStart(6, '0');
  return code;
}

const JAR = new Map();
function remember(res) {
  for (const c of res.headers.getSetCookie?.() ?? []) {
    const [pair, ...attrs] = c.split(';');
    const eq = pair.indexOf('=');
    const name = pair.slice(0, eq).trim();
    const value = pair.slice(eq + 1).trim();
    const path = (attrs.find((a) => /^\s*path=/i.test(a)) || 'path=/').split('=')[1] || '/';
    const maxAge = (attrs.find((a) => /^\s*max-age=/i.test(a)) || '').split('=')[1];
    if (maxAge && Number(maxAge) <= 0) JAR.delete(name);
    else JAR.set(name, { name, value, path });
  }
}
function cookieHeader() {
  return [...JAR.values()].map((c) => `${c.name}=${c.value}`).join('; ');
}
async function call(path, body, extra = {}) {
  const res = await fetch(`${API}/api/platform${path}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Origin: `http://${HOST}:3000`,
      'X-CSRF-Token': JAR.get('flx_platform_csrf')?.value ?? '',
      Cookie: cookieHeader(),
      ...extra,
    },
    body: JSON.stringify(body ?? {}),
    redirect: 'manual',
  });
  remember(res);
  const text = await res.text();
  let json;
  try { json = JSON.parse(text); } catch { json = { raw: text.slice(0, 200) }; }
  return { status: res.status, json };
}

const out = (process.argv.find((a) => a.startsWith('--out=')) || '--out=/tmp/platform-state.json').slice(6);
const email = process.env.PLATFORM_ADMIN_EMAIL || env('PLATFORM_ADMIN_EMAIL') || 'admin@flexora.com';
const password = process.env.PLATFORM_ADMIN_PASSWORD || env('SUPER_ADMIN_PASSWORD');
// An EMPTY password is a legitimate (if alarming) value on this demo box: the
// seed hashes whatever SUPER_ADMIN_PASSWORD holds. Only a missing variable is an error.
if (password === undefined) {
  console.error('✗ no platform admin password (SUPER_ADMIN_PASSWORD in apps/api/.env)');
  process.exit(1);
}

const login = await call('/auth/login', { email, password });
if (login.status !== 200 && login.status !== 201) {
  console.error(`✗ login ${login.status} ${JSON.stringify(login.json).slice(0, 160)}`);
  process.exit(1);
}
let secret = null;
if (login.json.totpPending) {
  const enrol = await call('/auth/totp/enrol', {});
  if (enrol.status !== 200 && enrol.status !== 201) {
    // already enrolled: an operator-supplied secret is the only way in
    secret = process.env.PLATFORM_TOTP_SECRET || null;
    if (!secret) {
      console.error(`✗ enrol ${enrol.status} ${JSON.stringify(enrol.json).slice(0, 160)} — set PLATFORM_TOTP_SECRET`);
      process.exit(1);
    }
  } else {
    secret = enrol.json.secret;
    writeFileSync('/tmp/platform-totp-secret', secret);
  }
  const verify = await call('/auth/totp/verify', { code: totp(secret) });
  if (verify.status !== 200 && verify.status !== 201) {
    console.error(`✗ verify ${verify.status} ${JSON.stringify(verify.json).slice(0, 160)}`);
    process.exit(1);
  }
}

const cookies = [...JAR.values()].map((c) => ({
  name: c.name,
  value: c.value,
  domain: HOST,
  path: c.path,
  expires: -1,
  httpOnly: true,
  secure: false,
  sameSite: 'Lax',
}));
writeFileSync(out, JSON.stringify(cookies, null, 1));
console.log(`✓ platform session → ${out} (enrolment: ${secret ? 'done' : 'already enrolled'}, cookies: ${cookies.map((c) => c.name).join(', ')})`);
