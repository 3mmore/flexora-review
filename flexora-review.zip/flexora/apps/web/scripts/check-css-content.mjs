#!/usr/bin/env node
/**
 * The guard's blind spot, closed.
 *
 * A DOM crawl reads text nodes, attributes and input values. It cannot see text
 * that a stylesheet draws with `content: '…'`. Two English sentences were living
 * there — "Operational surface" above every page body and a whole "Next best
 * action: start with one clean record…" line inside empty states — and no amount
 * of crawling would have found them.
 *
 * This script walks every stylesheet in src/ and fails on any `content:` whose
 * value contains a Latin letter and is not empty. Arabic inside `content:` is
 * allowed (a decorative label is fine in the product language); English is not,
 * because the product ships Arabic by default and a stylesheet cannot follow the
 * user's language setting.
 *
 * Exit 1 on a finding, so it can be wired into `npm run check:arabic` and into CI.
 */

import { readFileSync, readdirSync, statSync } from 'fs';
import { join, relative } from 'path';

const ROOT = join(process.cwd(), 'src');
const ALLOWLIST = new Set([
  // Glyph-only content: quotation marks, arrows, bullets, dots, dashes.
  '\u2018', '\u2019', '\u201c', '\u201d', '\u2190', '\u2192', '\u2022', '\u00b7', '\u2013', '\u2014',
]);

function walk(dir) {
  const out = [];
  for (const name of readdirSync(dir)) {
    const full = join(dir, name);
    const st = statSync(full);
    if (st.isDirectory()) out.push(...walk(full));
    else if (/\.(css|scss)$/.test(name)) out.push(full);
  }
  return out;
}

const findings = [];
for (const file of walk(ROOT)) {
  const text = readFileSync(file, 'utf8');
  const lines = text.split('\n');
  lines.forEach((line, i) => {
    const m = line.match(/content:\s*(['"])(.*?)\1/);
    if (!m) return;
    const value = m[2];
    if (!value.trim()) return; // '' is a shape, not text
    if (ALLOWLIST.has(value.trim())) return; // a single glyph
    if (/[A-Za-z]/.test(value)) {
      findings.push({ file: relative(process.cwd(), file), line: i + 1, value });
    }
  });
}

if (findings.length) {
  console.error(`✗ ${findings.length} stylesheet string(s) would render Latin text the crawl cannot see:\n`);
  for (const f of findings) console.error(`  ${f.file}:${f.line}  content: "${f.value}"`);
  console.error('\nMove the string into the dictionary and render it as text, or delete it.');
  process.exit(1);
}
console.log('✓ no Latin text is generated from CSS');
