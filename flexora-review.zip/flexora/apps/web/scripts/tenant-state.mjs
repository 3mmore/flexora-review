#!/usr/bin/env node
/**
 * LOCAL-ONLY dev helper: produce the staff cookie jar for the browser guard.
 *
 * WHY THIS EXISTS
 *   `POST /api/auth/login` is throttled to FIVE attempts per FIFTEEN MINUTES —
 *   correct behaviour for a product, but it means a UI guard that logs in on
 *   every run can make at most five crawls a quarter of an hour and then gets
 *   429s that look like app bugs. So: sign one access token with the API's own
 *   secret (the same claims auth.service.ts signs, see `payload` there), prove it
 *   against /api/auth/me, and reuse the cookie. The guard still supports a real
 *   --email/--password login for end-to-end runs.
 *
 *   Refuses to run against anything but a localhost database, prints no secret,
 *   and is imported by nothing in the app.
 *
 * USAGE
 *   node scripts/tenant-state.mjs [--email=owner@demo.flexora.app] [--hours=2] \
 *        [--out=/tmp/tenant-state.json]
 */
import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHmac, randomBytes } from 'node:crypto';
import { dirname, resolve } from 'node:path';

const args = Object.fromEntries(
  process.argv.slice(2).map((a) => {
    const [k, ...v] = a.replace(/^--/, '').split('=');
    return [k, v.length ? v.join('=') : true];
  }),
);
const EMAIL = String(args.email || 'owner@demo.flexora.app');
const HOURS = Number(args.hours || 2);
const OUT = args.out ? resolve(String(args.out)) : '/tmp/tenant-state.json';
const API = String(args.api || 'http://127.0.0.1:4000').replace(/\/+$/, '');
// Browser host for the cookie jar. The owner console refuses a hostname that
// disagrees with the one Next proxies to, so this is not cosmetic.
const HOST = process.env.MEASURE_HOST || 'localhost';

const envFile = new URL('../../api/.env', import.meta.url);
const env = Object.fromEntries(
  readFileSync(envFile, 'utf8')
    .split('\n')
    .filter((l) => l && !l.startsWith('#') && l.includes('='))
    .map((l) => {
      const i = l.indexOf('=');
      return [l.slice(0, i).trim(), l.slice(i + 1).trim()];
    }),
);
const secret = env.JWT_ACCESS_SECRET;
if (!secret) {
  console.error('tenant-state: JWT_ACCESS_SECRET missing from apps/api/.env');
  process.exit(2);
}
const dbUrl = env.DATABASE_URL || env.DATABASE_URL_BASE || '';
if (dbUrl && !/@(127\.0\.0\.1|localhost)[:/]/.test(dbUrl)) {
  console.error('tenant-state: refusing — DATABASE_URL is not a localhost database');
  process.exit(2);
}

const psql = (sql) =>
  execFileSync('psql', ['-U', 'postgres', '-h', '127.0.0.1', '-d', 'flexora', '-Atc', sql], {
    // no default password in a shipped file: the operator supplies the local
    // database password through the environment (see .env.example)
    env: { ...process.env, PGPASSWORD: env.PGPASSWORD_OWNER || '' },
    encoding: 'utf8',
  }).trim();

const row = psql(
  `select u.id, coalesce(u."gymId",''), u.role, u.name, u.email,
          coalesce(u."branchId",''), case when u."onboardingCompleted" then '1' else '0' end
   from "User" u where u.email = '${EMAIL}' limit 1;`,
);
if (!row) {
  console.error(`tenant-state: no user ${EMAIL} in the database`);
  process.exit(2);
}
const [id, gymId, role, name, email, branchId, onboarded] = row.split('|');
if (!gymId) {
  console.error('tenant-state: that user is a platform admin, not a gym user');
  process.exit(2);
}

const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
const now = Math.floor(Date.now() / 1000);
const payload = {
  sub: id,
  jti: randomBytes(16).toString('hex'),
  iss: 'flexora-api',
  aud: 'flexora-staff',
  gymId,
  role,
  name,
  email,
  branchId: branchId || null,
  onboardingCompleted: onboarded === '1',
  // The middleware reads role defaults + this claim; the API re-computes from
  // the database on every call, so an empty claim cannot grant anything.
  permissions: [],
  iat: now,
  exp: now + Math.round(HOURS * 3600),
};
const signingInput = `${b64({ alg: 'HS256', typ: 'JWT' })}.${b64(payload)}`;
const token = `${signingInput}.${createHmac('sha256', secret).update(signingInput).digest('base64url')}`;

const probe = await fetch(`${API}/api/auth/me`, { headers: { Cookie: `flx_access=${token}` } });
if (!probe.ok) {
  console.error(`tenant-state: token rejected by /api/auth/me → ${probe.status} ${(await probe.text()).slice(0, 200)}`);
  process.exit(1);
}
const me = await probe.json().catch(() => ({}));
console.log(`staff session OK: ${me.name || name} · ${me.role || role} · gym ${gymId.slice(0, 8)}…`);

const jar = [
  { name: 'flx_access', value: token, domain: HOST, path: '/', httpOnly: true, secure: false, sameSite: 'Strict' },
];
mkdirSync(dirname(OUT), { recursive: true });
writeFileSync(OUT, JSON.stringify(jar, null, 2));
console.log(`staff cookies → ${OUT} (valid ${HOURS}h)`);
