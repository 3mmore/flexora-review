#!/usr/bin/env node
/**
 * PHASE O1.5 — fail a production web build when loopback addresses got baked in.
 *
 * WHY THIS EXISTS
 * ---------------
 * apps/web/next.config.mjs computes the /api/* rewrite DESTINATION at build time:
 *
 *   const API_PROXY_TARGET = (process.env.API_PROXY_TARGET || 'http://localhost:4000')
 *   rewrites: () => [{ source: '/api/:path*', destination: `${API_PROXY_TARGET}/api/:path*` }]
 *
 * That fallback is correct on a developer's machine and fatal in a container,
 * where nothing listens on localhost:4000 — every proxied API call fails, and
 * nothing at runtime reveals why. The same class of mistake applies to
 * NEXT_PUBLIC_* values, which Next inlines into the client bundles at build time
 * (a runtime `environment:` entry changes nothing). The build is the only place
 * either can be caught, so this check runs as part of `npm run build` — in the
 * image and on a host alike.
 *
 * WHAT IS SCANNED (and what is deliberately not)
 * ----------------------------------------------
 * Scanned: our own build output and the manifests that drive the running server
 *   .next/static/**                  client bundles (NEXT_PUBLIC_* land here)
 *   .next/server/**                  server bundles
 *   .next/*-manifest.json            routes/prerender/app-path/react-loadable
 *   .next/required-server-files.json the config the standalone server boots from
 *   .next/standalone/**              shipped server, EXCLUDING node_modules
 *
 * Skipped, each for a stated reason (printed in the report so coverage is
 * auditable rather than assumed):
 *   .next/cache/**        build cache; not shipped, and it mirrors source text
 *   **\/node_modules/**   third-party code contains 'localhost' in its own
 *                         defaults and docs; it is not our baked configuration
 *   *.map                 source maps echo original source text (including the
 *                         dev-only allowedDevOrigins list); not shipped by default
 *   binary files          detected by extension and by a NUL byte in the head
 *
 * One surgical exception inside a scanned file: `allowedDevOrigins` in
 * required-server-files.json is Next's DEV-server allow-list, echoed verbatim
 * from next.config.mjs. It never affects a production server, so its value is
 * removed before scanning and a NOTE is printed — a blind spot that is named,
 * not one that is hidden.
 *
 * EXIT CODES  0 clean · 1 findings · 2 usage/self-test failure
 * OPT-OUT     ALLOW_LOOPBACK_IN_BUILD=true — a loud warning, exit 0. It exists so
 *             a developer can still `npm run build` on a machine whose .env.local
 *             points the proxy at localhost:4000. It is never set in the image
 *             build, so a shipped artifact can never opt out by accident.
 */
import { readdirSync, readFileSync, statSync, existsSync, mkdtempSync, writeFileSync, mkdirSync, rmSync } from 'node:fs';
import { join, relative, dirname } from 'node:path';
import { tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';

// A FINDING is a loopback address in ENDPOINT position: either behind a scheme,
// or with a concrete port. Both are what a baked misconfiguration looks like
// (http://localhost:4000/api/:path*, ws://127.0.0.1:6379, "localhost:4000").
//
// Deliberately NOT a finding: a bare `localhost` / `127.0.0.1` word. Next's own
// framework chunks ship a hostname-classification regex and construct
// `http://localhost:${process.env.PORT}` for dev, and our own source compares
// `hostname === 'localhost'` to relax checks in development. Flagging those would
// make the check unusable, so they are counted and listed as INFORMATION instead
// -- visible, never silently dropped. The port must be a literal number, which is
// also why Next's `${process.env.PORT}` template does not trip the URL rule.
const RULES = [
  { id: 'LOOPBACK-URL', re: /\b(?:https?|wss?|redis|rediss|amqp):\/\/(?:[^\/@\s]+@)?(?:localhost|127\.0\.0\.1|\[::1\])(?::\d+)?(?=["'\/\s\\)\],}]|$)/gi, label: 'loopback URL' },
  { id: 'LOOPBACK-HOSTPORT', re: /\b(?:localhost|127\.0\.0\.1):\d{2,5}\b/gi, label: 'loopback host:port' },
];
const INFO_RULE = { id: 'LOOPBACK-WORD', re: /\b(?:localhost|127\.0\.0\.1|\[::1\])\b/gi };
const BINARY_EXT = new Set(['.png', '.jpg', '.jpeg', '.gif', '.ico', '.webp', '.avif', '.woff', '.woff2', '.ttf', '.otf', '.eot', '.mp4', '.webm', '.pdf', '.zip', '.gz', '.br', '.wasm', '.node']);
const MANIFEST_GLOB = /-(manifest)\.json$/;
const MAX_PER_FILE = 3;

function skipReason(relPath) {
  if (relPath.startsWith('cache/') || relPath.includes('/cache/')) return 'build cache (not shipped)';
  if (relPath.includes('node_modules/')) return 'third-party code (not our configuration)';
  if (relPath.endsWith('.map')) return 'source map (echoes source text, not shipped)';
  if (BINARY_EXT.has(relPath.slice(relPath.lastIndexOf('.')))) return 'binary file';
  return null;
}

function inScanScope(relPath) {
  if (relPath.startsWith('static/') || relPath.startsWith('server/') || relPath.startsWith('standalone/')) return true;
  if (!relPath.includes('/') && relPath.endsWith('.json') && MANIFEST_GLOB.test(relPath)) return true;
  if (relPath === 'required-server-files.json') return true;
  return false;
}

/** Count bare loopback words per file — reported as information, never as a finding. */
function countInfoWords(text) {
  let n = 0;
  INFO_RULE.re.lastIndex = 0;
  let m;
  while ((m = INFO_RULE.re.exec(text)) !== null) { n += 1; if (m.index === INFO_RULE.re.lastIndex) INFO_RULE.re.lastIndex += 1; }
  return n;
}

/**
 * Show the matched endpoint, minus any credentials.
 * A loopback address is not a secret and hiding its port would make the report
 * useless ("loc***" tells an operator nothing). What MUST NOT be echoed is a
 * password, so any userinfo in the matched URL is replaced wholesale (standing
 * constraint: never print secret values — names and rules only).
 */
function mask(line, idx, hitLen) {
  const before = line.slice(Math.max(0, idx - 30), idx);
  const hit = line.slice(idx, idx + hitLen);
  const after = line.slice(idx + hitLen, idx + hitLen + 25);
  // Scrub the whole assembled string: the password of a baked URL can sit in the
  // context BEFORE the match (…redis://:hunter2@localhost:6379…), so masking only
  // the matched span is not enough. Both a scheme-qualified userinfo and a bare
  // user:pass@ are removed. Over-masking (e.g. an email address in an artifact)
  // is acceptable; under-masking is not.
  const scrub = (t) => t
    .replace(/(\w+:\/\/)[^/@\s]*@/g, '$1***:***@')
    .replace(/(^|[^\w:/])([A-Za-z0-9._%+-]+:[^@\s"']*@)/g, '$1***:***@');
  return scrub(`${before}${hit}${after}`).trim();
}

export function scanDir(nextDir) {
  const findings = [];
  const notes = [];
  const info = new Map();
  const skipped = new Map();
  let scanned = 0;

  if (!existsSync(nextDir)) return { findings, notes, info, skipped, scanned, error: `no such directory: ${nextDir}` };

  const walk = (abs, rel) => {
    for (const entry of readdirSync(abs)) {
      const absPath = join(abs, entry);
      const relPath = rel ? `${rel}/${entry}` : entry;
      let st;
      try { st = statSync(absPath); } catch { continue; }
      if (st.isDirectory()) { walk(absPath, relPath); continue; }
      const why = skipReason(relPath);
      if (why) { skipped.set(why, (skipped.get(why) || 0) + 1); continue; }
      if (!inScanScope(relPath)) { skipped.set('outside the shipped/runtime scope', (skipped.get('outside the shipped/runtime scope') || 0) + 1); continue; }
      let text;
      try { text = readFileSync(absPath, 'utf8'); } catch { continue; }
      if (text.includes('\u0000')) { skipped.set('binary file (NUL byte)', (skipped.get('binary file (NUL byte)') || 0) + 1); continue; }
      const infoHits = countInfoWords(text);
      if (infoHits > 0) info.set(relPath, infoHits);
      scanned += 1;
      const lines = text.split('\n');
      let perFile = 0;
      for (let i = 0; i < lines.length && perFile < MAX_PER_FILE; i++) {
        const urlHitOnLine = RULES[0].re.test(lines[i]);
        RULES[0].re.lastIndex = 0;
        for (const rule of RULES) {
          // a host:port already reported as part of a full URL is not a second finding
          if (rule.id === 'LOOPBACK-HOSTPORT' && urlHitOnLine) continue;
          rule.re.lastIndex = 0;
          let m;
          while ((m = rule.re.exec(lines[i])) !== null) {
            findings.push({ file: relPath, line: i + 1, rule: rule.id, label: rule.label, context: mask(lines[i], m.index, m[0].length) });
            perFile += 1;
            if (perFile >= MAX_PER_FILE) break;
            if (m.index === rule.re.lastIndex) rule.re.lastIndex += 1;
          }
          if (perFile >= MAX_PER_FILE) break;
        }
      }
      // count remaining hits in this file without listing them
      let extra = 0;
      for (const line of lines) for (const rule of RULES) { rule.re.lastIndex = 0; let m; while ((m = rule.re.exec(line)) !== null) { extra += 1; if (m.index === rule.re.lastIndex) rule.re.lastIndex += 1; } }
      if (extra > perFile) findings.push({ file: relPath, line: 0, rule: 'LOOPBACK-MORE', label: `${extra - perFile} further hit(s) in this file`, context: '' });
    }
  };

  walk(nextDir, '');
  return { findings, notes, info, skipped, scanned };
}

function report(res, nextDir) {
  console.log(`web build loopback check — ${nextDir}`);
  console.log(`  files scanned: ${res.scanned}`);
  for (const [why, n] of [...res.skipped.entries()].sort()) console.log(`  skipped: ${n} file(s) — ${why}`);
  for (const n of res.notes) console.log(`  NOTE ${n}`);
  const infoTotal = [...(res.info || new Map()).values()].reduce((a, b) => a + b, 0);
  if (infoTotal > 0) {
    console.log(`  INFO ${infoTotal} bare loopback word(s) in ${res.info.size} file(s) — not findings (framework/dev-detection code); the highest counts:`);
    for (const [f, n] of [...res.info.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5)) console.log(`       ${n}\t${f}`);
  }
  if (res.error) { console.log(`  ERROR ${res.error}`); return 2; }
  if (res.findings.length === 0) {
    console.log('  PASS — no loopback address is baked into the production build output.');
    return 0;
  }
  console.log(`  ${res.findings.length} finding(s):`);
  for (const f of res.findings) {
    console.log(`    ${f.file}:${f.line} ${f.rule} ${f.label}${f.context ? ` → …${f.context}…` : ''}`);
  }
  console.log('  FAIL — a production web build must not contain loopback addresses.');
  console.log('  Fix: pass the value as a BUILD arg (API_PROXY_TARGET / NEXT_PUBLIC_*) — see');
  console.log('       docker-compose.yml web.build.args and apps/web/Dockerfile.');
  return 1;
}

// ---------------------------------------------------------------- self-test ---
function selfTest() {
  const root = mkdtempSync(join(tmpdir(), 'o15-selftest-'));
  let pass = 0; let fail = 0;
  const check = (name, ok) => { if (ok) { pass += 1; console.log(`    PASS  ${name}`); } else { fail += 1; console.log(`    FAIL  ${name}`); } };

  const write = (tree, rel, content) => {
    const p = join(tree, rel); mkdirSync(dirname(p), { recursive: true }); writeFileSync(p, content);
  };

  // CASE 1 — must FAIL: the exact defect this check exists for
  const bad = join(root, 'bad', '.next');
  write(bad, 'routes-manifest.json', JSON.stringify({ rewrites: [{ source: '/api/:path*', destination: 'http://localhost:4000/api/:path*' }] }));
  let r = scanDir(bad);
  check('a baked http://localhost:4000 rewrite destination is caught', r.findings.some((f) => f.rule === 'LOOPBACK-URL' && f.file === 'routes-manifest.json'));
  check('...and it is reported as a loopback URL, with the port visible in the context', r.findings.some((f) => f.rule === 'LOOPBACK-URL' && /4000/.test(f.context)));
  check('the finding names the file and line', r.findings[0].file === 'routes-manifest.json' && r.findings[0].line === 1);
  check('the reported context shows the endpoint and its port', /localhost:4000/.test(r.findings[0].context));

  // CASE 1b — a baked URL that carries credentials must never echo the password
  const badCred = join(root, 'badcred', '.next');
  write(badCred, 'required-server-files.json', JSON.stringify({ config: { env: { REDIS_URL: 'redis://:Sup3rSecretPassw0rd@localhost:6379' } } }));
  r = scanDir(badCred);
  check('a loopback URL with an embedded password is still a finding', r.findings.length > 0);
  check('...and the password is masked out of the report', r.findings.every((f) => !f.context.includes('Sup3rSecretPassw0rd')) && r.findings.some((f) => f.context.includes('***:***@')));

  // CASE 2 — must FAIL: 127.0.0.1 inside a client bundle (baked NEXT_PUBLIC_*)
  const bad2 = join(root, 'bad2', '.next');
  write(bad2, 'static/chunks/app/page-abc123.js', 'self.__next_f.push([1,"api base http://127.0.0.1:4000/api"])');
  r = scanDir(bad2);
  check('a 127.0.0.1 URL inlined into a client chunk is caught', r.findings.some((f) => f.rule === 'LOOPBACK-URL' && f.file.startsWith('static/chunks/')));

  // CASE 2b — the password precedes the match: context scrubbing must still hide it
  const badPre = join(root, 'badpre', '.next');
  write(badPre, 'required-server-files.json', JSON.stringify({ config: { env: { PROXY: 'user:Sup3rSecretPassw0rd@localhost:4000' } } }));
  r = scanDir(badPre);
  check('a bare user:pass@localhost:port is a finding', r.findings.length > 0);
  check('...and a password preceding the match is scrubbed from the context', r.findings.every((f) => !f.context.includes('Sup3rSecretPassw0rd')));
  check('...no finding anywhere in the run echoes that password', JSON.stringify(r.findings).indexOf('Sup3rSecretPassw0rd') === -1);

  // CASE 3 — must PASS: the same tree with a correct production value
  const good = join(root, 'good', '.next');
  write(good, 'routes-manifest.json', JSON.stringify({ rewrites: [{ source: '/api/:path*', destination: 'http://api:4000/api/:path*' }] }));
  write(good, 'static/chunks/app/page-abc123.js', 'self.__next_f.push([1,"api base https://app.example.com/api"])');
  write(good, 'server/app/page.js', 'module.exports={};');
  r = scanDir(good);
  check('a production build with http://api:4000 and a public origin passes', r.findings.length === 0);
  check('it actually scanned the files (not vacuously green)', r.scanned >= 3);

  // CASE 3b — must FAIL: a bare host:port with no scheme (config-style baking)
  const bad3 = join(root, 'bad3', '.next');
  write(bad3, 'required-server-files.json', JSON.stringify({ config: { env: { API_PROXY_TARGET: 'localhost:4000' } }, files: [] }));
  r = scanDir(bad3);
  check('a bare "localhost:4000" in the server config is caught', r.findings.some((f) => f.rule === 'LOOPBACK-HOSTPORT'));

  // CASE 3c — must PASS: framework code and dev-detection comparisons are NOT findings
  const fw = join(root, 'fw', '.next');
  write(fw, 'server/chunks/ssr/[root-of-the-server]__abc._.js',
    'const re=/^(127\\.0\\.0\\.1|localhost)$/;if(isDev(c.hostname)&&(c.hostname="localhost"),c);const u=new URL(`http://localhost:${process.env.PORT||3000}`);')
  ;
  write(fw, 'static/chunks/31x6ft.js', 'const hosts=["testing.stripe.com","flexora.app","localhost"];if("localhost"===new URL(a).hostname)return a;');
  write(fw, 'required-server-files.json', JSON.stringify({ config: { allowedDevOrigins: ['*.e2b.app', 'localhost', '127.0.0.1'] } }));
  r = scanDir(fw);
  check('Next framework hostname code is not flagged', r.findings.length === 0);
  check('...but its bare loopback words are still reported as information', [...r.info.values()].reduce((a, b) => a + b, 0) >= 4);

  // CASE 4 — skipped areas must not create false positives
  const noisy = join(root, 'noisy', '.next');
  write(noisy, 'cache/webpack/0.pack', 'localhost localhost localhost');
  write(noisy, 'standalone/node_modules/some-pkg/index.js', "const host = 'localhost';");
  write(noisy, 'static/chunks/app/page-abc123.js', '//# sourceMappingURL=page-abc123.js.map');
  write(noisy, 'server/app/page.js.map', '{"sources":["localhost"]}');
  write(noisy, 'required-server-files.json', JSON.stringify({ config: { allowedDevOrigins: ['*.e2b.app', 'localhost', '127.0.0.1'] }, files: [] }));
  write(noisy, 'routes-manifest.json', JSON.stringify({ rewrites: { beforeFiles: [], afterFiles: [{ source: '/api/:path*', destination: 'http://api:4000/api/:path*' }], fallback: [] } }));
  r = scanDir(noisy);
  check('build cache, node_modules and source maps are skipped, not scanned', r.findings.length === 0);
  check('a correct http://api:4000 rewrite in the same tree passes', r.scanned >= 1);
  check('the skip reasons are counted for auditability', r.skipped.size >= 3);

  // CASE 5 — usage errors
  r = scanDir(join(root, 'does-not-exist'));
  check('a missing .next directory is an error, not a silent pass', !!r.error);

  rmSync(root, { recursive: true, force: true });
  const total = pass + fail;
  console.log(`  SELF-TEST: ${pass}/${total} cases behaved correctly`);
  return fail === 0 ? 0 : 2;
}

// --------------------------------------------------------------------- cli ---
const argv = process.argv.slice(2);
if (argv.includes('--help') || argv.includes('-h')) {
  console.log('usage: node scripts/check-no-loopback.mjs [--next-dir=DIR] [--self-test] [--quiet]');
  process.exit(0);
}
if (argv.includes('--self-test')) process.exit(selfTest());

const here = dirname(fileURLToPath(import.meta.url));
const dirArg = argv.find((a) => a.startsWith('--next-dir='));
const nextDir = dirArg ? dirArg.slice('--next-dir='.length) : join(here, '..', '.next');
const quiet = argv.includes('--quiet');

if (process.env.ALLOW_LOOPBACK_IN_BUILD === 'true') {
  console.log('web build loopback check — SKIPPED');
  console.log('  WARN ALLOW_LOOPBACK_IN_BUILD=true: loopback addresses in this build output are');
  console.log('       being accepted on purpose. Never set this for an image you intend to ship.');
  process.exit(0);
}

const res = scanDir(nextDir);
if (quiet && res.findings.length === 0 && !res.error) { console.log('web build loopback check: PASS'); process.exit(0); }
process.exit(report(res, nextDir));
