#!/usr/bin/env node
/**
 * FLEXORA — Arabic-UI guard + mobile measurement harness.
 *
 * WHAT THIS IS
 *   A real-browser crawl of every route at 375x812 that:
 *     1. extracts every piece of text a user can READ (visible text, placeholders,
 *        aria-labels, title attributes, document.title),
 *     2. FAILS (exit 1) when a Latin word appears that is not in the documented
 *        allowlist,
 *     3. FAILS when a raw i18n key is rendered (e.g. "platform_alerts_label"),
 *     4. measures the mobile problems the owner reported: horizontal overflow,
 *        tap targets under 44px, rendered tables on a phone, and counts the taps
 *        to the four most common tasks.
 *
 * WHY IT HAS ZERO DEPENDENCIES
 *   Puppeteer/Playwright would add a dependency (and a browser download) to a
 *   product that ships to gyms. Chromium is driven directly over the DevTools
 *   protocol with Node 22's built-in `WebSocket`, so the guard needs nothing but
 *   a system browser. If no browser is found it exits with code 2 and says so —
 *   a missing browser must never look like a pass.
 *
 * USAGE
 *   node scripts/check-arabic-ui.mjs --base=http://127.0.0.1:3000 \
 *        [--out=docs/screens/after] [--json=arabic-ui.json] [--screens=a,b]
 *        [--max-routes=10] [--no-login]
 *
 * EXIT CODES  0 clean · 1 violations · 2 no browser / harness error
 */
import { spawn } from 'node:child_process';
import { mkdirSync, writeFileSync, readFileSync, existsSync } from 'node:fs';
import { dirname, resolve } from 'node:path';

// ── args ────────────────────────────────────────────────────────────────────
const args = Object.fromEntries(
  process.argv.slice(2).map((a) => {
    const [k, ...v] = a.replace(/^--/, '').split('=');
    return [k, v.length ? v.join('=') : true];
  }),
);
// Every knob has an ENV fallback so `npm run check:arabic:ui` can carry no
// arguments at all — a loopback URL baked into package.json ends up inside the
// production build (found by scripts/check-web-loopback.sh during the isolated
// build gate), and absolute sandbox paths are meaningless to anyone else.
const BASE = String(args.base || process.env.ARABIC_UI_BASE || 'http://127.0.0.1:3000').replace(/\/+$/, '');
const OUT = args.out ? resolve(String(args.out)) : null;
const JSON_OUT = args.json ? resolve(String(args.json)) : null;
const ONLY = args.screens ? String(args.screens).split(',').filter(Boolean) : null;
const MAX_ROUTES = args['max-routes'] ? Number(args['max-routes']) : Infinity;
const STATE = args.state
  ? resolve(String(args.state))
  : process.env.ARABIC_UI_STATE
    ? resolve(String(process.env.ARABIC_UI_STATE))
    : null;
// ARABIC_UI_NO_LOGIN mirrors the --no-login flag, for the same reason every other
// knob has an env fallback: the npm script cannot carry arguments (they end up
// inside the Next standalone build, where scripts/check-web-loopback.sh finds a
// baked-in loopback URL). Use it when a saved session state is supplied.
const SKIP_LOGIN = Boolean(args['no-login']) || /^(1|true|yes)$/i.test(process.env.ARABIC_UI_NO_LOGIN || '');
const SAVE_STATE = args['save-state'] ? resolve(String(args['save-state'])) : null;
// Credentials for the tenant app. Without them every app route redirects to
// /login and the guard would "pass" by measuring the login page 40 times, so a
// gated route is an ERROR (exit 2), never a pass. --allow-gated lists the few
// pages that legitimately need a credential we do not hold (platform TOTP).
const EMAIL = args.email || process.env.ARABIC_UI_EMAIL || '';
const PASSWORD = args.password || process.env.ARABIC_UI_PASSWORD || '';
const USER_DATA_MODE = String(args['user-data'] || process.env.ARABIC_UI_USER_DATA || ''); // 'auto' = read the tenant's own names
const ALLOW_GATED = new Set(
  String(args['allow-gated'] || process.env.ARABIC_UI_ALLOW_GATED || '')
    .split(',').map((s) => s.trim()).filter(Boolean),
);

// ── the allowlist ───────────────────────────────────────────────────────────
// Every entry needs a reason. Rules:
//   * the brand logotype is an image/wordmark, not a word to translate;
//   * whatever the USER typed is their data;
//   * technical identifiers that are not words (codes, extensions, IDs).
const ALLOWLIST_FILE = new URL('./arabic-allowlist.json', import.meta.url);
const allow = existsSync(ALLOWLIST_FILE)
  ? JSON.parse(readFileSync(ALLOWLIST_FILE, 'utf8'))
  : { words: [], patterns: [] };

/**
 * Remove the customer's own values from a rendered string before judging it.
 *
 * Token-level, not substring-level: a 4-letter gym slug like "demo" occurs INSIDE
 * "owner@demo.flexora.app", so replacing substrings shreds the very token we then
 * fail on (measured: it turned an allowed e-mail into "owner@ .flexora.app"). A
 * token is dropped when it EQUALS a collected value, or when it CONTAINS a
 * collected value long enough to be unambiguous (>= 8 chars, e.g. a full address).
 */
function stripUserData(text) {
  // Bidi and zero-width control characters ride along with RTL text ("‏demo"),
  // so they are removed before any comparison.
  const clean = String(text).replace(/[\u200B-\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g, '');
  if (!USER_DATA.length) return clean;
  let out = clean;
  // Pass 1 — unambiguous values are removed as substrings, longest first. That is
  // (a) anything 8+ characters (full names, addresses, e-mails) and (b) anything
  // containing a SPACE, whatever its length: a multi-word value is the tenant's
  // own phrase and can be EMBEDDED inside product Arabic, which the whole-token
  // pass below cannot see. Measured case: the /ai heuristic renders
  // «باقة 1 Month شغالة كويس — …» from the gym's own plan name "1 Month" (7
  // characters), and the whole-token pass left the word "Month" looking like
  // product Latin. Only strings the tenant's own API returned are stripped, so
  // this cannot excuse product text.
  for (const v of USER_DATA) {
    if ((v.length >= 8 || /\s/.test(v.trim())) && out.includes(v)) out = out.split(v).join(' ');
  }
  // Pass 2 — short values ("Maadi", "VIP", "demo") are removed only as WHOLE
  // tokens. Substring removal of a 4-letter slug would shred "owner@demo.flexora.app"
  // into "owner@ .flexora.app" and then fail on the pieces.
  return out
    .split(/(\s+)/)
    .map((chunk) => {
      if (!chunk.trim()) return chunk;
      const lower = chunk.toLowerCase();
      return USER_DATA.some((u) => u.toLowerCase() === lower) ? ' ' : chunk;
    })
    .join('');
}

/**
 * The customer's own values, collected once per run by --user-data=auto and read
 * by stripUserData. Empty means nothing to strip (and, with --user-data=auto, an
 * error: grading every screen clean for the wrong reason).
 */
let USER_DATA = [];
const USER_DATA_REQUIRED = USER_DATA_MODE === 'auto';

/**
 * Remove URLs and bare domain names before judging a string. A link printed next
 * to a webhook field ("https://yourdomain.com/api/…") is the operator's own
 * endpoint, not English prose. Without this the tokeniser splits "https" off the
 * scheme and the URL pattern can never match the token it was written for.
 */
function stripUrls(text) {
  // CSS custom properties and colour functions are values, not words.
  text = String(text)
    .replace(/var\(--[a-z0-9-]+\)/gi, ' ')
    .replace(/rgba?\([^)]*\)/gi, ' ')
    .replace(/--[a-z0-9-]+/gi, ' ')
    // A {placeholder} is part of a template an operator copies, never prose.
    .replace(/\{[^}]*\}/g, ' ');
  return text
    .replace(/\b(?:https?|mailto):\/\/\S+/gi, ' ')
    .replace(/\b(?:https?|mailto):\S*/gi, ' ')
    .replace(/\b(?:[a-z0-9-]+\.)+(?:com|org|net|io|app|dev|example|local)(?::\d+)?(?:\/\S*)?/gi, ' ');
}

/**
 * One place that decides whether a rendered string is judged at all.
 *
 * Returns the text to judge, or null when the string is an IDENTIFIER rather than
 * copy: a value the operator must copy verbatim (a webhook token with a
 * {placeholder}, a CSS custom property). Prose never contains braces, and an
 * identifier contains no Arabic, so both conditions are required.
 */
function scrubbable(raw) {
  const text = stripUserData(raw);
  const looksLikeIdentifier = /[{}]/.test(text) && !/[\u0600-\u06FF]/.test(text);
  return looksLikeIdentifier ? null : text;
}

function latinViolations(sample, where, route = null) {
  const found = [];
  // Identifiers that are allowed on ONE route only (a developer reference page
  // that must print the exact string a developer types). Matched as whole tokens.
  const routeIds = (allow.routeIdentifiers && route && allow.routeIdentifiers[route]) || [];
  // A "word" starts with a Latin letter and may contain digits/apostrophes.
  // A single stray letter is ignored (measurements, "x" in a formula).
  const words = stripUrls(sample).match(/[A-Za-z][A-Za-z0-9'’._-]{1,}/g) || [];
  for (const w of words) {
    const bare = w.replace(/[.,)'’]+$/, '');
    if (bare.length < 2) continue;
    if (allow.words.some((a) => a.toLowerCase() === bare.toLowerCase())) continue;
    if (allow.patterns.some((p) => new RegExp(p).test(bare))) continue;
    if (routeIds.some((id) => id.toLowerCase() === bare.toLowerCase())) continue;
    found.push({ text: bare, where });
  }
  return found;
}

// A rendered i18n key looks like snake_case with at least one underscore and no
// spaces — e.g. "platform_alerts_label". Those must never reach a screen.
function keyLeaks(sample, where) {
  const hits = [];
  const re = /\b[a-z][a-z0-9]*(?:_[a-z0-9]+){1,6}\b/g;
  for (const m of sample.match(re) || []) {
    // allowlist documented identifier-ish strings (file names, class names)
    if (allow.patterns.some((p) => new RegExp(p).test(m))) continue;
    hits.push({ text: m, where });
  }
  return hits;
}

// ── routes ──────────────────────────────────────────────────────────────────
// Every page that exists. Auth-gated ones are visited while logged in; a redirect
// to /login is recorded as "gated" rather than as a failure.
//
// A third element is an optional TAB: a substring of a button's visible text.
// It exists because a screen that lives behind a tab (the team monthly money
// matrix) is still a screen a receptionist reads, and a crawl that only loads
// the parent route would never see it.
const ROUTES = [
  // public
  ['/', 'public-landing'], ['/landing', 'public-landing2'], ['/login', 'public-login'], ['/register', 'public-register'],
  ['/onboarding', 'public-onboarding'], ['/support', 'public-support'],
  // tenant app
  ['/dashboard', 'app'], ['/members', 'app'], ['/attendance', 'app'], ['/checkin', 'app'], ['/checkin/kiosk', 'app'],
  ['/biometric', 'app'], ['/invitations', 'app'], ['/leads', 'app'], ['/crm', 'app'], ['/campaigns', 'app'],
  ['/contracts', 'app'], ['/classes', 'app'], ['/coach', 'app'], ['/users', 'app'], ['/transfers', 'app'],
  ['/inventory', 'app'], ['/pos', 'app'], ['/sales', 'app'], ['/staff-attendance', 'app'], ['/reports', 'app'],
  ['/accounting', 'app'], ['/expenses', 'app'], ['/billing', 'app'], ['/license', 'app'], ['/ai', 'app'],
  ['/ai-advanced', 'app'], ['/white-label', 'app'], ['/marketplace', 'app'], ['/backups', 'app'],
  ['/settings', 'app'], ['/settings/notifications', 'app'], ['/wa-bot', 'app'], ['/notifications', 'app'],
  ['/team/performance', 'app'],
  // the same route, second tab: per-employee × per-month money matrix
  ['/team/performance', 'app-tab-monthly', 'آخر ٦ / ١٢ شهرًا'],
  ['/plans', 'app'], ['/products', 'app'], ['/branches', 'app'],
  ['/members/import', 'app'], ['/offline', 'app'], ['/design-system', 'app'], ['/enterprise', 'app'],
  // member portal
  ['/portal/login', 'portal'], ['/portal/dashboard', 'portal'], ['/portal/attendance', 'portal'],
  ['/portal/bookings', 'portal'], ['/portal/classes', 'portal'], ['/portal/financial', 'portal'],
  ['/portal/member-card', 'portal'], ['/portal/notifications', 'portal'], ['/portal/profile', 'portal'],
  ['/portal/renew', 'portal'],
  // PACK 2 · ITEM 5 — the self check-in surfaces earn their own routes here so
  // the guard fails the build if either one starts painting a Latin word.
  ['/portal/checkin', 'portal-self-checkin'],
  ['/portal/checkin?t=not-a-real-token', 'portal-self-checkin-bad-token'],
  // error pages
  ['/this-route-does-not-exist-ar-guard', 'error-404'],
  // platform console — every page under app/(platform)/platform/. The console is
  // a separate product surface with its own session, so it is measured with its
  // own cookie jar (/tmp/platform-state.json) and browsed on `localhost`, the
  // hostname the api's ADMIN_HOSTS gate agrees with when Next proxies to it.
  ['/platform/login', 'platform'], ['/platform/dashboard', 'platform'], ['/platform/gyms', 'platform'],
  ['/platform/subscriptions', 'platform'], ['/platform/audit-log', 'platform'], ['/platform/flags', 'platform'],
  ['/platform/security', 'platform'], ['/platform/health', 'platform'], ['/platform/revenue', 'platform'],
  ['/platform/alerts', 'platform'], ['/platform/admins', 'platform'],
];

// ── chromium ────────────────────────────────────────────────────────────────
function findChrome() {
  const candidates = [
    process.env.CHROMIUM_BIN,
    '/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/google-chrome',
    '/usr/bin/google-chrome-stable', '/snap/bin/chromium',
  ].filter(Boolean);
  for (const c of candidates) if (existsSync(c)) return c;
  return null;
}

const chrome = findChrome();
if (!chrome) {
  console.error('check-arabic-ui: no Chromium/Chrome found (set CHROMIUM_BIN). REFUSING to report success without a browser.');
  process.exit(2);
}

const PORT = 9222 + (process.pid % 200);
const chromeProc = spawn(chrome, [
  '--headless=new', '--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage',
  '--hide-scrollbars', '--force-device-scale-factor=1',
  // Process-model flags are deliberately NOT used here. --renderer-process-limit=1
  // and --no-zygote were tried and measured on this 1.9 GB box: they pushed a
  // 69-route crawl from 2.7 minutes to more than twenty, because every new tab
  // tore down and rebuilt the one renderer. The crawl reuses a single tab across
  // routes, so it never accumulates renderers anyway.
  `--remote-debugging-port=${PORT}`, '--user-data-dir=/tmp/arabic-ui-chrome-' + process.pid,
  'about:blank',
], {
  stdio: ['ignore', 'ignore', 'ignore'],
  // A reset box ships Chrome's shared libraries OUTSIDE the loader's path (the
  // bundled files are versioned, `libatk-1.0.so.0.25611.1`, with no SONAME
  // symlink). Without this the browser starts and dies before opening its
  // debugging port, and the crawl reports "no websocket" — a confusing failure
  // that says nothing about the product. Set here so the guard works from a bare
  // `node scripts/check-arabic-ui.mjs` with no shell setup.
  env: {
    ...process.env,
    ...(existsSync('/home/user/work/bin/chrome/libs/usr/lib/x86_64-linux-gnu')
      ? { LD_LIBRARY_PATH: '/home/user/work/bin/chrome/libs/usr/lib/x86_64-linux-gnu' }
      : {}),
  },
});
// A crawl that crashes must not leave a browser behind eating the box.
process.on('exit', () => { try { chromeProc.kill('SIGKILL'); } catch { /* gone */ } });
process.on('SIGINT', () => { try { chromeProc.kill('SIGKILL'); } catch { /* gone */ } process.exit(130); });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function wsUrl() {
  for (let i = 0; i < 100; i++) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/version`);
      if (res.ok) return (await res.json()).webSocketDebuggerUrl;
    } catch { /* not up yet */ }
    await sleep(100);
  }
  throw new Error('chromium did not expose a debugging websocket');
}

class CDP {
  constructor(ws) { this.ws = ws; this.id = 0; this.pending = new Map(); this.events = new Map();
    ws.addEventListener('message', (e) => {
      const msg = JSON.parse(e.data);
      if (msg.id && this.pending.has(msg.id)) {
        const { resolve, reject } = this.pending.get(msg.id); this.pending.delete(msg.id);
        msg.error ? reject(new Error(msg.error.message)) : resolve(msg.result);
      } else if (msg.method && this.events.has(msg.method)) {
        for (const fn of this.events.get(msg.method)) fn(msg.params);
      }
    });
  }
  send(method, params = {}, sessionId) {
    const id = ++this.id;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }));
    });
  }
  on(method, fn) { if (!this.events.has(method)) this.events.set(method, []); this.events.get(method).push(fn); }
}

async function main() {
  const url = await wsUrl();
  const ws = new WebSocket(url);
  await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', rej); });
  const cdp = new CDP(ws);

  const { targetId } = await cdp.send('Target.createTarget', { url: 'about:blank' });
  const { sessionId } = await cdp.send('Target.attachToTarget', { targetId, flatten: true });
  const S = (m, p) => cdp.send(m, p, sessionId);

  await S('Page.enable');
  await S('Runtime.enable');
  await S('Network.enable');
  await S('Emulation.setDeviceMetricsOverride', { width: 375, height: 812, deviceScaleFactor: 1, mobile: true });
  await S('Emulation.setTouchEmulationEnabled', { enabled: true, maxTouchPoints: 5 });

  // ── settling ─────────────────────────────────────────────────────────────
  // A fixed sleep measures whatever happened to be on screen: the same route
  // reported 41 and 71 overflowing elements on two runs because one measured a
  // skeleton and the other measured the table. Count in-flight requests instead
  // and wait for quiet, so BEFORE and AFTER are measured on the same page state.

  // ── error tracing ────────────────────────────────────────────────────────
  // A page can look "clean" because it silently bounced to /login after a 401.
  // Every non-2xx API response per route is kept so a failure is explainable
  // instead of mysterious.
  let trace = [];
  cdp.on('Network.responseReceived', (e) => {
    const u = e.response && e.response.url;
    if (u && u.includes('/api/') && e.response.status >= 400) {
      trace.push(`${e.response.status} ${u.replace(BASE, '').replace(/\?.*$/, '')}`);
    }
  });

  // Values that belong to the customer, not to the product: gym name, branch
  // names, staff names, member names. Everything here is allowed by decision.
  let userData = [];

  const evaluate = async (expression) => {
    const r = await S('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true });
    if (r.exceptionDetails) throw new Error(r.exceptionDetails.text + ' ' + (r.exceptionDetails.exception?.description || ''));
    return r.result.value;
  };

  // ── login once, reuse cookies ────────────────────────────────────────────
  async function login(email, password) {
    await S('Page.navigate', { url: `${BASE}/login` });
    await sleep(2500);
    const out = await evaluate(`(async () => {
      const r = await fetch('/api/health/live', { credentials: 'include' });
      const csrf = document.cookie.split(';').map(v => v.trim()).find(v => v.startsWith('_csrf='))?.slice(6) || '';
      const res = await fetch('/api/auth/login', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': decodeURIComponent(csrf) },
        body: JSON.stringify({ email: ${JSON.stringify(email)}, password: ${JSON.stringify(password)} }),
      });
      return { status: res.status, body: await res.text() };
    })()`);
    return out;
  }

  // optional session state: cookie jars captured by previous runs. More than one
  // may be given (--state=tenant.json,portal.json) because the staff app and the
  // member portal are different identities with different cookie names.
  const results = [];
  for (const file of STATE ? String(STATE).split(',').map((f) => f.trim()).filter(Boolean) : []) {
    if (!existsSync(file)) throw new Error(`--state file not found: ${file}`);
    const cookies = JSON.parse(readFileSync(file, 'utf8'));
    for (const c of cookies) {
      // A member jar captured on `localhost` is useless when the crawl runs on
      // `127.0.0.1` (a cookie is host-scoped), and the portal then redirects to
      // its login page — reported as AUTH BROKEN even though the session is
      // valid. Write the jar for BOTH hosts so the portal routes are reachable
      // whichever hostname `--base` names. Other domains are left untouched.
      const hosts = c.domain === 'localhost' ? ['localhost', '127.0.0.1'] : [c.domain];
      for (const domain of hosts) {
        await S('Network.setCookie', { name: c.name, value: c.value, domain, path: c.path || '/', httpOnly: c.httpOnly, secure: c.secure, sameSite: c.sameSite });
      }
    }
    console.log(`state: loaded ${cookies.length} cookies from ${file}`);
  }

  // ── authenticate ONCE, then crawl with those cookies ─────────────────────
  // Without a real session the tenant screens are unreachable and the crawl
  // would silently grade the login page. So: log in, prove it, and treat any
  // later redirect back to a login page as a harness error.
  if (!SKIP_LOGIN) {
    if (!EMAIL || !PASSWORD) {
      throw new Error(
        'no credentials: pass --email/--password (or ARABIC_UI_EMAIL/ARABIC_UI_PASSWORD) so the app routes can be reached; use --no-login for a public-only run',
      );
    }
    const out = await login(EMAIL, PASSWORD);
    const ok = out.status === 200 || out.status === 201;
    console.log(`login ${EMAIL} → HTTP ${out.status}${ok ? '' : ' (FAILED)'}`);
    if (!ok) {
      throw new Error(`login failed (HTTP ${out.status}): ${out.body.slice(0, 300)}`);
    }
    if (SAVE_STATE) {
      const { cookies } = await S('Network.getAllCookies');
      mkdirSync(dirname(SAVE_STATE), { recursive: true });
      writeFileSync(SAVE_STATE, JSON.stringify(cookies, null, 2));
      console.log(`saved ${cookies.length} cookies → ${SAVE_STATE}`);
    }
  }

  // --screens=a,b limits the crawl to those paths (still capped by --max-routes).
  const queue = (ONLY ? ROUTES.filter(([p]) => ONLY.includes(p)) : ROUTES).slice(0, MAX_ROUTES);
  if (ONLY && queue.length === 0) throw new Error(`--screens matched no route: ${ONLY.join(',')}`);
  if (USER_DATA_MODE === 'auto') {
    // One round-trip per collection, using the session we already hold. Retried:
    // on a cold start the first page load can fire before the session cookie is
    // visible to the requests, and a missing gym name would leave the tenant's
    // real name looking like product English.
    await S('Page.navigate', { url: `${BASE}/dashboard` });
    await sleep(3000);
    const collect = () => evaluate(`(async () => {
      const out = [];
      const grab = async (url, pick) => {
        try {
          const r = await fetch(url, { credentials: 'include' });
          if (!r.ok) return;
          const j = await r.json();
          // a list endpoint returns an array or {items:[…]}; /gyms/me returns ONE object
          const rows = Array.isArray(j) ? j
            : (j.items || j.data || j.members || j.branches || (typeof j.name === 'string' ? [j] : []));
          for (const row of rows) { const v = pick(row); if (v) for (const piece of String(v).split('\u0000')) if (piece) out.push(piece); }
        } catch { /* a collection we cannot read simply contributes nothing */ }
      };
      await grab('/api/gyms/me', (g) => g && g.name);
      await grab('/api/gyms/me', (g) => g && g.slug); // printed on the member portal login
      await grab('/api/branches', (b) => b && b.name);
      // PAGINATED, because the list endpoint caps a page: with 35 members in the
      // database '/api/members?take=100' returned 20 and '?limit=100' returned 22,
      // so 13 real member names were never learned and their rows read as product
      // Latin. Measured on the demo gym, not assumed.
      for (let page = 1; page <= 20; page++) {
        const before = out.length;
        try {
          const r = await fetch('/api/members?limit=100&page=' + page, { credentials: 'include' });
          if (r.ok) {
            const j = await r.json();
            for (const row of (j.items || [])) if (row && row.name) out.push(String(row.name));
          }
        } catch { /* a page we cannot read contributes nothing */ }
        if (out.length === before) break;   // a page with nothing new ends the walk
      }
      // The names on /attendance come from the attendance rows, and a row can
      // reference a member the list above does not return.
      await grab('/api/attendance?limit=200', (a) => a && a.memberName);
      // /ai prints the gym's own stored suggestions; that is the customer's text.
      // AiSuggestion columns are title / description / action / impact — the
      // rendered sentence lives in description (measured against the schema; the
      // first version guessed "text" and learned nothing).
      for (const f of ['title', 'description', 'action', 'impact']) {
        await grab('/api/ai/suggestions', (x) => x && x[f]);
      }
      await grab('/api/users', (u) => u && u.name);
      await grab('/api/users', (u) => u && u.email);
      await grab('/api/auth/me', (u) => u && u.name);
      // The owner console shows platform-admin identity and gym slugs - both are
      // the customer's/operator's own data, not product text.
      await grab('/api/platform/auth/me', (a) => a && a.admin && a.admin.name);
      await grab('/api/platform/auth/me', (a) => a && a.admin && a.admin.email);
      await grab('/api/platform/admins', (a) => a && a.name);
      await grab('/api/platform/admins', (a) => a && a.email);
      await grab('/api/products', (p) => p && p.name);
      await grab('/api/products', (p) => p && p.sku);
      await grab('/api/classes/templates', (c) => c && c.name);   // class names are the gym's own text
      await grab('/api/classes/sessions', (c) => c && c.title);
      await grab('/api/products', (p) => p && p.category);
      await grab('/api/plans', (p) => p && p.name);
      await grab('/api/branches', (b) => b && b.address);
      await grab('/api/campaigns', (c) => c && c.name);
      await grab('/api/platform/gyms', (g) => g && g.slug);
      await grab('/api/platform/gyms', (g) => g && g.name);
      // the gyms list carries the owner's name and contact on the gym row
      await grab('/api/platform/gyms', (g) => g && g.ownerName);
      await grab('/api/platform/gyms', (g) => g && g.email);
      await grab('/api/platform/gyms', (g) => g && g.phone);
      await grab('/api/platform/subscriptions', (s) => s && s.ownerEmail);
      await grab('/api/platform/subscriptions', (s) => s && s.ownerPhone);
      // Any address or phone the console shows is the customer's own data, wherever
      // the payload nests it. Sweeping by SHAPE catches a field this list does not
      // name yet, instead of letting it read as product English.
      await grab('/api/platform/subscriptions', (row) => {
        const found = [];
        const walk = (v) => {
          if (typeof v === 'string' && (/^[^@ ]+@[^@ ]+[.][a-z]{2,}$/i.test(v) || /^[+]?[0-9]{10,15}$/.test(v))) found.push(v);
          else if (v && typeof v === 'object') Object.values(v).forEach(walk);
        };
        walk(row);
        return found.length ? found.join('\u0000') : null;
      });
      return [...new Set(out)].sort((a, b) => b.length - a.length);
    })()`);
    for (let attempt = 0; attempt < 3; attempt++) {
      userData = await collect();
      USER_DATA = userData;
      if (userData.some((v) => /[A-Za-z]/.test(v))) break; // the gym name arrived
      await sleep(1500);
    }
    console.log(`user-data: excluding ${userData.length} customer values: ${userData.join(' · ')}`);
  }

  for (const [path, kind, tabText] of queue) {
    const target = `${BASE}${path}`;
    trace = [];
    let nav;
    try {
      // A single hung page must not hang the build: 20s deadline, then measure
      // whatever is on screen and move on.
      nav = await Promise.race([
        S('Page.navigate', { url: target }),
        sleep(20000).then(() => ({ timedOut: true })),
      ]);
      // Fixed wait, not a network-idle probe: the probe's injected fetch counter
      // stalled the run on pages that keep a request open (a dashboard polling
      // every few seconds never reports idle), and Runtime.evaluate then never
      // returned. 3.5 s covers the slowest route measured (landing, 2.9 s).
      await sleep(3500);
      // a tab route: click it, then let the matrix load before measuring
      if (tabText) {
        const clicked = await evaluate(`(() => {
          const b = [...document.querySelectorAll('button,[role=tab],a')]
            .find((e) => (e.innerText || '').includes(${JSON.stringify('__TAB__')}));
          if (!b) return 'none';
          b.click();
          return 'ok';
        })()`.replace('__TAB__', tabText));
        if (clicked !== 'ok') {
          console.error(`check-arabic-ui: tab ${JSON.stringify(tabText)} not found on ${path}`);
          process.exitCode = 1;
        }
        await sleep(3000);
      }
      const doc = await evaluate(`({ url: location.pathname, title: document.title, ready: document.readyState })`);
      const collected = await evaluate(`(() => {
        const clean = (s) => (s || '').replace(/\\s+/g, ' ').trim();
        const visible = [];
        const walk = (node) => {
          if (node.nodeType === 3) {
            const t = clean(node.textContent);
            if (!t) return;
            const el = node.parentElement;
            if (!el) return;
            const cs = getComputedStyle(el);
            if (cs.display === 'none' || cs.visibility === 'hidden' || Number(cs.opacity) === 0) return;
            const r = el.getBoundingClientRect();
            if (r.width === 0 && r.height === 0) return;
            visible.push(t);
            return;
          }
          if (node.nodeType !== 1) return;
          const el = node;
          if (['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE'].includes(el.tagName)) return;
          for (const attr of ['placeholder', 'aria-label', 'title', 'alt']) {
            const v = clean(el.getAttribute(attr));
            if (v) visible.push(v);
          }
          // A checkbox/radio carries the literal value "on" by default and never
          // displays it; the same is true for the other non-text input types.
          const TEXTLESS_INPUTS = ['hidden', 'password', 'checkbox', 'radio', 'submit', 'button', 'reset', 'file', 'range', 'color'];
          if (el.tagName === 'INPUT' && !TEXTLESS_INPUTS.includes(el.type) && el.value) {
            const v = clean(el.value);
            if (v && v.length < 120) visible.push(v);
          }
          for (const child of el.childNodes) walk(child);
        };
        walk(document.body);
        // metrics
        const docW = document.documentElement.scrollWidth;
        const vw = window.innerWidth;
        const overflowing = [];
        for (const el of document.querySelectorAll('*')) {
          const r = el.getBoundingClientRect();
          if (r.width > vw + 2) {
            const sel = el.tagName.toLowerCase() + (el.className && typeof el.className === 'string' ? '.' + el.className.split(' ').filter(Boolean).slice(0, 2).join('.') : '');
            overflowing.push({ sel, w: Math.round(r.width) });
          }
        }
        const smallTargets = [];
        for (const el of document.querySelectorAll('a,button,[role="button"],input,select,textarea')) {
          const r = el.getBoundingClientRect();
          if (r.width === 0 || r.height === 0) continue;
          if (r.height < 44 || r.width < 44) {
            const label = (el.getAttribute('aria-label') || el.textContent || el.getAttribute('placeholder') || el.tagName).toString().trim().slice(0, 40);
            smallTargets.push({ label, w: Math.round(r.width), h: Math.round(r.height) });
          }
        }
        return {
          texts: [...new Set(visible)],
          textCount: visible.length,
          overflow: { docW, vw, els: overflowing.slice(0, 12), count: overflowing.length },
          smallTargets: smallTargets.slice(0, 40),
          smallTargetCount: smallTargets.length,
          // Only tables that actually paint: a table converted to cards on a
          // phone is still in the DOM for desktop and for assistive tech.
          tables: [...document.querySelectorAll('table')].filter((t) => {
            const cs = getComputedStyle(t);
            const r = t.getBoundingClientRect();
            return cs.display !== 'none' && cs.visibility !== 'hidden' && r.width > 0 && r.height > 0;
          }).length,
          tablesAsCards: document.querySelectorAll('.mobile-table-cards').length,
          bottomNav: !!document.querySelector('[data-testid="bottom-nav"], nav.bottom-nav'),
        };
      })()`);

      // Per-string pass: the violation list names the WHOLE rendered string, so a
      // report can quote the exact copy instead of twelve loose words.
      const latinTexts = [];
      const judgeable = [];
      if (!USER_DATA.length && USER_DATA_REQUIRED) {
        throw new Error('--user-data=auto collected nothing: every screen would be graded as clean for the wrong reason');
      }
      for (const oneRaw of [...collected.texts, doc.title]) {
        // One scrubber for both passes: the customer's own values are removed, and
        // a string that is really an identifier is not judged as copy at all.
        const one = scrubbable(oneRaw);
        if (one === null) continue;
        judgeable.push(one);
        const hits = latinViolations(one, 'text', path);
        if (hits.length) {
          latinTexts.push({ text: oneRaw.slice(0, 180), words: [...new Set(hits.map((h) => h.text))].slice(0, 12) });
        }
      }
      // the aggregate judges exactly the strings the per-string pass judged
      const all = judgeable.join(' \n ');
      const latin = latinViolations(all, 'text', path);
      const keys = keyLeaks(all, 'text');

      // A gated page = we asked for an authenticated screen and landed on a
      // login screen instead. That is a BROKEN RUN, not a clean page: grading the
      // login page 40 times would report success while measuring nothing.
      const LOGIN_URLS = ['/login', '/portal/login', '/platform/login'];
      const gated =
        !LOGIN_URLS.includes(path) && LOGIN_URLS.includes(doc.url);

      const rec = {
        path, kind, gated, finalUrl: doc.url, title: doc.title,
        latinCount: latin.length, latin: latinTexts.slice(0, 60),
        _aggregate: [...new Set(latin.map((x) => x.text))].slice(0, 20),
        keyLeaks: [...new Set(keys.map((k) => k.text))].slice(0, 20),
        apiErrors: [...new Set(trace)].slice(0, 12),
        overflowCount: collected.overflow.count, overflowW: collected.overflow.docW, vw: collected.overflow.vw,
        smallTargetCount: collected.smallTargetCount, smallTargets: collected.smallTargets,
        tables: collected.tables, bottomNav: collected.bottomNav, texts: collected.texts.length,
      };
      results.push(rec);

      if (OUT) {
        mkdirSync(OUT, { recursive: true });
        const shot = await S('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
        const name = path === '/' ? 'root' : path.replace(/^\//, '').replace(/\//g, '-');
        writeFileSync(`${OUT}/${name}.png`, Buffer.from(shot.data, 'base64'));
      }
      if (trace.length) console.log(`     ↳ ${[...new Set(trace)].slice(0, 4).join(' | ')}`);
      console.log(`${gated ? 'GATE' : latin.length || keys.length ? '✗   ' : '✓   '} ${path.padEnd(34)} latin=${String(latin.length).padStart(3)} keys=${keys.length} overflow=${collected.overflow.count} small=${collected.smallTargetCount} tables=${collected.tables}`);
      // print WHAT the Latin words are, not just how many: a count alone tells
      // nobody which string to fix
      if (latin.length || keys.length) {
        for (const one of latinTexts.slice(0, 12)) {
          console.log(`      latin: ${JSON.stringify(one.text)}  ← ${one.words.join(' | ')}`);
        }
        if (keys.length) console.log(`      keys:  ${JSON.stringify(collected.rawKeys?.slice(0, 8) || keys.slice(0, 8))}`);
      }
    } catch (e) {
      results.push({ path, kind, error: String(e.message || e) });
      console.error(`! ${path}: ${e.message || e}`);
    }
  }

  // ── report ───────────────────────────────────────────────────────────────
  const totals = results.reduce((acc, r) => {
    acc.latin += r.latinCount || 0;
    acc.keys += (r.keyLeaks || []).length;
    acc.overflow += r.overflowCount || 0;
    acc.small += r.smallTargetCount || 0;
    acc.tables += r.tables || 0;
    if (r.gated && !ALLOW_GATED.has(r.path)) acc.gated += 1;
    acc.screens += 1;
    return acc;
  }, { latin: 0, keys: 0, overflow: 0, small: 0, tables: 0, screens: 0, gated: 0 });

  console.log(`\nSCREENS ${totals.screens} · LATIN ${totals.latin} · KEY-LEAKS ${totals.keys} · OVERFLOWING SCREENS ${totals.overflow} · SMALL TARGETS ${totals.small} · TABLES ${totals.tables} · GATED ${totals.gated}`);
  if (totals.gated) {
    console.error(`\nAUTH BROKEN: ${totals.gated} authenticated route(s) redirected to a login page — nothing was measured there.`);
    for (const r of results) if (r.gated && !ALLOW_GATED.has(r.path)) console.error(`   ${r.path} → ${r.finalUrl}`);
    if (JSON_OUT) { mkdirSync(dirname(JSON_OUT), { recursive: true }); writeFileSync(JSON_OUT, JSON.stringify({ base: BASE, generatedAt: new Date().toISOString(), totals, results }, null, 2)); }
    await cdp.send('Browser.close').catch(() => {});
    return 2;
  }

  if (JSON_OUT) {
    mkdirSync(dirname(JSON_OUT), { recursive: true });
    writeFileSync(JSON_OUT, JSON.stringify({ base: BASE, generatedAt: new Date().toISOString(), totals, results }, null, 2));
    console.log(`wrote ${JSON_OUT}`);
  }

  await cdp.send('Browser.close').catch(() => {});
  const violations = totals.latin + totals.keys;
  return violations === 0 ? 0 : 1;
}

main()
  .then((code) => { chromeProc.kill('SIGKILL'); process.exit(code); })
  .catch((e) => { console.error('check-arabic-ui FAILED:', e.message); chromeProc.kill('SIGKILL'); process.exit(2); });
