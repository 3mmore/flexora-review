#!/usr/bin/env node
/**
 * LOCAL-ONLY dev helper: produce the cookie jar for the member-portal crawl.
 *
 * WHY THIS EXISTS
 *   The member portal authenticates by OTP over WhatsApp, and the API refuses to
 *   even issue a code unless the gym has WhatsApp configured
 *   (`code: WHATSAPP_NOT_CONFIGURED`). The demo gym does not, and a test harness
 *   must not be able to read a real member's code — that is the design working.
 *   But the Arabic-UI guard has to reach the 10 portal screens; otherwise it
 *   grades the portal login page ten times and reports success while measuring
 *   nothing.
 *
 *   So this script mints a MEMBER token with the same secret and the same claims
 *   the portal's own verify-otp would sign (see portal.service.ts), for a demo
 *   member, and writes the two cookies the browser would hold. It reads the
 *   secret but never prints it, refuses to run against a non-local database, and
 *   is imported by nothing in the app.
 *
 * USAGE
 *   node scripts/portal-state.mjs --mobile=01012345678 [--slug=demo] [--out=...]
 */
import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { createHmac, randomBytes } from 'node:crypto';
import { dirname, resolve } from 'node:path';

const args = Object.fromEntries(
  process.argv.slice(2).map((a) => {
    const [k, ...v] = a.replace(/^--/, '').split('=');
    return [k, v.length ? v.join('=') : true];
  }),
);
const MOBILE = String(args.mobile || '');
const SLUG = String(args.slug || 'demo');
const OUT = args.out ? resolve(String(args.out)) : '/tmp/portal-state.json';
const API = String(args.api || 'http://127.0.0.1:4000').replace(/\/+$/, '');
// Browser host for the cookie jar. The owner console refuses a hostname that
// disagrees with the one Next proxies to, so this is not cosmetic.
const HOST = process.env.MEASURE_HOST || 'localhost';
if (!MOBILE) {
  console.error('portal-state: --mobile is required (a member mobile in the demo gym)');
  process.exit(2);
}

// ── secrets from the api .env (never printed) ───────────────────────────────
const envFile = new URL('../../api/.env', import.meta.url);
const env = Object.fromEntries(
  readFileSync(envFile, 'utf8')
    .split('\n')
    .filter((l) => l && !l.startsWith('#') && l.includes('='))
    .map((l) => {
      const i = l.indexOf('=');
      return [l.slice(0, i).trim(), l.slice(i + 1).trim()];
    }),
);
const secret = env.JWT_MEMBER_SECRET;
if (!secret) {
  console.error('portal-state: JWT_MEMBER_SECRET missing from apps/api/.env');
  process.exit(2);
}
const dbUrl = env.DATABASE_URL || env.DATABASE_URL_BASE || '';
if (dbUrl && !/@(127\.0\.0\.1|localhost)[:/]/.test(dbUrl)) {
  console.error('portal-state: refusing — DATABASE_URL is not a localhost database');
  process.exit(2);
}

// ── pick the member the API will resolve for this mobile ───────────────────
const psql = (sql) =>
  execFileSync('psql', ['-U', 'postgres', '-h', '127.0.0.1', '-d', 'flexora', '-Atc', sql], {
    // no default password in a shipped file: the operator supplies the local
    // database password through the environment (see .env.example)
    env: { ...process.env, PGPASSWORD: env.PGPASSWORD_OWNER || '' },
    encoding: 'utf8',
  }).trim();

const row = psql(
  `select m.id, m."gymId", m.name, m.mobile from "Member" m join "Gym" g on g.id = m."gymId"
   where g.slug = '${SLUG}' and m.mobile = '${MOBILE}' limit 1;`,
);
if (!row) {
  console.error(`portal-state: no member with mobile ${MOBILE} in gym '${SLUG}'`);
  process.exit(2);
}
const [memberId, gymId, name] = row.split('|');

// ── sign the token exactly as portal.service.ts does ────────────────────────
const b64 = (o) => Buffer.from(JSON.stringify(o)).toString('base64url');
const now = Math.floor(Date.now() / 1000);
const payload = {
  sub: memberId,
  memberId,
  gymId,
  role: 'MEMBER',
  mobile: MOBILE,
  name,
  jti: randomBytes(16).toString('hex'),
  iss: 'flexora-api',
  aud: 'flexora-member',
  iat: now,
  exp: now + 24 * 3600,
};
const signingInput = `${b64({ alg: 'HS256', typ: 'JWT' })}.${b64(payload)}`;
const token = `${signingInput}.${createHmac('sha256', secret).update(signingInput).digest('base64url')}`;

// ── prove the token is accepted before writing it out ──────────────────────
const probe = await fetch(`${API}/api/portal/me`, { headers: { Cookie: `flx_member_access=${token}` } });
if (!probe.ok) {
  console.error(`portal-state: token rejected by /api/portal/me → ${probe.status} ${(await probe.text()).slice(0, 200)}`);
  process.exit(1);
}
const me = await probe.json().catch(() => ({}));
console.log(`member session OK: ${me.name || name} (${memberId.slice(0, 8)}…) ${me.status ? '[' + me.status + ']' : ''}`);

const jar = [
  { name: 'flx_member_access', value: token, domain: HOST, path: '/', httpOnly: true, secure: false, sameSite: 'Strict' },
  { name: 'flx_member_session', value: '1', domain: HOST, path: '/', httpOnly: false, secure: false, sameSite: 'Strict' },
];
mkdirSync(dirname(OUT), { recursive: true });
writeFileSync(OUT, JSON.stringify(jar, null, 2));
console.log(`portal cookies → ${OUT}`);
