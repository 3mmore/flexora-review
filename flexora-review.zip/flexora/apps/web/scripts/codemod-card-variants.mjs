#!/usr/bin/env node
/**
 * FLEXORA — Card variant codemod (OPTIONAL / gradual migration)
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Rewrites legacy <Card variant="..."> usages to the new Obsidian design system:
 *     glow      -> ai
 *     elevated  -> kpi
 *     outline   -> default
 *
 * This is OPTIONAL. The Card component already maps these internally, so the app
 * works without running this. Use it only to make source reflect the new names.
 *
 * Safety:
 *   - Dependency-free (Node built-ins only).
 *   - DRY-RUN by default — prints a diff summary, writes nothing.
 *   - Pass --write to actually apply changes.
 *   - Only rewrites the `variant="..."` value on JSX where the literal matches;
 *     handles single OR double quotes. Leaves everything else untouched.
 *
 * Usage:
 *   node scripts/codemod-card-variants.mjs            # dry run (default)
 *   node scripts/codemod-card-variants.mjs --write    # apply changes
 *   node scripts/codemod-card-variants.mjs --write src/app/dashboard   # scope a dir
 */
import { readdirSync, readFileSync, writeFileSync, statSync } from 'node:fs';
import { join, extname } from 'node:path';

const WRITE = process.argv.includes('--write');
const args = process.argv.slice(2).filter((a) => a !== '--write');
const ROOT = args[0] || 'src';

const MAP = { glow: 'ai', elevated: 'kpi', outline: 'default' };

// Match variant="X" or variant='X' where X is a legacy value.
const RE = /\bvariant=(["'])(glow|elevated|outline)\1/g;

/** Recursively collect .tsx/.ts files. */
function walk(dir) {
  const out = [];
  for (const entry of readdirSync(dir)) {
    const p = join(dir, entry);
    const st = statSync(p);
    if (st.isDirectory()) {
      if (['node_modules', '.next', 'dist', '.git'].includes(entry)) continue;
      out.push(...walk(p));
    } else if (['.tsx', '.ts'].includes(extname(p))) {
      out.push(p);
    }
  }
  return out;
}

let filesChanged = 0;
let totalReplacements = 0;
const summary = [];

for (const file of walk(ROOT)) {
  const src = readFileSync(file, 'utf8');
  if (!/\bvariant=/.test(src)) continue;

  let count = 0;
  const next = src.replace(RE, (_m, q, legacy) => {
    count++;
    return `variant=${q}${MAP[legacy]}${q}`;
  });

  if (count > 0) {
    filesChanged++;
    totalReplacements += count;
    summary.push(`  ${file}: ${count} replacement(s)`);
    if (WRITE) writeFileSync(file, next, 'utf8');
  }
}

console.log(`\nFLEXORA Card variant codemod (${WRITE ? 'WRITE' : 'DRY-RUN'})`);
console.log(`Scope: ${ROOT}`);
console.log(`Mapping: glow→ai, elevated→kpi, outline→default\n`);
if (summary.length) {
  console.log(summary.join('\n'));
  console.log(`\n${totalReplacements} replacement(s) across ${filesChanged} file(s).`);
  if (!WRITE) console.log('Run again with --write to apply.');
} else {
  console.log('No legacy Card variant literals found. Nothing to do.');
}
