#!/usr/bin/env bash
# Start the built Next app (never `next dev`: ~20 s per route and OOM here).
set -u
cd /home/user/work/flexora/apps/web || exit 1
export PORT=3000
export API_PROXY_TARGET='http://127.0.0.1:4000'
export NEXT_PUBLIC_API_URL=''
# middleware.ts verifies flx_access itself, so the web service needs the same
# secret as apps/api — the same value apps/web/.env.example documents.
export JWT_ACCESS_SECRET="$(grep -m1 '^JWT_ACCESS_SECRET=' ../api/.env | cut -d= -f2-)"
# See start-api.sh: unset + NODE_ENV=production would refuse every console request.
export ADMIN_HOSTS='localhost,127.0.0.1'
exec ./node_modules/.bin/next start -p 3000
