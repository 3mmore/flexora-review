// FLEXORA Gym OS — apps/web ESLint flat config (Item 12)
//
// Next.js 16 removed `next lint` entirely (see the Next.js 16 upgrade
// guide: "next lint is deprecated and removed in Next.js 16 — migrate to
// the ESLint CLI"), and apps/web's package.json still had
// `"lint": "next lint"`, which fails immediately on this Next.js version.
// This is a minimal, real, working flat config (ESLint v9+ format) using
// @next/eslint-plugin-next directly (rather than eslint-config-next's
// legacy-config + FlatCompat bridge, which throws a circular-JSON error
// under this dependency combination), so `npm run lint` actually lints
// something instead of erroring out.
import js from '@eslint/js';
import tseslint from 'typescript-eslint';
import nextPlugin from '@next/eslint-plugin-next';

export default tseslint.config(
  {
    ignores: ['.next/**', 'node_modules/**', 'out/**'],
  },
  js.configs.recommended,
  ...tseslint.configs.recommended,
  {
    plugins: { '@next/next': nextPlugin },
    rules: {
      ...nextPlugin.configs.recommended.rules,
      // First time ESLint has been wired up for this app (Item 12).
      // Downgraded to "warn" rather than fixing unrelated pre-existing
      // files as part of "add a CI pipeline."
      '@typescript-eslint/no-explicit-any': 'off',
      '@typescript-eslint/no-unused-vars': ['warn', { argsIgnorePattern: '^_' }],
      '@next/next/no-assign-module-variable': 'warn',
      'no-useless-escape': 'warn',
    },
  },
);
