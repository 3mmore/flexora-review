/*
 * FLEXORA Gym OS - brand pre-paint
 * (c) 2024 Ammar Allam. All rights reserved.
 *
 * WHY THIS IS A FILE AND NOT AN INLINE SCRIPT (PHASE R0.5, owner decision)
 * This code used to be inlined into the root layout with dangerouslySetInnerHTML,
 * which put its path skip-list - including the owner-console prefix - into EVERY
 * HTML document the app serves, on every hostname: the marketing page, the login
 * page and even the 404 page all named the console path twice. Measured with
 * work/r0-evidence.sh section G before the move: "'/platform' occurrences=2" in
 * ctl-web-home-public, ctl-web-login-public and ref-unknown-web-public.
 * Serving it as a same-origin file removes the string (and all inline script) from
 * the HTML, which is also what lets the owner console carry a strict CSP with
 * script-src 'self' and no 'unsafe-inline' (PHASE R1.8).
 *
 * It is loaded with a plain blocking <script src> - NOT async, NOT defer, NOT
 * next/script - because it has to run before first paint: that is the whole reason
 * it exists (the recurring "still gold" report, see the comment in app/layout.tsx).
 *
 * Residual risk, reported honestly: the skip-list below is still readable by anyone
 * who fetches this file. What the move removes is the leak from every HTML
 * document; it does not make the console path unguessable. The console answers a
 * plain 404 on any hostname that is not in ADMIN_HOSTS, so knowing the path buys an
 * attacker nothing they can act on.
 *
 * BEHAVIOUR IS UNCHANGED from the inlined version - same list, same order, same
 * localStorage key, same CSS custom properties. Proven by
 * work/r0-brand-prepaint.spec.js (Playwright, 375px): the accent is applied on a
 * tenant page and is NOT applied on a console page.
 */
(function () {
  try {
    var SKIP = ['/login', '/register', '/portal', '/billing', '/onboarding', '/license', '/platform', '/landing', '/'];
    var p = location.pathname;
    for (var i = 0; i < SKIP.length; i++) { if (SKIP[i] === '/' ? p === '/' : p.indexOf(SKIP[i]) === 0) return; }
    var raw = localStorage.getItem('flexora-brand-v1'); if (!raw) return;
    var b = JSON.parse(raw); if (!b || (Date.now() - (b.at || 0)) > 604800000) return; var c = b.accent; if (!c) return;
    var h = String(c).replace('#', ''); if (!/^[0-9a-fA-F]{6}$/.test(h)) return;
    var n = parseInt(h, 16), r = (n >> 16) & 255, g = (n >> 8) & 255, bl = n & 255;
    var dr = Math.round(r * 0.4), dg = Math.round(g * 0.4), db = Math.round(bl * 0.4);
    var dim = '#' + ((dr << 16) | (dg << 8) | db).toString(16).padStart(6, '0');
    var st = document.documentElement.style;
    st.setProperty('--brand', c);
    st.setProperty('--brand-rgb', r + ', ' + g + ', ' + bl);
    st.setProperty('--brand-dim', dim);
    st.setProperty('--brand-dim-rgb', dr + ', ' + dg + ', ' + db);
    st.setProperty('--cyan', c); st.setProperty('--cyan-text', c); st.setProperty('--primary', c);
    st.setProperty('--primary-dim', dim); st.setProperty('--info', c);
    st.setProperty('--cyan-dim', dim);
    st.setProperty('--cyan-glow', 'rgba(' + r + ',' + g + ',' + bl + ',0.25)');
    st.setProperty('--cyan-border', 'rgba(' + r + ',' + g + ',' + bl + ',0.3)');
    st.setProperty('--primary-soft', 'rgba(' + r + ',' + g + ',' + bl + ',0.14)');
    st.setProperty('--primary-border', 'rgba(' + r + ',' + g + ',' + bl + ',0.26)');
    st.setProperty('--primary-glow', 'rgba(' + r + ',' + g + ',' + bl + ',0.25)');
    var lum = (0.299 * r + 0.587 * g + 0.114 * bl) / 255;
    st.setProperty('--btn-text', lum > 0.6 ? '#000000' : '#ffffff');
  } catch (e) { }
})();
