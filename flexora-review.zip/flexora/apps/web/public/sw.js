/* ===========================================================================
   FLEXORA Gym OS — Service Worker
   © 2024 Ammar Allam. All rights reserved.

   PACK 2 · STEP 2.3 — rewritten. The previous version cached EVERY navigation
   response stale-while-revalidate, which meant the HTML of /dashboard, /members
   and /api-backed pages stayed readable in Cache Storage after the user signed
   out on a shared desk tablet. It also served that stale HTML in preference to
   the network on the next load. Both are gone.

   The rules below mirror src/lib/pwa-cache-policy.ts, which is unit-tested and
   whose invariants are asserted against THIS FILE by
   src/lib/__tests__/pwa-cache-policy.spec.ts. If you change one, change both.

     1. non-GET                     → network only
     2. /api/…                      → network only (account data, never stored)
     3. navigation (HTML)           → network first, /offline on failure,
                                      NEVER written to a cache
     4. build output (js/css/img)   → cache first, refreshed in the background
     5. anything else               → network only
     6. message CLEAR_CACHE         → delete every cache (sign-out)
   =========================================================================== */
const CACHE_VERSION = 'flexora-static-v3';
const ASSET_CACHE = `${CACHE_VERSION}-assets`;
const OFFLINE_URL = '/offline';

/* Only static files are pre-cached. No HTML, no API. */
const PRECACHE = ['/offline', '/manifest.webmanifest', '/manifest-staff.webmanifest', '/icon-192.png', '/icon-512.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches
      .open(ASSET_CACHE)
      .then((c) => Promise.all(PRECACHE.map((url) => c.add(url).catch(() => undefined))))
      .catch(() => undefined),
  );
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== ASSET_CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

/* Sign-out: the next account on this device must find nothing. */
self.addEventListener('message', (e) => {
  if (e.data && e.data.type === 'CLEAR_CACHE') {
    e.waitUntil(
      caches
        .keys()
        .then((keys) => Promise.all(keys.map((k) => caches.delete(k))))
        .then(() => {
          if (e.source) e.source.postMessage({ type: 'CACHE_CLEARED' });
        }),
    );
  }
});

const ASSET_RE = /\.(?:woff2?|png|jpe?g|gif|svg|ico|webp|css|js|webmanifest)$/i;

self.addEventListener('fetch', (e) => {
  const request = e.request;
  if (request.method !== 'GET') return; // 1

  let url;
  try {
    url = new URL(request.url);
  } catch {
    return;
  }
  if (url.origin !== self.location.origin) return; // never proxy third parties

  // 2 — account data is never stored, and when offline the app is told plainly
  if (url.pathname === '/api' || url.pathname.startsWith('/api/')) {
    e.respondWith(
      fetch(request).catch(
        () =>
          new Response(JSON.stringify({ offline: true, code: 'OFFLINE', message: 'لا يوجد اتصال بالإنترنت' }), {
            status: 503,
            headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' },
          }),
      ),
    );
    return;
  }

  // 3 — HTML: network first, offline page on failure. Nothing is written.
  if (request.mode === 'navigate') {
    e.respondWith(
      fetch(request).catch(async () => {
        const offline = await caches.match(OFFLINE_URL);
        return offline || new Response('', { status: 503, statusText: 'offline' });
      }),
    );
    return;
  }

  // 4 — build output: cache first, then refresh in the background
  if (ASSET_RE.test(url.pathname)) {
    e.respondWith(
      caches.match(request).then(
        (cached) =>
          cached ||
          fetch(request).then((res) => {
            if (res && res.ok) {
              const copy = res.clone();
              caches.open(ASSET_CACHE).then((c) => c.put(request, copy)).catch(() => undefined);
            }
            return res;
          }),
      ),
    );
    return;
  }

  // 5 — everything else: the network, and nothing kept
});
