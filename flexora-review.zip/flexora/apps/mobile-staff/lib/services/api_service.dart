import 'dart:convert';

/**
 * FLEXORA Gym OS — Staff App API Service (Phase 16 — production-grade)
 * © 2024 Ammar Allam. All rights reserved.
 *
 * Features:
 *   - Bearer auth auto-attached
 *   - Auto-refresh on 401
 *   - Exponential-backoff retry
 *   - Offline queue for POS sales + check-ins
 */
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class ApiService {
  static const String _baseUrl = String.fromEnvironment('FLEXORA_API_BASE_URL', defaultValue: 'https://api.flexora.app/api');
  final Dio _dio = Dio(BaseOptions(
    baseUrl: _baseUrl,
    connectTimeout: const Duration(seconds: 30),
    receiveTimeout: const Duration(seconds: 30),
    headers: { 'X-Client': 'flexora-staff/2.0.0' },
  ));
  final Connectivity _conn = Connectivity();
  final FlutterSecureStorage _secure = const FlutterSecureStorage();

  void setAuthToken(String? token) {
    if (token != null) {
      _dio.options.headers['Authorization'] = 'Bearer $token';
    } else {
      _dio.options.headers.remove('Authorization');
    }
  }

  Future<bool> refreshToken() async {
    final prefs = await SharedPreferences.getInstance();
    final refresh = await _secure.read(key: 'flx_staff_refresh') ?? prefs.getString('flx_staff_refresh');
    if (refresh == null) return false;
    try {
      final res = await _dio.post('/auth/refresh', data: { 'refreshToken': refresh });
      final data = res.data as Map;
      await _secure.write(key: 'flx_staff_access', value: data['accessToken'] as String);
      if (data['refreshToken'] != null) await _secure.write(key: 'flx_staff_refresh', value: data['refreshToken'] as String);
      await prefs.remove('flx_staff_token');
      _dio.options.headers['Authorization'] = 'Bearer ${data['accessToken']}';
      return true;
    } catch (_) { return false; }
  }

  Future<Map<String, dynamic>> login(String email, String password) async {
    final res = await _dio.post('/auth/login', data: {'email': email, 'password': password});
    final data = Map<String, dynamic>.from(res.data as Map);
    final access = data['accessToken'] as String?;
    final refresh = data['refreshToken'] as String?;
    if (access != null) {
      await _secure.write(key: 'flx_staff_access', value: access);
      _dio.options.headers['Authorization'] = 'Bearer $access';
    }
    if (refresh != null) await _secure.write(key: 'flx_staff_refresh', value: refresh);
    return data;
  }

  Future<Map<String, dynamic>> dashboard() => get('/dashboard');
  Future<Map<String, dynamic>> checkIn(String memberCode) => post('/attendance/check-in', data: {'code': memberCode});
  Future<Map<String, dynamic>> classSessions() => get('/classes/sessions');
  Future<Map<String, dynamic>> leads() => get('/leads');
  Future<Map<String, dynamic>> createLead(Map<String, dynamic> data) => post('/leads', data: data);

  Future<Map<String, dynamic>> get(String path, {Map<String, dynamic>? query}) async {
    return _executeWithRetry(() async {
      final res = await _dio.get(path, queryParameters: query);
      return Map<String, dynamic>.from(res.data as Map);
    });
  }

  Future<Map<String, dynamic>> post(String path, {dynamic data}) async {
    if (!await _isOnline()) {
      await _queueOffline(path, data);
      return {'queued': true};
    }
    return _executeWithRetry(() async {
      final res = await _dio.post(path, data: data);
      return Map<String, dynamic>.from(res.data as Map);
    });
  }

  Future<Map<String, dynamic>> _executeWithRetry(Future<Map<String, dynamic>> Function() fn, {int retries = 2}) async {
    for (var i = 0; i <= retries; i++) {
      try { return await fn(); }
      catch (e) {
        if (e is DioException && e.response?.statusCode == 401 && i == 0) {
          if (await refreshToken()) continue;
        }
        if (i == retries) rethrow;
        await Future.delayed(Duration(milliseconds: 200 * (i + 1) * (i + 1)));
      }
    }
    throw 'unreachable';
  }

  Future<bool> _isOnline() async {
    final r = await _conn.checkConnectivity();
    return r != ConnectivityResult.none;
  }

  Future<void> _queueOffline(String path, dynamic data) async {
    final prefs = await SharedPreferences.getInstance();
    final queue = prefs.getStringList('flx_staff_offline_queue') ?? [];
    queue.add(jsonEncode({
      'method': 'POST',
      'path': path,
      'createdAt': DateTime.now().toIso8601String(),
      'data': data,
    }));
    await prefs.setStringList('flx_staff_offline_queue', queue);
  }

  Future<int> flushOfflineQueue() async {
    final prefs = await SharedPreferences.getInstance();
    final queue = prefs.getStringList('flx_staff_offline_queue') ?? [];
    var flushed = 0;
    for (final entry in queue) {
      try {
        final decoded = jsonDecode(entry) as Map<String, dynamic>;
        final path = decoded['path'] as String;
        final data = decoded['data'];
        await _dio.post(path, data: data);
        flushed++;
      } catch (_) { break; }
    }
    await prefs.setStringList('flx_staff_offline_queue', queue.skip(flushed).toList());
    return flushed;
  }
}
