/**
 * FLEXORA Gym OS — Staff Auth Service (Phase 16)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:shared_preferences/shared_preferences.dart';
class AuthService {
  static const _k = 'flx_staff_token';
  Future<String?> getToken() async => (await SharedPreferences.getInstance()).getString(_k);
  Future<void> setToken(String t) async => (await SharedPreferences.getInstance()).setString(_k, t);
  Future<void> logout() async => (await SharedPreferences.getInstance()).clear();
}
