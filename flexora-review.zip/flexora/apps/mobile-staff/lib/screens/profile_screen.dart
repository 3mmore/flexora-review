/**
 * FLEXORA Gym OS — Staff Profile (Phase 16 — extension)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profile'), backgroundColor: Colors.black),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(child: Column(children: [
            const CircleAvatar(radius: 48, backgroundColor: Color(0xFF00CFFF), child: Text('SS', style: TextStyle(color: Colors.black, fontSize: 28, fontWeight: FontWeight.bold))),
            const SizedBox(height: 12),
            const Text('Sara Salah', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
            const Text('OWNER · Nasr City', style: TextStyle(color: Colors.white60)),
          ])),
          const SizedBox(height: 24),
          Card(
            color: Colors.grey[900],
            child: Column(children: [
              const ListTile(title: Text('Email', style: TextStyle(color: Colors.white60)), trailing: Text('owner@demo.flexora.app', style: TextStyle(color: Colors.white))),
              const Divider(color: Colors.white10, height: 1),
              const ListTile(title: Text('Branch', style: TextStyle(color: Colors.white60)), trailing: Text('Nasr City', style: TextStyle(color: Colors.white))),
              const Divider(color: Colors.white10, height: 1),
              const ListTile(title: Text('2FA', style: TextStyle(color: Colors.white60)), trailing: Text('✓ Enabled', style: TextStyle(color: Colors.green))),
            ]),
          ),
          const SizedBox(height: 24),
          OutlinedButton(
            onPressed: () => Navigator.pushReplacementNamed(context, '/login'),
            style: OutlinedButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Sign out'),
          ),
        ],
      ),
    );
  }
}
