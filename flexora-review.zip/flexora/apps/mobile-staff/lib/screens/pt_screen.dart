/**
 * FLEXORA Gym OS — PT Sessions (Phase 16)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:flutter/material.dart';
class PtScreen extends StatelessWidget {
  const PtScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final sessions = [
      {'member': 'Ahmed Hassan', 'time': 'Today 4:00 PM', 'duration': '60 min'},
      {'member': 'Mariam Adel', 'time': 'Today 5:00 PM', 'duration': '60 min'},
      {'member': 'Youssef Ibrahim', 'time': 'Tomorrow 10:00 AM', 'duration': '90 min'},
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('PT Sessions'), backgroundColor: Colors.black),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: sessions.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (_, i) => Card(color: Colors.grey[900], child: ListTile(
          leading: const Icon(Icons.fitness_center, color: Color(0xFF00CFFF)),
          title: Text(sessions[i]['member']!, style: const TextStyle(color: Colors.white)),
          subtitle: Text('${sessions[i]['time']} · ${sessions[i]['duration']}', style: const TextStyle(color: Colors.white60)),
          trailing: OutlinedButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Checked in: ${sessions[i]['member']}'))), child: const Text('Check in')),
        )),
      ),
    );
  }
}
