/**
 * FLEXORA Gym OS — QR Check-in (Phase 16)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

class CheckinScreen extends StatelessWidget {
  const CheckinScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Check-in'), backgroundColor: Colors.black),
      body: Stack(children: [
        MobileScanner(controller: MobileScannerController(detectionSpeed: DetectionSpeed.normal), onDetect: (capture) {
          for (final b in capture.barcodes) {
            final code = b.rawValue ?? '';
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Checked in: $code'), backgroundColor: const Color(0xFF00CFFF)));
          }
        }),
        Positioned(bottom: 24, left: 0, right: 0, child: Center(child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          decoration: BoxDecoration(color: Colors.black.withOpacity(0.7), borderRadius: BorderRadius.circular(20)),
          child: const Text('Scan member QR', style: TextStyle(color: Color(0xFF00CFFF), fontWeight: FontWeight.bold)),
        ))),
      ]),
    );
  }
}
