/**
 * FLEXORA Gym OS — Notifications (Phase 16)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:flutter/material.dart';
class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final items = [
      ('🚨', 'Low stock: Creatine (4 units left)'),
      ('🎂', 'Member Ahmed Hassan birthday tomorrow'),
      ('📊', 'Daily report ready — 23 check-ins today'),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Notifications'), backgroundColor: Colors.black),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (_, i) => Card(color: Colors.grey[900], child: ListTile(
          leading: Text(items[i].$1, style: const TextStyle(fontSize: 28)),
          title: Text(items[i].$2, style: const TextStyle(color: Colors.white)),
        )),
      ),
    );
  }
}
