/**
 * FLEXORA Gym OS — Inventory (Phase 16)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:flutter/material.dart';
class InventoryScreen extends StatelessWidget {
  const InventoryScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final items = [
      {'name': 'Whey Protein 2kg', 'qty': 18, 'low': 5},
      {'name': 'Creatine 300g', 'qty': 4, 'low': 5},
      {'name': 'Water 600ml', 'qty': 120, 'low': 24},
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Inventory'), backgroundColor: Colors.black),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (_, i) {
          final low = items[i]['qty']! < items[i]['low']!;
          return Card(color: Colors.grey[900], child: ListTile(
            leading: Icon(Icons.inventory, color: low ? Colors.red : const Color(0xFF00CFFF)),
            title: Text(items[i]['name']!, style: const TextStyle(color: Colors.white)),
            subtitle: Text('Qty: ${items[i]['qty']} / low alert: ${items[i]['low']}${low ? ' ⚠️ LOW STOCK' : ''}', style: TextStyle(color: low ? Colors.red : Colors.white60)),
          ));
        },
      ),
    );
  }
}
