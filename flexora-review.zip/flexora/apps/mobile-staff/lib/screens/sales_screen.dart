/**
 * FLEXORA Gym OS — POS / Sales (Phase 16)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:flutter/material.dart';
class SalesScreen extends StatefulWidget {
  const SalesScreen({super.key});
  @override
  State<SalesScreen> createState() => _SalesScreenState();
}
class _SalesScreenState extends State<SalesScreen> {
  final _cart = <Map<String, dynamic>>[];
  final _products = [
    {'name': 'Whey Protein', 'price': 1450.0},
    {'name': 'Creatine', 'price': 520.0},
    {'name': 'Water', 'price': 10.0},
    {'name': 'Energy Bar', 'price': 35.0},
  ];

  @override
  Widget build(BuildContext context) {
    final total = _cart.fold<double>(0, (s, it) => s + (it['price'] as double) * (it['qty'] as int));
    return Scaffold(
      appBar: AppBar(title: const Text('POS'), backgroundColor: Colors.black),
      body: Column(children: [
        Expanded(child: ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: _products.length,
          itemBuilder: (_, i) => Card(
            color: Colors.grey[900],
            child: ListTile(
              title: Text(_products[i]['name']!, style: const TextStyle(color: Colors.white)),
              subtitle: Text('EGP ${_products[i]['price']}', style: const TextStyle(color: Color(0xFF00CFFF))),
              trailing: FilledButton(
                style: FilledButton.styleFrom(backgroundColor: const Color(0xFF00CFFF), foregroundColor: Colors.black),
                onPressed: () => setState(() => _cart.add({..._products[i], 'qty': 1})),
                child: const Text('Add'),
              ),
            ),
          ),
        )),
        if (_cart.isNotEmpty) Container(
          padding: const EdgeInsets.all(16),
          color: Colors.grey[900],
          child: Row(children: [
            Expanded(child: Text('${_cart.length} items · EGP ${total.toStringAsFixed(2)}', style: const TextStyle(color: Color(0xFF00CFFF), fontWeight: FontWeight.bold, fontSize: 18))),
            FilledButton(
              style: FilledButton.styleFrom(backgroundColor: const Color(0xFF00CFFF), foregroundColor: Colors.black),
              onPressed: () {
                setState(() => _cart.clear());
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Sale completed!')));
              },
              child: const Text('Checkout'),
            ),
          ]),
        ),
      ]),
    );
  }
}
