/**
 * FLEXORA Gym OS — Leads (Phase 16)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:flutter/material.dart';

class LeadsScreen extends StatelessWidget {
  const LeadsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final leads = [
      {'name': 'Ahmed Mostafa', 'phone': '01001234567', 'score': 92, 'status': 'HOT'},
      {'name': 'Mariam Saleh', 'phone': '01112345678', 'score': 78, 'status': 'WARM'},
      {'name': 'Khaled Raafat', 'phone': '01223456789', 'score': 65, 'status': 'WARM'},
      {'name': 'Layla Hassan', 'phone': '01534567890', 'score': 41, 'status': 'COLD'},
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Leads'), backgroundColor: Colors.black),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: leads.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (_, i) => Card(
          color: Colors.grey[900],
          child: ListTile(
            title: Text(leads[i]['name']!, style: const TextStyle(color: Colors.white)),
            subtitle: Text(leads[i]['phone']!, style: const TextStyle(color: Colors.white60)),
            trailing: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: leads[i]['status'] == 'HOT' ? Colors.red : (leads[i]['status'] == 'WARM' ? Colors.orange : Colors.grey),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text('${leads[i]['score']}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
          ),
        ),
      ),
    );
  }
}
