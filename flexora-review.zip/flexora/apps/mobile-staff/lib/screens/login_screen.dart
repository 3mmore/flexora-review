/**
 * FLEXORA Gym OS — Staff Login (Phase 16)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:flutter/material.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _pwd = TextEditingController();
  bool _busy = false;

  Future<void> _login() async {
    setState(() => _busy = true);
    await Future.delayed(const Duration(milliseconds: 500));
    setState(() => _busy = false);
    if (mounted) Navigator.of(context).pushReplacementNamed('/home');
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const Text('FLEXORA', style: TextStyle(color: Color(0xFF00CFFF), fontSize: 36, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          const Text('Staff', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 48),
          TextField(controller: _email, decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: _pwd, obscureText: true, decoration: const InputDecoration(labelText: 'Password', border: OutlineInputBorder())),
          const SizedBox(height: 24),
          SizedBox(width: double.infinity, child: FilledButton(
            style: FilledButton.styleFrom(backgroundColor: const Color(0xFF00CFFF), foregroundColor: Colors.black),
            onPressed: _busy ? null : _login,
            child: Text(_busy ? 'Signing in…' : 'Sign in'),
          )),
        ]),
      ),
    ),
  );
}
