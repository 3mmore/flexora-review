/**
 * FLEXORA Gym OS — Staff Mobile App (Phase 16)
 * © 2024 Ammar Allam. All rights reserved.
 */
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'services/auth_service.dart';
import 'services/api_service.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'screens/checkin_screen.dart';
import 'screens/leads_screen.dart';
import 'screens/pt_screen.dart';
import 'screens/inventory_screen.dart';
import 'screens/sales_screen.dart';
import 'screens/notifications_screen.dart';
import 'screens/profile_screen.dart';

void main() => runApp(const FlexoraStaffApp());

class FlexoraStaffApp extends StatelessWidget {
  const FlexoraStaffApp({super.key});
  @override
  Widget build(BuildContext context) => MultiProvider(
    providers: [
      Provider<AuthService>(create: (_) => AuthService()),
      Provider<ApiService>(create: (_) => ApiService()),
    ],
    child: MaterialApp.router(
      title: 'FLEXORA Staff',
      theme: ThemeData(
        brightness: Brightness.dark,
        primaryColor: const Color(0xFF00CFFF),
        scaffoldBackgroundColor: Colors.black,
        colorScheme: const ColorScheme.dark(primary: Color(0xFF00CFFF), surface: Colors.black),
        useMaterial3: true,
      ),
      routerConfig: GoRouter(
        initialLocation: '/login',
        routes: [
          GoRoute(path: '/login', builder: (_, __) => const LoginScreen()),
          GoRoute(path: '/home', builder: (_, __) => const HomeScreen()),
          GoRoute(path: '/checkin', builder: (_, __) => const CheckinScreen()),
          GoRoute(path: '/leads', builder: (_, __) => const LeadsScreen()),
          GoRoute(path: '/pt', builder: (_, __) => const PtScreen()),
          GoRoute(path: '/inventory', builder: (_, __) => const InventoryScreen()),
          GoRoute(path: '/sales', builder: (_, __) => const SalesScreen()),
          GoRoute(path: '/notifications', builder: (_, __) => const NotificationsScreen()),
        GoRoute(path: '/profile', builder: (_, __) => const ProfileScreen()),
        ],
      ),
    ),
  );
}
