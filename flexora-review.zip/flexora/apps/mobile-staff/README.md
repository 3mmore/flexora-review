# FLEXORA Gym OS — Staff Mobile App (Phase 16)

Flutter app for gym staff (reception, coaches, manager).
© 2024 Ammar Allam. WhatsApp: +20XXXXXXXXXX

## Build

```bash
cd apps/mobile-staff
flutter pub get
flutter analyze
flutter build apk --release
flutter build ios --release
```

## Screens

- Login (email + password)
- Home (grid menu)
- QR Check-in (camera scanner)
- Leads (with AI score)
- PT Sessions
- Inventory (with low-stock alerts)
- POS / Sales
- Notifications
