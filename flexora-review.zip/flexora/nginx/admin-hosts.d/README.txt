FLEXORA PHASE R0 — production admin hostnames for the nginx host gate
(c) 2024 Ammar Allam. All rights reserved.

nginx/nginx.conf ends its admin-host map with:

    include /etc/nginx/admin-hosts.d/*.map;

which is this directory (compose mounts it read-only). Add a production admin
hostname WITHOUT editing nginx.conf, by creating a file here whose name ends in
.map, containing one line per hostname:

    console.example.com 1;

Rules, identical to ADMIN_HOSTS in the api and the web app:
  * one hostname per line, followed by a space and `1;`
  * never a wildcard — a console that answers on every hostname is a console on the
    public origin (the api and the web app reject wildcards too, so a wildcard here
    would only make nginx disagree with them)
  * never a name under the reserved `.invalid` TLD: nginx itself sends
    Host: host-gate.denied.invalid upstream for console requests that arrive on a
    public hostname, and ADMIN_HOSTS refuses to accept it
  * `host:port` is NOT supported by this map (it keys on $host, which never carries
    a port). Pin ports in ADMIN_HOSTS if you need to.
  * after editing: `docker compose exec nginx nginx -t` then
    `docker compose exec nginx nginx -s reload`

The three lists must agree — ADMIN_HOSTS (api), ADMIN_HOSTS (web) and this
directory. scripts/check-admin-hosts-parity.py fails the build when they drift.

A fresh install ships this directory with no .map file, which is deliberate: trial
mode allows the console on localhost and 127.0.0.1 only.
